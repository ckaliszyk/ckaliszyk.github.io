theory axioms
  imports xreal_0
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, s for "RealXREAL-0M1"
mlemma axioms_lm_1:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 x9 & s =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies r <=XXREAL-0R1 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 x9 & s =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2)) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1)))) or ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies  not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1))"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume A1: "((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 x9 & s =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
    show "((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2)) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1)))) or ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies  not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1))"
    proof-
      have cases: "(r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2 or r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or  not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
         sorry
      have case1: "r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2 implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2))"
      proof(rule impI)
        assume "r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2"
        thus " not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2))"
          using A1 arytm_0_th_5 xboole_0_th_3 sorry
      qed
      have case2: "r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1))"
      proof(rule impI)
        assume "r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        thus " not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1))"
          using A1 arytm_0_th_5 xboole_0_th_3 sorry
      qed
      have case3: " not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies  not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1)"
      proof(rule impI)
        assume " not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        thus " not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1)"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x, y, z for "RealXREAL-0M1"
mlemma axioms_lm_2:
" for x be RealXREAL-0M1 holds  for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] implies x2 =XBOOLE-0R4 0NUMBERSK6 & x =HIDDENR1 x1"
proof-
  have " for x be RealXREAL-0M1 holds  for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] implies (x2 <>HIDDENR2 0NUMBERSK6 implies  False ) & x =HIDDENR1 x1"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
    assume A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
    have A2: "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    show "x2 <>HIDDENR2 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "x2 <>HIDDENR2 0NUMBERSK6"
      then have "x =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(x1,x2)"
        using A1 arytm_0_def_5 sorry
      thus " False "
        using A2 arytm_0_th_8 sorry
    qed
    thus "x =HIDDENR1 x1"
      using A1 arytm_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma axioms_lm_3:
" for x9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x9 =HIDDENR1 x & y9 =HIDDENR1 y implies +ARYTM-0K1(x9,y9) =XBOOLE-0R4 x +XCMPLX-0K2 y"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  assume A1: "x9 =HIDDENR1 x & y9 =HIDDENR1 y"
  obtain x1 x2 y1 y2 where
    [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
    A2: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A3: "x +XCMPLX-0K2 y =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
    using xcmplx_0_def_4 sorry
  have "x2 =XBOOLE-0R4 0NUMBERSK6 & y2 =XBOOLE-0R4 0NUMBERSK6"
    using A2 axioms_lm_2 sorry
  then have A4: "+ARYTM-0K1(x2,y2) =XBOOLE-0R4 0NUMBERSK6"
    using arytm_0_th_11 sorry
  have "x =HIDDENR1 x1 & y =HIDDENR1 y1"
    using A2 axioms_lm_2 sorry
  thus "+ARYTM-0K1(x9,y9) =XBOOLE-0R4 x +XCMPLX-0K2 y"
    using A1 A3 A4 arytm_0_def_5 sorry
qed "sorry"

mlemma axioms_lm_4:
"{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
  using tarski_def_1 sorry

reserve r, r1, r2 for "ElementSUBSET-1M1-of REAL+ARYTM-2K2"
mtheorem axioms_th_1:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 y) implies ( ex z be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y)"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 y) implies ( ex tVar1 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not (x <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 y)))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 y"
    show " ex tVar1 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not (x <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 y))"
    proof-
      have cases: "(X =XBOOLE-0R4 0NUMBERSK6 or Y =XBOOLE-0R4 0NUMBERSK6) or X <>HIDDENR2 0NUMBERSK6 & Y <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "X =XBOOLE-0R4 0NUMBERSK6 or Y =XBOOLE-0R4 0NUMBERSK6 implies ( ex tVar1 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not (x <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 y)))"
      proof(rule impI)
        assume A2: "X =XBOOLE-0R4 0NUMBERSK6 or Y =XBOOLE-0R4 0NUMBERSK6"
        show " ex tVar1 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not (x <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 y))"
        proof(rule bexI[of _ "\<one>\<^sub>M"])
          show " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not (x <=XXREAL-0R1 \<one>\<^sub>M & \<one>\<^sub>M <=XXREAL-0R1 y))"
            using A2 sorry
        qed "sorry"
      qed
      have case2: "X <>HIDDENR2 0NUMBERSK6 & Y <>HIDDENR2 0NUMBERSK6 implies  not ( for z be RealXREAL-0M1 holds  not ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not (x <=XXREAL-0R1 z & z <=XXREAL-0R1 y))))"
      proof(rule impMI ,rule impI)
        assume A3: "X <>HIDDENR2 0NUMBERSK6"
          and A4: "Y <>HIDDENR2 0NUMBERSK6"
        obtain x1 where
          [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A5: "x1 inTARSKIR2 X"
          using A3 subset_1_th_4 sorry
        have A6: "X c=TARSKIR1 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using numbers_def_1 xboole_1_th_1 sorry
        have A7: "Y c=TARSKIR1 REAL+ARYTM-2K2 \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using numbers_def_1 xboole_1_th_1 sorry
        have A8: " ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st x2 inTARSKIR2 Y"
          using A4 subset_1_th_4 sorry
        show " not ( for z be RealXREAL-0M1 holds  not ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((x inHIDDENR3 X & y inHIDDENR3 Y) &  not (x <=XXREAL-0R1 z & z <=XXREAL-0R1 y))))"
        proof-
          have " ex z be ElementSUBSET-1M1-of omegaORDINAL1K4 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
          proof-
            show " ex z be ElementSUBSET-1M1-of omegaORDINAL1K4 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
            proof-
              have cases: "(X missesXBOOLE-0R1 REAL+ARYTM-2K2 & Y missesXBOOLE-0R1 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] or Y meetsXBOOLE-0R5 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or X meetsXBOOLE-0R5 REAL+ARYTM-2K2"
                 sorry
              have case1: "X missesXBOOLE-0R1 REAL+ARYTM-2K2 & Y missesXBOOLE-0R1 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex z be ElementSUBSET-1M1-of omegaORDINAL1K4 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y)"
              proof(rule impMI ,rule impI)
                assume A9: "X missesXBOOLE-0R1 REAL+ARYTM-2K2"
                  and A10: "Y missesXBOOLE-0R1 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                obtain z where 
                  [ty]:"z be ElementSUBSET-1M1-of omegaORDINAL1K4" and zDef:"z = 0NUMBERSK6"
                   sorry
                show " ex z be ElementSUBSET-1M1-of omegaORDINAL1K4 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
                  fix x assume [ty]: "x be RealXREAL-0M1"
                  fix y assume [ty]: "y be RealXREAL-0M1"
                  assume A11: "x inHIDDENR3 X"
                    and A12: "y inHIDDENR3 Y"
                  have " not z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] &  not x inHIDDENR3 REAL+ARYTM-2K2"
                    using A9 A11 arytm_0_th_5 arytm_2_th_20 xboole_0_th_3 sorry
                  thus "x <=XXREAL-0R1 z"
                    using xxreal_0_def_5 sorry
                  have "Y c=TARSKIR1 REAL+ARYTM-2K2"
                    using A7 A10 xboole_1_th_73 sorry
                  then obtain y9 o where 
                    [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y" and
                    [ty]:"o be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and oDef:"o = 0NUMBERSK6"
                    using A12 arytm_2_th_20 sorry
                  have "o <='ARYTM-2R1 y9"
                    using arytm_1_th_6 sorry
                  thus "z <=XXREAL-0R1 y"
                    using axioms_lm_1 sorry
                qed "sorry"
              qed
              have case2: "Y meetsXBOOLE-0R5 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ( ex tVar3 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 tVar3 & tVar3 <=XXREAL-0R1 y)"
              proof(rule impI)
                assume A13: "Y meetsXBOOLE-0R5 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                have "{r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 X } c=TARSKIR1 REAL+ARYTM-2K2"
                proof-
                  have "{r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 X } c=TARSKIR1 REAL+ARYTM-2K2"
                  proof-
                    have " for u be objectHIDDENM1 holds u inHIDDENR3 {r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 X } implies u inHIDDENR3 REAL+ARYTM-2K2"
                    proof(rule ballI,rule impI)
                      fix u assume [ty]: "u be objectHIDDENM1"
                      assume "u inHIDDENR3 {r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 X }"
                      then have " ex r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st u =HIDDENR1 r & [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 X"
                         sorry
                      thus "u inHIDDENR3 REAL+ARYTM-2K2"
                         sorry
                    qed "sorry"
                    thus "{r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 X } c=TARSKIR1 REAL+ARYTM-2K2"
                      using tarski_def_3 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                then obtain X9 where 
                  [ty]:"X9 be SubsetSUBSET-1M2-of REAL+ARYTM-2K2" and X9Def:"X9 = {r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 X }"
                   sorry
                have "{r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 Y } c=TARSKIR1 REAL+ARYTM-2K2"
                proof-
                  have "{r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 Y } c=TARSKIR1 REAL+ARYTM-2K2"
                  proof-
                    have " for u be objectHIDDENM1 holds u inHIDDENR3 {r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 Y } implies u inHIDDENR3 REAL+ARYTM-2K2"
                    proof(rule ballI,rule impI)
                      fix u assume [ty]: "u be objectHIDDENM1"
                      assume "u inHIDDENR3 {r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 Y }"
                      then have " ex r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st u =HIDDENR1 r & [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 Y"
                         sorry
                      thus "u inHIDDENR3 REAL+ARYTM-2K2"
                         sorry
                    qed "sorry"
                    thus "{r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 Y } c=TARSKIR1 REAL+ARYTM-2K2"
                      using tarski_def_3 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                then obtain Y9 where 
                  [ty]:"Y9 be SubsetSUBSET-1M2-of REAL+ARYTM-2K2" and Y9Def:"Y9 = {r where r be ElementSUBSET-1M1-of REAL+ARYTM-2K2 : [TARSKIK4 0NUMBERSK6,r ] inHIDDENR3 Y }"
                   sorry
                obtain e where
                  [ty]:"e be objectHIDDENM1" and 
                  A14: "e inHIDDENR3 Y"and A15: "e inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  using A13 xboole_0_th_3 sorry
                obtain u y1 where
                  [ty]:"u be objectHIDDENM1" "y1 be objectHIDDENM1" and 
                  A16: "u inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A17: "y1 inHIDDENR3 REAL+ARYTM-2K2"and A18: "e =HIDDENR1 [TARSKIK4 u,y1 ]"
                  using A15 zfmisc_1_th_84 sorry
                have 
                  [ty]:"y1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                  using A17 sorry
                have "e inHIDDENR3 REALNUMBERSK2"
                  using A14 sorry
                then have A19: "[TARSKIK4 0NUMBERSK6,y1 ] inHIDDENR3 REALNUMBERSK2"
                  using A16 A18 tarski_def_1 sorry
                then obtain y0 where 
                  [ty]:"y0 be RealXREAL-0M1" and y0Def:"y0 = [TARSKIK4 0NUMBERSK6,y1 ]"
                   sorry
                have A20: "y0 inHIDDENR3 Y"
                  using A14 A16 A18 tarski_def_1 sorry
                then have A21: "y1 inTARSKIR2 Y9"
                   sorry
                have A22: "y0 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  using axioms_lm_4 zfmisc_1_th_87 sorry
                have A23: "X c=TARSKIR1 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                proof-
                  have " for u be objectHIDDENM1 holds u inHIDDENR3 X implies u inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                  proof(rule ballI,rule impI)
                    fix u assume [ty]: "u be objectHIDDENM1"
                    assume A24: "u inHIDDENR3 X"
                    then obtain x where 
                      [ty]:"x be RealXREAL-0M1" and xDef:"x = u"
                       sorry
                    have "x inHIDDENR3 REAL+ARYTM-2K2 implies  False "
                    proof(rule impI)
                      assume "x inHIDDENR3 REAL+ARYTM-2K2"
                      then have A25: " not x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                        using arytm_0_th_5 xboole_0_th_3 sorry
                      have "x <=XXREAL-0R1 y0 &  not y0 inHIDDENR3 REAL+ARYTM-2K2"
                        using A1 A22 A20 A24 arytm_0_th_5 xboole_0_th_3 sorry
                      thus " False "
                        using A25 xxreal_0_def_5 sorry
                    qed
                    thus "u inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using A6 A24 xboole_0_def_3 sorry
                  qed "sorry"
                  thus "X c=TARSKIR1 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                    using tarski_def_3 sorry
                qed
                then obtain e x3 where
                  [ty]:"e be objectHIDDENM1" "x3 be objectHIDDENM1" and 
                  A26: "e inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A27: "x3 inHIDDENR3 REAL+ARYTM-2K2"and A28: "x1 =HIDDENR1 [TARSKIK4 e,x3 ]"
                  using A5 zfmisc_1_th_84 sorry
                have 
                  [ty]:"x3 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                  using A27 sorry
                have "x1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x3 ]"
                  using A26 A28 tarski_def_1 sorry
                then have A29: "x3 inTARSKIR2 X9"
                  using A5 sorry
                have " for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y9 inTARSKIR2 Y9 & x9 inTARSKIR2 X9 implies y9 <='ARYTM-2R1 x9"
                proof-
                  have " for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y9 inTARSKIR2 Y9 implies (x9 inTARSKIR2 X9 implies y9 <='ARYTM-2R1 x9)"
                  proof(rule ballI,rule ballI,rule impI,rule impI)
                    fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                    fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                    assume "y9 inTARSKIR2 Y9"
                    then have A30: " ex r1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st y9 =XBOOLE-0R4 r1 & [TARSKIK4 0NUMBERSK6,r1 ] inHIDDENR3 Y"
                       sorry
                    assume "x9 inTARSKIR2 X9"
                    then have A31: " ex r2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x9 =XBOOLE-0R4 r2 & [TARSKIK4 0NUMBERSK6,r2 ] inHIDDENR3 X"
                       sorry
                    then obtain x y where 
                      [ty]:"x be RealXREAL-0M1" and xDef:"x = [TARSKIK4 0NUMBERSK6,x9 ]" and
                      [ty]:"y be RealXREAL-0M1" and yDef:"y = [TARSKIK4 0NUMBERSK6,y9 ]"
                      using A30 sorry
                    have A32: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using axioms_lm_4 zfmisc_1_th_87 sorry
                    have "x <=XXREAL-0R1 y"
                      using A1 A30 A31 sorry
                    then obtain x99 y99 where
                      [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                      A33: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A34: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & y99 <='ARYTM-2R1 x99"
                      using A32 xxreal_0_def_5 sorry
                    have "x9 =XBOOLE-0R4 x99"
                      using A33 xtuple_0_th_1 sorry
                    thus "y9 <='ARYTM-2R1 x9"
                      using A34 xtuple_0_th_1 sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                then obtain z9 where
                  [ty]:"z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                  A35: " for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y9 inTARSKIR2 Y9 & x9 inTARSKIR2 X9 implies y9 <='ARYTM-2R1 z9 & z9 <='ARYTM-2R1 x9"
                  using A29 arytm_2_th_8 sorry
                have A36: "y1 <>HIDDENR2 0NUMBERSK6"
                  using A19 arytm_0_th_3 sorry
                have "y1 <='ARYTM-2R1 z9"
                  using A21 A29 A35 sorry
                then have "[TARSKIK4 0NUMBERSK6,z9 ] inHIDDENR3 REALNUMBERSK2"
                  using A36 arytm_0_th_2 arytm_1_th_5 sorry
                then obtain z where 
                  [ty]:"z be RealXREAL-0M1" and zDef:"z = [TARSKIK4 0NUMBERSK6,z9 ]"
                   sorry
                show " ex tVar3 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 tVar3 & tVar3 <=XXREAL-0R1 y"
                proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impMI ,rule impI)
                  fix x assume [ty]: "x be RealXREAL-0M1"
                  fix y assume [ty]: "y be RealXREAL-0M1"
                  assume A37: "x inHIDDENR3 X"
                    and A38: "y inHIDDENR3 Y"
                  obtain e x9 where
                    [ty]:"e be objectHIDDENM1" "x9 be objectHIDDENM1" and 
                    A39: "e inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A40: "x9 inHIDDENR3 REAL+ARYTM-2K2"and A41: "x =HIDDENR1 [TARSKIK4 e,x9 ]"
                    using A23 A37 zfmisc_1_th_84 sorry
                  have 
                    [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                    using A40 sorry
                  have A42: "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                    using axioms_lm_4 zfmisc_1_th_87 sorry
                  have A43: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"
                    using A39 A41 tarski_def_1 sorry
                  then have A44: "x9 inTARSKIR2 X9"
                    using A37 sorry
                  show "x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                  proof-
                    have cases: "y inHIDDENR3 REAL+ARYTM-2K2 or y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using A7 A38 xboole_0_def_3 sorry
                    have case1: "y inHIDDENR3 REAL+ARYTM-2K2 implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                    proof(rule impI,rule conjMI)
                      assume A45: "y inHIDDENR3 REAL+ARYTM-2K2"
                      have "z9 <='ARYTM-2R1 x9"
                        using A21 A35 A44 sorry
                      thus "x <=XXREAL-0R1 z"
                        using A23 A42 A37 A43 axioms_lm_1 sorry
                      have A46: " not y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                        using A45 arytm_0_th_5 xboole_0_th_3 sorry
                      have " not z inHIDDENR3 REAL+ARYTM-2K2"
                        using A42 arytm_0_th_5 xboole_0_th_3 sorry
                      thus "z <=XXREAL-0R1 y"
                        using A46 xxreal_0_def_5 sorry
                    qed
                    have case2: "y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                    proof(rule impI)
                      assume A47: "y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      then obtain e y9 where
                        [ty]:"e be objectHIDDENM1" "y9 be objectHIDDENM1" and 
                        A48: "e inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"and A49: "y9 inHIDDENR3 REAL+ARYTM-2K2"and A50: "y =HIDDENR1 [TARSKIK4 e,y9 ]"
                        using zfmisc_1_th_84 sorry
                      have 
                        [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                        using A49 sorry
                      have A51: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"
                        using A48 A50 tarski_def_1 sorry
                      then have "y9 inTARSKIR2 Y9"
                        using A38 sorry
                      then have "y9 <='ARYTM-2R1 z9 & z9 <='ARYTM-2R1 x9"
                        using A35 A44 sorry
                      thus "x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                        using A23 A42 A37 A43 A47 A51 axioms_lm_1 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
              qed
              have case3: "X meetsXBOOLE-0R5 REAL+ARYTM-2K2 implies ( ex tVar4 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 tVar4 & tVar4 <=XXREAL-0R1 y)"
              proof(rule impI)
                assume A52: "X meetsXBOOLE-0R5 REAL+ARYTM-2K2"
                obtain X9 where 
                  [ty]:"X9 be SubsetSUBSET-1M2-of REAL+ARYTM-2K2" and X9Def:"X9 = X /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (REAL+ARYTM-2K2)"
                  using xboole_1_th_17 sorry
                obtain x1 where
                  [ty]:"x1 be objectHIDDENM1" and 
                  A53: "x1 inHIDDENR3 X"and A54: "x1 inHIDDENR3 REAL+ARYTM-2K2"
                  using A52 xboole_0_th_3 sorry
                have 
                  [ty]:"x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                  using A54 sorry
                have "x1 inTARSKIR2 REAL+ARYTM-2K2"
                   sorry
                then obtain x0 where 
                  [ty]:"x0 be RealXREAL-0M1" and x0Def:"x0 = x1"
                  using arytm_0_th_1 sorry
                have A55: "Y c=TARSKIR1 REAL+ARYTM-2K2"
                proof-
                  have " for u be objectHIDDENM1 holds u inHIDDENR3 Y implies u inHIDDENR3 REAL+ARYTM-2K2"
                  proof(rule ballI,rule impI)
                    fix u assume [ty]: "u be objectHIDDENM1"
                    assume A56: "u inHIDDENR3 Y"
                    then obtain y where 
                      [ty]:"y be RealXREAL-0M1" and yDef:"y = u"
                       sorry
                    have "y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  False "
                    proof(rule impI)
                      assume "y inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      then have A57: " not y inHIDDENR3 REAL+ARYTM-2K2"
                        using arytm_0_th_5 xboole_0_th_3 sorry
                      have "x0 <=XXREAL-0R1 y &  not x0 inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                        using A1 A53 A56 arytm_0_th_5 xboole_0_th_3 sorry
                      thus " False "
                        using A57 xxreal_0_def_5 sorry
                    qed
                    thus "u inHIDDENR3 REAL+ARYTM-2K2"
                      using A7 A56 xboole_0_def_3 sorry
                  qed "sorry"
                  thus "Y c=TARSKIR1 REAL+ARYTM-2K2"
                    using tarski_def_3 sorry
                qed
                then obtain Y9 where 
                  [ty]:"Y9 be SubsetSUBSET-1M2-of REAL+ARYTM-2K2" and Y9Def:"Y9 = Y"
                   sorry
                have " for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x9 inTARSKIR2 X9 & y9 inTARSKIR2 Y9 implies x9 <='ARYTM-2R1 y9"
                proof(rule ballI,rule ballI,rule impI)
                  fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                  fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
                  have A58: "X9 c=TARSKIR1 X"
                    using xboole_1_th_17 sorry
                  have "x9 inTARSKIR2 REAL+ARYTM-2K2 & y9 inTARSKIR2 REAL+ARYTM-2K2"
                     sorry
                  then obtain x y where 
                    [ty]:"x be RealXREAL-0M1" and xDef:"x = x9" and
                    [ty]:"y be RealXREAL-0M1" and yDef:"y = y9"
                    using arytm_0_th_1 sorry
                  assume "x9 inTARSKIR2 X9 & y9 inTARSKIR2 Y9"
                  then have "x <=XXREAL-0R1 y"
                    using A1 A58 sorry
                  then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 x9 & y =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9"
                    using xxreal_0_def_5 sorry
                  thus "x9 <='ARYTM-2R1 y9"
                     sorry
                qed "sorry"
                then obtain z9 where
                  [ty]:"z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                  A59: " for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x9 inTARSKIR2 X9 & y9 inTARSKIR2 Y9 implies x9 <='ARYTM-2R1 z9 & z9 <='ARYTM-2R1 y9"
                  using A8 arytm_2_th_8 sorry
                have "z9 inTARSKIR2 REAL+ARYTM-2K2"
                   sorry
                then obtain z where 
                  [ty]:"z be RealXREAL-0M1" and zDef:"z = z9"
                  using arytm_0_th_1 sorry
                show " ex tVar4 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 tVar4 & tVar4 <=XXREAL-0R1 y"
                proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impMI ,rule impI)
                  fix x assume [ty]: "x be RealXREAL-0M1"
                  fix y assume [ty]: "y be RealXREAL-0M1"
                  assume A60: "x inHIDDENR3 X"
                    and A61: "y inHIDDENR3 Y"
                  obtain y9 where 
                    [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = y"
                    using A55 A61 sorry
                  have A62: "x0 inHIDDENR3 X9"
                    using A53 xboole_0_def_4 sorry
                  show "x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                  proof-
                    have cases: "x inHIDDENR3 REAL+ARYTM-2K2 or x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using A6 A60 xboole_0_def_3 sorry
                    have case1: "x inHIDDENR3 REAL+ARYTM-2K2 implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                    proof(rule impI)
                      assume "x inHIDDENR3 REAL+ARYTM-2K2"
                      then obtain x9 where 
                        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = x"
                         sorry
                      have "x9 inTARSKIR2 X9"
                        using A60 xboole_0_def_4 sorry
                      then have "x9 <='ARYTM-2R1 z9 & z9 <='ARYTM-2R1 y9"
                        using A59 A61 sorry
                      thus "x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                        using axioms_lm_1 sorry
                    qed
                    have case2: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
                    proof(rule impI,rule conjMI)
                      assume A63: "x inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      have A64: " not z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                        using arytm_0_th_5 xboole_0_th_3 sorry
                      have " not x inHIDDENR3 REAL+ARYTM-2K2"
                        using A63 arytm_0_th_5 xboole_0_th_3 sorry
                      thus "x <=XXREAL-0R1 z"
                        using A64 xxreal_0_def_5 sorry
                      have "z9 <='ARYTM-2R1 y9"
                        using A62 A59 A61 sorry
                      thus "z <=XXREAL-0R1 y"
                        using axioms_lm_1 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem axioms_th_2:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 NATNUMBERSK1 & y inHIDDENR3 NATNUMBERSK1 implies x +XCMPLX-0K2 y inTARSKIR2 NATNUMBERSK1"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 NATNUMBERSK1 & y inHIDDENR3 NATNUMBERSK1 implies x +XCMPLX-0K2 y inTARSKIR2 NATNUMBERSK1"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    obtain x1 y1 where 
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and x1Def:"x1 = x" and
      [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" and y1Def:"y1 = y"
      using xreal_0_def_1 sorry
    have A1: "+ARYTM-0K1(x1,y1) =XBOOLE-0R4 x +XCMPLX-0K2 y"
      using axioms_lm_3 sorry
    assume A2: "x inHIDDENR3 NATNUMBERSK1 & y inHIDDENR3 NATNUMBERSK1"
    then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x1 =XBOOLE-0R4 x9 & y1 =XBOOLE-0R4 y9) & +ARYTM-0K1(x1,y1) =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
      using arytm_0_def_1 arytm_2_th_2 sorry
    thus "x +XCMPLX-0K2 y inTARSKIR2 NATNUMBERSK1"
      using A1 A2 arytm_2_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem axioms_th_3:
" for A be SubsetSUBSET-1M2-of REALNUMBERSK2 holds 0NUMBERSK6 inTARSKIR2 A & ( for x be RealXREAL-0M1 holds x inHIDDENR3 A implies x +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 A) implies NATNUMBERSK1 c=TARSKIR1 A"
proof(rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be SubsetSUBSET-1M2-of REALNUMBERSK2"
  assume A1: "0NUMBERSK6 inTARSKIR2 A"
    and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 A implies x +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 A"
  obtain B where 
    [ty]:"B be SubsetSUBSET-1M2-of REAL+ARYTM-2K2" and BDef:"B = A /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (REAL+ARYTM-2K2)"
    using xboole_1_th_17 sorry
  have A3: "B c=TARSKIR1 A"
    using xboole_1_th_17 sorry
  have A4: " for x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x9 inTARSKIR2 B & y9 =XBOOLE-0R4 \<one>\<^sub>M implies x9 +ARYTM-2K7 y9 inTARSKIR2 B"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A5: "x9 inTARSKIR2 B"
      and A6: "y9 =XBOOLE-0R4 \<one>\<^sub>M"
    obtain x where 
      [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and xDef:"x = x9"
      using arytm_0_th_1 sorry
    obtain y where 
      [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and yDef:"y = \<one>\<^sub>M"
      using numbers_th_19 sorry
    obtain xx where 
      [ty]:"xx be RealXREAL-0M1" and xxDef:"xx = x"
       sorry
    have "xx +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 A"
      using A2 A3 A5 sorry
    then have "( ex x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x99 & \<one>\<^sub>M =XBOOLE-0R4 y99) & +ARYTM-0K1(x,y) =XBOOLE-0R4 x99 +ARYTM-2K7 y99) & +ARYTM-0K1(x,y) inTARSKIR2 A"
      using axioms_lm_3 arytm_0_def_1 arytm_2_th_20 sorry
    thus "x9 +ARYTM-2K7 y9 inTARSKIR2 B"
      using A6 xboole_0_def_4 sorry
  qed "sorry"
  have "0NUMBERSK6 inTARSKIR2 B"
    using A1 arytm_2_th_20 xboole_0_def_4 sorry
  then have "NATNUMBERSK1 c=TARSKIR1 B"
    using A4 arytm_2_th_17 sorry
  thus "NATNUMBERSK1 c=TARSKIR1 A"
    using A3 sorry
qed "sorry"

mtheorem axioms_th_4:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k =HIDDENR1 {i where i be NatORDINAL1M6 : i <XXREAL-0R3 k }"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k =HIDDENR1 {i where i be NatORDINAL1M6 :  not i <XXREAL-0R3 k }"
  proof(rule ballI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "k inHIDDENR3 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    let ?Y = "{i where i be NatORDINAL1M6 : i <XXREAL-0R3 k }"
    obtain K where 
      [ty]:"K be ElementSUBSET-1M1-of NATNUMBERSK1" and KDef:"K = k"
      using ordinal1_def_12 sorry
    have " for e be objectHIDDENM1 holds e inHIDDENR3 K iff e inHIDDENR3 ?Y"
    proof-
      have " for e be objectHIDDENM1 holds (e inHIDDENR3 K implies e inHIDDENR3 {i where i be NatORDINAL1M6 : i <XXREAL-0R3 k }) & (e inHIDDENR3 {i where i be NatORDINAL1M6 : i <XXREAL-0R3 k } implies e inHIDDENR3 K)"
      proof(rule ballI,rule conjMI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        show "e inHIDDENR3 K implies e inHIDDENR3 {i where i be NatORDINAL1M6 : i <XXREAL-0R3 k }"
        proof-
          have "e inHIDDENR3 K implies e inHIDDENR3 {i where i be NatORDINAL1M6 :  not i <XXREAL-0R3 k }"
          proof(rule impI)
            assume A2: "e inHIDDENR3 K"
            have A3: "K c=ORDINAL1R1 NATNUMBERSK1"
              using ordinal1_def_2 sorry
            then obtain j where 
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = e"
              using A2 sorry
            have "e inHIDDENR3 NATNUMBERSK1"
              using A3 A2 sorry
            then obtain y9 where 
              [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = e"
              using arytm_2_th_2 sorry
            obtain x9 where 
              [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = K"
              using arytm_2_th_2 sorry
            have "y9 <='ARYTM-2R1 x9"
              using A2 arytm_2_th_18 sorry
            then have A4: "j <=XXREAL-0R1 k"
              using axioms_lm_1 sorry
            obtain yy9 where 
              [ty]:"yy9 be setHIDDENM2" and yy9Def:"yy9 = y9"
               sorry
            have " not yy9 inTARSKIR2 yy9"
               sorry
            then have "y9 <>HIDDENR2 x9"
              using A2 sorry
            then have "j <XXREAL-0R3 k"
              using A4 xxreal_0_th_1 sorry
            thus "e inHIDDENR3 {i where i be NatORDINAL1M6 :  not i <XXREAL-0R3 k }"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        assume "e inHIDDENR3 ?Y"
        then obtain i where
          [ty]:"i be NatORDINAL1M6" and 
          A5: "e =HIDDENR1 i"and A6: " not k <=XXREAL-0R1 i"
           sorry
        have A7: "i inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then obtain x9 y9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x9Def:"x9 = e" and
          [ty]:"y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y9Def:"y9 = k"
          using A5 A1 arytm_2_th_2 sorry
        have " not y9 <='ARYTM-2R1 x9"
          using A5 A6 axioms_lm_1 sorry
        thus "e inHIDDENR3 K"
          using A5 A6 A7 arytm_2_th_18 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "k =HIDDENR1 {i where i be NatORDINAL1M6 :  not i <XXREAL-0R3 k }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
