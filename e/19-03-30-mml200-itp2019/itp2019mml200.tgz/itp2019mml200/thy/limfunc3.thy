theory limfunc3
  imports limfunc2 xcmplx_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, r1, r2, g, g1, g2, x0, t for "RealXREAL-0M1"
reserve n, k, m for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve seq for "Real-SequenceSEQ-1M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mlemma limfunc3_lm_1:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1 implies r -XCMPLX-0K6 g <XXREAL-0R3 r1 & r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
proof-
  have " for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g & r <=XXREAL-0R1 r1 implies r -XCMPLX-0K6 g <XXREAL-0R3 r1 &  not r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 g"
      and A2: "r <=XXREAL-0R1 r1"
    have "r -XCMPLX-0K6 g <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
      using A1 A2 xreal_1_th_15 sorry
    thus "r -XCMPLX-0K6 g <XXREAL-0R3 r1"
       sorry
    have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r1 +XCMPLX-0K2 g"
      using A1 A2 xreal_1_th_8 sorry
    thus " not r <XXREAL-0R3 r1 +XCMPLX-0K2 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc3_lm_2:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X implies ((((rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X implies rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ((rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2) & (rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X"
    thus A2: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_1 sorry
    show A3: "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_4 sorry
    then have A4: "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELAT-1K1 f2"
      using xboole_1_th_17 sorry
    have "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELAT-1K1 f1"
      using A3 xboole_1_th_17 sorry
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2"
      using A2 A4 sorry
    have A5: "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
      using A3 xboole_1_th_17 xboole_1_th_33 sorry
    have "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X"
      using A3 xboole_1_th_17 xboole_1_th_33 sorry
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
      using A1 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc3_lm_3:
" for r be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r & r <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for r be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r &  not r <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
      using xreal_1_th_139 sorry
    thus " not r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r &  not r <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
      using limfunc3_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma limfunc3_lm_4:
" for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X implies ((((rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X implies rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ((rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2) & (rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X"
    thus A2: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_1 sorry
    show A3: "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_1 sorry
    then have A4: "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELAT-1K1 f2"
      using xboole_1_th_17 sorry
    have "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELAT-1K1 f1"
      using A3 xboole_1_th_17 sorry
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2"
      using A2 A4 sorry
    have A5: "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
      using A3 xboole_1_th_17 xboole_1_th_33 sorry
    have "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 X c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X"
      using A3 xboole_1_th_17 xboole_1_th_33 sorry
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 X & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 X"
      using A1 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_1:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) or rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
proof-
  have " for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) or rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) or rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 seq implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 rngFUNCT-1K2 seq"
      then obtain n where
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A3: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
        using funct_2_th_113 sorry
      have "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      proof-
        show "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        proof-
          have cases: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) or rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
            using A1 sorry
          have case1: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0) implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          proof(rule impI)
            assume A4: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
            then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
              using A2 A3 xboole_0_def_4 sorry
            then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
              using xxreal_1_th_229 sorry
            then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & g1 <XXREAL-0R3 x0"
               sorry
            then have A5: " not x inHIDDENR3 {TARSKIK1 x0}"
              using A3 tarski_def_1 sorry
            have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f"
              using A2 A3 A4 xboole_0_def_4 sorry
            thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
              using A3 A5 xboole_0_def_5 sorry
          qed
          have case2: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0) implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          proof(rule impI)
            assume A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
            then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
              using A2 A3 xboole_0_def_4 sorry
            then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
              using xxreal_1_th_230 sorry
            then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & x0 <XXREAL-0R3 g1"
               sorry
            then have A7: " not x inHIDDENR3 {TARSKIK1 x0}"
              using A3 tarski_def_1 sorry
            have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f"
              using A2 A3 A6 xboole_0_def_4 sorry
            thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
              using A3 A7 xboole_0_def_5 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
         sorry
    qed "sorry"
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_2:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f) implies ((seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
proof-
  have " for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f) implies seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & (rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f"
    have A2: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 seq .FUNCT-1K1 k -XCMPLX-0K6 x0 .| <XXREAL-0R3 r)"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume A3: "0NUMBERSK6 <XXREAL-0R3 r"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A4: "r \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
        using seq_4_th_3 sorry
      show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 seq .FUNCT-1K1 k -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "n <=XXREAL-0R1 k"
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A5: "\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_12 sorry
        then have "r \<inverse>XCMPLX-0K5 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A4 xxreal_0_th_2 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 r \<inverse>XCMPLX-0K5"
          using A3 xreal_1_th_76 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 r \<inverse>XCMPLX-0K5"
          using A5 xxreal_0_th_2 sorry
        then have A6: "\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 r"
          using xcmplx_1_th_216 sorry
        have "k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have " |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-1K1 k .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        then have " |.COMPLEX1K10 -XCMPLX-0K4 (seq .FUNCT-1K1 k -XCMPLX-0K6 x0) .| <XXREAL-0R3 r"
          using A6 xxreal_0_th_2 sorry
        thus " |.COMPLEX1K10 seq .FUNCT-1K1 k -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
          using complex1_th_52 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be convergentSEQ-2V5"
      using seq_2_def_6 sorry
    thus "limSEQ-2K1 seq =COMPLEX1R1 x0"
      using A2 seq_2_def_7 sorry
    show A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 seq implies x inHIDDENR3 domRELAT-1K1 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 seq"
        then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        thus "x inHIDDENR3 domRELAT-1K1 f"
          using A1 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 seq implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A8: "x inHIDDENR3 rngFUNCT-1K2 seq"
      then obtain n where
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
        using funct_2_th_113 sorry
      have "0NUMBERSK6 <>HIDDENR2  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .|"
        using A1 sorry
      then have "(x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)+XCMPLX-0K2 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 +XCMPLX-0K2 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using absvalue_th_2 sorry
      then have " not x inHIDDENR3 {TARSKIK1 x0}"
        using A9 tarski_def_1 sorry
      thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 A8 xboole_0_def_5 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_3:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 k implies (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 r) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar2 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar2 <=XXREAL-0R1 k implies 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| & ( |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 r & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 seq =COMPLEX1R1 x0"
      and A3: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 r"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A4: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 seq .FUNCT-1K1 k -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
      using A1 A2 seq_2_def_7 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    show " ex tVar2 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar2 <=XXREAL-0R1 k implies 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| & ( |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 r & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f)"
    proof(rule bexI[of _ "n"],rule ballI,rule impI,rule conjMI,rule conjMI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      assume "n <=XXREAL-0R1 k"
      then have " |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
        using A4 sorry
      then have A5: " |.COMPLEX1K10 -XCMPLX-0K4 (x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) .| <XXREAL-0R3 r"
         sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 x0 <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 seq"
          using valued_0_th_28 sorry
        then have " not seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
          using A3 xboole_0_def_5 sorry
        thus "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 x0 <>HIDDENR2 0NUMBERSK6"
          using tarski_def_1 sorry
      qed "sorry"
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 x0 <>HIDDENR2 0NUMBERSK6"
         sorry
      then have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 -XCMPLX-0K4 (x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) .|"
        using complex1_th_47 sorry
      thus "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .|"
        using complex1_th_52 sorry
      show " |.COMPLEX1K10 x0 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 r"
        using A5 complex1_th_52 sorry
      have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 rngFUNCT-1K2 seq"
        using valued_0_th_28 sorry
      thus "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f"
        using A3 xboole_0_def_5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_4:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
proof-
  have " for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
    have "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
    proof(rule conjMI)
      show "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A2: "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          then obtain r1 where
            [ty]:"r1 be RealXREAL-0M1" and 
            A3: "r1 =HIDDENR1 x"
             sorry
          have "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using A2 xboole_0_def_5 sorry
          then have "x inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
            using rcomp_1_def_2 sorry
          then have A4: " ex g2 be RealXREAL-0M1 st (g2 =HIDDENR1 x & x0 -XCMPLX-0K6 r <XXREAL-0R3 g2) & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 r"
             sorry
          have " not x inHIDDENR3 {TARSKIK1 x0}"
            using A2 xboole_0_def_5 sorry
          then have A5: "r1 <>HIDDENR2 x0"
            using A3 tarski_def_1 sorry
          have "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          proof-
            show "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
            proof-
              have cases: "r1 <XXREAL-0R3 x0 or x0 <XXREAL-0R3 r1"
                using A5 xxreal_0_th_1 sorry
              have case1: "r1 <XXREAL-0R3 x0 implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
              proof(rule impI)
                assume "r1 <XXREAL-0R3 x0"
                then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 }"
                  using A3 A4 sorry
                then have "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .["
                  using A3 rcomp_1_def_2 sorry
                thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
                  using xboole_0_def_3 sorry
              qed
              have case2: "x0 <XXREAL-0R3 r1 implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
              proof(rule impI)
                assume "x0 <XXREAL-0R3 r1"
                then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
                  using A3 A4 sorry
                then have "x inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
                  using A3 rcomp_1_def_2 sorry
                thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
                  using xboole_0_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
             sorry
        qed "sorry"
        thus "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        have "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        proof-
          show "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          proof-
            have cases: "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ or x inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
              using A6 xboole_0_def_3 sorry
            have case1: "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
            proof(rule impI)
              assume "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .["
              then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 }"
                using rcomp_1_def_2 sorry
              then obtain g1 where
                [ty]:"g1 be RealXREAL-0M1" and 
                A7: "g1 =HIDDENR1 x"and A8: "x0 -XCMPLX-0K6 r <XXREAL-0R3 g1"and A9: "g1 <XXREAL-0R3 x0"
                 sorry
              have "g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r"
                using A1 A9 limfunc3_lm_1 sorry
              then have "x inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
                using A7 A8 sorry
              then have A10: "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_2 sorry
              have " not x inHIDDENR3 {TARSKIK1 x0}"
                using A7 A9 tarski_def_1 sorry
              thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
                using A10 xboole_0_def_5 sorry
            qed
            have case2: "x inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
            proof(rule impI)
              assume "x inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
              then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
                using rcomp_1_def_2 sorry
              then obtain g1 where
                [ty]:"g1 be RealXREAL-0M1" and 
                A11: "g1 =HIDDENR1 x"and A12: "x0 <XXREAL-0R3 g1"and A13: "g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r"
                 sorry
              have "x0 -XCMPLX-0K6 r <XXREAL-0R3 g1"
                using A1 A12 limfunc3_lm_1 sorry
              then have "x inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
                using A11 A13 sorry
              then have A14: "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_2 sorry
              have " not x inHIDDENR3 {TARSKIK1 x0}"
                using A11 A12 tarski_def_1 sorry
              thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
                using A14 xboole_0_def_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
           sorry
      qed "sorry"
      thus "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
        using tarski_def_3 sorry
    qed
    thus "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0} =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_5:
" for r2 be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds 0NUMBERSK6 <XXREAL-0R3 r2 & ].RCOMP-1K2 x0 -XCMPLX-0K6 r2,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r2 .[ c=TARSKIR1 domRELAT-1K1 f implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))"
proof-
  have " for r2 be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds 0NUMBERSK6 <XXREAL-0R3 r2 & ].RCOMP-1K2 x0 -XCMPLX-0K6 r2,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r2 .[ c=TARSKIR1 domRELAT-1K1 f implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar3 be RealXREAL-0M1 st  ex tVar4 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar3 &  not tVar3 <XXREAL-0R3 x0) & tVar3 inHIDDENR3 domRELAT-1K1 f) &  not tVar4 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar4) & tVar4 inHIDDENR3 domRELAT-1K1 f))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r2"
      and A2: "].RCOMP-1K2 x0 -XCMPLX-0K6 r2,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r2 .[ c=TARSKIR1 domRELAT-1K1 f"
    have A3: "].RCOMP-1K2 x0 -XCMPLX-0K6 r2,x0 .[ c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r2,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r2 .["
      using xboole_1_th_7 sorry
    have A4: "].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r2 .[ c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r2,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r2 .["
      using xboole_1_th_7 sorry
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    assume A5: "r1 <XXREAL-0R3 x0"
      and A6: "x0 <XXREAL-0R3 r2"
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A7: "r1 <XXREAL-0R3 g1"and A8: "g1 <XXREAL-0R3 x0"and A9: "g1 inHIDDENR3 domRELAT-1K1 f"
      using A1 A2 A3 A5 limfunc2_th_3 xboole_1_th_1 sorry
    obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A10: "g2 <XXREAL-0R3 r2"and A11: "x0 <XXREAL-0R3 g2"and A12: "g2 inHIDDENR3 domRELAT-1K1 f"
      using A1 A2 A4 A6 limfunc2_th_4 xboole_1_th_1 sorry
    show " ex tVar3 be RealXREAL-0M1 st  ex tVar4 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar3 &  not tVar3 <XXREAL-0R3 x0) & tVar3 inHIDDENR3 domRELAT-1K1 f) &  not tVar4 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar4) & tVar4 inHIDDENR3 domRELAT-1K1 f"
    proof(rule bexI[of _ "g1"])
      show " ex tVar4 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) &  not tVar4 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar4) & tVar4 inHIDDENR3 domRELAT-1K1 f"
      proof(rule bexI[of _ "g2"])
        show "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
          using A7 A8 A9 A10 A11 A12 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_6:
" for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f) implies (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
proof-
  have " for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f) implies (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f"
    have A2: " for n be NatNAT-1M1 holds (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-1K1 n & seq .FUNCT-1K1 n <XXREAL-0R3 x0) & seq .FUNCT-1K1 n inTARSKIR2 domRELAT-1K1 f"
    proof-
      have " for n be NatNAT-1M1 holds ( not x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-1K1 n &  not seq .FUNCT-1K1 n <XXREAL-0R3 x0) & seq .FUNCT-1K1 n inTARSKIR2 domRELAT-1K1 f"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus "( not x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-1K1 n &  not seq .FUNCT-1K1 n <XXREAL-0R3 x0) & seq .FUNCT-1K1 n inTARSKIR2 domRELAT-1K1 f"
          using A1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0"
      using limfunc2_th_5 sorry
    have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      using limfunc2_th_5 A2 sorry
    thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      using limfunc3_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_7:
" for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & 0NUMBERSK6 <XXREAL-0R3 g implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g)"
proof-
  have " for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & 0NUMBERSK6 <XXREAL-0R3 g) implies ( ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar5 <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n &  not seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 seq =COMPLEX1R1 x0"
      and A3: "0NUMBERSK6 <XXREAL-0R3 g"
    have "x0 -XCMPLX-0K6 g <XXREAL-0R3 limSEQ-2K1 seq"
      using A2 A3 limfunc3_lm_1 sorry
    then obtain k1 where
      [ty]:"k1 be NatNAT-1M1" and 
      A4: " for n be NatNAT-1M1 holds k1 <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 seq .FUNCT-1K1 n"
      using A1 limfunc2_th_1 sorry
    have "limSEQ-2K1 seq <XXREAL-0R3 x0 +XCMPLX-0K2 g"
      using A2 A3 limfunc3_lm_1 sorry
    then obtain k2 where
      [ty]:"k2 be NatNAT-1M1" and 
      A5: " for n be NatNAT-1M1 holds k2 <=XXREAL-0R1 n implies seq .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
      using A1 limfunc2_th_2 sorry
    obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = maxXXREAL-0K5(k1,k2)"
      using ordinal1_def_12 sorry
    show " ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar5 <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 g <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n &  not seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
    proof(rule bexI[of _ "k"],rule ballI,rule impI,rule conjMI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      assume A6: "k <=XXREAL-0R1 n"
      have "k1 <=XXREAL-0R1 k"
        using xxreal_0_th_25 sorry
      then have "k1 <=XXREAL-0R1 n"
        using A6 xxreal_0_th_2 sorry
      thus "x0 -XCMPLX-0K6 g <XXREAL-0R3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A4 sorry
      have "k2 <=XXREAL-0R1 k"
        using xxreal_0_th_25 sorry
      then have "k2 <=XXREAL-0R1 n"
        using A6 xxreal_0_th_2 sorry
      thus " not seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 g"
        using A5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_8:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) iff ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f))) & (( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)) implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar8 &  not tVar8 <XXREAL-0R3 x0) & tVar8 inHIDDENR3 domRELAT-1K1 f) &  not tVar9 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar9) & tVar9 inHIDDENR3 domRELAT-1K1 f)))"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f))"
    proof-
      have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies ( for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)) & ( for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex tVar7 be RealXREAL-0M1 st ( not tVar7 <XXREAL-0R3 r &  not x0 <XXREAL-0R3 tVar7) & tVar7 inHIDDENR3 domRELAT-1K1 f))"
      proof(rule impI,rule conjMI,rule ballI,rule impI)
        assume A1: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
        show " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
        proof-
          have " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex tVar6 be RealXREAL-0M1 st ( not r <XXREAL-0R3 tVar6 &  not tVar6 <XXREAL-0R3 x0) & tVar6 inHIDDENR3 domRELAT-1K1 f)"
          proof(rule ballI,rule impI)
            have A2: "x0 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"
              using limfunc3_lm_1 sorry
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume "r <XXREAL-0R3 x0"
            then obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A3: "r <XXREAL-0R3 g1"and A4: "g1 <XXREAL-0R3 x0"and A5: "g1 inHIDDENR3 domRELAT-1K1 f"and "g2 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"and "x0 <XXREAL-0R3 g2"and "g2 inHIDDENR3 domRELAT-1K1 f"
              using A1 A2 sorry
            show " ex tVar6 be RealXREAL-0M1 st ( not r <XXREAL-0R3 tVar6 &  not tVar6 <XXREAL-0R3 x0) & tVar6 inHIDDENR3 domRELAT-1K1 f"
            proof(rule bexI[of _ "g1"])
              show "( not r <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f"
                using A3 A4 A5 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A6: "x0 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 x0"
          using limfunc3_lm_1 sorry
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "x0 <XXREAL-0R3 r"
        then obtain g1 g2 where
          [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
          "x0 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1"and "g1 <XXREAL-0R3 x0"and "g1 inHIDDENR3 domRELAT-1K1 f"and A7: "g2 <XXREAL-0R3 r"and A8: "x0 <XXREAL-0R3 g2"and A9: "g2 inHIDDENR3 domRELAT-1K1 f"
          using A1 A6 sorry
        show " ex tVar7 be RealXREAL-0M1 st ( not tVar7 <XXREAL-0R3 r &  not x0 <XXREAL-0R3 tVar7) & tVar7 inHIDDENR3 domRELAT-1K1 f"
        proof(rule bexI[of _ "g2"])
          show "( not g2 <XXREAL-0R3 r &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
            using A7 A8 A9 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A10: " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
      and A11: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    assume A12: "r1 <XXREAL-0R3 x0"
      and A13: "x0 <XXREAL-0R3 r2"
    obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A14: "g2 <XXREAL-0R3 r2"and A15: "x0 <XXREAL-0R3 g2"and A16: "g2 inHIDDENR3 domRELAT-1K1 f"
      using A11 A13 sorry
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A17: "r1 <XXREAL-0R3 g1"and A18: "g1 <XXREAL-0R3 x0"and A19: "g1 inHIDDENR3 domRELAT-1K1 f"
      using A10 A12 sorry
    show " ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar8 &  not tVar8 <XXREAL-0R3 x0) & tVar8 inHIDDENR3 domRELAT-1K1 f) &  not tVar9 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar9) & tVar9 inHIDDENR3 domRELAT-1K1 f"
    proof(rule bexI[of _ "g1"])
      show " ex tVar9 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) &  not tVar9 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar9) & tVar9 inHIDDENR3 domRELAT-1K1 f"
      proof(rule bexI[of _ "g2"])
        show "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
          using A17 A18 A19 A14 A15 A16 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef limfunc3_def_1 (" _ is-convergent-inLIMFUNC3R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-convergent-inLIMFUNC3R1 x0 means
  ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( ex g be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g)"..

mdef limfunc3_def_2 (" _ is-divergent-to+infty-inLIMFUNC3R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-divergent-to+infty-inLIMFUNC3R2 x0 means
  ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"..

mdef limfunc3_def_3 (" _ is-divergent-to-infty-inLIMFUNC3R3  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-divergent-to-infty-inLIMFUNC3R3 x0 means
  ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)"..

mtheorem limfunc3_th_9:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies (( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))) implies f is-convergent-inLIMFUNC3R1 x0))"
  proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-convergent-inLIMFUNC3R1 x0 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
    proof-
      have "f is-convergent-inLIMFUNC3R1 x0 & ( not ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) or ( for g be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)))) implies  False "
      proof(rule impMI ,rule impI)
        assume A1: "f is-convergent-inLIMFUNC3R1 x0"
          and A2: " not ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) or ( for g be RealXREAL-0M1 holds  ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)))"
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A3: " for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g"
          using A1 sorry
        obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A4: "0NUMBERSK6 <XXREAL-0R3 g1"and A5: " for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1)"
          using A1 A2 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) & Lamb2 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
        have A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r1)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar10 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar10 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar10 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar10 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 tVar10 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r1 where
              [ty]:"r1 be RealXREAL-0M1" and 
              A7: "?X(n,r1)"
              using A5 xreal_1_th_139 sorry
            have 
              [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex tVar10 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar10 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar10 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar10 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 tVar10 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
            proof(rule bexI[of _ "r1"])
              show "((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & r1 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
                using A7 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A6 sorry
        have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A8 limfunc3_th_2 sorry
        have A10: "limSEQ-2K1 s =COMPLEX1R1 x0"
          using A8 limfunc3_th_2 sorry
        have A11: "s be convergentSEQ-2V5"
          using A8 limfunc3_th_2 sorry
        then have A12: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
          using A3 A10 A9 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
          using A3 A11 A10 A9 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A13: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A4 A12 seq_2_def_7 sorry
        have A14: " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A13 sorry
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
          using A8 limfunc3_th_2 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 n) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A14 funct_2_th_108 A15 sorry
        thus " False "
          using A8 A15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A16: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    assume Given: " ex g be RealXREAL-0M1 st  for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A17: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A18: "s be convergentSEQ-2V5"
        and A19: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A20: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      have A21: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
      proof(rule ballI,rule impI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        assume A22: "0NUMBERSK6 <XXREAL-0R3 g1"
        obtain g2 where
          [ty]:"g2 be RealXREAL-0M1" and 
          A23: "0NUMBERSK6 <XXREAL-0R3 g2"and A24: " for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A17 A22 sorry
        obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A25: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 k implies (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 g2) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f"
          using A18 A19 A20 A23 limfunc3_th_3 sorry
        have 
          [ty]:"n be NatNAT-1M1"
           sorry
        show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A26: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume A27: "n <=XXREAL-0R1 k"
          then have A28: " |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .| <XXREAL-0R3 g2"
            using A25 A26 sorry
          have A29: "s .FUNCT-1K1 k inTARSKIR2 domRELAT-1K1 f"
            using A25 A27 A26 sorry
          have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .|"
            using A25 A27 A26 sorry
          then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 k) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A24 A28 A29 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A20 funct_2_th_108 xboole_1_th_1 A26 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using seq_2_def_6 sorry
      thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
        using A21 seq_2_def_7 sorry
    qed "sorry"
    thus "f is-convergent-inLIMFUNC3R1 x0"
      using A16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_10:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-divergent-to+infty-inLIMFUNC3R2 x0 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1))) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-divergent-to+infty-inLIMFUNC3R2 x0 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1))"
    proof-
      have "f is-divergent-to+infty-inLIMFUNC3R2 x0 & ( not ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) or ( ex g1 be RealXREAL-0M1 st  for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 r1 <=XXREAL-0R1 g1))) implies  False "
      proof(rule impMI ,rule impI)
        assume A1: "f is-divergent-to+infty-inLIMFUNC3R2 x0"
          and A2: " not ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) or ( ex g1 be RealXREAL-0M1 st  for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 r1 <=XXREAL-0R1 g1))"
        obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A3: " for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 r1 <=XXREAL-0R1 g1)"
          using A1 A2 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) & Lamb2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 Lamb2 <=XXREAL-0R1 g1"
        have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r1)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar12 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar12 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar12 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 tVar12 <=XXREAL-0R1 g1"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r1 where
              [ty]:"r1 be RealXREAL-0M1" and 
              A5: "?X(n,r1)"
              using A3 xreal_1_th_139 sorry
            have 
              [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar12 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar12 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar12 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 tVar12 <=XXREAL-0R1 g1"
            proof(rule bexI[of _ "r1"])
              show "((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & r1 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 r1 <=XXREAL-0R1 g1"
                using A5 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A4 sorry
        have A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A6 limfunc3_th_2 sorry
        have A8: "limSEQ-2K1 s =COMPLEX1R1 x0"
          using A6 limfunc3_th_2 sorry
        have "s be convergentSEQ-2V5"
          using A6 limfunc3_th_2 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
          using A1 A8 A7 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A9: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies g1 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
           sorry
        have A10: "g1 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n"
          using A9 sorry
        have A11: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
          using A6 limfunc3_th_2 sorry
        then have "g1 <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 n)"
          using A10 funct_2_th_108 A11 sorry
        thus " False "
          using A6 A11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A12: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
      and A13: " for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A14: "s be convergentSEQ-2V5"
        and A15: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      have " for g1 be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies g1 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
      proof(rule ballI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        obtain g2 where
          [ty]:"g2 be RealXREAL-0M1" and 
          A17: "0NUMBERSK6 <XXREAL-0R3 g2"and A18: " for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies g1 <XXREAL-0R3 f .FUNCT-1K1 r1"
          using A13 sorry
        obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A19: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 k implies (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 g2) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f"
          using A14 A15 A16 A17 limfunc3_th_3 sorry
        have 
          [ty]:"n be NatNAT-1M1"
           sorry
        show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies g1 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A20: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume A21: "n <=XXREAL-0R1 k"
          then have A22: " |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .| <XXREAL-0R3 g2"
            using A19 A20 sorry
          have A23: "s .FUNCT-1K1 k inTARSKIR2 domRELAT-1K1 f"
            using A19 A21 A20 sorry
          have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .|"
            using A19 A21 A20 sorry
          then have "g1 <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 k)"
            using A18 A22 A23 sorry
          thus "g1 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
            using A16 funct_2_th_108 xboole_1_th_1 A20 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
         sorry
    qed "sorry"
    thus "f is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_11:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to-infty-inLIMFUNC3R3 x0 iff ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-divergent-to-infty-inLIMFUNC3R3 x0 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1))) & (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-divergent-to-infty-inLIMFUNC3R3 x0 implies ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1))"
    proof-
      have "f is-divergent-to-infty-inLIMFUNC3R3 x0 & ( not ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) or ( ex g1 be RealXREAL-0M1 st  for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1 f .FUNCT-1K1 r1))) implies  False "
      proof(rule impMI ,rule impI)
        assume A1: "f is-divergent-to-infty-inLIMFUNC3R3 x0"
          and A2: " not ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) or ( ex g1 be RealXREAL-0M1 st  for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1 f .FUNCT-1K1 r1))"
        obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A3: " for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1 f .FUNCT-1K1 r1)"
          using A1 A2 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) & Lamb2 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1 f .FUNCT-1K1 Lamb2"
        have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r1)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar14 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar14 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar14 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar14 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1 f .FUNCT-1K1 tVar14"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r1 where
              [ty]:"r1 be RealXREAL-0M1" and 
              A5: "?X(n,r1)"
              using A3 xreal_1_th_139 sorry
            have 
              [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex tVar14 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar14 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar14 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar14 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1 f .FUNCT-1K1 tVar14"
            proof(rule bexI[of _ "r1"])
              show "((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & r1 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1 f .FUNCT-1K1 r1"
                using A5 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A4 sorry
        have A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A6 limfunc3_th_2 sorry
        have A8: "limSEQ-2K1 s =COMPLEX1R1 x0"
          using A6 limfunc3_th_2 sorry
        have "s be convergentSEQ-2V5"
          using A6 limfunc3_th_2 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
          using A1 A8 A7 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A9: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 g1"
           sorry
        have A10: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n <XXREAL-0R3 g1"
          using A9 sorry
        have A11: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
          using A6 limfunc3_th_2 sorry
        then have "f .FUNCT-1K1 (s .FUNCT-1K1 n) <XXREAL-0R3 g1"
          using A10 funct_2_th_108 A11 sorry
        thus " False "
          using A6 A11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A12: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
      and A13: " for g1 be RealXREAL-0M1 holds  ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1)"
    have " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A14: "s be convergentSEQ-2V5"
        and A15: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      have " for g1 be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 g1"
      proof(rule ballI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        obtain g2 where
          [ty]:"g2 be RealXREAL-0M1" and 
          A17: "0NUMBERSK6 <XXREAL-0R3 g2"and A18: " for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 r1 <XXREAL-0R3 g1"
          using A13 sorry
        obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A19: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 k implies (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 g2) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f"
          using A14 A15 A16 A17 limfunc3_th_3 sorry
        have 
          [ty]:"n be NatNAT-1M1"
           sorry
        show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 g1"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A20: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume A21: "n <=XXREAL-0R1 k"
          then have A22: " |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .| <XXREAL-0R3 g2"
            using A19 A20 sorry
          have A23: "s .FUNCT-1K1 k inTARSKIR2 domRELAT-1K1 f"
            using A19 A21 A20 sorry
          have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .|"
            using A19 A21 A20 sorry
          then have "f .FUNCT-1K1 (s .FUNCT-1K1 k) <XXREAL-0R3 g1"
            using A18 A22 A23 sorry
          thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 g1"
            using A16 funct_2_th_108 xboole_1_th_1 A20 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
         sorry
    qed "sorry"
    thus "f is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_12:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 iff f is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-divergent-to+infty-inLIMFUNC3R2 x0 implies f is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f is-right-divergent-to+infty-inLIMFUNC2R5 x0) & (f is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f is-right-divergent-to+infty-inLIMFUNC2R5 x0 implies f is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-divergent-to+infty-inLIMFUNC3R2 x0 implies f is-left-divergent-to+infty-inLIMFUNC2R2 x0 & f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
    proof(rule impI,rule conjMI)
      assume A1: "f is-divergent-to+infty-inLIMFUNC3R2 x0"
      have A2: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
        assume A3: "s be convergentSEQ-2V5"
          and A4: "limSEQ-2K1 s =COMPLEX1R1 x0"
          and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A5 limfunc3_th_1 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
          using A1 A3 A4 sorry
      qed "sorry"
      have A6: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
        assume A7: "s be convergentSEQ-2V5"
          and A8: "limSEQ-2K1 s =COMPLEX1R1 x0"
          and A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A9 limfunc3_th_1 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
          using A1 A7 A8 sorry
      qed "sorry"
      have A10: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
        using A1 sorry
      then have " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
        using limfunc3_th_8 sorry
      thus "f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
        using A2 limfunc2_def_2 sorry
      have " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)"
        using A10 limfunc3_th_8 sorry
      thus "f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
        using A6 limfunc2_def_5 sorry
    qed
    assume A11: "f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      and A12: "f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
    have A13: " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)"
      using A12 limfunc2_def_5 sorry
    have A14: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A15: "s be convergentSEQ-2V5"
        and A16: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A17: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
      proof-
        show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        proof-
          have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0)"
             sorry
          have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
          proof(rule impI)
            assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
            then obtain k where
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A18: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
               sorry
            have A19: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
              using A17 xboole_1_th_1 sorry
            have A20: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                then obtain n where
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A21: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                  using funct_2_th_113 sorry
                have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0"
                  using A18 nat_1_th_12 sorry
                then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
                   sorry
                then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
                  using xxreal_1_th_229 sorry
                then have A22: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 x0"
                  using A21 nat_1_def_3 sorry
                have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
                  using valued_0_th_28 sorry
                then have "x inHIDDENR3 rngFUNCT-1K2 s"
                  using A21 nat_1_def_3 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                  using A19 A22 xboole_0_def_4 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                using tarski_def_3 sorry
            qed
            have A23: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A17 valued_0_th_27 xboole_1_th_1 sorry
            have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
              using A15 A16 seq_4_th_20 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
              using A11 A15 A20 limfunc2_def_2 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
              using A23 limfunc1_th_7 sorry
          qed
          have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
          proof(rule impI)
            assume A24: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0"
            have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
            proof-
              show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
              proof-
                have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                   sorry
                have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
                proof(rule impI)
                  assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  then obtain k where
                    [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A25: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                     sorry
                  have A26: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
                    using A17 xboole_1_th_1 sorry
                  have A27: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A28: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
                        using A25 nat_1_th_12 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
                         sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
                        using xxreal_1_th_230 sorry
                      then have A29: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 x0"
                        using A28 nat_1_def_3 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have "x inHIDDENR3 rngFUNCT-1K2 s"
                        using A28 nat_1_def_3 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                        using A26 A29 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                      using tarski_def_3 sorry
                  qed
                  have A30: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
                    using A17 valued_0_th_27 xboole_1_th_1 sorry
                  have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
                    using A15 A16 seq_4_th_20 sorry
                  then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
                    using A12 A15 A27 limfunc2_def_5 sorry
                  thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
                    using A30 limfunc1_th_7 sorry
                qed
                have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
                proof(rule impI)
                  assume A31: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                  have A32: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                  proof(rule ballI)
                    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain n where
                      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A33: "k <=XXREAL-0R1 n"and A34: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 x0"
                      using A31 sorry
                    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                    proof(rule bexI[of _ "n"],rule conjMI)
                      show "k <=XXREAL-0R1 n"
                        using A33 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                        using A17 xboole_0_def_5 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      thus "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                        using A34 xxreal_0_th_1 sorry
                    qed "sorry"
                  qed "sorry"
                  then have " ex m1 be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 m1 & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m1 <XXREAL-0R3 x0"
                     sorry
                  then have A35: " ex m be NatNAT-1M1 st ?X(m)"
                     sorry
                  obtain M where
                    [ty]:"M be NatNAT-1M1" and 
                    A36: "?X(M) & ( for n be NatNAT-1M1 holds ?X(n) implies M <=XXREAL-0R1 n)"
                    using nat_1_sch_5 A35 sorry
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb1 =XBOOLE-0R4 n & Lamb2 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k)"
                  let ?X3 = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. ?P(Lamb2,Lamb3)"
                  obtain M9 where 
                    [ty]:"M9 be ElementSUBSET-1M1-of NATNUMBERSK1" and M9Def:"M9 = M"
                    using ordinal1_def_12 sorry
                  have A37: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain m where
                      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A38: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"and A39: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                      using A32 sorry
                    show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                    proof(rule bexI[of _ "m"])
                      show "n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                        using A38 A39 nat_1_th_13 sorry
                    qed "sorry"
                  qed "sorry"
                  have A40: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X3(n,x,y)"
                  proof-
                    have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar18 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar18 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar18 =XBOOLE-0R4 nc & tVar18 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                    proof(rule ballI,rule ballI)
                      fix n assume [ty]: "n be NatNAT-1M1"
                      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                      let ?X = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                      have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(m)"
                        using A37 sorry
                      then have A41: " ex m be NatNAT-1M1 st ?X(m)"
                         sorry
                      obtain l where
                        [ty]:"l be NatNAT-1M1" and 
                        A42: "?X(l) & ( for k be NatNAT-1M1 holds ?X(k) implies l <=XXREAL-0R1 k)"
                        using nat_1_sch_5 A41 sorry
                      show " ex tVar18 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar18 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar18 =XBOOLE-0R4 nc & tVar18 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                      proof(rule bexI[of _ "l"])
                        have "l inTARSKIR2 NATNUMBERSK1"
                          using ordinal1_def_12 sorry
                        thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds l =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                          using A42 sorry
                      qed "sorry"
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  obtain F where
                    [ty]:"F be sequenceNAT-1M2-of NATNUMBERSK1" and 
                    A43: "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M9 & ( for n be NatNAT-1M1 holds ?X3(n,F .RECDEF-1K1 n,F .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                    using recdef_1_sch_2 A40 sorry
                  have A44: "rngFUNCT-1K2 F c=TARSKIR1 NATNUMBERSK1"
                    using relat_1_def_19 sorry
                  then have A45: "rngFUNCT-1K2 F c=TARSKIR1 REALNUMBERSK2"
                    using numbers_th_19 sorry
                  have A46: "domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1"
                    using funct_2_def_1 sorry
                  then have 
                    [ty]:"F be Real-SequenceSEQ-1M1"
                    using A45 relset_1_th_4 sorry
                  have A47: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    have "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 F"
                      using A46 funct_1_def_3 sorry
                    thus "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A44 sorry
                  qed "sorry"
                  have " for n be NatNAT-1M1 holds F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI)
                    fix n assume [ty]: "n be NatNAT-1M1"
                    have A48: "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A47 sorry
                    have A49: "n inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have "F .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A47 A49 sorry
                    thus "F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                      using A43 A48 sorry
                  qed "sorry"
                  then have 
                    [ty]:"F be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
                    using seqm_3_def_6 sorry
                  have A50: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s"
                    using valued_0_def_17 sorry
                  then have "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 rngFUNCT-1K2 s"
                    using valued_0_th_21 sorry
                  then have A51: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
                    using A17 sorry
                  have A52: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 n)"
                  proof-
                    have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-1K1 n <XXREAL-0R3 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
                    proof(rule impI)
                      let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                      assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
                      then have A53: " ex n be NatNAT-1M1 st ?X(n)"
                         sorry
                      obtain M1 where
                        [ty]:"M1 be NatNAT-1M1" and 
                        A54: "?X(M1) & ( for n be NatNAT-1M1 holds ?X(n) implies M1 <=XXREAL-0R1 n)"
                        using nat_1_sch_5 A53 sorry
                      let ?X = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 M1 & s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                      have A55: " ex n be NatNAT-1M1 st ?X(n)"
                      proof-
                        have " ex tVar19 be NatNAT-1M1 st tVar19 <XXREAL-0R3 M1 & (s .FUNCT-1K1 tVar19 <XXREAL-0R3 x0 & ( ex tVar20 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar20 =COMPLEX1R1 tVar19))"
                        proof-
                          show " ex tVar19 be NatNAT-1M1 st tVar19 <XXREAL-0R3 M1 & (s .FUNCT-1K1 tVar19 <XXREAL-0R3 x0 & ( ex tVar20 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar20 =COMPLEX1R1 tVar19))"
                          proof(rule bexI[of _ "M"],rule conjMI,rule conjMI)
                            have A56: "M <>HIDDENR2 M1"
                              using A43 A54 sorry
                            have "M <=XXREAL-0R1 M1"
                              using A36 A54 sorry
                            thus "M <XXREAL-0R3 M1"
                              using A56 xxreal_0_th_1 sorry
                            show "s .FUNCT-1K1 M <XXREAL-0R3 x0"
                              using A36 sorry
                            show " ex tVar20 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar20 =COMPLEX1R1 M"
                            proof(rule bexI[of _ "0NUMBERSK6"])
                              show "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M"
                                using A43 sorry
                            qed "sorry"
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have A57: " for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 M1"
                         sorry
                      obtain MX where
                        [ty]:"MX be NatNAT-1M1" and 
                        A58: "?X(MX) & ( for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 MX)"
                        using nat_1_sch_6 A57 A55 sorry
                      have A59: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds MX <XXREAL-0R3 k & k <XXREAL-0R3 M1 implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 x0"
                      proof-
                        have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (MX <XXREAL-0R3 k & k <XXREAL-0R3 M1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0) implies  False "
                        proof(rule impI)
                          assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (MX <XXREAL-0R3 k & k <XXREAL-0R3 M1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0"
                          then obtain k where
                            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                            A60: "MX <XXREAL-0R3 k"and A61: "k <XXREAL-0R3 M1"and A62: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0"
                             sorry
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k)"
                                 sorry
                              have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                              proof(rule impI)
                                assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k"
                                thus " False "
                                  using A58 A60 A61 A62 sorry
                              qed
                              have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                              proof(rule impI)
                                assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k"
                                thus " False "
                                  using A54 A61 A62 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      obtain m where
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A63: "F .RECDEF-1K1 m =COMPLEX1R1 MX"
                        using A58 sorry
                      have "M1 inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      then have A64: "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 M1"
                        using A43 A54 A58 A63 sorry
                      have A65: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 x0"
                        using A43 A63 sorry
                      have A66: "MX <XXREAL-0R3 F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                        using A43 A63 sorry
                      have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1 implies  False "
                      proof(rule impI)
                        assume "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1"
                        then have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 M1"
                          using A64 xxreal_0_th_1 sorry
                        thus " False "
                          using A59 A66 A65 sorry
                      qed
                      thus " False "
                        using A54 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  have A67: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                  proof(rule ballI)
                    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain n where
                      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A68: "k <=XXREAL-0R1 n"and A69: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0"
                      using A24 sorry
                    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                    proof(rule bexI[of _ "n"],rule conjMI)
                      show "k <=XXREAL-0R1 n"
                        using A68 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                        using A17 xboole_0_def_5 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      thus "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                        using A69 xxreal_0_th_1 sorry
                    qed "sorry"
                  qed "sorry"
                  then have " ex mn be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 mn & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> mn >XXREAL-0R4 x0"
                     sorry
                  then have A70: " ex m be NatNAT-1M1 st ?X(m)"
                     sorry
                  obtain N where
                    [ty]:"N be NatNAT-1M1" and 
                    A71: "?X(N) & ( for n be NatNAT-1M1 holds ?X(n) implies N <=XXREAL-0R1 n)"
                    using nat_1_sch_5 A70 sorry
                  let ?X = "\<lambda>Lamb1. (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                  have A72: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
                  proof-
                    have " for k be NatNAT-1M1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <XXREAL-0R3 x0 implies (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
                    proof(rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      assume "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <XXREAL-0R3 x0"
                      have "?P(F .RECDEF-1K1 k,F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                        using A43 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 x0"
                         sorry
                      thus "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
                        using funct_2_th_15 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have A73: "?X(0NUMBERSK6)"
                    using A36 A43 funct_2_th_15 sorry
                  have A74: " for k be NatNAT-1M1 holds ?X(k)"
                    using nat_1_sch_2 A73 A72 sorry
                  have A75: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A76: "x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A77: "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                        using A74 sorry
                      then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
                        using A77 sorry
                      then have A78: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 x0"
                        using xxreal_1_th_229 sorry
                      have "x inHIDDENR3 domRELAT-1K1 f"
                        using A51 A76 xboole_0_def_5 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                        using A78 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                      using tarski_def_3 sorry
                  qed
                  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb1 =XBOOLE-0R4 n & Lamb2 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k)"
                  let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. ?P(Lamb2,Lamb3)"
                  have A79: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F be convergentSEQ-2V5"
                    using A15 A50 seq_4_th_16 sorry
                  obtain N9 where 
                    [ty]:"N9 be ElementSUBSET-1M1-of NATNUMBERSK1" and N9Def:"N9 = N"
                    using ordinal1_def_12 sorry
                  have A80: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain m where
                      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A81: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"and A82: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                      using A67 sorry
                    show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                    proof(rule bexI[of _ "m"])
                      show "n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                        using A81 A82 nat_1_th_13 sorry
                    qed "sorry"
                  qed "sorry"
                  have A83: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n,x,y)"
                  proof-
                    have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar23 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar23 =XBOOLE-0R4 nc & tVar23 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k)"
                    proof(rule ballI,rule ballI)
                      fix n assume [ty]: "n be NatNAT-1M1"
                      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                      let ?X = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                      have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(m)"
                        using A80 sorry
                      then have A84: " ex m be NatNAT-1M1 st ?X(m)"
                         sorry
                      obtain l where
                        [ty]:"l be NatNAT-1M1" and 
                        A85: "?X(l) & ( for k be NatNAT-1M1 holds ?X(k) implies l <=XXREAL-0R1 k)"
                        using nat_1_sch_5 A84 sorry
                      have 
                        [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      show " ex tVar23 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar23 =XBOOLE-0R4 nc & tVar23 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k)"
                      proof(rule bexI[of _ "l"])
                        show " for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds l =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k)"
                          using A85 sorry
                      qed "sorry"
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  obtain G where
                    [ty]:"G be sequenceNAT-1M2-of NATNUMBERSK1" and 
                    A86: "G .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 N9 & ( for n be NatNAT-1M1 holds ?X(n,G .RECDEF-1K1 n,G .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                    using recdef_1_sch_2 A83 sorry
                  have A87: "rngFUNCT-1K2 G c=TARSKIR1 NATNUMBERSK1"
                    using relat_1_def_19 sorry
                  then have A88: "rngFUNCT-1K2 G c=TARSKIR1 REALNUMBERSK2"
                    using numbers_th_19 sorry
                  have A89: "domRELAT-1K1 G =XBOOLE-0R4 NATNUMBERSK1"
                    using funct_2_def_1 sorry
                  then have 
                    [ty]:"G be Real-SequenceSEQ-1M1"
                    using A88 relset_1_th_4 sorry
                  have A90: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    have "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 G"
                      using A89 funct_1_def_3 sorry
                    thus "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A87 sorry
                  qed "sorry"
                  have " for n be NatNAT-1M1 holds G .FUNCT-1K1 n <XXREAL-0R3 G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI)
                    fix n assume [ty]: "n be NatNAT-1M1"
                    have A91: "n inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have A92: "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A90 sorry
                    have "G .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A90 A91 sorry
                    thus "G .FUNCT-1K1 n <XXREAL-0R3 G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                      using A86 A92 sorry
                  qed "sorry"
                  then have 
                    [ty]:"G be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
                    using seqm_3_def_6 sorry
                  have A93: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s"
                    using valued_0_def_17 sorry
                  then have "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 rngFUNCT-1K2 s"
                    using valued_0_th_21 sorry
                  then have A94: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
                    using A17 sorry
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                  have A95: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0 implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 n)"
                  proof-
                    have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-1K1 n >XXREAL-0R4 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
                    proof(rule impI)
                      assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
                      then have A96: " ex n be NatNAT-1M1 st ?X(n)"
                         sorry
                      obtain N1 where
                        [ty]:"N1 be NatNAT-1M1" and 
                        A97: "?X(N1) & ( for n be NatNAT-1M1 holds ?X(n) implies N1 <=XXREAL-0R1 n)"
                        using nat_1_sch_5 A96 sorry
                      let ?X = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 N1 & s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                      have A98: " ex n be NatNAT-1M1 st ?X(n)"
                      proof-
                        have " ex tVar24 be NatNAT-1M1 st tVar24 <XXREAL-0R3 N1 & (s .FUNCT-1K1 tVar24 >XXREAL-0R4 x0 & ( ex tVar25 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar25 =COMPLEX1R1 tVar24))"
                        proof-
                          show " ex tVar24 be NatNAT-1M1 st tVar24 <XXREAL-0R3 N1 & (s .FUNCT-1K1 tVar24 >XXREAL-0R4 x0 & ( ex tVar25 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar25 =COMPLEX1R1 tVar24))"
                          proof(rule bexI[of _ "N"],rule conjMI,rule conjMI)
                            have A99: "N <>HIDDENR2 N1"
                              using A86 A97 sorry
                            have "N <=XXREAL-0R1 N1"
                              using A71 A97 sorry
                            thus "N <XXREAL-0R3 N1"
                              using A99 xxreal_0_th_1 sorry
                            show "s .FUNCT-1K1 N >XXREAL-0R4 x0"
                              using A71 sorry
                            show " ex tVar25 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar25 =COMPLEX1R1 N"
                            proof(rule bexI[of _ "0NUMBERSK6"])
                              show "G .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 N"
                                using A86 sorry
                            qed "sorry"
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have A100: " for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 N1"
                         sorry
                      obtain NX where
                        [ty]:"NX be NatNAT-1M1" and 
                        A101: "?X(NX) & ( for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 NX)"
                        using nat_1_sch_6 A100 A98 sorry
                      have A102: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds NX <XXREAL-0R3 k & k <XXREAL-0R3 N1 implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 x0"
                      proof-
                        have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (NX <XXREAL-0R3 k & k <XXREAL-0R3 N1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0) implies  False "
                        proof(rule impI)
                          assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (NX <XXREAL-0R3 k & k <XXREAL-0R3 N1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0"
                          then obtain k where
                            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                            A103: "NX <XXREAL-0R3 k"and A104: "k <XXREAL-0R3 N1"and A105: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0"
                             sorry
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k)"
                                 sorry
                              have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                              proof(rule impI)
                                assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k"
                                thus " False "
                                  using A101 A103 A104 A105 sorry
                              qed
                              have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                              proof(rule impI)
                                assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k"
                                thus " False "
                                  using A97 A104 A105 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      obtain m where
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A106: "G .RECDEF-1K1 m =COMPLEX1R1 NX"
                        using A101 sorry
                      have "N1 inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      then have A107: "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 N1"
                        using A86 A97 A101 A106 sorry
                      have A108: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 x0"
                        using A86 A106 sorry
                      have A109: "NX <XXREAL-0R3 G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                        using A86 A106 sorry
                      have "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 N1 implies  False "
                      proof(rule impI)
                        assume "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 N1"
                        then have "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 N1"
                          using A107 xxreal_0_th_1 sorry
                        thus " False "
                          using A102 A109 A108 sorry
                      qed
                      thus " False "
                        using A97 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  let ?X = "\<lambda>Lamb1. (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                  have A110: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
                  proof-
                    have " for k be NatNAT-1M1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 k >XXREAL-0R4 x0 implies (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 x0"
                    proof(rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      assume "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 k >XXREAL-0R4 x0"
                      have "?P(G .RECDEF-1K1 k,G .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                        using A86 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (G .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 x0"
                         sorry
                      thus "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 x0"
                        using funct_2_th_15 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have A111: "?X(0NUMBERSK6)"
                    using A71 A86 funct_2_th_15 sorry
                  have A112: " for k be NatNAT-1M1 holds ?X(k)"
                    using nat_1_sch_2 A111 A110 sorry
                  have A113: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A114: "x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A115: "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                        using A112 sorry
                      then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
                        using A115 sorry
                      then have A116: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 x0"
                        using xxreal_1_th_230 sorry
                      have "x inHIDDENR3 domRELAT-1K1 f"
                        using A94 A114 xboole_0_def_5 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                        using A116 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                      using tarski_def_3 sorry
                  qed
                  have A117: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G be convergentSEQ-2V5"
                    using A15 A93 seq_4_th_16 sorry
                  have "limSEQ-2K1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) =COMPLEX1R1 x0"
                    using A15 A16 A93 seq_4_th_17 sorry
                  then have A118: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) be divergent-to+inftyLIMFUNC1V1"
                    using A12 A117 A113 limfunc2_def_5 sorry
                  have "limSEQ-2K1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) =COMPLEX1R1 x0"
                    using A15 A16 A50 seq_4_th_17 sorry
                  then have A119: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) be divergent-to+inftyLIMFUNC1V1"
                    using A11 A79 A75 limfunc2_def_2 sorry
                  have " for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                  proof(rule ballI)
                    fix r assume [ty]: "r be RealXREAL-0M1"
                    obtain n1 where
                      [ty]:"n1 be NatNAT-1M1" and 
                      A120: " for k be NatNAT-1M1 holds n1 <=XXREAL-0R1 k implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) .FUNCT-1K1 k"
                      using A119 sorry
                    obtain n2 where
                      [ty]:"n2 be NatNAT-1M1" and 
                      A121: " for k be NatNAT-1M1 holds n2 <=XXREAL-0R1 k implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) .FUNCT-1K1 k"
                      using A118 sorry
                    obtain n where 
                      [ty]:"n be NatNAT-1M1" and nDef:"n = maxNAT-1K5(F .RECDEF-1K1 n1,G .RECDEF-1K1 n2)"
                       sorry
                    show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                    proof(rule bexI[of _ "n"],rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      have A122: "k inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      assume A123: "n <=XXREAL-0R1 k"
                      have "s .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-1K1 k inTARSKIR2 {TARSKIK1 x0}"
                        using A17 xboole_0_def_5 sorry
                      then have A124: "s .FUNCT-1K1 k <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      have "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                      proof-
                        show "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                        proof-
                          have cases: "s .FUNCT-1K1 k <XXREAL-0R3 x0 or s .FUNCT-1K1 k >XXREAL-0R4 x0"
                            using A124 xxreal_0_th_1 sorry
                          have case1: "s .FUNCT-1K1 k <XXREAL-0R3 x0 implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                          proof(rule impI)
                            assume "s .FUNCT-1K1 k <XXREAL-0R3 x0"
                            then obtain l where
                              [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                              A125: "k =COMPLEX1R1 F .RECDEF-1K1 l"
                              using A52 A122 sorry
                            have "F .RECDEF-1K1 n1 <=XXREAL-0R1 n"
                              using xxreal_0_th_25 sorry
                            then have "F .RECDEF-1K1 n1 <=XXREAL-0R1 k"
                              using A123 xxreal_0_th_2 sorry
                            then have "l >=XXREAL-0R2 n1"
                              using A125 seqm_3_th_1 sorry
                            then have "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l"
                              using A120 sorry
                            then have "r <XXREAL-0R3 f .FUNCT-1K1 ((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l)"
                              using A51 funct_2_th_108 xboole_1_th_1 sorry
                            then have "r <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 k)"
                              using A125 funct_2_th_15 sorry
                            thus "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                              using A17 funct_2_th_108 xboole_1_th_1 A122 sorry
                          qed
                          have case2: "s .FUNCT-1K1 k >XXREAL-0R4 x0 implies r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                          proof(rule impI)
                            assume "s .FUNCT-1K1 k >XXREAL-0R4 x0"
                            then obtain l where
                              [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                              A126: "k =COMPLEX1R1 G .RECDEF-1K1 l"
                              using A95 A122 sorry
                            have "G .RECDEF-1K1 n2 <=XXREAL-0R1 n"
                              using xxreal_0_th_25 sorry
                            then have "G .RECDEF-1K1 n2 <=XXREAL-0R1 k"
                              using A123 xxreal_0_th_2 sorry
                            then have "l >=XXREAL-0R2 n2"
                              using A126 seqm_3_th_1 sorry
                            then have "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l"
                              using A121 sorry
                            then have "r <XXREAL-0R3 f .FUNCT-1K1 ((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l)"
                              using A94 funct_2_th_108 xboole_1_th_1 sorry
                            then have "r <XXREAL-0R3 f .FUNCT-1K1 (s .FUNCT-1K1 k)"
                              using A126 funct_2_th_15 sorry
                            thus "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                              using A17 funct_2_th_108 xboole_1_th_1 A122 sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus "r <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k"
                         sorry
                    qed "sorry"
                  qed "sorry"
                  thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
         sorry
    qed "sorry"
    have " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
      using A11 limfunc2_def_2 sorry
    then have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
      using A13 limfunc3_th_8 sorry
    thus "f is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_13:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to-infty-inLIMFUNC3R3 x0 iff f is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-divergent-to-infty-inLIMFUNC3R3 x0 implies f is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f is-right-divergent-to-infty-inLIMFUNC2R6 x0) & (f is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f is-right-divergent-to-infty-inLIMFUNC2R6 x0 implies f is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-divergent-to-infty-inLIMFUNC3R3 x0 implies f is-left-divergent-to-infty-inLIMFUNC2R3 x0 & f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
    proof(rule impI,rule conjMI)
      assume A1: "f is-divergent-to-infty-inLIMFUNC3R3 x0"
      have A2: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
        assume A3: "s be convergentSEQ-2V5"
          and A4: "limSEQ-2K1 s =COMPLEX1R1 x0"
          and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A5 limfunc3_th_1 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
          using A1 A3 A4 sorry
      qed "sorry"
      have A6: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
        assume A7: "s be convergentSEQ-2V5"
          and A8: "limSEQ-2K1 s =COMPLEX1R1 x0"
          and A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A9 limfunc3_th_1 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
          using A1 A7 A8 sorry
      qed "sorry"
      have A10: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
        using A1 sorry
      then have " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
        using limfunc3_th_8 sorry
      thus "f is-left-divergent-to-infty-inLIMFUNC2R3 x0"
        using A2 limfunc2_def_3 sorry
      have " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)"
        using A10 limfunc3_th_8 sorry
      thus "f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
        using A6 limfunc2_def_6 sorry
    qed
    assume A11: "f is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      and A12: "f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
    have A13: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A14: "s be convergentSEQ-2V5"
        and A15: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
      proof-
        show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        proof-
          have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0)"
             sorry
          have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
          proof(rule impI)
            assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
            then obtain k where
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A17: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
               sorry
            have A18: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
              using A16 xboole_1_th_1 sorry
            have A19: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                then obtain n where
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A20: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                  using funct_2_th_113 sorry
                have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0"
                  using A17 nat_1_th_12 sorry
                then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
                   sorry
                then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
                  using xxreal_1_th_229 sorry
                then have A21: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 x0"
                  using A20 nat_1_def_3 sorry
                have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
                  using valued_0_th_28 sorry
                then have "x inHIDDENR3 rngFUNCT-1K2 s"
                  using A20 nat_1_def_3 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                  using A18 A21 xboole_0_def_4 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                using tarski_def_3 sorry
            qed
            have A22: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A16 valued_0_th_27 xboole_1_th_1 sorry
            have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
              using A14 A15 seq_4_th_20 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
              using A11 A14 A19 limfunc2_def_3 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
              using A22 limfunc1_th_7 sorry
          qed
          have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
          proof(rule impI)
            assume A23: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0"
            have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
            proof-
              show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
              proof-
                have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                   sorry
                have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
                proof(rule impI)
                  assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  then obtain k where
                    [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A24: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                     sorry
                  have A25: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
                    using A16 xboole_1_th_1 sorry
                  have A26: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A27: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
                        using A24 nat_1_th_12 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
                         sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
                        using xxreal_1_th_230 sorry
                      then have A28: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 x0"
                        using A27 nat_1_def_3 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have "x inHIDDENR3 rngFUNCT-1K2 s"
                        using A27 nat_1_def_3 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                        using A25 A28 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                      using tarski_def_3 sorry
                  qed
                  have A29: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
                    using A16 valued_0_th_27 xboole_1_th_1 sorry
                  have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
                    using A14 A15 seq_4_th_20 sorry
                  then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
                    using A12 A14 A26 limfunc2_def_6 sorry
                  thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
                    using A29 limfunc1_th_7 sorry
                qed
                have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
                proof(rule impI)
                  assume A30: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb1 =XBOOLE-0R4 n & Lamb2 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k)"
                  let ?X3 = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. ?P(Lamb2,Lamb3)"
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                  have A31: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                  proof(rule ballI)
                    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain n where
                      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A32: "k <=XXREAL-0R1 n"and A33: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 x0"
                      using A30 sorry
                    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                    proof(rule bexI[of _ "n"],rule conjMI)
                      show "k <=XXREAL-0R1 n"
                        using A32 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                        using A16 xboole_0_def_5 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      thus "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                        using A33 xxreal_0_th_1 sorry
                    qed "sorry"
                  qed "sorry"
                  then have " ex m1 be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 m1 & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m1 <XXREAL-0R3 x0"
                     sorry
                  then have A34: " ex m be NatNAT-1M1 st ?X(m)"
                     sorry
                  obtain M where
                    [ty]:"M be NatNAT-1M1" and 
                    A35: "?X(M) & ( for n be NatNAT-1M1 holds ?X(n) implies M <=XXREAL-0R1 n)"
                    using nat_1_sch_5 A34 sorry
                  obtain M9 where 
                    [ty]:"M9 be ElementSUBSET-1M1-of NATNUMBERSK1" and M9Def:"M9 = M"
                    using ordinal1_def_12 sorry
                  have A36: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain m where
                      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A37: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"and A38: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                      using A31 sorry
                    show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                    proof(rule bexI[of _ "m"])
                      show "n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                        using A37 A38 nat_1_th_13 sorry
                    qed "sorry"
                  qed "sorry"
                  have A39: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X3(n,x,y)"
                  proof-
                    have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar29 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar29 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar29 =XBOOLE-0R4 nc & tVar29 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                    proof(rule ballI,rule ballI)
                      fix n assume [ty]: "n be NatNAT-1M1"
                      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                      let ?X = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                      have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(m)"
                        using A36 sorry
                      then have A40: " ex m be NatNAT-1M1 st ?X(m)"
                         sorry
                      obtain l where
                        [ty]:"l be NatNAT-1M1" and 
                        A41: "?X(l) & ( for k be NatNAT-1M1 holds ?X(k) implies l <=XXREAL-0R1 k)"
                        using nat_1_sch_5 A40 sorry
                      show " ex tVar29 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar29 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar29 =XBOOLE-0R4 nc & tVar29 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                      proof(rule bexI[of _ "l"])
                        have "l inTARSKIR2 NATNUMBERSK1"
                          using ordinal1_def_12 sorry
                        thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds l =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                          using A41 sorry
                      qed "sorry"
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  obtain F where
                    [ty]:"F be sequenceNAT-1M2-of NATNUMBERSK1" and 
                    A42: "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M9 & ( for n be NatNAT-1M1 holds ?X3(n,F .RECDEF-1K1 n,F .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                    using recdef_1_sch_2 A39 sorry
                  have A43: "rngFUNCT-1K2 F c=TARSKIR1 NATNUMBERSK1"
                    using relat_1_def_19 sorry
                  then have A44: "rngFUNCT-1K2 F c=TARSKIR1 REALNUMBERSK2"
                    using numbers_th_19 sorry
                  have A45: "domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1"
                    using funct_2_def_1 sorry
                  then have 
                    [ty]:"F be Real-SequenceSEQ-1M1"
                    using A44 relset_1_th_4 sorry
                  have A46: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    have "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 F"
                      using A45 funct_1_def_3 sorry
                    thus "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A43 sorry
                  qed "sorry"
                  have " for n be NatNAT-1M1 holds F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI)
                    fix n assume [ty]: "n be NatNAT-1M1"
                    have A47: "n inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have A48: "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A46 sorry
                    have "F .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A46 A47 sorry
                    thus "F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                      using A42 A48 sorry
                  qed "sorry"
                  then have 
                    [ty]:"F be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
                    using seqm_3_def_6 sorry
                  have A49: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s"
                    using valued_0_def_17 sorry
                  then have "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 rngFUNCT-1K2 s"
                    using valued_0_th_21 sorry
                  then have A50: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
                    using A16 sorry
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                  have A51: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 n)"
                  proof-
                    have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-1K1 n <XXREAL-0R3 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
                    proof(rule impI)
                      assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
                      then have A52: " ex n be NatNAT-1M1 st ?X(n)"
                         sorry
                      obtain M1 where
                        [ty]:"M1 be NatNAT-1M1" and 
                        A53: "?X(M1) & ( for n be NatNAT-1M1 holds ?X(n) implies M1 <=XXREAL-0R1 n)"
                        using nat_1_sch_5 A52 sorry
                      let ?X = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 M1 & s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                      have A54: " ex n be NatNAT-1M1 st ?X(n)"
                      proof-
                        have " ex tVar30 be NatNAT-1M1 st tVar30 <XXREAL-0R3 M1 & (s .FUNCT-1K1 tVar30 <XXREAL-0R3 x0 & ( ex tVar31 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar31 =COMPLEX1R1 tVar30))"
                        proof-
                          show " ex tVar30 be NatNAT-1M1 st tVar30 <XXREAL-0R3 M1 & (s .FUNCT-1K1 tVar30 <XXREAL-0R3 x0 & ( ex tVar31 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar31 =COMPLEX1R1 tVar30))"
                          proof(rule bexI[of _ "M"],rule conjMI,rule conjMI)
                            have A55: "M <>HIDDENR2 M1"
                              using A42 A53 sorry
                            have "M <=XXREAL-0R1 M1"
                              using A35 A53 sorry
                            thus "M <XXREAL-0R3 M1"
                              using A55 xxreal_0_th_1 sorry
                            show "s .FUNCT-1K1 M <XXREAL-0R3 x0"
                              using A35 sorry
                            show " ex tVar31 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar31 =COMPLEX1R1 M"
                            proof(rule bexI[of _ "0NUMBERSK6"])
                              show "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M"
                                using A42 sorry
                            qed "sorry"
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have A56: " for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 M1"
                         sorry
                      obtain MX where
                        [ty]:"MX be NatNAT-1M1" and 
                        A57: "?X(MX) & ( for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 MX)"
                        using nat_1_sch_6 A56 A54 sorry
                      have A58: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds MX <XXREAL-0R3 k & k <XXREAL-0R3 M1 implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 x0"
                      proof-
                        have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (MX <XXREAL-0R3 k & k <XXREAL-0R3 M1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0) implies  False "
                        proof(rule impI)
                          assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (MX <XXREAL-0R3 k & k <XXREAL-0R3 M1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0"
                          then obtain k where
                            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                            A59: "MX <XXREAL-0R3 k"and A60: "k <XXREAL-0R3 M1"and A61: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0"
                             sorry
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k)"
                                 sorry
                              have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                              proof(rule impI)
                                assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k"
                                thus " False "
                                  using A57 A59 A60 A61 sorry
                              qed
                              have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                              proof(rule impI)
                                assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k"
                                thus " False "
                                  using A53 A60 A61 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      obtain m where
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A62: "F .RECDEF-1K1 m =COMPLEX1R1 MX"
                        using A57 sorry
                      have "M1 inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      then have A63: "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 M1"
                        using A42 A53 A57 A62 sorry
                      have A64: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 x0"
                        using A42 A62 sorry
                      have A65: "MX <XXREAL-0R3 F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                        using A42 A62 sorry
                      have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1 implies  False "
                      proof(rule impI)
                        assume "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1"
                        then have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 M1"
                          using A63 xxreal_0_th_1 sorry
                        thus " False "
                          using A58 A65 A64 sorry
                      qed
                      thus " False "
                        using A53 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                  have A66: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                  proof(rule ballI)
                    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain n where
                      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A67: "k <=XXREAL-0R1 n"and A68: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0"
                      using A23 sorry
                    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                    proof(rule bexI[of _ "n"],rule conjMI)
                      show "k <=XXREAL-0R1 n"
                        using A67 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                        using A16 xboole_0_def_5 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      thus "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                        using A68 xxreal_0_th_1 sorry
                    qed "sorry"
                  qed "sorry"
                  then have " ex mn be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 mn & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> mn >XXREAL-0R4 x0"
                     sorry
                  then have A69: " ex m be NatNAT-1M1 st ?X(m)"
                     sorry
                  obtain N where
                    [ty]:"N be NatNAT-1M1" and 
                    A70: "?X(N) & ( for n be NatNAT-1M1 holds ?X(n) implies N <=XXREAL-0R1 n)"
                    using nat_1_sch_5 A69 sorry
                  let ?X = "\<lambda>Lamb1. (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                  have A71: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
                  proof-
                    have " for k be NatNAT-1M1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <XXREAL-0R3 x0 implies (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
                    proof(rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      assume "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <XXREAL-0R3 x0"
                      have "?P(F .RECDEF-1K1 k,F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                        using A42 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 x0"
                         sorry
                      thus "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
                        using funct_2_th_15 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have A72: "?X(0NUMBERSK6)"
                    using A35 A42 funct_2_th_15 sorry
                  have A73: " for k be NatNAT-1M1 holds ?X(k)"
                    using nat_1_sch_2 A72 A71 sorry
                  have A74: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A75: "x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A76: "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                        using A73 sorry
                      then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
                        using A76 sorry
                      then have A77: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 x0"
                        using xxreal_1_th_229 sorry
                      have "x inHIDDENR3 domRELAT-1K1 f"
                        using A50 A75 xboole_0_def_5 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                        using A77 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                      using tarski_def_3 sorry
                  qed
                  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb1 =XBOOLE-0R4 n & Lamb2 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k)"
                  let ?X3 = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. ?P(Lamb2,Lamb3)"
                  have A78: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F be convergentSEQ-2V5"
                    using A14 A49 seq_4_th_16 sorry
                  have "limSEQ-2K1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) =COMPLEX1R1 x0"
                    using A14 A15 A49 seq_4_th_17 sorry
                  then have A79: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) be divergent-to-inftyLIMFUNC1V2"
                    using A11 A78 A74 limfunc2_def_3 sorry
                  obtain N9 where 
                    [ty]:"N9 be ElementSUBSET-1M1-of NATNUMBERSK1" and N9Def:"N9 = N"
                    using ordinal1_def_12 sorry
                  have A80: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain m where
                      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A81: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"and A82: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                      using A66 sorry
                    show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                    proof(rule bexI[of _ "m"])
                      show "n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                        using A81 A82 nat_1_th_13 sorry
                    qed "sorry"
                  qed "sorry"
                  have A83: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X3(n,x,y)"
                  proof-
                    have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar34 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar34 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar34 =XBOOLE-0R4 nc & tVar34 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k))"
                    proof(rule ballI,rule ballI)
                      fix n assume [ty]: "n be NatNAT-1M1"
                      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                      let ?X = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                      have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(m)"
                        using A80 sorry
                      then have A84: " ex m be NatNAT-1M1 st ?X(m)"
                         sorry
                      obtain l where
                        [ty]:"l be NatNAT-1M1" and 
                        A85: "?X(l) & ( for k be NatNAT-1M1 holds ?X(k) implies l <=XXREAL-0R1 k)"
                        using nat_1_sch_5 A84 sorry
                      show " ex tVar34 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar34 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar34 =XBOOLE-0R4 nc & tVar34 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k))"
                      proof(rule bexI[of _ "l"])
                        have "l inTARSKIR2 NATNUMBERSK1"
                          using ordinal1_def_12 sorry
                        thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds l =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k))"
                          using A85 sorry
                      qed "sorry"
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  obtain G where
                    [ty]:"G be sequenceNAT-1M2-of NATNUMBERSK1" and 
                    A86: "G .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 N9 & ( for n be NatNAT-1M1 holds ?X3(n,G .RECDEF-1K1 n,G .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                    using recdef_1_sch_2 A83 sorry
                  have A87: "rngFUNCT-1K2 G c=TARSKIR1 NATNUMBERSK1"
                    using relat_1_def_19 sorry
                  then have A88: "rngFUNCT-1K2 G c=TARSKIR1 REALNUMBERSK2"
                    using numbers_th_19 sorry
                  have A89: "domRELAT-1K1 G =XBOOLE-0R4 NATNUMBERSK1"
                    using funct_2_def_1 sorry
                  then have 
                    [ty]:"G be Real-SequenceSEQ-1M1"
                    using A88 relset_1_th_4 sorry
                  have A90: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    have "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 G"
                      using A89 funct_1_def_3 sorry
                    thus "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A87 sorry
                  qed "sorry"
                  have " for n be NatNAT-1M1 holds G .FUNCT-1K1 n <XXREAL-0R3 G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI)
                    fix n assume [ty]: "n be NatNAT-1M1"
                    have A91: "n inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have A92: "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A90 sorry
                    have "G .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A90 A91 sorry
                    thus "G .FUNCT-1K1 n <XXREAL-0R3 G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                      using A86 A92 sorry
                  qed "sorry"
                  then have 
                    [ty]:"G be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
                    using seqm_3_def_6 sorry
                  have A93: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s"
                    using valued_0_def_17 sorry
                  then have "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 rngFUNCT-1K2 s"
                    using valued_0_th_21 sorry
                  then have A94: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
                    using A16 sorry
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                  have A95: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0 implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 n)"
                  proof-
                    have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-1K1 n >XXREAL-0R4 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
                    proof(rule impI)
                      assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
                      then have A96: " ex n be NatNAT-1M1 st ?X(n)"
                         sorry
                      obtain N1 where
                        [ty]:"N1 be NatNAT-1M1" and 
                        A97: "?X(N1) & ( for n be NatNAT-1M1 holds ?X(n) implies N1 <=XXREAL-0R1 n)"
                        using nat_1_sch_5 A96 sorry
                      let ?X = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 N1 & s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                      have A98: " ex n be NatNAT-1M1 st ?X(n)"
                      proof-
                        have " ex tVar35 be NatNAT-1M1 st tVar35 <XXREAL-0R3 N1 & (s .FUNCT-1K1 tVar35 >XXREAL-0R4 x0 & ( ex tVar36 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar36 =COMPLEX1R1 tVar35))"
                        proof-
                          show " ex tVar35 be NatNAT-1M1 st tVar35 <XXREAL-0R3 N1 & (s .FUNCT-1K1 tVar35 >XXREAL-0R4 x0 & ( ex tVar36 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar36 =COMPLEX1R1 tVar35))"
                          proof(rule bexI[of _ "N"],rule conjMI,rule conjMI)
                            have A99: "N <>HIDDENR2 N1"
                              using A86 A97 sorry
                            have "N <=XXREAL-0R1 N1"
                              using A70 A97 sorry
                            thus "N <XXREAL-0R3 N1"
                              using A99 xxreal_0_th_1 sorry
                            show "s .FUNCT-1K1 N >XXREAL-0R4 x0"
                              using A70 sorry
                            show " ex tVar36 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar36 =COMPLEX1R1 N"
                            proof(rule bexI[of _ "0NUMBERSK6"])
                              show "G .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 N"
                                using A86 sorry
                            qed "sorry"
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have A100: " for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 N1"
                         sorry
                      obtain NX where
                        [ty]:"NX be NatNAT-1M1" and 
                        A101: "?X(NX) & ( for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 NX)"
                        using nat_1_sch_6 A100 A98 sorry
                      have A102: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds NX <XXREAL-0R3 k & k <XXREAL-0R3 N1 implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 x0"
                      proof-
                        have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (NX <XXREAL-0R3 k & k <XXREAL-0R3 N1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0) implies  False "
                        proof(rule impI)
                          assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (NX <XXREAL-0R3 k & k <XXREAL-0R3 N1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0"
                          then obtain k where
                            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                            A103: "NX <XXREAL-0R3 k"and A104: "k <XXREAL-0R3 N1"and A105: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0"
                             sorry
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k)"
                                 sorry
                              have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                              proof(rule impI)
                                assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k"
                                thus " False "
                                  using A101 A103 A104 A105 sorry
                              qed
                              have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                              proof(rule impI)
                                assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k"
                                thus " False "
                                  using A97 A104 A105 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      obtain m where
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A106: "G .RECDEF-1K1 m =COMPLEX1R1 NX"
                        using A101 sorry
                      have "N1 inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      then have A107: "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 N1"
                        using A86 A97 A101 A106 sorry
                      have A108: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 x0"
                        using A86 A106 sorry
                      have A109: "NX <XXREAL-0R3 G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                        using A86 A106 sorry
                      have "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 N1 implies  False "
                      proof(rule impI)
                        assume "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 N1"
                        then have "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 N1"
                          using A107 xxreal_0_th_1 sorry
                        thus " False "
                          using A102 A109 A108 sorry
                      qed
                      thus " False "
                        using A97 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  let ?X = "\<lambda>Lamb1. (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                  have A110: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
                  proof-
                    have " for k be NatNAT-1M1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 k >XXREAL-0R4 x0 implies (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 x0"
                    proof(rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      assume "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 k >XXREAL-0R4 x0"
                      have "?P(G .RECDEF-1K1 k,G .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                        using A86 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (G .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 x0"
                         sorry
                      thus "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 x0"
                        using funct_2_th_15 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have A111: "?X(0NUMBERSK6)"
                    using A70 A86 funct_2_th_15 sorry
                  have A112: " for k be NatNAT-1M1 holds ?X(k)"
                    using nat_1_sch_2 A111 A110 sorry
                  have A113: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A114: "x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A115: "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                        using A112 sorry
                      then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
                        using A115 sorry
                      then have A116: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 x0"
                        using xxreal_1_th_230 sorry
                      have "x inHIDDENR3 domRELAT-1K1 f"
                        using A94 A114 xboole_0_def_5 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                        using A116 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                      using tarski_def_3 sorry
                  qed
                  have A117: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G be convergentSEQ-2V5"
                    using A14 A93 seq_4_th_16 sorry
                  have "limSEQ-2K1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) =COMPLEX1R1 x0"
                    using A14 A15 A93 seq_4_th_17 sorry
                  then have A118: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) be divergent-to-inftyLIMFUNC1V2"
                    using A12 A117 A113 limfunc2_def_6 sorry
                  have " for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                  proof(rule ballI)
                    fix r assume [ty]: "r be RealXREAL-0M1"
                    obtain n1 where
                      [ty]:"n1 be NatNAT-1M1" and 
                      A119: " for k be NatNAT-1M1 holds n1 <=XXREAL-0R1 k implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) .FUNCT-1K1 k <XXREAL-0R3 r"
                      using A79 sorry
                    obtain n2 where
                      [ty]:"n2 be NatNAT-1M1" and 
                      A120: " for k be NatNAT-1M1 holds n2 <=XXREAL-0R1 k implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) .FUNCT-1K1 k <XXREAL-0R3 r"
                      using A118 sorry
                    obtain n where 
                      [ty]:"n be NatNAT-1M1" and nDef:"n = maxNAT-1K5(F .RECDEF-1K1 n1,G .RECDEF-1K1 n2)"
                       sorry
                    show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                    proof(rule bexI[of _ "n"],rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      have A121: "k inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      assume A122: "n <=XXREAL-0R1 k"
                      have "s .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-1K1 k inTARSKIR2 {TARSKIK1 x0}"
                        using A16 xboole_0_def_5 sorry
                      then have A123: "s .FUNCT-1K1 k <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                      proof-
                        show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                        proof-
                          have cases: "s .FUNCT-1K1 k <XXREAL-0R3 x0 or s .FUNCT-1K1 k >XXREAL-0R4 x0"
                            using A123 xxreal_0_th_1 sorry
                          have case1: "s .FUNCT-1K1 k <XXREAL-0R3 x0 implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                          proof(rule impI)
                            assume "s .FUNCT-1K1 k <XXREAL-0R3 x0"
                            then obtain l where
                              [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                              A124: "k =COMPLEX1R1 F .RECDEF-1K1 l"
                              using A51 A121 sorry
                            have "F .RECDEF-1K1 n1 <=XXREAL-0R1 n"
                              using xxreal_0_th_25 sorry
                            then have "F .RECDEF-1K1 n1 <=XXREAL-0R1 k"
                              using A122 xxreal_0_th_2 sorry
                            then have "l >=XXREAL-0R2 n1"
                              using A124 seqm_3_th_1 sorry
                            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l <XXREAL-0R3 r"
                              using A119 sorry
                            then have "f .FUNCT-1K1 ((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l) <XXREAL-0R3 r"
                              using A50 funct_2_th_108 xboole_1_th_1 sorry
                            then have "f .FUNCT-1K1 (s .FUNCT-1K1 k) <XXREAL-0R3 r"
                              using A124 funct_2_th_15 sorry
                            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                              using A16 funct_2_th_108 xboole_1_th_1 A121 sorry
                          qed
                          have case2: "s .FUNCT-1K1 k >XXREAL-0R4 x0 implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                          proof(rule impI)
                            assume "s .FUNCT-1K1 k >XXREAL-0R4 x0"
                            then obtain l where
                              [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                              A125: "k =COMPLEX1R1 G .RECDEF-1K1 l"
                              using A95 A121 sorry
                            have "G .RECDEF-1K1 n2 <=XXREAL-0R1 n"
                              using xxreal_0_th_25 sorry
                            then have "G .RECDEF-1K1 n2 <=XXREAL-0R1 k"
                              using A122 xxreal_0_th_2 sorry
                            then have "l >=XXREAL-0R2 n2"
                              using A125 seqm_3_th_1 sorry
                            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l <XXREAL-0R3 r"
                              using A120 sorry
                            then have "f .FUNCT-1K1 ((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l) <XXREAL-0R3 r"
                              using A94 funct_2_th_108 xboole_1_th_1 sorry
                            then have "f .FUNCT-1K1 (s .FUNCT-1K1 k) <XXREAL-0R3 r"
                              using A125 funct_2_th_15 sorry
                            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                              using A16 funct_2_th_108 xboole_1_th_1 A121 sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k <XXREAL-0R3 r"
                         sorry
                    qed "sorry"
                  qed "sorry"
                  thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
         sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A126: "r1 <XXREAL-0R3 x0"
        and A127: "x0 <XXREAL-0R3 r2"
      obtain g1 where
        [ty]:"g1 be RealXREAL-0M1" and 
        A128: "r1 <XXREAL-0R3 g1"and A129: "g1 <XXREAL-0R3 x0"and A130: "g1 inHIDDENR3 domRELAT-1K1 f"
        using A11 A126 limfunc2_def_3 sorry
      obtain g2 where
        [ty]:"g2 be RealXREAL-0M1" and 
        A131: "g2 <XXREAL-0R3 r2"and A132: "x0 <XXREAL-0R3 g2"and A133: "g2 inHIDDENR3 domRELAT-1K1 f"
        using A12 A127 limfunc2_def_6 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
            using A128 A129 A130 A131 A132 A133 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & f2 is-divergent-to+infty-inLIMFUNC3R2 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & (f2 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A2: "f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)"
    have A4: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5"
        and A6: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_4 sorry
      then have A8: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A2 A5 A6 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_4 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 A6 sorry
      then have A9: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A8 limfunc1_th_8 sorry
      have A10: "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A7 limfunc3_lm_4 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A7 limfunc3_lm_4 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A10 A9 rfunct_2_th_8 sorry
    qed "sorry"
    have A11: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A12: "s be convergentSEQ-2V5"
        and A13: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A14: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A14 limfunc3_lm_2 sorry
      then have A15: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A2 A12 A13 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A14 limfunc3_lm_2 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A1 A12 A13 sorry
      then have A16: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A15 limfunc1_th_10 sorry
      have A17: "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A14 limfunc3_lm_2 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A14 limfunc3_lm_2 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A17 A16 rfunct_2_th_8 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A18: "r1 <XXREAL-0R3 x0"
        and A19: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A20: "r1 <XXREAL-0R3 g1"and A21: "g1 <XXREAL-0R3 x0"and A22: "g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"and A23: "g2 <XXREAL-0R3 r2"and A24: "x0 <XXREAL-0R3 g2"and A25: "g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A3 A18 A19 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using A20 A21 A22 A23 A24 A25 valued_1_def_1 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A4 sorry
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A26: "r1 <XXREAL-0R3 x0"
        and A27: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A28: "r1 <XXREAL-0R3 g1"and A29: "g1 <XXREAL-0R3 x0"and A30: "g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"and A31: "g2 <XXREAL-0R3 r2"and A32: "x0 <XXREAL-0R3 g2"and A33: "g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A3 A26 A27 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using A28 A29 A30 A31 A32 A33 valued_1_def_4 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_15:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & f2 is-divergent-to-infty-inLIMFUNC3R3 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to-infty-inLIMFUNC3R3 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & (f2 is-divergent-to-infty-inLIMFUNC3R3 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to-infty-inLIMFUNC3R3 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      and A2: "f2 is-divergent-to-infty-inLIMFUNC3R3 x0"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)"
    have A4: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5"
        and A6: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_4 sorry
      then have A8: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A2 A5 A6 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_4 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A5 A6 sorry
      then have A9: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A8 limfunc1_th_11 sorry
      have A10: "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A7 limfunc3_lm_4 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A7 limfunc3_lm_4 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A10 A9 rfunct_2_th_8 sorry
    qed "sorry"
    have A11: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A12: "s be convergentSEQ-2V5"
        and A13: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A14: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A14 limfunc3_lm_2 sorry
      then have A15: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A2 A12 A13 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A14 limfunc3_lm_2 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A1 A12 A13 sorry
      then have A16: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A15 limfunc1_th_24 sorry
      have A17: "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A14 limfunc3_lm_2 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A14 limfunc3_lm_2 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A17 A16 rfunct_2_th_8 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A18: "r1 <XXREAL-0R3 x0"
        and A19: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A20: "r1 <XXREAL-0R3 g1"and A21: "g1 <XXREAL-0R3 x0"and A22: "g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"and A23: "g2 <XXREAL-0R3 r2"and A24: "x0 <XXREAL-0R3 g2"and A25: "g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A3 A18 A19 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using A20 A21 A22 A23 A24 A25 valued_1_def_1 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A4 sorry
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A26: "r1 <XXREAL-0R3 x0"
        and A27: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A28: "r1 <XXREAL-0R3 g1"and A29: "g1 <XXREAL-0R3 x0"and A30: "g1 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"and A31: "g2 <XXREAL-0R3 r2"and A32: "x0 <XXREAL-0R3 g2"and A33: "g2 inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A3 A26 A27 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using A28 A29 A30 A31 A32 A33 valued_1_def_4 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_16:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r"and A4: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5"
        and A6: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
        using A3 A5 A6 limfunc3_th_7 sorry
      have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have A9: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 sorry
      then have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using limfunc3_lm_4 sorry
      have A11: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2"
        using A9 limfunc3_lm_4 sorry
      have " ex r2 be setHIDDENM2 st  for n be NatNAT-1M1 holds r2 <XXREAL-0R3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof-
        obtain r1 where
          [ty]:"r1 be RealXREAL-0M1" and 
          A12: " for g be objectHIDDENM1 holds g inHIDDENR3 (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 f2 implies r1 <=XXREAL-0R1 f2 .FUNCT-1K1 g"
          using A4 rfunct_1_th_71 sorry
        obtain r2 where 
          [ty]:"r2 be setHIDDENM2" and r2Def:"r2 = r1 -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        show " ex r2 be setHIDDENM2 st  for n be NatNAT-1M1 holds r2 <XXREAL-0R3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
        proof(rule bexI[of _ "r2"],rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A13: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have A14: "k <=XXREAL-0R1 n +NAT-1K1 k"
            using nat_1_th_12 sorry
          then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r"
            using A8 sorry
          then have A15: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
            using nat_1_def_3 sorry
          have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
            using A8 A14 sorry
          then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
            using nat_1_def_3 sorry
          then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
            using A15 sorry
          then have A16: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using rcomp_1_def_2 sorry
          have A17: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
            using valued_0_th_28 sorry
          then have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {TARSKIK1 x0}"
            using A9 xboole_0_def_5 sorry
          then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
            using A16 xboole_0_def_5 sorry
          then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
            using A3 limfunc3_th_4 sorry
          then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 f2"
            using A11 A17 xboole_0_def_4 sorry
          then have "r1 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) -XCMPLX-0K6 0NUMBERSK6"
            using A12 xreal_1_th_15 sorry
          thus "r2 <XXREAL-0R3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
            using A11 funct_2_th_108 A13 sorry
        qed "sorry"
      qed
      then have A18: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be bounded-belowSEQ-2V4"
        using seq_2_def_4 sorry
      have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
        using A5 A6 seq_4_th_20 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A5 A10 sorry
      then have A19: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A18 limfunc1_th_9 sorry
      have A20: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A7 limfunc3_lm_4 sorry
      have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A9 limfunc3_lm_4 sorry
      then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using valued_1_def_1 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A20 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A19 limfunc1_th_7 sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_17:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st  ex r1 be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & 0NUMBERSK6 <XXREAL-0R3 r1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies r1 <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies (( ex r be RealXREAL-0M1 st  ex t be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & 0NUMBERSK6 <XXREAL-0R3 t) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies t <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    assume Given: " ex r be RealXREAL-0M1 st  ex t be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & 0NUMBERSK6 <XXREAL-0R3 t) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies t <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r t where
      [ty]:"r be RealXREAL-0M1" "t be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r"and A4: "0NUMBERSK6 <XXREAL-0R3 t"and A5: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies t <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5"
        and A7: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
        using A3 A6 A7 limfunc3_th_7 sorry
      have A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A8 limfunc3_lm_2 sorry
      have A11: "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A8 limfunc3_lm_2 sorry
      have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have A12: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
        using A8 sorry
      then have A13: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using limfunc3_lm_2 sorry
      have A14: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2"
        using A12 limfunc3_lm_2 sorry
      have A15: "0NUMBERSK6 <XXREAL-0R3 t & ( for n be NatNAT-1M1 holds t <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n)"
      proof(rule conjMI,rule ballI)
        show "0NUMBERSK6 <XXREAL-0R3 t"
          using A4 sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have A16: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A17: "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using A9 sorry
        then have A18: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using nat_1_def_3 sorry
        have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A9 A17 sorry
        then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
          using A18 sorry
        then have A19: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_2 sorry
        have A20: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {TARSKIK1 x0}"
          using A12 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A19 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          using A3 limfunc3_th_4 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
          using A14 A20 xboole_0_def_4 sorry
        then have "t <=XXREAL-0R1 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A5 sorry
        thus "t <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A14 funct_2_th_108 A16 sorry
      qed "sorry"
      have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
        using A6 A7 seq_4_th_20 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A6 A13 sorry
      then have A21: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A15 limfunc1_th_22 sorry
      have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A12 limfunc3_lm_2 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A11 rfunct_2_th_8 sorry
      also have "... = (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A10 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A21 limfunc1_th_7 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_18:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f is-divergent-to+infty-inLIMFUNC3R2 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0) & (f is-divergent-to+infty-inLIMFUNC3R2 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0)) & (f is-divergent-to-infty-inLIMFUNC3R3 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0)) & (f is-divergent-to-infty-inLIMFUNC3R3 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0)"
proof-
  have " for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-divergent-to+infty-inLIMFUNC3R2 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0) & ((f is-divergent-to+infty-inLIMFUNC3R2 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0) & ((f is-divergent-to-infty-inLIMFUNC3R3 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0) & (f is-divergent-to-infty-inLIMFUNC3R3 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-divergent-to+infty-inLIMFUNC3R2 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
    proof(rule impMI ,rule impI)
      assume A1: "f is-divergent-to+infty-inLIMFUNC3R2 x0"
        and A2: "r >XXREAL-0R4 0NUMBERSK6"
      have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & ( for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"
      proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        proof-
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar49 be RealXREAL-0M1 st  ex tVar50 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar49 &  not tVar49 <XXREAL-0R3 x0) & tVar49 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar50 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar50) & tVar50 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume A3: "r1 <XXREAL-0R3 x0"
              and A4: "x0 <XXREAL-0R3 r2"
            obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A5: "r1 <XXREAL-0R3 g1"and A6: "g1 <XXREAL-0R3 x0"and A7: "g1 inHIDDENR3 domRELAT-1K1 f"and A8: "g2 <XXREAL-0R3 r2"and A9: "x0 <XXREAL-0R3 g2"and A10: "g2 inHIDDENR3 domRELAT-1K1 f"
              using A1 A3 A4 sorry
            show " ex tVar49 be RealXREAL-0M1 st  ex tVar50 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar49 &  not tVar49 <XXREAL-0R3 x0) & tVar49 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar50 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar50) & tVar50 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            proof(rule bexI[of _ "g1"])
              show " ex tVar50 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar50 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar50) & tVar50 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              proof(rule bexI[of _ "g2"])
                show "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
                  using A5 A6 A7 A8 A9 A10 valued_1_def_5 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A11: "seq be convergentSEQ-2V5"
          and A12: "limSEQ-2K1 seq =COMPLEX1R1 x0"
          and A13: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}"
        have A14: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A13 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A1 A11 A12 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A2 limfunc1_th_13 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A14 rfunct_2_th_9 xboole_1_th_1 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
        using limfunc3_def_2 sorry
    qed
    show "f is-divergent-to+infty-inLIMFUNC3R2 x0 & r <XXREAL-0R3 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0"
    proof(rule impMI ,rule impI)
      assume A15: "f is-divergent-to+infty-inLIMFUNC3R2 x0"
        and A16: "r <XXREAL-0R3 0NUMBERSK6"
      have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & ( for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)"
      proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        proof-
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar51 be RealXREAL-0M1 st  ex tVar52 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar51 &  not tVar51 <XXREAL-0R3 x0) & tVar51 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar52 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar52) & tVar52 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume A17: "r1 <XXREAL-0R3 x0"
              and A18: "x0 <XXREAL-0R3 r2"
            obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A19: "r1 <XXREAL-0R3 g1"and A20: "g1 <XXREAL-0R3 x0"and A21: "g1 inHIDDENR3 domRELAT-1K1 f"and A22: "g2 <XXREAL-0R3 r2"and A23: "x0 <XXREAL-0R3 g2"and A24: "g2 inHIDDENR3 domRELAT-1K1 f"
              using A15 A17 A18 sorry
            show " ex tVar51 be RealXREAL-0M1 st  ex tVar52 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar51 &  not tVar51 <XXREAL-0R3 x0) & tVar51 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar52 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar52) & tVar52 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            proof(rule bexI[of _ "g1"])
              show " ex tVar52 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar52 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar52) & tVar52 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              proof(rule bexI[of _ "g2"])
                show "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
                  using A19 A20 A21 A22 A23 A24 valued_1_def_5 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A25: "seq be convergentSEQ-2V5"
          and A26: "limSEQ-2K1 seq =COMPLEX1R1 x0"
          and A27: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}"
        have A28: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A27 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          using A15 A25 A26 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A16 limfunc1_th_13 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A28 rfunct_2_th_9 xboole_1_th_1 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0"
        using limfunc3_def_3 sorry
    qed
    show "f is-divergent-to-infty-inLIMFUNC3R3 x0 & r >XXREAL-0R4 0NUMBERSK6 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0"
    proof(rule impMI ,rule impI)
      assume A29: "f is-divergent-to-infty-inLIMFUNC3R3 x0"
        and A30: "r >XXREAL-0R4 0NUMBERSK6"
      have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & ( for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2)"
      proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        proof-
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar53 be RealXREAL-0M1 st  ex tVar54 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar53 &  not tVar53 <XXREAL-0R3 x0) & tVar53 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar54 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar54) & tVar54 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume A31: "r1 <XXREAL-0R3 x0"
              and A32: "x0 <XXREAL-0R3 r2"
            obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A33: "r1 <XXREAL-0R3 g1"and A34: "g1 <XXREAL-0R3 x0"and A35: "g1 inHIDDENR3 domRELAT-1K1 f"and A36: "g2 <XXREAL-0R3 r2"and A37: "x0 <XXREAL-0R3 g2"and A38: "g2 inHIDDENR3 domRELAT-1K1 f"
              using A29 A31 A32 sorry
            show " ex tVar53 be RealXREAL-0M1 st  ex tVar54 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar53 &  not tVar53 <XXREAL-0R3 x0) & tVar53 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar54 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar54) & tVar54 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            proof(rule bexI[of _ "g1"])
              show " ex tVar54 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar54 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar54) & tVar54 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              proof(rule bexI[of _ "g2"])
                show "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
                  using A33 A34 A35 A36 A37 A38 valued_1_def_5 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
        assume A39: "seq be convergentSEQ-2V5"
          and A40: "limSEQ-2K1 seq =COMPLEX1R1 x0"
          and A41: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}"
        have A42: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A41 valued_1_def_5 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A29 A39 A40 sorry
        then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A30 limfunc1_th_14 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
          using A42 rfunct_2_th_9 xboole_1_th_1 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to-infty-inLIMFUNC3R3 x0"
        using limfunc3_def_3 sorry
    qed
    assume A43: "f is-divergent-to-infty-inLIMFUNC3R3 x0"
      and A44: "r <XXREAL-0R3 0NUMBERSK6"
    have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))) & ( for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      proof-
        have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar55 be RealXREAL-0M1 st  ex tVar56 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar55 &  not tVar55 <XXREAL-0R3 x0) & tVar55 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar56 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar56) & tVar56 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          fix r2 assume [ty]: "r2 be RealXREAL-0M1"
          assume A45: "r1 <XXREAL-0R3 x0"
            and A46: "x0 <XXREAL-0R3 r2"
          obtain g1 g2 where
            [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
            A47: "r1 <XXREAL-0R3 g1"and A48: "g1 <XXREAL-0R3 x0"and A49: "g1 inHIDDENR3 domRELAT-1K1 f"and A50: "g2 <XXREAL-0R3 r2"and A51: "x0 <XXREAL-0R3 g2"and A52: "g2 inHIDDENR3 domRELAT-1K1 f"
            using A43 A45 A46 sorry
          show " ex tVar55 be RealXREAL-0M1 st  ex tVar56 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar55 &  not tVar55 <XXREAL-0R3 x0) & tVar55 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar56 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar56) & tVar56 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          proof(rule bexI[of _ "g1"])
            show " ex tVar56 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not tVar56 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar56) & tVar56 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            proof(rule bexI[of _ "g2"])
              show "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
                using A47 A48 A49 A50 A51 A52 valued_1_def_5 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A53: "seq be convergentSEQ-2V5"
        and A54: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A55: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}"
      have A56: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A55 valued_1_def_5 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
        using A43 A53 A54 sorry
      then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A44 limfunc1_th_14 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
        using A56 rfunct_2_th_9 xboole_1_th_1 sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
      using limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_19:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
  proof(rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0"
    have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
    proof-
      show "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
      proof-
        have cases: "f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0"
          using A1 sorry
        have case1: "f is-divergent-to+infty-inLIMFUNC3R2 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
        proof(rule impI)
          assume A2: "f is-divergent-to+infty-inLIMFUNC3R2 x0"
          have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f \\SUBSET-1K6 {TARSKIK1 x0}) implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          proof(rule ballI,rule impMI ,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A4: "seq be convergentSEQ-2V5"
              and A5: "limSEQ-2K1 seq =COMPLEX1R1 x0"
              and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f \\SUBSET-1K6 {TARSKIK1 x0}"
            have A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
              using A6 valued_1_def_11 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A2 A4 A5 sorry
            then have A8: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) be divergent-to+inftyLIMFUNC1V1"
              using limfunc1_th_25 sorry
            have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
              using A7 xboole_1_th_1 sorry
            thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A8 rfunct_2_th_10 sorry
          qed "sorry"
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume A9: "r1 <XXREAL-0R3 x0"
              and A10: "x0 <XXREAL-0R3 r2"
            obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A11: "r1 <XXREAL-0R3 g1"and A12: "g1 <XXREAL-0R3 x0"and A13: "g1 inHIDDENR3 domRELAT-1K1 f"and A14: "g2 <XXREAL-0R3 r2"and A15: "x0 <XXREAL-0R3 g2"and A16: "g2 inHIDDENR3 domRELAT-1K1 f"
              using A2 A9 A10 sorry
            show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "g1"])
              show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
              proof(rule bexI[of _ "g2"])
                show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
                  using A11 A12 A13 A14 A15 A16 valued_1_def_11 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
            using A3 sorry
        qed
        have case2: "f is-divergent-to-infty-inLIMFUNC3R3 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
        proof(rule impI)
          assume A17: "f is-divergent-to-infty-inLIMFUNC3R3 x0"
          have A18: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f \\SUBSET-1K6 {TARSKIK1 x0}) implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
          proof(rule ballI,rule impMI ,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
            assume A19: "seq be convergentSEQ-2V5"
              and A20: "limSEQ-2K1 seq =COMPLEX1R1 x0"
              and A21: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f \\SUBSET-1K6 {TARSKIK1 x0}"
            have A22: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
              using A21 valued_1_def_11 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
              using A17 A19 A20 sorry
            then have A23: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) be divergent-to+inftyLIMFUNC1V1"
              using limfunc1_th_25 sorry
            have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
              using A22 xboole_1_th_1 sorry
            thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A23 rfunct_2_th_10 sorry
          qed "sorry"
          have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix r1 assume [ty]: "r1 be RealXREAL-0M1"
            fix r2 assume [ty]: "r2 be RealXREAL-0M1"
            assume A24: "r1 <XXREAL-0R3 x0"
              and A25: "x0 <XXREAL-0R3 r2"
            obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A26: "r1 <XXREAL-0R3 g1"and A27: "g1 <XXREAL-0R3 x0"and A28: "g1 inHIDDENR3 domRELAT-1K1 f"and A29: "g2 <XXREAL-0R3 r2"and A30: "x0 <XXREAL-0R3 g2"and A31: "g2 inHIDDENR3 domRELAT-1K1 f"
              using A17 A24 A25 sorry
            show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "g1"])
              show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
              proof(rule bexI[of _ "g2"])
                show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
                  using A26 A27 A28 A29 A30 A31 valued_1_def_11 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
            using A18 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-divergent-to+infty-inLIMFUNC3R2 x0"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_20:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-decreasingVALUED-0V11 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-increasingVALUED-0V12) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-decreasingVALUED-0V11 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-increasingVALUED-0V12) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1) implies (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-decreasingVALUED-0V11 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-increasingVALUED-0V12) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-decreasingVALUED-0V11"and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-increasingVALUED-0V12"and A3: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1"and A4: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1"
       sorry
    assume A5: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    then have " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)"
      using limfunc3_th_8 sorry
    then have A6: "f is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      using A2 A4 limfunc2_th_29 sorry
    have " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
      using A5 limfunc3_th_8 sorry
    then have "f is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      using A1 A3 limfunc2_th_25 sorry
    thus "f is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A6 limfunc3_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_21:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (((0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be increasingVALUED-0V9) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be decreasingVALUED-0V10) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-aboveSEQ-2V1) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-aboveSEQ-2V1) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
  using limfunc3_th_20 sorry

mtheorem limfunc3_th_22:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-increasingVALUED-0V12 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-decreasingVALUED-0V11) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-increasingVALUED-0V12 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-decreasingVALUED-0V11) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) implies (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex r be RealXREAL-0M1 st ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-increasingVALUED-0V12 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-decreasingVALUED-0V11) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be non-increasingVALUED-0V12"and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be non-decreasingVALUED-0V11"and A3: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2"and A4: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2"
       sorry
    assume A5: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    then have " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)"
      using limfunc3_th_8 sorry
    then have A6: "f is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      using A2 A4 limfunc2_th_31 sorry
    have " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
      using A5 limfunc3_th_8 sorry
    then have "f is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      using A1 A3 limfunc2_th_27 sorry
    thus "f is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A6 limfunc3_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_23:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st (((0NUMBERSK6 <XXREAL-0R3 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be decreasingVALUED-0V10) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be increasingVALUED-0V9) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) be bounded-belowSEQ-2V2) &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be bounded-belowSEQ-2V2) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
  using limfunc3_th_22 sorry

mtheorem limfunc3_th_24:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies (( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
      and A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    assume Given: " ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r"and A4: "domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"and A5: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
        using A2 sorry
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5"
        and A7: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
        using A3 A6 A7 limfunc3_th_7 sorry
      have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have A11: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A8 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A12: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A13: "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using A9 sorry
        then have A14: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using nat_1_def_3 sorry
        have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A9 A13 sorry
        then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
          using A14 sorry
        then have A15: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_2 sorry
        have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
          using A11 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A15 xboole_0_def_5 sorry
        thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          using A3 A12 limfunc3_th_4 sorry
      qed "sorry"
      then have A16: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
         sorry
      have A17: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
        using A8 xboole_1_th_1 sorry
      then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f"
        using A10 sorry
      then have A18: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A16 xboole_1_th_19 sorry
      then have A19: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A4 sorry
      have A20: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A21: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A5 A18 sorry
        then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A19 funct_2_th_108 xboole_1_th_18 A21 sorry
        thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A17 A10 funct_2_th_108 xboole_1_th_1 A21 sorry
      qed "sorry"
      have A22: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1"
        using A19 xboole_1_th_18 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A23: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then have " not x inHIDDENR3 {TARSKIK1 x0}"
          using A11 xboole_0_def_5 sorry
        thus "x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
          using A22 A23 xboole_0_def_5 sorry
      qed "sorry"
      then have A24: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
         sorry
      have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
        using A6 A7 seq_4_th_20 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A1 A6 A24 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to+inftyLIMFUNC1V1"
        using A20 limfunc1_th_42 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to+inftyLIMFUNC1V1"
        using A8 valued_0_th_27 xboole_1_th_1 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using limfunc1_th_7 sorry
    qed "sorry"
    thus "f is-divergent-to+infty-inLIMFUNC3R2 x0"
      using limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_25:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) implies (( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
      and A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    assume Given: " ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r"and A4: "domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"and A5: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)) & ( for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
        using A2 sorry
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A6: "s be convergentSEQ-2V5"
        and A7: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
        using A3 A6 A7 limfunc3_th_7 sorry
      have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      then have A11: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A8 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A12: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
          using funct_2_th_113 sorry
        have A13: "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using A9 sorry
        then have A14: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using nat_1_def_3 sorry
        have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A9 A13 sorry
        then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
          using A14 sorry
        then have A15: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_2 sorry
        have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
          using A11 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A15 xboole_0_def_5 sorry
        thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          using A3 A12 limfunc3_th_4 sorry
      qed "sorry"
      then have A16: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
         sorry
      have A17: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
        using A8 xboole_1_th_1 sorry
      then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f"
        using A10 sorry
      then have A18: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A16 xboole_1_th_19 sorry
      then have A19: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A4 sorry
      have A20: " for n be NatNAT-1M1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A21: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A5 A18 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A17 A10 funct_2_th_108 xboole_1_th_1 A21 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A19 funct_2_th_108 xboole_1_th_18 A21 sorry
      qed "sorry"
      have A22: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1"
        using A19 xboole_1_th_18 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A23: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        then have " not x inHIDDENR3 {TARSKIK1 x0}"
          using A11 xboole_0_def_5 sorry
        thus "x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
          using A22 A23 xboole_0_def_5 sorry
      qed "sorry"
      then have A24: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
         sorry
      have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
        using A6 A7 seq_4_th_20 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
        using A1 A6 A24 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be divergent-to-inftyLIMFUNC1V2"
        using A20 limfunc1_th_43 sorry
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be divergent-to-inftyLIMFUNC1V2"
        using A8 valued_0_th_27 xboole_1_th_1 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using limfunc1_th_7 sorry
    qed "sorry"
    thus "f is-divergent-to-infty-inLIMFUNC3R3 x0"
      using limfunc3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_26:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to+infty-inLIMFUNC3R2 x0 implies (( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to+infty-inLIMFUNC3R2 x0"
    assume Given: " ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A2: "0NUMBERSK6 <XXREAL-0R3 r"and A3: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have A5: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ =XBOOLE-0R4 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
      using A3 xboole_1_th_18 xboole_1_th_28 sorry
    have A6: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
      using A3 xboole_1_th_18 xboole_1_th_28 sorry
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
      using A2 A3 limfunc3_th_5 xboole_1_th_18 sorry
    thus "f is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A1 A2 A4 A5 A6 limfunc3_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_27:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-divergent-to-infty-inLIMFUNC3R3 x0 implies (( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)) implies f is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-divergent-to-infty-inLIMFUNC3R3 x0"
    assume Given: " ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A2: "0NUMBERSK6 <XXREAL-0R3 r"and A3: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1"and A4: " for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f .FUNCT-1K1 g <=XXREAL-0R1 f1 .FUNCT-1K1 g"
       sorry
    have A5: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ =XBOOLE-0R4 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
      using A3 xboole_1_th_18 xboole_1_th_28 sorry
    have A6: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
      using A3 xboole_1_th_18 xboole_1_th_28 sorry
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
      using A2 A3 limfunc3_th_5 xboole_1_th_18 sorry
    thus "f is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A1 A2 A4 A5 A6 limfunc3_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef limfunc3_def_4 ("limLIMFUNC3K1'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"assume f is-convergent-inLIMFUNC3R1 x0 func limLIMFUNC3K1(f,x0) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
proof-
  (*existence*)
    show "f is-convergent-inLIMFUNC3R1 x0 implies ( ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it)"
    proof(rule impI)
      assume Assume: "f is-convergent-inLIMFUNC3R1 x0"
      have A1: "f is-convergent-inLIMFUNC3R1 x0"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st  for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it"
        using A1 sorry
    qed
  (*uniqueness*)
    show "f is-convergent-inLIMFUNC3R1 x0 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f is-convergent-inLIMFUNC3R1 x0"
      have A1: "f is-convergent-inLIMFUNC3R1 x0"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it1) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2"
      proof-
        have " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g1) & ( for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2) implies g1 =HIDDENR1 g2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 Lamb2 & Lamb2 <XXREAL-0R3 x0) & Lamb2 inHIDDENR3 domRELAT-1K1 f"
          have A2: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A3: "x0 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"
              using xreal_1_th_8 sorry
            have "x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
              using limfunc3_lm_3 sorry
            then obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A4: "x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1"and A5: "g1 <XXREAL-0R3 x0"and A6: "g1 inHIDDENR3 domRELAT-1K1 f"and "g2 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"and "x0 <XXREAL-0R3 g2"and "g2 inHIDDENR3 domRELAT-1K1 f"
              using A1 A3 sorry
            have 
              [ty]:"g1 be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex g1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f"
            proof(rule bexI[of _ "g1"])
              show "(x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f"
                using A4 A5 A6 sorry
            qed "sorry"
          qed "sorry"
          obtain s where
            [ty]:"s be Real-SequenceSEQ-1M1" and 
            A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A2 sorry
          have A8: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
            using A7 limfunc3_th_6 sorry
          have A9: "limSEQ-2K1 s =COMPLEX1R1 x0"
            using A7 limfunc3_th_6 sorry
          fix g1 assume [ty]: "g1 be RealXREAL-0M1"
          fix g2 assume [ty]: "g2 be RealXREAL-0M1"
          assume A10: " for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g1"
            and A11: " for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x0) & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0} implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 g2"
          have A12: "s be convergentSEQ-2V5"
            using A7 limfunc3_th_6 sorry
          then have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g1"
            using A9 A8 A10 sorry
          thus "g1 =HIDDENR1 g2"
            using A12 A9 A8 A11 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem limfunc3_th_28:
" for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies (limLIMFUNC3K1(f,x0) =COMPLEX1R1 g iff ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))))"
proof-
  have " for g be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies (limLIMFUNC3K1(f,x0) =COMPLEX1R1 g implies ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))) & (( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))) implies limLIMFUNC3K1(f,x0) =COMPLEX1R1 g)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
    show "limLIMFUNC3K1(f,x0) =COMPLEX1R1 g implies ( for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1)))"
    proof-
      have "limLIMFUNC3K1(f,x0) =COMPLEX1R1 g & ( ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .|))) implies  False "
      proof(rule impMI ,rule impI)
        assume A2: "limLIMFUNC3K1(f,x0) =COMPLEX1R1 g"
          and A3: " ex g1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g1 & ( for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .|))"
        obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A4: "0NUMBERSK6 <XXREAL-0R3 g1"and A5: " for g2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g2 implies ( ex r1 be RealXREAL-0M1 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f) & g1 <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .|)"
          using A3 sorry
        let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 Lamb2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) & Lamb2 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
        have A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st ?X(n,r1)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar62 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar62 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar62 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar62 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 tVar62 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            obtain r1 where
              [ty]:"r1 be RealXREAL-0M1" and 
              A7: "?X(n,r1)"
              using A5 xreal_1_th_139 sorry
            have 
              [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex tVar62 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar62 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 tVar62 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & tVar62 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 tVar62 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
            proof(rule bexI[of _ "r1"])
              show "((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) & r1 inHIDDENR3 domRELAT-1K1 f) &  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| >=XXREAL-0R2 g1"
                using A7 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A6 sorry
        have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A8 limfunc3_th_2 sorry
        have A10: "limSEQ-2K1 s =COMPLEX1R1 x0"
          using A8 limfunc3_th_2 sorry
        have A11: "s be convergentSEQ-2V5"
          using A8 limfunc3_th_2 sorry
        then have A12: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
          using A1 A2 A10 A9 limfunc3_def_4 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
          using A1 A11 A10 A9 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A13: " for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A4 A12 seq_2_def_7 sorry
        have A14: " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 n -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A13 sorry
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
          using A8 limfunc3_th_2 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 n) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A14 funct_2_th_108 A15 sorry
        thus " False "
          using A8 A15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A16: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex g2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g2 & ( for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1))"
    have 
      [ty]:"g be RealXREAL-0M1"
       sorry
    have " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A17: "s be convergentSEQ-2V5"
        and A18: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A19: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      have A20: " for g1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g1 implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1)"
      proof(rule ballI,rule impI)
        fix g1 assume [ty]: "g1 be RealXREAL-0M1"
        assume A21: "0NUMBERSK6 <XXREAL-0R3 g1"
        obtain g2 where
          [ty]:"g2 be RealXREAL-0M1" and 
          A22: "0NUMBERSK6 <XXREAL-0R3 g2"and A23: " for r1 be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 r1 .| <XXREAL-0R3 g2) & r1 inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
          using A16 A21 sorry
        obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A24: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 k implies (0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| &  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k .| <XXREAL-0R3 g2) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k inTARSKIR2 domRELAT-1K1 f"
          using A17 A18 A19 A22 limfunc3_th_3 sorry
        have 
          [ty]:"n be NatNAT-1M1"
           sorry
        show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A25: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume A26: "n <=XXREAL-0R1 k"
          then have A27: " |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .| <XXREAL-0R3 g2"
            using A24 A25 sorry
          have A28: "s .FUNCT-1K1 k inTARSKIR2 domRELAT-1K1 f"
            using A24 A26 A25 sorry
          have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x0 -XCMPLX-0K6 s .FUNCT-1K1 k .|"
            using A24 A26 A25 sorry
          then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 k) -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A23 A27 A28 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 g .| <XXREAL-0R3 g1"
            using A19 funct_2_th_108 xboole_1_th_1 A25 sorry
        qed "sorry"
      qed "sorry"
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using seq_2_def_6 sorry
      thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 g"
        using A20 seq_2_def_7 sorry
    qed "sorry"
    thus "limLIMFUNC3K1(f,x0) =COMPLEX1R1 g"
      using A1 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_29:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies (((f is-left-convergent-inLIMFUNC2R1 x0 & f is-right-convergent-inLIMFUNC2R4 x0) & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies f is-left-convergent-inLIMFUNC2R1 x0 & (f is-right-convergent-inLIMFUNC2R4 x0 & ((lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
    have A2: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A3: "s be convergentSEQ-2V5"
        and A4: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A5: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A5 limfunc3_th_1 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
        using A1 A3 A4 limfunc3_def_4 sorry
    qed "sorry"
    have A6: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A7: "s be convergentSEQ-2V5"
        and A8: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A9 limfunc3_th_1 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
        using A1 A7 A8 limfunc3_def_4 sorry
    qed "sorry"
    have A10: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
      using A1 sorry
    then have " for r be RealXREAL-0M1 holds r <XXREAL-0R3 x0 implies ( ex g be RealXREAL-0M1 st (r <XXREAL-0R3 g & g <XXREAL-0R3 x0) & g inHIDDENR3 domRELAT-1K1 f)"
      using limfunc3_th_8 sorry
    thus "f is-left-convergent-inLIMFUNC2R1 x0"
      using A6 limfunc2_def_1 sorry
    then have A11: "lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
      using A6 limfunc2_def_7 sorry
    have " for r be RealXREAL-0M1 holds x0 <XXREAL-0R3 r implies ( ex g be RealXREAL-0M1 st (g <XXREAL-0R3 r & x0 <XXREAL-0R3 g) & g inHIDDENR3 domRELAT-1K1 f)"
      using A10 limfunc3_th_8 sorry
    thus "f is-right-convergent-inLIMFUNC2R4 x0"
      using A2 limfunc2_def_4 sorry
    thus "(lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)"
      using A11 A2 limfunc2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_30:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-left-convergent-inLIMFUNC2R1 x0 & f is-right-convergent-inLIMFUNC2R4 x0) & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0) implies (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-left-convergent-inLIMFUNC2R1 x0 & (f is-right-convergent-inLIMFUNC2R4 x0 & lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)) implies f is-convergent-inLIMFUNC3R1 x0 & (limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-left-convergent-inLIMFUNC2R1 x0"
      and A2: "f is-right-convergent-inLIMFUNC2R4 x0"
      and A3: "lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)"
    have A4: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A5: "s be convergentSEQ-2V5"
        and A6: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A7: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
      proof-
        show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
        proof-
          have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0)"
             sorry
          have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
          proof(rule impI,rule conjMI)
            assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
            then obtain k where
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
               sorry
            have A9: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
              using A7 xboole_1_th_1 sorry
            have A10: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                then obtain n where
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A11: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                  using funct_2_th_113 sorry
                have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0"
                  using A8 nat_1_th_12 sorry
                then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
                   sorry
                then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 left-open-halflineLIMFUNC1K1 x0"
                  using xxreal_1_th_229 sorry
                then have A12: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 x0"
                  using A11 nat_1_def_3 sorry
                have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
                  using valued_0_th_28 sorry
                then have "x inHIDDENR3 rngFUNCT-1K2 s"
                  using A11 nat_1_def_3 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                  using A9 A12 xboole_0_def_4 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                using tarski_def_3 sorry
            qed
            have A13: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A7 valued_0_th_27 xboole_1_th_1 sorry
            have A14: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
              using A5 A6 seq_4_th_20 sorry
            then have A15: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
              using A1 A3 A5 A10 limfunc2_def_7 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
              using A13 seq_4_th_21 sorry
            have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
              using A1 A5 A14 A10 limfunc2_def_7 sorry
            thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
              using A15 A13 seq_4_th_22 sorry
          qed
          have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
          proof(rule impI)
            assume A16: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0"
            have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
            proof-
              show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
              proof-
                have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                   sorry
                have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
                proof(rule impI,rule conjMI)
                  assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  then obtain k where
                    [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A17: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                     sorry
                  have A18: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
                    using A7 xboole_1_th_1 sorry
                  have A19: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A20: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "x0 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
                        using A17 nat_1_th_12 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
                         sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 right-open-halflineLIMFUNC1K4 x0"
                        using xxreal_1_th_230 sorry
                      then have A21: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 x0"
                        using A20 nat_1_def_3 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have "x inHIDDENR3 rngFUNCT-1K2 s"
                        using A20 nat_1_def_3 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                        using A18 A21 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                      using tarski_def_3 sorry
                  qed
                  have A22: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
                    using A7 valued_0_th_27 xboole_1_th_1 sorry
                  have A23: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
                    using A5 A6 seq_4_th_20 sorry
                  then have A24: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
                    using A2 A3 A5 A19 limfunc2_def_8 sorry
                  thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
                    using A22 seq_4_th_21 sorry
                  have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
                    using A2 A3 A5 A23 A19 limfunc2_def_8 sorry
                  thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
                    using A24 A22 seq_4_th_22 sorry
                qed
                have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
                proof(rule impI,rule conjMI)
                  assume A25: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & x0 >=XXREAL-0R2 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  let ?GR = "lim-leftLIMFUNC2K1(f,x0)"
                  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb1 =XBOOLE-0R4 n & Lamb2 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k)"
                  let ?X3 = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. ?P(Lamb2,Lamb3)"
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                  have A26: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                  proof(rule ballI)
                    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain n where
                      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A27: "k <=XXREAL-0R1 n"and A28: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 x0"
                      using A25 sorry
                    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                    proof(rule bexI[of _ "n"],rule conjMI)
                      show "k <=XXREAL-0R1 n"
                        using A27 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                        using A7 xboole_0_def_5 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      thus "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                        using A28 xxreal_0_th_1 sorry
                    qed "sorry"
                  qed "sorry"
                  then have " ex m1 be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 m1 & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m1 <XXREAL-0R3 x0"
                     sorry
                  then have A29: " ex m be NatNAT-1M1 st ?X(m)"
                     sorry
                  obtain M where
                    [ty]:"M be NatNAT-1M1" and 
                    A30: "?X(M) & ( for n be NatNAT-1M1 holds ?X(n) implies M <=XXREAL-0R1 n)"
                    using nat_1_sch_5 A29 sorry
                  obtain M9 where 
                    [ty]:"M9 be ElementSUBSET-1M1-of NATNUMBERSK1" and M9Def:"M9 = M"
                    using ordinal1_def_12 sorry
                  have A31: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain m where
                      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A32: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"and A33: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                      using A26 sorry
                    show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                    proof(rule bexI[of _ "m"])
                      show "n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0"
                        using A32 A33 nat_1_th_13 sorry
                    qed "sorry"
                  qed "sorry"
                  have A34: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X3(n,x,y)"
                  proof-
                    have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar66 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar66 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar66 =XBOOLE-0R4 nc & tVar66 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                    proof(rule ballI,rule ballI)
                      fix n assume [ty]: "n be NatNAT-1M1"
                      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                      let ?X = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                      have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(m)"
                        using A31 sorry
                      then have A35: " ex m be NatNAT-1M1 st ?X(m)"
                         sorry
                      obtain l where
                        [ty]:"l be NatNAT-1M1" and 
                        A36: "?X(l) & ( for k be NatNAT-1M1 holds ?X(k) implies l <=XXREAL-0R1 k)"
                        using nat_1_sch_5 A35 sorry
                      show " ex tVar66 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar66 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar66 =XBOOLE-0R4 nc & tVar66 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                      proof(rule bexI[of _ "l"])
                        have "l inTARSKIR2 NATNUMBERSK1"
                          using ordinal1_def_12 sorry
                        thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds l =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <XXREAL-0R3 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0 implies m <=XXREAL-0R1 k))"
                          using A36 sorry
                      qed "sorry"
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  obtain F where
                    [ty]:"F be sequenceNAT-1M2-of NATNUMBERSK1" and 
                    A37: "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M9 & ( for n be NatNAT-1M1 holds ?X3(n,F .RECDEF-1K1 n,F .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                    using recdef_1_sch_2 A34 sorry
                  have A38: "rngFUNCT-1K2 F c=TARSKIR1 NATNUMBERSK1"
                    using relat_1_def_19 sorry
                  then have A39: "rngFUNCT-1K2 F c=TARSKIR1 REALNUMBERSK2"
                    using numbers_th_19 sorry
                  have A40: "domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1"
                    using funct_2_def_1 sorry
                  then have 
                    [ty]:"F be Real-SequenceSEQ-1M1"
                    using A39 relset_1_th_4 sorry
                  have A41: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    have "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 F"
                      using A40 funct_1_def_3 sorry
                    thus "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A38 sorry
                  qed "sorry"
                  have " for n be NatNAT-1M1 holds F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI)
                    fix n assume [ty]: "n be NatNAT-1M1"
                    have A42: "n inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have A43: "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A41 sorry
                    have "F .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A41 A42 sorry
                    thus "F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                      using A37 A43 sorry
                  qed "sorry"
                  then have 
                    [ty]:"F be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
                    using seqm_3_def_6 sorry
                  have A44: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s"
                    using valued_0_def_17 sorry
                  then have "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 rngFUNCT-1K2 s"
                    using valued_0_th_21 sorry
                  then have A45: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
                    using A7 sorry
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                  have A46: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 n)"
                  proof-
                    have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-1K1 n <XXREAL-0R3 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
                    proof(rule impI)
                      assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
                      then have A47: " ex n be NatNAT-1M1 st ?X(n)"
                         sorry
                      obtain M1 where
                        [ty]:"M1 be NatNAT-1M1" and 
                        A48: "?X(M1) & ( for n be NatNAT-1M1 holds ?X(n) implies M1 <=XXREAL-0R1 n)"
                        using nat_1_sch_5 A47 sorry
                      let ?X = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 M1 & s .FUNCT-1K1 Lamb1 <XXREAL-0R3 x0) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                      have A49: " ex n be NatNAT-1M1 st ?X(n)"
                      proof-
                        have " ex tVar67 be NatNAT-1M1 st tVar67 <XXREAL-0R3 M1 & (s .FUNCT-1K1 tVar67 <XXREAL-0R3 x0 & ( ex tVar68 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar68 =COMPLEX1R1 tVar67))"
                        proof-
                          show " ex tVar67 be NatNAT-1M1 st tVar67 <XXREAL-0R3 M1 & (s .FUNCT-1K1 tVar67 <XXREAL-0R3 x0 & ( ex tVar68 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar68 =COMPLEX1R1 tVar67))"
                          proof(rule bexI[of _ "M"],rule conjMI,rule conjMI)
                            have A50: "M <>HIDDENR2 M1"
                              using A37 A48 sorry
                            have "M <=XXREAL-0R1 M1"
                              using A30 A48 sorry
                            thus "M <XXREAL-0R3 M1"
                              using A50 xxreal_0_th_1 sorry
                            show "s .FUNCT-1K1 M <XXREAL-0R3 x0"
                              using A30 sorry
                            show " ex tVar68 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar68 =COMPLEX1R1 M"
                            proof(rule bexI[of _ "0NUMBERSK6"])
                              show "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M"
                                using A37 sorry
                            qed "sorry"
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have A51: " for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 M1"
                         sorry
                      obtain MX where
                        [ty]:"MX be NatNAT-1M1" and 
                        A52: "?X(MX) & ( for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 MX)"
                        using nat_1_sch_6 A51 A49 sorry
                      have A53: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds MX <XXREAL-0R3 k & k <XXREAL-0R3 M1 implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >=XXREAL-0R2 x0"
                      proof-
                        have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (MX <XXREAL-0R3 k & k <XXREAL-0R3 M1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0) implies  False "
                        proof(rule impI)
                          assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (MX <XXREAL-0R3 k & k <XXREAL-0R3 M1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0"
                          then obtain k where
                            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                            A54: "MX <XXREAL-0R3 k"and A55: "k <XXREAL-0R3 M1"and A56: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <XXREAL-0R3 x0"
                             sorry
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k)"
                                 sorry
                              have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                              proof(rule impI)
                                assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k"
                                thus " False "
                                  using A52 A54 A55 A56 sorry
                              qed
                              have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                              proof(rule impI)
                                assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k"
                                thus " False "
                                  using A48 A55 A56 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      obtain m where
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A57: "F .RECDEF-1K1 m =COMPLEX1R1 MX"
                        using A52 sorry
                      have "M1 inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      then have A58: "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 M1"
                        using A37 A48 A52 A57 sorry
                      have A59: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 x0"
                        using A37 A57 sorry
                      have A60: "MX <XXREAL-0R3 F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                        using A37 A57 sorry
                      have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1 implies  False "
                      proof(rule impI)
                        assume "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1"
                        then have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 M1"
                          using A58 xxreal_0_th_1 sorry
                        thus " False "
                          using A53 A60 A59 sorry
                      qed
                      thus " False "
                        using A48 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                  have A61: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                  proof(rule ballI)
                    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain n where
                      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A62: "k <=XXREAL-0R1 n"and A63: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 x0"
                      using A16 sorry
                    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                    proof(rule bexI[of _ "n"],rule conjMI)
                      show "k <=XXREAL-0R1 n"
                        using A62 sorry
                      have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                        using A7 xboole_0_def_5 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      thus "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                        using A63 xxreal_0_th_1 sorry
                    qed "sorry"
                  qed "sorry"
                  then have " ex mn be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 mn & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> mn >XXREAL-0R4 x0"
                     sorry
                  then have A64: " ex m be NatNAT-1M1 st ?X(m)"
                     sorry
                  obtain N where
                    [ty]:"N be NatNAT-1M1" and 
                    A65: "?X(N) & ( for n be NatNAT-1M1 holds ?X(n) implies N <=XXREAL-0R1 n)"
                    using nat_1_sch_5 A64 sorry
                  let ?X = "\<lambda>Lamb1. (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 Lamb1 <XXREAL-0R3 x0"
                  have A66: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
                  proof-
                    have " for k be NatNAT-1M1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <XXREAL-0R3 x0 implies (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
                    proof(rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      assume "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <XXREAL-0R3 x0"
                      have "?P(F .RECDEF-1K1 k,F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                        using A37 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 x0"
                         sorry
                      thus "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
                        using funct_2_th_15 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have A67: "?X(0NUMBERSK6)"
                    using A30 A37 funct_2_th_15 sorry
                  have A68: " for k be NatNAT-1M1 holds ?X(k)"
                    using nat_1_sch_2 A67 A66 sorry
                  have A69: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A70: "x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A71: "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
                        using A68 sorry
                      then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <XXREAL-0R3 x0 }"
                        using A71 sorry
                      then have A72: "x inHIDDENR3 left-open-halflineLIMFUNC1K1 x0"
                        using xxreal_1_th_229 sorry
                      have "x inHIDDENR3 domRELAT-1K1 f"
                        using A45 A70 xboole_0_def_5 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                        using A72 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 x0)"
                      using tarski_def_3 sorry
                  qed
                  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb1 =XBOOLE-0R4 n & Lamb2 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k)"
                  let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. ?P(Lamb2,Lamb3)"
                  have A73: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F be convergentSEQ-2V5"
                    using A5 A44 seq_4_th_16 sorry
                  obtain N9 where 
                    [ty]:"N9 be ElementSUBSET-1M1-of NATNUMBERSK1" and N9Def:"N9 = N"
                    using ordinal1_def_12 sorry
                  have A74: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    obtain m where
                      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A75: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"and A76: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                      using A61 sorry
                    show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                    proof(rule bexI[of _ "m"])
                      show "n <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0"
                        using A75 A76 nat_1_th_13 sorry
                    qed "sorry"
                  qed "sorry"
                  have A77: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n,x,y)"
                  proof-
                    have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar71 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar71 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar71 =XBOOLE-0R4 nc & tVar71 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k))"
                    proof(rule ballI,rule ballI)
                      fix n assume [ty]: "n be NatNAT-1M1"
                      fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                      let ?X = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                      have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(m)"
                        using A74 sorry
                      then have A78: " ex m be NatNAT-1M1 st ?X(m)"
                         sorry
                      obtain l where
                        [ty]:"l be NatNAT-1M1" and 
                        A79: "?X(l) & ( for k be NatNAT-1M1 holds ?X(k) implies l <=XXREAL-0R1 k)"
                        using nat_1_sch_5 A78 sorry
                      show " ex tVar71 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar71 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds tVar71 =XBOOLE-0R4 nc & tVar71 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k))"
                      proof(rule bexI[of _ "l"])
                        have "l inTARSKIR2 NATNUMBERSK1"
                          using ordinal1_def_12 sorry
                        thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds l =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m >XXREAL-0R4 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0 implies m <=XXREAL-0R1 k))"
                          using A79 sorry
                      qed "sorry"
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  obtain G where
                    [ty]:"G be sequenceNAT-1M2-of NATNUMBERSK1" and 
                    A80: "G .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 N9 & ( for n be NatNAT-1M1 holds ?X(n,G .RECDEF-1K1 n,G .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                    using recdef_1_sch_2 A77 sorry
                  have A81: "rngFUNCT-1K2 G c=TARSKIR1 NATNUMBERSK1"
                    using relat_1_def_19 sorry
                  then have A82: "rngFUNCT-1K2 G c=TARSKIR1 REALNUMBERSK2"
                    using numbers_th_19 sorry
                  have A83: "domRELAT-1K1 G =XBOOLE-0R4 NATNUMBERSK1"
                    using funct_2_def_1 sorry
                  then have 
                    [ty]:"G be Real-SequenceSEQ-1M1"
                    using A82 relset_1_th_4 sorry
                  have A84: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    have "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 G"
                      using A83 funct_1_def_3 sorry
                    thus "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A81 sorry
                  qed "sorry"
                  have " for n be NatNAT-1M1 holds G .FUNCT-1K1 n <XXREAL-0R3 G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI)
                    fix n assume [ty]: "n be NatNAT-1M1"
                    have A85: "n inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have A86: "G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A84 sorry
                    have "G .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
                      using A84 A85 sorry
                    thus "G .FUNCT-1K1 n <XXREAL-0R3 G .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                      using A80 A86 sorry
                  qed "sorry"
                  then have 
                    [ty]:"G be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
                    using seqm_3_def_6 sorry
                  have A87: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s"
                    using valued_0_def_17 sorry
                  then have "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 rngFUNCT-1K2 s"
                    using valued_0_th_21 sorry
                  then have A88: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
                    using A7 sorry
                  have A89: "limSEQ-2K1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) =COMPLEX1R1 x0"
                    using A5 A6 A44 seq_4_th_17 sorry
                  then have A90: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
                    using A1 A73 A69 limfunc2_def_7 sorry
                  have A91: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) be convergentSEQ-2V5"
                    using A1 A3 A73 A89 A69 limfunc2_def_7 sorry
                  have A92: "s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G be convergentSEQ-2V5"
                    using A5 A87 seq_4_th_16 sorry
                  let ?X = "\<lambda>Lamb1. s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                  have A93: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0 implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 n)"
                  proof-
                    have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s .FUNCT-1K1 n >XXREAL-0R4 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
                    proof(rule impI)
                      assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
                      then have A94: " ex n be NatNAT-1M1 st ?X(n)"
                         sorry
                      obtain N1 where
                        [ty]:"N1 be NatNAT-1M1" and 
                        A95: "?X(N1) & ( for n be NatNAT-1M1 holds ?X(n) implies N1 <=XXREAL-0R1 n)"
                        using nat_1_sch_5 A94 sorry
                      let ?X = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 N1 & s .FUNCT-1K1 Lamb1 >XXREAL-0R4 x0) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                      have A96: " ex n be NatNAT-1M1 st ?X(n)"
                      proof-
                        have " ex tVar72 be NatNAT-1M1 st tVar72 <XXREAL-0R3 N1 & (s .FUNCT-1K1 tVar72 >XXREAL-0R4 x0 & ( ex tVar73 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar73 =COMPLEX1R1 tVar72))"
                        proof-
                          show " ex tVar72 be NatNAT-1M1 st tVar72 <XXREAL-0R3 N1 & (s .FUNCT-1K1 tVar72 >XXREAL-0R4 x0 & ( ex tVar73 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar73 =COMPLEX1R1 tVar72))"
                          proof(rule bexI[of _ "N"],rule conjMI,rule conjMI)
                            have A97: "N <>HIDDENR2 N1"
                              using A80 A95 sorry
                            have "N <=XXREAL-0R1 N1"
                              using A65 A95 sorry
                            thus "N <XXREAL-0R3 N1"
                              using A97 xxreal_0_th_1 sorry
                            show "s .FUNCT-1K1 N >XXREAL-0R4 x0"
                              using A65 sorry
                            show " ex tVar73 be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 tVar73 =COMPLEX1R1 N"
                            proof(rule bexI[of _ "0NUMBERSK6"])
                              show "G .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 N"
                                using A80 sorry
                            qed "sorry"
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have A98: " for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 N1"
                         sorry
                      obtain NX where
                        [ty]:"NX be NatNAT-1M1" and 
                        A99: "?X(NX) & ( for n be NatNAT-1M1 holds ?X(n) implies n <=XXREAL-0R1 NX)"
                        using nat_1_sch_6 A98 A96 sorry
                      have A100: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds NX <XXREAL-0R3 k & k <XXREAL-0R3 N1 implies s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <=XXREAL-0R1 x0"
                      proof-
                        have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (NX <XXREAL-0R3 k & k <XXREAL-0R3 N1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0) implies  False "
                        proof(rule impI)
                          assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (NX <XXREAL-0R3 k & k <XXREAL-0R3 N1) & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0"
                          then obtain k where
                            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                            A101: "NX <XXREAL-0R3 k"and A102: "k <XXREAL-0R3 N1"and A103: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k >XXREAL-0R4 x0"
                             sorry
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k)"
                                 sorry
                              have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                              proof(rule impI)
                                assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st G .RECDEF-1K1 m =COMPLEX1R1 k"
                                thus " False "
                                  using A99 A101 A102 A103 sorry
                              qed
                              have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                              proof(rule impI)
                                assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds G .RECDEF-1K1 m <>HIDDENR2 k"
                                thus " False "
                                  using A95 A102 A103 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      obtain m where
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A104: "G .RECDEF-1K1 m =COMPLEX1R1 NX"
                        using A99 sorry
                      have "N1 inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      then have A105: "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 N1"
                        using A80 A95 A99 A104 sorry
                      have A106: "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 x0"
                        using A80 A104 sorry
                      have A107: "NX <XXREAL-0R3 G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                        using A80 A104 sorry
                      have "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 N1 implies  False "
                      proof(rule impI)
                        assume "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 N1"
                        then have "G .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 N1"
                          using A105 xxreal_0_th_1 sorry
                        thus " False "
                          using A100 A107 A106 sorry
                      qed
                      thus " False "
                        using A95 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  let ?X = "\<lambda>Lamb1. (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 Lamb1 >XXREAL-0R4 x0"
                  have A108: " for k be NatNAT-1M1 holds ?X(k) implies ?X(k +NAT-1K1 \<one>\<^sub>M)"
                  proof-
                    have " for k be NatNAT-1M1 holds (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 k >XXREAL-0R4 x0 implies (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 x0"
                    proof(rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      assume "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 k >XXREAL-0R4 x0"
                      have "?P(G .RECDEF-1K1 k,G .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                        using A80 sorry
                      then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (G .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 x0"
                         sorry
                      thus "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 x0"
                        using funct_2_th_15 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have A109: "?X(0NUMBERSK6)"
                    using A65 A80 funct_2_th_15 sorry
                  have A110: " for k be NatNAT-1M1 holds ?X(k)"
                    using nat_1_sch_2 A109 A108 sorry
                  have A111: "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) implies x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume A112: "x inHIDDENR3 rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G)"
                      then obtain n where
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A113: "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                        using funct_2_th_113 sorry
                      have "(s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n >XXREAL-0R4 x0"
                        using A110 sorry
                      then have "x inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : x0 <XXREAL-0R3 g1 }"
                        using A113 sorry
                      then have A114: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 x0"
                        using xxreal_1_th_230 sorry
                      have "x inHIDDENR3 domRELAT-1K1 f"
                        using A88 A112 xboole_0_def_5 sorry
                      thus "x inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                        using A114 xboole_0_def_4 sorry
                    qed "sorry"
                    thus "rngFUNCT-1K2 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 x0)"
                      using tarski_def_3 sorry
                  qed
                  have A115: "limSEQ-2K1 (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) =COMPLEX1R1 x0"
                    using A5 A6 A87 seq_4_th_17 sorry
                  then have A116: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
                    using A2 A3 A92 A111 limfunc2_def_8 sorry
                  have A117: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) be convergentSEQ-2V5"
                    using A2 A3 A92 A115 A111 limfunc2_def_8 sorry
                  have A118: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r)"
                  proof(rule ballI,rule impI)
                    fix r assume [ty]: "r be RealXREAL-0M1"
                    assume A119: "0NUMBERSK6 <XXREAL-0R3 r"
                    then obtain n1 where
                      [ty]:"n1 be NatNAT-1M1" and 
                      A120: " for k be NatNAT-1M1 holds n1 <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) .FUNCT-1K1 k -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                      using A91 A90 seq_2_def_7 sorry
                    obtain n2 where
                      [ty]:"n2 be NatNAT-1M1" and 
                      A121: " for k be NatNAT-1M1 holds n2 <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) .FUNCT-1K1 k -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                      using A117 A116 A119 seq_2_def_7 sorry
                    obtain n where 
                      [ty]:"n be NatNAT-1M1" and nDef:"n = maxNAT-1K5(F .RECDEF-1K1 n1,G .RECDEF-1K1 n2)"
                       sorry
                    show " ex n be NatNAT-1M1 st  for k be NatNAT-1M1 holds n <=XXREAL-0R1 k implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                    proof(rule bexI[of _ "n"],rule ballI,rule impI)
                      fix k assume [ty]: "k be NatNAT-1M1"
                      have A122: "k inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      assume A123: "n <=XXREAL-0R1 k"
                      have "s .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 s"
                        using valued_0_th_28 sorry
                      then have " not s .FUNCT-1K1 k inTARSKIR2 {TARSKIK1 x0}"
                        using A7 xboole_0_def_5 sorry
                      then have A124: "s .FUNCT-1K1 k <>HIDDENR2 x0"
                        using tarski_def_1 sorry
                      have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                      proof-
                        show " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                        proof-
                          have cases: "s .FUNCT-1K1 k <XXREAL-0R3 x0 or s .FUNCT-1K1 k >XXREAL-0R4 x0"
                            using A124 xxreal_0_th_1 sorry
                          have case1: "s .FUNCT-1K1 k <XXREAL-0R3 x0 implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                          proof(rule impI)
                            assume "s .FUNCT-1K1 k <XXREAL-0R3 x0"
                            then obtain l where
                              [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                              A125: "k =COMPLEX1R1 F .RECDEF-1K1 l"
                              using A46 A122 sorry
                            have "F .RECDEF-1K1 n1 <=XXREAL-0R1 n"
                              using xxreal_0_th_25 sorry
                            then have "F .RECDEF-1K1 n1 <=XXREAL-0R1 k"
                              using A123 xxreal_0_th_2 sorry
                            then have "l >=XXREAL-0R2 n1"
                              using A125 seqm_3_th_1 sorry
                            then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                              using A120 sorry
                            then have " |.COMPLEX1K10 f .FUNCT-1K1 ((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l) -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                              using A45 funct_2_th_108 xboole_1_th_1 sorry
                            then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 k) -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                              using A125 funct_2_th_15 sorry
                            thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                              using A7 funct_2_th_108 xboole_1_th_1 A122 sorry
                          qed
                          have case2: "s .FUNCT-1K1 k >XXREAL-0R4 x0 implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                          proof(rule impI)
                            assume "s .FUNCT-1K1 k >XXREAL-0R4 x0"
                            then obtain l where
                              [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                              A126: "k =COMPLEX1R1 G .RECDEF-1K1 l"
                              using A93 A122 sorry
                            have "G .RECDEF-1K1 n2 <=XXREAL-0R1 n"
                              using xxreal_0_th_25 sorry
                            then have "G .RECDEF-1K1 n2 <=XXREAL-0R1 k"
                              using A123 xxreal_0_th_2 sorry
                            then have "l >=XXREAL-0R2 n2"
                              using A126 seqm_3_th_1 sorry
                            then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                              using A121 sorry
                            then have " |.COMPLEX1K10 f .FUNCT-1K1 ((s *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> G).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l) -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                              using A88 funct_2_th_108 xboole_1_th_1 sorry
                            then have " |.COMPLEX1K10 f .FUNCT-1K1 (s .FUNCT-1K1 k) -XCMPLX-0K6 ?GR .| <XXREAL-0R3 r"
                              using A126 funct_2_th_15 sorry
                            thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                              using A7 funct_2_th_108 xboole_1_th_1 A122 sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s .FUNCT-1K1 k -XCMPLX-0K6 lim-leftLIMFUNC2K1(f,x0) .| <XXREAL-0R3 r"
                         sorry
                    qed "sorry"
                  qed "sorry"
                  thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
                    using seq_2_def_6 sorry
                  thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
                    using A118 seq_2_def_7 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0)"
         sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A127: "r1 <XXREAL-0R3 x0"
        and A128: "x0 <XXREAL-0R3 r2"
      obtain g1 where
        [ty]:"g1 be RealXREAL-0M1" and 
        A129: "r1 <XXREAL-0R3 g1"and A130: "g1 <XXREAL-0R3 x0"and A131: "g1 inHIDDENR3 domRELAT-1K1 f"
        using A1 A127 limfunc2_def_1 sorry
      obtain g2 where
        [ty]:"g2 be RealXREAL-0M1" and 
        A132: "g2 <XXREAL-0R3 r2"and A133: "x0 <XXREAL-0R3 g2"and A134: "g2 inHIDDENR3 domRELAT-1K1 f"
        using A2 A128 limfunc2_def_4 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f"
            using A129 A130 A131 A132 A133 A134 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f is-convergent-inLIMFUNC3R1 x0"
      using A4 sorry
    thus "limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-leftLIMFUNC2K1(f,x0) & limLIMFUNC3K1(f,x0) =COMPLEX1R1 lim-rightLIMFUNC2K2(f,x0)"
      using A3 A4 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_31:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (limLIMFUNC3K1(f,x0))"
proof-
  have " for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (limLIMFUNC3K1(f,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
    have A2: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 r *XCMPLX-0K3 (limLIMFUNC3K1(f,x0))"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A3: "seq be convergentSEQ-2V5"
        and A4: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K6 {TARSKIK1 x0}"
      have A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A5 valued_1_def_5 sorry
      then have A7: "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
        using rfunct_2_th_9 xboole_1_th_1 sorry
      have A8: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A3 A4 A6 sorry
      then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using seq_2_th_7 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A6 rfunct_2_th_9 xboole_1_th_1 sorry
      have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
        using A1 A3 A4 A6 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 r *XCMPLX-0K3 (limLIMFUNC3K1(f,x0))"
        using A8 A7 seq_2_th_8 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A9: "r1 <XXREAL-0R3 x0"
        and A10: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A11: "r1 <XXREAL-0R3 g1"and A12: "g1 <XXREAL-0R3 x0"and A13: "g1 inHIDDENR3 domRELAT-1K1 f"and A14: "g2 <XXREAL-0R3 r2"and A15: "x0 <XXREAL-0R3 g2"and A16: "g2 inHIDDENR3 domRELAT-1K1 f"
        using A1 A9 A10 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A11 A12 A13 A14 A15 A16 valued_1_def_5 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0"
      using A2 sorry
    thus "limLIMFUNC3K1(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 r *XCMPLX-0K3 (limLIMFUNC3K1(f,x0))"
      using A2 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_32:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 -XCMPLX-0K4 limLIMFUNC3K1(f,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 -XCMPLX-0K4 limLIMFUNC3K1(f,x0)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
    show "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0"
      using A1 limfunc3_th_31 sorry
    have "limLIMFUNC3K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (limLIMFUNC3K1(f,x0))"
      using A1 limfunc3_th_31 sorry
    also have "... = -XCMPLX-0K4 limLIMFUNC3K1(f,x0)"
       sorry
    finally show "limLIMFUNC3K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 -XCMPLX-0K4 limLIMFUNC3K1(f,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_33:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 limLIMFUNC3K1(f2,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-convergent-inLIMFUNC3R1 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 limLIMFUNC3K1(f2,x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 x0"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 limLIMFUNC3K1(f2,x0)"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be convergentSEQ-2V5"
        and A6: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      have A8: "domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A7 limfunc3_lm_4 sorry
      have A9: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_4 sorry
      have A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_4 sorry
      then have A11: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
        using A2 A5 A6 limfunc3_def_4 sorry
      have A12: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A2 A5 A6 A10 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A7 limfunc3_lm_4 sorry
      then have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
        using A8 rfunct_2_th_8 sorry
      have A14: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A5 A6 A9 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A12 A13 seq_2_th_5 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
        using A1 A5 A6 A9 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 limLIMFUNC3K1(f2,x0)"
        using A14 A12 A11 A13 seq_2_th_6 sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0"
      using A3 sorry
    thus "limLIMFUNC3K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 limLIMFUNC3K1(f2,x0)"
      using A4 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_34:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0) -XCMPLX-0K6 limLIMFUNC3K1(f2,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-convergent-inLIMFUNC3R1 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 limLIMFUNC3K1(f1,x0) -XCMPLX-0K6 limLIMFUNC3K1(f2,x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 x0"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    have A4: "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0"
      using A2 limfunc3_th_32 sorry
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0"
      using A1 A3 limfunc3_th_33 sorry
    have "limLIMFUNC3K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 limLIMFUNC3K1(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0)"
      using A1 A3 A4 limfunc3_th_33 sorry
    also have "... = limLIMFUNC3K1(f1,x0) +XCMPLX-0K2 (-XCMPLX-0K4 limLIMFUNC3K1(f2,x0))"
      using A2 limfunc3_th_32 sorry
    also have "... = limLIMFUNC3K1(f1,x0) -XCMPLX-0K6 limLIMFUNC3K1(f2,x0)"
       sorry
    finally show "limLIMFUNC3K1(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 limLIMFUNC3K1(f1,x0) -XCMPLX-0K6 limLIMFUNC3K1(f2,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_35:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 & (f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
      and A2: "f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      and A3: "limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6"
    have A4: "domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using A2 sorry
    also have "... = domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    finally have "domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have A5: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A6: "seq be convergentSEQ-2V5"
        and A7: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A8: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}"
      have A9: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
        using A1 A4 A6 A7 A8 limfunc3_def_4 sorry
      have A10: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
        using A8 rfunct_2_th_12 xboole_1_th_1 sorry
      have A11: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
        using A4 A8 xboole_1_th_1 sorry
      have A12: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A4 A6 A7 A8 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A3 A4 A9 A11 A10 rfunct_2_th_11 seq_2_th_21 sorry
      show "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
        using A3 A4 A12 A9 A11 A10 rfunct_2_th_11 seq_2_th_22 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      using A1 A4 sorry
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0"
      using A5 sorry
    thus "limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
      using A5 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_36:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1  |.COMPLEX1K10 limLIMFUNC3K1(f,x0) .|"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1  |.COMPLEX1K10 limLIMFUNC3K1(f,x0) .|"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
    have A2: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f \\SUBSET-1K6 {TARSKIK1 x0}) implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1  |.COMPLEX1K10 limLIMFUNC3K1(f,x0) .|"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A3: "seq be convergentSEQ-2V5"
        and A4: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A5: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f \\SUBSET-1K6 {TARSKIK1 x0}"
      have A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        using A5 valued_1_def_11 sorry
      then have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
        using xboole_1_th_1 sorry
      then have A7: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
        using rfunct_2_th_10 sorry
      have A8: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A3 A4 A6 sorry
      thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A7 sorry
      have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
        using A1 A3 A4 A6 limfunc3_def_4 sorry
      thus "limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1  |.COMPLEX1K10 limLIMFUNC3K1(f,x0) .|"
        using A8 A7 seq_4_th_14 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A9: "r1 <XXREAL-0R3 x0"
        and A10: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A11: "r1 <XXREAL-0R3 g1"and A12: "g1 <XXREAL-0R3 x0"and A13: "g1 inHIDDENR3 domRELAT-1K1 f"and A14: "g2 <XXREAL-0R3 r2"and A15: "x0 <XXREAL-0R3 g2"and A16: "g2 inHIDDENR3 domRELAT-1K1 f"
        using A1 A9 A10 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
        proof(rule bexI[of _ "g2"])
          show "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
            using A11 A12 A13 A14 A15 A16 valued_1_def_11 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-convergent-inLIMFUNC3R1 x0"
      using A2 sorry
    thus "limLIMFUNC3K1(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1  |.COMPLEX1K10 limLIMFUNC3K1(f,x0) .|"
      using A2 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_37:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 & (limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
      and A2: "limLIMFUNC3K1(f,x0) <>HIDDENR2 0NUMBERSK6"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)"
    have A4: "domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    have A5: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A6: "seq be convergentSEQ-2V5"
        and A7: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A8: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}"
      have A9: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be non-zeroORDINAL1V9"
        using A8 rfunct_2_th_11 xboole_1_th_1 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using A8 xboole_1_th_1 sorry
      then have A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
        using A4 xboole_1_th_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 seq implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A11: "x inHIDDENR3 rngFUNCT-1K2 seq"
        then have " not x inHIDDENR3 {TARSKIK1 x0}"
          using A8 xboole_0_def_5 sorry
        thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using A10 A11 xboole_0_def_5 sorry
      qed "sorry"
      then have A12: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
         sorry
      then have A13: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f,x0)"
        using A1 A6 A7 limfunc3_def_4 sorry
      have A14: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
        using A8 rfunct_2_th_12 xboole_1_th_1 sorry
      have A15: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A6 A7 A12 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A2 A13 A9 A14 seq_2_th_21 sorry
      show "limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
        using A2 A15 A13 A9 A14 seq_2_th_22 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A16: "r1 <XXREAL-0R3 x0"
        and A17: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A18: "r1 <XXREAL-0R3 g1"and A19: "g1 <XXREAL-0R3 x0"and A20: "g1 inHIDDENR3 domRELAT-1K1 f"and A21: "g2 <XXREAL-0R3 r2"and A22: "x0 <XXREAL-0R3 g2"and A23: "g2 inHIDDENR3 domRELAT-1K1 f"and A24: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"and A25: "f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6"
        using A3 A16 A17 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule bexI[of _ "g2"])
          have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A25 tarski_def_1 sorry
          then have A26: " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A24 tarski_def_1 sorry
          then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          thus "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using A4 A18 A19 A20 A21 A22 A23 A26 xboole_0_def_5 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0"
      using A5 sorry
    thus "limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f,x0))\<inverse>XCMPLX-0K5"
      using A5 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_38:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))*XCMPLX-0K3 (limLIMFUNC3K1(f2,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-convergent-inLIMFUNC3R1 x0 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))*XCMPLX-0K3 (limLIMFUNC3K1(f2,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 x0"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    have A4: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))*XCMPLX-0K3 (limLIMFUNC3K1(f2,x0))"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A5: "seq be convergentSEQ-2V5"
        and A6: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      have A8: "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A7 limfunc3_lm_2 sorry
      have A9: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_2 sorry
      have A10: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A7 limfunc3_lm_2 sorry
      then have A11: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
        using A2 A5 A6 limfunc3_def_4 sorry
      have A12: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A2 A5 A6 A10 sorry
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A7 limfunc3_lm_2 sorry
      then have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq"
        using A8 rfunct_2_th_8 sorry
      have A14: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A1 A5 A6 A9 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
        using A12 A13 seq_2_th_14 sorry
      have "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
        using A1 A5 A6 A9 limfunc3_def_4 sorry
      thus "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))*XCMPLX-0K3 (limLIMFUNC3K1(f2,x0))"
        using A14 A12 A11 A13 seq_2_th_15 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0"
      using A3 sorry
    thus "limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))*XCMPLX-0K3 (limLIMFUNC3K1(f2,x0))"
      using A4 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_39:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & limLIMFUNC3K1(f2,x0) <>HIDDENR2 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 (limLIMFUNC3K1(f1,x0))/XCMPLX-0K7 (limLIMFUNC3K1(f2,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-convergent-inLIMFUNC3R1 x0 & (limLIMFUNC3K1(f2,x0) <>HIDDENR2 0NUMBERSK6 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))))) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 (limLIMFUNC3K1(f1,x0))/XCMPLX-0K7 (limLIMFUNC3K1(f2,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 x0"
      and A3: "limLIMFUNC3K1(f2,x0) <>HIDDENR2 0NUMBERSK6"
      and A4: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    have A5: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st (r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & (((((g1 inHIDDENR3 domRELAT-1K1 f2 & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f2) & f2 .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f2 .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A6: "r1 <XXREAL-0R3 x0"
        and A7: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A8: "r1 <XXREAL-0R3 g1"and A9: "g1 <XXREAL-0R3 x0"and A10: "g1 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"and A11: "g2 <XXREAL-0R3 r2"and A12: "x0 <XXREAL-0R3 g2"and A13: "g2 inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A4 A6 A7 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st (r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & (((((g1 inHIDDENR3 domRELAT-1K1 f2 & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f2) & f2 .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f2 .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st (r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & (((((g1 inHIDDENR3 domRELAT-1K1 f2 & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f2) & f2 .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f2 .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)"
        proof(rule bexI[of _ "g2"],rule conjMI)
          show "r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0"
            using A8 A9 sorry
          have A14: "domRELAT-1K1 (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
            using rfunct_1_def_1 sorry
          then have "g2 inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A13 xboole_0_def_4 sorry
          then have " not g2 inHIDDENR3 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using xboole_0_def_5 sorry
          then have A15: " not f2 .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A13 A14 funct_1_def_7 sorry
          have "g1 inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A10 A14 xboole_0_def_4 sorry
          then have " not g1 inHIDDENR3 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using xboole_0_def_5 sorry
          then have " not f2 .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A10 A14 funct_1_def_7 sorry
          thus "((((g1 inHIDDENR3 domRELAT-1K1 f2 & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f2) & f2 .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f2 .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6"
            using A10 A11 A12 A13 A14 A15 tarski_def_1 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    then have A16: "f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0"
      using A2 A3 limfunc3_th_37 sorry
    have A17: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 =FUNCT-1R1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_th_31 sorry
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0"
      using A1 A4 A16 limfunc3_th_38 sorry
    have "limLIMFUNC3K1(f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 (limLIMFUNC3K1(f2,x0))\<inverse>XCMPLX-0K5"
      using A2 A3 A5 limfunc3_th_37 sorry
    then have "limLIMFUNC3K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 (limLIMFUNC3K1(f1,x0))*XCMPLX-0K3 (limLIMFUNC3K1(f2,x0))\<inverse>XCMPLX-0K5"
      using A1 A4 A17 A16 limfunc3_th_38 sorry
    also have "... = (limLIMFUNC3K1(f1,x0))/XCMPLX-0K7 (limLIMFUNC3K1(f2,x0))"
      using xcmplx_0_def_9 sorry
    finally show "limLIMFUNC3K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =HIDDENR1 (limLIMFUNC3K1(f1,x0))/XCMPLX-0K7 (limLIMFUNC3K1(f2,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_40:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (limLIMFUNC3K1(f1,x0) =COMPLEX1R1 0NUMBERSK6 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)))) implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be boundedSEQ-2V6) implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "limLIMFUNC3K1(f1,x0) =COMPLEX1R1 0NUMBERSK6"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be boundedSEQ-2V6"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) be boundedSEQ-2V6"
       sorry
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A6: " for r1 be objectHIDDENM1 holds r1 inHIDDENR3 (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 f2 implies  |.COMPLEX1K10 f2 .FUNCT-1K1 r1.| <=XXREAL-0R1 g"
      using A5 rfunct_1_th_73 sorry
    have A7: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A8: "s be convergentSEQ-2V5"
        and A9: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A10: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K6 {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A11: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
        using A4 A8 A9 limfunc3_th_7 sorry
      have A12: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A10 limfunc3_lm_2 sorry
      then have A13: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
        using A12 sorry
      have A14: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
        using A8 A9 seq_4_th_20 sorry
      then have A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
        using A1 A8 A13 sorry
      have A16: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f2"
        using A10 limfunc3_lm_2 sorry
      then have A17: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2"
        using A12 sorry
      have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule conjMI,rule ballI)
        let ?t = " |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g.|"
          using complex1_th_46 sorry
        thus "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have A18: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A19: "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using A11 sorry
        then have A20: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using nat_1_def_3 sorry
        have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A11 A19 sorry
        then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
          using A20 sorry
        then have A21: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_2 sorry
        have A22: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {TARSKIK1 x0}"
          using A13 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A21 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          using A4 limfunc3_th_4 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 f2"
          using A17 A22 xboole_0_def_4 sorry
        then have " |.COMPLEX1K10 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n).| <=XXREAL-0R1 g"
          using A6 sorry
        then have A23: " |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <=XXREAL-0R1 g"
          using A16 A12 funct_2_th_108 xboole_1_th_1 A18 sorry
        have "g <=XXREAL-0R1  |.COMPLEX1K10 g.|"
          using absvalue_th_4 sorry
        then have "g <XXREAL-0R3 ?t"
          using limfunc3_lm_1 sorry
        thus " |.COMPLEX1K10 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n.| <XXREAL-0R3  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
          using A23 xxreal_0_th_2 sorry
      qed "sorry"
      then have A24: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be boundedSEQ-2V6"
        using seq_2_th_3 sorry
      have A25: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A10 limfunc3_lm_2 sorry
      have "domRELAT-1K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A10 limfunc3_lm_2 sorry
      then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A25 A12 sorry
      then have A26: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using rfunct_2_th_8 sorry
      also have "... = (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A25 valued_0_th_27 sorry
      finally have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =HIDDENR1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A27: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A8 A14 A13 limfunc3_def_4 sorry
      then have A28: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
        using A15 A24 seq_2_th_25 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
        using A26 seq_4_th_21 sorry
      have "limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)) =COMPLEX1R1 0NUMBERSK6"
        using A15 A27 A24 seq_2_th_26 sorry
      thus "limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 0NUMBERSK6"
        using A28 A26 seq_4_th_22 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-convergent-inLIMFUNC3R1 x0"
      using A3 sorry
    thus "limLIMFUNC3K1(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 0NUMBERSK6"
      using A7 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_41:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f))) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[))) implies f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-convergent-inLIMFUNC3R1 x0 & (limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)))) implies (( ex r1 be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[))) implies f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 x0"
      and A3: "limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
      and A4: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
    assume Given: " ex r1 be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r1 & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[))"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A5: "0NUMBERSK6 <XXREAL-0R3 r1"and A6: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"and A7: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
       sorry
    have "f is-convergent-inLIMFUNC3R1 x0 & (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0))"
    proof-
      show "f is-convergent-inLIMFUNC3R1 x0 & (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0))"
      proof-
        have cases: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
          using A7 sorry
        have case1: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) implies f is-convergent-inLIMFUNC3R1 x0 & (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0))"
        proof(rule impI,rule conjMI)
          assume A8: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
          have A9: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
          proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
            fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
            assume A10: "s be convergentSEQ-2V5"
              and A11: "limSEQ-2K1 s =COMPLEX1R1 x0"
              and A12: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
            obtain k where
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r1 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r1"
              using A5 A10 A11 limfunc3_th_7 sorry
            have A14: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
              using valued_0_th_21 sorry
            then have A15: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
              using A12 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .["
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A16: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A17: "x =HIDDENR1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              have A18: "k <=XXREAL-0R1 n +NAT-1K1 k"
                using nat_1_th_12 sorry
              then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r1"
                using A13 sorry
              then have A19: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r1"
                using nat_1_def_3 sorry
              have "x0 -XCMPLX-0K6 r1 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
                using A13 A18 sorry
              then have "x0 -XCMPLX-0K6 r1 <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using nat_1_def_3 sorry
              then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r1 }"
                using A19 sorry
              then have A20: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 +XCMPLX-0K2 r1 .["
                using rcomp_1_def_2 sorry
              have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                using A15 A16 A17 xboole_0_def_5 sorry
              then have "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 +XCMPLX-0K2 r1 .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
                using A17 A20 xboole_0_def_5 sorry
              thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .["
                using A5 limfunc3_th_4 sorry
            qed "sorry"
            then have A21: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .["
               sorry
            have A22: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
              using A12 xboole_1_th_1 sorry
            then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f"
              using A14 sorry
            then have A23: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
              using A21 xboole_1_th_19 sorry
            then have A24: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
              using A8 sorry
            then have A25: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
              using A8 sorry
            have A26: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
              using A10 A11 seq_4_th_20 sorry
            have A27: "domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2"
              using xboole_1_th_17 sorry
            then have A28: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2"
              using A25 sorry
            have A29: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A30: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                then have " not x inHIDDENR3 {TARSKIK1 x0}"
                  using A15 xboole_0_def_5 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
                  using A28 A30 xboole_0_def_5 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
                using tarski_def_3 sorry
            qed
            then have A31: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
              using A2 A10 A26 limfunc3_def_4 sorry
            have A32: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1"
              using xboole_1_th_17 sorry
            then have A33: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1"
              using A24 sorry
            have A34: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A35: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                then have " not x inHIDDENR3 {TARSKIK1 x0}"
                  using A15 xboole_0_def_5 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
                  using A33 A35 xboole_0_def_5 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
                using tarski_def_3 sorry
            qed
            then have A36: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A1 A10 A26 limfunc3_def_4 sorry
            have A37: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have A38: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A39: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                using valued_0_th_28 sorry
              then have "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A23 sorry
              then have A40: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A14 A22 funct_2_th_108 xboole_1_th_1 A38 sorry
              have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A23 A39 sorry
              then have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A14 A22 funct_2_th_108 xboole_1_th_1 A38 sorry
              thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A32 A27 A24 A25 A40 funct_2_th_108 xboole_1_th_1 A38 sorry
            qed "sorry"
            have A41: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
              using A2 A10 A26 A29 sorry
            have A42: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
              using A1 A10 A26 A34 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
              using A3 A36 A41 A31 A37 seq_2_th_19 sorry
            then have A43: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
              using A12 valued_0_th_27 xboole_1_th_1 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
              using seq_4_th_21 sorry
            have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A3 A42 A36 A41 A31 A37 seq_2_th_20 sorry
            then have "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A12 valued_0_th_27 xboole_1_th_1 sorry
            thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A43 seq_4_th_22 sorry
          qed "sorry"
          thus "f is-convergent-inLIMFUNC3R1 x0"
            using A4 sorry
          thus "f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
            using A9 limfunc3_def_4 sorry
        qed
        have case2: "domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) implies f is-convergent-inLIMFUNC3R1 x0 & (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0))"
        proof(rule impI,rule conjMI)
          assume A44: "domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) & domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
          have A45: " for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
          proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
            fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
            assume A46: "s be convergentSEQ-2V5"
              and A47: "limSEQ-2K1 s =COMPLEX1R1 x0"
              and A48: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
            obtain k where
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A49: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r1 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r1"
              using A5 A46 A47 limfunc3_th_7 sorry
            have A50: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
              using valued_0_th_21 sorry
            then have A51: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
              using A48 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .["
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A52: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A53: "x =HIDDENR1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using funct_2_th_113 sorry
              have A54: "k <=XXREAL-0R1 n +NAT-1K1 k"
                using nat_1_th_12 sorry
              then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r1"
                using A49 sorry
              then have A55: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r1"
                using nat_1_def_3 sorry
              have "x0 -XCMPLX-0K6 r1 <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
                using A49 A54 sorry
              then have "x0 -XCMPLX-0K6 r1 <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using nat_1_def_3 sorry
              then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r1 }"
                using A55 sorry
              then have A56: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 +XCMPLX-0K2 r1 .["
                using rcomp_1_def_2 sorry
              have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
                using A51 A52 A53 xboole_0_def_5 sorry
              then have "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 +XCMPLX-0K2 r1 .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
                using A53 A56 xboole_0_def_5 sorry
              thus "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .["
                using A5 limfunc3_th_4 sorry
            qed "sorry"
            then have A57: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .["
               sorry
            have A58: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
              using A48 xboole_1_th_1 sorry
            then have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f"
              using A50 sorry
            then have A59: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
              using A57 xboole_1_th_19 sorry
            then have A60: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
              using A44 sorry
            then have A61: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[)"
              using A44 sorry
            have A62: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
              using A46 A47 seq_4_th_20 sorry
            have A63: "domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f2"
              using xboole_1_th_17 sorry
            then have A64: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2"
              using A60 sorry
            have A65: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A66: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                then have " not x inHIDDENR3 {TARSKIK1 x0}"
                  using A51 xboole_0_def_5 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
                  using A64 A66 xboole_0_def_5 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
                using tarski_def_3 sorry
            qed
            then have A67: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
              using A2 A46 A62 limfunc3_def_4 sorry
            have A68: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r1,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r1 .[) c=TARSKIR1 domRELAT-1K1 f1"
              using xboole_1_th_17 sorry
            then have A69: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1"
              using A61 sorry
            have A70: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A71: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                then have " not x inHIDDENR3 {TARSKIK1 x0}"
                  using A51 xboole_0_def_5 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
                  using A69 A71 xboole_0_def_5 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
                using tarski_def_3 sorry
            qed
            then have A72: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A1 A46 A62 limfunc3_def_4 sorry
            have A73: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have A74: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A75: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
                using valued_0_th_28 sorry
              then have "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A59 sorry
              then have A76: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A50 A58 funct_2_th_108 xboole_1_th_1 A74 sorry
              have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
                using A6 A59 A75 sorry
              then have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A50 A58 funct_2_th_108 xboole_1_th_1 A74 sorry
              thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
                using A68 A63 A60 A61 A76 funct_2_th_108 xboole_1_th_1 A74 sorry
            qed "sorry"
            have A77: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
              using A2 A46 A62 A65 sorry
            have A78: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
              using A1 A46 A62 A70 sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
              using A3 A72 A77 A67 A73 seq_2_th_19 sorry
            then have A79: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
              using A48 valued_0_th_27 xboole_1_th_1 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
              using seq_4_th_21 sorry
            have "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A3 A78 A72 A77 A67 A73 seq_2_th_20 sorry
            then have "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A48 valued_0_th_27 xboole_1_th_1 sorry
            thus "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
              using A79 seq_4_th_22 sorry
          qed "sorry"
          thus "f is-convergent-inLIMFUNC3R1 x0"
            using A4 sorry
          thus "f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
            using A45 limfunc3_def_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_42:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)) & ( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & (f2 is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)) implies (( ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)) implies f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 x0"
      and A3: "limLIMFUNC3K1(f1,x0) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
    assume Given: " ex r be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 r & ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f"and A6: " for g be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 g & f .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g"
       sorry
    have A7: "domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
      using A5 xboole_1_th_18 xboole_1_th_28 sorry
    have A8: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using A5 xboole_1_th_18 sorry
    then have A9: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
      using xboole_1_th_18 xboole_1_th_28 sorry
    have A10: "domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
      using A8 xboole_1_th_18 xboole_1_th_28 sorry
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f)"
      using A4 A5 limfunc3_th_5 xboole_1_th_18 sorry
    thus "f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
      using A1 A2 A3 A4 A6 A7 A9 A10 limfunc3_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_43:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))) implies limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-convergent-inLIMFUNC3R1 x0 & f2 is-convergent-inLIMFUNC3R1 x0 implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))) implies limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-convergent-inLIMFUNC3R1 x0"
      and A2: "f2 is-convergent-inLIMFUNC3R1 x0"
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g))"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r"and A4: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
       sorry
    have "limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
    proof-
      show "limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
      proof-
        have cases: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) or domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          using A4 sorry
        have case1: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) implies limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
        proof(rule impI)
          assume A5: "domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 Lamb2 & Lamb2 <XXREAL-0R3 x0) & Lamb2 inHIDDENR3 domRELAT-1K1 f1"
          have A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A7: "x0 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"
              using limfunc3_lm_1 sorry
            have "x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
              using limfunc3_lm_3 sorry
            then obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A8: "x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1"and A9: "g1 <XXREAL-0R3 x0"and A10: "g1 inHIDDENR3 domRELAT-1K1 f1"and "g2 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"and "x0 <XXREAL-0R3 g2"and "g2 inHIDDENR3 domRELAT-1K1 f1"
              using A1 A7 sorry
            have 
              [ty]:"g1 be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex g1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1"
            proof(rule bexI[of _ "g1"])
              show "(x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f1"
                using A8 A9 A10 sorry
            qed "sorry"
          qed "sorry"
          obtain s where
            [ty]:"s be Real-SequenceSEQ-1M1" and 
            A11: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A6 sorry
          have A12: "limSEQ-2K1 s =COMPLEX1R1 x0"
            using A11 limfunc3_th_6 sorry
          have A13: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
            using A11 limfunc3_th_6 sorry
          have A14: "s be convergentSEQ-2V5"
            using A11 limfunc3_th_6 sorry
          have "x0 -XCMPLX-0K6 r <XXREAL-0R3 x0"
            using A3 limfunc3_lm_1 sorry
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A15: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-1K1 n"
            using A14 A12 limfunc2_th_1 sorry
          have A16: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
            using A14 A12 seq_4_th_20 sorry
          have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
            using valued_0_th_21 sorry
          then have A17: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
            using A13 sorry
          then have A18: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
            using A1 A14 A16 limfunc3_def_4 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A19: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A20: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0"
              using A11 A20 sorry
            then have A21: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
              using nat_1_def_3 sorry
            have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A15 nat_1_th_12 sorry
            then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using nat_1_def_3 sorry
            then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
              using A21 sorry
            then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .["
              using rcomp_1_def_2 sorry
            then have A22: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
              using xboole_0_def_3 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELAT-1K1 f1"
              using A11 A20 sorry
            then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f1"
              using nat_1_def_3 sorry
            thus "x inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
              using A19 A22 xboole_0_def_4 sorry
          qed "sorry"
          then have A23: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
             sorry
          then have A24: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
            using A5 sorry
          have A25: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A26: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              using valued_0_th_28 sorry
            then have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
              using A5 A23 sorry
            then have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
              using A24 funct_2_th_108 xboole_1_th_18 A26 sorry
            thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
              using A23 funct_2_th_108 xboole_1_th_18 A26 sorry
          qed "sorry"
          have A27: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2"
            using A24 xboole_1_th_18 sorry
          have A28: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A29: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then have " not x inHIDDENR3 {TARSKIK1 x0}"
                using A17 xboole_0_def_5 sorry
              thus "x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
                using A27 A29 xboole_0_def_5 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
              using tarski_def_3 sorry
          qed
          then have A30: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
            using A2 A14 A16 limfunc3_def_4 sorry
          have A31: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
            using A2 A14 A16 A28 sorry
          have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
            using A1 A14 A16 A17 sorry
          thus "limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
            using A18 A31 A30 A25 seq_2_th_18 sorry
        qed
        have case2: "domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g) implies limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
        proof(rule impI)
          assume A32: "domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f1 .FUNCT-1K1 g <=XXREAL-0R1 f2 .FUNCT-1K1 g)"
          let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 Lamb2 & Lamb2 <XXREAL-0R3 x0) & Lamb2 inHIDDENR3 domRELAT-1K1 f2"
          have A33: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f2"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A34: "x0 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"
              using limfunc3_lm_1 sorry
            have "x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 x0"
              using limfunc3_lm_3 sorry
            then obtain g1 g2 where
              [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
              A35: "x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1"and A36: "g1 <XXREAL-0R3 x0"and A37: "g1 inHIDDENR3 domRELAT-1K1 f2"and "g2 <XXREAL-0R3 x0 +XCMPLX-0K2 \<one>\<^sub>M"and "x0 <XXREAL-0R3 g2"and "g2 inHIDDENR3 domRELAT-1K1 f2"
              using A2 A34 sorry
            have 
              [ty]:"g1 be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            show " ex g1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f2"
            proof(rule bexI[of _ "g1"])
              show "(x0 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f2"
                using A35 A36 A37 sorry
            qed "sorry"
          qed "sorry"
          obtain s where
            [ty]:"s be Real-SequenceSEQ-1M1" and 
            A38: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?X(n,s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A33 sorry
          have A39: "limSEQ-2K1 s =COMPLEX1R1 x0"
            using A38 limfunc3_th_6 sorry
          have A40: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
            using A38 limfunc3_th_6 sorry
          have A41: "s be convergentSEQ-2V5"
            using A38 limfunc3_th_6 sorry
          have "x0 -XCMPLX-0K6 r <XXREAL-0R3 x0"
            using A3 limfunc3_lm_1 sorry
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A42: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-1K1 n"
            using A41 A39 limfunc2_th_1 sorry
          have A43: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
            using A41 A39 seq_4_th_20 sorry
          have "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
            using valued_0_th_21 sorry
          then have A44: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 \\SUBSET-1K6 {TARSKIK1 x0}"
            using A40 sorry
          then have A45: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f2,x0)"
            using A2 A41 A43 limfunc3_def_4 sorry
          have A46: " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A47: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
              using funct_2_th_113 sorry
            have A48: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) <XXREAL-0R3 x0"
              using A38 A48 sorry
            then have A49: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0"
              using nat_1_def_3 sorry
            have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-1K1 (n +XCMPLX-0K2 k)"
              using A42 nat_1_th_12 sorry
            then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using nat_1_def_3 sorry
            then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 x0 }"
              using A49 sorry
            then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .["
              using rcomp_1_def_2 sorry
            then have A50: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
              using xboole_0_def_3 sorry
            have "s .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 domRELAT-1K1 f2"
              using A38 A48 sorry
            then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f2"
              using nat_1_def_3 sorry
            thus "x inHIDDENR3 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
              using A47 A50 xboole_0_def_4 sorry
          qed "sorry"
          then have A51: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
             sorry
          then have A52: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
            using A32 sorry
          have A53: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have A54: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              using valued_0_th_28 sorry
            then have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
              using A32 A46 sorry
            then have "f1 .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n) <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
              using A51 funct_2_th_108 xboole_1_th_18 A54 sorry
            thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <=XXREAL-0R1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
              using A52 funct_2_th_108 xboole_1_th_18 A54 sorry
          qed "sorry"
          have A55: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1"
            using A52 xboole_1_th_18 sorry
          have A56: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A57: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              then have " not x inHIDDENR3 {TARSKIK1 x0}"
                using A44 xboole_0_def_5 sorry
              thus "x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
                using A55 A57 xboole_0_def_5 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f1 \\SUBSET-1K6 {TARSKIK1 x0}"
              using tarski_def_3 sorry
          qed
          then have A58: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limLIMFUNC3K1(f1,x0)"
            using A1 A41 A43 limfunc3_def_4 sorry
          have A59: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
            using A1 A41 A43 A56 sorry
          have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
            using A2 A41 A43 A44 sorry
          thus "limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
            using A45 A59 A58 A53 seq_2_th_18 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "limLIMFUNC3K1(f1,x0) <=XXREAL-0R1 limLIMFUNC3K1(f2,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_44:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0 implies (( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    assume A2: "f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0"
    have A3: " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq =COMPLEX1R1 x0 & rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A4: "seq be convergentSEQ-2V5"
        and A5: "limSEQ-2K1 seq =COMPLEX1R1 x0"
        and A6: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}"
      have "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using A6 xboole_1_th_1 sorry
      then have A7: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f"
        using A1 xboole_1_th_1 sorry
      have A8: "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 seq implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A9: "x inHIDDENR3 rngFUNCT-1K2 seq"
          then have " not x inHIDDENR3 {TARSKIK1 x0}"
            using A6 xboole_0_def_5 sorry
          thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
            using A7 A9 xboole_0_def_5 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 seq c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using tarski_def_3 sorry
      qed
      have "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
      proof-
        show "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
        proof-
          have cases: "f is-divergent-to+infty-inLIMFUNC3R2 x0 or f is-divergent-to-infty-inLIMFUNC3R3 x0"
            using A2 sorry
          have case1: "f is-divergent-to+infty-inLIMFUNC3R2 x0 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
          proof(rule impI)
            assume "f is-divergent-to+infty-inLIMFUNC3R2 x0"
            then have A10: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to+inftyLIMFUNC1V1"
              using A4 A5 A8 sorry
            then have A11: "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
              using limfunc1_th_34 sorry
            have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
              using A10 limfunc1_th_34 sorry
            thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
              using A6 A11 rfunct_2_th_12 xboole_1_th_1 sorry
          qed
          have case2: "f is-divergent-to-infty-inLIMFUNC3R3 x0 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
          proof(rule impI)
            assume "f is-divergent-to-infty-inLIMFUNC3R3 x0"
            then have A12: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be divergent-to-inftyLIMFUNC1V2"
              using A4 A5 A8 sorry
            then have A13: "limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 0NUMBERSK6"
              using limfunc1_th_34 sorry
            have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
              using A12 limfunc1_th_34 sorry
            thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
              using A6 A13 rfunct_2_th_12 xboole_1_th_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
         sorry
    qed "sorry"
    assume A14: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A15: "r1 <XXREAL-0R3 x0"
        and A16: "x0 <XXREAL-0R3 r2"
      obtain g1 g2 where
        [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
        A17: "r1 <XXREAL-0R3 g1"and A18: "g1 <XXREAL-0R3 x0"and A19: "g1 inHIDDENR3 domRELAT-1K1 f"and A20: "g2 <XXREAL-0R3 r2"and A21: "x0 <XXREAL-0R3 g2"and A22: "g2 inHIDDENR3 domRELAT-1K1 f"and A23: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"and A24: "f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6"
        using A14 A15 A16 sorry
      show " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof(rule bexI[of _ "g1"])
        show " ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule bexI[of _ "g2"])
          have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A24 tarski_def_1 sorry
          then have A25: " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A23 tarski_def_1 sorry
          then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          thus "((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using A1 A17 A18 A19 A20 A21 A22 A25 xboole_0_def_5 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-convergent-inLIMFUNC3R1 x0"
      using A3 sorry
    thus "limLIMFUNC3K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 0NUMBERSK6"
      using A3 limfunc3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_45:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 & (limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))) implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
      and A2: "limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)"
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 g"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & ( for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      proof-
        have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar89 be RealXREAL-0M1 st  ex tVar90 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar89 &  not tVar89 <XXREAL-0R3 x0) & tVar89 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not tVar90 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar90) & tVar90 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          fix r2 assume [ty]: "r2 be RealXREAL-0M1"
          assume A6: "r1 <XXREAL-0R3 x0"
            and A7: "x0 <XXREAL-0R3 r2"
          obtain g1 g2 where
            [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
            A8: "r1 <XXREAL-0R3 g1"and A9: "g1 <XXREAL-0R3 x0"and A10: "g1 inHIDDENR3 domRELAT-1K1 f"and A11: "g2 <XXREAL-0R3 r2"and A12: "x0 <XXREAL-0R3 g2"and A13: "g2 inHIDDENR3 domRELAT-1K1 f"and A14: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"and A15: "f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6"
            using A3 A6 A7 sorry
          have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A15 tarski_def_1 sorry
          then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          then have A16: "g2 inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A13 xboole_0_def_5 sorry
          show " ex tVar89 be RealXREAL-0M1 st  ex tVar90 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar89 &  not tVar89 <XXREAL-0R3 x0) & tVar89 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not tVar90 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar90) & tVar90 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule bexI[of _ "g1"])
            show " ex tVar90 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not tVar90 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar90) & tVar90 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            proof(rule bexI[of _ "g2"])
              have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                using A14 tarski_def_1 sorry
              then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                using funct_1_def_7 sorry
              then have "g1 inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                using A10 xboole_0_def_5 sorry
              thus "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                using A8 A9 A11 A12 A16 rfunct_1_def_2 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A17: "s be convergentSEQ-2V5"
        and A18: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A19: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A20: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
        using A4 A17 A18 limfunc3_th_7 sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using A19 xboole_1_th_1 sorry
      have A22: "domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A23: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A21 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A19 rfunct_2_th_12 xboole_1_th_1 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A24: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A25: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
        using A21 A22 xboole_1_th_1 sorry
      then have A26: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f"
        using A24 sorry
      have A27: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}"
        using A19 A24 sorry
      have A28: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A29: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          then have " not x inHIDDENR3 {TARSKIK1 x0}"
            using A27 xboole_0_def_5 sorry
          thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
            using A26 A29 xboole_0_def_5 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using tarski_def_3 sorry
      qed
      have A30: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
        using A17 A18 seq_4_th_20 sorry
      then have A31: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A17 A28 limfunc3_def_4 sorry
      have A32: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be non-zeroORDINAL1V9"
        using A21 A24 rfunct_2_th_11 xboole_1_th_1 sorry
      have " for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A33: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A34: "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using A20 sorry
        then have A35: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using nat_1_def_3 sorry
        have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A20 A34 sorry
        then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
          using A35 sorry
        then have A36: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_2 sorry
        have A37: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 {TARSKIK1 x0}"
          using A27 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A36 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          using A4 limfunc3_th_4 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n inTARSKIR2 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
          using A26 A37 xboole_0_def_4 sorry
        then have A38: "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A5 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
          using A32 seq_1_th_5 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using A25 A24 A38 funct_2_th_108 xboole_1_th_1 A33 sorry
      qed "sorry"
      then have A39: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies 0NUMBERSK6 <XXREAL-0R3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
         sorry
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
        using A1 A17 A30 A28 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to+inftyLIMFUNC1V1"
        using A31 A39 limfunc1_th_35 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to+inftyLIMFUNC1V1"
        using A23 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0"
      using limfunc3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_46:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 & (limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6 & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6))) implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
      and A2: "limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
      and A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 f) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6) & f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6)"
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <=XXREAL-0R1 0NUMBERSK6"
       sorry
    have "( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))) & ( for s be Real-SequenceSEQ-1M1 holds s be convergentSEQ-2V5 & (limSEQ-2K1 s =COMPLEX1R1 x0 & rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
      show " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st ((((r1 <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & g2 <XXREAL-0R3 r2) & x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
      proof-
        have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 <XXREAL-0R3 x0 & x0 <XXREAL-0R3 r2 implies ( ex tVar91 be RealXREAL-0M1 st  ex tVar92 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar91 &  not tVar91 <XXREAL-0R3 x0) & tVar91 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not tVar92 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar92) & tVar92 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix r1 assume [ty]: "r1 be RealXREAL-0M1"
          fix r2 assume [ty]: "r2 be RealXREAL-0M1"
          assume A6: "r1 <XXREAL-0R3 x0"
            and A7: "x0 <XXREAL-0R3 r2"
          obtain g1 g2 where
            [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
            A8: "r1 <XXREAL-0R3 g1"and A9: "g1 <XXREAL-0R3 x0"and A10: "g1 inHIDDENR3 domRELAT-1K1 f"and A11: "g2 <XXREAL-0R3 r2"and A12: "x0 <XXREAL-0R3 g2"and A13: "g2 inHIDDENR3 domRELAT-1K1 f"and A14: "f .FUNCT-1K1 g1 <>HIDDENR2 0NUMBERSK6"and A15: "f .FUNCT-1K1 g2 <>HIDDENR2 0NUMBERSK6"
            using A3 A6 A7 sorry
          have " not f .FUNCT-1K1 g2 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A15 tarski_def_1 sorry
          then have " not g2 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          then have A16: "g2 inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A13 xboole_0_def_5 sorry
          show " ex tVar91 be RealXREAL-0M1 st  ex tVar92 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 tVar91 &  not tVar91 <XXREAL-0R3 x0) & tVar91 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not tVar92 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar92) & tVar92 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule bexI[of _ "g1"])
            show " ex tVar92 be RealXREAL-0M1 st (((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not tVar92 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 tVar92) & tVar92 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            proof(rule bexI[of _ "g2"])
              have " not f .FUNCT-1K1 g1 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
                using A14 tarski_def_1 sorry
              then have " not g1 inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                using funct_1_def_7 sorry
              then have "g1 inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
                using A10 xboole_0_def_5 sorry
              thus "(((( not r1 <XXREAL-0R3 g1 &  not g1 <XXREAL-0R3 x0) & g1 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) &  not g2 <XXREAL-0R3 r2) &  not x0 <XXREAL-0R3 g2) & g2 inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                using A8 A9 A11 A12 A16 rfunct_1_def_2 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
      assume A17: "s be convergentSEQ-2V5"
        and A18: "limSEQ-2K1 s =COMPLEX1R1 x0"
        and A19: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}"
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A20: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
        using A4 A17 A18 limfunc3_th_7 sorry
      have A21: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using A19 xboole_1_th_1 sorry
      have A22: "domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A23: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A21 valued_0_th_27 xboole_1_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_18 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using A19 rfunct_2_th_12 xboole_1_th_1 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      have A24: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngFUNCT-1K2 s"
        using valued_0_th_21 sorry
      have A25: "rngFUNCT-1K2 s c=TARSKIR1 domRELAT-1K1 f"
        using A21 A22 xboole_1_th_1 sorry
      then have A26: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f"
        using A24 sorry
      have A27: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) \\SUBSET-1K6 {TARSKIK1 x0}"
        using A19 A24 sorry
      have A28: "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) implies x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A29: "x inHIDDENR3 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          then have " not x inHIDDENR3 {TARSKIK1 x0}"
            using A27 xboole_0_def_5 sorry
          thus "x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
            using A26 A29 xboole_0_def_5 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELAT-1K1 f \\SUBSET-1K6 {TARSKIK1 x0}"
          using tarski_def_3 sorry
      qed
      have A30: "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 x0"
        using A17 A18 seq_4_th_20 sorry
      then have A31: "limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 A17 A28 limfunc3_def_4 sorry
      have A32: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be non-zeroORDINAL1V9"
        using A21 A24 rfunct_2_th_11 xboole_1_th_1 sorry
      have A33: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A34: "k <=XXREAL-0R1 n +NAT-1K1 k"
          using nat_1_th_12 sorry
        then have "s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using A20 sorry
        then have A35: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 x0 +XCMPLX-0K2 r"
          using nat_1_def_3 sorry
        have "x0 -XCMPLX-0K6 r <XXREAL-0R3 s .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
          using A20 A34 sorry
        then have "x0 -XCMPLX-0K6 r <XXREAL-0R3 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using nat_1_def_3 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
          using A35 sorry
        then have A36: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_2 sorry
        have A37: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngFUNCT-1K2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
          using valued_0_th_28 sorry
        then have " not (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
          using A27 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {TARSKIK1 x0}"
          using A36 xboole_0_def_5 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
          using A4 limfunc3_th_4 sorry
        then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
          using A26 A37 xboole_0_def_4 sorry
        then have A38: "f .FUNCT-1K1 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) <=XXREAL-0R1 0NUMBERSK6"
          using A5 sorry
        have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using A32 seq_1_th_5 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 0NUMBERSK6"
          using A25 A24 A38 funct_2_th_108 xboole_1_th_1 sorry
      qed "sorry"
      have A39: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 n implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
      proof-
        have " for n be NatNAT-1M1 holds  not (0NUMBERSK6 <=XXREAL-0R1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6)"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          thus " not (0NUMBERSK6 <=XXREAL-0R1 n & f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6)"
            using A33 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) be convergentSEQ-2V5"
        using A1 A17 A30 A28 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be divergent-to-inftyLIMFUNC1V2"
        using A31 A39 limfunc1_th_36 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s be divergent-to-inftyLIMFUNC1V2"
        using A23 limfunc1_th_7 sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0"
      using limfunc3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_47:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6 implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
      and A2: "limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
    have A3: "f is-right-convergent-inLIMFUNC2R4 x0"
      using A1 limfunc3_th_29 sorry
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
       sorry
    have A6: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
    proof(rule ballI,rule impI)
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume A7: "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
      then have "g inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        using xboole_0_def_4 sorry
      then have A8: "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        using xboole_0_def_3 sorry
      have "g inHIDDENR3 domRELAT-1K1 f"
        using A7 xboole_0_def_4 sorry
      then have "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A8 xboole_0_def_4 sorry
      thus "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
        using A5 sorry
    qed "sorry"
    have A9: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies 0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
    proof(rule ballI,rule impI)
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume A10: "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[)"
      then have "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .["
        using xboole_0_def_4 sorry
      then have A11: "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        using xboole_0_def_3 sorry
      have "g inHIDDENR3 domRELAT-1K1 f"
        using A10 xboole_0_def_4 sorry
      then have "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A11 xboole_0_def_4 sorry
      thus "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 g"
        using A5 sorry
    qed "sorry"
    have "lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 limfunc3_th_29 sorry
    then have A12: "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-divergent-to+infty-inLIMFUNC2R5 x0"
      using A3 A4 A6 limfunc2_th_73 sorry
    have A13: "f is-left-convergent-inLIMFUNC2R1 x0"
      using A1 limfunc3_th_29 sorry
    have "lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 limfunc3_th_29 sorry
    then have "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-divergent-to+infty-inLIMFUNC2R2 x0"
      using A13 A4 A9 limfunc2_th_71 sorry
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to+infty-inLIMFUNC3R2 x0"
      using A12 limfunc3_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem limfunc3_th_48:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6) & ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-convergent-inLIMFUNC3R1 x0 & limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6 implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6)) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-convergent-inLIMFUNC3R1 x0"
      and A2: "limLIMFUNC3K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
    have A3: "f is-right-convergent-inLIMFUNC2R4 x0"
      using A1 limfunc3_th_29 sorry
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
       sorry
    have A6: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume A7: "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
      then have "g inHIDDENR3 ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        using xboole_0_def_4 sorry
      then have A8: "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        using xboole_0_def_3 sorry
      have "g inHIDDENR3 domRELAT-1K1 f"
        using A7 xboole_0_def_4 sorry
      then have "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A8 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
        using A5 sorry
    qed "sorry"
    have A9: " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[) implies f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume A10: "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[)"
      then have "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .["
        using xboole_0_def_4 sorry
      then have A11: "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .["
        using xboole_0_def_3 sorry
      have "g inHIDDENR3 domRELAT-1K1 f"
        using A10 xboole_0_def_4 sorry
      then have "g inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 .[ \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ].RCOMP-1K2 x0,x0 +XCMPLX-0K2 r .[)"
        using A11 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 g <XXREAL-0R3 0NUMBERSK6"
        using A5 sorry
    qed "sorry"
    have "lim-rightLIMFUNC2K2(f,x0) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 limfunc3_th_29 sorry
    then have A12: "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-right-divergent-to-infty-inLIMFUNC2R6 x0"
      using A3 A4 A6 limfunc2_th_74 sorry
    have A13: "f is-left-convergent-inLIMFUNC2R1 x0"
      using A1 limfunc3_th_29 sorry
    have "lim-leftLIMFUNC2K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 limfunc3_th_29 sorry
    then have "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-left-divergent-to-infty-inLIMFUNC2R3 x0"
      using A13 A4 A9 limfunc2_th_72 sorry
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-divergent-to-infty-inLIMFUNC3R3 x0"
      using A12 limfunc3_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
