theory nat_d
  imports finset_1 int_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, p, k, l, m, n, s, h, i, j, t, i1, i2 for "naturalORDINAL1V7\<bar>NumberORDINAL1M1"
mlemma nat_d_lm_1:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k divINT-1K5 l be NatNAT-1M1"
proof(rule ballI,rule ballI)
  fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix l assume [ty]: "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  obtain k1 l1 where 
    [ty]:"k1 be NatNAT-1M1" and k1Def:"k1 = k" and
    [ty]:"l1 be NatNAT-1M1" and l1Def:"l1 = l"
    using tarski_th_1 sorry
  have "k1 divINT-1K5 l1 inHIDDENR3 NATNUMBERSK1"
    using int_1_th_3 int_1_th_55 sorry
  thus "k divINT-1K5 l be NatNAT-1M1"
     sorry
qed "sorry"

mlemma nat_d_lm_2:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k modINT-1K6 l be NatNAT-1M1"
proof(rule ballI,rule ballI)
  fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix l assume [ty]: "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have "k modINT-1K6 l inHIDDENR3 NATNUMBERSK1"
    using int_1_th_3 int_1_th_57 sorry
  thus "k modINT-1K6 l be NatNAT-1M1"
     sorry
qed "sorry"

abbreviation(input) NAT_DK1(" _ divNAT-DK1  _ " [132,132]132) where
  "k divNAT-DK1 l \<equiv> k divINT-1K5 l"

mtheorem nat_d_def_1:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"redefine func k divNAT-DK1 l \<rightarrow> NatNAT-1M1 means
  \<lambda>it. ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 it +XCMPLX-0K2 t & t <XXREAL-0R3 l) or it =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
proof
(*compatibility*)
  show " for it be NatNAT-1M1 holds it =HIDDENR1 k divNAT-DK1 l iff ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 it +XCMPLX-0K2 t & t <XXREAL-0R3 l) or it =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
  proof-
    have " for r be NatNAT-1M1 holds  not ((r =HIDDENR1 k divINT-1K5 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k divINT-1K5 l)"
    proof(rule ballI)
      fix r assume [ty]: "r be NatNAT-1M1"
      show " not ((r =HIDDENR1 k divINT-1K5 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k divINT-1K5 l)"
      proof-
        have cases: "l =HIDDENR1 0NUMBERSK6 or l >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "l =HIDDENR1 0NUMBERSK6 implies  not ((r =HIDDENR1 k divINT-1K5 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k divINT-1K5 l)"
        proof(rule impI)
          assume "l =HIDDENR1 0NUMBERSK6"
          thus " not ((r =HIDDENR1 k divINT-1K5 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t &  not t <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k divINT-1K5 l)"
            using int_1_th_48 sorry
        qed
        have case2: "l >XXREAL-0R4 0NUMBERSK6 implies (r =HIDDENR1 k divINT-1K5 l implies ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t & t <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6) & (( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t & t <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6 implies r =HIDDENR1 k divINT-1K5 l)"
        proof(rule impI,rule conjMI,rule impI)
          assume A1: "l >XXREAL-0R4 0NUMBERSK6"
          then have A2: "k =HIDDENR1 l *XCMPLX-0K3 (k divINT-1K5 l) +XCMPLX-0K2 (k modINT-1K6 l)"
            using int_1_th_59 sorry
          have A3: "k modINT-1K6 l be NatNAT-1M1"
            using nat_d_lm_2 sorry
          thus "r =HIDDENR1 k divINT-1K5 l implies ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t & t <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
            using A1 A2 int_1_th_58 sorry
          assume A4: "( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 r +XCMPLX-0K2 t & t <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
          have A5: "k modINT-1K6 l <XXREAL-0R3 l"
            using A1 int_1_th_58 sorry
          have "k divINT-1K5 l be NatNAT-1M1"
            using nat_d_lm_1 sorry
          thus "r =HIDDENR1 k divINT-1K5 l"
            using A2 A3 A4 A5 nat_1_th_18 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem nat_d_add_1:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster k divINT-1K5 l as-term-is NatNAT-1M1"
proof
(*coherence*)
  show "k divINT-1K5 l be NatNAT-1M1"
    using nat_d_lm_1 sorry
qed "sorry"

abbreviation(input) NAT_DK2(" _ modNAT-DK2  _ " [132,132]132) where
  "k modNAT-DK2 l \<equiv> k modINT-1K6 l"

mtheorem nat_d_def_2:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"redefine func k modNAT-DK2 l \<rightarrow> NatNAT-1M1 means
  \<lambda>it. ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 it & it <XXREAL-0R3 l) or it =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
proof
(*compatibility*)
  show " for it be NatNAT-1M1 holds it =HIDDENR1 k modNAT-DK2 l iff ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 it & it <XXREAL-0R3 l) or it =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
  proof-
    have " for r be NatNAT-1M1 holds  not ((r =HIDDENR1 k modINT-1K6 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k modINT-1K6 l)"
    proof(rule ballI)
      fix r assume [ty]: "r be NatNAT-1M1"
      show " not ((r =HIDDENR1 k modINT-1K6 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k modINT-1K6 l)"
      proof-
        have cases: "l =HIDDENR1 0NUMBERSK6 or l >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "l =HIDDENR1 0NUMBERSK6 implies  not ((r =HIDDENR1 k modINT-1K6 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k modINT-1K6 l)"
        proof(rule impI)
          assume "l =HIDDENR1 0NUMBERSK6"
          thus " not ((r =HIDDENR1 k modINT-1K6 l & ( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l))) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not ( not (( for t be NatNAT-1M1 holds  not (k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r &  not r <XXREAL-0R3 l)) &  not (r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6)) &  not r =HIDDENR1 k modINT-1K6 l)"
            using int_1_def_10 sorry
        qed
        have case2: "l >XXREAL-0R4 0NUMBERSK6 implies (r =HIDDENR1 k modINT-1K6 l implies ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r & r <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6) & (( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r & r <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6 implies r =HIDDENR1 k modINT-1K6 l)"
        proof(rule impI,rule conjMI,rule impI)
          assume A1: "l >XXREAL-0R4 0NUMBERSK6"
          then have A2: "k =HIDDENR1 l *XCMPLX-0K3 (k divNAT-DK1 l) +XCMPLX-0K2 (k modINT-1K6 l)"
            using int_1_th_59 sorry
          thus "r =HIDDENR1 k modINT-1K6 l implies ( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r & r <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
            using A1 int_1_th_58 sorry
          assume A3: "( ex t be NatNAT-1M1 st k =HIDDENR1 l *XCMPLX-0K3 t +XCMPLX-0K2 r & r <XXREAL-0R3 l) or r =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 0NUMBERSK6"
          have A4: "k modINT-1K6 l <XXREAL-0R3 l"
            using A1 int_1_th_58 sorry
          have "k modINT-1K6 l be NatNAT-1M1"
            using nat_d_lm_2 sorry
          thus "r =HIDDENR1 k modINT-1K6 l"
            using A2 A3 A4 nat_1_th_18 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem nat_d_add_2:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster k modINT-1K6 l as-term-is NatNAT-1M1"
proof
(*coherence*)
  show "k modINT-1K6 l be NatNAT-1M1"
    using nat_d_lm_2 sorry
qed "sorry"

abbreviation(input) NAT_DK3(" _ divNAT-DK3  _ " [132,132]132) where
  "k divNAT-DK3 l \<equiv> k divINT-1K5 l"

mtheorem nat_d_add_3:
  mlet "k be NatNAT-1M1", "l be NatNAT-1M1"
"cluster k divINT-1K5 l as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "k divINT-1K5 l be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "k divNAT-DK1 l be NatNAT-1M1"
       sorry
    thus "k divINT-1K5 l be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
  qed
qed "sorry"

abbreviation(input) NAT_DK4(" _ modNAT-DK4  _ " [132,132]132) where
  "k modNAT-DK4 l \<equiv> k modINT-1K6 l"

mtheorem nat_d_add_4:
  mlet "k be NatNAT-1M1", "l be NatNAT-1M1"
"cluster k modINT-1K6 l as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "k modINT-1K6 l be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "k modNAT-DK2 l be NatNAT-1M1"
       sorry
    thus "k modINT-1K6 l be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
  qed
qed "sorry"

mtheorem nat_d_th_1:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 i implies j modNAT-DK2 i <XXREAL-0R3 i"
  using int_1_th_58 sorry

mtheorem nat_d_th_2:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 i implies j =HIDDENR1 i *XCMPLX-0K3 (j divNAT-DK1 i) +XCMPLX-0K2 (j modNAT-DK2 i)"
  using int_1_th_59 sorry

abbreviation(input) NAT_DR1(" _ dividesNAT-DR1  _ " [50,50]50) where
  "k dividesNAT-DR1 l \<equiv> k dividesINT-1R1 l"

mtheorem nat_d_def_3:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"redefine pred k dividesNAT-DR1 l means
   ex t be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 t"
proof
(*compatibility*)
  show "k dividesNAT-DR1 l iff ( ex t be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 t)"
  proof-
    have "(k dividesINT-1R1 l implies ( ex t be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 t)) &  not ( not ( for t be NatNAT-1M1 holds  not l =HIDDENR1 k *XCMPLX-0K3 t) &  not k dividesINT-1R1 l)"
    proof(rule conjMI)
      show "k dividesINT-1R1 l implies ( ex t be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 t)"
      proof(rule impI)
        assume A1: "k dividesINT-1R1 l"
        show " ex t be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 t"
        proof-
          have " ex tVar1 be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 tVar1"
          proof-
            obtain t where
              [ty]:"t be IntegerINT-1M1" and 
              A2: "l =HIDDENR1 k *XCMPLX-0K3 t"
              using A1 int_1_def_3 sorry
            show " ex tVar1 be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 tVar1"
            proof-
              have cases: "0NUMBERSK6 <XXREAL-0R3 l or l =HIDDENR1 0NUMBERSK6"
                 sorry
              have case1: "0NUMBERSK6 <XXREAL-0R3 l implies ( ex tVar1 be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 tVar1)"
              proof(rule impI)
                assume "0NUMBERSK6 <XXREAL-0R3 l"
                then have "0NUMBERSK6 <=XXREAL-0R1 t"
                  using A2 sorry
                then have 
                  [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using int_1_th_3 sorry
                show " ex tVar1 be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 tVar1"
                proof(rule bexI[of _ "t"])
                  show "l =HIDDENR1 k *XCMPLX-0K3 t"
                    using A2 sorry
                qed "sorry"
              qed
              have case2: "l =HIDDENR1 0NUMBERSK6 implies ( ex tVar2 be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 tVar2)"
              proof(rule impI)
                assume A3: "l =HIDDENR1 0NUMBERSK6"
                show " ex tVar2 be NatNAT-1M1 st l =HIDDENR1 k *XCMPLX-0K3 tVar2"
                proof(rule bexI[of _ "0NUMBERSK6"])
                  show "l =HIDDENR1 k *XCMPLX-0K3 (0NUMBERSK6)"
                    using A3 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
      qed
      show " not ( not ( for t be NatNAT-1M1 holds  not l =HIDDENR1 k *XCMPLX-0K3 t) &  not k dividesINT-1R1 l)"
        using int_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem NAT_DR1_reflexivity:
" for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds l dividesNAT-DR1 l"
proof-
  have " for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  ex t be NatNAT-1M1 st l =HIDDENR1 l *XCMPLX-0K3 t"
  proof-
    have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not ( for t be NatNAT-1M1 holds  not i =HIDDENR1 i *XCMPLX-0K3 t)"
    proof(rule ballI)
      fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
      have "i =HIDDENR1 i *XCMPLX-0K3 \<one>\<^sub>M"
         sorry
      thus " not ( for t be NatNAT-1M1 holds  not i =HIDDENR1 i *XCMPLX-0K3 t)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using nat_d_def_3 sorry
qed

mtheorem nat_d_th_3:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds j dividesNAT-DR1 i iff i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (j dividesNAT-DR1 i implies i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j)) &  not (i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j) &  not j dividesNAT-DR1 i)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "j dividesNAT-DR1 i implies i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j)"
    proof(rule impI)
      assume "j dividesNAT-DR1 i"
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A1: "i =HIDDENR1 j *XCMPLX-0K3 k"
         sorry
      have A2: "i =HIDDENR1 j *XCMPLX-0K3 k +NAT-1K1 0NUMBERSK6"
        using A1 sorry
      have "j <>HIDDENR2 0NUMBERSK6 implies i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j)"
      proof(rule impI)
        assume A3: "j <>HIDDENR2 0NUMBERSK6"
        then have A4: "i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j) +XCMPLX-0K2 (i modNAT-DK2 j)"
          using int_1_th_59 sorry
        have "i modNAT-DK2 j <XXREAL-0R3 j"
          using A3 nat_d_th_1 sorry
        thus "i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j)"
          using A2 A4 nat_1_th_18 sorry
      qed
      thus "i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j)"
        using A1 sorry
    qed
    show " not (i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j) &  not j dividesNAT-DR1 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_4:
" for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & j dividesNAT-DR1 h implies i dividesNAT-DR1 h"
  using int_2_th_9 sorry

mtheorem nat_d_th_5:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & j dividesNAT-DR1 i implies i =HIDDENR1 j"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & j dividesNAT-DR1 i implies i =HIDDENR1 j"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i dividesNAT-DR1 j"
      and A2: "j dividesNAT-DR1 i"
    have A3: "j =HIDDENR1 i *XCMPLX-0K3 (j divNAT-DK1 i)"
      using A1 nat_d_th_3 sorry
    have "i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j)"
      using A2 nat_d_th_3 sorry
    then have A4: "i *XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 (i *XCMPLX-0K3 (j divNAT-DK1 i))*XCMPLX-0K3 (i divNAT-DK1 j)"
      using A3 sorry
    also have "... = i *XCMPLX-0K3 ((j divNAT-DK1 i)*XCMPLX-0K3 (i divNAT-DK1 j))"
       sorry
    finally have "i *XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 i *XCMPLX-0K3 ((j divNAT-DK1 i)*XCMPLX-0K3 (i divNAT-DK1 j))"
       sorry
    have A5: "i =HIDDENR1 0NUMBERSK6 implies i =HIDDENR1 j"
      using A3 sorry
    have "(j divNAT-DK1 i)*XCMPLX-0K3 (i divNAT-DK1 j) =XBOOLE-0R4 \<one>\<^sub>M implies i =HIDDENR1 j"
    proof(rule impI)
      assume "(j divNAT-DK1 i)*XCMPLX-0K3 (i divNAT-DK1 j) =XBOOLE-0R4 \<one>\<^sub>M"
      then have "j divNAT-DK1 i =XBOOLE-0R4 \<one>\<^sub>M"
        using nat_1_th_15 sorry
      thus "i =HIDDENR1 j"
        using A3 sorry
    qed
    thus "i =HIDDENR1 j"
      using A4 A5 xcmplx_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_6:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 0NUMBERSK6 & \<one>\<^sub>M dividesNAT-DR1 i"
  using int_2_th_12 sorry

mtheorem nat_d_th_7:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 j & i dividesNAT-DR1 j implies i <=XXREAL-0R1 j"
  using int_2_th_27 sorry

mtheorem nat_d_th_8:
" for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & i dividesNAT-DR1 h implies i dividesNAT-DR1 j +XCMPLX-0K2 h"
proof-
  have " for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & i dividesNAT-DR1 h implies i dividesNAT-DR1 j +XCMPLX-0K2 h"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix h assume [ty]: "h be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i dividesNAT-DR1 j"
      and A2: "i dividesNAT-DR1 h"
    have A3: "j =HIDDENR1 i *XCMPLX-0K3 (j divNAT-DK1 i)"
      using A1 nat_d_th_3 sorry
    have "h =HIDDENR1 i *XCMPLX-0K3 (h divNAT-DK1 i)"
      using A2 nat_d_th_3 sorry
    then have "j +XCMPLX-0K2 h =XBOOLE-0R4 i *XCMPLX-0K3 ((j divNAT-DK1 i)+XCMPLX-0K2 (h divNAT-DK1 i))"
      using A3 sorry
    thus "i dividesNAT-DR1 j +XCMPLX-0K2 h"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_9:
" for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j implies i dividesNAT-DR1 j *XCMPLX-0K3 h"
  using int_2_th_2 sorry

mtheorem nat_d_th_10:
" for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & i dividesNAT-DR1 j +XCMPLX-0K2 h implies i dividesNAT-DR1 h"
proof-
  have " for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & i dividesNAT-DR1 j +XCMPLX-0K2 h implies i dividesNAT-DR1 h"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix h assume [ty]: "h be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i dividesNAT-DR1 j"
      and A2: "i dividesNAT-DR1 j +XCMPLX-0K2 h"
    obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A3: "j +XCMPLX-0K2 h =XBOOLE-0R4 i *XCMPLX-0K3 t"
      using A2 sorry
    obtain u where
      [ty]:"u be NatNAT-1M1" and 
      A4: "j =HIDDENR1 i *XCMPLX-0K3 u"
      using A1 sorry
    have "i <>HIDDENR2 0NUMBERSK6 implies i dividesNAT-DR1 h"
    proof(rule impI)
      assume A5: "i <>HIDDENR2 0NUMBERSK6"
      then have A6: "h =HIDDENR1 i *XCMPLX-0K3 (h divNAT-DK1 i) +XCMPLX-0K2 (h modNAT-DK2 i)"
        using int_1_th_59 sorry
      have A7: "j +XCMPLX-0K2 (i *XCMPLX-0K3 (h divNAT-DK1 i) +XCMPLX-0K2 (h modNAT-DK2 i)) =XBOOLE-0R4 i *XCMPLX-0K3 (u +XCMPLX-0K2 (h divNAT-DK1 i)) +XCMPLX-0K2 (h modNAT-DK2 i)"
        using A4 sorry
      have A8: "h modNAT-DK2 i <XXREAL-0R3 i"
        using A5 nat_d_th_1 sorry
      have "j +XCMPLX-0K2 h =XBOOLE-0R4 i *XCMPLX-0K3 t +NAT-1K1 0NUMBERSK6"
        using A3 sorry
      then have "h modNAT-DK2 i =XBOOLE-0R4 0NUMBERSK6"
        using A6 A7 A8 nat_1_th_18 sorry
      thus "i dividesNAT-DR1 h"
        using A6 sorry
    qed
    thus "i dividesNAT-DR1 h"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_11:
" for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & i dividesNAT-DR1 h implies i dividesNAT-DR1 j modNAT-DK2 h"
proof-
  have " for h be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i dividesNAT-DR1 j & i dividesNAT-DR1 h implies i dividesNAT-DR1 j modNAT-DK2 h"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix h assume [ty]: "h be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i dividesNAT-DR1 j"
      and A2: "i dividesNAT-DR1 h"
    have A3: "h =HIDDENR1 0NUMBERSK6 implies i dividesNAT-DR1 j modNAT-DK2 h"
    proof(rule impI)
      assume "h =HIDDENR1 0NUMBERSK6"
      then have "j modNAT-DK2 h =XBOOLE-0R4 0NUMBERSK6"
        using nat_d_def_2 sorry
      thus "i dividesNAT-DR1 j modNAT-DK2 h"
        using nat_d_th_6 sorry
    qed
    have "h <>HIDDENR2 0NUMBERSK6 implies i dividesNAT-DR1 j modNAT-DK2 h"
    proof(rule impI)
      assume "h <>HIDDENR2 0NUMBERSK6"
      then have A4: "j =HIDDENR1 h *XCMPLX-0K3 (j divNAT-DK1 h) +XCMPLX-0K2 (j modNAT-DK2 h)"
        using int_1_th_59 sorry
      have "i dividesNAT-DR1 h *XCMPLX-0K3 (j divNAT-DK1 h)"
        using A2 nat_d_th_9 sorry
      thus "i dividesNAT-DR1 j modNAT-DK2 h"
        using A1 A4 nat_d_th_10 sorry
    qed
    thus "i dividesNAT-DR1 j modNAT-DK2 h"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) NAT_DK5(" _ lcmNAT-DK5  _ " [132,132]132) where
  "k lcmNAT-DK5 n \<equiv> k lcmINT-2K2 n"

mtheorem nat_d_def_4:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"redefine func k lcmNAT-DK5 n \<rightarrow> setHIDDENM2 means
  \<lambda>it. (k dividesNAT-DR1 it & n dividesNAT-DR1 it) & ( for m be NatNAT-1M1 holds k dividesNAT-DR1 m & n dividesNAT-DR1 m implies it dividesNAT-DR1 m)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 k lcmNAT-DK5 n iff (k dividesNAT-DR1 it & n dividesNAT-DR1 it) & ( for m be NatNAT-1M1 holds k dividesNAT-DR1 m & n dividesNAT-DR1 m implies it dividesNAT-DR1 m)"
  proof-
    have " for IT be NatNAT-1M1 holds (IT =XBOOLE-0R4 k lcmINT-2K2 n implies (k dividesNAT-DR1 IT & n dividesNAT-DR1 IT) & ( for m be NatNAT-1M1 holds k dividesNAT-DR1 m & n dividesNAT-DR1 m implies IT dividesNAT-DR1 m)) & (k dividesNAT-DR1 IT & (n dividesNAT-DR1 IT & ( for m be NatNAT-1M1 holds k dividesNAT-DR1 m & n dividesNAT-DR1 m implies IT dividesNAT-DR1 m)) implies IT =HIDDENR1 k lcmINT-2K2 n)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
      fix IT assume [ty]: "IT be NatNAT-1M1"
      show "IT =XBOOLE-0R4 k lcmINT-2K2 n implies (k dividesNAT-DR1 IT & n dividesNAT-DR1 IT) & ( for m be NatNAT-1M1 holds k dividesNAT-DR1 m & n dividesNAT-DR1 m implies IT dividesNAT-DR1 m)"
        using int_2_def_1 sorry
      assume A1: "k dividesNAT-DR1 IT"
        and A2: "n dividesNAT-DR1 IT"
        and A3: " for m be NatNAT-1M1 holds k dividesNAT-DR1 m & n dividesNAT-DR1 m implies IT dividesNAT-DR1 m"
      have " for m be IntegerINT-1M1 holds k dividesINT-1R1 m & n dividesINT-1R1 m implies IT dividesINT-1R1 m"
      proof(rule ballI,rule impMI ,rule impI)
        fix m assume [ty]: "m be IntegerINT-1M1"
        have "m inHIDDENR3 INTINT-1K1"
          using int_1_def_2 sorry
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A4: "m =HIDDENR1 i or m =HIDDENR1 -XCMPLX-0K4 i"
          using int_1_def_1 sorry
        assume A5: "k dividesINT-1R1 m"
          and A6: "n dividesINT-1R1 m"
        have A7: "k dividesNAT-DR1 i"
          using A4 A5 int_2_th_10 sorry
        have "n dividesNAT-DR1 i"
          using A4 A6 int_2_th_10 sorry
        then have "IT dividesNAT-DR1 i"
          using A3 A7 sorry
        thus "IT dividesINT-1R1 m"
          using A4 int_2_th_10 sorry
      qed "sorry"
      thus "IT =HIDDENR1 k lcmINT-2K2 n"
        using A1 A2 int_2_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) NAT_DK6(" _ lcmNAT-DK6  _ " [132,132]132) where
  "k lcmNAT-DK6 n \<equiv> k lcmINT-2K2 n"

mtheorem nat_d_add_5:
  mlet "k be NatNAT-1M1", "n be NatNAT-1M1"
"cluster k lcmINT-2K2 n as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "k lcmINT-2K2 n be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

abbreviation(input) NAT_DK7(" _ gcdNAT-DK7  _ " [132,132]132) where
  "k gcdNAT-DK7 n \<equiv> k gcdINT-2K3 n"

mtheorem nat_d_def_5:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"redefine func k gcdNAT-DK7 n \<rightarrow> setHIDDENM2 means
  \<lambda>it. (it dividesNAT-DR1 k & it dividesNAT-DR1 n) & ( for m be NatNAT-1M1 holds m dividesNAT-DR1 k & m dividesNAT-DR1 n implies m dividesNAT-DR1 it)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 k gcdNAT-DK7 n iff (it dividesNAT-DR1 k & it dividesNAT-DR1 n) & ( for m be NatNAT-1M1 holds m dividesNAT-DR1 k & m dividesNAT-DR1 n implies m dividesNAT-DR1 it)"
  proof-
    have " for IT be NatNAT-1M1 holds (IT =XBOOLE-0R4 k gcdINT-2K3 n implies (IT dividesNAT-DR1 k & IT dividesNAT-DR1 n) & ( for m be NatNAT-1M1 holds m dividesNAT-DR1 k & m dividesNAT-DR1 n implies m dividesNAT-DR1 IT)) & (IT dividesNAT-DR1 k & (IT dividesNAT-DR1 n & ( for m be NatNAT-1M1 holds m dividesNAT-DR1 k & m dividesNAT-DR1 n implies m dividesNAT-DR1 IT)) implies IT =HIDDENR1 k gcdINT-2K3 n)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
      fix IT assume [ty]: "IT be NatNAT-1M1"
      show "IT =XBOOLE-0R4 k gcdINT-2K3 n implies (IT dividesNAT-DR1 k & IT dividesNAT-DR1 n) & ( for m be NatNAT-1M1 holds m dividesNAT-DR1 k & m dividesNAT-DR1 n implies m dividesNAT-DR1 IT)"
        using int_2_def_2 sorry
      assume A1: "IT dividesNAT-DR1 k"
        and A2: "IT dividesNAT-DR1 n"
        and A3: " for m be NatNAT-1M1 holds m dividesNAT-DR1 k & m dividesNAT-DR1 n implies m dividesNAT-DR1 IT"
      have " for m be IntegerINT-1M1 holds m dividesINT-1R1 k & m dividesINT-1R1 n implies m dividesINT-1R1 IT"
      proof(rule ballI,rule impMI ,rule impI)
        fix m assume [ty]: "m be IntegerINT-1M1"
        have "m inHIDDENR3 INTINT-1K1"
          using int_1_def_2 sorry
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A4: "m =HIDDENR1 i or m =HIDDENR1 -XCMPLX-0K4 i"
          using int_1_def_1 sorry
        assume A5: "m dividesINT-1R1 k"
          and A6: "m dividesINT-1R1 n"
        have A7: "i dividesNAT-DR1 k"
          using A4 A5 int_2_th_10 sorry
        have "i dividesNAT-DR1 n"
          using A4 A6 int_2_th_10 sorry
        then have "i dividesNAT-DR1 IT"
          using A3 A7 sorry
        thus "m dividesINT-1R1 IT"
          using A4 int_2_th_10 sorry
      qed "sorry"
      thus "IT =HIDDENR1 k gcdINT-2K3 n"
        using A1 A2 int_2_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) NAT_DK8(" _ gcdNAT-DK8  _ " [132,132]132) where
  "k gcdNAT-DK8 n \<equiv> k gcdINT-2K3 n"

mtheorem nat_d_add_6:
  mlet "k be NatNAT-1M1", "n be NatNAT-1M1"
"cluster k gcdINT-2K3 n as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "k gcdINT-2K3 n be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

(*\$N Correctness of Euclid's Algorithm*)
(*\$N Greatest Common Divisor Algorithm*)
theorem nat_d_sch_1:
  fixes Qf1 af0 bf0 
  assumes
[ty_func]: "\<And> x1. x1 be NatNAT-1M1 \<Longrightarrow> Qf1(x1) be NatNAT-1M1" and
  [ty]: "af0 be NatNAT-1M1" and
  [ty]: "bf0 be NatNAT-1M1" and
   A1: "0NUMBERSK6 <XXREAL-0R3 bf0 & bf0 <XXREAL-0R3 af0" and
   A2: "Qf1(0NUMBERSK6) =XBOOLE-0R4 af0 & Qf1(\<one>\<^sub>M) =XBOOLE-0R4 bf0" and
   A3: " for n be NatNAT-1M1 holds Qf1(n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Qf1(n) modNAT-DK4 Qf1(n +NAT-1K1 \<one>\<^sub>M)"
  shows " ex n be NatNAT-1M1 st Qf1(n) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & Qf1(n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
  proof-
    have " ex tVar4 be NatNAT-1M1 st Qf1(tVar4) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & Qf1(tVar4 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
    proof-
      let ?P = "\<lambda>Lamb1.  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st Lamb1 =XBOOLE-0R4 Qf1(n)"
      have A4: " ex k be NatNAT-1M1 st ?P(k)"
        using A2 sorry
      have A5: " for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & ?P(k) implies ( ex n be NatNAT-1M1 st n <XXREAL-0R3 k & ?P(n))"
      proof-
        have " for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k =XBOOLE-0R4 Qf1(n)) implies  not ( for n be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 k & ( ex nc be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 Qf1(nc))))"
        proof(rule ballI,rule impMI ,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A6: "k <>HIDDENR2 0NUMBERSK6"
            and A7: " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k =XBOOLE-0R4 Qf1(n)"
          obtain n where
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A8: "k =XBOOLE-0R4 Qf1(n)"
            using A7 sorry
          obtain Q where 
            [ty]:"Q be ElementSUBSET-1M1-of NATNUMBERSK1" and QDef:"Q = Qf1(n +NAT-1K1 \<one>\<^sub>M)"
            using ordinal1_def_12 sorry
          have A9: "n =XBOOLE-0R4 0NUMBERSK6 implies Q <XXREAL-0R3 k"
            using A1 A2 A8 sorry
          have "( ex m be NatNAT-1M1 st n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M) implies Qf1(n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 k & ( ex m be ElementSUBSET-1M1-of omegaORDINAL1K4 st Qf1(n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Qf1(m))"
          proof(rule impI,rule conjMI)
            assume Given: " ex m be NatNAT-1M1 st n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A10: "n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
               sorry
            obtain m1 where 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = m"
              using ordinal1_def_12 sorry
            have "Qf1(m1 +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Qf1(m1) modNAT-DK4 Qf1(m1 +NAT-1K1 \<one>\<^sub>M)"
              using A3 sorry
            thus "Qf1(n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 k"
              using A6 A8 A10 nat_d_th_1 sorry
            obtain m where 
              [ty]:"m be ElementSUBSET-1M1-of omegaORDINAL1K4" and mDef:"m = n +NAT-1K1 \<one>\<^sub>M"
               sorry
            show " ex m be ElementSUBSET-1M1-of omegaORDINAL1K4 st Qf1(n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Qf1(m)"
            proof(rule bexI[of _ "m"])
              show "Qf1(n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Qf1(m)"
                 sorry
            qed "sorry"
          qed
          thus " not ( for n be NatNAT-1M1 holds  not ( not n <XXREAL-0R3 k & ( ex nc be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 Qf1(nc))))"
            using A9 nat_1_th_6 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A11: "?P(0NUMBERSK6)"
        using nat_1_sch_7 A4 A5 sorry
      let ?Q = "\<lambda>Lamb1. 0NUMBERSK6 =XBOOLE-0R4 Qf1(Lamb1)"
      have A12: " ex n be NatNAT-1M1 st ?Q(n)"
        using A11 sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A13: "?Q(k) & ( for n be NatNAT-1M1 holds ?Q(n) implies k <=XXREAL-0R1 n)"
        using nat_1_sch_5 A12 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A14: "k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
        using A1 A2 A13 nat_1_th_6 sorry
      have 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      show " ex tVar4 be NatNAT-1M1 st Qf1(tVar4) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0 & Qf1(tVar4 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
      proof(rule bexI[of _ "n"],rule conjMI)
        let ?PP = "\<lambda>Lamb1. Qf1(n) dividesNAT-DR1 Qf1(Lamb1) & Qf1(n) dividesNAT-DR1 Qf1(Lamb1 +NAT-1K1 \<one>\<^sub>M)"
        have "?PP(n)"
          using A13 A14 nat_d_th_6 sorry
        then have A15: " ex k be NatNAT-1M1 st ?PP(k)"
           sorry
        have A16: " for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & ?PP(k) implies ( ex m be NatNAT-1M1 st m <XXREAL-0R3 k & ?PP(m))"
        proof-
          have " for l be NatNAT-1M1 holds l <>HIDDENR2 0NUMBERSK6 & (Qf1(n) dividesNAT-DR1 Qf1(l) & Qf1(n) dividesNAT-DR1 Qf1(l +NAT-1K1 \<one>\<^sub>M)) implies ( ex tVar5 be NatNAT-1M1 st tVar5 <XXREAL-0R3 l & (Qf1(n) dividesNAT-DR1 Qf1(tVar5) & Qf1(n) dividesNAT-DR1 Qf1(tVar5 +NAT-1K1 \<one>\<^sub>M)))"
          proof(rule ballI,rule impMI ,rule impMI ,rule impI)
            fix l assume [ty]: "l be NatNAT-1M1"
            assume A17: "l <>HIDDENR2 0NUMBERSK6"
              and A18: "Qf1(n) dividesNAT-DR1 Qf1(l)"
              and A19: "Qf1(n) dividesNAT-DR1 Qf1(l +NAT-1K1 \<one>\<^sub>M)"
            obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A20: "l =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
              using A17 nat_1_th_6 sorry
            have 
              [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            show " ex tVar5 be NatNAT-1M1 st tVar5 <XXREAL-0R3 l & (Qf1(n) dividesNAT-DR1 Qf1(tVar5) & Qf1(n) dividesNAT-DR1 Qf1(tVar5 +NAT-1K1 \<one>\<^sub>M))"
            proof(rule bexI[of _ "m"],rule conjMI,rule conjMI)
              have A21: "m <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_11 sorry
              have "m <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M"
                 sorry
              thus "m <XXREAL-0R3 l"
                using A20 A21 xxreal_0_th_1 sorry
              have A22: "Qf1(m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 implies Qf1(n) dividesNAT-DR1 Qf1(m)"
              proof(rule impI)
                assume A23: "Qf1(m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
                have "m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 k implies Qf1(n) dividesNAT-DR1 Qf1(m)"
                proof(rule impI)
                  assume A24: "m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 k"
                  have "k <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                    using A13 A23 sorry
                  then have "k <XXREAL-0R3 m +NAT-1K1 \<one>\<^sub>M"
                    using A24 xxreal_0_th_1 sorry
                  then have A25: "k <=XXREAL-0R1 m"
                    using nat_1_th_13 sorry
                  let ?Q = "\<lambda>Lamb1. k <=XXREAL-0R1 Lamb1 implies Qf1(Lamb1) =XBOOLE-0R4 0NUMBERSK6"
                  have A26: "?Q(0NUMBERSK6)"
                    using A13 sorry
                  have A27: " for m be NatNAT-1M1 holds ?Q(m) implies ?Q(m +NAT-1K1 \<one>\<^sub>M)"
                  proof-
                    have " for m be NatNAT-1M1 holds (k <=XXREAL-0R1 m implies Qf1(m) =XBOOLE-0R4 0NUMBERSK6) & k <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M implies Qf1(m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
                    proof(rule ballI,rule impMI ,rule impI)
                      fix m assume [ty]: "m be NatNAT-1M1"
                      assume A28: "k <=XXREAL-0R1 m implies Qf1(m) =XBOOLE-0R4 0NUMBERSK6"
                        and A29: "k <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                      have "k <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M implies Qf1(m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
                      proof(rule impI)
                        assume "k <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M"
                        then have A30: "k <XXREAL-0R3 m +NAT-1K1 \<one>\<^sub>M"
                          using A29 xxreal_0_th_1 sorry
                        then obtain l where
                          [ty]:"l be NatNAT-1M1" and 
                          A31: "m =XBOOLE-0R4 l +NAT-1K1 \<one>\<^sub>M"
                          using A1 A2 A28 nat_1_th_6 nat_1_th_13 sorry
                        have 
                          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
                          using ordinal1_def_12 sorry
                        have "Qf1(l +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Qf1(l) modNAT-DK4 Qf1(l +NAT-1K1 \<one>\<^sub>M)"
                          using A3 sorry
                        thus "Qf1(m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
                          using A28 A30 A31 nat_d_def_2 nat_1_th_13 sorry
                      qed
                      thus "Qf1(m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
                        using A13 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have " for m be NatNAT-1M1 holds ?Q(m)"
                    using nat_1_sch_2 A26 A27 sorry
                  then have "Qf1(m) =XBOOLE-0R4 0NUMBERSK6"
                    using A25 sorry
                  thus "Qf1(n) dividesNAT-DR1 Qf1(m)"
                    using nat_d_th_6 sorry
                qed
                thus "Qf1(n) dividesNAT-DR1 Qf1(m)"
                  using A14 sorry
              qed
              have "Qf1(m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6 implies Qf1(n) dividesNAT-DR1 Qf1(m)"
              proof(rule impI)
                assume A32: "Qf1(m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
                have "Qf1(m +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Qf1(m) modNAT-DK4 Qf1(m +NAT-1K1 \<one>\<^sub>M)"
                  using A3 sorry
                then have A33: "Qf1(m) =XBOOLE-0R4 Qf1(m +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (Qf1(m) divNAT-DK3 Qf1(m +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 Qf1(m +NAT-1K1 \<two>\<^sub>M)"
                  using A32 int_1_th_59 sorry
                have "Qf1(n) dividesNAT-DR1 Qf1(m +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (Qf1(m) divNAT-DK3 Qf1(m +NAT-1K1 \<one>\<^sub>M))"
                  using A18 A20 nat_d_th_9 sorry
                thus "Qf1(n) dividesNAT-DR1 Qf1(m)"
                  using A19 A20 A33 nat_d_th_8 sorry
              qed
              thus "Qf1(n) dividesNAT-DR1 Qf1(m)"
                using A22 sorry
              show "Qf1(n) dividesNAT-DR1 Qf1(m +NAT-1K1 \<one>\<^sub>M)"
                using A18 A20 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "(Qf1(n) dividesNAT-DR1 af0 & Qf1(n) dividesNAT-DR1 bf0) & ( for m be NatNAT-1M1 holds m dividesNAT-DR1 af0 & m dividesNAT-DR1 bf0 implies m dividesNAT-DR1 Qf1(n))"
        proof(rule conjMI,rule ballI,rule impMI ,rule impI)
          have "?PP(0NUMBERSK6)"
            using nat_1_sch_7 A15 A16 sorry
          thus "Qf1(n) dividesNAT-DR1 af0 & Qf1(n) dividesNAT-DR1 bf0"
            using A2 sorry
          fix m assume [ty]: "m be NatNAT-1M1"
          let ?P1 = "\<lambda>Lamb1. m dividesNAT-DR1 Qf1(Lamb1) & m dividesNAT-DR1 Qf1(Lamb1 +NAT-1K1 \<one>\<^sub>M)"
          assume A34: "m dividesNAT-DR1 af0"
            and A35: "m dividesNAT-DR1 bf0"
          have A36: "?P1(0NUMBERSK6)"
            using A2 A34 A35 sorry
          have A37: " for k be NatNAT-1M1 holds ?P1(k) implies ?P1(k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for k be NatNAT-1M1 holds m dividesNAT-DR1 Qf1(k) & m dividesNAT-DR1 Qf1(k +NAT-1K1 \<one>\<^sub>M) implies m dividesNAT-DR1 Qf1(k +NAT-1K1 \<one>\<^sub>M) & m dividesNAT-DR1 Qf1((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
            proof(rule ballI,rule impMI ,rule impI,rule conjMI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A38: "m dividesNAT-DR1 Qf1(k)"
                and A39: "m dividesNAT-DR1 Qf1(k +NAT-1K1 \<one>\<^sub>M)"
              show "m dividesNAT-DR1 Qf1(k +NAT-1K1 \<one>\<^sub>M)"
                using A39 sorry
              have "Qf1(k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Qf1(k) modNAT-DK4 Qf1(k +NAT-1K1 \<one>\<^sub>M)"
                using A3 sorry
              thus "m dividesNAT-DR1 Qf1((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
                using A38 A39 nat_d_th_11 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for k be NatNAT-1M1 holds ?P1(k)"
            using nat_1_sch_2 A36 A37 sorry
          thus "m dividesNAT-DR1 Qf1(n)"
             sorry
        qed "sorry"
        thus "Qf1(n) =XBOOLE-0R4 af0 gcdNAT-DK8 bf0"
          using nat_d_def_5 sorry
        show "Qf1(n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
          using A13 A14 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem nat_d_th_12:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 or n modNAT-DK2 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n modNAT-DK2 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "n modNAT-DK2 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6"
    have A2: "\<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
       sorry
    have "n modNAT-DK2 \<two>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M"
      using nat_d_th_1 sorry
    then have A3: "n modNAT-DK2 \<two>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M"
      using A2 nat_1_th_13 sorry
    have "n modNAT-DK2 \<two>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 nat_1_th_14 sorry
    thus "n modNAT-DK2 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using A3 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_13:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k *XCMPLX-0K3 n modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k *XCMPLX-0K3 n modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "k be NatNAT-1M1 & n be NatNAT-1M1"
      using tarski_th_1 sorry
    show "k *XCMPLX-0K3 n modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have cases: "k =HIDDENR1 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "k =HIDDENR1 0NUMBERSK6 implies k *XCMPLX-0K3 n modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "k =HIDDENR1 0NUMBERSK6"
        thus "k *XCMPLX-0K3 n modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
          using nat_d_def_2 sorry
      qed
      have case2: "k <>HIDDENR2 0NUMBERSK6 implies k *XCMPLX-0K3 n modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
      proof(rule impI)
        assume A1: "k <>HIDDENR2 0NUMBERSK6"
        have "k *XCMPLX-0K3 n =XBOOLE-0R4 k *XCMPLX-0K3 n +NAT-1K1 0NUMBERSK6"
           sorry
        thus "k *XCMPLX-0K3 n modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
          using A0 A1 nat_d_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_14:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k >XXREAL-0R4 \<one>\<^sub>M implies \<one>\<^sub>M modNAT-DK2 k =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k >XXREAL-0R4 \<one>\<^sub>M implies \<one>\<^sub>M modNAT-DK2 k =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "k >XXREAL-0R4 \<one>\<^sub>M"
    have "\<one>\<^sub>M =XBOOLE-0R4 k *XCMPLX-0K3 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M"
       sorry
    thus "\<one>\<^sub>M modNAT-DK2 k =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 nat_d_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_15:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 k -XCMPLX-0K6 m *XCMPLX-0K3 n implies l modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6 & l =HIDDENR1 k -XCMPLX-0K6 m *XCMPLX-0K3 n implies l modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix l assume [ty]: "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix m assume [ty]: "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
      and A2: "l =HIDDENR1 k -XCMPLX-0K6 m *XCMPLX-0K3 n"
    show "l modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have cases: "n =HIDDENR1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "n =HIDDENR1 0NUMBERSK6 implies l modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "n =HIDDENR1 0NUMBERSK6"
        thus "l modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
          using A1 A2 sorry
      qed
      have case2: "n <>HIDDENR2 0NUMBERSK6 implies l modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "n <>HIDDENR2 0NUMBERSK6"
        then obtain t where
          [ty]:"t be NatNAT-1M1" and 
          A3: "k =HIDDENR1 n *XCMPLX-0K3 t +NAT-1K1 0NUMBERSK6"and A4: "0NUMBERSK6 <XXREAL-0R3 n"
          using A1 nat_d_def_2 sorry
        have A5: "l =HIDDENR1 n *XCMPLX-0K3 (t -XCMPLX-0K6 m) +XCMPLX-0K2 0NUMBERSK6"
          using A2 A3 sorry
        have "t <XXREAL-0R3 m +NAT-1K1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "t <XXREAL-0R3 m +NAT-1K1 0NUMBERSK6"
          then have "t -XCMPLX-0K6 m <XXREAL-0R3 0NUMBERSK6"
            using xreal_1_th_19 sorry
          then have "l <XXREAL-0R3 n *XCMPLX-0K3 (0NUMBERSK6)"
            using A4 A5 xreal_1_th_68 sorry
          thus " False "
             sorry
        qed
        then have "t -XCMPLX-0K6 m be ElementSUBSET-1M1-of NATNUMBERSK1"
          using nat_1_th_21 sorry
        thus "l modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
          using A4 A5 nat_d_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_16:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (n <>HIDDENR2 0NUMBERSK6 & k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6) & l <XXREAL-0R3 n implies (k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 l"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n <>HIDDENR2 0NUMBERSK6 & (k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6 & l <XXREAL-0R3 n) implies (k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 l"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix l assume [ty]: "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "(k be NatNAT-1M1 & n be NatNAT-1M1) & l be NatNAT-1M1"
      using tarski_th_1 sorry
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
      and A2: "k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
      and A3: "l <XXREAL-0R3 n"
    have " ex t be NatNAT-1M1 st k =HIDDENR1 n *XCMPLX-0K3 t +NAT-1K1 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 n"
      using A1 A2 nat_d_def_2 sorry
    thus "(k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 l"
      using A0 A3 nat_d_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_17:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6 implies (k +XCMPLX-0K2 l)modNAT-DK2 n =XBOOLE-0R4 l modNAT-DK2 n"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6 implies (k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 l modNAT-DK2 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix l assume [ty]: "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
    show "(k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 l modNAT-DK2 n"
    proof-
      have cases: "n =HIDDENR1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "n =HIDDENR1 0NUMBERSK6 implies (k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 l modNAT-DK2 n"
      proof(rule impI)
        assume A2: "n =HIDDENR1 0NUMBERSK6"
        then have "(k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 0NUMBERSK6"
          using nat_d_def_2 sorry
        also have "... = l modNAT-DK2 n"
          using A2 nat_d_def_2 sorry
        finally show "(k +XCMPLX-0K2 l)modNAT-DK2 n =HIDDENR1 l modNAT-DK2 n"
           sorry
      qed
      have case2: "n <>HIDDENR2 0NUMBERSK6 implies (k +XCMPLX-0K2 l)modNAT-DK2 n =XBOOLE-0R4 l modNAT-DK2 n"
      proof(rule impI)
        assume A3: "n <>HIDDENR2 0NUMBERSK6"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A4: "k =HIDDENR1 n *XCMPLX-0K3 m +NAT-1K1 0NUMBERSK6"and "0NUMBERSK6 <XXREAL-0R3 n"
          using A1 nat_d_def_2 sorry
        obtain t where
          [ty]:"t be NatNAT-1M1" and 
          A5: "l =HIDDENR1 n *XCMPLX-0K3 t +XCMPLX-0K2 (l modNAT-DK2 n)"and A6: "l modNAT-DK2 n <XXREAL-0R3 n"
          using A3 nat_d_def_2 sorry
        have "k +XCMPLX-0K2 l =XBOOLE-0R4 n *XCMPLX-0K3 (m +XCMPLX-0K2 t) +XCMPLX-0K2 (l modNAT-DK2 n)"
          using A4 A5 sorry
        thus "(k +XCMPLX-0K2 l)modNAT-DK2 n =XBOOLE-0R4 l modNAT-DK2 n"
          using A6 nat_d_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_18:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <>HIDDENR2 0NUMBERSK6 implies k *XCMPLX-0K3 n divNAT-DK1 k =HIDDENR1 n"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <>HIDDENR2 0NUMBERSK6 implies k *XCMPLX-0K3 n divNAT-DK1 k =HIDDENR1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "k be NatNAT-1M1 & n be NatNAT-1M1"
      using tarski_th_1 sorry
    assume A1: "k <>HIDDENR2 0NUMBERSK6"
    have "k *XCMPLX-0K3 n =XBOOLE-0R4 k *XCMPLX-0K3 n +NAT-1K1 0NUMBERSK6"
       sorry
    thus "k *XCMPLX-0K3 n divNAT-DK1 k =HIDDENR1 n"
      using A0 A1 nat_d_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_19:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6 implies (k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 (k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for l be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6 implies (k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 (k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix l assume [ty]: "l be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "k modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
    show "(k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 (k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)"
    proof-
      have cases: "n <>HIDDENR2 0NUMBERSK6 or n =HIDDENR1 0NUMBERSK6"
         sorry
      have case1: "n <>HIDDENR2 0NUMBERSK6 implies (k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 (k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)"
      proof(rule impI)
        assume A2: "n <>HIDDENR2 0NUMBERSK6"
        then have A3: "k =HIDDENR1 n *XCMPLX-0K3 (k divNAT-DK1 n) +NAT-1K1 0NUMBERSK6"
          using A1 int_1_th_59 sorry
        have A4: " ex t be NatNAT-1M1 st l =HIDDENR1 n *XCMPLX-0K3 t +XCMPLX-0K2 (l modNAT-DK2 n) & l modNAT-DK2 n <XXREAL-0R3 n"
          using A2 nat_d_def_2 sorry
        have "l =HIDDENR1 n *XCMPLX-0K3 (l divNAT-DK1 n) +XCMPLX-0K2 (l modNAT-DK2 n)"
          using A2 int_1_th_59 sorry
        then have "k +XCMPLX-0K2 l =XBOOLE-0R4 n *XCMPLX-0K3 ((k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)) +XCMPLX-0K2 (l modNAT-DK2 n)"
          using A3 sorry
        thus "(k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 (k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)"
          using A4 nat_d_def_1 sorry
      qed
      have case2: "n =HIDDENR1 0NUMBERSK6 implies (k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 (k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)"
      proof(rule impI)
        assume A5: "n =HIDDENR1 0NUMBERSK6"
        then have A6: "(k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 0NUMBERSK6"
          using nat_d_def_1 sorry
        have "k divNAT-DK1 n =XBOOLE-0R4 0NUMBERSK6"
          using A5 nat_d_def_1 sorry
        thus "(k +XCMPLX-0K2 l)divNAT-DK1 n =XBOOLE-0R4 (k divNAT-DK1 n)+XCMPLX-0K2 (l divNAT-DK1 n)"
          using A5 A6 nat_d_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
(*\$CT*)
mtheorem nat_d_th_21:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m modNAT-DK2 n =XBOOLE-0R4 (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m modNAT-DK2 n =XBOOLE-0R4 (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix m assume [ty]: "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "m modNAT-DK2 n =XBOOLE-0R4 (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n"
    proof-
      have cases: "n >XXREAL-0R4 0NUMBERSK6 or n =HIDDENR1 0NUMBERSK6"
         sorry
      have case1: "n >XXREAL-0R4 0NUMBERSK6 implies m modNAT-DK2 n =XBOOLE-0R4 (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n"
      proof(rule impI)
        assume A1: "n >XXREAL-0R4 0NUMBERSK6"
        have " for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m modNAT-DK2 n =HIDDENR1 t implies (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n =HIDDENR1 t"
        proof-
          have " for t be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m modNAT-DK2 n =HIDDENR1 t implies (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n =HIDDENR1 t"
          proof(rule ballI,rule impI)
            fix t assume [ty]: "t be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
            assume "m modNAT-DK2 n =HIDDENR1 t"
            then obtain q where
              [ty]:"q be NatNAT-1M1" and 
              A2: "m =HIDDENR1 n *XCMPLX-0K3 q +XCMPLX-0K2 t"and A3: "t <XXREAL-0R3 n"
              using A1 nat_d_def_2 sorry
            have A0: "((k be NatNAT-1M1 & m be NatNAT-1M1) & n be NatNAT-1M1) & t be NatNAT-1M1"
              using tarski_th_1 sorry
            have " ex p be NatNAT-1M1 st n *XCMPLX-0K3 k +XCMPLX-0K2 m =XBOOLE-0R4 n *XCMPLX-0K3 p +XCMPLX-0K2 t & t <XXREAL-0R3 n"
            proof-
              have " ex tVar6 be NatNAT-1M1 st n *XCMPLX-0K3 k +XCMPLX-0K2 m =XBOOLE-0R4 n *XCMPLX-0K3 tVar6 +XCMPLX-0K2 t &  not t <XXREAL-0R3 n"
              proof-
                obtain p where 
                  [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1" and pDef:"p = k +XCMPLX-0K2 q"
                  using ordinal1_def_12 sorry
                show " ex tVar6 be NatNAT-1M1 st n *XCMPLX-0K3 k +XCMPLX-0K2 m =XBOOLE-0R4 n *XCMPLX-0K3 tVar6 +XCMPLX-0K2 t &  not t <XXREAL-0R3 n"
                proof(rule bexI[of _ "p"])
                  show "n *XCMPLX-0K3 k +XCMPLX-0K2 m =XBOOLE-0R4 n *XCMPLX-0K3 p +XCMPLX-0K2 t &  not t <XXREAL-0R3 n"
                    using A2 A3 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            thus "(n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n =HIDDENR1 t"
              using A0 nat_d_def_2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "m modNAT-DK2 n =XBOOLE-0R4 (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n"
           sorry
      qed
      have case2: "n =HIDDENR1 0NUMBERSK6 implies m modNAT-DK2 n =XBOOLE-0R4 (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n"
      proof(rule impI)
        assume "n =HIDDENR1 0NUMBERSK6"
        thus "m modNAT-DK2 n =XBOOLE-0R4 (n *XCMPLX-0K3 k +XCMPLX-0K2 m)modNAT-DK2 n"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_22:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (p +XCMPLX-0K2 s)modNAT-DK2 n =XBOOLE-0R4 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
proof-
  have " for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (p +XCMPLX-0K2 s)modNAT-DK2 n =XBOOLE-0R4 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix s assume [ty]: "s be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "(p +XCMPLX-0K2 s)modNAT-DK2 n =XBOOLE-0R4 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
    proof-
      have cases: "n >XXREAL-0R4 0NUMBERSK6 or n =HIDDENR1 0NUMBERSK6"
         sorry
      have case1: "n >XXREAL-0R4 0NUMBERSK6 implies (p +XCMPLX-0K2 s)modNAT-DK2 n =XBOOLE-0R4 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
      proof(rule impI)
        assume "n >XXREAL-0R4 0NUMBERSK6"
        then have "(p +XCMPLX-0K2 s)modNAT-DK2 n =HIDDENR1 ((n *XCMPLX-0K3 (p divNAT-DK1 n) +XCMPLX-0K2 (p modNAT-DK2 n))+XCMPLX-0K2 s)modNAT-DK2 n"
          using int_1_th_59 sorry
        also have "... = (n *XCMPLX-0K3 (p divNAT-DK1 n) +XCMPLX-0K2 ((p modNAT-DK2 n)+XCMPLX-0K2 s))modNAT-DK2 n"
           sorry
        also have "... = ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
          using nat_d_th_21 sorry
        finally have "(p +XCMPLX-0K2 s)modNAT-DK2 n =HIDDENR1 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
           sorry
        thus "(p +XCMPLX-0K2 s)modNAT-DK2 n =XBOOLE-0R4 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
           sorry
      qed
      have case2: "n =HIDDENR1 0NUMBERSK6 implies (p +XCMPLX-0K2 s)modNAT-DK2 n =HIDDENR1 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
      proof(rule impI)
        assume A1: "n =HIDDENR1 0NUMBERSK6"
        then have "(p +XCMPLX-0K2 s)modNAT-DK2 n =HIDDENR1 0NUMBERSK6"
          using nat_d_def_2 sorry
        also have "... = ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
          using A1 nat_d_def_2 sorry
        finally show "(p +XCMPLX-0K2 s)modNAT-DK2 n =HIDDENR1 ((p modNAT-DK2 n)+XCMPLX-0K2 s)modNAT-DK2 n"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_23:
" for p be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for s be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (p +XCMPLX-0K2 s)modNAT-DK2 n =XBOOLE-0R4 (p +XCMPLX-0K2 (s modNAT-DK2 n))modNAT-DK2 n"
  using nat_d_th_22 sorry

mtheorem nat_d_th_24:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <XXREAL-0R3 n implies k modNAT-DK2 n =HIDDENR1 k"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  not ( not k <XXREAL-0R3 n &  not k modNAT-DK2 n =HIDDENR1 k)"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "k =HIDDENR1 n *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 k"
       sorry
    thus " not ( not k <XXREAL-0R3 n &  not k modNAT-DK2 n =HIDDENR1 k)"
      using nat_d_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_25:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "n modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have cases: "n >XXREAL-0R4 0NUMBERSK6 or n =HIDDENR1 0NUMBERSK6"
         sorry
      have case1: "n >XXREAL-0R4 0NUMBERSK6 implies n modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
      proof(rule impI)
        assume A1: "n >XXREAL-0R4 0NUMBERSK6"
        have "n =HIDDENR1 n *XCMPLX-0K3 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
           sorry
        thus "n modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
          using A1 nat_d_def_2 sorry
      qed
      have case2: "n =HIDDENR1 0NUMBERSK6 implies n modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "n =HIDDENR1 0NUMBERSK6"
        thus "n modNAT-DK2 n =XBOOLE-0R4 0NUMBERSK6"
          using nat_d_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_26:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 =XBOOLE-0R4 0NUMBERSK6 modNAT-DK2 n"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 =XBOOLE-0R4 0NUMBERSK6 modNAT-DK2 n"
  proof(rule ballI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "n =HIDDENR1 0NUMBERSK6 or n >XXREAL-0R4 0NUMBERSK6"
       sorry
    thus "0NUMBERSK6 =XBOOLE-0R4 0NUMBERSK6 modNAT-DK2 n"
      using nat_d_def_2 nat_d_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_27:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 j implies i divNAT-DK1 j =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 j implies (i divNAT-DK1 j <>HIDDENR2 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i <XXREAL-0R3 j"
    show "i divNAT-DK1 j <>HIDDENR2 0NUMBERSK6 implies  False "
    proof-
      have cases: "( ex j1 be NatNAT-1M1 st i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j) +XCMPLX-0K2 j1 & j1 <XXREAL-0R3 j) or i divNAT-DK1 j =XBOOLE-0R4 0NUMBERSK6 & j =HIDDENR1 0NUMBERSK6"
        using nat_d_def_1 sorry
      have case1: "( ex j1 be NatNAT-1M1 st i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j) +XCMPLX-0K2 j1 & j1 <XXREAL-0R3 j) implies (i divNAT-DK1 j <>HIDDENR2 0NUMBERSK6 implies  False )"
      proof(rule impI,rule impI)
        assume " ex j1 be NatNAT-1M1 st i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j) +XCMPLX-0K2 j1 & j1 <XXREAL-0R3 j"
        then obtain j1 where
          [ty]:"j1 be NatNAT-1M1" and 
          A2: "i =HIDDENR1 j *XCMPLX-0K3 (i divNAT-DK1 j) +XCMPLX-0K2 j1"and "j1 <XXREAL-0R3 j"
           sorry
        assume "i divNAT-DK1 j <>HIDDENR2 0NUMBERSK6"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A3: "i divNAT-DK1 j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        have "i =HIDDENR1 j +XCMPLX-0K2 (j *XCMPLX-0K3 k +XCMPLX-0K2 j1)"
          using A2 A3 sorry
        thus " False "
          using A1 nat_1_th_11 sorry
      qed
      have case2: "i divNAT-DK1 j =XBOOLE-0R4 0NUMBERSK6 & j =HIDDENR1 0NUMBERSK6 implies i divNAT-DK1 j =XBOOLE-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "i divNAT-DK1 j =XBOOLE-0R4 0NUMBERSK6 & j =HIDDENR1 0NUMBERSK6"
        thus "i divNAT-DK1 j =XBOOLE-0R4 0NUMBERSK6"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_28:
" for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m >XXREAL-0R4 0NUMBERSK6 implies n gcdNAT-DK7 m =XBOOLE-0R4 m gcdNAT-DK7 (n modNAT-DK2 m)"
proof-
  have " for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m >XXREAL-0R4 0NUMBERSK6 implies n gcdNAT-DK7 m =XBOOLE-0R4 m gcdNAT-DK7 (n modNAT-DK2 m)"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    let ?r = "n modNAT-DK2 m"
    let ?x = "n gcdNAT-DK7 m"
    let ?y = "m gcdNAT-DK7 ?r"
    assume "m >XXREAL-0R4 0NUMBERSK6"
    then obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A1: "n =HIDDENR1 m *XCMPLX-0K3 t +XCMPLX-0K2 ?r"and "?r <XXREAL-0R3 m"
      using nat_d_def_2 sorry
    have 
      [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A2: "?x dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    have A3: "?x dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    then have "?x dividesNAT-DR1 ?r"
      using A2 nat_d_th_11 sorry
    then have A4: "?x dividesNAT-DR1 ?y"
      using A3 nat_d_def_5 sorry
    have A5: "?y dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    have A6: "?y dividesNAT-DR1 ?r"
      using nat_d_def_5 sorry
    have "?y dividesNAT-DR1 m *XCMPLX-0K3 t"
      using A5 nat_d_th_9 sorry
    then have "?y dividesNAT-DR1 n"
      using A1 A6 nat_d_th_8 sorry
    then have "?y dividesNAT-DR1 ?x"
      using A5 nat_d_def_5 sorry
    thus "n gcdNAT-DK7 m =XBOOLE-0R4 m gcdNAT-DK7 (n modNAT-DK2 m)"
      using A4 nat_d_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem nat_d_sch_2:
  fixes kf0 nf0 Pp1 
  assumes
[ty]: "kf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
  [ty]: "nf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
   A1: "Pp1(0NUMBERSK6)" and
   A2: "kf0 >XXREAL-0R4 0NUMBERSK6" and
   A3: " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds (Pp1(kf0 *XCMPLX-0K3 i) & j <>HIDDENR2 0NUMBERSK6) & j <=XXREAL-0R1 kf0 implies Pp1(kf0 *XCMPLX-0K3 i +XCMPLX-0K2 j)"
  shows "Pp1(nf0)"
  proof-
    let ?R = "\<lambda>Lamb1. Pp1(kf0 *XCMPLX-0K3 Lamb1)"
    have A4: "?R(0NUMBERSK6)"
      using A1 sorry
    have A5: " for i be NatNAT-1M1 holds Pp1(kf0 *XCMPLX-0K3 i) implies Pp1(kf0 *XCMPLX-0K3 (i +NAT-1K1 \<one>\<^sub>M))"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A6: "?R(i)"
      have "kf0 *NAT-1K2 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 kf0 *XCMPLX-0K3 i +NAT-1K1 kf0"
         sorry
      thus "Pp1(kf0 *XCMPLX-0K3 (i +NAT-1K1 \<one>\<^sub>M))"
        using A2 A3 A6 sorry
    qed "sorry"
    have A7: " for i be NatNAT-1M1 holds ?R(i)"
      using nat_1_sch_2 A4 A5 sorry
    show "Pp1(nf0)"
    proof-
      have cases: "nf0 modNAT-DK4 kf0 =XBOOLE-0R4 0NUMBERSK6 or nf0 modNAT-DK4 kf0 <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "nf0 modNAT-DK4 kf0 =XBOOLE-0R4 0NUMBERSK6 implies Pp1(nf0)"
      proof(rule impI)
        assume "nf0 modNAT-DK4 kf0 =XBOOLE-0R4 0NUMBERSK6"
        then have "nf0 =XBOOLE-0R4 kf0 *NAT-1K2 (nf0 divNAT-DK3 kf0) +NAT-1K1 0NUMBERSK6"
          using A2 int_1_th_59 sorry
        thus "Pp1(nf0)"
          using A7 sorry
      qed
      have case2: "nf0 modNAT-DK4 kf0 <>HIDDENR2 0NUMBERSK6 implies Pp1(nf0)"
      proof(rule impI)
        assume A8: "nf0 modNAT-DK4 kf0 <>HIDDENR2 0NUMBERSK6"
        have A9: "nf0 =XBOOLE-0R4 kf0 *NAT-1K2 (nf0 divNAT-DK3 kf0) +NAT-1K1 (nf0 modNAT-DK4 kf0)"
          using A2 int_1_th_59 sorry
        have "nf0 modNAT-DK4 kf0 <=XXREAL-0R1 kf0"
          using A2 nat_d_th_1 sorry
        thus "Pp1(nf0)"
          using A3 A7 A8 A9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed

mtheorem nat_d_th_29:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "i be NatNAT-1M1 & j be NatNAT-1M1"
      using tarski_th_1 sorry
    have A1: "i <>HIDDENR2 0NUMBERSK6 & j <>HIDDENR2 0NUMBERSK6 implies i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
    proof(rule impMI ,rule impI)
      assume A2: "i <>HIDDENR2 0NUMBERSK6"
        and A3: "j <>HIDDENR2 0NUMBERSK6"
      have A4: "i dividesNAT-DR1 i implies i dividesNAT-DR1 i *XCMPLX-0K3 j"
        using A0 sorry
      have "j dividesNAT-DR1 j implies j dividesNAT-DR1 j *XCMPLX-0K3 i"
        using A0 sorry
      then have "i lcmNAT-DK5 j dividesNAT-DR1 i *XCMPLX-0K3 j"
        using A4 nat_d_def_4 sorry
      then obtain c where
        [ty]:"c be NatNAT-1M1" and 
        A5: "i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 c"
         sorry
      have A6: "i dividesNAT-DR1 i lcmNAT-DK5 j"
        using nat_d_def_4 sorry
      have A7: "j dividesNAT-DR1 i lcmNAT-DK5 j"
        using nat_d_def_4 sorry
      obtain d where
        [ty]:"d be NatNAT-1M1" and 
        A8: "i lcmNAT-DK5 j =XBOOLE-0R4 i *XCMPLX-0K3 d"
        using A6 sorry
      obtain e where
        [ty]:"e be NatNAT-1M1" and 
        A9: "i lcmNAT-DK5 j =XBOOLE-0R4 j *XCMPLX-0K3 e"
        using A7 sorry
      have "i *XCMPLX-0K3 j =XBOOLE-0R4 i *XCMPLX-0K3 (c *XCMPLX-0K3 d)"
        using A5 A8 sorry
      then have A10: "j =HIDDENR1 c *XCMPLX-0K3 d"
        using A2 xcmplx_1_th_5 sorry
      have "i *XCMPLX-0K3 j =XBOOLE-0R4 j *XCMPLX-0K3 (c *XCMPLX-0K3 e)"
        using A5 A9 sorry
      then have "i =HIDDENR1 c *XCMPLX-0K3 e"
        using A3 xcmplx_1_th_5 sorry
      then have A11: "c dividesNAT-DR1 i"
         sorry
      have A12: "c dividesNAT-DR1 j"
        using A10 sorry
      have " for f be NatNAT-1M1 holds f dividesNAT-DR1 i & f dividesNAT-DR1 j implies f dividesNAT-DR1 c"
      proof(rule ballI,rule impMI ,rule impI)
        fix f assume [ty]: "f be NatNAT-1M1"
        assume A13: "f dividesNAT-DR1 i"
          and A14: "f dividesNAT-DR1 j"
        obtain g where
          [ty]:"g be NatNAT-1M1" and 
          A15: "i =HIDDENR1 f *XCMPLX-0K3 g"
          using A13 sorry
        obtain h where
          [ty]:"h be NatNAT-1M1" and 
          A16: "j =HIDDENR1 f *XCMPLX-0K3 h"
          using A14 sorry
        have A17: "j *XCMPLX-0K3 g =XBOOLE-0R4 (g *XCMPLX-0K3 h)*XCMPLX-0K3 f"
          using A16 sorry
        have "i *XCMPLX-0K3 h =XBOOLE-0R4 (g *XCMPLX-0K3 h)*XCMPLX-0K3 f"
          using A15 sorry
        then have A18: "i dividesNAT-DR1 (g *XCMPLX-0K3 h)*XCMPLX-0K3 f"
           sorry
        have "j dividesNAT-DR1 (g *XCMPLX-0K3 h)*XCMPLX-0K3 f"
          using A17 sorry
        then have "i lcmNAT-DK5 j dividesNAT-DR1 (g *XCMPLX-0K3 h)*XCMPLX-0K3 f"
          using A18 nat_d_def_4 sorry
        then obtain z where
          [ty]:"z be NatNAT-1M1" and 
          A19: "(g *XCMPLX-0K3 h)*XCMPLX-0K3 f =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 z"
           sorry
        have A20: "c *XCMPLX-0K3 (i lcmNAT-DK5 j) =HIDDENR1 (g *XCMPLX-0K3 (h *XCMPLX-0K3 f))*XCMPLX-0K3 f"
          using A5 A15 A16 sorry
        also have "... = ((i lcmNAT-DK5 j)*XCMPLX-0K3 z)*XCMPLX-0K3 f"
          using A19 sorry
        also have "... = (z *XCMPLX-0K3 f)*XCMPLX-0K3 (i lcmNAT-DK5 j)"
           sorry
        finally have "c *XCMPLX-0K3 (i lcmNAT-DK5 j) =HIDDENR1 (z *XCMPLX-0K3 f)*XCMPLX-0K3 (i lcmNAT-DK5 j)"
           sorry
        have "i lcmNAT-DK5 j <>HIDDENR2 0NUMBERSK6"
          using A2 A3 int_2_th_4 sorry
        then have "c =XBOOLE-0R4 f *XCMPLX-0K3 z"
          using A20 xcmplx_1_th_5 sorry
        thus "f dividesNAT-DR1 c"
           sorry
      qed "sorry"
      thus "i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
        using A5 A11 A12 nat_d_def_5 sorry
    qed
    have "i =HIDDENR1 0NUMBERSK6 or j =HIDDENR1 0NUMBERSK6 implies i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
    proof(rule impI)
      assume A21: "i =HIDDENR1 0NUMBERSK6 or j =HIDDENR1 0NUMBERSK6"
      then have "i *XCMPLX-0K3 j =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
         sorry
      also have "... = (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
        using A21 int_2_th_4 sorry
      finally have "i *XCMPLX-0K3 j =HIDDENR1 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
         sorry
      thus "i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
         sorry
    qed
    thus "i *XCMPLX-0K3 j =XBOOLE-0R4 (i lcmNAT-DK5 j)*XCMPLX-0K3 (i gcdNAT-DK7 j)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_30:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds i >=XXREAL-0R2 0NUMBERSK6 & j >XXREAL-0R4 0NUMBERSK6 implies i gcdINT-2K3 j =XBOOLE-0R4 j gcdINT-2K3 (i modINT-1K6 j)"
proof-
  have " for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds i >=XXREAL-0R2 0NUMBERSK6 & j >XXREAL-0R4 0NUMBERSK6 implies i gcdINT-2K3 j =HIDDENR1 j gcdINT-2K3 (i modINT-1K6 j)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix j assume [ty]: "j be IntegerINT-1M1"
    assume A1: "i >=XXREAL-0R2 0NUMBERSK6"
      and A2: "j >XXREAL-0R4 0NUMBERSK6"
    have A3: " |.INT-2K1 j.| >XXREAL-0R4 0NUMBERSK6"
      using A2 absvalue_def_1 sorry
    have "i gcdINT-2K3 j =HIDDENR1  |.INT-2K1 i.| gcdNAT-DK8  |.INT-2K1 j.|"
      using int_2_th_34 sorry
    also have "... =  |.INT-2K1 j.| gcdNAT-DK8 ( |.INT-2K1 i.| modNAT-DK4  |.INT-2K1 j.|)"
      using A3 nat_d_th_28 sorry
    also have "... =  |.INT-2K1 j.| gcdNAT-DK8  |.INT-2K1  |.INT-2K1 i.| modNAT-DK4  |.INT-2K1 j.| .|"
      using absvalue_def_1 sorry
    also have "... = j gcdINT-2K3 ( |.INT-2K1 i.| modNAT-DK4  |.INT-2K1 j.|)"
      using int_2_th_34 sorry
    also have "... = j gcdINT-2K3 (i modINT-1K6 j)"
      using A1 A2 int_2_th_32 sorry
    finally show "i gcdINT-2K3 j =HIDDENR1 j gcdINT-2K3 (i modINT-1K6 j)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_31:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i lcmNAT-DK5 i =HIDDENR1 i"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i lcmNAT-DK5 i =HIDDENR1 i"
  proof(rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "i be NatNAT-1M1"
      using tarski_th_1 sorry
    have " for m be NatNAT-1M1 holds i dividesNAT-DR1 m & i dividesNAT-DR1 m implies i dividesNAT-DR1 m"
       sorry
    thus "i lcmNAT-DK5 i =HIDDENR1 i"
      using A0 nat_d_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_32:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i gcdNAT-DK7 i =HIDDENR1 i"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i gcdNAT-DK7 i =HIDDENR1 i"
  proof(rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A0: "i be NatNAT-1M1"
      using tarski_th_1 sorry
    have " for m be NatNAT-1M1 holds m dividesNAT-DR1 i & m dividesNAT-DR1 i implies m dividesNAT-DR1 i"
       sorry
    thus "i gcdNAT-DK7 i =HIDDENR1 i"
      using A0 nat_d_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_33:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 j & i <>HIDDENR2 0NUMBERSK6 implies  not i /XCMPLX-0K7 j be integerINT-1V1"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 j & i <>HIDDENR2 0NUMBERSK6 implies (i /XCMPLX-0K7 j be integerINT-1V1 implies  not  True )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i <XXREAL-0R3 j"
      and A2: "i <>HIDDENR2 0NUMBERSK6"
    assume "i /XCMPLX-0K7 j be integerINT-1V1"
    then obtain r where 
      [ty]:"r be IntegerINT-1M1" and rDef:"r = i /XCMPLX-0K7 j"
       sorry
    have "r =HIDDENR1 [\\INT-1K2 r/]"
      using int_1_th_25 sorry
    also have "... = i divINT-1K5 j"
      using int_1_def_9 sorry
    finally have "r =HIDDENR1 i divINT-1K5 j"
       sorry
    thus " not  True "
      using A1 A2 nat_d_th_27 xcmplx_1_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) NAT_DK9(" _ -''NAT-DK9  _ " [132,132]132) where
  "i -'NAT-DK9 j \<equiv> i -'XREAL-0K1 j"

mtheorem nat_d_add_7:
  mlet "i be NatNAT-1M1", "j be NatNAT-1M1"
"cluster i -'XREAL-0K1 j as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "i -'XREAL-0K1 j be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "i -'XREAL-0K1 j =XBOOLE-0R4 i -XCMPLX-0K6 j & 0NUMBERSK6 <=XXREAL-0R1 i -'XREAL-0K1 j or i -'XREAL-0K1 j =XBOOLE-0R4 0NUMBERSK6"
      using xreal_0_def_2 sorry
    thus "i -'XREAL-0K1 j be ElementSUBSET-1M1-of NATNUMBERSK1"
      using int_1_th_3 sorry
  qed
qed "sorry"

mtheorem nat_d_th_34:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (i +XCMPLX-0K2 j)-'XREAL-0K1 j =HIDDENR1 i"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (i +XCMPLX-0K2 j)-'XREAL-0K1 j =HIDDENR1 i"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "(i +XCMPLX-0K2 j)-XCMPLX-0K6 j >=XXREAL-0R2 0NUMBERSK6"
       sorry
    thus "(i +XCMPLX-0K2 j)-'XREAL-0K1 j =HIDDENR1 i"
      using xreal_0_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_35:
" for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a -'XREAL-0K1 b <=XXREAL-0R1 a"
proof-
  have " for a be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for b be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a -'XREAL-0K1 b <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix b assume [ty]: "b be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "a -XCMPLX-0K6 b <=XXREAL-0R1 a -XCMPLX-0K6 0NUMBERSK6"
      using xreal_1_th_230 sorry
    thus "a -'XREAL-0K1 b <=XXREAL-0R1 a"
      using xreal_0_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_36:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n -'XREAL-0K1 i =XBOOLE-0R4 0NUMBERSK6 implies n <=XXREAL-0R1 i"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n -'XREAL-0K1 i =XBOOLE-0R4 0NUMBERSK6 implies (i <XXREAL-0R3 n implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "n -'XREAL-0K1 i =XBOOLE-0R4 0NUMBERSK6"
    assume "i <XXREAL-0R3 n"
    then have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
      using nat_1_th_13 sorry
    then have "(i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 i <=XXREAL-0R1 n -XCMPLX-0K6 i"
      using xreal_1_th_9 sorry
    thus " False "
      using A1 xreal_0_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_37:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies (j +XCMPLX-0K2 k)-'XREAL-0K1 i =XBOOLE-0R4 (j +XCMPLX-0K2 k)-XCMPLX-0K6 i"
  using nat_1_th_12 xreal_1_th_233 sorry

mtheorem nat_d_th_38:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies (j +XCMPLX-0K2 k)-'XREAL-0K1 i =XBOOLE-0R4 (j -'XREAL-0K1 i)+XCMPLX-0K2 k"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies (j +XCMPLX-0K2 k)-'XREAL-0K1 i =HIDDENR1 (j -'XREAL-0K1 i)+XCMPLX-0K2 k"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i <=XXREAL-0R1 j"
    then have "(j +XCMPLX-0K2 k)-'XREAL-0K1 i =HIDDENR1 (j +XCMPLX-0K2 k)-XCMPLX-0K6 i"
      using nat_1_th_12 xreal_1_th_233 sorry
    also have "... = (j -XCMPLX-0K6 i)+XCMPLX-0K2 k"
       sorry
    also have "... = (j -'XREAL-0K1 i)+XCMPLX-0K2 k"
      using A1 xreal_1_th_233 sorry
    finally show "(j +XCMPLX-0K2 k)-'XREAL-0K1 i =HIDDENR1 (j -'XREAL-0K1 i)+XCMPLX-0K2 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_39:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M or i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M implies i -'XREAL-0K1 i1 =XBOOLE-0R4 i -XCMPLX-0K6 i1"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M or i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M implies i -'XREAL-0K1 i1 =XBOOLE-0R4 i -XCMPLX-0K6 i1"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M or i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M"
    show "i -'XREAL-0K1 i1 =XBOOLE-0R4 i -XCMPLX-0K6 i1"
    proof-
      have cases: "i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M or i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M"
        using A1 sorry
      have case1: "i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M implies i -'XREAL-0K1 i1 =XBOOLE-0R4 i -XCMPLX-0K6 i1"
      proof(rule impI)
        assume "i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M"
        thus "i -'XREAL-0K1 i1 =XBOOLE-0R4 i -XCMPLX-0K6 i1"
          using xreal_0_def_2 sorry
      qed
      have case2: "i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M implies i -'XREAL-0K1 i1 =XBOOLE-0R4 i -XCMPLX-0K6 i1"
      proof(rule impI)
        assume "i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M"
        thus "i -'XREAL-0K1 i1 =XBOOLE-0R4 i -XCMPLX-0K6 i1"
          using xreal_0_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_40:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n -'XREAL-0K1 0NUMBERSK6 =HIDDENR1 n"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n -'XREAL-0K1 0NUMBERSK6 =HIDDENR1 n"
  proof(rule ballI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "n -'XREAL-0K1 0NUMBERSK6 =HIDDENR1 n -XCMPLX-0K6 0NUMBERSK6"
      using xreal_0_def_2 sorry
    also have "... = n"
       sorry
    finally have "n -'XREAL-0K1 0NUMBERSK6 =HIDDENR1 n"
       sorry
    thus "n -'XREAL-0K1 0NUMBERSK6 =HIDDENR1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_41:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 implies n -'XREAL-0K1 i2 <=XXREAL-0R1 n -'XREAL-0K1 i1"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 implies n -'XREAL-0K1 i2 <=XXREAL-0R1 n -'XREAL-0K1 i1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i1 <=XXREAL-0R1 i2"
    show "n -'XREAL-0K1 i2 <=XXREAL-0R1 n -'XREAL-0K1 i1"
    proof-
      have cases: "i2 <=XXREAL-0R1 n or i2 >XXREAL-0R4 n"
         sorry
      have case1: "i2 <=XXREAL-0R1 n implies n -'XREAL-0K1 i2 <=XXREAL-0R1 n -'XREAL-0K1 i1"
      proof(rule impI)
        assume A2: "i2 <=XXREAL-0R1 n"
        then have A3: "n -'XREAL-0K1 i1 =XBOOLE-0R4 n -XCMPLX-0K6 i1"
          using A1 xreal_1_th_233 xxreal_0_th_2 sorry
        have "n -'XREAL-0K1 i2 =XBOOLE-0R4 n -XCMPLX-0K6 i2"
          using A2 xreal_1_th_233 sorry
        thus "n -'XREAL-0K1 i2 <=XXREAL-0R1 n -'XREAL-0K1 i1"
          using A1 A3 xreal_1_th_10 sorry
      qed
      have case2: "i2 >XXREAL-0R4 n implies n -'XREAL-0K1 i2 <=XXREAL-0R1 n -'XREAL-0K1 i1"
      proof(rule impI)
        assume "i2 >XXREAL-0R4 n"
        then have "n -XCMPLX-0K6 i2 <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_49 sorry
        thus "n -'XREAL-0K1 i2 <=XXREAL-0R1 n -'XREAL-0K1 i1"
          using xreal_0_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_42:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 implies i1 -'XREAL-0K1 n <=XXREAL-0R1 i2 -'XREAL-0K1 n"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 implies i1 -'XREAL-0K1 n <=XXREAL-0R1 i2 -'XREAL-0K1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i1 <=XXREAL-0R1 i2"
    show "i1 -'XREAL-0K1 n <=XXREAL-0R1 i2 -'XREAL-0K1 n"
    proof-
      have cases: "i1 -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6 or i1 -XCMPLX-0K6 n <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "i1 -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6 implies i1 -'XREAL-0K1 n <=XXREAL-0R1 i2 -'XREAL-0K1 n"
      proof(rule impI)
        assume "i1 -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6"
        then have A2: "i1 -'XREAL-0K1 n =XBOOLE-0R4 i1 -XCMPLX-0K6 n"
          using xreal_0_def_2 sorry
        have "i1 -XCMPLX-0K6 n <=XXREAL-0R1 i2 -XCMPLX-0K6 n"
          using A1 xreal_1_th_9 sorry
        thus "i1 -'XREAL-0K1 n <=XXREAL-0R1 i2 -'XREAL-0K1 n"
          using A2 xreal_0_def_2 sorry
      qed
      have case2: "i1 -XCMPLX-0K6 n <XXREAL-0R3 0NUMBERSK6 implies i1 -'XREAL-0K1 n <=XXREAL-0R1 i2 -'XREAL-0K1 n"
      proof(rule impI)
        assume "i1 -XCMPLX-0K6 n <XXREAL-0R3 0NUMBERSK6"
        thus "i1 -'XREAL-0K1 n <=XXREAL-0R1 i2 -'XREAL-0K1 n"
          using xreal_0_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_43:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M or i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M implies (i -'XREAL-0K1 i1)+XCMPLX-0K2 i1 =HIDDENR1 i"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M or i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M implies (i -'XREAL-0K1 i1)+XCMPLX-0K2 i1 =HIDDENR1 i"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "i -'XREAL-0K1 i1 >=XXREAL-0R2 \<one>\<^sub>M or i -XCMPLX-0K6 i1 >=XXREAL-0R2 \<one>\<^sub>M"
    then have "(i -'XREAL-0K1 i1)+XCMPLX-0K2 i1 =HIDDENR1 (i -XCMPLX-0K6 i1)+XCMPLX-0K2 i1"
      using nat_d_th_39 sorry
    also have "... = i"
       sorry
    finally have "(i -'XREAL-0K1 i1)+XCMPLX-0K2 i1 =HIDDENR1 i"
       sorry
    thus "(i -'XREAL-0K1 i1)+XCMPLX-0K2 i1 =HIDDENR1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_44:
" for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 implies i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
proof-
  have " for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 implies i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
  proof(rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i1 <=XXREAL-0R1 i2"
    have 
      [ty]:"i1 be NatNAT-1M1" and
      [ty]:"i2 be NatNAT-1M1"
      using tarski_th_1 sorry
    show "i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
    proof-
      have cases: "i1 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 or i1 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "i1 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 implies i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
      proof(rule impI)
        assume "i1 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
        then have "i1 -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 i1 -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_0_def_2 sorry
        then have "i1 -'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 (i1 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
          using nat_1_th_12 sorry
        thus "i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
          using A1 xxreal_0_th_2 sorry
      qed
      have case2: "i1 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6 implies i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
      proof(rule impI)
        assume "i1 -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
        thus "i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
          using xreal_0_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_45:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
    proof-
      have cases: "i >=XXREAL-0R2 \<two>\<^sub>M or i <XXREAL-0R3 \<two>\<^sub>M"
         sorry
      have case1: "i >=XXREAL-0R2 \<two>\<^sub>M implies i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
      proof(rule impI)
        assume A1: "i >=XXREAL-0R2 \<two>\<^sub>M"
        then have "\<one>\<^sub>M <=XXREAL-0R1 i"
          using xxreal_0_th_2 sorry
        then have "i -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
          using xreal_1_th_48 sorry
        then have A2: "i -'XREAL-0K1 \<one>\<^sub>M =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_0_def_2 sorry
        have "i -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A1 xreal_1_th_9 sorry
        then have "(i -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        then have "(i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M =XBOOLE-0R4 i -XCMPLX-0K6 \<two>\<^sub>M"
          using A2 xreal_0_def_2 sorry
        thus "i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
          using xreal_0_def_2 sorry
      qed
      have case2: "i <XXREAL-0R3 \<two>\<^sub>M implies i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
      proof(rule impI)
        assume A3: "i <XXREAL-0R3 \<two>\<^sub>M"
        then have "i -XCMPLX-0K6 \<two>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M"
          using xreal_1_th_9 sorry
        then have A4: "i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
          using xreal_0_def_2 sorry
        have A5: "(i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A3 nat_1_th_13 sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 i & i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M or i <XXREAL-0R3 \<one>\<^sub>M & (i <XXREAL-0R3 \<one>\<^sub>M implies i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M)"
        proof-
          show "\<one>\<^sub>M <=XXREAL-0R1 i & i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M or i <XXREAL-0R3 \<one>\<^sub>M & (i <XXREAL-0R3 \<one>\<^sub>M implies i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M)"
          proof-
            have cases: "\<one>\<^sub>M <=XXREAL-0R1 i or i <XXREAL-0R3 \<one>\<^sub>M"
               sorry
            have case1: "\<one>\<^sub>M <=XXREAL-0R1 i implies i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
            proof(rule impI)
              assume "\<one>\<^sub>M <=XXREAL-0R1 i"
              then have "i =HIDDENR1 \<one>\<^sub>M"
                using A5 xxreal_0_th_1 sorry
              then have "(i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 -'NAT-DK9 \<one>\<^sub>M"
                using xreal_1_th_232 sorry
              thus "i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
                using A4 nat_d_th_35 sorry
            qed
            have case2: "i <XXREAL-0R3 \<one>\<^sub>M implies i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
            proof(rule impI)
              assume "i <XXREAL-0R3 \<one>\<^sub>M"
              then have "i -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              then have "(i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 -'NAT-DK9 \<one>\<^sub>M"
                using xreal_0_def_2 sorry
              thus "i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
                using A4 nat_d_th_35 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "i -'XREAL-0K1 \<two>\<^sub>M =XBOOLE-0R4 (i -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_46:
" for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2 implies (i1 -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2 & i1 -'XREAL-0K1 \<two>\<^sub>M <XXREAL-0R3 i2) & i1 <=XXREAL-0R1 i2"
proof-
  have " for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2 implies i1 -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2 & ( not i1 -'XREAL-0K1 \<two>\<^sub>M <XXREAL-0R3 i2 & i1 <=XXREAL-0R1 i2)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
    then have A2: "i1 <XXREAL-0R3 i2"
      using nat_1_th_13 sorry
    have "i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i1"
      using nat_d_th_35 sorry
    thus A3: "i1 -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2"
      using A2 xxreal_0_th_2 sorry
    have A4: "(i1 -'XREAL-0K1 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M =XBOOLE-0R4 i1 -'XREAL-0K1 \<two>\<^sub>M"
      using nat_d_th_45 sorry
    have 
      [ty]:"i1 be NatNAT-1M1"
      using tarski_th_1 sorry
    have "(i1 -'NAT-DK9 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 i1 -'NAT-DK9 \<one>\<^sub>M"
      using nat_d_th_35 sorry
    thus " not i1 -'XREAL-0K1 \<two>\<^sub>M <XXREAL-0R3 i2 & i1 <=XXREAL-0R1 i2"
      using A1 A3 A4 xxreal_0_th_2 nat_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_47:
" for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 i2 or (i1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2 implies ((((((((i1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 i2 & (i1 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M <XXREAL-0R3 i2) & (i1 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<two>\<^sub>M <XXREAL-0R3 i2) & i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2) & (i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 i2) & ((i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2) & i1 <XXREAL-0R3 i2) & i1 -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2) & i1 -'XREAL-0K1 \<two>\<^sub>M <XXREAL-0R3 i2) & i1 <=XXREAL-0R1 i2"
proof-
  have " for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 i2 or (i1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2 implies (((i1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 i2 & (i1 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M <XXREAL-0R3 i2) & (i1 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<two>\<^sub>M <XXREAL-0R3 i2) & i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2) & ((((( not (i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 i2 &  not ((i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2) &  not i1 <XXREAL-0R3 i2) &  not i1 -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2) &  not i1 -'XREAL-0K1 \<two>\<^sub>M <XXREAL-0R3 i2) & i1 <=XXREAL-0R1 i2)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "i1 +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 i2 or (i1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
    then have "(i1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
       sorry
    thus A1: "((i1 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 i2 & (i1 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M <XXREAL-0R3 i2) & (i1 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<two>\<^sub>M <XXREAL-0R3 i2) & i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
      using nat_d_th_46 nat_1_th_13 sorry
    have "i1 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i1"
      using nat_d_th_35 sorry
    then have "(i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i1 +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    then have A2: "(i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 i2"
      using A1 xxreal_0_th_2 sorry
    have 
      [ty]:"i1 be NatNAT-1M1"
      using tarski_th_1 sorry
    have "((i1 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M <=XXREAL-0R1 (i1 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
      using nat_d_th_35 sorry
    thus "(((( not (i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 i2 &  not ((i1 -'XREAL-0K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)-'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2) &  not i1 <XXREAL-0R3 i2) &  not i1 -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 i2) &  not i1 -'XREAL-0K1 \<two>\<^sub>M <XXREAL-0R3 i2) & i1 <=XXREAL-0R1 i2"
      using A1 nat_d_th_46 A2 xxreal_0_th_2 nat_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_48:
" for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 or i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M implies ((((i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<one>\<^sub>M) & i1 <XXREAL-0R3 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <=XXREAL-0R1 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <XXREAL-0R3 i2 +NAT-1K1 \<two>\<^sub>M) & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<two>\<^sub>M"
proof-
  have " for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <=XXREAL-0R1 i2 or i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M implies (((( not i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <=XXREAL-0R1 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 i2 +NAT-1K1 \<two>\<^sub>M) & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i1 <=XXREAL-0R1 i2 or i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
    have A2: "i1 <=XXREAL-0R1 i2 implies (((( not i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <=XXREAL-0R1 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 i2 +NAT-1K1 \<two>\<^sub>M) & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<two>\<^sub>M"
    proof(rule impI)
      assume "i1 <=XXREAL-0R1 i2"
      then have A3: "i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      have "(i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i2 +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "(((( not i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <=XXREAL-0R1 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 i2 +NAT-1K1 \<two>\<^sub>M) & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<two>\<^sub>M"
        using A3 nat_1_th_13 sorry
    qed
    have "i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M implies (((( not i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <=XXREAL-0R1 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 i2 +NAT-1K1 \<two>\<^sub>M) & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<two>\<^sub>M"
    proof(rule impI)
      assume A4: "i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
      have "i2 -'XREAL-0K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
        using nat_d_th_35 sorry
      thus "(((( not i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <=XXREAL-0R1 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 i2 +NAT-1K1 \<two>\<^sub>M) & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<two>\<^sub>M"
        using A2 A4 xxreal_0_th_2 sorry
    qed
    thus "(((( not i1 <XXREAL-0R3 i2 +NAT-1K1 \<one>\<^sub>M & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & i1 <=XXREAL-0R1 (i2 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) &  not i1 <XXREAL-0R3 i2 +NAT-1K1 \<two>\<^sub>M) & i1 <=XXREAL-0R1 i2 +NAT-1K1 \<two>\<^sub>M"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_49:
" for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <XXREAL-0R3 i2 or i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2 implies i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
proof-
  have " for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i1 <XXREAL-0R3 i2 or i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2 implies i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i1 <XXREAL-0R3 i2 or i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
    show "i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
    proof-
      have cases: "i1 <XXREAL-0R3 i2 or i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
        using A1 sorry
      have case1: "i1 <XXREAL-0R3 i2 implies i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
      proof(rule impI)
        assume A2: "i1 <XXREAL-0R3 i2"
        then have "i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
          using nat_1_th_13 sorry
        then have A3: "(i1 +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 i2 -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
          using A2 nat_1_th_13 sorry
        thus "i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
          using A3 xreal_1_th_233 sorry
      qed
      have case2: "i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2 implies i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
      proof(rule impI)
        assume A4: "i1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
        then have A5: "(i1 +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 i2 -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i2"
          using A4 nat_1_th_13 sorry
        thus "i1 <=XXREAL-0R1 i2 -'XREAL-0K1 \<one>\<^sub>M"
          using A5 xreal_1_th_233 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_50:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i >=XXREAL-0R2 i1 implies i >=XXREAL-0R2 i1 -'XREAL-0K1 i2"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i >=XXREAL-0R2 i1 implies i >=XXREAL-0R2 i1 -'XREAL-0K1 i2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i2 assume [ty]: "i2 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i >=XXREAL-0R2 i1"
    have "i1 >=XXREAL-0R2 i1 -'XREAL-0K1 i2"
      using nat_d_th_35 sorry
    thus "i >=XXREAL-0R2 i1 -'XREAL-0K1 i2"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_51:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & \<one>\<^sub>M <=XXREAL-0R1 i1 -'XREAL-0K1 i implies i1 -'XREAL-0K1 i <XXREAL-0R3 i1"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & \<one>\<^sub>M <=XXREAL-0R1 i1 -'XREAL-0K1 i implies  not i1 -'XREAL-0K1 i <XXREAL-0R3 i1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i1 assume [ty]: "i1 be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 i"
      and A2: "\<one>\<^sub>M <=XXREAL-0R1 i1 -'XREAL-0K1 i"
    have "i1 -XCMPLX-0K6 i =HIDDENR1 ((i1 -'XREAL-0K1 i)+XCMPLX-0K2 i)-XCMPLX-0K6 i"
      using A2 nat_d_th_43 sorry
    also have "... = i1 -'XREAL-0K1 i"
       sorry
    finally have "i1 -XCMPLX-0K6 i =HIDDENR1 i1 -'XREAL-0K1 i"
       sorry
    thus " not i1 -'XREAL-0K1 i <XXREAL-0R3 i1"
      using A1 xreal_1_th_231 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_52:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 k <=XXREAL-0R1 j implies i <=XXREAL-0R1 j +XCMPLX-0K2 k"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i -'XREAL-0K1 k <=XXREAL-0R1 j implies i <=XXREAL-0R1 j +XCMPLX-0K2 k"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i -'XREAL-0K1 k <=XXREAL-0R1 j"
    show "i <=XXREAL-0R1 j +XCMPLX-0K2 k"
    proof-
      have cases: "i >=XXREAL-0R2 k or i <=XXREAL-0R1 k"
         sorry
      have case1: "i >=XXREAL-0R2 k implies i <=XXREAL-0R1 j +XCMPLX-0K2 k"
      proof(rule impI)
        assume A2: "i >=XXREAL-0R2 k"
        have "(i -'XREAL-0K1 k)+XCMPLX-0K2 k <=XXREAL-0R1 j +XCMPLX-0K2 k"
          using A1 xreal_1_th_6 sorry
        thus "i <=XXREAL-0R1 j +XCMPLX-0K2 k"
          using A2 xreal_1_th_235 sorry
      qed
      have case2: "i <=XXREAL-0R1 k implies i <=XXREAL-0R1 j +XCMPLX-0K2 k"
      proof(rule impI)
        assume A3: "i <=XXREAL-0R1 k"
        have "k <=XXREAL-0R1 j +XCMPLX-0K2 k"
          using nat_1_th_11 sorry
        thus "i <=XXREAL-0R1 j +XCMPLX-0K2 k"
          using A3 xxreal_0_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_53:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j +XCMPLX-0K2 k implies i -'XREAL-0K1 k <=XXREAL-0R1 j"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j +XCMPLX-0K2 k implies i -'XREAL-0K1 k <=XXREAL-0R1 j"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "i <=XXREAL-0R1 j +XCMPLX-0K2 k"
    then have "i -'XREAL-0K1 k <=XXREAL-0R1 (j +XCMPLX-0K2 k)-'XREAL-0K1 k"
      using nat_d_th_42 sorry
    thus "i -'XREAL-0K1 k <=XXREAL-0R1 j"
      using nat_d_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_54:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j -'XREAL-0K1 k & k <=XXREAL-0R1 j implies i +XCMPLX-0K2 k <=XXREAL-0R1 j"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j -'XREAL-0K1 k & j >=XXREAL-0R2 k implies i +XCMPLX-0K2 k <=XXREAL-0R1 j"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i <=XXREAL-0R1 j -'XREAL-0K1 k"
      and A2: "j >=XXREAL-0R2 k"
    have "i +XCMPLX-0K2 k <=XXREAL-0R1 (j -'XREAL-0K1 k)+XCMPLX-0K2 k"
      using A1 xreal_1_th_6 sorry
    thus "i +XCMPLX-0K2 k <=XXREAL-0R1 j"
      using A2 xreal_1_th_235 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_55:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds j +XCMPLX-0K2 k <=XXREAL-0R1 i implies k <=XXREAL-0R1 i -'XREAL-0K1 j"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds j +XCMPLX-0K2 k <=XXREAL-0R1 i implies k <=XXREAL-0R1 i -'XREAL-0K1 j"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "j +XCMPLX-0K2 k <=XXREAL-0R1 i"
    show "k <=XXREAL-0R1 i -'XREAL-0K1 j"
    proof-
      have cases: "j +XCMPLX-0K2 k =HIDDENR1 i or j +XCMPLX-0K2 k <XXREAL-0R3 i"
        using A1 xxreal_0_th_1 sorry
      have case1: "j +XCMPLX-0K2 k =HIDDENR1 i implies k <=XXREAL-0R1 i -'XREAL-0K1 j"
      proof(rule impI)
        assume "j +XCMPLX-0K2 k =HIDDENR1 i"
        thus "k <=XXREAL-0R1 i -'XREAL-0K1 j"
          using nat_d_th_34 sorry
      qed
      have case2: "j +XCMPLX-0K2 k <XXREAL-0R3 i implies k <=XXREAL-0R1 i -'XREAL-0K1 j"
      proof(rule impI)
        assume "j +XCMPLX-0K2 k <XXREAL-0R3 i"
        thus "k <=XXREAL-0R1 i -'XREAL-0K1 j"
          using nat_d_th_52 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_56:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <=XXREAL-0R1 i & i <XXREAL-0R3 j implies i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds k <=XXREAL-0R1 i & i <XXREAL-0R3 j implies  not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "k <=XXREAL-0R1 i"
      and A2: "i <XXREAL-0R3 j"
    have "(i -'XREAL-0K1 k)+XCMPLX-0K2 k =HIDDENR1 i"
      using A1 xreal_1_th_235 sorry
    then have "(i -'XREAL-0K1 k)+XCMPLX-0K2 k <XXREAL-0R3 (j -'XREAL-0K1 k)+XCMPLX-0K2 k"
      using A1 A2 xreal_1_th_235 xxreal_0_th_2 sorry
    thus " not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
      using xreal_1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_57:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 j & k <XXREAL-0R3 j implies i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <XXREAL-0R3 j & k <XXREAL-0R3 j implies  not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i <XXREAL-0R3 j"
      and A2: "k <XXREAL-0R3 j"
    show " not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
    proof-
      have cases: "k <=XXREAL-0R1 i or k >XXREAL-0R4 i"
         sorry
      have case1: "k <=XXREAL-0R1 i implies  not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
      proof(rule impI)
        assume "k <=XXREAL-0R1 i"
        then have A3: "i -'XREAL-0K1 k =XBOOLE-0R4 i -XCMPLX-0K6 k"
          using xreal_1_th_233 sorry
        have "j -'XREAL-0K1 k =XBOOLE-0R4 j -XCMPLX-0K6 k"
          using A2 xreal_1_th_233 sorry
        thus " not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
          using A1 A3 xreal_1_th_9 sorry
      qed
      have case2: "k >XXREAL-0R4 i implies  not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
      proof(rule impI)
        assume "k >XXREAL-0R4 i"
        then have "i -XCMPLX-0K6 k <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_49 sorry
        then have A4: "i -'XREAL-0K1 k =XBOOLE-0R4 0NUMBERSK6"
          using xreal_0_def_2 sorry
        have "j -'XREAL-0K1 k <>HIDDENR2 0NUMBERSK6"
          using A2 nat_d_th_36 sorry
        thus " not i -'XREAL-0K1 k <XXREAL-0R3 j -'XREAL-0K1 k"
          using A4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_58:
" for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies j -'XREAL-0K1 (j -'XREAL-0K1 i) =HIDDENR1 i"
proof-
  have " for i be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for j be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds i <=XXREAL-0R1 j implies j -'XREAL-0K1 (j -'XREAL-0K1 i) =HIDDENR1 i"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix j assume [ty]: "j be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "i <=XXREAL-0R1 j"
    have "(j -'XREAL-0K1 (j -'XREAL-0K1 i))+XCMPLX-0K2 (j -'XREAL-0K1 i) =HIDDENR1 j"
      using nat_d_th_50 xreal_1_th_235 sorry
    also have "... = i +XCMPLX-0K2 (j -'XREAL-0K1 i)"
      using A1 xreal_1_th_235 sorry
    finally have "(j -'XREAL-0K1 (j -'XREAL-0K1 i))+XCMPLX-0K2 (j -'XREAL-0K1 i) =HIDDENR1 i +XCMPLX-0K2 (j -'XREAL-0K1 i)"
       sorry
    thus "j -'XREAL-0K1 (j -'XREAL-0K1 i) =HIDDENR1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_59:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n <XXREAL-0R3 k implies (k -'XREAL-0K1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 k -'XREAL-0K1 n"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n <XXREAL-0R3 k implies (k -'XREAL-0K1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 k -'XREAL-0K1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "n <XXREAL-0R3 k"
    have A2: "k -'XREAL-0K1 n =XBOOLE-0R4 k -XCMPLX-0K6 n"
      using A1 xreal_1_th_233 sorry
    have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
      using A1 nat_1_th_13 sorry
    then have "k -'XREAL-0K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 k -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
      using xreal_1_th_233 sorry
    thus "(k -'XREAL-0K1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 k -'XREAL-0K1 n"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_60:
" for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds A be trivialSUBSET-1V2 iff cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
proof-
  have " for A be finiteFINSET-1V1\<bar>setHIDDENM2 holds (A be trivialSUBSET-1V2 implies cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M) & (cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M implies A be trivialSUBSET-1V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be finiteFINSET-1V1\<bar>setHIDDENM2"
    show "A be trivialSUBSET-1V2 implies cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
    proof(rule impI)
      assume A1: "A be trivialSUBSET-1V2"
      show "cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
      proof-
        have cases: "A be emptyXBOOLE-0V1 or A be  non emptyXBOOLE-0V1"
           sorry
        have case1: "A be emptyXBOOLE-0V1 implies cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
        proof(rule impI)
          assume "A be emptyXBOOLE-0V1"
          thus "cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
             sorry
        qed
        have case2: "A be  non emptyXBOOLE-0V1 implies cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
        proof(rule impI)
          assume "A be  non emptyXBOOLE-0V1"
          then have " ex x be objectHIDDENM1 st A =XBOOLE-0R4 {TARSKIK1 x}"
            using A1 zfmisc_1_th_131 sorry
          then have "cardCARD-1K4 A =XBOOLE-0R4 \<one>\<^sub>M"
            using card_1_th_30 sorry
          thus "cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    assume A2: "cardCARD-1K4 A <XXREAL-0R3 \<two>\<^sub>M"
    show "A be trivialSUBSET-1V2"
    proof-
      have cases: "cardCARD-1K4 A =XBOOLE-0R4 0NUMBERSK6 or cardCARD-1K4 A =XBOOLE-0R4 \<one>\<^sub>M"
        using A2 nat_1_th_23 sorry
      have case1: "cardCARD-1K4 A =XBOOLE-0R4 0NUMBERSK6 implies A be trivialSUBSET-1V2"
      proof(rule impI)
        assume "cardCARD-1K4 A =XBOOLE-0R4 0NUMBERSK6"
        thus "A be trivialSUBSET-1V2"
           sorry
      qed
      have case2: "cardCARD-1K4 A =XBOOLE-0R4 \<one>\<^sub>M implies A be trivialSUBSET-1V2"
      proof(rule impI)
        assume "cardCARD-1K4 A =XBOOLE-0R4 \<one>\<^sub>M"
        then have "A be \<one>\<^sub>M -elementCARD-1V3"
          using card_1_def_7 sorry
        thus "A be trivialSUBSET-1V2"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_61:
" for n be IntegerINT-1M1 holds  for a be IntegerINT-1M1 holds  for k be IntegerINT-1M1 holds (n <>HIDDENR2 0NUMBERSK6 implies (a +XCMPLX-0K2 n *XCMPLX-0K3 k)divINT-1K5 n =HIDDENR1 (a divINT-1K5 n)+XCMPLX-0K2 k) & (a +XCMPLX-0K2 n *XCMPLX-0K3 k)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
proof(rule ballI,rule ballI,rule ballI,rule conjMI)
  fix n assume [ty]: "n be IntegerINT-1M1"
  fix a assume [ty]: "a be IntegerINT-1M1"
  fix k assume [ty]: "k be IntegerINT-1M1"
  show A1: "n <>HIDDENR2 0NUMBERSK6 implies (a +XCMPLX-0K2 n *XCMPLX-0K3 k)divINT-1K5 n =HIDDENR1 (a divINT-1K5 n)+XCMPLX-0K2 k"
  proof(rule impI)
    assume A2: "n <>HIDDENR2 0NUMBERSK6"
    have "(a +XCMPLX-0K2 n *XCMPLX-0K3 k)divINT-1K5 n =HIDDENR1 [\\INT-1K2 (a +XCMPLX-0K2 n *XCMPLX-0K3 k)/XCMPLX-0K7 n /]"
      using int_1_def_9 sorry
    also have "... = [\\INT-1K2 (a +XCMPLX-0K2 n *XCMPLX-0K3 k)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5 /]"
      using xcmplx_0_def_9 sorry
    also have "... = [\\INT-1K2 a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 +XCMPLX-0K2 (n *XCMPLX-0K3 n \<inverse>XCMPLX-0K5)*XCMPLX-0K3 k /]"
       sorry
    also have "... = [\\INT-1K2 a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 k /]"
      using A2 xcmplx_0_def_7 sorry
    also have "... = [\\INT-1K2 a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 /] +XCMPLX-0K2 k"
      using int_1_th_28 sorry
    also have "... = [\\INT-1K2 a /XCMPLX-0K7 n /] +XCMPLX-0K2 k"
      using xcmplx_0_def_9 sorry
    also have "... = (a divINT-1K5 n)+XCMPLX-0K2 k"
      using int_1_def_9 sorry
    finally show "(a +XCMPLX-0K2 n *XCMPLX-0K3 k)divINT-1K5 n =HIDDENR1 (a divINT-1K5 n)+XCMPLX-0K2 k"
       sorry
  qed
  show "(a +XCMPLX-0K2 n *XCMPLX-0K3 k)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
  proof-
    have cases: "n <>HIDDENR2 0NUMBERSK6 or n =HIDDENR1 0NUMBERSK6"
       sorry
    have case1: "n <>HIDDENR2 0NUMBERSK6 implies (a +XCMPLX-0K2 n *XCMPLX-0K3 k)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
    proof(rule impI)
      assume A3: "n <>HIDDENR2 0NUMBERSK6"
      then have "(a +XCMPLX-0K2 n *XCMPLX-0K3 k)modINT-1K6 n =HIDDENR1 (a +XCMPLX-0K2 n *XCMPLX-0K3 k)-XCMPLX-0K6 ((a divINT-1K5 n)+XCMPLX-0K2 k)*XCMPLX-0K3 n"
        using A1 int_1_def_10 sorry
      also have "... = a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n"
         sorry
      also have "... = a modINT-1K6 n"
        using A3 int_1_def_10 sorry
      finally show "(a +XCMPLX-0K2 n *XCMPLX-0K3 k)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
         sorry
    qed
    have case2: "n =HIDDENR1 0NUMBERSK6 implies (a +XCMPLX-0K2 n *XCMPLX-0K3 k)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
    proof(rule impI)
      assume "n =HIDDENR1 0NUMBERSK6"
      thus "(a +XCMPLX-0K2 n *XCMPLX-0K3 k)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem nat_d_th_62:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies ( for a be IntegerINT-1M1 holds a modINT-1K6 n >=XXREAL-0R2 0NUMBERSK6 & a modINT-1K6 n <XXREAL-0R3 n)"
proof-
  have " for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies ( for a be IntegerINT-1M1 holds a modINT-1K6 n >=XXREAL-0R2 0NUMBERSK6 &  not a modINT-1K6 n <XXREAL-0R3 n)"
  proof(rule ballI,rule impI,rule ballI)
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
    fix a assume [ty]: "a be IntegerINT-1M1"
    have "0NUMBERSK6 <=XXREAL-0R1 a modINT-1K6 n & (a modINT-1K6 n >=XXREAL-0R2 n implies  False )"
    proof(rule conjMI,rule impI)
      have "a divINT-1K5 n =HIDDENR1 [\\INT-1K2 a /XCMPLX-0K7 n /]"
        using int_1_def_9 sorry
      then have "a divINT-1K5 n <=XXREAL-0R1 a /XCMPLX-0K7 n"
        using int_1_def_6 sorry
      then have "(a divINT-1K5 n)*XCMPLX-0K3 n <=XXREAL-0R1 (a /XCMPLX-0K7 n)*XCMPLX-0K3 n"
        using xreal_1_th_64 sorry
      then have "(a divINT-1K5 n)*XCMPLX-0K3 n <=XXREAL-0R1 (a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5)*XCMPLX-0K3 n"
        using xcmplx_0_def_9 sorry
      then have "(a divINT-1K5 n)*XCMPLX-0K3 n <=XXREAL-0R1 a *XCMPLX-0K3 (n \<inverse>XCMPLX-0K5 *XCMPLX-0K3 n)"
         sorry
      then have "(a divINT-1K5 n)*XCMPLX-0K3 n <=XXREAL-0R1 a *XCMPLX-0K3 \<one>\<^sub>M"
        using A1 xcmplx_0_def_7 sorry
      then have "(a divINT-1K5 n)*XCMPLX-0K3 n -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n <=XXREAL-0R1 a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n"
        using xreal_1_th_9 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 a modINT-1K6 n"
        using int_1_def_10 sorry
      assume "a modINT-1K6 n >=XXREAL-0R2 n"
      then have "a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n >=XXREAL-0R2 n"
        using A1 int_1_def_10 sorry
      then have "(a +XCMPLX-0K2 (-XCMPLX-0K4 (a divINT-1K5 n)*XCMPLX-0K3 n))+XCMPLX-0K2 (a divINT-1K5 n)*XCMPLX-0K3 n >=XXREAL-0R2 n +XCMPLX-0K2 (a divINT-1K5 n)*XCMPLX-0K3 n"
        using xreal_1_th_6 sorry
      then have "a -XCMPLX-0K6 n >=XXREAL-0R2 (n +XCMPLX-0K2 (a divINT-1K5 n)*XCMPLX-0K3 n)-XCMPLX-0K6 n"
        using xreal_1_th_9 sorry
      then have "(a -XCMPLX-0K6 n)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5 >=XXREAL-0R2 ((a divINT-1K5 n)*XCMPLX-0K3 n)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5"
        using xreal_1_th_64 sorry
      then have "(a -XCMPLX-0K6 n)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5 >=XXREAL-0R2 (a divINT-1K5 n)*XCMPLX-0K3 (n *XCMPLX-0K3 n \<inverse>XCMPLX-0K5)"
         sorry
      then have "a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 -XCMPLX-0K6 n *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 >=XXREAL-0R2 (a divINT-1K5 n)*XCMPLX-0K3 \<one>\<^sub>M"
        using A1 xcmplx_0_def_7 sorry
      then have "a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 a divINT-1K5 n"
        using A1 xcmplx_0_def_7 sorry
      then have A2: "a /XCMPLX-0K7 n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 a divINT-1K5 n"
        using xcmplx_0_def_9 sorry
      have "a divINT-1K5 n =HIDDENR1 [\\INT-1K2 a /XCMPLX-0K7 n /]"
        using int_1_def_9 sorry
      thus " False "
        using A2 int_1_def_6 sorry
    qed
    thus "a modINT-1K6 n >=XXREAL-0R2 0NUMBERSK6 &  not a modINT-1K6 n <XXREAL-0R3 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_63:
" for n be IntegerINT-1M1 holds  for a be IntegerINT-1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 n implies a modINT-1K6 n =HIDDENR1 a) & (0NUMBERSK6 >XXREAL-0R4 a & a >=XXREAL-0R2 -XCMPLX-0K4 n implies a modINT-1K6 n =HIDDENR1 n +XCMPLX-0K2 a)"
proof-
  have " for n be IntegerINT-1M1 holds  for a be IntegerINT-1M1 holds  not ((0NUMBERSK6 <=XXREAL-0R1 a &  not a <XXREAL-0R3 n) &  not a modINT-1K6 n =HIDDENR1 a) &  not (( not 0NUMBERSK6 >XXREAL-0R4 a & a >=XXREAL-0R2 -XCMPLX-0K4 n) &  not a modINT-1K6 n =HIDDENR1 n +XCMPLX-0K2 a)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be IntegerINT-1M1"
    fix a assume [ty]: "a be IntegerINT-1M1"
    show " not ((0NUMBERSK6 <=XXREAL-0R1 a &  not a <XXREAL-0R3 n) &  not a modINT-1K6 n =HIDDENR1 a) &  not (( not 0NUMBERSK6 >XXREAL-0R4 a & a >=XXREAL-0R2 -XCMPLX-0K4 n) &  not a modINT-1K6 n =HIDDENR1 n +XCMPLX-0K2 a)"
    proof-
      have cases: "n =HIDDENR1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "n =HIDDENR1 0NUMBERSK6 implies  not ((0NUMBERSK6 <=XXREAL-0R1 a &  not a <XXREAL-0R3 n) &  not a modINT-1K6 n =HIDDENR1 a) &  not (( not 0NUMBERSK6 >XXREAL-0R4 a & a >=XXREAL-0R2 -XCMPLX-0K4 n) &  not a modINT-1K6 n =HIDDENR1 n +XCMPLX-0K2 a)"
      proof(rule impI)
        assume "n =HIDDENR1 0NUMBERSK6"
        thus " not ((0NUMBERSK6 <=XXREAL-0R1 a &  not a <XXREAL-0R3 n) &  not a modINT-1K6 n =HIDDENR1 a) &  not (( not 0NUMBERSK6 >XXREAL-0R4 a & a >=XXREAL-0R2 -XCMPLX-0K4 n) &  not a modINT-1K6 n =HIDDENR1 n +XCMPLX-0K2 a)"
           sorry
      qed
      have case2: "n <>HIDDENR2 0NUMBERSK6 implies (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 n implies a modINT-1K6 n =HIDDENR1 a) & (0NUMBERSK6 >XXREAL-0R4 a & a >=XXREAL-0R2 -XCMPLX-0K4 n implies a modINT-1K6 n =HIDDENR1 n +XCMPLX-0K2 a)"
      proof(rule impI,rule conjMI,rule impMI ,rule impI)
        assume A1: "n <>HIDDENR2 0NUMBERSK6"
        show "0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 n implies a modINT-1K6 n =HIDDENR1 a"
        proof(rule impMI ,rule impI)
          assume A2: "0NUMBERSK6 <=XXREAL-0R1 a"
            and A3: "a <XXREAL-0R3 n"
          obtain aa where 
            [ty]:"aa be ElementSUBSET-1M1-of NATNUMBERSK1" and aaDef:"aa = a"
            using A2 int_1_th_3 sorry
          obtain nn where 
            [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
            using A2 A3 int_1_th_3 sorry
          obtain t where
            [ty]:"t be NatNAT-1M1" and 
            A4: "aa =XBOOLE-0R4 nn *XCMPLX-0K3 t +NAT-1K1 (aa modNAT-DK4 nn)"and "aa modNAT-DK4 nn <XXREAL-0R3 nn"
            using A1 nat_d_def_2 sorry
          have "t =XBOOLE-0R4 0NUMBERSK6"
          proof-
            have "t <>HIDDENR2 0NUMBERSK6 implies  not  True "
            proof(rule impI)
              assume "t <>HIDDENR2 0NUMBERSK6"
              then have "t >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
                using int_1_th_7 sorry
              then have A5: "t *XCMPLX-0K3 n >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 n"
                using A2 A3 xreal_1_th_64 sorry
              have "nn *XCMPLX-0K3 t +NAT-1K1 (aa modNAT-DK4 nn) >=XXREAL-0R2 nn *XCMPLX-0K3 t"
                using nat_1_th_11 sorry
              thus " not  True "
                using A3 A4 A5 xxreal_0_th_2 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          thus "a modINT-1K6 n =HIDDENR1 a"
            using A4 sorry
        qed
        assume A6: "0NUMBERSK6 >XXREAL-0R4 a"
          and A7: "a >=XXREAL-0R2 -XCMPLX-0K4 n"
        have A8: "n >=XXREAL-0R2 0NUMBERSK6"
          using A6 A7 sorry
        have A9: "a /XCMPLX-0K7 n -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
        proof-
          have "a /XCMPLX-0K7 n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True "
          proof(rule impI)
            assume "a /XCMPLX-0K7 n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
            then have "(a /XCMPLX-0K7 n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
              using xreal_1_th_6 sorry
            then have "a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 >=XXREAL-0R2 0NUMBERSK6"
              using xcmplx_0_def_9 sorry
            then have "(a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5)*XCMPLX-0K3 n >=XXREAL-0R2 (0NUMBERSK6)*XCMPLX-0K3 n"
              using A8 sorry
            then have "a *XCMPLX-0K3 (n \<inverse>XCMPLX-0K5 *XCMPLX-0K3 n) >=XXREAL-0R2 0NUMBERSK6"
               sorry
            then have "a *XCMPLX-0K3 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
              using A1 xcmplx_0_def_7 sorry
            thus " not  True "
              using A6 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "a *XCMPLX-0K3 n \<inverse>XCMPLX-0K5 >=XXREAL-0R2 (-XCMPLX-0K4 n)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5"
          using A7 A8 xreal_1_th_64 sorry
        then have "a /XCMPLX-0K7 n >=XXREAL-0R2 -XCMPLX-0K4 n *XCMPLX-0K3 n \<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        then have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 n"
          using A1 xcmplx_0_def_7 sorry
        then have "[\\INT-1K2 a /XCMPLX-0K7 n /] =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          using A9 int_1_def_6 sorry
        then have A10: "a divINT-1K5 n =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
          using int_1_def_9 sorry
        have "a modINT-1K6 n =HIDDENR1 a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n"
          using A1 int_1_def_10 sorry
        thus "a modINT-1K6 n =HIDDENR1 n +XCMPLX-0K2 a"
          using A10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_64:
" for n be IntegerINT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (n <>HIDDENR2 0NUMBERSK6 & a modINT-1K6 n =HIDDENR1 b modINT-1K6 n implies (a,b)are-congruent-modINT-1R3 n) & ((a,b)are-congruent-modINT-1R3 n implies a modINT-1K6 n =HIDDENR1 b modINT-1K6 n)"
proof-
  have " for n be IntegerINT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (n <>HIDDENR2 0NUMBERSK6 implies (a modINT-1K6 n =HIDDENR1 b modINT-1K6 n implies (a,b)are-congruent-modINT-1R3 n)) & ((a,b)are-congruent-modINT-1R3 n implies a modINT-1K6 n =HIDDENR1 b modINT-1K6 n)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix n assume [ty]: "n be IntegerINT-1M1"
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    show "n <>HIDDENR2 0NUMBERSK6 implies (a modINT-1K6 n =HIDDENR1 b modINT-1K6 n implies (a,b)are-congruent-modINT-1R3 n)"
    proof(rule impI,rule impI)
      assume A1: "n <>HIDDENR2 0NUMBERSK6"
      assume "a modINT-1K6 n =HIDDENR1 b modINT-1K6 n"
      then have "a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n =HIDDENR1 b modINT-1K6 n"
        using A1 int_1_def_10 sorry
      then have "a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n =XBOOLE-0R4 b -XCMPLX-0K6 (b divINT-1K5 n)*XCMPLX-0K3 n"
        using A1 int_1_def_10 sorry
      then have "a -XCMPLX-0K6 b =XBOOLE-0R4 ((-XCMPLX-0K4 (b divINT-1K5 n))+XCMPLX-0K2 (a divINT-1K5 n))*XCMPLX-0K3 n"
         sorry
      then have "n dividesINT-1R1 a -XCMPLX-0K6 b"
        using int_1_def_3 sorry
      thus "(a,b)are-congruent-modINT-1R3 n"
        using int_2_th_15 sorry
    qed
    assume "(a,b)are-congruent-modINT-1R3 n"
    then have "n dividesINT-1R1 a -XCMPLX-0K6 b"
      using int_2_th_15 sorry
    then obtain k where
      [ty]:"k be IntegerINT-1M1" and 
      A2: "n *XCMPLX-0K3 k =XBOOLE-0R4 a -XCMPLX-0K6 b"
      using int_1_def_3 sorry
    have "a =HIDDENR1 n *XCMPLX-0K3 k +XCMPLX-0K2 b"
      using A2 sorry
    thus "a modINT-1K6 n =HIDDENR1 b modINT-1K6 n"
      using nat_d_th_61 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_65:
" for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for a be IntegerINT-1M1 holds (a modINT-1K6 n)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  fix a assume [ty]: "a be IntegerINT-1M1"
  show "(a modINT-1K6 n)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
  proof-
    have cases: "n =HIDDENR1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "n =HIDDENR1 0NUMBERSK6 implies (a modINT-1K6 n)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
    proof(rule impI)
      assume A1: "n =HIDDENR1 0NUMBERSK6"
      then have "(a modINT-1K6 n)modINT-1K6 n =HIDDENR1 0NUMBERSK6"
        using int_1_def_10 sorry
      also have "... = a modINT-1K6 n"
        using A1 int_1_def_10 sorry
      finally show "(a modINT-1K6 n)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
         sorry
    qed
    have case2: "n <>HIDDENR2 0NUMBERSK6 implies (a modINT-1K6 n)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
    proof(rule impI)
      assume "n <>HIDDENR2 0NUMBERSK6"
      then have "a modINT-1K6 n >=XXREAL-0R2 0NUMBERSK6 & a modINT-1K6 n <XXREAL-0R3 n"
        using nat_d_th_62 sorry
      thus "(a modINT-1K6 n)modINT-1K6 n =HIDDENR1 a modINT-1K6 n"
        using nat_d_th_63 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem nat_d_th_66:
" for n be IntegerINT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds (a +XCMPLX-0K2 b)modINT-1K6 n =HIDDENR1 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))modINT-1K6 n"
proof(rule ballI,rule ballI,rule ballI)
  fix n assume [ty]: "n be IntegerINT-1M1"
  fix a assume [ty]: "a be IntegerINT-1M1"
  fix b assume [ty]: "b be IntegerINT-1M1"
  show "(a +XCMPLX-0K2 b)modINT-1K6 n =HIDDENR1 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))modINT-1K6 n"
  proof-
    have cases: "n =HIDDENR1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "n =HIDDENR1 0NUMBERSK6 implies (a +XCMPLX-0K2 b)modINT-1K6 n =HIDDENR1 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))modINT-1K6 n"
    proof(rule impI)
      assume A1: "n =HIDDENR1 0NUMBERSK6"
      then have "(a +XCMPLX-0K2 b)modINT-1K6 n =HIDDENR1 0NUMBERSK6"
        using int_1_def_10 sorry
      also have "... = ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))modINT-1K6 n"
        using A1 int_1_def_10 sorry
      finally show "(a +XCMPLX-0K2 b)modINT-1K6 n =HIDDENR1 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))modINT-1K6 n"
         sorry
    qed
    have case2: "n <>HIDDENR2 0NUMBERSK6 implies (a +XCMPLX-0K2 b)modINT-1K6 n =HIDDENR1 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))modINT-1K6 n"
    proof(rule impI)
      assume "n <>HIDDENR2 0NUMBERSK6"
      then have "(a modINT-1K6 n)+XCMPLX-0K2 (a divINT-1K5 n)*XCMPLX-0K3 n =XBOOLE-0R4 (a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n)+XCMPLX-0K2 (a divINT-1K5 n)*XCMPLX-0K3 n & (b modINT-1K6 n)+XCMPLX-0K2 (b divINT-1K5 n)*XCMPLX-0K3 n =XBOOLE-0R4 (b -XCMPLX-0K6 (b divINT-1K5 n)*XCMPLX-0K3 n)+XCMPLX-0K2 (b divINT-1K5 n)*XCMPLX-0K3 n"
        using int_1_def_10 sorry
      then have "(a +XCMPLX-0K2 b)-XCMPLX-0K6 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n)) =XBOOLE-0R4 ((a divINT-1K5 n)+XCMPLX-0K2 (b divINT-1K5 n))*XCMPLX-0K3 n"
         sorry
      then have "n dividesINT-1R1 (a +XCMPLX-0K2 b)-XCMPLX-0K6 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))"
        using int_1_def_3 sorry
      then have "(a +XCMPLX-0K2 b,(a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))are-congruent-modINT-1R3 n"
        using int_2_th_15 sorry
      thus "(a +XCMPLX-0K2 b)modINT-1K6 n =HIDDENR1 ((a modINT-1K6 n)+XCMPLX-0K2 (b modINT-1K6 n))modINT-1K6 n"
        using nat_d_th_64 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem nat_d_th_67:
" for n be IntegerINT-1M1 holds  for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a *XCMPLX-0K3 b modINT-1K6 n =HIDDENR1 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) modINT-1K6 n"
proof(rule ballI,rule ballI,rule ballI)
  fix n assume [ty]: "n be IntegerINT-1M1"
  fix a assume [ty]: "a be IntegerINT-1M1"
  fix b assume [ty]: "b be IntegerINT-1M1"
  show "a *XCMPLX-0K3 b modINT-1K6 n =HIDDENR1 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) modINT-1K6 n"
  proof-
    have cases: "n =HIDDENR1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "n =HIDDENR1 0NUMBERSK6 implies a *XCMPLX-0K3 b modINT-1K6 n =HIDDENR1 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) modINT-1K6 n"
    proof(rule impI)
      assume A1: "n =HIDDENR1 0NUMBERSK6"
      then have "a *XCMPLX-0K3 b modINT-1K6 n =HIDDENR1 0NUMBERSK6"
        using int_1_def_10 sorry
      also have "... = (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) modINT-1K6 n"
        using A1 int_1_def_10 sorry
      finally show "a *XCMPLX-0K3 b modINT-1K6 n =HIDDENR1 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) modINT-1K6 n"
         sorry
    qed
    have case2: "n <>HIDDENR2 0NUMBERSK6 implies a *XCMPLX-0K3 b modINT-1K6 n =HIDDENR1 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) modINT-1K6 n"
    proof(rule impI)
      assume "n <>HIDDENR2 0NUMBERSK6"
      then have "(a modINT-1K6 n)+XCMPLX-0K2 (a divINT-1K5 n)*XCMPLX-0K3 n =XBOOLE-0R4 (a -XCMPLX-0K6 (a divINT-1K5 n)*XCMPLX-0K3 n)+XCMPLX-0K2 (a divINT-1K5 n)*XCMPLX-0K3 n & (b modINT-1K6 n)+XCMPLX-0K2 (b divINT-1K5 n)*XCMPLX-0K3 n =XBOOLE-0R4 (b -XCMPLX-0K6 (b divINT-1K5 n)*XCMPLX-0K3 n)+XCMPLX-0K2 (b divINT-1K5 n)*XCMPLX-0K3 n"
        using int_1_def_10 sorry
      then have "a *XCMPLX-0K3 b -XCMPLX-0K6 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) =XBOOLE-0R4 ((a modINT-1K6 n)*XCMPLX-0K3 (b divINT-1K5 n) +XCMPLX-0K2 ((a divINT-1K5 n)*XCMPLX-0K3 (b modINT-1K6 n) +XCMPLX-0K2 ((a divINT-1K5 n)*XCMPLX-0K3 n)*XCMPLX-0K3 (b divINT-1K5 n)))*XCMPLX-0K3 n"
         sorry
      then have "n dividesINT-1R1 a *XCMPLX-0K3 b -XCMPLX-0K6 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n)"
        using int_1_def_3 sorry
      then have "(a *XCMPLX-0K3 b,(a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n))are-congruent-modINT-1R3 n"
        using int_2_th_15 sorry
      thus "a *XCMPLX-0K3 b modINT-1K6 n =HIDDENR1 (a modINT-1K6 n)*XCMPLX-0K3 (b modINT-1K6 n) modINT-1K6 n"
        using nat_d_th_64 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

(*\$N Bezout's identity*)
(*\$N Bezout's lemma*)
mtheorem nat_d_th_68:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  ex s be IntegerINT-1M1 st  ex t be IntegerINT-1M1 st a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    have A1: " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies ( ex s be IntegerINT-1M1 st  ex t be IntegerINT-1M1 st a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
    proof-
      have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix a assume [ty]: "a be IntegerINT-1M1"
        fix b assume [ty]: "b be IntegerINT-1M1"
        assume A2: "a >XXREAL-0R4 0NUMBERSK6"
          and A3: "b >XXREAL-0R4 0NUMBERSK6"
        have 
          [ty]:"a be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"b be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A2 A3 int_1_th_3 sorry
        let ?M = "{z where z be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex s be IntegerINT-1M1 st  ex t be IntegerINT-1M1 st z =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b }"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 ?M & Lamb1 <>HIDDENR2 0NUMBERSK6"
        have "a =XBOOLE-0R4 \<one>\<^sub>M *NAT-1K2 a +NAT-1K1 (0NUMBERSK6)*NAT-1K2 b"
           sorry
        then have A4: "a inTARSKIR2 ?M"
           sorry
        then have A5: " ex k be NatNAT-1M1 st ?P(k)"
          using A2 sorry
        obtain g where
          [ty]:"g be NatNAT-1M1" and 
          A6: "?P(g) & ( for n be NatNAT-1M1 holds ?P(n) implies g <=XXREAL-0R1 n)"
          using nat_1_sch_5 A5 sorry
        let ?G = "{zz where zz be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex s be ElementSUBSET-1M1-of NATNUMBERSK1 st zz =XBOOLE-0R4 s *XCMPLX-0K3 g }"
        have " ex z be ElementSUBSET-1M1-of NATNUMBERSK1 st z =XBOOLE-0R4 g & ( ex s be IntegerINT-1M1 st  ex t be IntegerINT-1M1 st z =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
          using A6 sorry
        then obtain s t where
          [ty]:"s be IntegerINT-1M1" "t be IntegerINT-1M1" and 
          A7: "g =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b"
           sorry
        have A8: " for x be objectHIDDENM1 holds x inHIDDENR3 ?M implies x inHIDDENR3 ?G"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {z where z be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex s be IntegerINT-1M1 st  ex t be IntegerINT-1M1 st z =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b } implies x inHIDDENR3 {zz where zz be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for s be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not zz =XBOOLE-0R4 s *XCMPLX-0K3 g) }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?M"
            then obtain x9 where
              [ty]:"x9 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A9: "x9 =HIDDENR1 x"and A10: " ex u be IntegerINT-1M1 st  ex v be IntegerINT-1M1 st x9 =XBOOLE-0R4 u *XCMPLX-0K3 a +XCMPLX-0K2 v *XCMPLX-0K3 b"
               sorry
            obtain u v where
              [ty]:"u be IntegerINT-1M1" "v be IntegerINT-1M1" and 
              A11: "x =HIDDENR1 u *XCMPLX-0K3 a +XCMPLX-0K2 v *XCMPLX-0K3 b"
              using A9 A10 sorry
            obtain r where
              [ty]:"r be NatNAT-1M1" and 
              A12: "x9 =XBOOLE-0R4 g *XCMPLX-0K3 (x9 divNAT-DK3 g) +XCMPLX-0K2 r"and A13: "r <XXREAL-0R3 g"
              using A6 nat_d_def_1 sorry
            have A14: "r inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "r =HIDDENR1 x9 -XCMPLX-0K6 g *XCMPLX-0K3 (x9 divNAT-DK3 g)"
              using A12 sorry
            also have "... = a *XCMPLX-0K3 (u +XCMPLX-0K2 (-XCMPLX-0K4 s *XCMPLX-0K3 (x9 divNAT-DK3 g))) +XCMPLX-0K2 b *XCMPLX-0K3 (v +XCMPLX-0K2 (-XCMPLX-0K4 t *XCMPLX-0K3 (x9 divNAT-DK3 g)))"
              using A7 A9 A11 sorry
            finally have "r =HIDDENR1 a *XCMPLX-0K3 (u +XCMPLX-0K2 (-XCMPLX-0K4 s *XCMPLX-0K3 (x9 divNAT-DK3 g))) +XCMPLX-0K2 b *XCMPLX-0K3 (v +XCMPLX-0K2 (-XCMPLX-0K4 t *XCMPLX-0K3 (x9 divNAT-DK3 g)))"
               sorry
            then have "r inTARSKIR2 ?M"
              using A14 sorry
            then have "r =XBOOLE-0R4 0NUMBERSK6"
              using A6 A13 sorry
            thus "x inHIDDENR3 {zz where zz be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for s be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not zz =XBOOLE-0R4 s *XCMPLX-0K3 g) }"
              using A9 A12 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 ?G implies x inHIDDENR3 ?M"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {zz where zz be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex s be ElementSUBSET-1M1-of NATNUMBERSK1 st zz =XBOOLE-0R4 s *XCMPLX-0K3 g } implies x inHIDDENR3 {z where z be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not z =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?G"
            then have A15: " ex x9 be ElementSUBSET-1M1-of NATNUMBERSK1 st x9 =HIDDENR1 x & ( ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st x9 =XBOOLE-0R4 u *XCMPLX-0K3 g)"
               sorry
            then obtain u where
              [ty]:"u be IntegerINT-1M1" and 
              A16: "x =HIDDENR1 u *XCMPLX-0K3 g"
               sorry
            have "x =HIDDENR1 (u *XCMPLX-0K3 s)*XCMPLX-0K3 a +XCMPLX-0K2 (u *XCMPLX-0K3 t)*XCMPLX-0K3 b"
              using A7 A16 sorry
            thus "x inHIDDENR3 {z where z be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not z =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) }"
              using A15 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A17: "?G =XBOOLE-0R4 ?M"
          using A8 tarski_th_2 sorry
        have A18: " |.INT-2K1 b.| =XBOOLE-0R4 b"
          using absvalue_def_1 sorry
        have A19: " |.INT-2K1 a.| =XBOOLE-0R4 a"
          using absvalue_def_1 sorry
        have A20: " for m be NatNAT-1M1 holds m dividesNAT-DR1  |.INT-2K1 a.| & m dividesNAT-DR1  |.INT-2K1 b.| implies m dividesNAT-DR1 g"
        proof(rule ballI,rule impMI ,rule impI)
          have " ex g9 be ElementSUBSET-1M1-of NATNUMBERSK1 st g9 =XBOOLE-0R4 g & ( ex s be IntegerINT-1M1 st  ex t be IntegerINT-1M1 st g9 =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
            using A6 sorry
          then obtain s t where
            [ty]:"s be IntegerINT-1M1" "t be IntegerINT-1M1" and 
            A21: "g =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b"
             sorry
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A22: "m dividesNAT-DR1  |.INT-2K1 a.|"
            and A23: "m dividesNAT-DR1  |.INT-2K1 b.|"
          obtain u where
            [ty]:"u be NatNAT-1M1" and 
            A24: "a =XBOOLE-0R4 m *XCMPLX-0K3 u"
            using A19 A22 sorry
          obtain v where
            [ty]:"v be NatNAT-1M1" and 
            A25: "b =XBOOLE-0R4 m *XCMPLX-0K3 v"
            using A18 A23 sorry
          have A26: "g =XBOOLE-0R4 m *XCMPLX-0K3 (s *XCMPLX-0K3 u +XCMPLX-0K2 t *XCMPLX-0K3 v)"
            using A24 A25 A21 sorry
          then have "s *XCMPLX-0K3 u +XCMPLX-0K2 t *XCMPLX-0K3 v >=XXREAL-0R2 0NUMBERSK6"
            using A6 sorry
          then have "s *XCMPLX-0K3 u +XCMPLX-0K2 t *XCMPLX-0K3 v be ElementSUBSET-1M1-of NATNUMBERSK1"
            using int_1_th_3 sorry
          thus "m dividesNAT-DR1 g"
            using A26 sorry
        qed "sorry"
        have "b =XBOOLE-0R4 (0NUMBERSK6)*NAT-1K2 a +NAT-1K1 \<one>\<^sub>M *NAT-1K2 b"
           sorry
        then have "b inTARSKIR2 ?M"
           sorry
        then have " ex b9 be ElementSUBSET-1M1-of NATNUMBERSK1 st b9 =XBOOLE-0R4 b & ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st b9 =XBOOLE-0R4 t *XCMPLX-0K3 g)"
          using A17 sorry
        then have A27: "g dividesNAT-DR1  |.INT-2K1 b.|"
          using A18 sorry
        have " ex a9 be ElementSUBSET-1M1-of NATNUMBERSK1 st a9 =XBOOLE-0R4 a & ( ex s be ElementSUBSET-1M1-of NATNUMBERSK1 st a9 =XBOOLE-0R4 s *XCMPLX-0K3 g)"
          using A4 A17 sorry
        then have "g dividesNAT-DR1  |.INT-2K1 a.|"
          using A19 sorry
        then have "g =HIDDENR1  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b.|"
          using A27 A20 nat_d_def_5 sorry
        also have "... = a gcdNAT-DK8 b"
          using int_2_th_34 sorry
        finally have "g =HIDDENR1 a gcdNAT-DK8 b"
           sorry
        thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
          using A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(a =HIDDENR1 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6) &  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) or (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))"
    proof-
      show "(a =HIDDENR1 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6) &  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) or (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))"
      proof-
        have cases: "(a =HIDDENR1 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6) or a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "a =HIDDENR1 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
        proof(rule impI)
          assume A28: "a =HIDDENR1 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6"
          have A29: " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a =HIDDENR1 0NUMBERSK6 implies a gcdINT-2K3 b =XBOOLE-0R4  |.INT-2K1 b.|"
          proof(rule ballI,rule ballI,rule impI)
            fix a assume [ty]: "a be IntegerINT-1M1"
            fix b assume [ty]: "b be IntegerINT-1M1"
            assume "a =HIDDENR1 0NUMBERSK6"
            then have " |.INT-2K1 a.| =XBOOLE-0R4 0NUMBERSK6"
              using absvalue_def_1 sorry
            then have A30: " |.INT-2K1 b.| dividesNAT-DR1  |.INT-2K1 a.|"
              using nat_d_th_6 sorry
            have "a gcdINT-2K3 b =XBOOLE-0R4  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b.| & ( for m be NatNAT-1M1 holds m dividesNAT-DR1  |.INT-2K1 a.| & m dividesNAT-DR1  |.INT-2K1 b.| implies m dividesNAT-DR1  |.INT-2K1 b.|)"
              using int_2_th_34 sorry
            thus "a gcdINT-2K3 b =XBOOLE-0R4  |.INT-2K1 b.|"
              using A30 nat_d_def_5 sorry
          qed "sorry"
          have "a =HIDDENR1 0NUMBERSK6 &  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) or b =HIDDENR1 0NUMBERSK6 & (b =HIDDENR1 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))"
          proof-
            show "a =HIDDENR1 0NUMBERSK6 &  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) or b =HIDDENR1 0NUMBERSK6 & (b =HIDDENR1 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))"
            proof-
              have cases: "a =HIDDENR1 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6"
                using A28 sorry
              have case1: "a =HIDDENR1 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
              proof(rule impI)
                assume "a =HIDDENR1 0NUMBERSK6"
                then have A31: "a gcdINT-2K3 b =XBOOLE-0R4  |.INT-2K1 b.|"
                  using A29 sorry
                have "b >=XXREAL-0R2 0NUMBERSK6 & a gcdINT-2K3 b =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 b or b <XXREAL-0R3 0NUMBERSK6 & (b <XXREAL-0R3 0NUMBERSK6 implies a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b)"
                proof-
                  show "b >=XXREAL-0R2 0NUMBERSK6 & a gcdINT-2K3 b =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 b or b <XXREAL-0R3 0NUMBERSK6 & (b <XXREAL-0R3 0NUMBERSK6 implies a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b)"
                  proof-
                    have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
                       sorry
                    have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies a gcdINT-2K3 b =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 b"
                    proof(rule impI)
                      assume "b >=XXREAL-0R2 0NUMBERSK6"
                      thus "a gcdINT-2K3 b =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 b"
                        using A31 absvalue_def_1 sorry
                    qed
                    have case2: "b <XXREAL-0R3 0NUMBERSK6 implies a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
                    proof(rule impI)
                      assume "b <XXREAL-0R3 0NUMBERSK6"
                      then have "a gcdINT-2K3 b =HIDDENR1 -XCMPLX-0K4 b *XCMPLX-0K3 \<one>\<^sub>M"
                        using A31 absvalue_def_1 sorry
                      also have "... = (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
                         sorry
                      finally show "a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
                         sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
                   sorry
              qed
              have case2: "b =HIDDENR1 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
              proof(rule impI)
                assume "b =HIDDENR1 0NUMBERSK6"
                then have A32: "a gcdINT-2K3 b =XBOOLE-0R4  |.INT-2K1 a.|"
                  using A29 sorry
                have "a >=XXREAL-0R2 0NUMBERSK6 & a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 b or a <XXREAL-0R3 0NUMBERSK6 & (a <XXREAL-0R3 0NUMBERSK6 implies a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 b +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a)"
                proof-
                  show "a >=XXREAL-0R2 0NUMBERSK6 & a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 b or a <XXREAL-0R3 0NUMBERSK6 & (a <XXREAL-0R3 0NUMBERSK6 implies a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 b +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a)"
                  proof-
                    have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
                       sorry
                    have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 b"
                    proof(rule impI)
                      assume "a >=XXREAL-0R2 0NUMBERSK6"
                      thus "a gcdINT-2K3 b =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 b"
                        using A32 absvalue_def_1 sorry
                    qed
                    have case2: "a <XXREAL-0R3 0NUMBERSK6 implies a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 b +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a"
                    proof(rule impI)
                      assume "a <XXREAL-0R3 0NUMBERSK6"
                      then have "a gcdINT-2K3 b =HIDDENR1 -XCMPLX-0K4 a *XCMPLX-0K3 \<one>\<^sub>M"
                        using A32 absvalue_def_1 sorry
                      also have "... = (0NUMBERSK6)*XCMPLX-0K3 b +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a"
                         sorry
                      finally show "a gcdINT-2K3 b =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 b +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a"
                         sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
             sorry
        qed
        have case2: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
        proof(rule impI)
          assume A33: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
          have "(((a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) &  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) or (a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & (a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))) or (a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) & (a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))) or (a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) & (a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))"
          proof-
            show "(((a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) &  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b) or (a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & (a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))) or (a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) & (a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))) or (a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) & (a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b))"
            proof-
              have cases: "((a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) or a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) or a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6"
                 sorry
              have case1: "a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
              proof(rule impI)
                assume "a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6"
                thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
                  using A1 A33 sorry
              qed
              have case2: "a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
              proof(rule impI)
                assume A34: "a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6"
                then have "-XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6"
                  using xreal_1_th_58 sorry
                then obtain s t where
                  [ty]:"s be IntegerINT-1M1" "t be IntegerINT-1M1" and 
                  A35: "(-XCMPLX-0K4 a)gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 (-XCMPLX-0K4 a) +XCMPLX-0K2 t *XCMPLX-0K3 b"
                  using A1 A33 A34 sorry
                have A36: "a gcdINT-2K3 b =HIDDENR1  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b.|"
                  using int_2_th_34 sorry
                also have "... =  |.INT-2K1 -XCMPLX-0K4 a .| gcdNAT-DK8  |.INT-2K1 b.|"
                  using complex1_th_52 sorry
                also have "... = (-XCMPLX-0K4 a)gcdINT-2K3 b"
                  using int_2_th_34 sorry
                finally have "a gcdINT-2K3 b =HIDDENR1 (-XCMPLX-0K4 a)gcdINT-2K3 b"
                   sorry
                have "s *XCMPLX-0K3 (-XCMPLX-0K4 a) +XCMPLX-0K2 t *XCMPLX-0K3 b =XBOOLE-0R4 (-XCMPLX-0K4 s)*XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b"
                   sorry
                thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
                  using A35 A36 sorry
              qed
              have case3: "a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
              proof(rule impI)
                assume A37: "a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6"
                then have "-XCMPLX-0K4 b >XXREAL-0R4 0NUMBERSK6"
                  using xreal_1_th_58 sorry
                then obtain s t where
                  [ty]:"s be IntegerINT-1M1" "t be IntegerINT-1M1" and 
                  A38: "a gcdINT-2K3 (-XCMPLX-0K4 b) =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 (-XCMPLX-0K4 b)"
                  using A1 A33 A37 sorry
                have A39: "a gcdINT-2K3 b =HIDDENR1  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b.|"
                  using int_2_th_34 sorry
                also have "... =  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 -XCMPLX-0K4 b .|"
                  using complex1_th_52 sorry
                also have "... = a gcdINT-2K3 (-XCMPLX-0K4 b)"
                  using int_2_th_34 sorry
                finally have "a gcdINT-2K3 b =HIDDENR1 a gcdINT-2K3 (-XCMPLX-0K4 b)"
                   sorry
                have "s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 (-XCMPLX-0K4 b) =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 (-XCMPLX-0K4 t)*XCMPLX-0K3 b"
                   sorry
                thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
                  using A38 A39 sorry
              qed
              have case4: "a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies  not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
              proof(rule impI)
                assume "a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6"
                then have "-XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6 & -XCMPLX-0K4 b >XXREAL-0R4 0NUMBERSK6"
                  using xreal_1_th_58 sorry
                then obtain s t where
                  [ty]:"s be IntegerINT-1M1" "t be IntegerINT-1M1" and 
                  A40: "(-XCMPLX-0K4 a)gcdINT-2K3 (-XCMPLX-0K4 b) =XBOOLE-0R4 s *XCMPLX-0K3 (-XCMPLX-0K4 a) +XCMPLX-0K2 t *XCMPLX-0K3 (-XCMPLX-0K4 b)"
                  using A1 sorry
                have A41: "a gcdINT-2K3 b =HIDDENR1  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b.|"
                  using int_2_th_34 sorry
                also have "... =  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 -XCMPLX-0K4 b .|"
                  using complex1_th_52 sorry
                also have "... =  |.INT-2K1 -XCMPLX-0K4 a .| gcdNAT-DK8  |.INT-2K1 -XCMPLX-0K4 b .|"
                  using complex1_th_52 sorry
                also have "... = (-XCMPLX-0K4 a)gcdINT-2K3 (-XCMPLX-0K4 b)"
                  using int_2_th_34 sorry
                finally have "a gcdINT-2K3 b =HIDDENR1 (-XCMPLX-0K4 a)gcdINT-2K3 (-XCMPLX-0K4 b)"
                   sorry
                have "s *XCMPLX-0K3 (-XCMPLX-0K4 a) +XCMPLX-0K2 t *XCMPLX-0K3 (-XCMPLX-0K4 b) =XBOOLE-0R4 (-XCMPLX-0K4 s)*XCMPLX-0K3 a +XCMPLX-0K2 (-XCMPLX-0K4 t)*XCMPLX-0K3 b"
                   sorry
                thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
                  using A40 A41 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 case4 sorry
            qed
          qed
          thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for s be IntegerINT-1M1 holds  for t be IntegerINT-1M1 holds  not a gcdINT-2K3 b =XBOOLE-0R4 s *XCMPLX-0K3 a +XCMPLX-0K2 t *XCMPLX-0K3 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_69:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 k =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 k =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    show "n modNAT-DK2 k =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have cases: "k <>HIDDENR2 0NUMBERSK6 or k =HIDDENR1 0NUMBERSK6"
         sorry
      have case1: "k <>HIDDENR2 0NUMBERSK6 implies (n modNAT-DK2 k =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6)"
      proof(rule impI,rule impI)
        assume "k <>HIDDENR2 0NUMBERSK6"
        then have "k >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_14 sorry
        then obtain K where 
          [ty]:"K be ElementSUBSET-1M1-of NATNUMBERSK1" and KDef:"K = k -XCMPLX-0K6 \<one>\<^sub>M"
          using int_1_th_3 xreal_1_th_48 sorry
        have A1: "K +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k -XCMPLX-0K6 0NUMBERSK6"
           sorry
        assume "n modNAT-DK2 k =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M"
        then have "(n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 k modNAT-DK2 k"
          using A1 nat_d_th_22 sorry
        thus "(n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6"
          using nat_d_th_25 sorry
      qed
      have case2: "k =HIDDENR1 0NUMBERSK6 implies  not (n modNAT-DK2 k =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M &  not (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6)"
      proof(rule impI)
        assume "k =HIDDENR1 0NUMBERSK6"
        thus " not (n modNAT-DK2 k =XBOOLE-0R4 k -XCMPLX-0K6 \<one>\<^sub>M &  not (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 0NUMBERSK6)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_70:
" for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 k <XXREAL-0R3 k -XCMPLX-0K6 \<one>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 (n modNAT-DK2 k)+NAT-1K1 \<one>\<^sub>M"
proof-
  have " for k be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds n modNAT-DK2 k <XXREAL-0R3 k -XCMPLX-0K6 \<one>\<^sub>M implies (n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 (n modNAT-DK2 k)+NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "n modNAT-DK2 k <XXREAL-0R3 k -XCMPLX-0K6 \<one>\<^sub>M"
    then have A1: "(n modNAT-DK2 k)+NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 k"
      using xreal_1_th_20 sorry
    have "(n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 ((n modNAT-DK2 k)+NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k"
      using nat_d_th_22 sorry
    thus "(n +NAT-1K1 \<one>\<^sub>M)modNAT-DK2 k =XBOOLE-0R4 (n modNAT-DK2 k)+NAT-1K1 \<one>\<^sub>M"
      using A1 nat_d_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem nat_d_th_71:
" for i be IntegerINT-1M1 holds  for n be NatNAT-1M1 holds i *XCMPLX-0K3 n modINT-1K6 n =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule ballI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  have "i *XCMPLX-0K3 n modINT-1K6 n =HIDDENR1 (i modINT-1K6 n)*XCMPLX-0K3 (n modNAT-DK4 n) modINT-1K6 n"
    using nat_d_th_67 sorry
  also have "... = (i modINT-1K6 n)*XCMPLX-0K3 (0NUMBERSK6) modINT-1K6 n"
    using nat_d_th_25 sorry
  also have "... = 0NUMBERSK6 modNAT-DK4 n"
     sorry
  finally have "i *XCMPLX-0K3 n modINT-1K6 n =HIDDENR1 0NUMBERSK6 modNAT-DK4 n"
     sorry
  thus "i *XCMPLX-0K3 n modINT-1K6 n =HIDDENR1 0NUMBERSK6"
    using nat_d_th_26 sorry
qed "sorry"

mtheorem nat_d_th_72:
" for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6 implies (m -'XREAL-0K1 n)+XCMPLX-0K2 n =HIDDENR1 m"
proof-
  have " for m be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds m -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6 implies (m -'XREAL-0K1 n)+XCMPLX-0K2 n =HIDDENR1 m"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "m -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6"
    then have "m -'XREAL-0K1 n =XBOOLE-0R4 m -XCMPLX-0K6 n"
      using xreal_0_def_2 sorry
    thus "(m -'XREAL-0K1 n)+XCMPLX-0K2 n =HIDDENR1 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
