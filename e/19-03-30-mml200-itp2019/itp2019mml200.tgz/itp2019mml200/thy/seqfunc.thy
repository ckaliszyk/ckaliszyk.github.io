theory seqfunc
  imports fcont_1 classes1 limfunc1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve D1, D2, x, y for "setHIDDENM2"
reserve n, k for "NatNAT-1M1"
reserve p, x1, r for "RealXREAL-0M1"
reserve f for "FunctionFUNCT-1M1"
syntax SEQFUNCM1 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("Functional-SequenceSEQFUNCM1-of'( _ , _ ')" [0,0]70)
translations "Functional-SequenceSEQFUNCM1-of(D1,D2)" \<rightharpoonup> "sequenceNAT-1M2-of PFuncsPARTFUN1K4(D1,D2)"

reserve F for "Functional-SequenceSEQFUNCM1-of(D1,D2)"
syntax SEQFUNCK1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .SEQFUNCK1\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "F .SEQFUNCK1\<^bsub>(D1,D2)\<^esub> n" \<rightharpoonup> "F .FUNCT-1K1 n"

mtheorem seqfunc_add_1:
  mlet "D1 be setHIDDENM2", "D2 be setHIDDENM2", "F be Functional-SequenceSEQFUNCM1-of(D1,D2)", "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster F .FUNCT-1K1 n as-term-is PartFuncPARTFUN1M1-of(D1,D2)"
proof
(*coherence*)
  show "F .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2)"
  proof-
    have "n inHIDDENR3 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have "n inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> F"
      using funct_2_def_1 sorry
    then have "F .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(PFuncsPARTFUN1K4(D1,D2))\<^esub> F"
      using funct_1_def_3 sorry
    thus "F .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2)"
      using partfun1_th_46 sorry
  qed
qed "sorry"

reserve G, H, H1, H2, J for "Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
mlemma seqfunc_lm_1:
" for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be Functional-SequenceSEQFUNCM1-of(D1,D2) iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2))"
proof-
  have " for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (f be Functional-SequenceSEQFUNCM1-of(D1,D2) implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2))) & (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2)) implies f be Functional-SequenceSEQFUNCM1-of(D1,D2))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix D1 assume [ty]: "D1 be setHIDDENM2"
    fix D2 assume [ty]: "D2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be Functional-SequenceSEQFUNCM1-of(D1,D2) implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2))"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "f be Functional-SequenceSEQFUNCM1-of(D1,D2)"
      thus "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
        using funct_2_def_1 sorry
      fix x assume [ty]: "x be setHIDDENM2"
      assume "x inTARSKIR2 NATNUMBERSK1"
      then have "x inTARSKIR2 domRELAT-1K1 f"
        using A1 funct_2_def_1 sorry
      then have A2: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
        using funct_1_def_3 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(D1,D2)"
        using A1 relat_1_def_19 sorry
      thus "f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2)"
        using A2 partfun1_th_46 sorry
    qed "sorry"
    assume A3: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
      and A4: " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2)"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 PFuncsPARTFUN1K4(D1,D2)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 f"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "x inHIDDENR3 domRELAT-1K1 f"and A6: "y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have "f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2)"
        using A3 A4 A5 sorry
      thus "y inHIDDENR3 PFuncsPARTFUN1K4(D1,D2)"
        using A6 partfun1_th_45 sorry
    qed "sorry"
    then have "rngFUNCT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(D1,D2)"
       sorry
    thus "f be Functional-SequenceSEQFUNCM1-of(D1,D2)"
      using A3 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_1:
" for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be Functional-SequenceSEQFUNCM1-of(D1,D2) iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2))"
proof-
  have " for D1 be setHIDDENM2 holds  for D2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (f be Functional-SequenceSEQFUNCM1-of(D1,D2) implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2))) & (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2)) implies f be Functional-SequenceSEQFUNCM1-of(D1,D2))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix D1 assume [ty]: "D1 be setHIDDENM2"
    fix D2 assume [ty]: "D2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be Functional-SequenceSEQFUNCM1-of(D1,D2) implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2))"
      using seqfunc_lm_1 ordinal1_def_12 sorry
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
      and A2: " for n be NatNAT-1M1 holds f .FUNCT-1K1 n be PartFuncPARTFUN1M1-of(D1,D2)"
    have " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1,D2)"
      using A2 sorry
    thus "f be Functional-SequenceSEQFUNCM1-of(D1,D2)"
      using A1 seqfunc_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem seqfunc_sch_1:
  fixes D1f0 D2f0 Ff1 
  assumes
[ty]: "D1f0 be setHIDDENM2" and
  [ty]: "D2f0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be PartFuncPARTFUN1M1-of(D1f0,D2f0)"
  shows " ex G be Functional-SequenceSEQFUNCM1-of(D1f0,D2f0) st  for n be NatNAT-1M1 holds G .SEQFUNCK1\<^bsub>(D1f0,D2f0)\<^esub> n =RELSET-1R2\<^bsub>(D1f0,D2f0)\<^esub> Ff1(n)"
  proof-
    have " ex tVar1 be Functional-SequenceSEQFUNCM1-of(D1f0,D2f0) st  for n be NatNAT-1M1 holds tVar1 .SEQFUNCK1\<^bsub>(D1f0,D2f0)\<^esub> n =RELSET-1R2\<^bsub>(D1f0,D2f0)\<^esub> Ff1(n)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
         sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x)"
        using classes1_sch_1 A1 sorry
      have " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1f0,D2f0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 NATNUMBERSK1"
        then have "f .FUNCT-1K1 x =XBOOLE-0R4 Ff1(x)"
          using A3 sorry
        thus "f .FUNCT-1K1 x be PartFuncPARTFUN1M1-of(D1f0,D2f0)"
           sorry
      qed "sorry"
      then have 
        [ty]:"f be Functional-SequenceSEQFUNCM1-of(D1f0,D2f0)"
        using A2 seqfunc_lm_1 sorry
      show " ex tVar1 be Functional-SequenceSEQFUNCM1-of(D1f0,D2f0) st  for n be NatNAT-1M1 holds tVar1 .SEQFUNCK1\<^bsub>(D1f0,D2f0)\<^esub> n =RELSET-1R2\<^bsub>(D1f0,D2f0)\<^esub> Ff1(n)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus "f .SEQFUNCK1\<^bsub>(D1f0,D2f0)\<^esub> n =RELSET-1R2\<^bsub>(D1f0,D2f0)\<^esub> Ff1(n)"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef seqfunc_def_1 (" _ '(#')SEQFUNCK2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "r be RealXREAL-0M1"
"func r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof-
      have " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
      proof-
        let ?U = "\<lambda>Lamb1. r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1"
        show " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using seqfunc_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A1: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          and A2: " for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A1 sorry
          thus "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A2 sorry
        qed "sorry"
        thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef seqfunc_def_2 (" _ \<inverse>SEQFUNCK3\<^bsub>'( _ ')\<^esub>" [228,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
    proof-
      have " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
      proof-
        let ?U = "\<lambda>Lamb1. H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1 ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        show " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
          using seqfunc_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>) & ( for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A1: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
          and A2: " for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
            using A1 sorry
          thus "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A2 sorry
        qed "sorry"
        thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef seqfunc_def_3 ("-SEQFUNCK4\<^bsub>'( _ ')\<^esub>  _ " [0,132]132 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func -SEQFUNCK4\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof-
      have " ex tVar2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds tVar2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
      proof-
        show " ex tVar2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds tVar2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        proof(rule bexI[of _ "(-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H"],rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          show "((-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using seqfunc_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A3: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          and A4: " for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A3 sorry
          thus "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A4 sorry
        qed "sorry"
        thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem SEQFUNCK4_involutiveness:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds -SEQFUNCK4\<^bsub>(D)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H) =HIDDENR1 H"
proof-
  have " for it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds it =HIDDENR1 -SEQFUNCK4\<^bsub>(D)\<^esub> H implies H =HIDDENR1 -SEQFUNCK4\<^bsub>(D)\<^esub> it"
  proof-
    have " for it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof-
      have " for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
      proof(rule ballI,rule ballI,rule impI,rule ballI)
        fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A5: " for n be NatNAT-1M1 holds G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        fix n assume [ty]: "n be NatNAT-1M1"
        have "H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
           sorry
        also have "... = -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using A5 sorry
        finally show "H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using seqfunc_def_3 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef seqfunc_def_4 ("absSEQFUNCK5\<^bsub>'( _ ')\<^esub>  _ " [0,250]250 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func absSEQFUNCK5\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof-
      have " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
      proof-
        let ?U = "\<lambda>Lamb1. absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1)"
        show " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
          using seqfunc_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A6: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
          and A7: " for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
            using A7 sorry
          thus "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A6 sorry
        qed "sorry"
        thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem SEQFUNCK5_projectivity:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (absSEQFUNCK5\<^bsub>(D)\<^esub> H) =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> H"
proof-
  have " for it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds it =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> H implies it =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> it"
  proof-
    have " for it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) implies ( for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n))"
    proof-
      have " for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) implies ( for n be NatNAT-1M1 holds G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n))"
      proof(rule ballI,rule ballI,rule impI,rule ballI)
        fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A8: " for n be NatNAT-1M1 holds G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        fix n assume [ty]: "n be NatNAT-1M1"
        have "G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n))"
          using A8 sorry
        also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
          using A8 sorry
        finally show "G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using seqfunc_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef seqfunc_def_5 (" _ +SEQFUNCK6\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G +SEQFUNCK6\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof-
      have " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
      proof-
        let ?U = "\<lambda>Lamb1. G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1 +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1"
        show " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using seqfunc_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A1: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          and A2: " for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A1 sorry
          thus "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A2 sorry
        qed "sorry"
        thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef seqfunc_def_6 (" _ -SEQFUNCK7\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G -SEQFUNCK7\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) equals
  G +SEQFUNCK6\<^bsub>(D)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H)"
proof-
  (*coherence*)
    show "G +SEQFUNCK6\<^bsub>(D)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H) be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef seqfunc_def_7 (" _ '(#')SEQFUNCK8\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) means
  \<lambda>it.  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof-
      have " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
      proof-
        let ?U = "\<lambda>Lamb1. G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1 (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1"
        show " ex f be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) st  for n be NatNAT-1M1 holds f .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using seqfunc_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
        assume A1: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          and A2: " for n be NatNAT-1M1 holds H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A1 sorry
          thus "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
            using A2 sorry
        qed "sorry"
        thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef seqfunc_def_8 (" _ '/SEQFUNCK9\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
"func G /SEQFUNCK9\<^bsub>(D)\<^esub> H \<rightarrow> Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) equals
  G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
proof-
  (*coherence*)
    show "G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem seqfunc_th_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H iff ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H implies ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    show "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H implies ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof-
      have "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H implies ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
      proof(rule impI,rule ballI)
        assume A1: "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H"
        fix n assume [ty]: "n be NatNAT-1M1"
        have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using A1 seqfunc_def_7 sorry
        also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>)"
          using seqfunc_def_2 sorry
        also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using rfunct_1_th_31 sorry
        finally show "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A2: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G /SEQFUNCK9\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n /RFUNCT-1K3\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using A2 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>)"
        using rfunct_1_th_31 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_2 sorry
      also have "... = (G /SEQFUNCK9\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      finally show "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G /SEQFUNCK9\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> H"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H iff ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H implies ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)) & (( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) implies H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    show "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H implies ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof-
      have "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H implies ( for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
      proof(rule impI,rule ballI)
        assume A1: "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H"
        fix n assume [ty]: "n be NatNAT-1M1"
        have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using A1 seqfunc_def_5 sorry
        also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
          using seqfunc_def_3 sorry
        finally show "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A2: " for n be NatNAT-1M1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G -SEQFUNCK7\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using A2 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_3 sorry
      also have "... = (G -SEQFUNCK7\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      finally show "H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G -SEQFUNCK7\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "H1 =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G +SEQFUNCK6\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H +SEQFUNCK6\<^bsub>(D)\<^esub> G & (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)+SEQFUNCK6\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G +SEQFUNCK6\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H +SEQFUNCK6\<^bsub>(D)\<^esub> G & (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)+SEQFUNCK6\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix J assume [ty]: "J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (G +SEQFUNCK6\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (H +SEQFUNCK6\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(G +SEQFUNCK6\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      also have "... = (H +SEQFUNCK6\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      finally show "(G +SEQFUNCK6\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (H +SEQFUNCK6\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "G +SEQFUNCK6\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H +SEQFUNCK6\<^bsub>(D)\<^esub> G"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((G +SEQFUNCK6\<^bsub>(D)\<^esub> H)+SEQFUNCK6\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G +SEQFUNCK6\<^bsub>(D)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((G +SEQFUNCK6\<^bsub>(D)\<^esub> H)+SEQFUNCK6\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G +SEQFUNCK6\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      also have "... = (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)+VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using rfunct_1_th_8 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      also have "... = (G +SEQFUNCK6\<^bsub>(D)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      finally show "((G +SEQFUNCK6\<^bsub>(D)\<^esub> H)+SEQFUNCK6\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G +SEQFUNCK6\<^bsub>(D)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(G +SEQFUNCK6\<^bsub>(D)\<^esub> H)+SEQFUNCK6\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> (H +SEQFUNCK6\<^bsub>(D)\<^esub> J)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_5:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> G & (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> G & (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix J assume [ty]: "J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      finally show "(G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> G"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using rfunct_1_th_9 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      finally show "((G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J & J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J & J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =HIDDENR1 J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix J assume [ty]: "J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((G +SEQFUNCK6\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((G +SEQFUNCK6\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G +SEQFUNCK6\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using rfunct_1_th_10 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      finally show "((G +SEQFUNCK6\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(G +SEQFUNCK6\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J"
      using funct_2_th_63 sorry
    then have "J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =HIDDENR1 G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J"
      using seqfunc_th_5 sorry
    also have "... = J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J"
      using seqfunc_th_5 sorry
    also have "... = J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H"
      using seqfunc_th_5 sorry
    finally show "J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =HIDDENR1 J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds -SEQFUNCK4\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds -SEQFUNCK4\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_3 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      finally show "(-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "-SEQFUNCK4\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J & J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J & J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =HIDDENR1 J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix J assume [ty]: "J be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G -SEQFUNCK7\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_th_3 sorry
      also have "... = G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using rfunct_1_th_14 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> J .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_th_3 sorry
      finally show "((G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus A1: "(G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> J -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J"
      using funct_2_th_63 sorry
    have "J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =HIDDENR1 J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> H (#)SEQFUNCK8\<^bsub>(D)\<^esub> J"
      using seqfunc_th_5 sorry
    also have "... = (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)(#)SEQFUNCK8\<^bsub>(D)\<^esub> J"
      using A1 seqfunc_th_5 sorry
    also have "... = J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)"
      using seqfunc_th_5 sorry
    finally show "J (#)SEQFUNCK8\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> J (#)SEQFUNCK8\<^bsub>(D)\<^esub> H =HIDDENR1 J (#)SEQFUNCK8\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H & r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H & r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_5 sorry
      also have "... = r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using rfunct_1_th_16 sorry
      also have "... = (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_5 sorry
      finally show "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G +SEQFUNCK6\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G +SEQFUNCK6\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_th_3 sorry
      also have "... = r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using rfunct_1_th_18 sorry
      also have "... = (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_th_3 sorry
      finally show "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (G -SEQFUNCK7\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> G -SEQFUNCK7\<^bsub>(D)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (r *XCMPLX-0K3 p)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds (r *XCMPLX-0K3 p)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((r *XCMPLX-0K3 p)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((r *XCMPLX-0K3 p)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r *XCMPLX-0K3 p)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using rfunct_1_th_17 sorry
      also have "... = r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      finally show "((r *XCMPLX-0K3 p)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(r *XCMPLX-0K3 p)(#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> (p (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds \<one>\<^sub>M (#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds \<one>\<^sub>M (#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (\<one>\<^sub>M (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(\<one>\<^sub>M (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      also have "... = H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using rfunct_1_th_21 sorry
      finally show "(\<one>\<^sub>M (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "\<one>\<^sub>M (#)SEQFUNCK2\<^bsub>(D)\<^esub> H =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> H"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem seqfunc_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      also have "... = (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_2 sorry
      also have "... = (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>)"
        using seqfunc_def_2 sorry
      also have "... = (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        using rfunct_1_th_27 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        using seqfunc_def_7 sorry
      also have "... = (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_2 sorry
      finally show "(G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "G \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> (#)SEQFUNCK8\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r \<inverse>XCMPLX-0K5 (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r \<inverse>XCMPLX-0K5 (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        using seqfunc_def_2 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        using seqfunc_def_1 sorry
      also have "... = r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>)"
        using A1 rfunct_1_th_28 sorry
      also have "... = r \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_2 sorry
      also have "... = (r \<inverse>XCMPLX-0K5 (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      finally show "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)\<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> r \<inverse>XCMPLX-0K5 (#)SEQFUNCK2\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>)"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_4 sorry
      also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>)"
        using seqfunc_def_2 sorry
      also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        using rfunct_1_th_30 sorry
      also have "... = absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n ^RFUNCT-1K6\<^bsub>(D,REALNUMBERSK2)\<^esub>"
        using seqfunc_def_4 sorry
      also have "... = absSEQFUNCK5\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_2 sorry
      finally show "absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absSEQFUNCK5\<^bsub>(D)\<^esub> H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub> =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_16:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absSEQFUNCK5\<^bsub>(D)\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "absSEQFUNCK5\<^bsub>(D)\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> ((G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_4 sorry
      also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_7 sorry
      also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using rfunct_1_th_24 sorry
      also have "... = absSEQFUNCK5\<^bsub>(D)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_4 sorry
      also have "... = absSEQFUNCK5\<^bsub>(D)\<^esub> G .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_4 sorry
      also have "... = (absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_7 sorry
      finally show "absSEQFUNCK5\<^bsub>(D)\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absSEQFUNCK5\<^bsub>(D)\<^esub> (G (#)SEQFUNCK8\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_17:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (G /SEQFUNCK9\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (G /SEQFUNCK9\<^bsub>(D)\<^esub> H) =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have "absSEQFUNCK5\<^bsub>(D)\<^esub> (G /SEQFUNCK9\<^bsub>(D)\<^esub> H) =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> G (#)SEQFUNCK8\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> (H \<inverse>SEQFUNCK3\<^bsub>(D)\<^esub>)"
      using seqfunc_th_16 sorry
    also have "... = absSEQFUNCK5\<^bsub>(D)\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
      using seqfunc_th_15 sorry
    finally show "absSEQFUNCK5\<^bsub>(D)\<^esub> (G /SEQFUNCK9\<^bsub>(D)\<^esub> H) =HIDDENR1 absSEQFUNCK5\<^bsub>(D)\<^esub> G /SEQFUNCK9\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_18:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> ( |.COMPLEX1K10 r.|)(#)SEQFUNCK2\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds absSEQFUNCK5\<^bsub>(D)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> ( |.COMPLEX1K10 r.|)(#)SEQFUNCK2\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absSEQFUNCK5\<^bsub>(D)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)SEQFUNCK2\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "absSEQFUNCK5\<^bsub>(D)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_4 sorry
      also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_1 sorry
      also have "... = ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using rfunct_1_th_25 sorry
      also have "... = ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_4 sorry
      also have "... = (( |.COMPLEX1K10 r.|)(#)SEQFUNCK2\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
        using seqfunc_def_1 sorry
      finally show "absSEQFUNCK5\<^bsub>(D)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H) .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)SEQFUNCK2\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "absSEQFUNCK5\<^bsub>(D)\<^esub> (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,PFuncsPARTFUN1K4(D,REALNUMBERSK2))\<^esub> ( |.COMPLEX1K10 r.|)(#)SEQFUNCK2\<^bsub>(D)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x for "ElementSUBSET-1M1-of D"
reserve X, Y for "setHIDDENM2"
reserve S1, S2 for "Real-SequenceSEQ-1M1"
reserve f for "PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
mdef seqfunc_def_9 (" _ common-on-domSEQFUNCR1\<^bsub>'( _ , _ ')\<^esub>  _ " [50,0,0,50]50 ) where
  mlet "D1 be setHIDDENM2", "D2 be setHIDDENM2", "F be Functional-SequenceSEQFUNCM1-of(D1,D2)", "X be setHIDDENM2"
"pred X common-on-domSEQFUNCR1\<^bsub>(D1,D2)\<^esub> F means
  X <>HIDDENR2 {}XBOOLE-0K1 & ( for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D1)\<^esub> (F .SEQFUNCK1\<^bsub>(D1,D2)\<^esub> n))"..

mdef seqfunc_def_10 (" _ #SEQFUNCK10\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "x be ElementSUBSET-1M1-of D"
"func H #SEQFUNCK10\<^bsub>(D)\<^esub> x \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
    proof-
      have " ex tVar3 be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds tVar3 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
      proof-
        let ?U = "\<lambda>Lamb1. (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb1).FUNCT-1K1 x"
        obtain f where
          [ty]:"f be Real-SequenceSEQ-1M1" and 
          A1: " for n be NatNAT-1M1 holds f .FUNCT-1K1 n =COMPLEX1R1 ?U(n)"
          using seq_1_sch_1 sorry
        show " ex tVar3 be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds tVar3 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        proof(rule bexI[of _ "f"])
          show " for n be NatNAT-1M1 holds f .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x) implies it1 =HIDDENR1 it2"
    proof-
      have " for S1 be Real-SequenceSEQ-1M1 holds  for S2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds S1 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x) & ( for n be NatNAT-1M1 holds S2 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x) implies S1 =HIDDENR1 S2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix S1 assume [ty]: "S1 be Real-SequenceSEQ-1M1"
        fix S2 assume [ty]: "S2 be Real-SequenceSEQ-1M1"
        assume A2: " for n be NatNAT-1M1 holds S1 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
          and A3: " for n be NatNAT-1M1 holds S2 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds S1 .FUNCT-1K1 n =COMPLEX1R1 S2 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "S1 .FUNCT-1K1 n =COMPLEX1R1 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
            using A2 sorry
          thus "S1 .FUNCT-1K1 n =COMPLEX1R1 S2 .FUNCT-1K1 n"
            using A3 sorry
        qed "sorry"
        thus "S1 =HIDDENR1 S2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef seqfunc_def_11 (" _ is-point-conv-onSEQFUNCR2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"pred H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X means
  X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))))"..

mtheorem seqfunc_th_19:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X iff X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds (H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x))) & (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies (( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x)) implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    show "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x))"
    proof-
      have "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex tVar4 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> tVar4 & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 tVar4 .FUNCT-1K1 x))"
      proof(rule impI,rule conjMI)
        assume A1: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
        thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
           sorry
        obtain f where
          [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
          A2: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"and A3: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))"
          using A1 sorry
        show " ex tVar4 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> tVar4 & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 tVar4 .FUNCT-1K1 x)"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI,rule conjMI)
          show "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"
            using A2 sorry
          fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
          assume A4: "x inTARSKIR2 X"
          have A5: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be RealXREAL-0M1"
            assume A6: "p >XXREAL-0R4 0NUMBERSK6"
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A7: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
              using A3 A4 A6 sorry
            have 
              [ty]:"k be NatNAT-1M1"
               sorry
            show " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            proof(rule bexI[of _ "k"],rule ballI,rule impI)
              fix n assume [ty]: "n be NatNAT-1M1"
              assume "n >=XXREAL-0R2 k"
              then have " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
                using A7 sorry
              thus " |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
                using seqfunc_def_10 sorry
            qed "sorry"
          qed "sorry"
          thus "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
            using seq_2_def_6 sorry
          thus "limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x"
            using A5 seq_2_def_7 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume A8: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
    assume Given: " ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x)"
    then obtain f where
      [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
      A9: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"and A10: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x"
       sorry
    have " ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
    proof-
      have " ex tVar6 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> tVar6 & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar7 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar7 implies  not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 tVar6 .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
      proof-
        show " ex tVar6 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> tVar6 & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar7 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar7 implies  not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 tVar6 .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI,rule ballI,rule impI)
          show "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"
            using A9 sorry
          fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
          assume "x inTARSKIR2 X"
          then have A11: "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x"
            using A10 sorry
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume "p >XXREAL-0R4 0NUMBERSK6"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A12: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A11 seq_2_def_7 sorry
          have 
            [ty]:"k be NatNAT-1M1"
             sorry
          show " ex tVar7 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar7 implies  not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
          proof(rule bexI[of _ "k"],rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume "n >=XXREAL-0R2 k"
            then have " |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
              using A12 sorry
            thus " not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
              using seqfunc_def_10 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X iff X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds (H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5)) & (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5) implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10(limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> Lamb1),REALNUMBERSK2)"
    obtain f where
      [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
      A1: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f iff ?X(x)"and A2: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f implies f .FUNCT-1K1 x =COMPLEX1R1 ?U(x)"
      using seq_1_sch_3 sorry
    show "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A3: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
         sorry
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A4: "x inTARSKIR2 X"
      have " ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x)"
        using A3 seqfunc_th_19 sorry
      thus "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A4 sorry
    qed "sorry"
    assume A5: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      and A6: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
    have " ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & f .FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
    proof-
      show " ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & f .FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI,rule conjMI)
        show A7: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"
        proof-
          have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> f & domRELSET-1K1\<^bsub>(D)\<^esub> f c=TARSKIR1 X"
          proof(rule conjMI)
            show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> f"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A8: "x inHIDDENR3 X"
                have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> (0NUMBERSK6))"
                  using A5 sorry
                then have "X c=TARSKIR1 D"
                  using xboole_1_th_1 sorry
                then obtain x9 where 
                  [ty]:"x9 be ElementSUBSET-1M1-of D" and x9Def:"x9 = x"
                  using A8 sorry
                have "x9 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f"
                  using A1 A8 sorry
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f"
                   sorry
              qed "sorry"
              thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> f"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f implies x inHIDDENR3 X"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f"
              thus "x inHIDDENR3 X"
                using A1 sorry
            qed "sorry"
            thus "domRELSET-1K1\<^bsub>(D)\<^esub> f c=TARSKIR1 X"
              using tarski_def_3 sorry
          qed
          thus "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"
            using xboole_0_def_10 sorry
        qed
        fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
        assume A9: "x inTARSKIR2 X"
        thus "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
          using A6 sorry
        have "f .FUNCT-1K1 x =HIDDENR1 InSUBSET-1K10(limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x),REALNUMBERSK2)"
          using A2 A7 A9 sorry
        also have "... = limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
           sorry
        finally show "f .FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
           sorry
      qed "sorry"
    qed
    thus "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A5 seqfunc_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seqfunc_def_12 (" _ is-unif-conv-onSEQFUNCR3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"pred H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X means
  X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & ( ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))"..

mdef seqfunc_def_13 ("limSEQFUNCK11\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"assume H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X func limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) \<rightarrow> PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
proof-
  (*existence*)
    show "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( ex it be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)))"
    proof(rule impI)
      assume Assume: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      have A1: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
        using Assume sorry
      show " ex it be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
      proof-
        have " ex tVar9 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 implies tVar9 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
        proof-
          obtain f where
            [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
            A2: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"and A3: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) =COMPLEX1R1 f .FUNCT-1K1 x"
            using A1 seqfunc_th_19 sorry
          show " ex tVar9 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 implies tVar9 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
          proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
            show "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X"
              using A2 sorry
            fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
            assume "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f"
            thus "f .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
              using A2 A3 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for it1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> it1 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it1 implies it1 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) & (domRELSET-1K1\<^bsub>(D)\<^esub> it2 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it2 implies it2 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      have A1: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
        using Assume sorry
      show " for it1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> it1 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it1 implies it1 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) & (domRELSET-1K1\<^bsub>(D)\<^esub> it2 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it2 implies it2 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) implies it1 =HIDDENR1 it2"
      proof-
        have " for f1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ((domRELSET-1K1\<^bsub>(D)\<^esub> f1 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f1 implies f1 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) & domRELSET-1K1\<^bsub>(D)\<^esub> f2 =XBOOLE-0R4 X) & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f2 implies f2 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)) implies f1 =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> f2"
        proof-
          let ?U = "\<lambda>Lamb1. limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> Lamb1)"
          show " for f1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ((domRELSET-1K1\<^bsub>(D)\<^esub> f1 =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f1 implies f1 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))) & domRELSET-1K1\<^bsub>(D)\<^esub> f2 =XBOOLE-0R4 X) & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f2 implies f2 .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)) implies f1 =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> f2"
            using seq_1_sch_4 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem seqfunc_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies (f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) iff domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies (f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) implies domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))) & (domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))) implies f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    assume A1: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
    show "f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) implies domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
    proof-
      have "f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) implies domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar10 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar10 implies  not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
      proof(rule impI,rule conjMI,rule ballI,rule impI,rule ballI,rule impI)
        assume A2: "f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)"
        thus A3: "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X"
          using A1 seqfunc_def_13 sorry
        fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
        assume A4: "x inTARSKIR2 X"
        then have A5: "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
          using A1 seqfunc_th_20 sorry
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A6: "p >XXREAL-0R4 0NUMBERSK6"
        have "f .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
          using A1 A2 A3 A4 seqfunc_def_13 sorry
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A7: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
          using A5 A6 seq_2_def_7 sorry
        have 
          [ty]:"k be NatNAT-1M1"
           sorry
        show " ex tVar10 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar10 implies  not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n >=XXREAL-0R2 k"
          then have " |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A7 sorry
          thus " not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using seqfunc_def_10 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X"
      and A9: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))"
    have " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f implies f .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A10: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f"
      have A11: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A12: "p >XXREAL-0R4 0NUMBERSK6"
        obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A13: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
          using A8 A9 A10 A12 sorry
        have 
          [ty]:"k be NatNAT-1M1"
           sorry
        show " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n >=XXREAL-0R2 k"
          then have " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A13 sorry
          thus " |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using seqfunc_def_10 sorry
        qed "sorry"
      qed "sorry"
      then have "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using seq_2_def_6 sorry
      thus "f .FUNCT-1K1 x =COMPLEX1R1 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A11 seq_2_def_7 sorry
    qed "sorry"
    thus "f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)"
      using A1 A8 seqfunc_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X"
    have A2: " ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
    proof-
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
        A3: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"and A4: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)"
        using A1 sorry
      show " ex f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI,rule ballI,rule impI)
        show "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"
          using A3 sorry
        fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
        assume A5: "x inTARSKIR2 X"
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume "p >XXREAL-0R4 0NUMBERSK6"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A6: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
          using A4 sorry
        show " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n >=XXREAL-0R2 k"
          thus " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A5 A6 sorry
        qed "sorry"
      qed "sorry"
    qed
    have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A1 sorry
    thus "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1) & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies Y common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X & (Y <>HIDDENR2 {}XBOOLE-0K1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H) implies Y common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 X"
      and A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
    have " for n be NatNAT-1M1 holds Y c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A3 sorry
      thus "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 sorry
    qed "sorry"
    thus "Y common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1) & H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> Y & (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X & (Y <>HIDDENR2 {}XBOOLE-0K1 & H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) implies H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> Y & (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 X"
      and A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
    obtain f where
      [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
      A4: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"and A5: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))"
      using A3 sorry
    have A6: " ex g be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 D,REALNUMBERSK2 :]) st Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> g & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 Y implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
    proof-
      obtain g where 
        [ty]:"g be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 D,REALNUMBERSK2 :])" and gDef:"g = f  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y"
         sorry
      show " ex g be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 D,REALNUMBERSK2 :]) st Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> g & ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 Y implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p)))"
      proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule impI,rule ballI,rule impI)
        show A7: "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> g"
          using A1 A4 relat_1_th_62 sorry
        fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
        assume A8: "x inTARSKIR2 Y"
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume "p >XXREAL-0R4 0NUMBERSK6"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A9: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
          using A1 A5 A8 sorry
        show " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n >=XXREAL-0R2 k"
          then have " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A9 sorry
          thus " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A7 A8 funct_1_th_47 sorry
        qed "sorry"
      qed "sorry"
    qed
    have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A3 sorry
    then have "Y common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A1 A2 seqfunc_th_23 sorry
    thus A10: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> Y"
      using A6 sorry
    have A11: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) implies ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 x =HIDDENR1 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A12: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
      then have A13: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
        using relat_1_th_61 sorry
      then have A14: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
        using xboole_0_def_4 sorry
      have "x inTARSKIR2 Y"
        using A13 xboole_0_def_4 sorry
      then have A15: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y))"
        using A10 seqfunc_def_13 sorry
      have "((limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 x =HIDDENR1 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x"
        using A12 funct_1_th_47 sorry
      also have "... = limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A3 A14 seqfunc_def_13 sorry
      also have "... = (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y)).FUNCT-1K1 x"
        using A10 A15 seqfunc_def_13 sorry
      finally show "((limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 x =HIDDENR1 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y)).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) =XBOOLE-0R4 X"
      using A3 seqfunc_def_13 sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y =XBOOLE-0R4 Y"
      using A1 xboole_1_th_28 sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 Y"
      using relat_1_th_61 sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y))"
      using A10 seqfunc_def_13 sorry
    thus "(limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,Y)"
      using A11 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_25:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1) & H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> Y"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X & (Y <>HIDDENR2 {}XBOOLE-0K1 & H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X) implies H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 X"
      and A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X"
    obtain f where
      [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
      A4: "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 X"and A5: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)"
      using A3 sorry
    have A6: " ex g be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 D,REALNUMBERSK2 :]) st domRELSET-1K1\<^bsub>(D)\<^esub> g =HIDDENR1 Y & ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 Y implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p))"
    proof-
      obtain g where 
        [ty]:"g be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 D,REALNUMBERSK2 :])" and gDef:"g = f  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y"
         sorry
      show " ex g be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 D,REALNUMBERSK2 :]) st domRELSET-1K1\<^bsub>(D)\<^esub> g =HIDDENR1 Y & ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 Y implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p))"
      proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule impI)
        have A7: "domRELSET-1K1\<^bsub>(D)\<^esub> g =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> f /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
          using relat_1_th_61 sorry
        also have "... = Y"
          using A1 A4 xboole_1_th_28 sorry
        finally show "domRELSET-1K1\<^bsub>(D)\<^esub> g =HIDDENR1 Y"
           sorry
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume "p >XXREAL-0R4 0NUMBERSK6"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A8: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
          using A5 sorry
        show " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 Y implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
          assume A9: "n >=XXREAL-0R2 k"
            and A10: "x inTARSKIR2 Y"
          have " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A1 A8 A9 A10 sorry
          thus " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 g .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A7 A10 funct_1_th_47 sorry
        qed "sorry"
      qed "sorry"
    qed
    have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A3 sorry
    then have "Y common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A1 A2 seqfunc_th_23 sorry
    thus "H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> Y"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    assume A2: "x inTARSKIR2 X"
    have "{TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 & ( for n be NatNAT-1M1 holds {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n))"
    proof(rule conjMI)
      show "{TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have " for n be NatNAT-1M1 holds {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
          using A1 sorry
        thus "{TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
          using A2 zfmisc_1_th_31 sorry
      qed "sorry"
      thus " for n be NatNAT-1M1 holds {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
         sorry
    qed
    thus "{TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using seqfunc_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H)"
  using seqfunc_th_26 sorry

mtheorem seqfunc_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    assume A1: "{TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1"
      and A2: "{TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A3: "{TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A2 sorry
      have "x inTARSKIR2 {TARSKIK1 x} & {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 tarski_def_1 sorry
      then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A3 xboole_0_def_4 sorry
      then have A4: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_def_1 sorry
      have "(H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n +XCMPLX-0K2 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seq_1_th_7 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x +XCMPLX-0K2 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x +XCMPLX-0K2 (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_10 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using A4 valued_1_def_1 sorry
      also have "... = ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_5 sorry
      also have "... = ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      finally show "(H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A5: "{TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A2 sorry
      have "x inTARSKIR2 {TARSKIK1 x} & {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 tarski_def_1 sorry
      then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A5 xboole_0_def_4 sorry
      then have A6: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_th_12 sorry
      have "(H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n -XCMPLX-0K6 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using rfunct_2_th_1 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_10 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using A6 valued_1_th_13 sorry
      also have "... = ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_th_3 sorry
      also have "... = ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      finally show "(H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x)).FUNCT-1K1 n =HIDDENR1 ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x)).FUNCT-1K1 n =HIDDENR1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n *XCMPLX-0K3 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seq_1_th_8 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x *XCMPLX-0K3 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x *XCMPLX-0K3 (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_10 sorry
      also have "... = (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using valued_1_th_5 sorry
      also have "... = ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_7 sorry
      also have "... = ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      finally show "((H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x)).FUNCT-1K1 n =HIDDENR1 ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "(H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) & (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) & (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 (absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_10 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n.|).FUNCT-1K1 x"
        using seqfunc_def_4 sorry
      also have "... =  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n.|"
        using seqfunc_def_10 sorry
      also have "... = absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) .FUNCT-1K1 n"
        using seq_1_th_12 sorry
      finally show "(absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) .FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 (-VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 ((-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_10 sorry
      also have "... = (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_3 sorry
      also have "... = -XCMPLX-0K4 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using valued_1_th_8 sorry
      also have "... = -XCMPLX-0K4 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      also have "... = (-VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seq_1_th_10 sorry
      finally show "((-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 (-VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "(-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    assume A1: "{TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "x inTARSKIR2 {TARSKIK1 x} & {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 tarski_def_1 sorry
      then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
         sorry
      then have A2: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_def_5 sorry
      have "((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_10 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using seqfunc_def_1 sorry
      also have "... = r *XCMPLX-0K3 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x"
        using A2 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n"
        using seqfunc_def_10 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)).FUNCT-1K1 n"
        using seq_1_th_9 sorry
      finally show "((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x).FUNCT-1K1 n =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)).FUNCT-1K1 n"
         sorry
    qed "sorry"
    thus "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_31:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    assume "x inTARSKIR2 X"
    then have "{TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & {TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2"
      using A1 seqfunc_th_26 sorry
    thus "(H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x"
      using seqfunc_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_32:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) & (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
  using seqfunc_th_29 sorry

mtheorem seqfunc_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    assume "x inTARSKIR2 X"
    then have "{TARSKIK1 x} common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A1 seqfunc_th_26 sorry
    thus "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
      using seqfunc_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_34:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H1 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x & H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x) & (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
  using seqfunc_th_31 sorry

mtheorem seqfunc_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for x be ElementSUBSET-1M1-of D holds absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) & (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x"
  using seqfunc_th_32 sorry

mtheorem seqfunc_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ( for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x =RELSET-1R2\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
  using seqfunc_th_33 sorry

mtheorem seqfunc_th_37:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2) & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2 implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2 & (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1"
      and A2: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2"
    have A3: "X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 sorry
    have " for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 A2 sorry
      then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using xboole_1_th_19 sorry
      then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_def_1 sorry
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_5 sorry
    qed "sorry"
    thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2"
      using A3 sorry
    have " for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 A2 sorry
      then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using xboole_1_th_19 sorry
      then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_th_12 sorry
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_th_3 sorry
    qed "sorry"
    thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2"
      using A3 sorry
    have " for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) & X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 A2 sorry
      then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using xboole_1_th_19 sorry
      then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (H1 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n (#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_def_4 sorry
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_7 sorry
    qed "sorry"
    thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> -SEQFUNCK4\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> -SEQFUNCK4\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
    then have A2: "X <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have " for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> ( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n.|)"
        using valued_1_def_11 sorry
      also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_4 sorry
      finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
         sorry
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (absSEQFUNCK5\<^bsub>(D)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 sorry
    qed "sorry"
    thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
      using A2 sorry
    have " for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_th_8 sorry
      also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> ((-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_3 sorry
      finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
         sorry
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((-SEQFUNCK4\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 sorry
    qed "sorry"
    thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> -SEQFUNCK4\<^bsub>(D)\<^esub> H"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_39:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
    have A2: " for n be NatNAT-1M1 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using valued_1_def_5 sorry
      also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using seqfunc_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
         sorry
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H).SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n)"
        using A1 sorry
    qed "sorry"
    have "X <>HIDDENR2 {}XBOOLE-0K1"
      using A1 sorry
    thus "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H1 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ((((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) & H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) & H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H1 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X) & (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X) & (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H1 assume [ty]: "H1 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix H2 assume [ty]: "H2 be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "H1 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      and A2: "H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
    have A3: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A4: "x inTARSKIR2 X"
      then have "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 seqfunc_th_20 sorry
      then have "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using seq_2_th_5 sorry
      thus "(H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 A4 seqfunc_th_34 sorry
    qed "sorry"
    have A5: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A6: "x inTARSKIR2 X"
      then have "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 seqfunc_th_20 sorry
      then have "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using seq_2_th_11 sorry
      thus "(H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 A6 seqfunc_th_34 sorry
    qed "sorry"
    have A7: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 & X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H2"
      using A1 A2 sorry
    then have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2"
      using seqfunc_th_37 sorry
    thus A8: "H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A3 seqfunc_th_20 sorry
    have A9: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) implies (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A10: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      then have A11: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
        using valued_1_def_1 sorry
      then have A12: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
        using xboole_0_def_4 sorry
      have A13: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))"
        using A11 xboole_0_def_4 sorry
      then have A14: "x inTARSKIR2 X"
        using A1 seqfunc_def_13 sorry
      then have A15: "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 seqfunc_th_20 sorry
      have "(limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x =HIDDENR1 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)).FUNCT-1K1 x +XCMPLX-0K2 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x"
        using A10 valued_1_def_1 sorry
      also have "... = limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x) +XCMPLX-0K2 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x"
        using A1 A13 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x) +XCMPLX-0K2 limSEQ-2K1 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A2 A12 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A15 seq_2_th_6 sorry
      also have "... = limSEQ-2K1 ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A1 A2 A14 seqfunc_th_34 sorry
      finally show "(limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
         sorry
    qed "sorry"
    have A16: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A17: "x inTARSKIR2 X"
      then have "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 seqfunc_th_20 sorry
      then have "(H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x) be convergentSEQ-2V5"
        using seq_2_th_14 sorry
      thus "(H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 A17 seqfunc_th_34 sorry
    qed "sorry"
    have A18: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))) implies ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)))"
      then have A19: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
        using valued_1_def_4 sorry
      then have A20: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
        using xboole_0_def_4 sorry
      have A21: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))"
        using A19 xboole_0_def_4 sorry
      then have A22: "x inTARSKIR2 X"
        using A1 seqfunc_def_13 sorry
      then have A23: "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 seqfunc_th_20 sorry
      have "((limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))).FUNCT-1K1 x =HIDDENR1 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)).FUNCT-1K1 x *XCMPLX-0K3 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x"
        using valued_1_th_5 sorry
      also have "... = (limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x))*XCMPLX-0K3 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x"
        using A1 A21 seqfunc_def_13 sorry
      also have "... = (limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x))*XCMPLX-0K3 (limSEQ-2K1 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
        using A2 A20 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 ((H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x)(#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
        using A23 seq_2_th_15 sorry
      also have "... = limSEQ-2K1 ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A1 A2 A22 seqfunc_th_34 sorry
      finally show "((limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
         sorry
    qed "sorry"
    have A24: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) implies (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A25: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      then have A26: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
        using valued_1_th_12 sorry
      then have A27: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
        using xboole_0_def_4 sorry
      have A28: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))"
        using A26 xboole_0_def_4 sorry
      then have A29: "x inTARSKIR2 X"
        using A1 seqfunc_def_13 sorry
      then have A30: "H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5 & H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 A2 seqfunc_th_20 sorry
      have "(limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x =HIDDENR1 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x"
        using A25 valued_1_th_13 sorry
      also have "... = limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x) -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x"
        using A1 A28 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x) -XCMPLX-0K6 limSEQ-2K1 (H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A2 A27 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 (H1 #SEQFUNCK10\<^bsub>(D)\<^esub> x -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> H2 #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A30 seq_2_th_12 sorry
      also have "... = limSEQ-2K1 ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A1 A2 A29 seqfunc_th_34 sorry
      finally show "(limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      using valued_1_def_1 sorry
    also have "... = X /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      using A1 seqfunc_def_13 sorry
    also have "... = X /\\XBOOLE-0K3 X"
      using A2 seqfunc_def_13 sorry
    also have "... = X"
       sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) =HIDDENR1 X"
       sorry
    thus "limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 +SEQFUNCK6\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)"
      using A8 A9 seqfunc_def_13 sorry
    have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2"
      using A7 seqfunc_th_37 sorry
    thus A31: "H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A5 seqfunc_th_20 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      using valued_1_th_12 sorry
    also have "... = X /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      using A1 seqfunc_def_13 sorry
    also have "... = X /\\XBOOLE-0K3 X"
      using A2 seqfunc_def_13 sorry
    also have "... = X"
       sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)) =HIDDENR1 X"
       sorry
    thus "limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 -SEQFUNCK7\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X) -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X)"
      using A31 A24 seqfunc_def_13 sorry
    have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2"
      using A7 seqfunc_th_37 sorry
    thus A32: "H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2 is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A16 seqfunc_th_20 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X)) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      using valued_1_def_4 sorry
    also have "... = X /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      using A1 seqfunc_def_13 sorry
    also have "... = X /\\XBOOLE-0K3 X"
      using A2 seqfunc_def_13 sorry
    also have "... = X"
       sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ((limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))) =HIDDENR1 X"
       sorry
    thus "limSEQFUNCK11\<^bsub>(D)\<^esub>(H1 (#)SEQFUNCK8\<^bsub>(D)\<^esub> H2,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H1,X))(#)VALUED-1K21\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H2,X))"
      using A32 A18 seqfunc_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies ((absSEQFUNCK5\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(absSEQFUNCK5\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|) & -SEQFUNCK4\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & limSEQFUNCK11\<^bsub>(D)\<^esub>(-SEQFUNCK4\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies absSEQFUNCK5\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & (limSEQFUNCK11\<^bsub>(D)\<^esub>(absSEQFUNCK5\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .| & (-SEQFUNCK4\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(-SEQFUNCK4\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
    have A2: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume "x inTARSKIR2 X"
      then have "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 seqfunc_th_20 sorry
      then have "absVALUED-1K59\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) be convergentSEQ-2V5"
        using seq_4_th_13 sorry
      thus "absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using seqfunc_th_32 sorry
    qed "sorry"
    have A3: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) implies (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
      then have A4: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
        using valued_1_th_8 sorry
      then have "x inTARSKIR2 X"
        using A1 seqfunc_def_13 sorry
      then have A5: "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 seqfunc_th_20 sorry
      have "(-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x"
        using valued_1_th_8 sorry
      also have "... = -XCMPLX-0K4 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A1 A4 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 (-VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A5 seq_2_th_10 sorry
      also have "... = limSEQ-2K1 ((-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using seqfunc_th_32 sorry
      finally show "(-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
         sorry
    qed "sorry"
    have A6: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      using A1 sorry
    then have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> absSEQFUNCK5\<^bsub>(D)\<^esub> H"
      using seqfunc_th_38 sorry
    thus A7: "absSEQFUNCK5\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A2 seqfunc_th_20 sorry
    have A8: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|) implies ( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 (absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|)"
      then have A9: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
        using valued_1_def_11 sorry
      then have "x inTARSKIR2 X"
        using A1 seqfunc_def_13 sorry
      then have A10: "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 seqfunc_th_20 sorry
      have "( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|).FUNCT-1K1 x =HIDDENR1  |.COMPLEX1K10 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) .|"
        using A1 A9 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x .|)"
        using A10 seq_4_th_14 sorry
      also have "... = limSEQ-2K1 (absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using seqfunc_th_32 sorry
      finally show "( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 (absSEQFUNCK5\<^bsub>(D)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x)"
         sorry
    qed "sorry"
    have A11: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume "x inTARSKIR2 X"
      then have "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 seqfunc_th_20 sorry
      then have "-VALUED-1K34\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using seq_2_th_9 sorry
      thus "(-SEQFUNCK4\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using seqfunc_th_32 sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(D)\<^esub> ( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
      using valued_1_def_11 sorry
    also have "... = X"
      using A1 seqfunc_def_13 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ( |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|) =HIDDENR1 X"
       sorry
    thus "limSEQFUNCK11\<^bsub>(D)\<^esub>(absSEQFUNCK5\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X) .|"
      using A7 A8 seqfunc_def_13 sorry
    have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> -SEQFUNCK4\<^bsub>(D)\<^esub> H"
      using A6 seqfunc_th_38 sorry
    thus A12: "-SEQFUNCK4\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A11 seqfunc_th_20 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
      using valued_1_th_8 sorry
    also have "... = X"
      using A1 seqfunc_def_13 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) =HIDDENR1 X"
       sorry
    thus "limSEQFUNCK11\<^bsub>(D)\<^esub>(-SEQFUNCK4\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)"
      using A12 A3 seqfunc_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X implies r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & limSEQFUNCK11\<^bsub>(D)\<^esub>(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
    then have A2: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
       sorry
    have A3: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))) implies (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A4: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)))"
      then have A5: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
        using valued_1_def_5 sorry
      then have A6: "x inTARSKIR2 X"
        using A1 seqfunc_def_13 sorry
      then have A7: "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 seqfunc_th_20 sorry
      have "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))).FUNCT-1K1 x =HIDDENR1 r *XCMPLX-0K3 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x"
        using A4 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (limSEQ-2K1 (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
        using A1 A5 seqfunc_def_13 sorry
      also have "... = limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x))"
        using A7 seq_2_th_8 sorry
      also have "... = limSEQ-2K1 ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
        using A2 A6 seqfunc_th_33 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))).FUNCT-1K1 x =HIDDENR1 limSEQ-2K1 ((r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x)"
         sorry
    qed "sorry"
    have A8: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies (r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
      assume A9: "x inTARSKIR2 X"
      then have "H #SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A1 seqfunc_th_20 sorry
      then have "r (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> (H #SEQFUNCK10\<^bsub>(D)\<^esub> x) be convergentSEQ-2V5"
        using seq_2_th_7 sorry
      thus "(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H)#SEQFUNCK10\<^bsub>(D)\<^esub> x be convergentSEQ-2V5"
        using A2 A9 seqfunc_th_33 sorry
    qed "sorry"
    have "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H"
      using A2 seqfunc_th_39 sorry
    thus A10: "r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      using A8 seqfunc_th_20 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
      using valued_1_def_5 sorry
    also have "... = X"
      using A1 seqfunc_def_13 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))) =HIDDENR1 X"
       sorry
    thus "limSEQFUNCK11\<^bsub>(D)\<^esub>(r (#)SEQFUNCK2\<^bsub>(D)\<^esub> H,X) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X))"
      using A10 A3 seqfunc_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seqfunc_th_43:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X iff (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds (H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r))) & (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & (H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r))) implies H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    show "H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies (X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X) & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r))"
    proof-
      have "H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X implies X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H & (H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X & ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar19 be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 tVar19 & x inTARSKIR2 X implies  not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r)))"
      proof(rule impI,rule conjMI,rule conjMI,rule ballI,rule impI)
        assume A1: "H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X"
        then obtain f where
          [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
          A2: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> f"and A3: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p)"
           sorry
        show "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
          using A1 sorry
        have A4: " for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 X implies ( for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p))"
        proof(rule ballI,rule impI,rule ballI,rule impI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
          assume A5: "x inTARSKIR2 X"
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume "p >XXREAL-0R4 0NUMBERSK6"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A6: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
            using A3 sorry
          show " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 k implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
          proof(rule bexI[of _ "k"],rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume "n >=XXREAL-0R2 k"
            thus " |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 p"
              using A5 A6 sorry
          qed "sorry"
        qed "sorry"
        show "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
          using A1 seqfunc_th_22 sorry
        then have A7: "f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)"
          using A2 A4 seqfunc_th_21 sorry
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "r >XXREAL-0R4 0NUMBERSK6"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A8: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 x .| <XXREAL-0R3 r"
          using A3 sorry
        show " ex tVar19 be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 tVar19 & x inTARSKIR2 X implies  not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r"
        proof(rule bexI[of _ "k"],rule ballI,rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
          assume "n >=XXREAL-0R2 k & x inTARSKIR2 X"
          thus " not  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r"
            using A7 A8 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A9: "X common-on-domSEQFUNCR1\<^bsub>(D,REALNUMBERSK2)\<^esub> H"
      and A10: "H is-point-conv-onSEQFUNCR2\<^bsub>(D)\<^esub> X"
      and A11: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of D holds n >=XXREAL-0R2 k & x inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(D,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x -XCMPLX-0K6 (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)).FUNCT-1K1 x .| <XXREAL-0R3 r)"
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (limSEQFUNCK11\<^bsub>(D)\<^esub>(H,X)) =XBOOLE-0R4 X"
      using A10 seqfunc_def_13 sorry
    thus "H is-unif-conv-onSEQFUNCR3\<^bsub>(D)\<^esub> X"
      using A9 A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve H for "Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem seqfunc_th_44:
" for X be setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds H is-unif-conv-onSEQFUNCR3\<^bsub>(REALNUMBERSK2)\<^esub> X & ( for n be NatNAT-1M1 holds (H .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) implies (limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for H be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds H is-unif-conv-onSEQFUNCR3\<^bsub>(REALNUMBERSK2)\<^esub> X & ( for n be NatNAT-1M1 holds (H .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) implies (limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix H assume [ty]: "H be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?l = "limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)"
    assume A1: "H is-unif-conv-onSEQFUNCR3\<^bsub>(REALNUMBERSK2)\<^esub> X"
      and A2: " for n be NatNAT-1M1 holds (H .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    have A3: "H is-point-conv-onSEQFUNCR2\<^bsub>(REALNUMBERSK2)\<^esub> X"
      using A1 seqfunc_th_22 sorry
    then have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?l =XBOOLE-0R4 X"
      using seqfunc_def_13 sorry
    have A5: "X common-on-domSEQFUNCR1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> H"
      using A1 sorry
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies ?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
    proof-
      have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies (limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        then have A6: "x0 inHIDDENR3 X"
          using relat_1_th_57 sorry
        have 
          [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
        proof-
          have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar20 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar20 & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar20 implies  not  |.COMPLEX1K10 ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume "0NUMBERSK6 <XXREAL-0R3 r"
            then have A7: "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
              using xreal_1_th_222 sorry
            have 
              [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
              using xreal_0_def_1 sorry
            obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A8: " for n be NatNAT-1M1 holds  for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds n >=XXREAL-0R2 k & x1 inTARSKIR2 X implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x1 -XCMPLX-0K6 ?l .FUNCT-1K1 x1 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
              using A1 A7 seqfunc_th_43 sorry
            obtain k1 where
              [ty]:"k1 be NatNAT-1M1" and 
              A9: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 k1 implies  |.COMPLEX1K10 (H .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
              using A3 A6 A7 seqfunc_th_21 sorry
            obtain m where 
              [ty]:"m be NatNAT-1M1" and mDef:"m = maxXXREAL-0K5(k,k1)"
              using tarski_th_1 sorry
            let ?h = "H .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> m"
            have A10: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?h"
              using A5 sorry
            have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?h /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using relat_1_th_61 sorry
            also have "... = X"
              using A10 xboole_1_th_28 sorry
            finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 X"
               sorry
            have "?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
              using A2 sorry
            then have "?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using A6 A11 fcont_1_def_2 sorry
            then obtain s where
              [ty]:"s be RealXREAL-0M1" and 
              A12: "0NUMBERSK6 <XXREAL-0R3 s"and A13: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
              using A7 fcont_1_th_3 sorry
            have 
              [ty]:"s be RealXREAL-0M1"
               sorry
            show " ex tVar20 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar20 & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar20 implies  not  |.COMPLEX1K10 ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
            proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
              show "0NUMBERSK6 <XXREAL-0R3 s"
                using A12 sorry
              fix x1 assume [ty]: "x1 be RealXREAL-0M1"
              assume A14: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                and A15: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
              have A16: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?l /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
                using relat_1_th_61 sorry
              also have "... = X"
                using A4 sorry
              finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 X"
                 sorry
              then have " |.COMPLEX1K10 (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
                using A11 A13 A14 A15 sorry
              then have " |.COMPLEX1K10 ?h .FUNCT-1K1 x1 -XCMPLX-0K6 (?h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
                using A16 A11 A14 funct_1_th_47 sorry
              then have A17: " |.COMPLEX1K10 ?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
                using A6 funct_1_th_49 sorry
              have " |.COMPLEX1K10 ?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
                using A9 xxreal_0_th_25 sorry
              then have " |.COMPLEX1K10 (?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0)+XCMPLX-0K2 (?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0) .| <=XXREAL-0R1  |.COMPLEX1K10 ?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0 .| +XCMPLX-0K2  |.COMPLEX1K10 ?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| &  |.COMPLEX1K10 ?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0 .| +XCMPLX-0K2  |.COMPLEX1K10 ?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<three>\<^sub>M"
                using A17 complex1_th_56 xreal_1_th_8 sorry
              then have A18: " |.COMPLEX1K10 (?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0)+XCMPLX-0K2 (?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0) .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<three>\<^sub>M"
                using xxreal_0_th_2 sorry
              have " |.COMPLEX1K10 ?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| =COMPLEX1R1  |.COMPLEX1K10 (?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x1)+XCMPLX-0K2 ((?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0)+XCMPLX-0K2 (?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0)) .|"
                 sorry
              then have A19: " |.COMPLEX1K10 ?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| <=XXREAL-0R1  |.COMPLEX1K10 ?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x1 .| +XCMPLX-0K2  |.COMPLEX1K10 (?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0)+XCMPLX-0K2 (?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0) .|"
                using complex1_th_56 sorry
              have " |.COMPLEX1K10 ?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?l .FUNCT-1K1 x1 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
                using A8 A16 A14 xxreal_0_th_25 sorry
              then have " |.COMPLEX1K10 -XCMPLX-0K4 (?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x1) .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
                 sorry
              then have " |.COMPLEX1K10 ?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x1 .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M"
                using complex1_th_52 sorry
              then have " |.COMPLEX1K10 ?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x1 .| +XCMPLX-0K2  |.COMPLEX1K10 (?h .FUNCT-1K1 x1 -XCMPLX-0K6 ?h .FUNCT-1K1 x0)+XCMPLX-0K2 (?h .FUNCT-1K1 x0 -XCMPLX-0K6 ?l .FUNCT-1K1 x0) .| <XXREAL-0R3 r /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 (r /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<three>\<^sub>M)"
                using A18 xreal_1_th_8 sorry
              then have " |.COMPLEX1K10 ?l .FUNCT-1K1 x1 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| <XXREAL-0R3 (r /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<three>\<^sub>M"
                using A19 xxreal_0_th_2 sorry
              then have " |.COMPLEX1K10 (?l  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 ?l .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
                using A14 funct_1_th_47 sorry
              thus " not  |.COMPLEX1K10 ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 ((limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r"
                using A4 relat_1_th_68 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "(limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          using fcont_1_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(limSEQFUNCK11\<^bsub>(REALNUMBERSK2)\<^esub>(H,X)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using fcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
