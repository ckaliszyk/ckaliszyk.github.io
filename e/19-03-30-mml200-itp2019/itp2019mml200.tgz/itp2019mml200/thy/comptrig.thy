theory comptrig
  imports fcont_2 sin_cos2 comseq_3 binarith abian
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "RealXREAL-0M1"
theorem comptrig_sch_1:
  fixes Pp1 
  assumes
    A1: " ex k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st Pp1(k)" and
   A2: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds k <>HIDDENR2 \<one>\<^sub>M & Pp1(k) implies ( ex n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st n <XXREAL-0R3 k & Pp1(n))"
  shows "Pp1(\<one>\<^sub>M)"
  proof-
    obtain t where
      [ty]:"t be  non zeroORDINAL1V8\<bar>NatNAT-1M1" and 
      A3: "Pp1(t)"
      using A1 sorry
    let ?R = "\<lambda>Lamb1. Pp1(Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    have A4: " for k be NatNAT-1M1 holds k <>HIDDENR2 0NUMBERSK6 & Pp1(k +NAT-1K1 \<one>\<^sub>M) implies ( ex l be NatNAT-1M1 st l <XXREAL-0R3 k & Pp1(l +NAT-1K1 \<one>\<^sub>M))"
    proof(rule ballI,rule impMI ,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A5: "k <>HIDDENR2 0NUMBERSK6"
        and A6: "?R(k)"
      obtain k1 where 
        [ty]:"k1 be  non zeroORDINAL1V8\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and k1Def:"k1 = k +NAT-1K1 \<one>\<^sub>M"
         sorry
      have "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using A5 xreal_1_th_6 sorry
      then obtain n where
        [ty]:"n be  non zeroORDINAL1V8\<bar>NatNAT-1M1" and 
        A7: "n <XXREAL-0R3 k1"and A8: "Pp1(n)"
        using A2 A6 sorry
      obtain l where
        [ty]:"l be NatNAT-1M1" and 
        A9: "n =COMPLEX1R1 l +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_6 sorry
      show " ex l be NatNAT-1M1 st l <XXREAL-0R3 k & Pp1(l +NAT-1K1 \<one>\<^sub>M)"
      proof(rule bexI[of _ "l"],rule conjMI)
        show "l <XXREAL-0R3 k"
          using A7 A9 xreal_1_th_6 sorry
        show "Pp1(l +NAT-1K1 \<one>\<^sub>M)"
          using A8 A9 sorry
      qed "sorry"
    qed "sorry"
    have " ex s be NatNAT-1M1 st t =COMPLEX1R1 s +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    then have A10: " ex k be NatNAT-1M1 st ?R(k)"
      using A3 sorry
    have "?R(0NUMBERSK6)"
      using nat_1_sch_7 A10 A4 sorry
    thus "Pp1(\<one>\<^sub>M)"
       sorry
  qed

mtheorem comptrig_th_1:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have "0NUMBERSK6 <=XXREAL-0R1 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
    using xreal_1_th_63 sorry
  then have A1: "(ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
    using xreal_1_th_7 sorry
  have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1"
    using xreal_1_th_63 sorry
  then have "sqrtSQUARE-1K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1 <=XXREAL-0R1  |.COMPLEX1K10 z.|"
    using A1 square_1_th_26 sorry
  then have "-XCMPLX-0K4 sqrtSQUARE-1K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1 >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
    using xreal_1_th_24 sorry
  then have "ReCOMPLEX1K3 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 ReCOMPLEX1K3 z.| & -XCMPLX-0K4  |.COMPLEX1K10 ReCOMPLEX1K3 z.| >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
    using absvalue_th_4 complex1_th_72 sorry
  thus "ReCOMPLEX1K3 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
    using xxreal_0_th_2 sorry
qed "sorry"

mtheorem comptrig_th_2:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1"
    using xreal_1_th_63 sorry
  then have A1: "(ImCOMPLEX1K4 z)^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
    using xreal_1_th_7 sorry
  have "0NUMBERSK6 <=XXREAL-0R1 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
    using xreal_1_th_63 sorry
  then have "sqrtSQUARE-1K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 <=XXREAL-0R1  |.COMPLEX1K10 z.|"
    using A1 square_1_th_26 sorry
  then have "-XCMPLX-0K4 sqrtSQUARE-1K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
    using xreal_1_th_24 sorry
  then have "ImCOMPLEX1K4 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 ImCOMPLEX1K4 z.| & -XCMPLX-0K4  |.COMPLEX1K10 ImCOMPLEX1K4 z.| >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
    using absvalue_th_4 complex1_th_72 sorry
  thus "ImCOMPLEX1K4 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
    using xxreal_0_th_2 sorry
qed "sorry"

mtheorem comptrig_th_3:
" for z be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =HIDDENR1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =HIDDENR1  |.COMPLEX1K10 z *XCMPLX-0K3 z .|"
      using complex1_th_65 sorry
    also have "... = (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using complex1_th_68 sorry
    finally show "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =HIDDENR1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_4:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds x >=XXREAL-0R2 0NUMBERSK6 & n <>HIDDENR2 0NUMBERSK6 implies n -rootPOWERK1 x  |^NEWTONK1 n =COMPLEX1R1 x"
proof-
  have " for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds x >=XXREAL-0R2 0NUMBERSK6 & n <>HIDDENR2 0NUMBERSK6 implies n -rootPOWERK1 x  |^NEWTONK1 n =COMPLEX1R1 x"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "x >=XXREAL-0R2 0NUMBERSK6"
      and A2: "n <>HIDDENR2 0NUMBERSK6"
    have "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using A2 nat_1_th_13 sorry
    thus "n -rootPOWERK1 x  |^NEWTONK1 n =COMPLEX1R1 x"
      using A1 power_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_cl_1:
"cluster PISIN-COSK29 as-term-is  non negativeXXREAL-0V3"
proof
(*coherence*)
  show "PISIN-COSK29 be  non negativeXXREAL-0V3"
  proof-
    have " not PISIN-COSK29 be negativeXXREAL-0V3"
    proof-
      have "PISIN-COSK29 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
        using sin_cos_def_28 sorry
      thus " not PISIN-COSK29 be negativeXXREAL-0V3"
        using xxreal_1_th_4 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
mlemma
"PISIN-COSK29 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,\<four>\<^sub>M .["
  using sin_cos_def_28 sorry

mlemma comptrig_lm_1:
"0NUMBERSK6 <XXREAL-0R3 PISIN-COSK29"
  using xxreal_1_th_4 sorry

mlemma comptrig_lm_2:
"0NUMBERSK6 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using xreal_1_th_6 sorry

mlemma comptrig_lm_3:
"0NUMBERSK6 +XCMPLX-0K2 PISIN-COSK29 <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 PISIN-COSK29"
  using comptrig_lm_1 xreal_1_th_6 sorry

mlemma comptrig_lm_4:
"0NUMBERSK6 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using comptrig_lm_1 xreal_1_th_6 sorry

mlemma comptrig_lm_5:
"(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
  using comptrig_lm_2 xreal_1_th_6 sorry

mlemma
"(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
   sorry

mlemma comptrig_lm_6:
"(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  using comptrig_lm_5 xreal_1_th_6 sorry

mlemma comptrig_lm_7:
"0NUMBERSK6 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
  using comptrig_lm_1 sorry

mtheorem comptrig_th_5:
"(((((((((0NUMBERSK6 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M & (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29) & 0NUMBERSK6 <XXREAL-0R3 PISIN-COSK29) & -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) & PISIN-COSK29 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) & -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 0NUMBERSK6) & 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & PISIN-COSK29 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) & (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & 0NUMBERSK6 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
  using comptrig_lm_2 comptrig_lm_3 comptrig_lm_4 xreal_1_th_6 sorry

mtheorem comptrig_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,c .[ implies (x inHIDDENR3 ].RCOMP-1K2 a,b .[ or x =COMPLEX1R1 b) or x inHIDDENR3 ].RCOMP-1K2 b,c .["
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,c .[ & ( not x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not x =COMPLEX1R1 b) implies x inHIDDENR3 ].RCOMP-1K2 b,c .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "x inHIDDENR3 ].RCOMP-1K2 a,c .["
      and A2: " not x inHIDDENR3 ].RCOMP-1K2 a,b .["
      and A3: " not x =COMPLEX1R1 b"
    have "x <=XXREAL-0R1 a or x >=XXREAL-0R2 b"
      using A2 xxreal_1_th_4 sorry
    then have A4: "x >XXREAL-0R4 b"
      using A1 A3 xxreal_0_th_1 xxreal_1_th_4 sorry
    have "x <XXREAL-0R3 c"
      using A1 xxreal_1_th_4 sorry
    thus "x inHIDDENR3 ].RCOMP-1K2 b,c .["
      using A4 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_7:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies  not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
    show " not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have cases: "(x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ or x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) or x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
        using A1 comptrig_th_6 sorry
      have case1: "x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies  not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI)
        assume A2: "x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        then have "x <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using xxreal_1_th_4 sorry
        then have "-XCMPLX-0K4 x >XXREAL-0R4 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_24 sorry
        then have A3: "(-XCMPLX-0K4 x)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_6 sorry
        have "0NUMBERSK6 <XXREAL-0R3 x"
          using A2 xxreal_1_th_4 sorry
        then have "(-XCMPLX-0K4 x)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 x inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
          using A3 xxreal_1_th_4 sorry
        then have "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 x) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_80 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_78 sorry
      qed
      have case2: "x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies  not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
        thus " not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_76 sorry
      qed
      have case3: "x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies  not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI)
        assume A4: "x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
        then have "x <XXREAL-0R3 PISIN-COSK29"
          using xxreal_1_th_4 sorry
        then have A5: "x -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 PISIN-COSK29 -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_9 sorry
        have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x"
          using A4 xxreal_1_th_4 sorry
        then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_9 sorry
        then have "x -XCMPLX-0K6 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
          using A5 xxreal_1_th_4 sorry
        then have "(cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 x)) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_80 sorry
        then have "(cosSIN-COSK19).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 x) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_30 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_th_78 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_8:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .] implies (sinSIN-COSK17).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .] implies (sinSIN-COSK17).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
    then have "x <=XXREAL-0R1 PISIN-COSK29"
      using xxreal_1_th_1 sorry
    then have "(x =COMPLEX1R1 0NUMBERSK6 or x =COMPLEX1R1 PISIN-COSK29) or 0NUMBERSK6 <XXREAL-0R3 x & x <XXREAL-0R3 PISIN-COSK29"
      using A1 xxreal_0_th_1 xxreal_1_th_1 sorry
    then have "(x =COMPLEX1R1 0NUMBERSK6 or x =COMPLEX1R1 PISIN-COSK29) or x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using xxreal_1_th_4 sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
      using comptrig_th_7 sin_cos_th_30 sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_9:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies  not (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have A1: "(sinSIN-COSK17).FUNCT-1K1 (x -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29 -XCMPLX-0K6 x))"
       sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (-XCMPLX-0K4 x))"
      using sin_cos_th_30 sorry
    also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 x))"
      using sin_cos_th_78 sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x"
      using sin_cos_th_30 sorry
    finally have "(sinSIN-COSK17).FUNCT-1K1 (x -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x"
       sorry
    assume A2: "x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
    then have "x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_4 sorry
    then have A3: "x -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 PISIN-COSK29"
      using xreal_1_th_9 sorry
    have "PISIN-COSK29 <XXREAL-0R3 x"
      using A2 xxreal_1_th_4 sorry
    then have "PISIN-COSK29 -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 x -XCMPLX-0K6 PISIN-COSK29"
      using xreal_1_th_9 sorry
    then have "x -XCMPLX-0K6 PISIN-COSK29 inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using A3 xxreal_1_th_4 sorry
    thus " not (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
      using A1 comptrig_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_10:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .] implies (sinSIN-COSK17).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .] implies (sinSIN-COSK17).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
    then have "PISIN-COSK29 <=XXREAL-0R1 x & x <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_1 sorry
    then have "(x =COMPLEX1R1 PISIN-COSK29 or x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or PISIN-COSK29 <XXREAL-0R3 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_0_th_1 sorry
    then have "(x =COMPLEX1R1 PISIN-COSK29 or x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using xxreal_1_th_4 sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
      using comptrig_th_9 sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_11:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies  not (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have A1: "(sinSIN-COSK17).FUNCT-1K1 (x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x"
      using sin_cos_th_78 sorry
    assume A2: "x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
    then have "x <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_1_th_4 sorry
    then have A3: "x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x"
      using A2 xxreal_1_th_4 sorry
    then have "(-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    then have "x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using A3 xxreal_1_th_4 sorry
    thus " not (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A1 comptrig_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_12:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .] implies (cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .] implies (cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
    then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 x & x <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_1_th_1 sorry
    then have "(x =COMPLEX1R1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) or -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_0_th_1 sorry
    then have "(x =COMPLEX1R1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) or x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using xxreal_1_th_4 sorry
    thus "(cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
      using comptrig_th_11 sin_cos_th_30 sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_13:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies  not (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have A1: "(sinSIN-COSK17).FUNCT-1K1 (x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x"
      using sin_cos_th_78 sorry
    assume A2: "x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
    then have "x <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_4 sorry
    then have A3: "x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x"
      using A2 xxreal_1_th_4 sorry
    then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    then have "x +XCMPLX-0K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using A3 xxreal_1_th_4 sorry
    thus " not (cosSIN-COSK19).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
      using A1 comptrig_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_14:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .] implies (cosSIN-COSK19).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .] implies (cosSIN-COSK19).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
    then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 x & x <=XXREAL-0R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_1 sorry
    then have "(x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) or (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x & x <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_0_th_1 sorry
    then have "(x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) or x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      using xxreal_1_th_4 sorry
    thus "(cosSIN-COSK19).FUNCT-1K1 x <=XXREAL-0R1 0NUMBERSK6"
      using comptrig_th_13 sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_15:
" for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies  not (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have A1: "(cosSIN-COSK19).FUNCT-1K1 (x -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29 -XCMPLX-0K6 x))"
       sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29 +XCMPLX-0K2 (-XCMPLX-0K4 x))"
      using sin_cos_th_30 sorry
    also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 x)"
      using sin_cos_th_78 sorry
    also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x"
      using sin_cos_th_30 sorry
    finally have "(cosSIN-COSK19).FUNCT-1K1 (x -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 x"
       sorry
    assume A2: "x inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
    then have "x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_4 sorry
    then have "x -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 PISIN-COSK29"
      using xreal_1_th_9 sorry
    then have A3: "x -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_lm_5 xxreal_0_th_2 sorry
    have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 x"
      using A2 xxreal_1_th_4 sorry
    then have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 x -XCMPLX-0K6 PISIN-COSK29"
      using xreal_1_th_9 sorry
    then have "x -XCMPLX-0K6 PISIN-COSK29 inTARSKIR2 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      using A3 xxreal_1_th_4 sorry
    thus " not (cosSIN-COSK19).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      using A1 comptrig_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_16:
" for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .] implies (cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .] implies (cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x inHIDDENR3 [.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
    then have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <=XXREAL-0R1 x & x <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_1 sorry
    then have "(x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) or x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_0_th_1 sorry
    then have "(x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) or x =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or x inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using xxreal_1_th_4 sorry
    thus "(cosSIN-COSK19).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
      using comptrig_th_15 sin_cos_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_17:
" for x be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6 or x =COMPLEX1R1 PISIN-COSK29"
proof-
  have " for x be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 x =COMPLEX1R1 0NUMBERSK6 implies  not ( not x =COMPLEX1R1 0NUMBERSK6 &  not x =COMPLEX1R1 PISIN-COSK29)"
  proof(rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      and A2: "sinSIN-COSK18 x =COMPLEX1R1 0NUMBERSK6"
    have "(sinSIN-COSK17).FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6"
      using A2 sin_cos_def_17 sorry
    then have " not x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ &  not x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using comptrig_th_7 comptrig_th_9 sorry
    then have "x =COMPLEX1R1 0NUMBERSK6 or x >=XXREAL-0R2 PISIN-COSK29 & PISIN-COSK29 >=XXREAL-0R2 x"
      using A1 xxreal_1_th_4 sorry
    thus " not ( not x =COMPLEX1R1 0NUMBERSK6 &  not x =COMPLEX1R1 PISIN-COSK29)"
      using xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_18:
" for x be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & cosSIN-COSK20 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
proof-
  have " for x be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & (x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & cosSIN-COSK20 x =COMPLEX1R1 0NUMBERSK6) implies  not ( not x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M &  not x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
      and A2: "x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      and A3: "cosSIN-COSK20 x =COMPLEX1R1 0NUMBERSK6"
    have A4: "(cosSIN-COSK19).FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6"
      using A3 sin_cos_def_19 sorry
    then have " not x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      using comptrig_th_13 sorry
    then have A5: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 x or x >=XXREAL-0R2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_4 sorry
    have " not x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using A4 comptrig_th_11 sorry
    then have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 x or x >=XXREAL-0R2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_1_th_4 sorry
    then have "(x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) or x >XXREAL-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using A1 A5 comptrig_lm_1 xxreal_0_th_1 sorry
    then have "(x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) or x inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using A2 xxreal_1_th_4 sorry
    thus " not ( not x =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M &  not x =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
      using A4 comptrig_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_19:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be increasingRFUNCT-2V1"
proof-
  have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies diffFDIFF-1K1(sinSIN-COSK17,x) >XXREAL-0R4 0NUMBERSK6"
  proof-
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies  not diffFDIFF-1K1(sinSIN-COSK17,x) >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      then have "0NUMBERSK6 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 x"
        using comptrig_th_11 sorry
      thus " not diffFDIFF-1K1(sinSIN-COSK17,x) >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_68 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ be openRCOMP-1V3"
    using rcomp_1_th_7 sorry
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) be increasingRFUNCT-2V1"
    using A1 fdiff_1_th_26 rolle_th_9 sin_cos_th_24 sin_cos_th_68 sorry
qed

mtheorem comptrig_th_20:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be decreasingRFUNCT-2V2"
proof-
  have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies diffFDIFF-1K1(sinSIN-COSK17,x) <XXREAL-0R3 0NUMBERSK6"
  proof-
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies  not diffFDIFF-1K1(sinSIN-COSK17,x) <XXREAL-0R3 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      then have "0NUMBERSK6 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 x"
        using comptrig_th_13 sorry
      thus " not diffFDIFF-1K1(sinSIN-COSK17,x) <XXREAL-0R3 0NUMBERSK6"
        using sin_cos_th_68 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ be openRCOMP-1V3"
    using rcomp_1_th_7 sorry
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) be decreasingRFUNCT-2V2"
    using A1 fdiff_1_th_26 rolle_th_10 sin_cos_th_24 sin_cos_th_68 sorry
qed

mtheorem comptrig_th_21:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) be decreasingRFUNCT-2V2"
proof-
  have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies diffFDIFF-1K1(cosSIN-COSK19,x) <XXREAL-0R3 0NUMBERSK6"
  proof-
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies  not diffFDIFF-1K1(cosSIN-COSK19,x) <XXREAL-0R3 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      then have "0NUMBERSK6 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 x"
        using comptrig_th_7 sorry
      then have "0NUMBERSK6 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
         sorry
      thus " not diffFDIFF-1K1(cosSIN-COSK19,x) <XXREAL-0R3 0NUMBERSK6"
        using sin_cos_th_67 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ be openRCOMP-1V3"
    using rcomp_1_th_7 sorry
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[) be decreasingRFUNCT-2V2"
    using A1 fdiff_1_th_26 rolle_th_10 sin_cos_th_24 sin_cos_th_67 sorry
qed

mtheorem comptrig_th_22:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingRFUNCT-2V1"
proof-
  have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies diffFDIFF-1K1(cosSIN-COSK19,x) >XXREAL-0R4 0NUMBERSK6"
  proof-
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies  not diffFDIFF-1K1(cosSIN-COSK19,x) >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      then have "0NUMBERSK6 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using comptrig_th_9 xreal_1_th_50 sorry
      thus " not diffFDIFF-1K1(cosSIN-COSK19,x) >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_67 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ be openRCOMP-1V3"
    using rcomp_1_th_7 sorry
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) be increasingRFUNCT-2V1"
    using A1 fdiff_1_th_26 rolle_th_9 sin_cos_th_24 sin_cos_th_67 sorry
qed

mtheorem comptrig_th_23:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be increasingRFUNCT-2V1"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17) & (r2 inHIDDENR3 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17) & r1 <XXREAL-0R3 r2) implies (sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    assume A1: "r1 inHIDDENR3 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      and A2: "r2 inHIDDENR3 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      and A3: "r1 <XXREAL-0R3 r2"
    have A4: "r1 inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17)"
      using A1 xboole_0_def_4 sorry
    let ?r3 = "(r1 +XCMPLX-0K2 r2)/XCMPLX-0K7 \<two>\<^sub>M"
    have "r1 inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using A1 xboole_0_def_4 sorry
    then have A5: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 r1"
      using xxreal_1_th_1 sorry
    have " |.COMPLEX1K10 sinSIN-COSK18 ?r3 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have A6: " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 ?r3.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_17 sorry
    then have A7: "(sinSIN-COSK17).FUNCT-1K1 ?r3 <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have "r2 inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using A2 xboole_0_def_4 sorry
    then have A8: "r2 <=XXREAL-0R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_1_th_1 sorry
    have A9: "r1 <XXREAL-0R3 ?r3"
      using A3 xreal_1_th_226 sorry
    then have A10: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ?r3"
      using A5 xxreal_0_th_2 sorry
    have A11: "?r3 <XXREAL-0R3 r2"
      using A3 xreal_1_th_226 sorry
    then have "?r3 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A8 xxreal_0_th_2 sorry
    then have "?r3 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using A10 xxreal_1_th_4 sorry
    then have A12: "?r3 inTARSKIR2 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      using sin_cos_th_24 xboole_0_def_4 sorry
    have " |.COMPLEX1K10 sinSIN-COSK18 r2 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 r2.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_17 sorry
    then have A13: "(sinSIN-COSK17).FUNCT-1K1 r2 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have A14: "r2 inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17)"
      using A2 xboole_0_def_4 sorry
    have A15: "(sinSIN-COSK17).FUNCT-1K1 ?r3 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using A6 absvalue_th_5 sorry
    have "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
    proof-
      show "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
      proof-
        have cases: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r1 or -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 r1"
          using A5 xxreal_0_th_1 sorry
        have case1: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r1 implies (sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
        proof(rule impI)
          assume A16: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r1"
          then have A17: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r2"
            using A3 xxreal_0_th_2 sorry
          have "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
          proof-
            show "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
            proof-
              have cases: "r2 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or r2 =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                using A8 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies (sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
              proof(rule impI)
                assume A18: "r2 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                then have "r1 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                  using A3 xxreal_0_th_2 sorry
                then have "r1 inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
                  using A16 xxreal_1_th_4 sorry
                then have A19: "r1 inHIDDENR3 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A4 xboole_0_def_4 sorry
                have "r2 inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
                  using A17 A18 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A14 xboole_0_def_4 sorry
                thus "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
                  using A3 A19 comptrig_th_19 rfunct_2_th_20 sorry
              qed
              have case2: "r2 =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies ((sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume A20: "r2 =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                then have "r1 inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
                  using A3 A16 xxreal_1_th_4 sorry
                then have "r1 inHIDDENR3 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A4 xboole_0_def_4 sorry
                then have A21: "(sinSIN-COSK17).FUNCT-1K1 ?r3 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
                  using A9 A12 comptrig_th_19 rfunct_2_th_20 sorry
                assume "(sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 (sinSIN-COSK17).FUNCT-1K1 r1"
                thus " False "
                  using A7 A20 A21 sin_cos_th_76 xxreal_0_th_2 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
             sorry
        qed
        have case2: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 r1 implies (sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
        proof(rule impI)
          assume A22: "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 r1"
          have "(sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False "
          proof-
            show "(sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False "
            proof-
              have cases: "r2 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or r2 =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                using A8 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies ((sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume "r2 <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                then have "r2 inHIDDENR3 ].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
                  using A3 A22 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A14 xboole_0_def_4 sorry
                then have A23: "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 ?r3"
                  using A11 A12 comptrig_th_19 rfunct_2_th_20 sorry
                assume "(sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 (sinSIN-COSK17).FUNCT-1K1 r1"
                then have "(sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
                  using A22 sin_cos_th_30 sin_cos_th_76 sorry
                thus " False "
                  using A15 A13 A23 xxreal_0_th_1 sorry
              qed
              have case2: "r2 =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies (sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
              proof(rule impI)
                assume "r2 =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                thus "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
                  using A22 sin_cos_th_30 sin_cos_th_76 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(sinSIN-COSK17).FUNCT-1K1 r2 >XXREAL-0R4 (sinSIN-COSK17).FUNCT-1K1 r1"
       sorry
  qed "sorry"
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be increasingRFUNCT-2V1"
    using rfunct_2_th_20 sorry
qed

mtheorem comptrig_th_24:
"(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be decreasingRFUNCT-2V2"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17) & (r2 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17) & r1 <XXREAL-0R3 r2) implies (sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    assume A1: "r1 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      and A2: "r2 inHIDDENR3 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      and A3: "r1 <XXREAL-0R3 r2"
    have A4: "r1 inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17)"
      using A1 xboole_0_def_4 sorry
    have " |.COMPLEX1K10 sinSIN-COSK18 r2 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 r2.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_17 sorry
    then have A5: "(sinSIN-COSK17).FUNCT-1K1 r2 <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have " |.COMPLEX1K10 sinSIN-COSK18 r1 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 r1.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_17 sorry
    then have A6: "(sinSIN-COSK17).FUNCT-1K1 r1 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have "r2 inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
      using A2 xboole_0_def_4 sorry
    then have A7: "r2 <=XXREAL-0R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_1 sorry
    let ?r3 = "(r1 +XCMPLX-0K2 r2)/XCMPLX-0K7 \<two>\<^sub>M"
    have "r1 inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
      using A1 xboole_0_def_4 sorry
    then have A8: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 r1"
      using xxreal_1_th_1 sorry
    have " |.COMPLEX1K10 sinSIN-COSK18 ?r3 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have A9: " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 ?r3.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_17 sorry
    then have A10: "(sinSIN-COSK17).FUNCT-1K1 ?r3 <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have A11: "r2 inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17)"
      using A2 xboole_0_def_4 sorry
    have A12: "r1 <XXREAL-0R3 ?r3"
      using A3 xreal_1_th_226 sorry
    then have A13: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ?r3"
      using A8 xxreal_0_th_2 sorry
    have A14: "?r3 <XXREAL-0R3 r2"
      using A3 xreal_1_th_226 sorry
    then have "?r3 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using A7 xxreal_0_th_2 sorry
    then have "?r3 inTARSKIR2 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      using A13 xxreal_1_th_4 sorry
    then have A15: "?r3 inTARSKIR2 (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      using sin_cos_th_24 xboole_0_def_4 sorry
    have A16: "(sinSIN-COSK17).FUNCT-1K1 ?r3 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using A9 absvalue_th_5 sorry
    have "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
    proof-
      show "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
      proof-
        have cases: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r1 or (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 r1"
          using A8 xxreal_0_th_1 sorry
        have case1: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r1 implies (sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
        proof(rule impI)
          assume A17: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r1"
          then have A18: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r2"
            using A3 xxreal_0_th_2 sorry
          have "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
          proof-
            show "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
            proof-
              have cases: "r2 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) or r2 =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
                using A7 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies (sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
              proof(rule impI)
                assume A19: "r2 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
                then have "r1 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
                  using A3 xxreal_0_th_2 sorry
                then have "r1 inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
                  using A17 xxreal_1_th_4 sorry
                then have A20: "r1 inHIDDENR3 (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A4 xboole_0_def_4 sorry
                have "r2 inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
                  using A18 A19 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A11 xboole_0_def_4 sorry
                thus "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
                  using A3 A20 comptrig_th_20 rfunct_2_th_21 sorry
              qed
              have case2: "r2 =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies ((sinSIN-COSK17).FUNCT-1K1 r2 >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume A21: "r2 =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
                then have "r1 inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
                  using A3 A17 xxreal_1_th_4 sorry
                then have "r1 inHIDDENR3 (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A4 xboole_0_def_4 sorry
                then have A22: "(sinSIN-COSK17).FUNCT-1K1 ?r3 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
                  using A12 A15 comptrig_th_20 rfunct_2_th_21 sorry
                assume "(sinSIN-COSK17).FUNCT-1K1 r2 >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 r1"
                thus " False "
                  using A6 A16 A21 A22 sin_cos_th_76 xxreal_0_th_1 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
             sorry
        qed
        have case2: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 r1 implies (sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
        proof(rule impI)
          assume A23: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M =COMPLEX1R1 r1"
          have "(sinSIN-COSK17).FUNCT-1K1 r2 >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False "
          proof-
            show "(sinSIN-COSK17).FUNCT-1K1 r2 >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False "
            proof-
              have cases: "r2 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) or r2 =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
                using A7 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies ((sinSIN-COSK17).FUNCT-1K1 r2 >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume "r2 <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
                then have "r2 inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
                  using A3 A23 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
                  using A11 xboole_0_def_4 sorry
                then have A24: "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 ?r3"
                  using A14 A15 comptrig_th_20 rfunct_2_th_21 sorry
                assume "(sinSIN-COSK17).FUNCT-1K1 r2 >=XXREAL-0R2 (sinSIN-COSK17).FUNCT-1K1 r1"
                thus " False "
                  using A10 A5 A23 A24 sin_cos_th_76 xxreal_0_th_1 sorry
              qed
              have case2: "r2 =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies (sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
              proof(rule impI)
                assume "r2 =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
                thus "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
                  using A23 sin_cos_th_76 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(sinSIN-COSK17).FUNCT-1K1 r2 <XXREAL-0R3 (sinSIN-COSK17).FUNCT-1K1 r1"
       sorry
  qed "sorry"
  thus "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be decreasingRFUNCT-2V2"
    using rfunct_2_th_21 sorry
qed

mtheorem comptrig_th_25:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be decreasingRFUNCT-2V2"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19) & (r2 inHIDDENR3 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19) & r1 <XXREAL-0R3 r2) implies (cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    assume A1: "r1 inHIDDENR3 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
      and A2: "r2 inHIDDENR3 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
      and A3: "r1 <XXREAL-0R3 r2"
    have A4: "r1 inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19)"
      using A1 xboole_0_def_4 sorry
    have " |.COMPLEX1K10 cosSIN-COSK20 r2 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 r2.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_19 sorry
    then have A5: "(cosSIN-COSK19).FUNCT-1K1 r2 <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have " |.COMPLEX1K10 cosSIN-COSK20 r1 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 r1.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_19 sorry
    then have A6: "(cosSIN-COSK19).FUNCT-1K1 r1 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have "r2 inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using A2 xboole_0_def_4 sorry
    then have A7: "r2 <=XXREAL-0R1 PISIN-COSK29"
      using xxreal_1_th_1 sorry
    let ?r3 = "(r1 +XCMPLX-0K2 r2)/XCMPLX-0K7 \<two>\<^sub>M"
    have A8: "r1 <XXREAL-0R3 ?r3"
      using A3 xreal_1_th_226 sorry
    have " |.COMPLEX1K10 cosSIN-COSK20 ?r3 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have A9: " |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 ?r3.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_19 sorry
    then have A10: "(cosSIN-COSK19).FUNCT-1K1 ?r3 <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have A11: "r2 inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19)"
      using A2 xboole_0_def_4 sorry
    have A12: "r1 inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using A1 xboole_0_def_4 sorry
    then have A13: "0NUMBERSK6 <XXREAL-0R3 ?r3"
      using A8 xxreal_1_th_1 sorry
    have A14: "?r3 <XXREAL-0R3 r2"
      using A3 xreal_1_th_226 sorry
    then have "?r3 <XXREAL-0R3 PISIN-COSK29"
      using A7 xxreal_0_th_2 sorry
    then have "?r3 inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using A13 xxreal_1_th_4 sorry
    then have A15: "?r3 inTARSKIR2 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
      using sin_cos_th_24 xboole_0_def_4 sorry
    have A16: "(cosSIN-COSK19).FUNCT-1K1 ?r3 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using A9 absvalue_th_5 sorry
    have "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
    proof-
      show "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
      proof-
        have cases: "0NUMBERSK6 <XXREAL-0R3 r1 or 0NUMBERSK6 =COMPLEX1R1 r1"
          using A12 xxreal_1_th_1 sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 r1 implies (cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
        proof(rule impI)
          assume A17: "0NUMBERSK6 <XXREAL-0R3 r1"
          have "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
          proof-
            show "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
            proof-
              have cases: "r2 <XXREAL-0R3 PISIN-COSK29 or r2 =COMPLEX1R1 PISIN-COSK29"
                using A7 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 PISIN-COSK29 implies (cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
              proof(rule impI)
                assume A18: "r2 <XXREAL-0R3 PISIN-COSK29"
                then have "r1 <XXREAL-0R3 PISIN-COSK29"
                  using A3 xxreal_0_th_2 sorry
                then have "r1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
                  using A17 xxreal_1_th_4 sorry
                then have A19: "r1 inHIDDENR3 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A4 xboole_0_def_4 sorry
                have "r2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
                  using A3 A17 A18 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A11 xboole_0_def_4 sorry
                thus "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
                  using A3 A19 comptrig_th_21 rfunct_2_th_21 sorry
              qed
              have case2: "r2 =COMPLEX1R1 PISIN-COSK29 implies ((cosSIN-COSK19).FUNCT-1K1 r2 >=XXREAL-0R2 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume A20: "r2 =COMPLEX1R1 PISIN-COSK29"
                then have "r1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
                  using A3 A17 xxreal_1_th_4 sorry
                then have "r1 inHIDDENR3 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A4 xboole_0_def_4 sorry
                then have A21: "(cosSIN-COSK19).FUNCT-1K1 ?r3 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
                  using A8 A15 comptrig_th_21 rfunct_2_th_21 sorry
                assume "(cosSIN-COSK19).FUNCT-1K1 r2 >=XXREAL-0R2 (cosSIN-COSK19).FUNCT-1K1 r1"
                thus " False "
                  using A6 A16 A20 A21 sin_cos_th_76 xxreal_0_th_1 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
             sorry
        qed
        have case2: "0NUMBERSK6 =COMPLEX1R1 r1 implies (cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
        proof(rule impI)
          assume A22: "0NUMBERSK6 =COMPLEX1R1 r1"
          have "(cosSIN-COSK19).FUNCT-1K1 r2 >=XXREAL-0R2 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False "
          proof-
            show "(cosSIN-COSK19).FUNCT-1K1 r2 >=XXREAL-0R2 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False "
            proof-
              have cases: "r2 <XXREAL-0R3 PISIN-COSK29 or r2 =COMPLEX1R1 PISIN-COSK29"
                using A7 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 PISIN-COSK29 implies ((cosSIN-COSK19).FUNCT-1K1 r2 >=XXREAL-0R2 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume "r2 <XXREAL-0R3 PISIN-COSK29"
                then have "r2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
                  using A3 A22 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A11 xboole_0_def_4 sorry
                then have A23: "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 ?r3"
                  using A14 A15 comptrig_th_21 rfunct_2_th_21 sorry
                assume "(cosSIN-COSK19).FUNCT-1K1 r2 >=XXREAL-0R2 (cosSIN-COSK19).FUNCT-1K1 r1"
                thus " False "
                  using A10 A5 A22 A23 sin_cos_th_30 xxreal_0_th_1 sorry
              qed
              have case2: "r2 =COMPLEX1R1 PISIN-COSK29 implies (cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
              proof(rule impI)
                assume "r2 =COMPLEX1R1 PISIN-COSK29"
                thus "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
                  using A22 sin_cos_th_30 sin_cos_th_76 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(cosSIN-COSK19).FUNCT-1K1 r2 <XXREAL-0R3 (cosSIN-COSK19).FUNCT-1K1 r1"
       sorry
  qed "sorry"
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be decreasingRFUNCT-2V2"
    using rfunct_2_th_21 sorry
qed

mtheorem comptrig_th_26:
"(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be increasingRFUNCT-2V1"
proof-
  have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19) & (r2 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19) & r1 <XXREAL-0R3 r2) implies (cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix r2 assume [ty]: "r2 be RealXREAL-0M1"
    assume A1: "r1 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
      and A2: "r2 inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
      and A3: "r1 <XXREAL-0R3 r2"
    have A4: "r1 inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19)"
      using A1 xboole_0_def_4 sorry
    let ?r3 = "(r1 +XCMPLX-0K2 r2)/XCMPLX-0K7 \<two>\<^sub>M"
    have "r1 inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
      using A1 xboole_0_def_4 sorry
    then have A5: "PISIN-COSK29 <=XXREAL-0R1 r1"
      using xxreal_1_th_1 sorry
    have " |.COMPLEX1K10 cosSIN-COSK20 ?r3 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have A6: " |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 ?r3.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_19 sorry
    then have A7: "(cosSIN-COSK19).FUNCT-1K1 ?r3 <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have "r2 inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
      using A2 xboole_0_def_4 sorry
    then have A8: "r2 <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_1 sorry
    have A9: "r1 <XXREAL-0R3 ?r3"
      using A3 xreal_1_th_226 sorry
    then have A10: "PISIN-COSK29 <XXREAL-0R3 ?r3"
      using A5 xxreal_0_th_2 sorry
    have A11: "?r3 <XXREAL-0R3 r2"
      using A3 xreal_1_th_226 sorry
    then have "?r3 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A8 xxreal_0_th_2 sorry
    then have "?r3 inTARSKIR2 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using A10 xxreal_1_th_4 sorry
    then have A12: "?r3 inTARSKIR2 (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
      using sin_cos_th_24 xboole_0_def_4 sorry
    have " |.COMPLEX1K10 cosSIN-COSK20 r2 .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 r2.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_19 sorry
    then have A13: "(cosSIN-COSK19).FUNCT-1K1 r2 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have A14: "r2 inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19)"
      using A2 xboole_0_def_4 sorry
    have A15: "(cosSIN-COSK19).FUNCT-1K1 ?r3 >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      using A6 absvalue_th_5 sorry
    have "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
    proof-
      show "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
      proof-
        have cases: "PISIN-COSK29 <XXREAL-0R3 r1 or PISIN-COSK29 =COMPLEX1R1 r1"
          using A5 xxreal_0_th_1 sorry
        have case1: "PISIN-COSK29 <XXREAL-0R3 r1 implies (cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
        proof(rule impI)
          assume A16: "PISIN-COSK29 <XXREAL-0R3 r1"
          then have A17: "PISIN-COSK29 <XXREAL-0R3 r2"
            using A3 xxreal_0_th_2 sorry
          have "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
          proof-
            show "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
            proof-
              have cases: "r2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or r2 =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                using A8 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies (cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
              proof(rule impI)
                assume A18: "r2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                then have "r1 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                  using A3 xxreal_0_th_2 sorry
                then have "r1 inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
                  using A16 xxreal_1_th_4 sorry
                then have A19: "r1 inHIDDENR3 (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A4 xboole_0_def_4 sorry
                have "r2 inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
                  using A17 A18 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A14 xboole_0_def_4 sorry
                thus "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
                  using A3 A19 comptrig_th_22 rfunct_2_th_20 sorry
              qed
              have case2: "r2 =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies ((cosSIN-COSK19).FUNCT-1K1 r2 <=XXREAL-0R1 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume A20: "r2 =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                then have "r1 inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
                  using A3 A16 xxreal_1_th_4 sorry
                then have "r1 inHIDDENR3 (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A4 xboole_0_def_4 sorry
                then have A21: "(cosSIN-COSK19).FUNCT-1K1 ?r3 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
                  using A9 A12 comptrig_th_22 rfunct_2_th_20 sorry
                assume "(cosSIN-COSK19).FUNCT-1K1 r2 <=XXREAL-0R1 (cosSIN-COSK19).FUNCT-1K1 r1"
                thus " False "
                  using A7 A20 A21 sin_cos_th_76 xxreal_0_th_2 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
             sorry
        qed
        have case2: "PISIN-COSK29 =COMPLEX1R1 r1 implies (cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
        proof(rule impI)
          assume A22: "PISIN-COSK29 =COMPLEX1R1 r1"
          have "(cosSIN-COSK19).FUNCT-1K1 r2 <=XXREAL-0R1 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False "
          proof-
            show "(cosSIN-COSK19).FUNCT-1K1 r2 <=XXREAL-0R1 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False "
            proof-
              have cases: "r2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or r2 =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                using A8 xxreal_0_th_1 sorry
              have case1: "r2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies ((cosSIN-COSK19).FUNCT-1K1 r2 <=XXREAL-0R1 (cosSIN-COSK19).FUNCT-1K1 r1 implies  False )"
              proof(rule impI,rule impI)
                assume "r2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                then have "r2 inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
                  using A3 A22 xxreal_1_th_4 sorry
                then have "r2 inHIDDENR3 (].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                  using A14 xboole_0_def_4 sorry
                then have A23: "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 ?r3"
                  using A11 A12 comptrig_th_22 rfunct_2_th_20 sorry
                assume "(cosSIN-COSK19).FUNCT-1K1 r2 <=XXREAL-0R1 (cosSIN-COSK19).FUNCT-1K1 r1"
                thus " False "
                  using A15 A13 A22 A23 sin_cos_th_76 xxreal_0_th_1 sorry
              qed
              have case2: "r2 =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies (cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
              proof(rule impI)
                assume "r2 =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                thus "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
                  using A22 sin_cos_th_76 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(cosSIN-COSK19).FUNCT-1K1 r2 >XXREAL-0R4 (cosSIN-COSK19).FUNCT-1K1 r1"
       sorry
  qed "sorry"
  thus "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be increasingRFUNCT-2V1"
    using rfunct_2_th_20 sorry
qed

mtheorem comptrig_th_27:
" for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] & (cosSIN-COSK19).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
proof-
  have " for x be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] & (cosSIN-COSK19).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have " |.COMPLEX1K10 cosSIN-COSK20 x .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (cosSIN-COSK19).FUNCT-1K1 x.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_19 sorry
    then have A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 (cosSIN-COSK19).FUNCT-1K1 x & (cosSIN-COSK19).FUNCT-1K1 x <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    have " |.COMPLEX1K10 sinSIN-COSK18 x .| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_th_27 sorry
    then have " |.COMPLEX1K10 (sinSIN-COSK17).FUNCT-1K1 x.| <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos_def_17 sorry
    then have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 (sinSIN-COSK17).FUNCT-1K1 x & (sinSIN-COSK17).FUNCT-1K1 x <=XXREAL-0R1 \<one>\<^sub>M"
      using absvalue_th_5 sorry
    thus "(sinSIN-COSK17).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] & (cosSIN-COSK19).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using A1 xxreal_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_28:
"rngFUNCT-1K2 (sinSIN-COSK17) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
proof-
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17) & y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17) & y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  proof(rule ballI,rule conjMI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17) & y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex tVar2 be objectHIDDENM1 st tVar2 inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17) & y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 tVar2)"
      proof(rule impI)
        assume A1: "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        then obtain y1 where 
          [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
           sorry
        have "y1 inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 \<one>\<^sub>M,(sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) .]"
          using A1 xboole_0_def_3 sorry
        then have "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be continuousFCONT-1V1 & y1 inHIDDENR3 [.RCOMP-1K1 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M),(sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M),(sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) .]"
          using sin_cos_th_30 sin_cos_th_76 sorry
        then obtain x where
          [ty]:"x be RealXREAL-0M1" and 
          "x inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"and A2: "y1 =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 x"
          using fcont_2_th_15 sin_cos_th_24 sorry
        show " ex tVar2 be objectHIDDENM1 st tVar2 inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17) & y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 tVar2"
        proof(rule bexI[of _ "x"])
          have "x inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          thus "x inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17) & y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x"
            using A2 sin_cos_th_24 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show "( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (sinSIN-COSK17) & y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using comptrig_th_27 sin_cos_th_24 sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (sinSIN-COSK17) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    using funct_1_def_3 sorry
qed

mtheorem comptrig_th_29:
"rngFUNCT-1K2 (cosSIN-COSK19) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
proof-
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19) & y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19) & y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  proof(rule ballI,rule conjMI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19) & y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex tVar3 be objectHIDDENM1 st tVar3 inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19) & y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 tVar3)"
      proof(rule impI)
        assume A1: "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        then obtain y1 where 
          [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
           sorry
        have "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be continuousFCONT-1V1 & y1 inHIDDENR3 [.RCOMP-1K1 (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6),(cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29),(cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6) .]"
          using A1 sin_cos_th_30 sin_cos_th_76 xboole_0_def_3 sorry
        then obtain x where
          [ty]:"x be RealXREAL-0M1" and 
          "x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"and A2: "y1 =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 x"
          using fcont_2_th_15 sin_cos_th_24 sorry
        show " ex tVar3 be objectHIDDENM1 st tVar3 inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19) & y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 tVar3"
        proof(rule bexI[of _ "x"])
          have "x inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          thus "x inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19) & y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x"
            using A2 sin_cos_th_24 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show "( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 (cosSIN-COSK19) & y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
      using comptrig_th_27 sin_cos_th_24 sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (cosSIN-COSK19) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    using funct_1_def_3 sorry
qed

mtheorem comptrig_th_30:
"rngFUNCT-1K2 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
proof-
  let ?sin1 = "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  proof(rule ballI,rule conjMI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex tVar4 be objectHIDDENM1 st tVar4 inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 tVar4)"
      proof(rule impI)
        assume A1: "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        then obtain y1 where 
          [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
           sorry
        have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
          using xxreal_1_th_1 sorry
        then have A2: "?sin1 .FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
          using funct_1_th_49 sorry
        have "-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
          using xxreal_1_th_1 sorry
        then have "?sin1 .FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
          using funct_1_th_49 sorry
        then have "y1 inHIDDENR3 [.RCOMP-1K1 ?sin1 .FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M),?sin1 .FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) .]"
          using A1 A2 sin_cos_th_30 sin_cos_th_76 sorry
        then have A3: "?sin1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]) be continuousFCONT-1V1 & y1 inHIDDENR3 [.RCOMP-1K1 ?sin1 .FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M),?sin1 .FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?sin1 .FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M),?sin1 .FUNCT-1K1 (-XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) .]"
          using xboole_0_def_3 sorry
        have "domRELAT-1K1 ?sin1 =HIDDENR1 ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
          using relat_1_th_61 sin_cos_th_24 sorry
        also have "... = [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
          using xboole_1_th_28 sorry
        finally have "domRELAT-1K1 ?sin1 =HIDDENR1 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
           sorry
        then obtain x where
          [ty]:"x be RealXREAL-0M1" and 
          A4: "x inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"and A5: "y1 =COMPLEX1R1 ?sin1 .FUNCT-1K1 x"
          using A3 fcont_2_th_15 sorry
        show " ex tVar4 be objectHIDDENM1 st tVar4 inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 tVar4"
        proof(rule bexI[of _ "x"])
          have "x inHIDDENR3 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])"
            using A4 xboole_0_def_4 sorry
          thus "x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 x"
            using A5 relat_1_th_61 sin_cos_th_24 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show "( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    proof(rule impI)
      assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ?sin1 & y =HIDDENR1 ?sin1 .FUNCT-1K1 x"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "x inHIDDENR3 domRELAT-1K1 ?sin1"and A7: "y =HIDDENR1 ?sin1 .FUNCT-1K1 x"
         sorry
      have "domRELAT-1K1 ?sin1 c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17)"
        using relat_1_th_60 sorry
      then obtain x1 where 
        [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
        using A6 sin_cos_th_24 sorry
      have "y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x1"
        using A6 A7 funct_1_th_47 sorry
      thus "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        using comptrig_th_27 sorry
    qed
  qed "sorry"
  thus "rngFUNCT-1K2 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    using funct_1_def_3 sorry
qed

mtheorem comptrig_th_31:
"rngFUNCT-1K2 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
proof-
  let ?sin1 = "(sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])"
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  proof(rule ballI,rule conjMI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex tVar5 be objectHIDDENM1 st tVar5 inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 tVar5)"
      proof(rule impI)
        have "(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
          using comptrig_lm_4 xxreal_1_th_1 sorry
        then have A1: "?sin1 .FUNCT-1K1 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
          using funct_1_th_49 sorry
        assume A2: "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        then obtain y1 where 
          [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
           sorry
        have A3: "domRELAT-1K1 ?sin1 =HIDDENR1 ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
          using relat_1_th_61 sin_cos_th_24 sorry
        also have "... = [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
          using xboole_1_th_28 sorry
        finally have "domRELAT-1K1 ?sin1 =HIDDENR1 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
           sorry
        have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
          using comptrig_lm_4 xxreal_1_th_1 sorry
        then have "?sin1 .FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M)"
          using funct_1_th_49 sorry
        then have "?sin1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]) be continuousFCONT-1V1 & y1 inHIDDENR3 [.RCOMP-1K1 ?sin1 .FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M),?sin1 .FUNCT-1K1 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?sin1 .FUNCT-1K1 ((\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)),?sin1 .FUNCT-1K1 ((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) .]"
          using A2 A1 sin_cos_th_76 xboole_0_def_3 sorry
        then obtain x where
          [ty]:"x be RealXREAL-0M1" and 
          A4: "x inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"and A5: "y1 =COMPLEX1R1 ?sin1 .FUNCT-1K1 x"
          using A3 comptrig_lm_4 fcont_2_th_15 sorry
        show " ex tVar5 be objectHIDDENM1 st tVar5 inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 tVar5"
        proof(rule bexI[of _ "x"])
          have "x inHIDDENR3 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])"
            using A4 xboole_0_def_4 sorry
          thus "x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x"
            using A5 relat_1_th_61 sin_cos_th_24 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show "( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    proof(rule impI)
      assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ?sin1 & y =HIDDENR1 ?sin1 .FUNCT-1K1 x"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "x inHIDDENR3 domRELAT-1K1 ?sin1"and A7: "y =HIDDENR1 ?sin1 .FUNCT-1K1 x"
         sorry
      have "domRELAT-1K1 ?sin1 c=TARSKIR1 domRELAT-1K1 (sinSIN-COSK17)"
        using relat_1_th_60 sorry
      then obtain x1 where 
        [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
        using A6 sin_cos_th_24 sorry
      have "y =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 x1"
        using A6 A7 funct_1_th_47 sorry
      thus "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        using comptrig_th_27 sorry
    qed
  qed "sorry"
  thus "rngFUNCT-1K2 ((sinSIN-COSK17) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    using funct_1_def_3 sorry
qed

mtheorem comptrig_th_32:
"rngFUNCT-1K2 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
proof-
  let ?cos1 = "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  proof(rule ballI,rule conjMI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex tVar6 be objectHIDDENM1 st tVar6 inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 tVar6)"
      proof(rule impI)
        have "PISIN-COSK29 inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
          using xxreal_1_th_1 sorry
        then have A1: "?cos1 .FUNCT-1K1 (PISIN-COSK29) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29)"
          using funct_1_th_49 sorry
        assume A2: "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        then obtain y1 where 
          [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
           sorry
        have A3: "domRELAT-1K1 ?cos1 =HIDDENR1 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
          using relat_1_th_61 sin_cos_th_24 sorry
        also have "... = [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
          using xboole_1_th_28 sorry
        finally have "domRELAT-1K1 ?cos1 =HIDDENR1 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
           sorry
        have "0NUMBERSK6 inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
          using xxreal_1_th_1 sorry
        then have "?cos1 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 (0NUMBERSK6)"
          using funct_1_th_49 sorry
        then have "?cos1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]) be continuousFCONT-1V1 & y1 inHIDDENR3 [.RCOMP-1K1 ?cos1 .FUNCT-1K1 (0NUMBERSK6),?cos1 .FUNCT-1K1 (PISIN-COSK29) .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?cos1 .FUNCT-1K1 (PISIN-COSK29),?cos1 .FUNCT-1K1 (0NUMBERSK6) .]"
          using A2 A1 sin_cos_th_30 sin_cos_th_76 xboole_0_def_3 sorry
        then obtain x where
          [ty]:"x be RealXREAL-0M1" and 
          A4: "x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"and A5: "y1 =COMPLEX1R1 ?cos1 .FUNCT-1K1 x"
          using A3 fcont_2_th_15 sorry
        show " ex tVar6 be objectHIDDENM1 st tVar6 inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 tVar6"
        proof(rule bexI[of _ "x"])
          have "x inHIDDENR3 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])"
            using A4 xboole_0_def_4 sorry
          thus "x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 x"
            using A5 relat_1_th_61 sin_cos_th_24 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show "( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    proof(rule impI)
      assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ?cos1 & y =HIDDENR1 ?cos1 .FUNCT-1K1 x"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "x inHIDDENR3 domRELAT-1K1 ?cos1"and A7: "y =HIDDENR1 ?cos1 .FUNCT-1K1 x"
         sorry
      have "domRELAT-1K1 ?cos1 c=TARSKIR1 domRELAT-1K1 (cosSIN-COSK19)"
        using relat_1_th_60 sorry
      then obtain x1 where 
        [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
        using A6 sin_cos_th_24 sorry
      have "y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x1"
        using A6 A7 funct_1_th_47 sorry
      thus "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        using comptrig_th_27 sorry
    qed
  qed "sorry"
  thus "rngFUNCT-1K2 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    using funct_1_def_3 sorry
qed

mtheorem comptrig_th_33:
"rngFUNCT-1K2 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
proof-
  let ?cos1 = "(cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])"
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .])"
  proof(rule ballI,rule conjMI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .] implies ( ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 tVar7)"
      proof(rule impI)
        have "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
          using comptrig_lm_3 xxreal_1_th_1 sorry
        then have A1: "?cos1 .FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
          using funct_1_th_49 sorry
        assume A2: "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        then obtain y1 where 
          [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
           sorry
        have A3: "domRELAT-1K1 ?cos1 =HIDDENR1 ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
          using relat_1_th_61 sin_cos_th_24 sorry
        also have "... = [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
          using xboole_1_th_28 sorry
        finally have "domRELAT-1K1 ?cos1 =HIDDENR1 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
           sorry
        have "PISIN-COSK29 inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
          using comptrig_lm_3 xxreal_1_th_1 sorry
        then have "?cos1 .FUNCT-1K1 (PISIN-COSK29) =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29)"
          using funct_1_th_49 sorry
        then have "?cos1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]) be continuousFCONT-1V1 & y1 inHIDDENR3 [.RCOMP-1K1 ?cos1 .FUNCT-1K1 (PISIN-COSK29),?cos1 .FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?cos1 .FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)),?cos1 .FUNCT-1K1 (PISIN-COSK29) .]"
          using A2 A1 sin_cos_th_76 xboole_0_def_3 sorry
        then obtain x where
          [ty]:"x be RealXREAL-0M1" and 
          A4: "x inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"and A5: "y1 =COMPLEX1R1 ?cos1 .FUNCT-1K1 x"
          using A3 comptrig_lm_3 fcont_2_th_15 sorry
        show " ex tVar7 be objectHIDDENM1 st tVar7 inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 tVar7"
        proof(rule bexI[of _ "x"])
          have "x inHIDDENR3 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])"
            using A4 xboole_0_def_4 sorry
          thus "x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x"
            using A5 relat_1_th_61 sin_cos_th_24 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show "( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) & y =HIDDENR1 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])).FUNCT-1K1 x) implies y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    proof(rule impI)
      assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 ?cos1 & y =HIDDENR1 ?cos1 .FUNCT-1K1 x"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "x inHIDDENR3 domRELAT-1K1 ?cos1"and A7: "y =HIDDENR1 ?cos1 .FUNCT-1K1 x"
         sorry
      have "domRELAT-1K1 ?cos1 c=TARSKIR1 domRELAT-1K1 (cosSIN-COSK19)"
        using relat_1_th_60 sorry
      then obtain x1 where 
        [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
        using A6 sin_cos_th_24 sorry
      have "y =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 x1"
        using A6 A7 funct_1_th_47 sorry
      thus "y inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
        using comptrig_th_27 sorry
    qed
  qed "sorry"
  thus "rngFUNCT-1K2 ((cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])) =XBOOLE-0R4 [.RCOMP-1K1 -XCMPLX-0K4 \<one>\<^sub>M,\<one>\<^sub>M .]"
    using funct_1_def_3 sorry
qed

(*begin*)
mdef comptrig_def_1 ("ArgCOMPTRIGK1  _ " [164]164 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func ArgCOMPTRIGK1 z \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. (z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it) & it <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) if z <>HIDDENR2 0NUMBERSK6 otherwise \<lambda>it. it =COMPLEX1R1 0NUMBERSK6"
proof-
  (*existence*)
    show "(z <>HIDDENR2 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st (z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it) & it <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))) & ( not z <>HIDDENR2 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 0NUMBERSK6))"
    proof-
      have "(z <>HIDDENR2 0NUMBERSK6 implies ( ex r be RealXREAL-0M1 st (z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 r) & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))) &  not (z <>HIDDENR2 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 0NUMBERSK6))"
      proof(rule conjMI)
        show "z <>HIDDENR2 0NUMBERSK6 implies ( ex r be RealXREAL-0M1 st (z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 r) & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
        proof-
          have "z <>HIDDENR2 0NUMBERSK6 implies  not ( for r be RealXREAL-0M1 holds  not ((z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 r) &  not r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))"
          proof(rule impI)
            have " |.COMPLEX1K10 z.| >=XXREAL-0R2 0NUMBERSK6"
              using complex1_th_46 sorry
            then have A1: "ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) <=XXREAL-0R1 \<one>\<^sub>M"
              using complex1_th_54 xreal_1_th_185 sorry
            assume A2: "z <>HIDDENR2 0NUMBERSK6"
            then have A3: " |.COMPLEX1K10 z.| <>HIDDENR2 0NUMBERSK6"
              using complex1_th_45 sorry
            have " ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
            proof-
              show " ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
              proof-
                have cases: "ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6 or ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
                   sorry
                have case1: "ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6 implies ( ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))"
                proof(rule impI)
                  assume A4: "ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
                  let ?OPI = "[.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
                  obtain cos1 where 
                    [ty]:"cos1 be PartFuncPARTFUN1M1-of(?OPI,REALNUMBERSK2)" and cos1Def:"cos1 = (cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?OPI"
                    using partfun1_th_10 sorry
                  have 
                    [ty]:"cos1 be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(?OPI,REALNUMBERSK2)"
                    using comptrig_th_25 rfunct_2_th_50 sorry
                  obtain r where 
                    [ty]:"r be RealXREAL-0M1" and rDef:"r = cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .],REALNUMBERSK2)\<^esub> .FUNCT-1K1 (ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))"
                     sorry
                  have A5: "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
                    using comptrig_th_3 sorry
                  show " ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
                  proof(rule bexI[of _ "r"],rule conjMI,rule conjMI)
                    have "ReCOMPLEX1K3 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
                      using comptrig_th_1 sorry
                    then have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                      using complex1_th_46 xreal_1_th_193 sorry
                    then have A6: "ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) inTARSKIR2 rngFUNCT-1K2 cos1"
                      using A1 comptrig_th_32 xxreal_1_th_1 sorry
                    then have "ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) inTARSKIR2 domRELAT-1K1 (cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .],REALNUMBERSK2)\<^esub>)"
                      using funct_1_th_33 sorry
                    then have "r inHIDDENR3 rngFUNCT-1K2 (cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .],REALNUMBERSK2)\<^esub>)"
                      using funct_1_def_3 sorry
                    then have "r inHIDDENR3 domRELAT-1K1 cos1"
                      using funct_1_th_33 sorry
                    then have A7: "r inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
                      using relat_1_th_57 sorry
                    then have "r <=XXREAL-0R1 PISIN-COSK29"
                      using xxreal_1_th_1 sorry
                    then have A8: "r =COMPLEX1R1 PISIN-COSK29 or r <XXREAL-0R3 PISIN-COSK29"
                      using xxreal_0_th_1 sorry
                    have A9: "cosSIN-COSK20 r =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 r"
                      using sin_cos_def_19 sorry
                    also have "... = cos1 .FUNCT-1K1 r"
                      using A7 funct_1_th_49 sorry
                    also have "... = ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                      using A6 funct_1_th_35 sorry
                    finally have "cosSIN-COSK20 r =HIDDENR1 ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                       sorry
                    have "0NUMBERSK6 =COMPLEX1R1 r or 0NUMBERSK6 <XXREAL-0R3 r"
                      using A7 xxreal_1_th_1 sorry
                    then have "(r =COMPLEX1R1 0NUMBERSK6 or r =COMPLEX1R1 PISIN-COSK29) or r inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
                      using A8 xxreal_1_th_4 sorry
                    then have A10: "(sinSIN-COSK17).FUNCT-1K1 r >=XXREAL-0R2 0NUMBERSK6"
                      using comptrig_th_7 sin_cos_th_30 sin_cos_th_76 sorry
                    have "((cosSIN-COSK19).FUNCT-1K1 r)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 r)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M"
                      using sin_cos_th_28 sorry
                    then have "((sinSIN-COSK17).FUNCT-1K1 r)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 r)^2SQUARE-1K1"
                       sorry
                    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                      using A9 sin_cos_def_19 sorry
                    also have "... = \<one>\<^sub>M -XCMPLX-0K6 (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
                      using xcmplx_1_th_76 sorry
                    also have "... = ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 -XCMPLX-0K6 (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
                      using A3 xcmplx_1_th_60 sorry
                    also have "... = (( |.COMPLEX1K10 z.|)^2SQUARE-1K1 -XCMPLX-0K6 (ReCOMPLEX1K3 z)^2SQUARE-1K1)/XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
                       sorry
                    also have "... = (ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                      using A5 xcmplx_1_th_76 sorry
                    finally have "((sinSIN-COSK17).FUNCT-1K1 r)^2SQUARE-1K1 =HIDDENR1 (ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                       sorry
                    then have "(sinSIN-COSK17).FUNCT-1K1 r =HIDDENR1 sqrtSQUARE-1K3 (ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                      using A10 square_1_th_22 sorry
                    also have "... =  |.COMPLEX1K10 ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) .|"
                      using complex1_th_72 sorry
                    also have "... = ( |.COMPLEX1K10 ImCOMPLEX1K4 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10  |.COMPLEX1K10 z.| .|)"
                      using complex1_th_67 sorry
                    also have "... = ( |.COMPLEX1K10 ImCOMPLEX1K4 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                       sorry
                    finally have "(sinSIN-COSK17).FUNCT-1K1 r =HIDDENR1 ( |.COMPLEX1K10 ImCOMPLEX1K4 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                       sorry
                    then have " |.COMPLEX1K10 ImCOMPLEX1K4 z.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 r"
                      using A2 complex1_th_45 xcmplx_1_th_87 sorry
                    then have A11: "ImCOMPLEX1K4 z =HIDDENR1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 r"
                      using A4 absvalue_def_1 sorry
                    also have "... = ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r)"
                      using sin_cos_def_17 sorry
                    finally have "ImCOMPLEX1K4 z =HIDDENR1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r)"
                       sorry
                    have "ReCOMPLEX1K3 z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r)"
                      using A2 A9 complex1_th_45 xcmplx_1_th_87 sorry
                    thus "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8)"
                      using A11 complex1_th_13 sorry
                    show "0NUMBERSK6 <=XXREAL-0R1 r"
                      using A7 xxreal_1_th_1 sorry
                    have "r <=XXREAL-0R1 PISIN-COSK29"
                      using A7 xxreal_1_th_1 sorry
                    thus "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                      using comptrig_lm_3 xxreal_0_th_2 sorry
                  qed "sorry"
                qed
                have case2: "ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 implies ( ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))"
                proof(rule impI)
                  assume A12: "ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
                  show " ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
                  proof-
                    have cases: "ReCOMPLEX1K3 z <>HIDDENR2  |.COMPLEX1K10 z.| or ReCOMPLEX1K3 z =COMPLEX1R1  |.COMPLEX1K10 z.|"
                       sorry
                    have case1: "ReCOMPLEX1K3 z <>HIDDENR2  |.COMPLEX1K10 z.| implies ( ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))"
                    proof(rule impI)
                      assume A13: "ReCOMPLEX1K3 z <>HIDDENR2  |.COMPLEX1K10 z.|"
                      let ?OPI = "[.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
                      obtain cos1 where 
                        [ty]:"cos1 be PartFuncPARTFUN1M1-of(?OPI,REALNUMBERSK2)" and cos1Def:"cos1 = (cosSIN-COSK19) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?OPI"
                        using partfun1_th_10 sorry
                      have 
                        [ty]:"cos1 be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(?OPI,REALNUMBERSK2)"
                        using comptrig_th_26 rfunct_2_th_50 sorry
                      obtain r where 
                        [ty]:"r be RealXREAL-0M1" and rDef:"r = cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .],REALNUMBERSK2)\<^esub> .FUNCT-1K1 (ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))"
                         sorry
                      have "ReCOMPLEX1K3 z >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 z.|"
                        using comptrig_th_1 sorry
                      then have "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                        using complex1_th_46 xreal_1_th_193 sorry
                      then have A14: "ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) inTARSKIR2 rngFUNCT-1K2 cos1"
                        using A1 comptrig_th_33 xxreal_1_th_1 sorry
                      then have A15: "ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) inTARSKIR2 domRELAT-1K1 (cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .],REALNUMBERSK2)\<^esub>)"
                        using funct_1_th_33 sorry
                      then have "r inHIDDENR3 rngFUNCT-1K2 (cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .],REALNUMBERSK2)\<^esub>)"
                        using funct_1_def_3 sorry
                      then have "r inHIDDENR3 domRELAT-1K1 cos1"
                        using funct_1_th_33 sorry
                      then have A16: "r inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
                        using relat_1_th_57 sorry
                      then have "r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                        using xxreal_1_th_1 sorry
                      then have A17: "r =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                        using xxreal_0_th_1 sorry
                      have A18: "ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) <>HIDDENR2 \<one>\<^sub>M"
                        using A13 xcmplx_1_th_58 sorry
                      have A19: "r <>HIDDENR2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                      proof-
                        have "r =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies  False "
                        proof(rule impI)
                          have "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
                            using comptrig_lm_3 xxreal_1_th_1 sorry
                          then have "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) inTARSKIR2 domRELAT-1K1 cos1 & cos1 .FUNCT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) =COMPLEX1R1 \<one>\<^sub>M"
                            using funct_1_th_49 relat_1_th_57 sin_cos_th_24 sin_cos_th_76 sorry
                          then have A20: "cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .],REALNUMBERSK2)\<^esub> .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                            using funct_1_th_32 sorry
                          have "\<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 cos1"
                            using comptrig_th_33 xxreal_1_th_1 sorry
                          then have A21: "\<one>\<^sub>M inTARSKIR2 domRELAT-1K1 (cos1 \<inverse>PARTFUN2K2\<^bsub>([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .],REALNUMBERSK2)\<^esub>)"
                            using funct_1_th_33 sorry
                          assume "r =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                          thus " False "
                            using A18 A15 A21 A20 funct_1_def_4 sorry
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have A22: "cosSIN-COSK20 r =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 r"
                        using sin_cos_def_19 sorry
                      also have "... = cos1 .FUNCT-1K1 r"
                        using A16 funct_1_th_49 sorry
                      also have "... = ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                        using A14 funct_1_th_35 sorry
                      finally have "cosSIN-COSK20 r =HIDDENR1 ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                         sorry
                      have "PISIN-COSK29 <=XXREAL-0R1 r"
                        using A16 xxreal_1_th_1 sorry
                      then have "PISIN-COSK29 =COMPLEX1R1 r or PISIN-COSK29 <XXREAL-0R3 r"
                        using xxreal_0_th_1 sorry
                      then have "(r =COMPLEX1R1 PISIN-COSK29 or r =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or r inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
                        using A17 xxreal_1_th_4 sorry
                      then have A23: "(sinSIN-COSK17).FUNCT-1K1 r <=XXREAL-0R1 0NUMBERSK6"
                        using comptrig_th_9 sin_cos_th_76 sorry
                      show " ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
                      proof(rule bexI[of _ "r"],rule conjMI,rule conjMI)
                        have A24: "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
                          using comptrig_th_3 sorry
                        have "((cosSIN-COSK19).FUNCT-1K1 r)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 r)^2SQUARE-1K1 =COMPLEX1R1 \<one>\<^sub>M"
                          using sin_cos_th_28 sorry
                        then have "((sinSIN-COSK17).FUNCT-1K1 r)^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 r)^2SQUARE-1K1"
                           sorry
                        also have "... = \<one>\<^sub>M -XCMPLX-0K6 (ReCOMPLEX1K3 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                          using A22 sin_cos_def_19 sorry
                        also have "... = \<one>\<^sub>M -XCMPLX-0K6 (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
                          using xcmplx_1_th_76 sorry
                        also have "... = ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 -XCMPLX-0K6 (ReCOMPLEX1K3 z)^2SQUARE-1K1 /XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
                          using A3 xcmplx_1_th_60 sorry
                        also have "... = (( |.COMPLEX1K10 z.|)^2SQUARE-1K1 -XCMPLX-0K6 (ReCOMPLEX1K3 z)^2SQUARE-1K1)/XCMPLX-0K7 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
                           sorry
                        also have "... = (ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                          using A24 xcmplx_1_th_76 sorry
                        finally have "((sinSIN-COSK17).FUNCT-1K1 r)^2SQUARE-1K1 =HIDDENR1 (ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                           sorry
                        then have "-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 r =HIDDENR1 sqrtSQUARE-1K3 (ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|))^2SQUARE-1K1"
                          using A23 square_1_th_23 sorry
                        also have "... =  |.COMPLEX1K10 ImCOMPLEX1K4 z /XCMPLX-0K7 ( |.COMPLEX1K10 z.|) .|"
                          using complex1_th_72 sorry
                        also have "... = ( |.COMPLEX1K10 ImCOMPLEX1K4 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10  |.COMPLEX1K10 z.| .|)"
                          using complex1_th_67 sorry
                        also have "... = ( |.COMPLEX1K10 ImCOMPLEX1K4 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                           sorry
                        finally have "-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 r =HIDDENR1 ( |.COMPLEX1K10 ImCOMPLEX1K4 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                           sorry
                        then have "(sinSIN-COSK17).FUNCT-1K1 r =COMPLEX1R1 (-XCMPLX-0K4  |.COMPLEX1K10 ImCOMPLEX1K4 z.|)/XCMPLX-0K7 ( |.COMPLEX1K10 z.|)"
                           sorry
                        then have "-XCMPLX-0K4  |.COMPLEX1K10 ImCOMPLEX1K4 z.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 r"
                          using A2 complex1_th_45 xcmplx_1_th_87 sorry
                        then have A25: "-REAL-1K1 (-REAL-1K1 ImCOMPLEX1K4 z) =HIDDENR1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 r"
                          using A12 absvalue_def_1 sorry
                        also have "... = ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r)"
                          using sin_cos_def_17 sorry
                        finally have "-REAL-1K1 (-REAL-1K1 ImCOMPLEX1K4 z) =HIDDENR1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r)"
                           sorry
                        have "ReCOMPLEX1K3 z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r)"
                          using A2 A22 complex1_th_45 xcmplx_1_th_87 sorry
                        thus "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8)"
                          using A25 complex1_th_13 sorry
                        show "0NUMBERSK6 <=XXREAL-0R1 r"
                          using A16 xxreal_1_th_1 sorry
                        have "r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                          using A16 xxreal_1_th_1 sorry
                        thus "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                          using A19 xxreal_0_th_1 sorry
                      qed "sorry"
                    qed
                    have case2: "ReCOMPLEX1K3 z =COMPLEX1R1  |.COMPLEX1K10 z.| implies ( ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))"
                    proof(rule impI)
                      assume A26: "ReCOMPLEX1K3 z =COMPLEX1R1  |.COMPLEX1K10 z.|"
                      obtain r where 
                        [ty]:"r be RealXREAL-0M1" and rDef:"r = 0NUMBERSK6"
                         sorry
                      show " ex r be RealXREAL-0M1 st z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
                      proof(rule bexI[of _ "r"],rule conjMI,rule conjMI)
                        have "(ReCOMPLEX1K3 z)^2SQUARE-1K1 =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
                          using A26 comptrig_th_3 sorry
                        then have "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
                           sorry
                        thus "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8)"
                          using A26 complex1_th_13 sin_cos_th_31 sorry
                        show "0NUMBERSK6 <=XXREAL-0R1 r"
                           sorry
                        show "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                          using comptrig_lm_1 sorry
                      qed "sorry"
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " not ( for r be RealXREAL-0M1 holds  not ((z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 r) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 r))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 r) &  not r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        show " not (z <>HIDDENR2 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (z <>HIDDENR2 0NUMBERSK6 implies (((z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it1) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it1))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it1) & it1 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & ((z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 it2) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 it2))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 it2) & it2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) implies it1 =HIDDENR1 it2)) & ( not z <>HIDDENR2 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
    proof-
      have " for VarFor1 be RealXREAL-0M1 holds  for VarFor2 be RealXREAL-0M1 holds  not ((((((( not z <>HIDDENR2 0NUMBERSK6 & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 VarFor1) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 VarFor1))*XCMPLX-0K3 (<i>COMPLEX1K8)) & 0NUMBERSK6 <=XXREAL-0R1 VarFor1) &  not VarFor1 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 VarFor2) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 VarFor2))*XCMPLX-0K3 (<i>COMPLEX1K8)) & 0NUMBERSK6 <=XXREAL-0R1 VarFor2) &  not VarFor2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) &  not VarFor1 =HIDDENR1 VarFor2) &  not (((z <>HIDDENR2 0NUMBERSK6 & VarFor1 =COMPLEX1R1 0NUMBERSK6) & VarFor2 =COMPLEX1R1 0NUMBERSK6) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        have "z <>HIDDENR2 0NUMBERSK6 implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ((((z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 x) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 x))*XCMPLX-0K3 (<i>COMPLEX1K8) & 0NUMBERSK6 <=XXREAL-0R1 x) & x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 y) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 y))*XCMPLX-0K3 (<i>COMPLEX1K8)) & 0NUMBERSK6 <=XXREAL-0R1 y) & y <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies x =COMPLEX1R1 y)"
        proof-
          have "z <>HIDDENR2 0NUMBERSK6 implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 x) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 x))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 x & (x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & (z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 y) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 y))*XCMPLX-0K3 (<i>COMPLEX1K8) & (0NUMBERSK6 <=XXREAL-0R1 y & y <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))))) implies x =COMPLEX1R1 y)"
          proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
            assume "z <>HIDDENR2 0NUMBERSK6"
            then have A27: " |.COMPLEX1K10 z.| <>HIDDENR2 0NUMBERSK6"
              using complex1_th_45 sorry
            fix x assume [ty]: "x be RealXREAL-0M1"
            fix y assume [ty]: "y be RealXREAL-0M1"
            assume A28: "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 x) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
              and A29: "0NUMBERSK6 <=XXREAL-0R1 x"
              and A30: "x <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
              and A31: "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 y) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 y))*XCMPLX-0K3 (<i>COMPLEX1K8)"
              and A32: "0NUMBERSK6 <=XXREAL-0R1 y"
              and A33: "y <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            have "( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 x) =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 y)"
              using A28 A31 complex1_th_77 sorry
            then have "cosSIN-COSK20 x =COMPLEX1R1 cosSIN-COSK20 y"
              using A27 xcmplx_1_th_5 sorry
            then have "cosSIN-COSK20 x =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 y"
              using sin_cos_def_19 sorry
            then have A34: "(cosSIN-COSK19).FUNCT-1K1 x =COMPLEX1R1 (cosSIN-COSK19).FUNCT-1K1 y"
              using sin_cos_def_19 sorry
            have "( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 x) =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 y)"
              using A28 A31 complex1_th_77 sorry
            then have "sinSIN-COSK18 x =COMPLEX1R1 sinSIN-COSK18 y"
              using A27 xcmplx_1_th_5 sorry
            then have A35: "sinSIN-COSK18 x =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 y"
              using sin_cos_def_17 sorry
            have "x <>HIDDENR2 y implies  False "
            proof-
              show "x <>HIDDENR2 y implies  False "
              proof-
                have cases: "((x <=XXREAL-0R1 PISIN-COSK29 & y <=XXREAL-0R1 PISIN-COSK29 or x >XXREAL-0R4 PISIN-COSK29 & y >XXREAL-0R4 PISIN-COSK29) or x <=XXREAL-0R1 PISIN-COSK29 & y >XXREAL-0R4 PISIN-COSK29) or y <=XXREAL-0R1 PISIN-COSK29 & x >XXREAL-0R4 PISIN-COSK29"
                   sorry
                have case1: "x <=XXREAL-0R1 PISIN-COSK29 & y <=XXREAL-0R1 PISIN-COSK29 implies (x <>HIDDENR2 y implies  False )"
                proof(rule impI,rule impI)
                  assume A36: "x <=XXREAL-0R1 PISIN-COSK29 & y <=XXREAL-0R1 PISIN-COSK29"
                  then have "y inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
                    using A32 xxreal_1_th_1 sorry
                  then have A37: "y inHIDDENR3 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                    using sin_cos_th_24 xboole_0_def_4 sorry
                  assume "x <>HIDDENR2 y"
                  then have A38: "x <XXREAL-0R3 y or y <XXREAL-0R3 x"
                    using xxreal_0_th_1 sorry
                  have "x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
                    using A29 A36 xxreal_1_th_1 sorry
                  then have "x inHIDDENR3 ([.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                    using sin_cos_th_24 xboole_0_def_4 sorry
                  thus " False "
                    using A34 A37 A38 comptrig_th_25 rfunct_2_th_21 sorry
                qed
                have case2: "x >XXREAL-0R4 PISIN-COSK29 & y >XXREAL-0R4 PISIN-COSK29 implies (x <>HIDDENR2 y implies  False )"
                proof(rule impI,rule impI)
                  assume A39: "x >XXREAL-0R4 PISIN-COSK29 & y >XXREAL-0R4 PISIN-COSK29"
                  then have "y inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
                    using A33 xxreal_1_th_1 sorry
                  then have A40: "y inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                    using sin_cos_th_24 xboole_0_def_4 sorry
                  assume "x <>HIDDENR2 y"
                  then have A41: "x <XXREAL-0R3 y or y <XXREAL-0R3 x"
                    using xxreal_0_th_1 sorry
                  have "x inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
                    using A30 A39 xxreal_1_th_1 sorry
                  then have "x inHIDDENR3 ([.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .])/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (cosSIN-COSK19)"
                    using sin_cos_th_24 xboole_0_def_4 sorry
                  thus " False "
                    using A34 A40 A41 comptrig_th_26 rfunct_2_th_20 sorry
                qed
                have case3: "x <=XXREAL-0R1 PISIN-COSK29 & y >XXREAL-0R4 PISIN-COSK29 implies x =COMPLEX1R1 y"
                proof(rule impI)
                  assume A42: "x <=XXREAL-0R1 PISIN-COSK29 & y >XXREAL-0R4 PISIN-COSK29"
                  then have "y inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
                    using A33 xxreal_1_th_4 sorry
                  then have A43: "(sinSIN-COSK17).FUNCT-1K1 y <XXREAL-0R3 0NUMBERSK6"
                    using comptrig_th_9 sorry
                  have "x inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
                    using A29 A42 xxreal_1_th_1 sorry
                  then have "(sinSIN-COSK17).FUNCT-1K1 x >=XXREAL-0R2 0NUMBERSK6"
                    using comptrig_th_8 sorry
                  thus "x =COMPLEX1R1 y"
                    using A35 A43 sin_cos_def_17 sorry
                qed
                have case4: "y <=XXREAL-0R1 PISIN-COSK29 & x >XXREAL-0R4 PISIN-COSK29 implies x =COMPLEX1R1 y"
                proof(rule impI)
                  assume A44: "y <=XXREAL-0R1 PISIN-COSK29 & x >XXREAL-0R4 PISIN-COSK29"
                  then have "x inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
                    using A30 xxreal_1_th_4 sorry
                  then have A45: "(sinSIN-COSK17).FUNCT-1K1 x <XXREAL-0R3 0NUMBERSK6"
                    using comptrig_th_9 sorry
                  have "y inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
                    using A32 A44 xxreal_1_th_1 sorry
                  then have "(sinSIN-COSK17).FUNCT-1K1 y >=XXREAL-0R2 0NUMBERSK6"
                    using comptrig_th_8 sorry
                  thus "x =COMPLEX1R1 y"
                    using A35 A45 sin_cos_def_17 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 case4 sorry
              qed
            qed
            thus "x =COMPLEX1R1 y"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " for VarFor1 be RealXREAL-0M1 holds  for VarFor2 be RealXREAL-0M1 holds  not ((((((( not z <>HIDDENR2 0NUMBERSK6 & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 VarFor1) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 VarFor1))*XCMPLX-0K3 (<i>COMPLEX1K8)) & 0NUMBERSK6 <=XXREAL-0R1 VarFor1) &  not VarFor1 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 VarFor2) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 VarFor2))*XCMPLX-0K3 (<i>COMPLEX1K8)) & 0NUMBERSK6 <=XXREAL-0R1 VarFor2) &  not VarFor2 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) &  not VarFor1 =HIDDENR1 VarFor2) &  not (((z <>HIDDENR2 0NUMBERSK6 & VarFor1 =COMPLEX1R1 0NUMBERSK6) & VarFor2 =COMPLEX1R1 0NUMBERSK6) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be RealXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem comptrig_th_34:
" for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z &  not ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) or z =COMPLEX1R1 0NUMBERSK6"
      using comptrig_def_1 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z &  not ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_def_1 comptrig_lm_6 comptrig_lm_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_35:
" for x be RealXREAL-0M1 holds x >=XXREAL-0R2 0NUMBERSK6 implies ArgCOMPTRIGK1 x =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have A1: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) & ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using comptrig_th_34 sorry
  assume A2: "x >=XXREAL-0R2 0NUMBERSK6"
  show "ArgCOMPTRIGK1 x =COMPLEX1R1 0NUMBERSK6"
  proof-
    have cases: "x >XXREAL-0R4 -XCMPLX-0K4 0NUMBERSK6 or x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    have case1: "x >XXREAL-0R4 -XCMPLX-0K4 0NUMBERSK6 implies ArgCOMPTRIGK1 x =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume A3: "x >XXREAL-0R4 -XCMPLX-0K4 0NUMBERSK6"
      then have A4: "x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 ( |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))) +XCMPLX-0K2 (( |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using comptrig_def_1 sorry
      have " |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .| <>HIDDENR2 0NUMBERSK6"
        using A3 complex1_th_45 sorry
      then have "sinSIN-COSK18 (ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 0NUMBERSK6"
        using A4 complex1_th_77 sorry
      then have "ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6 or ( |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) =COMPLEX1R1 x"
        using A1 A4 comptrig_th_17 sin_cos_th_77 sorry
      then have "ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .| <XXREAL-0R3 0NUMBERSK6"
        using A3 sorry
      thus "ArgCOMPTRIGK1 x =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_46 sorry
    qed
    have case2: "x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 x =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 0NUMBERSK6"
      thus "ArgCOMPTRIGK1 x =COMPLEX1R1 0NUMBERSK6"
        using comptrig_def_1 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem comptrig_th_36:
" for x be RealXREAL-0M1 holds x <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 x =COMPLEX1R1 PISIN-COSK29"
proof(rule ballI,rule impI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have A1: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) & ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using comptrig_th_34 sorry
  assume A2: "x <XXREAL-0R3 0NUMBERSK6"
  then have A3: "x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 ( |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))) +XCMPLX-0K2 (( |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using comptrig_def_1 sorry
  have " |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .| <>HIDDENR2 0NUMBERSK6"
    using A2 complex1_th_45 sorry
  then have "sinSIN-COSK18 (ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 0NUMBERSK6"
    using A3 complex1_th_77 sorry
  then have "ArgCOMPTRIGK1 (x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 PISIN-COSK29 or ( |.COMPLEX1K10 x +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 \<one>\<^sub>M =COMPLEX1R1 x"
    using A1 A3 comptrig_th_17 sin_cos_th_31 sorry
  thus "ArgCOMPTRIGK1 x =COMPLEX1R1 PISIN-COSK29"
    using A2 complex1_th_46 sorry
qed "sorry"

mtheorem comptrig_th_37:
" for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof(rule ballI,rule impI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have A1: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) & ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using comptrig_th_34 sorry
  assume A2: "x >XXREAL-0R4 0NUMBERSK6"
  then have A3: "0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) <>HIDDENR2 0NUMBERSK6"
     sorry
  then have A4: "0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 ( |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)))) +XCMPLX-0K2 (( |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using comptrig_def_1 sorry
  have " |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .| <>HIDDENR2 0NUMBERSK6"
    using A3 complex1_th_45 sorry
  then have "cosSIN-COSK20 (ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 0NUMBERSK6"
    using A4 complex1_th_77 sorry
  then have "ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or ( |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) =COMPLEX1R1 x"
    using A1 A4 comptrig_th_18 sin_cos_th_77 sorry
  then have "ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or  |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .| <XXREAL-0R3 0NUMBERSK6"
    using A2 sorry
  thus "ArgCOMPTRIGK1 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
    using complex1_th_46 sorry
qed "sorry"

mtheorem comptrig_th_38:
" for x be RealXREAL-0M1 holds x <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
proof(rule ballI,rule impI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  have A1: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) & ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using comptrig_th_34 sorry
  assume A2: "x <XXREAL-0R3 0NUMBERSK6"
  then have A3: "0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) <>HIDDENR2 0NUMBERSK6"
     sorry
  then have A4: "0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 ( |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)))) +XCMPLX-0K2 (( |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using comptrig_def_1 sorry
  have " |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .| <>HIDDENR2 0NUMBERSK6"
    using A3 complex1_th_45 sorry
  then have "cosSIN-COSK20 (ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8))) =COMPLEX1R1 0NUMBERSK6"
    using A4 complex1_th_77 sorry
  then have "ArgCOMPTRIGK1 (0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) or ( |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 x *XCMPLX-0K3 (<i>COMPLEX1K8) .|)*XCMPLX-0K3 \<one>\<^sub>M =COMPLEX1R1 x"
    using A1 A4 comptrig_th_18 sin_cos_th_77 sorry
  thus "ArgCOMPTRIGK1 (x *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
    using A2 complex1_th_46 sorry
qed "sorry"

mtheorem comptrig_th_39:
"ArgCOMPTRIGK1 \<one>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
  using comptrig_th_35 sorry

mtheorem comptrig_th_40:
"ArgCOMPTRIGK1 (<i>COMPLEX1K8) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have "<i>COMPLEX1K8 =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  thus "ArgCOMPTRIGK1 (<i>COMPLEX1K8) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
    using comptrig_th_37 sorry
qed

mtheorem comptrig_th_41:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ iff ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6) & (ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    show "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
    proof-
      have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 &  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI,rule conjMI)
        assume A2: "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
        then have A3: "ArgCOMPTRIGK1 z >XXREAL-0R4 0NUMBERSK6"
          using xxreal_1_th_4 sorry
        then have "z <>HIDDENR2 0NUMBERSK6"
          using comptrig_def_1 sorry
        then have A4: "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8) &  |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6"
          using comptrig_def_1 complex1_th_47 sorry
        have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
          using A2 sin_cos_th_81 sorry
        thus "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
          using A4 complex1_th_12 sorry
        have "ArgCOMPTRIGK1 z <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using A2 xxreal_1_th_4 sorry
        then have "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
          using comptrig_lm_2 xxreal_0_th_2 sorry
        then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
          using A3 xxreal_1_th_4 sorry
        then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
          using comptrig_th_7 sorry
        then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_def_17 sorry
        thus " not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
          using A4 complex1_th_12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
      and A6: "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
    have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    then have "z <>HIDDENR2 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A5 complex1_th_77 sorry
    then have A7: " |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6 & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_def_1 complex1_th_47 sorry
    then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using A6 complex1_th_12 sorry
    then have A8: "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_def_17 sorry
    have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using A5 A7 complex1_th_12 sorry
    then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_def_19 sorry
    then have A9: " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
      using comptrig_th_14 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z"
      using comptrig_th_34 sorry
    then have A10: "ArgCOMPTRIGK1 z >XXREAL-0R4 0NUMBERSK6"
      using A8 sin_cos_th_30 sorry
    have " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
      using A8 comptrig_th_10 sorry
    then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 ArgCOMPTRIGK1 z or PISIN-COSK29 >XXREAL-0R4 ArgCOMPTRIGK1 z & (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 ArgCOMPTRIGK1 z"
      using A1 A9 xxreal_1_th_1 sorry
    thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
      using A10 comptrig_lm_5 xxreal_0_th_2 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_42:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ iff ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6) & (ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
    proof-
      have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 &  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI,rule conjMI)
        assume A1: "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
        then have "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
          using xxreal_1_th_4 sorry
        then have A2: "ArgCOMPTRIGK1 z <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
          using comptrig_lm_5 xxreal_0_th_2 sorry
        have A3: "ArgCOMPTRIGK1 z >XXREAL-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using A1 xxreal_1_th_4 sorry
        then have "z <>HIDDENR2 0NUMBERSK6"
          using comptrig_def_1 sorry
        then have A4: "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8) &  |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6"
          using comptrig_def_1 complex1_th_47 sorry
        have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ArgCOMPTRIGK1 z"
          using A1 xxreal_1_th_4 sorry
        then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
          using A2 xxreal_1_th_4 sorry
        then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using comptrig_th_13 sorry
        then have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using sin_cos_def_19 sorry
        thus "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
          using A4 complex1_th_12 sorry
        have "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
          using A1 xxreal_1_th_4 sorry
        then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
          using A3 xxreal_1_th_4 sorry
        then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
          using comptrig_th_7 sorry
        then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_def_17 sorry
        thus " not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
          using A4 complex1_th_12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
      and A6: "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
    have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    then have "z <>HIDDENR2 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A5 complex1_th_77 sorry
    then have A7: " |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6 & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_def_1 complex1_th_47 sorry
    then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using A6 complex1_th_12 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_def_17 sorry
    then have A8: " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
      using comptrig_th_10 sorry
    have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using A5 A7 complex1_th_12 sorry
    then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using sin_cos_def_19 sorry
    then have " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .]"
      using comptrig_th_12 sorry
    then have A9: "ArgCOMPTRIGK1 z <XXREAL-0R3 -XCMPLX-0K4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or ArgCOMPTRIGK1 z >XXREAL-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_1_th_1 sorry
    have "ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    then have "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      using A8 xxreal_1_th_1 sorry
    thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
      using A9 comptrig_th_34 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_43:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ iff ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6) & (ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
    proof-
      have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 &  not ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
      proof(rule impI,rule conjMI)
        assume A1: "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
        then have "PISIN-COSK29 <XXREAL-0R3 ArgCOMPTRIGK1 z"
          using xxreal_1_th_4 sorry
        then have A2: "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ArgCOMPTRIGK1 z"
          using comptrig_lm_2 xxreal_0_th_2 sorry
        have A3: "ArgCOMPTRIGK1 z >XXREAL-0R4 PISIN-COSK29"
          using A1 xxreal_1_th_4 sorry
        then have "z <>HIDDENR2 0NUMBERSK6"
          using comptrig_def_1 sorry
        then have A4: "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8) &  |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6"
          using comptrig_def_1 complex1_th_47 sorry
        have "ArgCOMPTRIGK1 z <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
          using A1 xxreal_1_th_4 sorry
        then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
          using A2 xxreal_1_th_4 sorry
        then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using comptrig_th_13 sorry
        then have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using sin_cos_def_19 sorry
        thus "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
          using A4 complex1_th_12 sorry
        have "ArgCOMPTRIGK1 z <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
          using A1 xxreal_1_th_4 sorry
        then have "ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          using comptrig_lm_6 xxreal_0_th_2 sorry
        then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
          using A3 xxreal_1_th_4 sorry
        then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using comptrig_th_9 sorry
        then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using sin_cos_def_17 sorry
        thus " not ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
          using A4 complex1_th_12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
      and A6: "ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
    have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    then have "z <>HIDDENR2 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A5 complex1_th_77 sorry
    then have A7: " |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6 & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_def_1 complex1_th_47 sorry
    then have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using A5 complex1_th_12 sorry
    then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using sin_cos_def_19 sorry
    then have A8: " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .]"
      using comptrig_th_16 sorry
    have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using A6 A7 complex1_th_12 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using sin_cos_def_17 sorry
    then have A9: " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using comptrig_th_8 sorry
    have "ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    then have A10: "ArgCOMPTRIGK1 z <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using A8 xxreal_1_th_1 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z"
      using comptrig_th_34 sorry
    then have "ArgCOMPTRIGK1 z >XXREAL-0R4 PISIN-COSK29"
      using A9 xxreal_1_th_1 sorry
    thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      using A10 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_44:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ iff ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6) & (ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
    proof-
      have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[ implies ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 &  not ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
      proof(rule impI,rule conjMI)
        assume A1: "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
        then have A2: "ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          using xxreal_1_th_4 sorry
        have A3: "ArgCOMPTRIGK1 z >XXREAL-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
          using A1 xxreal_1_th_4 sorry
        then have "z <>HIDDENR2 0NUMBERSK6"
          using comptrig_def_1 sorry
        then have A4: "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8) &  |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6"
          using comptrig_def_1 complex1_th_47 sorry
        have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
          using A1 comptrig_th_15 sorry
        then have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
          using sin_cos_def_19 sorry
        thus "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
          using A4 complex1_th_12 sorry
        have "ArgCOMPTRIGK1 z >XXREAL-0R4 PISIN-COSK29"
          using A3 comptrig_lm_5 xxreal_0_th_2 sorry
        then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
          using A2 xxreal_1_th_4 sorry
        then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using comptrig_th_9 sorry
        then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
          using sin_cos_def_17 sorry
        thus " not ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
          using A4 complex1_th_12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
      and A6: "ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
    have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    then have "z <>HIDDENR2 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A5 complex1_th_77 sorry
    then have A7: " |.COMPLEX1K10 z.| >XXREAL-0R4 0NUMBERSK6 & z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_def_1 complex1_th_47 sorry
    then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using A6 complex1_th_12 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using sin_cos_def_17 sorry
    then have A8: " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 0NUMBERSK6,PISIN-COSK29 .]"
      using comptrig_th_8 sorry
    have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using A5 A7 complex1_th_12 sorry
    then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_def_19 sorry
    then have " not ArgCOMPTRIGK1 z inHIDDENR3 [.RCOMP-1K1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .]"
      using comptrig_th_14 sorry
    then have A9: "ArgCOMPTRIGK1 z <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or ArgCOMPTRIGK1 z >XXREAL-0R4 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_1 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z"
      using comptrig_th_34 sorry
    then have A10: "ArgCOMPTRIGK1 z >XXREAL-0R4 PISIN-COSK29"
      using A8 xxreal_1_th_1 sorry
    have "ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using A10 A9 comptrig_lm_2 xxreal_0_th_2 xxreal_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_45:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 implies  not sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6) or ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A1: "(ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 or ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6) or z =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    assume "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
    then have "(ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ or ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[) or ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 comptrig_th_37 comptrig_th_41 comptrig_th_42 sorry
    then have A2: "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 or 0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) or ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
      using xxreal_1_th_4 sorry
    then have "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      using comptrig_lm_2 xxreal_0_th_2 sorry
    then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using A2 xxreal_1_th_4 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using comptrig_th_7 sorry
    thus " not sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_46:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 implies  not sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6) or ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A1: "(ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 or ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6) or z =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    assume "ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6"
    then have "(ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[ or ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) or ArgCOMPTRIGK1 z =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using A1 comptrig_th_38 comptrig_th_43 comptrig_th_44 sorry
    then have "(PISIN-COSK29 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) or (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or ArgCOMPTRIGK1 z =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using xxreal_1_th_4 sorry
    then have "PISIN-COSK29 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_lm_5 comptrig_lm_6 xxreal_0_th_2 sorry
    then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .["
      using xxreal_1_th_4 sorry
    then have "(sinSIN-COSK17).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using comptrig_th_9 sorry
    thus " not sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using sin_cos_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_47:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) >=XXREAL-0R2 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  assume "ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
  then have "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 or ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
     sorry
  then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6 or z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) & (ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 or ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6)"
    using comptrig_th_45 complex1_th_13 sorry
  thus "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >=XXREAL-0R2 0NUMBERSK6"
    using comptrig_th_35 comptrig_th_36 sin_cos_th_31 sin_cos_th_77 sorry
qed "sorry"

mtheorem comptrig_th_48:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z <=XXREAL-0R1 0NUMBERSK6 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) <=XXREAL-0R1 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  assume "ImCOMPLEX1K4 z <=XXREAL-0R1 0NUMBERSK6"
  then have "ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 or ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
     sorry
  then have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6 or z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) & (ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 or ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6)"
    using comptrig_th_46 complex1_th_13 sorry
  thus "sinSIN-COSK18 (ArgCOMPTRIGK1 z) <=XXREAL-0R1 0NUMBERSK6"
    using comptrig_th_35 comptrig_th_36 sin_cos_th_31 sin_cos_th_77 sorry
qed "sorry"

mtheorem comptrig_th_49:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 implies  not cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 or ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6) or ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A1: "(ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 or ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6) or z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    assume "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
    then have "(ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ or ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29),\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) .[) or ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6"
      using A1 comptrig_th_35 comptrig_th_41 comptrig_th_44 sorry
    then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using comptrig_th_15 sin_cos_th_30 sin_cos_th_80 sorry
    thus " not cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_50:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 implies  not cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "(ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 or ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6) or ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A1: "(ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6 or ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6) or z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    assume "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
    then have "(ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ or ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 PISIN-COSK29,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .[) or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
      using A1 comptrig_th_36 comptrig_th_42 comptrig_th_43 sorry
    then have "((PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 or PISIN-COSK29 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
      using xxreal_1_th_4 sorry
    then have "(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_lm_2 comptrig_lm_5 xxreal_0_th_2 sorry
    then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,(\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) .["
      using xxreal_1_th_4 sorry
    then have "(cosSIN-COSK19).FUNCT-1K1 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using comptrig_th_13 sorry
    thus " not cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6"
      using sin_cos_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_51:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) >=XXREAL-0R2 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  assume "ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6"
  then have "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6"
     sorry
  then have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) & ((ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 or ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6) or ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6)"
    using comptrig_th_49 complex1_th_13 sorry
  thus "cosSIN-COSK20 (ArgCOMPTRIGK1 z) >=XXREAL-0R2 0NUMBERSK6"
    using comptrig_def_1 comptrig_th_37 comptrig_th_38 sin_cos_th_31 sin_cos_th_77 sorry
qed "sorry"

mtheorem comptrig_th_52:
" for z be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 z <=XXREAL-0R1 0NUMBERSK6 & z <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 z) <=XXREAL-0R1 0NUMBERSK6"
proof(rule ballI,rule impMI ,rule impI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  assume A1: "ReCOMPLEX1K3 z <=XXREAL-0R1 0NUMBERSK6"
    and A2: "z <>HIDDENR2 0NUMBERSK6"
  have A3: "0NUMBERSK6 =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  have "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6"
    using A1 sorry
  then have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) & (ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6 or ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6)"
    using comptrig_th_50 complex1_th_13 sorry
  then have "cosSIN-COSK20 (ArgCOMPTRIGK1 z) <XXREAL-0R3 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) & (ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 or ImCOMPLEX1K4 z <XXREAL-0R3 0NUMBERSK6)"
    using A2 A3 sorry
  thus "cosSIN-COSK20 (ArgCOMPTRIGK1 z) <=XXREAL-0R1 0NUMBERSK6"
    using comptrig_th_37 comptrig_th_38 sin_cos_th_77 sorry
qed "sorry"

mtheorem comptrig_th_53:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  let ?P = "\<lambda>Lamb1. (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 Lamb1 =COMPLEX1R1 cosSIN-COSK20 (Lamb1 *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (Lamb1 *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  have A1: " for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8) implies (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "?P(n)"
    then have "(cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8))"
      using newton_th_6 sorry
    also have "... = (((cosSIN-COSK20 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (cosSIN-COSK20 x) -XCMPLX-0K6 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK18 x))+XCMPLX-0K2 ((cosSIN-COSK20 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK18 x))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 ((cosSIN-COSK20 x)*XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 x)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    also have "... = (cosSIN-COSK20 (n *XCMPLX-0K3 x +XCMPLX-0K2 x) +XCMPLX-0K2 ((cosSIN-COSK20 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK18 x))*XCMPLX-0K3 (<i>COMPLEX1K8))+XCMPLX-0K2 ((cosSIN-COSK20 x)*XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 x)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_75 sorry
    also have "... = cosSIN-COSK20 (n *XCMPLX-0K3 x +XCMPLX-0K2 x) +XCMPLX-0K2 ((cosSIN-COSK20 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (sinSIN-COSK18 x) +XCMPLX-0K2 (cosSIN-COSK20 x)*XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 x)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    also have "... = cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_75 sorry
    finally have "(cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "(cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 cosSIN-COSK20 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  have A2: "?P(0NUMBERSK6)"
    using newton_th_4 sin_cos_th_31 sorry
  show " for n be NatNAT-1M1 holds (cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 (n *XCMPLX-0K3 x) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 x))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using nat_1_sch_2 A2 A1 sorry
qed "sorry"

mtheorem comptrig_th_54:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be NatNAT-1M1 holds z <>HIDDENR2 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6 implies z  |^NEWTONK1 n =COMPLEX1R1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be NatNAT-1M1 holds z <>HIDDENR2 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6 implies z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "z <>HIDDENR2 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
    show "z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    proof-
      have cases: "z <>HIDDENR2 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6 & n >XXREAL-0R4 0NUMBERSK6"
        using A1 sorry
      have case1: "z <>HIDDENR2 0NUMBERSK6 implies z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      proof(rule impI)
        assume "z <>HIDDENR2 0NUMBERSK6"
        then have "z  |^NEWTONK1 n =HIDDENR1 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using comptrig_def_1 sorry
        also have "... = (( |.COMPLEX1K10 z.| +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8))) |^NEWTONK1 n"
           sorry
        also have "... = ( |.COMPLEX1K10 z.| +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using newton_th_7 sorry
        also have "... = (( |.COMPLEX1K10 z.|) |^NEWTONK1 n +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8))"
          using comptrig_th_53 sorry
        also have "... = ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        finally show "z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
      qed
      have case2: "z =COMPLEX1R1 0NUMBERSK6 & n >XXREAL-0R4 0NUMBERSK6 implies z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      proof(rule impI)
        assume A2: "z =COMPLEX1R1 0NUMBERSK6 & n >XXREAL-0R4 0NUMBERSK6"
        then have A3: "n >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
          using nat_1_th_13 sorry
        then have "z  |^NEWTONK1 n =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 ((0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using A2 newton_th_11 sorry
        also have "... = (0NUMBERSK6)*XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using A2 A3 complex1_th_44 newton_th_11 sorry
        also have "... = ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using A2 A3 complex1_th_44 newton_th_11 sorry
        finally show "z  |^NEWTONK1 n =HIDDENR1 ( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|) |^NEWTONK1 n *XCMPLX-0K3 (sinSIN-COSK18 (n *XCMPLX-0K3 (ArgCOMPTRIGK1 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_55:
" for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =COMPLEX1R1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
    have "(cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 cosSIN-COSK20 (n *XCMPLX-0K3 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_th_53 sorry
    also have "... = cosSIN-COSK20 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK18 (n *XCMPLX-0K3 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 xcmplx_1_th_87 sorry
    also have "... = cosSIN-COSK20 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK18 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 xcmplx_1_th_87 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK18 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 (x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_10 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos2_th_11 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_17 sorry
    also have "... = cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_def_19 sorry
    finally show "(cosSIN-COSK20 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 cosSIN-COSK20 x +XCMPLX-0K2 (sinSIN-COSK18 x)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_56:
" for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies z =COMPLEX1R1 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
    then have A2: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    show "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
    proof-
      have cases: "z <>HIDDENR2 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "z <>HIDDENR2 0NUMBERSK6 implies (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
      proof(rule impI)
        assume A3: "z <>HIDDENR2 0NUMBERSK6"
        have "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 ((n -rootPOWERK1 ( |.COMPLEX1K10 z.|) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8))) |^NEWTONK1 n"
           sorry
        also have "... = (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n) +XCMPLX-0K2 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using newton_th_7 sorry
        also have "... = (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n *XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8))"
          using A1 comptrig_th_55 sorry
        also have "... = ( |.COMPLEX1K10 z.| +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8))*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z) +XCMPLX-0K2 (sinSIN-COSK18 (ArgCOMPTRIGK1 z))*XCMPLX-0K3 (<i>COMPLEX1K8))"
          using A1 comptrig_th_4 complex1_th_46 sorry
        also have "... = (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))+XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
           sorry
        also have "... = z"
          using A3 comptrig_def_1 sorry
        finally show "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
           sorry
      qed
      have case2: "z =COMPLEX1R1 0NUMBERSK6 implies (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
      proof(rule impI)
        assume A4: "z =COMPLEX1R1 0NUMBERSK6"
        then have "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 ((0NUMBERSK6)*XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 (0NUMBERSK6) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using A2 complex1_th_44 power_th_5 sorry
        also have "... = (0NUMBERSK6 +XCMPLX-0K2 ((0NUMBERSK6)*XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n"
          using A2 power_th_5 sorry
        also have "... = z"
          using A2 A4 newton_th_11 sorry
        finally show "(n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 z.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 z +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)) |^NEWTONK1 n =HIDDENR1 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef comptrig_def_2 ("CRootCOMPTRIGM1-of'( _ , _ ')" [0,0]70 ) where
  mlet "x be ComplexXCMPLX-0M1", "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
"mode CRootCOMPTRIGM1-of(n,x) \<rightarrow> ComplexXCMPLX-0M1 means
  (\<lambda>it. it  |^NEWTONK1 n =COMPLEX1R1 x)"
proof-
  (*existence*)
    show " ex it be ComplexXCMPLX-0M1 st it  |^NEWTONK1 n =COMPLEX1R1 x"
    proof-
      have " ex tVar11 be ComplexXCMPLX-0M1 st tVar11  |^NEWTONK1 n =COMPLEX1R1 x"
      proof-
        obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6))/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (0NUMBERSK6))/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
          using xcmplx_0_def_2 sorry
        show " ex tVar11 be ComplexXCMPLX-0M1 st tVar11  |^NEWTONK1 n =COMPLEX1R1 x"
        proof(rule bexI[of _ "z"])
          show "z  |^NEWTONK1 n =COMPLEX1R1 x"
            using comptrig_th_56 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem comptrig_th_57:
" for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for k be NatNAT-1M1 holds n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,x)"
proof(rule ballI,rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  obtain z where 
    [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and zDef:"z = n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_0_def_2 sorry
  have "z  |^NEWTONK1 n =COMPLEX1R1 x"
    using comptrig_th_56 sorry
  thus "n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (cosSIN-COSK20 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)) +XCMPLX-0K2 (n -rootPOWERK1 ( |.COMPLEX1K10 x.|) *XCMPLX-0K3 (sinSIN-COSK18 ((ArgCOMPTRIGK1 x +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k)/XCMPLX-0K7 n)))*XCMPLX-0K3 (<i>COMPLEX1K8) be CRootCOMPTRIGM1-of(n,x)"
    using comptrig_def_2 sorry
qed "sorry"

mtheorem comptrig_th_58:
" for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for v be CRootCOMPTRIGM1-of(\<one>\<^sub>M,x) holds v =COMPLEX1R1 x"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  fix v assume [ty]: "v be CRootCOMPTRIGM1-of(\<one>\<^sub>M,x)"
  have "v  |^NEWTONK1 \<one>\<^sub>M =COMPLEX1R1 x"
    using comptrig_def_2 sorry
  thus "v =COMPLEX1R1 x"
     sorry
qed "sorry"

mtheorem comptrig_th_59:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for v be CRootCOMPTRIGM1-of(n,0NUMBERSK6) holds v =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for v be CRootCOMPTRIGM1-of(n,0NUMBERSK6) holds v <>HIDDENR2 0NUMBERSK6 implies  not  True "
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix v assume [ty]: "v be CRootCOMPTRIGM1-of(n,0NUMBERSK6)"
    let ?P = "\<lambda>Lamb1. v  |^NEWTONK1 Lamb1 =COMPLEX1R1 0NUMBERSK6"
    assume A1: "v <>HIDDENR2 0NUMBERSK6"
    have A2: " for k be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds k <>HIDDENR2 \<one>\<^sub>M & v  |^NEWTONK1 k =COMPLEX1R1 0NUMBERSK6 implies ( ex t be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st t <XXREAL-0R3 k & v  |^NEWTONK1 t =COMPLEX1R1 0NUMBERSK6)"
    proof(rule ballI,rule impMI ,rule impI)
      fix k assume [ty]: "k be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
      assume A3: "k <>HIDDENR2 \<one>\<^sub>M"
        and A4: "?P(k)"
      obtain t where
        [ty]:"t be NatNAT-1M1" and 
        A5: "k =COMPLEX1R1 t +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_6 sorry
      have 
        [ty]:"t be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
        using A3 A5 sorry
      show " ex t be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st t <XXREAL-0R3 k & v  |^NEWTONK1 t =COMPLEX1R1 0NUMBERSK6"
      proof(rule bexI[of _ "t"],rule conjMI)
        show "t <XXREAL-0R3 k"
          using A5 nat_1_th_13 sorry
        have "v  |^NEWTONK1 k =COMPLEX1R1 v  |^NEWTONK1 t *XCMPLX-0K3 v"
          using A5 newton_th_6 sorry
        thus "v  |^NEWTONK1 t =COMPLEX1R1 0NUMBERSK6"
          using A1 A4 sorry
      qed "sorry"
    qed "sorry"
    have A6: " ex n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st ?P(n)"
    proof-
      have " ex tVar13 be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st v  |^NEWTONK1 tVar13 =COMPLEX1R1 0NUMBERSK6"
      proof-
        show " ex tVar13 be  non zeroORDINAL1V8\<bar>NatNAT-1M1 st v  |^NEWTONK1 tVar13 =COMPLEX1R1 0NUMBERSK6"
        proof(rule bexI[of _ "n"])
          show "v  |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
            using comptrig_def_2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    have "?P(\<one>\<^sub>M)"
      using comptrig_sch_1 A6 A2 sorry
    thus " not  True "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comptrig_th_60:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for v be CRootCOMPTRIGM1-of(n,x) holds v =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  fix v assume [ty]: "v be CRootCOMPTRIGM1-of(n,x)"
  assume "v =COMPLEX1R1 0NUMBERSK6"
  then have "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M & (0NUMBERSK6) |^NEWTONK1 n =COMPLEX1R1 x"
    using comptrig_def_2 nat_1_th_13 sorry
  thus "x =COMPLEX1R1 0NUMBERSK6"
    using newton_th_11 sorry
qed "sorry"

mtheorem comptrig_th_61:
" for a be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & cosSIN-COSK20 a =COMPLEX1R1 \<one>\<^sub>M implies a =COMPLEX1R1 0NUMBERSK6"
proof(rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  assume A1: "0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    and A2: "cosSIN-COSK20 a =COMPLEX1R1 \<one>\<^sub>M"
  have "\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 a) =COMPLEX1R1 \<one>\<^sub>M"
    using A2 sin_cos_th_29 sorry
  then have "sinSIN-COSK18 a =COMPLEX1R1 0NUMBERSK6"
     sorry
  thus "a =COMPLEX1R1 0NUMBERSK6"
    using A1 A2 comptrig_th_17 sin_cos_th_77 sorry
qed "sorry"

mtheorem comptrig_th_62:
" for z be ComplexXCMPLX-0M1 holds z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  show "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof-
    have cases: "z =COMPLEX1R1 0NUMBERSK6 or z <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "z =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    proof(rule impI)
      assume "z =COMPLEX1R1 0NUMBERSK6"
      thus "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using complex1_th_44 sorry
    qed
    have case2: "z <>HIDDENR2 0NUMBERSK6 implies z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    proof(rule impI)
      assume "z <>HIDDENR2 0NUMBERSK6"
      thus "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using comptrig_def_1 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

end
