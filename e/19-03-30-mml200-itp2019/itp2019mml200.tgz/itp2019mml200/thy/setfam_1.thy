theory setfam_1
  imports subset_1 xfamily
begin
(*begin*)
reserve X, Y, Z, Z1, Z2, D for "setHIDDENM2"
reserve x, y for "objectHIDDENM1"
mdef setfam_1_def_1 ("meetSETFAM-1K1  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func meetSETFAM-1K1 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y) if X <>HIDDENR2 {}XBOOLE-0K1 otherwise \<lambda>it. it =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  (*existence*)
    show "(X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y))) & ( not X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be setHIDDENM2 st it =XBOOLE-0R4 {}XBOOLE-0K1))"
    proof-
      have "(X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex Z1 be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Z1 iff ( for Z be setHIDDENM2 holds Z inTARSKIR2 X implies x inHIDDENR3 Z))) &  not (X <>HIDDENR2 {}XBOOLE-0K1 & ( for VarFor1 be setHIDDENM2 holds  not VarFor1 =XBOOLE-0R4 {}XBOOLE-0K1))"
      proof(rule conjMI)
        show "X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex Z1 be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 Z1 iff ( for Z be setHIDDENM2 holds Z inTARSKIR2 X implies x inHIDDENR3 Z))"
        proof-
          have "X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar1 &  not ( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 X &  not x inHIDDENR3 Z))) &  not (( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 X &  not x inHIDDENR3 Z)) &  not x inHIDDENR3 tVar1))"
          proof(rule impI)
            let ?X = "\<lambda>Lamb1.  for Z be setHIDDENM2 holds Z inTARSKIR2 X implies Lamb1 inHIDDENR3 Z"
            assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
            obtain Y where
              [ty]:"Y be setHIDDENM2" and 
              A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 unionTARSKIK3 X & ?X(x)"
              using xboole_0_sch_1 sorry
            show " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar1 &  not ( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 X &  not x inHIDDENR3 Z))) &  not (( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 X &  not x inHIDDENR3 Z)) &  not x inHIDDENR3 tVar1)"
            proof(rule bexI[of _ "Y"])
              have " for x be objectHIDDENM1 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 X implies x inHIDDENR3 Z) implies x inHIDDENR3 Y"
              proof(rule ballI,rule impI)
                let ?y = "the ElementSUBSET-1M1-of X"
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A3: " for Z be setHIDDENM2 holds Z inTARSKIR2 X implies x inHIDDENR3 Z"
                have "x inHIDDENR3 ?y"
                  using A1 A3 sorry
                then have "x inHIDDENR3 unionTARSKIK3 X"
                  using A1 tarski_def_4 sorry
                thus "x inHIDDENR3 Y"
                  using A2 A3 sorry
              qed "sorry"
              thus " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Y &  not ( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 X &  not x inHIDDENR3 Z))) &  not (( for Z be setHIDDENM2 holds  not (Z inTARSKIR2 X &  not x inHIDDENR3 Z)) &  not x inHIDDENR3 Y)"
                using A2 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show " not (X <>HIDDENR2 {}XBOOLE-0K1 & ( for VarFor1 be setHIDDENM2 holds  not VarFor1 =XBOOLE-0R4 {}XBOOLE-0K1))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds (X <>HIDDENR2 {}XBOOLE-0K1 implies (( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)) implies it1 =HIDDENR1 it2)) & ( not X <>HIDDENR2 {}XBOOLE-0K1 implies (it1 =XBOOLE-0R4 {}XBOOLE-0K1 & it2 =XBOOLE-0R4 {}XBOOLE-0K1 implies it1 =HIDDENR1 it2))"
    proof-
      have " for Z1 be setHIDDENM2 holds  for Z2 be setHIDDENM2 holds  not ((( not X <>HIDDENR2 {}XBOOLE-0K1 & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Z1 &  not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y))) &  not (( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y)) &  not x inHIDDENR3 Z1))) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Z2 &  not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y))) &  not (( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y)) &  not x inHIDDENR3 Z2))) &  not Z1 =HIDDENR1 Z2) &  not (((X <>HIDDENR2 {}XBOOLE-0K1 & Z1 =XBOOLE-0R4 {}XBOOLE-0K1) & Z2 =XBOOLE-0R4 {}XBOOLE-0K1) &  not Z1 =HIDDENR1 Z2)"
      proof(rule ballI,rule ballI)
        fix Z1 assume [ty]: "Z1 be setHIDDENM2"
        fix Z2 assume [ty]: "Z2 be setHIDDENM2"
        have "X <>HIDDENR2 {}XBOOLE-0K1 & (( for x be objectHIDDENM1 holds x inHIDDENR3 Z1 iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Z2 iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y))) implies Z1 =XBOOLE-0R4 Z2"
        proof(rule impMI ,rule impMI ,rule impI)
          assume "X <>HIDDENR2 {}XBOOLE-0K1"
            and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Z1 iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)"
            and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 Z2 iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Z1 iff x inHIDDENR3 Z2"
          proof(rule ballI)
            fix x assume [ty]: "x be objectHIDDENM1"
            have "x inHIDDENR3 Z1 iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)"
              using A4 sorry
            thus "x inHIDDENR3 Z1 iff x inHIDDENR3 Z2"
              using A5 sorry
          qed "sorry"
          thus "Z1 =XBOOLE-0R4 Z2"
            using tarski_th_2 sorry
        qed
        thus " not ((( not X <>HIDDENR2 {}XBOOLE-0K1 & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Z1 &  not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y))) &  not (( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y)) &  not x inHIDDENR3 Z1))) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Z2 &  not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y))) &  not (( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X &  not x inHIDDENR3 Y)) &  not x inHIDDENR3 Z2))) &  not Z1 =HIDDENR1 Z2) &  not (((X <>HIDDENR2 {}XBOOLE-0K1 & Z1 =XBOOLE-0R4 {}XBOOLE-0K1) & Z2 =XBOOLE-0R4 {}XBOOLE-0K1) &  not Z1 =HIDDENR1 Z2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem setfam_1_th_1:
"meetSETFAM-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 {}XBOOLE-0K1"
  using setfam_1_def_1 sorry

mtheorem setfam_1_th_2:
" for X be setHIDDENM2 holds meetSETFAM-1K1 X c=TARSKIR1 unionTARSKIK3 X"
proof-
  have " for X be setHIDDENM2 holds meetSETFAM-1K1 X c=TARSKIR1 unionTARSKIK3 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "X <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K1 X c=TARSKIR1 unionTARSKIK3 X"
    proof(rule impI)
      assume A2: "X <>HIDDENR2 {}XBOOLE-0K1"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 X implies x inHIDDENR3 unionTARSKIK3 X"
      proof(rule ballI,rule impI)
        let ?y = "the ElementSUBSET-1M1-of X"
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 meetSETFAM-1K1 X"
        then have "x inHIDDENR3 ?y"
          using A2 setfam_1_def_1 sorry
        thus "x inHIDDENR3 unionTARSKIK3 X"
          using A2 tarski_def_4 sorry
      qed "sorry"
      thus "meetSETFAM-1K1 X c=TARSKIR1 unionTARSKIK3 X"
         sorry
    qed
    have "X =XBOOLE-0R4 {}XBOOLE-0K1 implies meetSETFAM-1K1 X c=TARSKIR1 unionTARSKIK3 X"
      using setfam_1_def_1 sorry
    thus "meetSETFAM-1K1 X c=TARSKIR1 unionTARSKIK3 X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_3:
" for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z inTARSKIR2 X implies meetSETFAM-1K1 X c=TARSKIR1 Z"
  using setfam_1_def_1 sorry

mtheorem setfam_1_th_4:
" for X be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 X implies meetSETFAM-1K1 X =XBOOLE-0R4 {}XBOOLE-0K1"
  using setfam_1_th_3 xboole_1_th_3 sorry

mtheorem setfam_1_th_5:
" for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 X implies Z c=TARSKIR1 Z1) implies Z c=TARSKIR1 meetSETFAM-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Z be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 X implies Z c=TARSKIR1 Z1) implies Z c=TARSKIR1 meetSETFAM-1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 X implies Z c=TARSKIR1 Z1"
    show "Z c=TARSKIR1 meetSETFAM-1K1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Z implies x inHIDDENR3 meetSETFAM-1K1 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 Z"
        have " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume "Y inTARSKIR2 X"
          then have "Z c=TARSKIR1 Y"
            using A2 sorry
          thus "x inHIDDENR3 Y"
            using A3 sorry
        qed "sorry"
        thus "x inHIDDENR3 meetSETFAM-1K1 X"
          using A1 setfam_1_def_1 sorry
      qed "sorry"
      thus "Z c=TARSKIR1 meetSETFAM-1K1 X"
        using tarski_def_3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & X c=TARSKIR1 Y implies meetSETFAM-1K1 Y c=TARSKIR1 meetSETFAM-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & X c=TARSKIR1 Y implies meetSETFAM-1K1 Y c=TARSKIR1 meetSETFAM-1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 Y implies x inHIDDENR3 meetSETFAM-1K1 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 meetSETFAM-1K1 Y"
      then have " for Z be setHIDDENM2 holds Z inTARSKIR2 X implies x inHIDDENR3 Z"
        using A2 setfam_1_def_1 sorry
      thus "x inHIDDENR3 meetSETFAM-1K1 X"
        using A1 setfam_1_def_1 sorry
    qed "sorry"
    thus "meetSETFAM-1K1 Y c=TARSKIR1 meetSETFAM-1K1 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X inTARSKIR2 Y & X c=TARSKIR1 Z implies meetSETFAM-1K1 Y c=TARSKIR1 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X inTARSKIR2 Y & X c=TARSKIR1 Z implies meetSETFAM-1K1 Y c=TARSKIR1 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X inTARSKIR2 Y"
      and A2: "X c=TARSKIR1 Z"
    have "meetSETFAM-1K1 Y c=TARSKIR1 X"
      using A1 setfam_1_th_3 sorry
    thus "meetSETFAM-1K1 Y c=TARSKIR1 Z"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X inTARSKIR2 Y & X missesXBOOLE-0R1 Z implies meetSETFAM-1K1 Y missesXBOOLE-0R1 Z"
  using setfam_1_th_3 xboole_1_th_63 sorry

mtheorem setfam_1_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
    have A3: "meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y c=TARSKIR1 meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y implies x inHIDDENR3 meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y"
        then have A4: "x inHIDDENR3 meetSETFAM-1K1 X & x inHIDDENR3 meetSETFAM-1K1 Y"
          using xboole_0_def_4 sorry
        have " for Z be setHIDDENM2 holds Z inTARSKIR2 X \\/XBOOLE-0K2 Y implies x inHIDDENR3 Z"
        proof(rule ballI,rule impI)
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume "Z inTARSKIR2 X \\/XBOOLE-0K2 Y"
          then have "Z inTARSKIR2 X or Z inTARSKIR2 Y"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 Z"
            using A4 setfam_1_def_1 sorry
        qed "sorry"
        thus "x inHIDDENR3 meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y)"
          using A1 setfam_1_def_1 sorry
      qed "sorry"
      thus "meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y c=TARSKIR1 meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y)"
        using tarski_def_3 sorry
    qed
    have "meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 meetSETFAM-1K1 X & meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 meetSETFAM-1K1 Y"
      using A1 A2 setfam_1_th_6 xboole_1_th_7 sorry
    then have "meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y"
      using xboole_1_th_19 sorry
    thus "meetSETFAM-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 meetSETFAM-1K1 X /\\XBOOLE-0K3 meetSETFAM-1K1 Y"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_10:
" for X be setHIDDENM2 holds meetSETFAM-1K1 {TARSKIK1 X} =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds meetSETFAM-1K1 {TARSKIK1 X} =XBOOLE-0R4 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "X c=TARSKIR1 meetSETFAM-1K1 {TARSKIK1 X}"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 meetSETFAM-1K1 {TARSKIK1 X}"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 X"
        then have " for Z be setHIDDENM2 holds Z inTARSKIR2 {TARSKIK1 X} implies y inHIDDENR3 Z"
          using tarski_def_1 sorry
        thus "y inHIDDENR3 meetSETFAM-1K1 {TARSKIK1 X}"
          using setfam_1_def_1 sorry
      qed "sorry"
      thus "X c=TARSKIR1 meetSETFAM-1K1 {TARSKIK1 X}"
        using tarski_def_3 sorry
    qed
    have "X inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    then have "meetSETFAM-1K1 {TARSKIK1 X} c=TARSKIR1 X"
      using setfam_1_th_3 sorry
    thus "meetSETFAM-1K1 {TARSKIK1 X} =XBOOLE-0R4 X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds meetSETFAM-1K1 {TARSKIK2 X,Y } =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds meetSETFAM-1K1 {TARSKIK2 X,Y } =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "X inTARSKIR2 {TARSKIK2 X,Y } & Y inTARSKIR2 {TARSKIK2 X,Y }"
      using tarski_def_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 {TARSKIK2 X,Y } iff x inHIDDENR3 X & x inHIDDENR3 Y"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 meetSETFAM-1K1 {TARSKIK2 X,Y } implies x inHIDDENR3 X & x inHIDDENR3 Y) & (x inHIDDENR3 X & x inHIDDENR3 Y implies x inHIDDENR3 meetSETFAM-1K1 {TARSKIK2 X,Y })"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 meetSETFAM-1K1 {TARSKIK2 X,Y } implies x inHIDDENR3 X & x inHIDDENR3 Y"
          using A1 setfam_1_def_1 sorry
        assume "x inHIDDENR3 X & x inHIDDENR3 Y"
        then have " for Z be setHIDDENM2 holds Z inTARSKIR2 {TARSKIK2 X,Y } implies x inHIDDENR3 Z"
          using tarski_def_2 sorry
        thus "x inHIDDENR3 meetSETFAM-1K1 {TARSKIK2 X,Y }"
          using setfam_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "meetSETFAM-1K1 {TARSKIK2 X,Y } =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
      using xboole_0_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve SFX, SFY, SFZ for "setHIDDENM2"
mdef setfam_1_def_2 (" _ is-finer-thanSETFAM-1R1  _ " [50,50]50 ) where
  mlet "SFX be setHIDDENM2", "SFY be setHIDDENM2"
"pred SFX is-finer-thanSETFAM-1R1 SFY means
   for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFY & X c=TARSKIR1 Y)"..

mtheorem SETFAM_1R1_reflexivity:
" for SFY be setHIDDENM2 holds SFY is-finer-thanSETFAM-1R1 SFY"
proof-
  have " for SFY be setHIDDENM2 holds  for X be setHIDDENM2 holds X inTARSKIR2 SFY implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFY & X c=TARSKIR1 Y)"
     sorry
  thus " ?thesis "
    using setfam_1_def_2 sorry
qed

mdef setfam_1_def_3 (" _ is-coarser-thanSETFAM-1R2  _ " [50,50]50 ) where
  mlet "SFX be setHIDDENM2", "SFY be setHIDDENM2"
"pred SFY is-coarser-thanSETFAM-1R2 SFX means
   for Y be setHIDDENM2 holds Y inTARSKIR2 SFY implies ( ex X be setHIDDENM2 st X inTARSKIR2 SFX & X c=TARSKIR1 Y)"..

mtheorem SETFAM_1R2_reflexivity:
" for SFY be setHIDDENM2 holds SFY is-coarser-thanSETFAM-1R2 SFY"
proof-
  have " for SFY be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y inTARSKIR2 SFY implies ( ex X be setHIDDENM2 st X inTARSKIR2 SFY & X c=TARSKIR1 Y)"
     sorry
  thus " ?thesis "
    using setfam_1_def_3 sorry
qed

mtheorem setfam_1_th_12:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFX c=TARSKIR1 SFY implies SFX is-finer-thanSETFAM-1R1 SFY"
   sorry

mtheorem setfam_1_th_13:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFX is-finer-thanSETFAM-1R1 SFY implies unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 SFY"
proof-
  have " for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds  not (SFX is-finer-thanSETFAM-1R1 SFY &  not unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 SFY)"
  proof(rule ballI,rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    have "( for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFY & X c=TARSKIR1 Y)) implies unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 SFY"
    proof(rule impI)
      assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFY & X c=TARSKIR1 Y)"
      show "unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 SFY"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 SFX implies x inHIDDENR3 unionTARSKIK3 SFY"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 unionTARSKIK3 SFX"
          then obtain Y where
            [ty]:"Y be setHIDDENM2" and 
            A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 SFX"
            using tarski_def_4 sorry
          have " ex Z be setHIDDENM2 st Z inTARSKIR2 SFY & Y c=TARSKIR1 Z"
            using A1 A3 sorry
          thus "x inHIDDENR3 unionTARSKIK3 SFY"
            using A2 tarski_def_4 sorry
        qed "sorry"
        thus "unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 SFY"
          using tarski_def_3 sorry
      qed
    qed
    thus " not (SFX is-finer-thanSETFAM-1R1 SFY &  not unionTARSKIK3 SFX c=TARSKIR1 unionTARSKIK3 SFY)"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_14:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFY <>HIDDENR2 {}XBOOLE-0K1 & SFY is-coarser-thanSETFAM-1R2 SFX implies meetSETFAM-1K1 SFX c=TARSKIR1 meetSETFAM-1K1 SFY"
proof-
  have " for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds  not (( not SFY <>HIDDENR2 {}XBOOLE-0K1 & SFY is-coarser-thanSETFAM-1R2 SFX) &  not meetSETFAM-1K1 SFX c=TARSKIR1 meetSETFAM-1K1 SFY)"
  proof(rule ballI,rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    have "SFY <>HIDDENR2 {}XBOOLE-0K1 & ( for Z2 be setHIDDENM2 holds Z2 inTARSKIR2 SFY implies ( ex Z1 be setHIDDENM2 st Z1 inTARSKIR2 SFX & Z1 c=TARSKIR1 Z2)) implies meetSETFAM-1K1 SFX c=TARSKIR1 meetSETFAM-1K1 SFY"
    proof(rule impMI ,rule impI)
      assume A1: "SFY <>HIDDENR2 {}XBOOLE-0K1"
        and A2: " for Z2 be setHIDDENM2 holds Z2 inTARSKIR2 SFY implies ( ex Z1 be setHIDDENM2 st Z1 inTARSKIR2 SFX & Z1 c=TARSKIR1 Z2)"
      have "meetSETFAM-1K1 SFX c=TARSKIR1 meetSETFAM-1K1 SFY"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 SFX implies x inHIDDENR3 meetSETFAM-1K1 SFY"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 meetSETFAM-1K1 SFX"
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 SFY implies x inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume "Z inTARSKIR2 SFY"
            then obtain Z1 where
              [ty]:"Z1 be setHIDDENM2" and 
              A4: "Z1 inTARSKIR2 SFX"and A5: "Z1 c=TARSKIR1 Z"
              using A2 sorry
            have "x inHIDDENR3 Z1"
              using A3 A4 setfam_1_def_1 sorry
            thus "x inHIDDENR3 Z"
              using A5 sorry
          qed "sorry"
          thus "x inHIDDENR3 meetSETFAM-1K1 SFY"
            using A1 setfam_1_def_1 sorry
        qed "sorry"
        thus "meetSETFAM-1K1 SFX c=TARSKIR1 meetSETFAM-1K1 SFY"
          using tarski_def_3 sorry
      qed
      thus "meetSETFAM-1K1 SFX c=TARSKIR1 meetSETFAM-1K1 SFY"
         sorry
    qed
    thus " not (( not SFY <>HIDDENR2 {}XBOOLE-0K1 & SFY is-coarser-thanSETFAM-1R2 SFX) &  not meetSETFAM-1K1 SFX c=TARSKIR1 meetSETFAM-1K1 SFY)"
      using setfam_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_15:
" for SFX be setHIDDENM2 holds {}XBOOLE-0K1 is-finer-thanSETFAM-1R1 SFX"
   sorry

mtheorem setfam_1_th_16:
" for SFX be setHIDDENM2 holds SFX is-finer-thanSETFAM-1R1 {}XBOOLE-0K1 implies SFX =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for SFX be setHIDDENM2 holds  not (SFX is-finer-thanSETFAM-1R1 {}XBOOLE-0K1 &  not SFX =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    have "( for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 {}XBOOLE-0K1 & X c=TARSKIR1 Y)) implies ( not SFX =XBOOLE-0R4 {}XBOOLE-0K1 implies  False )"
    proof(rule impI,rule impI)
      assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 {}XBOOLE-0K1 & X c=TARSKIR1 Y)"
      let ?x = "the ElementSUBSET-1M1-of SFX"
      assume " not SFX =XBOOLE-0R4 {}XBOOLE-0K1"
      then have " ex Y be setHIDDENM2 st Y inTARSKIR2 {}XBOOLE-0K1 & ?x c=TARSKIR1 Y"
        using A1 sorry
      thus " False "
         sorry
    qed
    thus " not (SFX is-finer-thanSETFAM-1R1 {}XBOOLE-0K1 &  not SFX =XBOOLE-0R4 {}XBOOLE-0K1)"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_17:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds  for SFZ be setHIDDENM2 holds SFX is-finer-thanSETFAM-1R1 SFY & SFY is-finer-thanSETFAM-1R1 SFZ implies SFX is-finer-thanSETFAM-1R1 SFZ"
proof-
  have " for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds  for SFZ be setHIDDENM2 holds  not ((SFX is-finer-thanSETFAM-1R1 SFY & SFY is-finer-thanSETFAM-1R1 SFZ) &  not SFX is-finer-thanSETFAM-1R1 SFZ)"
  proof(rule ballI,rule ballI,rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    fix SFZ assume [ty]: "SFZ be setHIDDENM2"
    have "( for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFY & X c=TARSKIR1 Y)) & ( for X be setHIDDENM2 holds X inTARSKIR2 SFY implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFZ & X c=TARSKIR1 Y)) implies SFX is-finer-thanSETFAM-1R1 SFZ"
    proof(rule impMI ,rule impI)
      assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFY & X c=TARSKIR1 Y)"
        and A2: " for X be setHIDDENM2 holds X inTARSKIR2 SFY implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 SFZ & X c=TARSKIR1 Y)"
      have " for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex tVar2 be setHIDDENM2 st tVar2 inTARSKIR2 SFZ & X c=TARSKIR1 tVar2)"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        assume "X inTARSKIR2 SFX"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A3: "Y inTARSKIR2 SFY"and A4: "X c=TARSKIR1 Y"
          using A1 sorry
        obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A5: "Z inTARSKIR2 SFZ & Y c=TARSKIR1 Z"
          using A2 A3 sorry
        show " ex tVar2 be setHIDDENM2 st tVar2 inTARSKIR2 SFZ & X c=TARSKIR1 tVar2"
        proof(rule bexI[of _ "Z"])
          show "Z inTARSKIR2 SFZ & X c=TARSKIR1 Z"
            using A4 A5 sorry
        qed "sorry"
      qed "sorry"
      thus "SFX is-finer-thanSETFAM-1R1 SFZ"
        using setfam_1_def_2 sorry
    qed
    thus " not ((SFX is-finer-thanSETFAM-1R1 SFY & SFY is-finer-thanSETFAM-1R1 SFZ) &  not SFX is-finer-thanSETFAM-1R1 SFZ)"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_18:
" for Y be setHIDDENM2 holds  for SFX be setHIDDENM2 holds SFX is-finer-thanSETFAM-1R1 {TARSKIK1 Y} implies ( for X be setHIDDENM2 holds X inTARSKIR2 SFX implies X c=TARSKIR1 Y)"
proof-
  have " for Y be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  not (SFX is-finer-thanSETFAM-1R1 {TARSKIK1 Y} &  not ( for X be setHIDDENM2 holds  not (X inTARSKIR2 SFX &  not X c=TARSKIR1 Y)))"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    have "( for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Z be setHIDDENM2 st Z inTARSKIR2 {TARSKIK1 Y} & X c=TARSKIR1 Z)) implies ( for X be setHIDDENM2 holds X inTARSKIR2 SFX implies X c=TARSKIR1 Y)"
    proof(rule impI,rule ballI,rule impI)
      assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex Z be setHIDDENM2 st Z inTARSKIR2 {TARSKIK1 Y} & X c=TARSKIR1 Z)"
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 SFX"
      then have " ex Z be setHIDDENM2 st Z inTARSKIR2 {TARSKIK1 Y} & X c=TARSKIR1 Z"
        using A1 sorry
      thus "X c=TARSKIR1 Y"
        using tarski_def_1 sorry
    qed "sorry"
    thus " not (SFX is-finer-thanSETFAM-1R1 {TARSKIK1 Y} &  not ( for X be setHIDDENM2 holds  not (X inTARSKIR2 SFX &  not X c=TARSKIR1 Y)))"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for SFX be setHIDDENM2 holds SFX is-finer-thanSETFAM-1R1 {TARSKIK2 X,Y } implies ( for Z be setHIDDENM2 holds Z inTARSKIR2 SFX implies Z c=TARSKIR1 X or Z c=TARSKIR1 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  not (SFX is-finer-thanSETFAM-1R1 {TARSKIK2 X,Y } &  not ( for Z be setHIDDENM2 holds  not ((Z inTARSKIR2 SFX &  not Z c=TARSKIR1 X) &  not Z c=TARSKIR1 Y)))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    have "( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 SFX implies ( ex Z2 be setHIDDENM2 st Z2 inTARSKIR2 {TARSKIK2 X,Y } & Z1 c=TARSKIR1 Z2)) implies ( for Z be setHIDDENM2 holds Z inTARSKIR2 SFX implies  not ( not Z c=TARSKIR1 X &  not Z c=TARSKIR1 Y))"
    proof(rule impI,rule ballI,rule impI)
      assume A1: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 SFX implies ( ex Z2 be setHIDDENM2 st Z2 inTARSKIR2 {TARSKIK2 X,Y } & Z1 c=TARSKIR1 Z2)"
      fix Z assume [ty]: "Z be setHIDDENM2"
      assume "Z inTARSKIR2 SFX"
      then obtain Z2 where
        [ty]:"Z2 be setHIDDENM2" and 
        A2: "Z2 inTARSKIR2 {TARSKIK2 X,Y }"and A3: "Z c=TARSKIR1 Z2"
        using A1 sorry
      have "{TARSKIK2 X,Y } =XBOOLE-0R4 {TARSKIK1 X} \\/XBOOLE-0K2 {TARSKIK1 Y}"
        using enumset1_th_1 sorry
      then have "Z2 inTARSKIR2 {TARSKIK1 X} or Z2 inTARSKIR2 {TARSKIK1 Y}"
        using A2 xboole_0_def_3 sorry
      thus " not ( not Z c=TARSKIR1 X &  not Z c=TARSKIR1 Y)"
        using A3 tarski_def_1 sorry
    qed "sorry"
    thus " not (SFX is-finer-thanSETFAM-1R1 {TARSKIK2 X,Y } &  not ( for Z be setHIDDENM2 holds  not ((Z inTARSKIR2 SFX &  not Z c=TARSKIR1 X) &  not Z c=TARSKIR1 Y)))"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef setfam_1_def_4 ("UNIONSETFAM-1K2'( _ , _ ')" [0,0]164 ) where
  mlet "SFX be setHIDDENM2", "SFY be setHIDDENM2"
"func UNIONSETFAM-1K2(SFX,SFY) \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
    proof-
      have " ex tVar3 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar3 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) &  not Z inTARSKIR2 tVar3)"
      proof-
        let ?X = "\<lambda>Lamb1.  ex Z be setHIDDENM2 st Lamb1 =XBOOLE-0R4 Z & ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
        obtain XX where
          [ty]:"XX be setHIDDENM2" and 
          A1: " for x be setHIDDENM2 holds x inTARSKIR2 XX iff x inTARSKIR2 boolZFMISC-1K1 (unionTARSKIK3 SFX \\/XBOOLE-0K2 unionTARSKIK3 SFY) & ?X(x)"
          using xfamily_sch_1 sorry
        show " ex tVar3 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar3 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) &  not Z inTARSKIR2 tVar3)"
        proof(rule bexI[of _ "XX"])
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 XX iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
          proof-
            have " for Z be setHIDDENM2 holds  not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) &  not Z inTARSKIR2 XX)"
            proof(rule ballI)
              fix Z assume [ty]: "Z be setHIDDENM2"
              have A2: "( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y) implies Z inTARSKIR2 XX"
              proof(rule impI)
                assume Given: " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
                then obtain X Y where
                  [ty]:"X be setHIDDENM2" "Y be setHIDDENM2" and 
                  A3: "X inTARSKIR2 SFX & Y inTARSKIR2 SFY"and A4: "Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
                   sorry
                have "X c=TARSKIR1 unionTARSKIK3 SFX & Y c=TARSKIR1 unionTARSKIK3 SFY"
                  using A3 zfmisc_1_th_74 sorry
                then have "Z c=TARSKIR1 unionTARSKIK3 SFX \\/XBOOLE-0K2 unionTARSKIK3 SFY"
                  using A4 xboole_1_th_13 sorry
                thus "Z inTARSKIR2 XX"
                  using A1 A3 A4 sorry
              qed
              have "Z inTARSKIR2 XX implies ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
              proof(rule impI)
                assume "Z inTARSKIR2 XX"
                then have " ex Z1 be setHIDDENM2 st Z =XBOOLE-0R4 Z1 & ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z1 =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
                  using A1 sorry
                thus " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
                   sorry
              qed
              thus " not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) &  not Z inTARSKIR2 XX)"
                using A2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for Z be setHIDDENM2 holds  not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) &  not Z inTARSKIR2 XX)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 it1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 it2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for Z1 be setHIDDENM2 holds  for Z2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 Z2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) implies Z1 =HIDDENR1 Z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix Z1 assume [ty]: "Z1 be setHIDDENM2"
        fix Z2 assume [ty]: "Z2 be setHIDDENM2"
        assume A5: " for Z be setHIDDENM2 holds Z inTARSKIR2 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
          and A6: " for Z be setHIDDENM2 holds Z inTARSKIR2 Z2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
        have " for Z be objectHIDDENM1 holds Z inHIDDENR3 Z1 iff Z inHIDDENR3 Z2"
        proof(rule ballI)
          fix Z assume [ty]: "Z be objectHIDDENM1"
          have "Z inHIDDENR3 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =HIDDENR1 X \\/XBOOLE-0K2 Y)"
            using A5 sorry
          thus "Z inHIDDENR3 Z1 iff Z inHIDDENR3 Z2"
            using A6 sorry
        qed "sorry"
        thus "Z1 =HIDDENR1 Z2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem SETFAM_1K2_commutativity:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds UNIONSETFAM-1K2(SFX,SFY) =HIDDENR1 UNIONSETFAM-1K2(SFY,SFX)"
proof-
  have " for it be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds it =HIDDENR1 UNIONSETFAM-1K2(SFX,SFY) implies it =HIDDENR1 UNIONSETFAM-1K2(SFY,SFX)"
  proof-
    have " for it be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) implies ( for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFY & Y inTARSKIR2 SFX) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y))"
    proof-
      have " for SFZ be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 SFZ iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) implies ( for Z be setHIDDENM2 holds (Z inTARSKIR2 SFZ implies ( ex Y be setHIDDENM2 st  ex X be setHIDDENM2 st (Y inTARSKIR2 SFY & X inTARSKIR2 SFX) & Z =XBOOLE-0R4 Y \\/XBOOLE-0K2 X)) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFY & Y inTARSKIR2 SFX) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) &  not Z inTARSKIR2 SFZ))"
      proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule conjMI)
        fix SFZ assume [ty]: "SFZ be setHIDDENM2"
        fix SFX assume [ty]: "SFX be setHIDDENM2"
        fix SFY assume [ty]: "SFY be setHIDDENM2"
        assume A7: " for Z be setHIDDENM2 holds Z inTARSKIR2 SFZ iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)"
        fix Z assume [ty]: "Z be setHIDDENM2"
        show "Z inTARSKIR2 SFZ implies ( ex Y be setHIDDENM2 st  ex X be setHIDDENM2 st (Y inTARSKIR2 SFY & X inTARSKIR2 SFX) & Z =XBOOLE-0R4 Y \\/XBOOLE-0K2 X)"
        proof(rule impI)
          assume "Z inTARSKIR2 SFZ"
          then have " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
            using A7 sorry
          thus " ex Y be setHIDDENM2 st  ex X be setHIDDENM2 st (Y inTARSKIR2 SFY & X inTARSKIR2 SFX) & Z =XBOOLE-0R4 Y \\/XBOOLE-0K2 X"
             sorry
        qed
        show " not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFY & Y inTARSKIR2 SFX) & Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y)) &  not Z inTARSKIR2 SFZ)"
          using A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using setfam_1_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef setfam_1_def_5 ("INTERSECTIONSETFAM-1K3'( _ , _ ')" [0,0]164 ) where
  mlet "SFX be setHIDDENM2", "SFY be setHIDDENM2"
"func INTERSECTIONSETFAM-1K3(SFX,SFY) \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
    proof-
      have " ex tVar4 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar4 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) &  not Z inTARSKIR2 tVar4)"
      proof-
        let ?X = "\<lambda>Lamb1.  ex Z be setHIDDENM2 st Lamb1 =XBOOLE-0R4 Z & ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
        obtain XX where
          [ty]:"XX be setHIDDENM2" and 
          A8: " for x be setHIDDENM2 holds x inTARSKIR2 XX iff x inTARSKIR2 boolZFMISC-1K1 (unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY) & ?X(x)"
          using xfamily_sch_1 sorry
        show " ex tVar4 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar4 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) &  not Z inTARSKIR2 tVar4)"
        proof(rule bexI[of _ "XX"])
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 XX iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
          proof-
            have " for Z be setHIDDENM2 holds  not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) &  not Z inTARSKIR2 XX)"
            proof(rule ballI)
              fix Z assume [ty]: "Z be setHIDDENM2"
              have A9: "( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y) implies Z inTARSKIR2 XX"
              proof(rule impI)
                assume Given: " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
                then obtain X Y where
                  [ty]:"X be setHIDDENM2" "Y be setHIDDENM2" and 
                  A10: "X inTARSKIR2 SFX & Y inTARSKIR2 SFY"and A11: "Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
                   sorry
                have "X c=TARSKIR1 unionTARSKIK3 SFX & Y c=TARSKIR1 unionTARSKIK3 SFY"
                  using A10 zfmisc_1_th_74 sorry
                then have "Z c=TARSKIR1 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
                  using A11 xboole_1_th_27 sorry
                thus "Z inTARSKIR2 XX"
                  using A8 A10 A11 sorry
              qed
              have "Z inTARSKIR2 XX implies ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
              proof(rule impI)
                assume "Z inTARSKIR2 XX"
                then have " ex Z1 be setHIDDENM2 st Z =XBOOLE-0R4 Z1 & ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z1 =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
                  using A8 sorry
                thus " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
                   sorry
              qed
              thus " not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) &  not Z inTARSKIR2 XX)"
                using A9 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for Z be setHIDDENM2 holds  not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) &  not Z inTARSKIR2 XX)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 it1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 it2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for Z1 be setHIDDENM2 holds  for Z2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 Z2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) implies Z1 =HIDDENR1 Z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix Z1 assume [ty]: "Z1 be setHIDDENM2"
        fix Z2 assume [ty]: "Z2 be setHIDDENM2"
        assume A12: " for Z be setHIDDENM2 holds Z inTARSKIR2 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
          and A13: " for Z be setHIDDENM2 holds Z inTARSKIR2 Z2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
        have " for Z be objectHIDDENM1 holds Z inHIDDENR3 Z1 iff Z inHIDDENR3 Z2"
        proof(rule ballI)
          fix Z assume [ty]: "Z be objectHIDDENM1"
          have "Z inHIDDENR3 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =HIDDENR1 X /\\XBOOLE-0K3 Y)"
            using A12 sorry
          thus "Z inHIDDENR3 Z1 iff Z inHIDDENR3 Z2"
            using A13 sorry
        qed "sorry"
        thus "Z1 =HIDDENR1 Z2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem SETFAM_1K3_commutativity:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds INTERSECTIONSETFAM-1K3(SFX,SFY) =HIDDENR1 INTERSECTIONSETFAM-1K3(SFY,SFX)"
proof-
  have " for it be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds it =HIDDENR1 INTERSECTIONSETFAM-1K3(SFX,SFY) implies it =HIDDENR1 INTERSECTIONSETFAM-1K3(SFY,SFX)"
  proof-
    have " for it be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) implies ( for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFY & Y inTARSKIR2 SFX) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y))"
    proof-
      have " for SFZ be setHIDDENM2 holds  for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 SFZ iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) implies ( for Z be setHIDDENM2 holds (Z inTARSKIR2 SFZ implies ( ex Y be setHIDDENM2 st  ex X be setHIDDENM2 st (Y inTARSKIR2 SFY & X inTARSKIR2 SFX) & Z =XBOOLE-0R4 Y /\\XBOOLE-0K3 X)) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFY & Y inTARSKIR2 SFX) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) &  not Z inTARSKIR2 SFZ))"
      proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule conjMI)
        fix SFZ assume [ty]: "SFZ be setHIDDENM2"
        fix SFX assume [ty]: "SFX be setHIDDENM2"
        fix SFY assume [ty]: "SFY be setHIDDENM2"
        assume A14: " for Z be setHIDDENM2 holds Z inTARSKIR2 SFZ iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)"
        fix Z assume [ty]: "Z be setHIDDENM2"
        show "Z inTARSKIR2 SFZ implies ( ex Y be setHIDDENM2 st  ex X be setHIDDENM2 st (Y inTARSKIR2 SFY & X inTARSKIR2 SFX) & Z =XBOOLE-0R4 Y /\\XBOOLE-0K3 X)"
        proof(rule impI)
          assume "Z inTARSKIR2 SFZ"
          then have " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
            using A14 sorry
          thus " ex Y be setHIDDENM2 st  ex X be setHIDDENM2 st (Y inTARSKIR2 SFY & X inTARSKIR2 SFX) & Z =XBOOLE-0R4 Y /\\XBOOLE-0K3 X"
             sorry
        qed
        show " not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFY & Y inTARSKIR2 SFX) & Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y)) &  not Z inTARSKIR2 SFZ)"
          using A14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using setfam_1_def_5 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef setfam_1_def_6 ("DIFFERENCESETFAM-1K4'( _ , _ ')" [0,0]164 ) where
  mlet "SFX be setHIDDENM2", "SFY be setHIDDENM2"
"func DIFFERENCESETFAM-1K4(SFX,SFY) \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for Z be setHIDDENM2 holds Z inTARSKIR2 it iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
    proof-
      have " ex tVar5 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar5 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) &  not Z inTARSKIR2 tVar5)"
      proof-
        let ?X = "\<lambda>Lamb1.  ex Z be setHIDDENM2 st Lamb1 =XBOOLE-0R4 Z & ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
        obtain XX where
          [ty]:"XX be setHIDDENM2" and 
          A15: " for x be setHIDDENM2 holds x inTARSKIR2 XX iff x inTARSKIR2 boolZFMISC-1K1 (unionTARSKIK3 SFX) & ?X(x)"
          using xfamily_sch_1 sorry
        show " ex tVar5 be setHIDDENM2 st  for Z be setHIDDENM2 holds  not (Z inTARSKIR2 tVar5 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) &  not Z inTARSKIR2 tVar5)"
        proof(rule bexI[of _ "XX"])
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 XX iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
          proof-
            have " for Z be setHIDDENM2 holds  not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) &  not Z inTARSKIR2 XX)"
            proof(rule ballI)
              fix Z assume [ty]: "Z be setHIDDENM2"
              have A16: "( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y) implies Z inTARSKIR2 XX"
              proof(rule impI)
                assume Given: " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y"
                then obtain X Y where
                  [ty]:"X be setHIDDENM2" "Y be setHIDDENM2" and 
                  A17: "X inTARSKIR2 SFX"and A18: "Y inTARSKIR2 SFY"and A19: "Z =XBOOLE-0R4 X \\SUBSET-1K6 Y"
                   sorry
                have "X c=TARSKIR1 unionTARSKIK3 SFX"
                  using A17 zfmisc_1_th_74 sorry
                then have "Z c=TARSKIR1 unionTARSKIK3 SFX"
                  using A19 sorry
                thus "Z inTARSKIR2 XX"
                  using A15 A17 A18 A19 sorry
              qed
              have "Z inTARSKIR2 XX implies ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
              proof(rule impI)
                assume "Z inTARSKIR2 XX"
                then have " ex Z1 be setHIDDENM2 st Z =XBOOLE-0R4 Z1 & ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z1 =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
                  using A15 sorry
                thus " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y"
                   sorry
              qed
              thus " not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) &  not Z inTARSKIR2 XX)"
                using A16 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for Z be setHIDDENM2 holds  not (Z inTARSKIR2 XX & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y))) &  not ( not ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) &  not Z inTARSKIR2 XX)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 it1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 it2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for Z1 be setHIDDENM2 holds  for Z2 be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) & ( for Z be setHIDDENM2 holds Z inTARSKIR2 Z2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)) implies Z1 =HIDDENR1 Z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix Z1 assume [ty]: "Z1 be setHIDDENM2"
        fix Z2 assume [ty]: "Z2 be setHIDDENM2"
        assume A20: " for Z be setHIDDENM2 holds Z inTARSKIR2 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
          and A21: " for Z be setHIDDENM2 holds Z inTARSKIR2 Z2 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =XBOOLE-0R4 X \\SUBSET-1K6 Y)"
        have " for Z be objectHIDDENM1 holds Z inHIDDENR3 Z1 iff Z inHIDDENR3 Z2"
        proof(rule ballI)
          fix Z assume [ty]: "Z be objectHIDDENM1"
          have "Z inHIDDENR3 Z1 iff ( ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & Z =HIDDENR1 X \\SUBSET-1K6 Y)"
            using A20 sorry
          thus "Z inHIDDENR3 Z1 iff Z inHIDDENR3 Z2"
            using A21 sorry
        qed "sorry"
        thus "Z1 =HIDDENR1 Z2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem setfam_1_th_20:
" for SFX be setHIDDENM2 holds SFX is-finer-thanSETFAM-1R1 UNIONSETFAM-1K2(SFX,SFX)"
proof-
  have " for SFX be setHIDDENM2 holds SFX is-finer-thanSETFAM-1R1 UNIONSETFAM-1K2(SFX,SFX)"
  proof(rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    have " for X be setHIDDENM2 holds X inTARSKIR2 SFX implies ( ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 UNIONSETFAM-1K2(SFX,SFX) & tVar6 c=TARSKIR1 tVar6)"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume A1: "X inTARSKIR2 SFX"
      show " ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 UNIONSETFAM-1K2(SFX,SFX) & tVar6 c=TARSKIR1 tVar6"
      proof(rule bexI[of _ "X"])
        have "X =XBOOLE-0R4 X \\/XBOOLE-0K2 X"
           sorry
        thus "X inTARSKIR2 UNIONSETFAM-1K2(SFX,SFX) & X c=TARSKIR1 X"
          using A1 setfam_1_def_4 sorry
      qed "sorry"
    qed "sorry"
    thus "SFX is-finer-thanSETFAM-1R1 UNIONSETFAM-1K2(SFX,SFX)"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_21:
" for SFX be setHIDDENM2 holds INTERSECTIONSETFAM-1K3(SFX,SFX) is-finer-thanSETFAM-1R1 SFX"
proof-
  have " for SFX be setHIDDENM2 holds INTERSECTIONSETFAM-1K3(SFX,SFX) is-finer-thanSETFAM-1R1 SFX"
  proof(rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    have " for X be setHIDDENM2 holds X inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFX) implies ( ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 SFX & X c=TARSKIR1 tVar7)"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFX)"
      then obtain Z1 Z2 where
        [ty]:"Z1 be setHIDDENM2" "Z2 be setHIDDENM2" and 
        A1: "Z1 inTARSKIR2 SFX"and "Z2 inTARSKIR2 SFX"and A2: "X =XBOOLE-0R4 Z1 /\\XBOOLE-0K3 Z2"
        using setfam_1_def_5 sorry
      show " ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 SFX & X c=TARSKIR1 tVar7"
      proof(rule bexI[of _ "Z1"])
        show "Z1 inTARSKIR2 SFX & X c=TARSKIR1 Z1"
          using A1 A2 xboole_1_th_17 sorry
      qed "sorry"
    qed "sorry"
    thus "INTERSECTIONSETFAM-1K3(SFX,SFX) is-finer-thanSETFAM-1R1 SFX"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_22:
" for SFX be setHIDDENM2 holds DIFFERENCESETFAM-1K4(SFX,SFX) is-finer-thanSETFAM-1R1 SFX"
proof-
  have " for SFX be setHIDDENM2 holds DIFFERENCESETFAM-1K4(SFX,SFX) is-finer-thanSETFAM-1R1 SFX"
  proof(rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    have " for X be setHIDDENM2 holds X inTARSKIR2 DIFFERENCESETFAM-1K4(SFX,SFX) implies ( ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 SFX & X c=TARSKIR1 tVar8)"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 DIFFERENCESETFAM-1K4(SFX,SFX)"
      then obtain Z1 Z2 where
        [ty]:"Z1 be setHIDDENM2" "Z2 be setHIDDENM2" and 
        A1: "Z1 inTARSKIR2 SFX"and "Z2 inTARSKIR2 SFX"and A2: "X =XBOOLE-0R4 Z1 \\SUBSET-1K6 Z2"
        using setfam_1_def_6 sorry
      show " ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 SFX & X c=TARSKIR1 tVar8"
      proof(rule bexI[of _ "Z1"])
        show "Z1 inTARSKIR2 SFX & X c=TARSKIR1 Z1"
          using A1 A2 sorry
      qed "sorry"
    qed "sorry"
    thus "DIFFERENCESETFAM-1K4(SFX,SFX) is-finer-thanSETFAM-1R1 SFX"
      using setfam_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_23:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFX meetsXBOOLE-0R5 SFY implies meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
proof-
  have " for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds  not ( not SFX meetsXBOOLE-0R5 SFY &  not meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY)))"
  proof(rule ballI,rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    let ?y = "the ElementSUBSET-1M1-of SFX /\\XBOOLE-0K3 SFY"
    have "SFX /\\XBOOLE-0K3 SFY <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
    proof(rule impI)
      assume A1: "SFX /\\XBOOLE-0K3 SFY <>HIDDENR2 {}XBOOLE-0K1"
      then have A2: "SFY <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have A3: "?y inTARSKIR2 SFX"
        using A1 xboole_0_def_4 sorry
      have A4: "?y inTARSKIR2 SFY"
        using A1 xboole_0_def_4 sorry
      have A5: "SFX <>HIDDENR2 {}XBOOLE-0K1"
        using A1 sorry
      have A6: "meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY)) implies x inHIDDENR3 meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A7: "x inHIDDENR3 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 SFY implies x inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume "Z inTARSKIR2 SFY"
            then have "?y /\\XBOOLE-0K3 Z inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFY)"
              using A3 setfam_1_def_5 sorry
            then have "x inHIDDENR3 ?y /\\XBOOLE-0K3 Z"
              using A7 setfam_1_def_1 sorry
            thus "x inHIDDENR3 Z"
              using xboole_0_def_4 sorry
          qed "sorry"
          then have A8: "x inHIDDENR3 meetSETFAM-1K1 SFY"
            using A2 setfam_1_def_1 sorry
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 SFX implies x inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume "Z inTARSKIR2 SFX"
            then have "Z /\\XBOOLE-0K3 ?y inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFY)"
              using A4 setfam_1_def_5 sorry
            then have "x inHIDDENR3 Z /\\XBOOLE-0K3 ?y"
              using A7 setfam_1_def_1 sorry
            thus "x inHIDDENR3 Z"
              using xboole_0_def_4 sorry
          qed "sorry"
          then have "x inHIDDENR3 meetSETFAM-1K1 SFX"
            using A5 setfam_1_def_1 sorry
          thus "x inHIDDENR3 meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY"
            using A8 xboole_0_def_4 sorry
        qed "sorry"
        thus "meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY"
          using tarski_def_3 sorry
      qed
      have A9: "?y /\\XBOOLE-0K3 ?y inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFY)"
        using A3 A4 setfam_1_def_5 sorry
      have "meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY c=TARSKIR1 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY implies x inHIDDENR3 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY"
          then have A10: "x inHIDDENR3 meetSETFAM-1K1 SFX & x inHIDDENR3 meetSETFAM-1K1 SFY"
            using xboole_0_def_4 sorry
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFY) implies x inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume "Z inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFY)"
            then obtain Z1 Z2 where
              [ty]:"Z1 be setHIDDENM2" "Z2 be setHIDDENM2" and 
              A11: "Z1 inTARSKIR2 SFX & Z2 inTARSKIR2 SFY"and A12: "Z =XBOOLE-0R4 Z1 /\\XBOOLE-0K3 Z2"
              using setfam_1_def_5 sorry
            have "x inHIDDENR3 Z1 & x inHIDDENR3 Z2"
              using A10 A11 setfam_1_def_1 sorry
            thus "x inHIDDENR3 Z"
              using A12 xboole_0_def_4 sorry
          qed "sorry"
          thus "x inHIDDENR3 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
            using A9 setfam_1_def_1 sorry
        qed "sorry"
        thus "meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY c=TARSKIR1 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
          using tarski_def_3 sorry
      qed
      thus "meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
        using A6 sorry
    qed
    thus " not ( not SFX meetsXBOOLE-0R5 SFY &  not meetSETFAM-1K1 SFX /\\XBOOLE-0K3 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (INTERSECTIONSETFAM-1K3(SFX,SFY)))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_24:
" for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFY <>HIDDENR2 {}XBOOLE-0K1 implies X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
proof-
  have " for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFY <>HIDDENR2 {}XBOOLE-0K1 implies X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    assume A1: "SFY <>HIDDENR2 {}XBOOLE-0K1"
    let ?y = "the ElementSUBSET-1M1-of SFY"
    have "X inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    then have A2: "X \\/XBOOLE-0K2 ?y inTARSKIR2 UNIONSETFAM-1K2({TARSKIK1 X},SFY)"
      using A1 setfam_1_def_4 sorry
    have A3: "X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY c=TARSKIR1 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY implies x inHIDDENR3 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY"
        then have A4: "x inHIDDENR3 X or x inHIDDENR3 meetSETFAM-1K1 SFY"
          using xboole_0_def_3 sorry
        have " for Z be setHIDDENM2 holds Z inTARSKIR2 UNIONSETFAM-1K2({TARSKIK1 X},SFY) implies x inHIDDENR3 Z"
        proof(rule ballI,rule impI)
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume "Z inTARSKIR2 UNIONSETFAM-1K2({TARSKIK1 X},SFY)"
          then obtain Z1 Z2 where
            [ty]:"Z1 be setHIDDENM2" "Z2 be setHIDDENM2" and 
            A5: "Z1 inTARSKIR2 {TARSKIK1 X} & Z2 inTARSKIR2 SFY"and A6: "Z =XBOOLE-0R4 Z1 \\/XBOOLE-0K2 Z2"
            using setfam_1_def_4 sorry
          have "x inHIDDENR3 Z1 or x inHIDDENR3 Z2"
            using A4 A5 setfam_1_def_1 tarski_def_1 sorry
          thus "x inHIDDENR3 Z"
            using A6 xboole_0_def_3 sorry
        qed "sorry"
        thus "x inHIDDENR3 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
          using A2 setfam_1_def_1 sorry
      qed "sorry"
      thus "X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY c=TARSKIR1 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
        using tarski_def_3 sorry
    qed
    have "meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY)) c=TARSKIR1 X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY)) implies ( not x inHIDDENR3 X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A7: "x inHIDDENR3 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
        assume A8: " not x inHIDDENR3 X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY"
        then have A9: " not x inHIDDENR3 X"
          using xboole_0_def_3 sorry
        have " not x inHIDDENR3 meetSETFAM-1K1 SFY"
          using A8 xboole_0_def_3 sorry
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A10: "Z inTARSKIR2 SFY"and A11: " not x inHIDDENR3 Z"
          using A1 setfam_1_def_1 sorry
        have "X inTARSKIR2 {TARSKIK1 X}"
          using tarski_def_1 sorry
        then have "X \\/XBOOLE-0K2 Z inTARSKIR2 UNIONSETFAM-1K2({TARSKIK1 X},SFY)"
          using A10 setfam_1_def_4 sorry
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Z"
          using A7 setfam_1_def_1 sorry
        thus " False "
          using A9 A11 xboole_0_def_3 sorry
      qed "sorry"
      thus "meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY)) c=TARSKIR1 X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY"
        using tarski_def_3 sorry
    qed
    thus "X \\/XBOOLE-0K2 meetSETFAM-1K1 SFY =XBOOLE-0R4 meetSETFAM-1K1 (UNIONSETFAM-1K2({TARSKIK1 X},SFY))"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_25:
" for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds X /\\XBOOLE-0K3 unionTARSKIK3 SFY =XBOOLE-0R4 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
proof-
  have " for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds X /\\XBOOLE-0K3 unionTARSKIK3 SFY =XBOOLE-0R4 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    have A1: "unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY)) c=TARSKIR1 X /\\XBOOLE-0K3 unionTARSKIK3 SFY"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY)) implies x inHIDDENR3 X /\\XBOOLE-0K3 unionTARSKIK3 SFY"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A2: "x inHIDDENR3 Z"and A3: "Z inTARSKIR2 INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY)"
          using tarski_def_4 sorry
        obtain X1 X2 where
          [ty]:"X1 be setHIDDENM2" "X2 be setHIDDENM2" and 
          A4: "X1 inTARSKIR2 {TARSKIK1 X}"and A5: "X2 inTARSKIR2 SFY"and A6: "Z =XBOOLE-0R4 X1 /\\XBOOLE-0K3 X2"
          using A3 setfam_1_def_5 sorry
        have "x inHIDDENR3 X2"
          using A2 A6 xboole_0_def_4 sorry
        then have A7: "x inHIDDENR3 unionTARSKIK3 SFY"
          using A5 tarski_def_4 sorry
        have "X1 =XBOOLE-0R4 X"
          using A4 tarski_def_1 sorry
        then have "x inHIDDENR3 X"
          using A2 A6 xboole_0_def_4 sorry
        thus "x inHIDDENR3 X /\\XBOOLE-0K3 unionTARSKIK3 SFY"
          using A7 xboole_0_def_4 sorry
      qed "sorry"
      thus "unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY)) c=TARSKIR1 X /\\XBOOLE-0K3 unionTARSKIK3 SFY"
        using tarski_def_3 sorry
    qed
    have "X /\\XBOOLE-0K3 unionTARSKIK3 SFY c=TARSKIR1 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 unionTARSKIK3 SFY implies x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A8: "x inHIDDENR3 X /\\XBOOLE-0K3 unionTARSKIK3 SFY"
        then have "x inHIDDENR3 unionTARSKIK3 SFY"
          using xboole_0_def_4 sorry
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A9: "x inHIDDENR3 Y"and A10: "Y inTARSKIR2 SFY"
          using tarski_def_4 sorry
        have "x inHIDDENR3 X"
          using A8 xboole_0_def_4 sorry
        then have A11: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using A9 xboole_0_def_4 sorry
        have "X inTARSKIR2 {TARSKIK1 X}"
          using tarski_def_1 sorry
        then have "X /\\XBOOLE-0K3 Y inTARSKIR2 INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY)"
          using A10 setfam_1_def_5 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
          using A11 tarski_def_4 sorry
      qed "sorry"
      thus "X /\\XBOOLE-0K3 unionTARSKIK3 SFY c=TARSKIR1 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
        using tarski_def_3 sorry
    qed
    thus "X /\\XBOOLE-0K3 unionTARSKIK3 SFY =XBOOLE-0R4 unionTARSKIK3 (INTERSECTIONSETFAM-1K3({TARSKIK1 X},SFY))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_26:
" for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFY <>HIDDENR2 {}XBOOLE-0K1 implies X \\SUBSET-1K6 unionTARSKIK3 SFY =XBOOLE-0R4 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
proof-
  have " for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFY <>HIDDENR2 {}XBOOLE-0K1 implies X \\SUBSET-1K6 unionTARSKIK3 SFY =XBOOLE-0R4 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    let ?y = "the ElementSUBSET-1M1-of SFY"
    have A1: "X inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    assume "SFY <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "X \\SUBSET-1K6 ?y inTARSKIR2 DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)"
      using A1 setfam_1_def_6 sorry
    have A3: "meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)) c=TARSKIR1 X \\SUBSET-1K6 unionTARSKIK3 SFY"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)) implies x inHIDDENR3 X \\SUBSET-1K6 unionTARSKIK3 SFY"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
        have " for Z be setHIDDENM2 holds Z inTARSKIR2 SFY implies  not x inHIDDENR3 Z"
        proof(rule ballI,rule impI)
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume "Z inTARSKIR2 SFY"
          then have "X \\SUBSET-1K6 Z inTARSKIR2 DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)"
            using A1 setfam_1_def_6 sorry
          then have "x inHIDDENR3 X \\SUBSET-1K6 Z"
            using A4 setfam_1_def_1 sorry
          thus " not x inHIDDENR3 Z"
            using xboole_0_def_5 sorry
        qed "sorry"
        then have " for Z be setHIDDENM2 holds x inHIDDENR3 Z implies  not Z inTARSKIR2 SFY"
           sorry
        then have A5: " not x inHIDDENR3 unionTARSKIK3 SFY"
          using tarski_def_4 sorry
        have "x inHIDDENR3 X \\SUBSET-1K6 ?y"
          using A2 A4 setfam_1_def_1 sorry
        thus "x inHIDDENR3 X \\SUBSET-1K6 unionTARSKIK3 SFY"
          using A5 xboole_0_def_5 sorry
      qed "sorry"
      thus "meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)) c=TARSKIR1 X \\SUBSET-1K6 unionTARSKIK3 SFY"
        using tarski_def_3 sorry
    qed
    have "X \\SUBSET-1K6 unionTARSKIK3 SFY c=TARSKIR1 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\SUBSET-1K6 unionTARSKIK3 SFY implies x inHIDDENR3 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\SUBSET-1K6 unionTARSKIK3 SFY"
        then have A6: "x inHIDDENR3 X &  not x inHIDDENR3 unionTARSKIK3 SFY"
          using xboole_0_def_5 sorry
        have " for Z be setHIDDENM2 holds Z inTARSKIR2 DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY) implies x inHIDDENR3 Z"
        proof(rule ballI,rule impI)
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume "Z inTARSKIR2 DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)"
          then obtain Z1 Z2 where
            [ty]:"Z1 be setHIDDENM2" "Z2 be setHIDDENM2" and 
            A7: "Z1 inTARSKIR2 {TARSKIK1 X} & Z2 inTARSKIR2 SFY"and A8: "Z =XBOOLE-0R4 Z1 \\SUBSET-1K6 Z2"
            using setfam_1_def_6 sorry
          have "x inHIDDENR3 Z1 &  not x inHIDDENR3 Z2"
            using A6 A7 tarski_def_1 tarski_def_4 sorry
          thus "x inHIDDENR3 Z"
            using A8 xboole_0_def_5 sorry
        qed "sorry"
        thus "x inHIDDENR3 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
          using A2 setfam_1_def_1 sorry
      qed "sorry"
      thus "X \\SUBSET-1K6 unionTARSKIK3 SFY c=TARSKIR1 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
        using tarski_def_3 sorry
    qed
    thus "X \\SUBSET-1K6 unionTARSKIK3 SFY =XBOOLE-0R4 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_27:
" for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFY <>HIDDENR2 {}XBOOLE-0K1 implies X \\SUBSET-1K6 meetSETFAM-1K1 SFY =XBOOLE-0R4 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
proof-
  have " for X be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFY <>HIDDENR2 {}XBOOLE-0K1 implies X \\SUBSET-1K6 meetSETFAM-1K1 SFY =XBOOLE-0R4 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    have A1: "X inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    have A2: "unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)) c=TARSKIR1 X \\SUBSET-1K6 meetSETFAM-1K1 SFY"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)) implies x inHIDDENR3 X \\SUBSET-1K6 meetSETFAM-1K1 SFY"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A3: "x inHIDDENR3 Z"and A4: "Z inTARSKIR2 DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)"
          using tarski_def_4 sorry
        obtain Z1 Z2 where
          [ty]:"Z1 be setHIDDENM2" "Z2 be setHIDDENM2" and 
          A5: "Z1 inTARSKIR2 {TARSKIK1 X}"and A6: "Z2 inTARSKIR2 SFY"and A7: "Z =XBOOLE-0R4 Z1 \\SUBSET-1K6 Z2"
          using A4 setfam_1_def_6 sorry
        have " not x inHIDDENR3 Z2"
          using A3 A7 xboole_0_def_5 sorry
        then have A8: " not x inHIDDENR3 meetSETFAM-1K1 SFY"
          using A6 setfam_1_def_1 sorry
        have "Z1 =XBOOLE-0R4 X"
          using A5 tarski_def_1 sorry
        thus "x inHIDDENR3 X \\SUBSET-1K6 meetSETFAM-1K1 SFY"
          using A3 A7 A8 xboole_0_def_5 sorry
      qed "sorry"
      thus "unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)) c=TARSKIR1 X \\SUBSET-1K6 meetSETFAM-1K1 SFY"
        using tarski_def_3 sorry
    qed
    assume A9: "SFY <>HIDDENR2 {}XBOOLE-0K1"
    have "X \\SUBSET-1K6 meetSETFAM-1K1 SFY c=TARSKIR1 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\SUBSET-1K6 meetSETFAM-1K1 SFY implies x inHIDDENR3 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A10: "x inHIDDENR3 X \\SUBSET-1K6 meetSETFAM-1K1 SFY"
        then have " not x inHIDDENR3 meetSETFAM-1K1 SFY"
          using xboole_0_def_5 sorry
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A11: "Z inTARSKIR2 SFY"and A12: " not x inHIDDENR3 Z"
          using A9 setfam_1_def_1 sorry
        have A13: "x inHIDDENR3 X \\SUBSET-1K6 Z"
          using A10 A12 xboole_0_def_5 sorry
        have "X \\SUBSET-1K6 Z inTARSKIR2 DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY)"
          using A1 A11 setfam_1_def_6 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
          using A13 tarski_def_4 sorry
      qed "sorry"
      thus "X \\SUBSET-1K6 meetSETFAM-1K1 SFY c=TARSKIR1 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
        using tarski_def_3 sorry
    qed
    thus "X \\SUBSET-1K6 meetSETFAM-1K1 SFY =XBOOLE-0R4 unionTARSKIK3 (DIFFERENCESETFAM-1K4({TARSKIK1 X},SFY))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_28:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY)) =XBOOLE-0R4 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
proof-
  have " for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY)) =XBOOLE-0R4 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
  proof(rule ballI,rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    have "unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY)) c=TARSKIR1 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY & unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY c=TARSKIR1 unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
    proof(rule conjMI)
      show "unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY)) c=TARSKIR1 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY)) implies x inHIDDENR3 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
          then obtain Z where
            [ty]:"Z be setHIDDENM2" and 
            A1: "x inHIDDENR3 Z"and A2: "Z inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFY)"
            using tarski_def_4 sorry
          obtain X Y where
            [ty]:"X be setHIDDENM2" "Y be setHIDDENM2" and 
            A3: "X inTARSKIR2 SFX"and A4: "Y inTARSKIR2 SFY"and A5: "Z =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
            using A2 setfam_1_def_5 sorry
          have "x inHIDDENR3 Y"
            using A1 A5 xboole_0_def_4 sorry
          then have A6: "x inHIDDENR3 unionTARSKIK3 SFY"
            using A4 tarski_def_4 sorry
          have "x inHIDDENR3 X"
            using A1 A5 xboole_0_def_4 sorry
          then have "x inHIDDENR3 unionTARSKIK3 SFX"
            using A3 tarski_def_4 sorry
          thus "x inHIDDENR3 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
            using A6 xboole_0_def_4 sorry
        qed "sorry"
        thus "unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY)) c=TARSKIR1 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY implies x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A7: "x inHIDDENR3 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
        then have "x inHIDDENR3 unionTARSKIK3 SFX"
          using xboole_0_def_4 sorry
        then obtain X0 where
          [ty]:"X0 be setHIDDENM2" and 
          A8: "x inHIDDENR3 X0 & X0 inTARSKIR2 SFX"
          using tarski_def_4 sorry
        have "x inHIDDENR3 unionTARSKIK3 SFY"
          using A7 xboole_0_def_4 sorry
        then obtain Y0 where
          [ty]:"Y0 be setHIDDENM2" and 
          A9: "x inHIDDENR3 Y0 & Y0 inTARSKIR2 SFY"
          using tarski_def_4 sorry
        have "X0 /\\XBOOLE-0K3 Y0 inTARSKIR2 INTERSECTIONSETFAM-1K3(SFX,SFY) & x inHIDDENR3 X0 /\\XBOOLE-0K3 Y0"
          using A8 A9 setfam_1_def_5 xboole_0_def_4 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
          using tarski_def_4 sorry
      qed "sorry"
      thus "unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY c=TARSKIR1 unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY))"
        using tarski_def_3 sorry
    qed
    thus "unionTARSKIK3 (INTERSECTIONSETFAM-1K3(SFX,SFY)) =XBOOLE-0R4 unionTARSKIK3 SFX /\\XBOOLE-0K3 unionTARSKIK3 SFY"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_29:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFX <>HIDDENR2 {}XBOOLE-0K1 & SFY <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K1 SFX \\/XBOOLE-0K2 meetSETFAM-1K1 SFY c=TARSKIR1 meetSETFAM-1K1 (UNIONSETFAM-1K2(SFX,SFY))"
proof-
  have " for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds SFX <>HIDDENR2 {}XBOOLE-0K1 & SFY <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K1 SFX \\/XBOOLE-0K2 meetSETFAM-1K1 SFY c=TARSKIR1 meetSETFAM-1K1 (UNIONSETFAM-1K2(SFX,SFY))"
  proof(rule ballI,rule ballI,rule impI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    let ?y = "the ElementSUBSET-1M1-of SFX"
    let ?z = "the ElementSUBSET-1M1-of SFY"
    assume "SFX <>HIDDENR2 {}XBOOLE-0K1 & SFY <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "?y \\/XBOOLE-0K2 ?z inTARSKIR2 UNIONSETFAM-1K2(SFX,SFY)"
      using setfam_1_def_4 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 SFX \\/XBOOLE-0K2 meetSETFAM-1K1 SFY implies x inHIDDENR3 meetSETFAM-1K1 (UNIONSETFAM-1K2(SFX,SFY))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 meetSETFAM-1K1 SFX \\/XBOOLE-0K2 meetSETFAM-1K1 SFY"
      then have A2: "x inHIDDENR3 meetSETFAM-1K1 SFX or x inHIDDENR3 meetSETFAM-1K1 SFY"
        using xboole_0_def_3 sorry
      have " for Z be setHIDDENM2 holds Z inTARSKIR2 UNIONSETFAM-1K2(SFX,SFY) implies x inHIDDENR3 Z"
      proof(rule ballI,rule impI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume "Z inTARSKIR2 UNIONSETFAM-1K2(SFX,SFY)"
        then obtain X Y where
          [ty]:"X be setHIDDENM2" "Y be setHIDDENM2" and 
          A3: "X inTARSKIR2 SFX & Y inTARSKIR2 SFY"and A4: "Z =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
          using setfam_1_def_4 sorry
        have "x inHIDDENR3 X or x inHIDDENR3 Y"
          using A2 A3 setfam_1_def_1 sorry
        thus "x inHIDDENR3 Z"
          using A4 xboole_0_def_3 sorry
      qed "sorry"
      thus "x inHIDDENR3 meetSETFAM-1K1 (UNIONSETFAM-1K2(SFX,SFY))"
        using A1 setfam_1_def_1 sorry
    qed "sorry"
    thus "meetSETFAM-1K1 SFX \\/XBOOLE-0K2 meetSETFAM-1K1 SFY c=TARSKIR1 meetSETFAM-1K1 (UNIONSETFAM-1K2(SFX,SFY))"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_30:
" for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
proof-
  have " for SFX be setHIDDENM2 holds  for SFY be setHIDDENM2 holds meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
  proof(rule ballI,rule ballI)
    fix SFX assume [ty]: "SFX be setHIDDENM2"
    fix SFY assume [ty]: "SFY be setHIDDENM2"
    show "meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
    proof-
      have cases: "(SFX =XBOOLE-0R4 {}XBOOLE-0K1 or SFY =XBOOLE-0R4 {}XBOOLE-0K1) or SFX <>HIDDENR2 {}XBOOLE-0K1 & SFY <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "SFX =XBOOLE-0R4 {}XBOOLE-0K1 or SFY =XBOOLE-0R4 {}XBOOLE-0K1 implies meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
      proof(rule impI)
        assume A1: "SFX =XBOOLE-0R4 {}XBOOLE-0K1 or SFY =XBOOLE-0R4 {}XBOOLE-0K1"
        have "DIFFERENCESETFAM-1K4(SFX,SFY) <>HIDDENR2 {}XBOOLE-0K1 implies  False "
        proof(rule impI)
          assume "DIFFERENCESETFAM-1K4(SFX,SFY) <>HIDDENR2 {}XBOOLE-0K1"
          then obtain e where
            [ty]:"e be objectHIDDENM1" and 
            A2: "e inHIDDENR3 DIFFERENCESETFAM-1K4(SFX,SFY)"
            using xboole_0_def_1 sorry
          have " ex X be setHIDDENM2 st  ex Y be setHIDDENM2 st (X inTARSKIR2 SFX & Y inTARSKIR2 SFY) & e =HIDDENR1 X \\SUBSET-1K6 Y"
            using A2 setfam_1_def_6 sorry
          thus " False "
            using A1 sorry
        qed
        then have "meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) =XBOOLE-0R4 {}XBOOLE-0K1"
          using setfam_1_def_1 sorry
        thus "meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
           sorry
      qed
      have case2: "SFX <>HIDDENR2 {}XBOOLE-0K1 & SFY <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
      proof(rule impI)
        assume A3: "SFX <>HIDDENR2 {}XBOOLE-0K1 & SFY <>HIDDENR2 {}XBOOLE-0K1"
        let ?z = "the ElementSUBSET-1M1-of SFX"
        let ?y = "the ElementSUBSET-1M1-of SFY"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) implies x inHIDDENR3 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY))"
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 SFX implies x inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume "Z inTARSKIR2 SFX"
            then have "Z \\SUBSET-1K6 ?y inTARSKIR2 DIFFERENCESETFAM-1K4(SFX,SFY)"
              using A3 setfam_1_def_6 sorry
            then have "x inHIDDENR3 Z \\SUBSET-1K6 ?y"
              using A4 setfam_1_def_1 sorry
            thus "x inHIDDENR3 Z"
               sorry
          qed "sorry"
          then have A5: "x inHIDDENR3 meetSETFAM-1K1 SFX"
            using A3 setfam_1_def_1 sorry
          have "?z \\SUBSET-1K6 ?y inTARSKIR2 DIFFERENCESETFAM-1K4(SFX,SFY)"
            using A3 setfam_1_def_6 sorry
          then have "x inHIDDENR3 ?z \\SUBSET-1K6 ?y"
            using A4 setfam_1_def_1 sorry
          then have " not x inHIDDENR3 ?y"
            using xboole_0_def_5 sorry
          then have " not x inHIDDENR3 meetSETFAM-1K1 SFY"
            using A3 setfam_1_def_1 sorry
          thus "x inHIDDENR3 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
            using A5 xboole_0_def_5 sorry
        qed "sorry"
        thus "meetSETFAM-1K1 (DIFFERENCESETFAM-1K4(SFX,SFY)) c=TARSKIR1 meetSETFAM-1K1 SFX \\SUBSET-1K6 meetSETFAM-1K1 SFY"
          using tarski_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SETFAM_1M1("Subset-FamilySETFAM-1M1-of  _ " [70]70) where
  "Subset-FamilySETFAM-1M1-of D \<equiv> SubsetSUBSET-1M2-of boolZFMISC-1K1 D"

reserve F, G for "Subset-FamilySETFAM-1M1-of D"
reserve P for "SubsetSUBSET-1M2-of D"
syntax SETFAM_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("unionSETFAM-1K5\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "unionSETFAM-1K5\<^bsub>(D)\<^esub> F" \<rightharpoonup> "unionTARSKIK3 F"

mtheorem setfam_1_add_1:
  mlet "D be setHIDDENM2", "F be Subset-FamilySETFAM-1M1-of D"
"cluster unionTARSKIK3 F as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "unionTARSKIK3 F be SubsetSUBSET-1M2-of D"
  proof-
    have "unionTARSKIK3 F c=TARSKIR1 D"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 F implies x inHIDDENR3 D"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 unionTARSKIK3 F"
        then have " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 F"
          using tarski_def_4 sorry
        thus "x inHIDDENR3 D"
           sorry
      qed "sorry"
      thus "unionTARSKIK3 F c=TARSKIR1 D"
        using tarski_def_3 sorry
    qed
    thus "unionTARSKIK3 F be SubsetSUBSET-1M2-of D"
       sorry
  qed
qed "sorry"

syntax SETFAM_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("meetSETFAM-1K6\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "meetSETFAM-1K6\<^bsub>(D)\<^esub> F" \<rightharpoonup> "meetSETFAM-1K1 F"

mtheorem setfam_1_add_2:
  mlet "D be setHIDDENM2", "F be Subset-FamilySETFAM-1M1-of D"
"cluster meetSETFAM-1K1 F as-term-is SubsetSUBSET-1M2-of D"
proof
(*coherence*)
  show "meetSETFAM-1K1 F be SubsetSUBSET-1M2-of D"
  proof-
    have "meetSETFAM-1K1 F c=TARSKIR1 D"
    proof-
      have A1: "meetSETFAM-1K1 F c=TARSKIR1 unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
        using setfam_1_th_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K1 F implies x inHIDDENR3 D"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 meetSETFAM-1K1 F"
        then have "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
          using A1 sorry
        thus "x inHIDDENR3 D"
           sorry
      qed "sorry"
      thus "meetSETFAM-1K1 F c=TARSKIR1 D"
        using tarski_def_3 sorry
    qed
    thus "meetSETFAM-1K1 F be SubsetSUBSET-1M2-of D"
       sorry
  qed
qed "sorry"

mtheorem setfam_1_th_31:
" for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds  for G be Subset-FamilySETFAM-1M1-of D holds ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 F iff P inTARSKIR2 G) implies F =XBOOLE-0R4 G"
proof-
  have " for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds  for G be Subset-FamilySETFAM-1M1-of D holds ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 F iff P inTARSKIR2 G) implies F =XBOOLE-0R4 G"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of D"
    fix G assume [ty]: "G be Subset-FamilySETFAM-1M1-of D"
    assume A1: " for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 F iff P inTARSKIR2 G"
    have "F c=TARSKIR1 G & G c=TARSKIR1 F"
    proof(rule conjMI)
      show "F c=TARSKIR1 G"
        using A1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 G implies x inHIDDENR3 F"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 G"
        thus "x inHIDDENR3 F"
          using A1 sorry
      qed "sorry"
      thus "G c=TARSKIR1 F"
        using tarski_def_3 sorry
    qed
    thus "F =XBOOLE-0R4 G"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef setfam_1_def_7 ("COMPLEMENTSETFAM-1K7\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be setHIDDENM2", "F be Subset-FamilySETFAM-1M1-of D"
"func COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F \<rightarrow> Subset-FamilySETFAM-1M1-of D means
  \<lambda>it.  for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 it iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
proof-
  (*existence*)
    show " ex it be Subset-FamilySETFAM-1M1-of D st  for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 it iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
    proof-
      have " ex G be Subset-FamilySETFAM-1M1-of D st  for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 G iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
      proof-
        let ?X = "\<lambda>Lamb1. Lamb1 `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
        show " ex G be Subset-FamilySETFAM-1M1-of D st  for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 G iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
          using subset_1_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Subset-FamilySETFAM-1M1-of D holds  for it2 be Subset-FamilySETFAM-1M1-of D holds ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 it1 iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F) & ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 it2 iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F) implies it1 =HIDDENR1 it2"
    proof-
      have " for G be Subset-FamilySETFAM-1M1-of D holds  for H be Subset-FamilySETFAM-1M1-of D holds ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 G iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F) & ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 H iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F) implies G =HIDDENR1 H"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix G assume [ty]: "G be Subset-FamilySETFAM-1M1-of D"
        fix H assume [ty]: "H be Subset-FamilySETFAM-1M1-of D"
        assume A1: " for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 G iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
          and A2: " for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 H iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
        have " for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 G iff P inTARSKIR2 H"
        proof(rule ballI)
          fix P assume [ty]: "P be SubsetSUBSET-1M2-of D"
          have "P inTARSKIR2 G iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
            using A1 sorry
          thus "P inTARSKIR2 G iff P inTARSKIR2 H"
            using A2 sorry
        qed "sorry"
        thus "G =HIDDENR1 H"
          using setfam_1_th_31 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem SETFAM_1K7_involutiveness:
  mlet "D be setHIDDENM2"
" for F be Subset-FamilySETFAM-1M1-of D holds COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) =HIDDENR1 F"
proof-
  have " for it be Subset-FamilySETFAM-1M1-of D holds  for F be Subset-FamilySETFAM-1M1-of D holds it =HIDDENR1 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies F =HIDDENR1 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> it"
  proof-
    have " for it be Subset-FamilySETFAM-1M1-of D holds  for F be Subset-FamilySETFAM-1M1-of D holds ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 it iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F) implies ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 F iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 it)"
    proof-
      have " for F be Subset-FamilySETFAM-1M1-of D holds  for G be Subset-FamilySETFAM-1M1-of D holds ( for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 F iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 G) implies ( for P be SubsetSUBSET-1M2-of D holds  not (P inTARSKIR2 G &  not P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F) &  not (P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F &  not P inTARSKIR2 G))"
      proof(rule ballI,rule ballI,rule impI,rule ballI)
        fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of D"
        fix G assume [ty]: "G be Subset-FamilySETFAM-1M1-of D"
        assume A3: " for P be SubsetSUBSET-1M2-of D holds P inTARSKIR2 F iff P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 G"
        fix P assume [ty]: "P be SubsetSUBSET-1M2-of D"
        have "(P `SUBSET-1K3\<^bsub>(D)\<^esub>)`SUBSET-1K3\<^bsub>(D)\<^esub> =XBOOLE-0R4 P"
           sorry
        thus " not (P inTARSKIR2 G &  not P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F) &  not (P `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F &  not P inTARSKIR2 G)"
          using A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using setfam_1_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_32:
" for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds F <>HIDDENR2 {}XBOOLE-0K1 implies COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds F <>HIDDENR2 {}XBOOLE-0K1 implies  not COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of D"
    let ?X = "the ElementSUBSET-1M1-of F"
    assume A1: "F <>HIDDENR2 {}XBOOLE-0K1"
    then obtain X where 
      [ty]:"X be SubsetSUBSET-1M2-of D" and XDef:"X = ?X"
      using tarski_def_3 sorry
    have "(X `SUBSET-1K3\<^bsub>(D)\<^esub>)`SUBSET-1K3\<^bsub>(D)\<^esub> =XBOOLE-0R4 X"
       sorry
    thus " not COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1"
      using A1 setfam_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_33:
" for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds F <>HIDDENR2 {}XBOOLE-0K1 implies [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
proof-
  have " for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds F <>HIDDENR2 {}XBOOLE-0K1 implies [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of D"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 D implies (( for X be setHIDDENM2 holds X inTARSKIR2 F implies  not x inHIDDENR3 X) iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies x inHIDDENR3 Y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 D implies (( for X be setHIDDENM2 holds X inTARSKIR2 F implies  not x inHIDDENR3 X) implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies x inHIDDENR3 Y)) & (( for Y be setHIDDENM2 holds Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies x inHIDDENR3 Y) implies ( for X be setHIDDENM2 holds X inTARSKIR2 F implies  not x inHIDDENR3 X))"
      proof(rule ballI,rule impI,rule conjMI,rule impI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 D"
        show "( for X be setHIDDENM2 holds X inTARSKIR2 F implies  not x inHIDDENR3 X) implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies x inHIDDENR3 Y)"
        proof(rule impI,rule ballI,rule impI)
          assume A3: " for X be setHIDDENM2 holds X inTARSKIR2 F implies  not x inHIDDENR3 X"
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume A4: "Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F"
          then have 
            [ty]:"Y be SubsetSUBSET-1M2-of D"
             sorry
          have "Y `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 F"
            using A4 setfam_1_def_7 sorry
          then have " not x inHIDDENR3 Y `SUBSET-1K3\<^bsub>(D)\<^esub>"
            using A3 sorry
          thus "x inHIDDENR3 Y"
            using A2 xboole_0_def_5 sorry
        qed "sorry"
        assume A5: " for Y be setHIDDENM2 holds Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies x inHIDDENR3 Y"
        fix X assume [ty]: "X be setHIDDENM2"
        assume A6: "X inTARSKIR2 F"
        then have 
          [ty]:"X be SubsetSUBSET-1M2-of D"
           sorry
        have "(X `SUBSET-1K3\<^bsub>(D)\<^esub>)`SUBSET-1K3\<^bsub>(D)\<^esub> =XBOOLE-0R4 X"
           sorry
        then have "X `SUBSET-1K3\<^bsub>(D)\<^esub> inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F"
          using A6 setfam_1_def_7 sorry
        then have "x inHIDDENR3 X `SUBSET-1K3\<^bsub>(D)\<^esub>"
          using A5 sorry
        thus " not x inHIDDENR3 X"
          using xboole_0_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume "F <>HIDDENR2 {}XBOOLE-0K1"
    then have A7: "COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F <>HIDDENR2 {}XBOOLE-0K1"
      using setfam_1_th_32 sorry
    have A8: "[#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F c=TARSKIR1 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F implies x inHIDDENR3 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A9: "x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
        then have " not x inHIDDENR3 unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
          using xboole_0_def_5 sorry
        then have " for X be setHIDDENM2 holds X inTARSKIR2 F implies  not x inHIDDENR3 X"
          using tarski_def_4 sorry
        then have " for Y be setHIDDENM2 holds Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies x inHIDDENR3 Y"
          using A1 A9 sorry
        thus "x inHIDDENR3 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
          using A7 setfam_1_def_1 sorry
      qed "sorry"
      thus "[#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F c=TARSKIR1 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
        using tarski_def_3 sorry
    qed
    have "meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) c=TARSKIR1 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) implies x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A10: "x inHIDDENR3 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
        then have " for X be setHIDDENM2 holds X inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F implies x inHIDDENR3 X"
          using setfam_1_def_1 sorry
        then have " for Y be setHIDDENM2 holds x inHIDDENR3 Y implies  not Y inTARSKIR2 F"
          using A1 sorry
        then have " not x inHIDDENR3 unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
          using tarski_def_4 sorry
        thus "x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
          using A10 xboole_0_def_5 sorry
      qed "sorry"
      thus "meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) c=TARSKIR1 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F"
        using tarski_def_3 sorry
    qed
    thus "[#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> unionSETFAM-1K5\<^bsub>(D)\<^esub> F =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
      using A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_34:
" for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds F <>HIDDENR2 {}XBOOLE-0K1 implies unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) =XBOOLE-0R4 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
proof-
  have " for D be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of D holds F <>HIDDENR2 {}XBOOLE-0K1 implies unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) =XBOOLE-0R4 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of D"
    assume A1: "F <>HIDDENR2 {}XBOOLE-0K1"
    have A2: "[#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F c=TARSKIR1 unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F implies x inHIDDENR3 unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
        then have " not x inHIDDENR3 meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
          using xboole_0_def_5 sorry
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A4: "X inTARSKIR2 F"and A5: " not x inHIDDENR3 X"
          using A1 setfam_1_def_1 sorry
        have 
          [ty]:"X be SubsetSUBSET-1M2-of D"
          using A4 sorry
        obtain XX where 
          [ty]:"XX be setHIDDENM2" and XXDef:"XX = X `SUBSET-1K3\<^bsub>(D)\<^esub>"
           sorry
        have A6: "(X `SUBSET-1K3\<^bsub>(D)\<^esub>)`SUBSET-1K3\<^bsub>(D)\<^esub> =XBOOLE-0R4 X"
           sorry
        have " ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F"
        proof-
          have " ex tVar9 be setHIDDENM2 st x inHIDDENR3 tVar9 & tVar9 inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F"
          proof-
            show " ex tVar9 be setHIDDENM2 st x inHIDDENR3 tVar9 & tVar9 inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F"
            proof(rule bexI[of _ "XX"])
              show "x inHIDDENR3 XX & XX inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F"
                using A3 A4 A5 A6 setfam_1_def_7 xboole_0_def_5 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        thus "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
          using tarski_def_4 sorry
      qed "sorry"
      thus "[#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F c=TARSKIR1 unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
        using tarski_def_3 sorry
    qed
    have "unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) c=TARSKIR1 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) implies x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A7: "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F)"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A8: "x inHIDDENR3 X"and A9: "X inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F"
          using tarski_def_4 sorry
        have 
          [ty]:"X be SubsetSUBSET-1M2-of D"
          using A9 sorry
        obtain XX where 
          [ty]:"XX be setHIDDENM2" and XXDef:"XX = X `SUBSET-1K3\<^bsub>(D)\<^esub>"
           sorry
        have " ex Y be setHIDDENM2 st Y inTARSKIR2 F &  not x inHIDDENR3 Y"
        proof-
          have " ex Y be setHIDDENM2 st Y inTARSKIR2 F &  not x inHIDDENR3 Y"
          proof-
            obtain Y where 
              [ty]:"Y be setHIDDENM2" and YDef:"Y = XX"
               sorry
            show " ex Y be setHIDDENM2 st Y inTARSKIR2 F &  not x inHIDDENR3 Y"
            proof(rule bexI[of _ "Y"],rule conjMI)
              show "Y inTARSKIR2 F"
                using A9 setfam_1_def_7 sorry
              show " not x inHIDDENR3 Y"
                using A8 xboole_0_def_5 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        then have " not x inHIDDENR3 meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
          using setfam_1_def_1 sorry
        thus "x inHIDDENR3 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
          using A7 xboole_0_def_5 sorry
      qed "sorry"
      thus "unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) c=TARSKIR1 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
        using tarski_def_3 sorry
    qed
    thus "unionSETFAM-1K5\<^bsub>(D)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(D)\<^esub> F) =XBOOLE-0R4 [#]SUBSET-1K2 D \\SUBSET-1K7\<^bsub>(D)\<^esub> meetSETFAM-1K6\<^bsub>(D)\<^esub> F"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem setfam_1_th_35:
" for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for P be SubsetSUBSET-1M2-of X holds P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F iff P inTARSKIR2 F"
proof-
  have " for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for P be SubsetSUBSET-1M2-of X holds  not (P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F &  not P inTARSKIR2 F) &  not (P inTARSKIR2 F &  not P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of X"
    fix P assume [ty]: "P be SubsetSUBSET-1M2-of X"
    have "P =XBOOLE-0R4 (P `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub>"
       sorry
    thus " not (P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F &  not P inTARSKIR2 F) &  not (P inTARSKIR2 F &  not P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F)"
      using setfam_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_36:
" for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for G be Subset-FamilySETFAM-1M1-of X holds COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G implies F c=TARSKIR1 G"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of X"
  fix G assume [ty]: "G be Subset-FamilySETFAM-1M1-of X"
  assume A1: "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 F implies x inHIDDENR3 G"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A2: "x inHIDDENR3 F"
    then obtain A where 
      [ty]:"A be SubsetSUBSET-1M2-of X" and ADef:"A = x"
       sorry
    have "A inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F)"
      using A2 sorry
    then have "A `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F"
      using setfam_1_def_7 sorry
    then have "(A `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 G"
      using A1 setfam_1_def_7 sorry
    thus "x inHIDDENR3 G"
       sorry
  qed "sorry"
  thus "F c=TARSKIR1 G"
    using tarski_def_3 sorry
qed "sorry"

mtheorem setfam_1_th_37:
" for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for G be Subset-FamilySETFAM-1M1-of X holds COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 G iff F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
proof-
  have " for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for G be Subset-FamilySETFAM-1M1-of X holds (COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 G implies F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G) & (F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G implies COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 G)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of X"
    fix G assume [ty]: "G be Subset-FamilySETFAM-1M1-of X"
    show "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 G implies F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
    proof(rule impI)
      assume "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 G"
      then have "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G)"
         sorry
      thus "F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
        using setfam_1_th_36 sorry
    qed
    assume "F c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
    then have "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F) c=TARSKIR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
       sorry
    thus "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F c=TARSKIR1 G"
      using setfam_1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_38:
" for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for G be Subset-FamilySETFAM-1M1-of X holds COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F =XBOOLE-0R4 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G implies F =XBOOLE-0R4 G"
proof-
  have " for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for G be Subset-FamilySETFAM-1M1-of X holds COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F =XBOOLE-0R4 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G implies F =HIDDENR1 G"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of X"
    fix G assume [ty]: "G be Subset-FamilySETFAM-1M1-of X"
    assume "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F =XBOOLE-0R4 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
    then have "F =HIDDENR1 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> (COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G)"
       sorry
    also have "... = G"
       sorry
    finally show "F =HIDDENR1 G"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_39:
" for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds  for G be Subset-FamilySETFAM-1M1-of X holds COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> (F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> G) =XBOOLE-0R4 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
proof(rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of X"
  fix G assume [ty]: "G be Subset-FamilySETFAM-1M1-of X"
  have " for P be SubsetSUBSET-1M2-of X holds P inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G iff P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> G"
  proof-
    have " for P be SubsetSUBSET-1M2-of X holds  not (P inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G &  not P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> G) &  not (P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> G &  not P inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G)"
    proof(rule ballI)
      fix P assume [ty]: "P be SubsetSUBSET-1M2-of X"
      have "P inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F or P inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G iff P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F or P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 G"
        using setfam_1_def_7 sorry
      thus " not (P inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G &  not P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> G) &  not (P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> G &  not P inTARSKIR2 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G)"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> (F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> G) =XBOOLE-0R4 COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 X)\<^esub> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> G"
    using setfam_1_def_7 sorry
qed "sorry"

mtheorem setfam_1_th_40:
" for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds F =XBOOLE-0R4 {TARSKIK1 X} implies COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix F assume [ty]: "F be Subset-FamilySETFAM-1M1-of X"
  assume A1: "F =XBOOLE-0R4 {TARSKIK1 X}"
  have "{}XBOOLE-0K1 c=TARSKIR1 X"
     sorry
  then obtain G where 
    [ty]:"G be Subset-FamilySETFAM-1M1-of X" and GDef:"G = {TARSKIK1 {}XBOOLE-0K1 }"
    using zfmisc_1_th_31 sorry
  have 
    [ty]:"G be Subset-FamilySETFAM-1M1-of X"
     sorry
  have " for P be SubsetSUBSET-1M2-of X holds P inTARSKIR2 G iff P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
  proof-
    have " for P be SubsetSUBSET-1M2-of X holds (P inTARSKIR2 G implies P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F) & (P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F implies P inTARSKIR2 G)"
    proof(rule ballI,rule conjMI,rule impI)
      fix P assume [ty]: "P be SubsetSUBSET-1M2-of X"
      show "P inTARSKIR2 G implies P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      proof(rule impI)
        assume "P inTARSKIR2 G"
        then have "P =XBOOLE-0R4 {}SUBSET-1K1 X"
          using tarski_def_1 sorry
        thus "P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
          using A1 tarski_def_1 sorry
      qed
      assume "P `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      then have A2: "P `SUBSET-1K3\<^bsub>(X)\<^esub> =XBOOLE-0R4 [#]SUBSET-1K2 X"
        using A1 tarski_def_1 sorry
      have "P =HIDDENR1 (P `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub>"
         sorry
      also have "... = {}XBOOLE-0K1"
        using A2 xboole_1_th_37 sorry
      finally have "P =HIDDENR1 {}XBOOLE-0K1"
         sorry
      thus "P inTARSKIR2 G"
        using tarski_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    using setfam_1_def_7 sorry
qed "sorry"

mtheorem setfam_1_cl_1:
  mlet "X be setHIDDENM2", "F be emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"cluster COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F be emptyXBOOLE-0V1"
    using setfam_1_def_7 sorry
qed "sorry"

mdef setfam_1_def_8 ("with-non-empty-elementsSETFAM-1V1" 70 ) where
"attr with-non-empty-elementsSETFAM-1V1 for setHIDDENM2 means
  (\<lambda>IT.  not {}XBOOLE-0K1 inTARSKIR2 IT)"..

mtheorem setfam_1_cl_2:
"cluster  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1"
  proof-
    have " ex tVar11 be setHIDDENM2 st tVar11 be  non emptyXBOOLE-0V1 & tVar11 be with-non-empty-elementsSETFAM-1V1"
    proof-
      show " ex tVar11 be setHIDDENM2 st tVar11 be  non emptyXBOOLE-0V1 & tVar11 be with-non-empty-elementsSETFAM-1V1"
      proof(rule bexI[of _ "{TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"],rule conjMI)
        show "{TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } be  non emptyXBOOLE-0V1"
           sorry
        have "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } implies  False "
        proof(rule impI)
          assume "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"
          thus " False "
            using tarski_def_1 sorry
        qed
        thus "{TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } be with-non-empty-elementsSETFAM-1V1"
          using setfam_1_def_8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem setfam_1_cl_3:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {TARSKIK1 A} as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{TARSKIK1 A} be with-non-empty-elementsSETFAM-1V1"
    using tarski_def_1 sorry
qed "sorry"

mtheorem setfam_1_cl_4:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {TARSKIK2 A,B } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{TARSKIK2 A,B } be with-non-empty-elementsSETFAM-1V1"
    using tarski_def_2 sorry
qed "sorry"

mtheorem setfam_1_cl_5:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K1 A,B,C } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K1 A,B,C } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_1 sorry
qed "sorry"

mtheorem setfam_1_cl_6:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K2 A,B,C,D } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K2 A,B,C,D } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_2 sorry
qed "sorry"

mtheorem setfam_1_cl_7:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K3 A,B,C,D,E } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K3 A,B,C,D,E } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_3 sorry
qed "sorry"

mtheorem setfam_1_cl_8:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K4 A,B,C,D,E,F } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K4 A,B,C,D,E,F } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_4 sorry
qed "sorry"

mtheorem setfam_1_cl_9:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K5 A,B,C,D,E,F,G } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K5 A,B,C,D,E,F,G } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_5 sorry
qed "sorry"

mtheorem setfam_1_cl_10:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K6 A,B,C,D,E,F,G,H } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K6 A,B,C,D,E,F,G,H } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_6 sorry
qed "sorry"

mtheorem setfam_1_cl_11:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K7 A,B,C,D,E,F,G,H,I } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K7 A,B,C,D,E,F,G,H,I } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_7 sorry
qed "sorry"

mtheorem setfam_1_cl_12:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "G be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "H be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "J be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster {ENUMSET1K8 A,B,C,D,E,F,G,H,I,J } as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "{ENUMSET1K8 A,B,C,D,E,F,G,H,I,J } be with-non-empty-elementsSETFAM-1V1"
    using enumset1_def_8 sorry
qed "sorry"

mtheorem setfam_1_cl_13:
  mlet "A be with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2", "B be with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2"
"cluster A \\/XBOOLE-0K2 B as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "A \\/XBOOLE-0K2 B be with-non-empty-elementsSETFAM-1V1"
  proof-
    have " not {}XBOOLE-0K1 inTARSKIR2 A &  not {}XBOOLE-0K1 inTARSKIR2 B"
      using setfam_1_def_8 sorry
    then have " not {}XBOOLE-0K1 inTARSKIR2 A \\/XBOOLE-0K2 B"
      using xboole_0_def_3 sorry
    thus "A \\/XBOOLE-0K2 B be with-non-empty-elementsSETFAM-1V1"
       sorry
  qed
qed "sorry"

mtheorem setfam_1_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds unionTARSKIK3 Y c=TARSKIR1 Z & X inTARSKIR2 Y implies X c=TARSKIR1 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds unionTARSKIK3 Y c=TARSKIR1 Z & X inTARSKIR2 Y implies X c=TARSKIR1 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "unionTARSKIK3 Y c=TARSKIR1 Z"
      and A2: "X inTARSKIR2 Y"
    show "X c=TARSKIR1 Z"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then have "x inHIDDENR3 unionTARSKIK3 Y"
          using A2 tarski_def_4 sorry
        thus "x inHIDDENR3 Z"
          using A1 sorry
      qed "sorry"
      thus "X c=TARSKIR1 Z"
        using tarski_def_3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_42:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds X c=TARSKIR1 unionTARSKIK3 (A \\/XBOOLE-0K2 B) & ( for Y be setHIDDENM2 holds Y inTARSKIR2 B implies Y missesXBOOLE-0R1 X) implies X c=TARSKIR1 unionTARSKIK3 A"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds X c=TARSKIR1 unionTARSKIK3 (A \\/XBOOLE-0K2 B) implies (( for Y be setHIDDENM2 holds Y inTARSKIR2 B implies Y missesXBOOLE-0R1 X) implies X c=TARSKIR1 unionTARSKIK3 A)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X c=TARSKIR1 unionTARSKIK3 (A \\/XBOOLE-0K2 B)"
    then have "X c=TARSKIR1 unionTARSKIK3 (A \\/XBOOLE-0K2 B) /\\XBOOLE-0K3 X"
      using xboole_1_th_19 sorry
    then have "X c=TARSKIR1 (unionTARSKIK3 A \\/XBOOLE-0K2 unionTARSKIK3 B)/\\XBOOLE-0K3 X"
      using zfmisc_1_th_78 sorry
    then have A1: "X c=TARSKIR1 unionTARSKIK3 A /\\XBOOLE-0K3 X \\/XBOOLE-0K2 unionTARSKIK3 B /\\XBOOLE-0K3 X"
      using xboole_1_th_23 sorry
    assume " for Y be setHIDDENM2 holds Y inTARSKIR2 B implies Y missesXBOOLE-0R1 X"
    then have "unionTARSKIK3 B missesXBOOLE-0R1 X"
      using zfmisc_1_th_80 sorry
    then have A2: "unionTARSKIK3 B /\\XBOOLE-0K3 X =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    have "unionTARSKIK3 A /\\XBOOLE-0K3 X c=TARSKIR1 unionTARSKIK3 A"
      using xboole_1_th_17 sorry
    thus "X c=TARSKIR1 unionTARSKIK3 A"
      using A2 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef setfam_1_def_9 ("IntersectSETFAM-1K8\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "M be setHIDDENM2", "B be Subset-FamilySETFAM-1M1-of M"
"func IntersectSETFAM-1K8\<^bsub>(M)\<^esub> B \<rightarrow> SubsetSUBSET-1M2-of M equals
  meetSETFAM-1K6\<^bsub>(M)\<^esub> B if B <>HIDDENR2 {}XBOOLE-0K1 otherwise M"
proof-
  (*coherence*)
    show "(B <>HIDDENR2 {}XBOOLE-0K1 implies meetSETFAM-1K6\<^bsub>(M)\<^esub> B be SubsetSUBSET-1M2-of M) & ( not B <>HIDDENR2 {}XBOOLE-0K1 implies M be SubsetSUBSET-1M2-of M)"
    proof-
      have " not ( not B <>HIDDENR2 {}XBOOLE-0K1 &  not meetSETFAM-1K6\<^bsub>(M)\<^esub> B be SubsetSUBSET-1M2-of M) &  not (B <>HIDDENR2 {}XBOOLE-0K1 &  not M be SubsetSUBSET-1M2-of M)"
      proof-
        have "M c=TARSKIR1 M"
           sorry
        thus " not ( not B <>HIDDENR2 {}XBOOLE-0K1 &  not meetSETFAM-1K6\<^bsub>(M)\<^esub> B be SubsetSUBSET-1M2-of M) &  not (B <>HIDDENR2 {}XBOOLE-0K1 &  not M be SubsetSUBSET-1M2-of M)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be SubsetSUBSET-1M2-of M holds  True "
       sorry
qed "sorry"

mtheorem setfam_1_th_43:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for R be Subset-FamilySETFAM-1M1-of X holds x inTARSKIR2 X implies (x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 R implies x inTARSKIR2 Y))"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for R be Subset-FamilySETFAM-1M1-of X holds x inTARSKIR2 X implies (x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 R implies x inTARSKIR2 Y)) & (( for Y be setHIDDENM2 holds Y inTARSKIR2 R implies x inTARSKIR2 Y) implies x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix R assume [ty]: "R be Subset-FamilySETFAM-1M1-of X"
    assume A1: "x inTARSKIR2 X"
    show "x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 R implies x inTARSKIR2 Y)"
    proof(rule impI,rule ballI,rule impI)
      assume A2: "x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R"
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume A3: "Y inTARSKIR2 R"
      then have "IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(X)\<^esub> R"
        using setfam_1_def_9 sorry
      thus "x inTARSKIR2 Y"
        using A2 A3 setfam_1_def_1 sorry
    qed "sorry"
    assume A4: " for Y be setHIDDENM2 holds Y inTARSKIR2 R implies x inTARSKIR2 Y"
    show "x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R"
    proof-
      have cases: "R <>HIDDENR2 {}XBOOLE-0K1 or R =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have case1: "R <>HIDDENR2 {}XBOOLE-0K1 implies x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R"
      proof(rule impI)
        assume A5: "R <>HIDDENR2 {}XBOOLE-0K1"
        then have "x inTARSKIR2 meetSETFAM-1K6\<^bsub>(X)\<^esub> R"
          using A4 setfam_1_def_1 sorry
        thus "x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R"
          using A5 setfam_1_def_9 sorry
      qed
      have case2: "R =XBOOLE-0R4 {}XBOOLE-0K1 implies x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R"
      proof(rule impI)
        assume "R =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "x inTARSKIR2 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> R"
          using A1 setfam_1_def_9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setfam_1_th_44:
" for X be setHIDDENM2 holds  for H be Subset-FamilySETFAM-1M1-of X holds  for J be Subset-FamilySETFAM-1M1-of X holds H c=TARSKIR1 J implies IntersectSETFAM-1K8\<^bsub>(X)\<^esub> J c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> H"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix H assume [ty]: "H be Subset-FamilySETFAM-1M1-of X"
  fix J assume [ty]: "J be Subset-FamilySETFAM-1M1-of X"
  assume A1: "H c=TARSKIR1 J"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> J implies x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> H"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A2: "x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> J"
    then have " for Y be setHIDDENM2 holds Y inTARSKIR2 H implies x inHIDDENR3 Y"
      using A1 setfam_1_th_43 sorry
    thus "x inHIDDENR3 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> H"
      using A2 setfam_1_th_43 sorry
  qed "sorry"
  thus "IntersectSETFAM-1K8\<^bsub>(X)\<^esub> J c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(X)\<^esub> H"
    using tarski_def_3 sorry
qed "sorry"

mtheorem setfam_1_cl_14:
  mlet "X be  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2"
"cluster note-that  non emptyXBOOLE-0V1 for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be  non emptyXBOOLE-0V1"
    using setfam_1_def_8 sorry
qed "sorry"

reserve E for "setHIDDENM2"
mdef setfam_1_def_10 ("empty-memberedSETFAM-1V2" 70 ) where
"attr empty-memberedSETFAM-1V2 for setHIDDENM2 means
  (\<lambda>E.  not ( ex x be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st x inTARSKIR2 E))"..

syntax SETFAM_1V3 :: "Ty" ("with-non-empty-elementSETFAM-1V3" 70)
translations "with-non-empty-elementSETFAM-1V3" \<rightharpoonup> " non empty-memberedSETFAM-1V2"

mtheorem setfam_1_cl_15:
"cluster with-non-empty-elementSETFAM-1V3 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be with-non-empty-elementSETFAM-1V3"
  proof-
    have " ex tVar12 be setHIDDENM2 st  not tVar12 be with-non-empty-elementSETFAM-1V3"
    proof-
      show " ex tVar12 be setHIDDENM2 st  not tVar12 be with-non-empty-elementSETFAM-1V3"
      proof(rule bexI[of _ "{TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"])
        have "{TARSKIK1 {}XBOOLE-0K1 } inTARSKIR2 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"
        proof-
          show "{TARSKIK1 {}XBOOLE-0K1 } inTARSKIR2 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"
            using tarski_def_1 sorry
        qed
        thus " not {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } be with-non-empty-elementSETFAM-1V3"
          using bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"] setfam_1_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem setfam_1_cl_16:
"cluster with-non-empty-elementSETFAM-1V3 also-is  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be with-non-empty-elementSETFAM-1V3 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem setfam_1_cl_17:
  mlet "X be with-non-empty-elementSETFAM-1V3\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for ElementSUBSET-1M1-of X"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of X st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be ElementSUBSET-1M1-of X holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have " ex x be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st x inTARSKIR2 X"
        using setfam_1_def_10 sorry
      thus " not ( for VarFor1 be ElementSUBSET-1M1-of X holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem setfam_1_cl_18:
  mlet "D be  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2"
"cluster unionTARSKIK3 D as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "unionTARSKIK3 D be  non emptyXBOOLE-0V1"
  proof-
    have " not unionTARSKIK3 D be emptyXBOOLE-0V1"
    proof-
      let ?d = "the ElementSUBSET-1M1-of D"
      have "?d c=TARSKIR1 unionTARSKIK3 D"
        using zfmisc_1_th_74 sorry
      thus " not unionTARSKIK3 D be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem setfam_1_cl_19:
"cluster  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1 also-is with-non-empty-elementSETFAM-1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be  non emptyXBOOLE-0V1\<bar>with-non-empty-elementsSETFAM-1V1 implies it be with-non-empty-elementSETFAM-1V3"
     sorry
qed "sorry"

mdef setfam_1_def_11 ("CoverSETFAM-1M2-of  _ " [70]70 ) where
  mlet "X be setHIDDENM2"
"mode CoverSETFAM-1M2-of X \<rightarrow> setHIDDENM2 means
  (\<lambda>it. X c=TARSKIR1 unionTARSKIK3 it)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st X c=TARSKIR1 unionTARSKIK3 it"
    proof-
      have " ex tVar14 be setHIDDENM2 st X c=TARSKIR1 unionTARSKIK3 tVar14"
      proof-
        show " ex tVar14 be setHIDDENM2 st X c=TARSKIR1 unionTARSKIK3 tVar14"
        proof(rule bexI[of _ "{TARSKIK1 X}"])
          show "X c=TARSKIR1 unionTARSKIK3 {TARSKIK1 X}"
            using zfmisc_1_th_25 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem setfam_1_th_45:
" for X be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of X holds F be CoverSETFAM-1M2-of X iff unionSETFAM-1K5\<^bsub>(X)\<^esub> F =XBOOLE-0R4 X"
  using setfam_1_def_11 sorry

mtheorem setfam_1_th_46:
" for X be setHIDDENM2 holds {TARSKIK1 {}XBOOLE-0K1 } be Subset-FamilySETFAM-1M1-of X"
proof-
  have " for X be setHIDDENM2 holds {TARSKIK1 {}XBOOLE-0K1 } be Subset-FamilySETFAM-1M1-of X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "{}XBOOLE-0K1 c=TARSKIR1 X"
       sorry
    thus "{TARSKIK1 {}XBOOLE-0K1 } be Subset-FamilySETFAM-1M1-of X"
      using zfmisc_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef setfam_1_def_12 ("with-proper-subsetsSETFAM-1V4\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr with-proper-subsetsSETFAM-1V4\<^bsub>(X)\<^esub> for Subset-FamilySETFAM-1M1-of X means
  (\<lambda>F.  not X inTARSKIR2 F)"..

mtheorem setfam_1_th_47:
" for TS be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of TS holds  for G be Subset-FamilySETFAM-1M1-of TS holds F be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub> & G c=TARSKIR1 F implies G be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>"
   sorry

mtheorem setfam_1_cl_20:
  mlet "TS be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub> for Subset-FamilySETFAM-1M1-of TS"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of TS st it be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>"
  proof-
    have " ex tVar15 be Subset-FamilySETFAM-1M1-of TS st tVar15 be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>"
    proof-
      obtain F where 
        [ty]:"F be Subset-FamilySETFAM-1M1-of TS" and FDef:"F = {TARSKIK1 {}XBOOLE-0K1 }"
        using setfam_1_th_46 sorry
      show " ex tVar15 be Subset-FamilySETFAM-1M1-of TS st tVar15 be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>"
      proof(rule bexI[of _ "F"])
        have "TS inTARSKIR2 F implies  not  True "
        proof(rule impI)
          assume "TS inTARSKIR2 F"
          thus " not  True "
            using tarski_def_1 sorry
        qed
        thus "F be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>"
          using setfam_1_def_12 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem setfam_1_th_48:
" for TS be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>\<bar>Subset-FamilySETFAM-1M1-of TS holds  for B be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>\<bar>Subset-FamilySETFAM-1M1-of TS holds A \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 TS)\<^esub> B be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>"
proof(rule ballI,rule ballI,rule ballI)
  fix TS assume [ty]: "TS be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>\<bar>Subset-FamilySETFAM-1M1-of TS"
  fix B assume [ty]: "B be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>\<bar>Subset-FamilySETFAM-1M1-of TS"
  have "TS inTARSKIR2 A \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 TS)\<^esub> B implies  not  True "
  proof(rule impI)
    assume "TS inTARSKIR2 A \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 TS)\<^esub> B"
    then have "TS inTARSKIR2 A or TS inTARSKIR2 B"
      using xboole_0_def_3 sorry
    thus " not  True "
      using setfam_1_def_12 sorry
  qed
  thus "A \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 TS)\<^esub> B be with-proper-subsetsSETFAM-1V4\<^bsub>(TS)\<^esub>"
    using setfam_1_def_12 sorry
qed "sorry"

mtheorem setfam_1_cl_21:
"cluster  non trivialSUBSET-1V2 also-is with-non-empty-elementSETFAM-1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be  non trivialSUBSET-1V2 implies it be with-non-empty-elementSETFAM-1V3"
  proof-
    have " for W be setHIDDENM2 holds W be  non trivialSUBSET-1V2 implies  not W be with-non-empty-elementSETFAM-1V3"
    proof(rule ballI,rule impI)
      fix W assume [ty]: "W be setHIDDENM2"
      assume "W be  non trivialSUBSET-1V2"
      then obtain w1 w2 where
        [ty]:"w1 be objectHIDDENM1" "w2 be objectHIDDENM1" and 
        A1: "w1 inHIDDENR3 W & w2 inHIDDENR3 W"and A2: "w1 <>HIDDENR2 w2"
        using zfmisc_1_def_10 sorry
      have "w1 <>HIDDENR2 {}XBOOLE-0K1 or w2 <>HIDDENR2 {}XBOOLE-0K1"
        using A2 sorry
      thus " not W be with-non-empty-elementSETFAM-1V3"
        using A1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) SETFAM_1K9("boolSETFAM-1K9  _ " [228]228) where
  "boolSETFAM-1K9 X \<equiv> boolZFMISC-1K1 X"

mtheorem setfam_1_add_3:
  mlet "X be setHIDDENM2"
"cluster boolZFMISC-1K1 X as-term-is Subset-FamilySETFAM-1M1-of X"
proof
(*coherence*)
  show "boolZFMISC-1K1 X be Subset-FamilySETFAM-1M1-of X"
    using zfmisc_1_def_1 sorry
qed "sorry"

mtheorem setfam_1_th_49:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for b be objectHIDDENM1 holds A <>HIDDENR2 {TARSKIK1 b} implies ( ex a be ElementSUBSET-1M1-of A st a <>HIDDENR2 b)"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for b be objectHIDDENM1 holds A <>HIDDENR2 {TARSKIK1 b} implies (( for a be ElementSUBSET-1M1-of A holds a =HIDDENR1 b) implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix b assume [ty]: "b be objectHIDDENM1"
    assume A1: "A <>HIDDENR2 {TARSKIK1 b}"
    assume A2: " for a be ElementSUBSET-1M1-of A holds a =HIDDENR1 b"
    have " for a be objectHIDDENM1 holds (a inHIDDENR3 A implies a =HIDDENR1 b) & (a =HIDDENR1 b implies a inHIDDENR3 A)"
    proof(rule ballI,rule conjMI,rule impI)
      let ?a0 = "the ElementSUBSET-1M1-of A"
      fix a assume [ty]: "a be objectHIDDENM1"
      show "a inHIDDENR3 A implies a =HIDDENR1 b"
        using A2 sorry
      assume A3: "a =HIDDENR1 b"
      have "?a0 =HIDDENR1 b"
        using A2 sorry
      thus "a inHIDDENR3 A"
        using A3 sorry
    qed "sorry"
    thus " False "
      using A1 tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
