theory rewrite1
  imports wellord1 eqrel_1 pboole finseq_5 trees_2
   "../mizar_extension/E_number"
begin
(*begin*)
mdef rewrite1_def_1 (" _ $^REWRITE1K1  _ " [164,164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1", "q be FinSequenceFINSEQ-1M1"
"func p $^REWRITE1K1 q \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. it =FINSEQ-1R1 p ^FINSEQ-1K8 q if p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 otherwise \<lambda>it.  ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it =FINSEQ-1R1 r ^FINSEQ-1K8 q"
proof-
  (*existence*)
    show "(p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 implies ( ex it be FinSequenceFINSEQ-1M1 st it =FINSEQ-1R1 p ^FINSEQ-1K8 q)) & ( not (p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1) implies ( ex it be FinSequenceFINSEQ-1M1 st  ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it =FINSEQ-1R1 r ^FINSEQ-1K8 q))"
    proof-
      have "(p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 implies ( ex r be FinSequenceFINSEQ-1M1 st r =FINSEQ-1R1 p ^FINSEQ-1K8 q)) & (p <>HIDDENR2 {}XBOOLE-0K1 & q <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar1 be FinSequenceFINSEQ-1M1 st  ex tVar2 be NatNAT-1M1 st  ex tVar3 be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 tVar2 +NAT-1K1 \<one>\<^sub>M & tVar3 =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 tVar2) & tVar3 ^FINSEQ-1K8 q =FINSEQ-1R1 tVar3 ^FINSEQ-1K8 q))"
      proof(rule conjMI,rule impMI ,rule impI)
        show "p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 implies ( ex r be FinSequenceFINSEQ-1M1 st r =FINSEQ-1R1 p ^FINSEQ-1K8 q)"
           sorry
        assume A1: "p <>HIDDENR2 {}XBOOLE-0K1"
          and "q <>HIDDENR2 {}XBOOLE-0K1"
        have "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using A1 nat_1_th_13 sorry
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A2: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 i"
          using nat_1_th_10 sorry
        have 
          [ty]:"i be NatNAT-1M1"
           sorry
        obtain r where 
          [ty]:"r be FinSequenceFINSEQ-1M1" and rDef:"r = p  |RELAT-1K8 SegFINSEQ-1K2 i"
          using finseq_1_th_15 sorry
        show " ex tVar1 be FinSequenceFINSEQ-1M1 st  ex tVar2 be NatNAT-1M1 st  ex tVar3 be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 tVar2 +NAT-1K1 \<one>\<^sub>M & tVar3 =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 tVar2) & tVar3 ^FINSEQ-1K8 q =FINSEQ-1R1 tVar3 ^FINSEQ-1K8 q"
        proof(rule bexI[of _ "r ^FINSEQ-1K8 q"])
          show " ex tVar2 be NatNAT-1M1 st  ex tVar3 be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 tVar2 +NAT-1K1 \<one>\<^sub>M & tVar3 =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 tVar2) & tVar3 ^FINSEQ-1K8 q =FINSEQ-1R1 tVar3 ^FINSEQ-1K8 q"
          proof(rule bexI[of _ "i"])
            show " ex tVar3 be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & tVar3 =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & tVar3 ^FINSEQ-1K8 q =FINSEQ-1R1 tVar3 ^FINSEQ-1K8 q"
            proof(rule bexI[of _ "r"])
              show "(lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & r ^FINSEQ-1K8 q =FINSEQ-1R1 r ^FINSEQ-1K8 q"
                using A2 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1 implies (it1 =FINSEQ-1R1 p ^FINSEQ-1K8 q & it2 =FINSEQ-1R1 p ^FINSEQ-1K8 q implies it1 =HIDDENR1 it2)) & ( not (p =FINSEQ-1R1 {}XBOOLE-0K1 or q =FINSEQ-1R1 {}XBOOLE-0K1) implies (( ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it1 =FINSEQ-1R1 r ^FINSEQ-1K8 q) & ( ex i be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M & r =RELAT-1R1 p  |RELAT-1K8 SegFINSEQ-1K2 i) & it2 =FINSEQ-1R1 r ^FINSEQ-1K8 q) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be FinSequenceFINSEQ-1M1 holds  True "
       sorry
qed "sorry"

mlemma rewrite1_lm_1:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds x inTARSKIR2 domFINSEQ-1K5 p implies (x <=XXREAL-0R1 lenFINSEQ-1K4 p & x >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6"
proof(rule ballI,rule ballI,rule impI,rule conjMI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix x assume [ty]: "x be NatNAT-1M1"
  assume "x inTARSKIR2 domFINSEQ-1K5 p"
  then have A1: "x inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
    using finseq_1_def_3 sorry
  thus "x <=XXREAL-0R1 lenFINSEQ-1K4 p & x >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
    using finseq_1_th_1 sorry
  show "x >XXREAL-0R4 0NUMBERSK6"
    using A1 finseq_1_th_1 sorry
qed "sorry"

mlemma rewrite1_lm_2:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds x +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies x <XXREAL-0R3 lenFINSEQ-1K4 p"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix x assume [ty]: "x be NatNAT-1M1"
  assume "x +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
  then have "x +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
    using rewrite1_lm_1 sorry
  thus "x <XXREAL-0R3 lenFINSEQ-1K4 p"
    using nat_1_th_13 sorry
qed "sorry"

mlemma rewrite1_lm_3:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds (x <=XXREAL-0R1 lenFINSEQ-1K4 p or x <XXREAL-0R3 lenFINSEQ-1K4 p) & (x >=XXREAL-0R2 \<one>\<^sub>M or x >XXREAL-0R4 0NUMBERSK6) implies x inTARSKIR2 domFINSEQ-1K5 p"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix x assume [ty]: "x be NatNAT-1M1"
  assume A1: "x <=XXREAL-0R1 lenFINSEQ-1K4 p or x <XXREAL-0R3 lenFINSEQ-1K4 p"
    and A2: "x >=XXREAL-0R2 \<one>\<^sub>M or x >XXREAL-0R4 0NUMBERSK6"
  have "x >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
    using A2 nat_1_th_13 sorry
  then have "x inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
    using A1 finseq_1_th_1 sorry
  thus "x inTARSKIR2 domFINSEQ-1K5 p"
    using finseq_1_def_3 sorry
qed "sorry"

mlemma rewrite1_lm_4:
" for p be FinSequenceFINSEQ-1M1 holds  for x be NatNAT-1M1 holds x <XXREAL-0R3 lenFINSEQ-1K4 p implies x +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
  fix x assume [ty]: "x be NatNAT-1M1"
  assume "x <XXREAL-0R3 lenFINSEQ-1K4 p"
  then have "x +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
    using nat_1_th_13 sorry
  thus "x +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
    using rewrite1_lm_3 sorry
qed "sorry"

reserve p, q, r for "FinSequenceFINSEQ-1M1"
reserve x, y for "objectHIDDENM1"
mtheorem rewrite1_th_1:
" for p be FinSequenceFINSEQ-1M1 holds {}XBOOLE-0K1 $^REWRITE1K1 p =FINSEQ-1R1 p & p $^REWRITE1K1 {}XBOOLE-0K1 =FINSEQ-1R1 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds {}XBOOLE-0K1 $^REWRITE1K1 p =FINSEQ-1R1 p & p $^REWRITE1K1 {}XBOOLE-0K1 =FINSEQ-1R1 p"
  proof(rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    have "{}XBOOLE-0K1 ^FINSEQ-1K8 p =FINSEQ-1R1 p & p ^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 p"
      using finseq_1_th_34 sorry
    thus "{}XBOOLE-0K1 $^REWRITE1K1 p =FINSEQ-1R1 p & p $^REWRITE1K1 {}XBOOLE-0K1 =FINSEQ-1R1 p"
      using rewrite1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_2:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 q =FINSEQ-1R1 p ^FINSEQ-1K8 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 q =FINSEQ-1R1 p ^FINSEQ-1K8 q"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    then have A1: "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_22 sorry
    assume "q <>HIDDENR2 {}XBOOLE-0K1"
    then obtain i r where
      [ty]:"i be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
      A2: "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"and A3: "r =RELAT-1R1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) |RELAT-1K8 SegFINSEQ-1K2 i"and A4: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 q =FINSEQ-1R1 r ^FINSEQ-1K8 q"
      using rewrite1_def_1 sorry
    have "i <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have A5: "lenFINSEQ-1K4 r =XBOOLE-0R4 i"
      using A2 A3 finseq_1_th_17 sorry
    have " ex s be FinSequenceFINSEQ-1M1 st p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 r ^FINSEQ-1K8 s"
      using A3 finseq_1_th_80 sorry
    then obtain t where
      [ty]:"t be FinSequenceFINSEQ-1M1" and 
      A6: "p ^FINSEQ-1K8 t =FINSEQ-1R1 r"
      using A2 A1 A5 finseq_1_th_47 sorry
    have "lenFINSEQ-1K4 r +NAT-1K1 0NUMBERSK6 =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 lenFINSEQ-1K4 t"
      using A6 finseq_1_th_22 sorry
    then have "t =FINSEQ-1R1 {}XBOOLE-0K1"
      using A2 A1 A5 sorry
    thus "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 q =FINSEQ-1R1 p ^FINSEQ-1K8 q"
      using A4 A6 finseq_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_3:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 ((<*FINSEQ-1K10 y*>)^FINSEQ-1K8 q) =FINSEQ-1R1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))^FINSEQ-1K8 q"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 ((<*FINSEQ-1K10 y*>)^FINSEQ-1K8 q) =FINSEQ-1R1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))^FINSEQ-1K8 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))^FINSEQ-1K8 q =FINSEQ-1R1 p ^FINSEQ-1K8 ((<*FINSEQ-1K10 y*>)^FINSEQ-1K8 q)"
      using finseq_1_th_32 sorry
    thus "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))$^REWRITE1K1 ((<*FINSEQ-1K10 y*>)^FINSEQ-1K8 q) =FINSEQ-1R1 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))^FINSEQ-1K8 q"
      using rewrite1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_4:
" for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds q <>HIDDENR2 {}XBOOLE-0K1 implies (<*FINSEQ-1K10 x*>)$^REWRITE1K1 q =FINSEQ-1R1 q"
proof-
  have " for q be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds  not ( not q <>HIDDENR2 {}XBOOLE-0K1 &  not (<*FINSEQ-1K10 x*>)$^REWRITE1K1 q =FINSEQ-1R1 q)"
  proof(rule ballI,rule ballI)
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "{}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 <*FINSEQ-1K10 x*> & {}XBOOLE-0K1 ^FINSEQ-1K8 q =FINSEQ-1R1 q"
      using finseq_1_th_34 sorry
    thus " not ( not q <>HIDDENR2 {}XBOOLE-0K1 &  not (<*FINSEQ-1K10 x*>)$^REWRITE1K1 q =FINSEQ-1R1 q)"
      using rewrite1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_5:
" for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be objectHIDDENM1 holds  for q be FinSequenceFINSEQ-1M1 holds  not (p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    let ?P = "\<lambda>Lamb1.  for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 & lenFINSEQ-1K4 p =XBOOLE-0R4 Lamb1 implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
    assume A1: "p <>HIDDENR2 {}XBOOLE-0K1"
    have " for i be NatNAT-1M1 holds ( for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 & lenFINSEQ-1K4 p =XBOOLE-0R4 i implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)) implies ( for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 & lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M))"
    proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A2: " for p be FinSequenceFINSEQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 & lenFINSEQ-1K4 p =XBOOLE-0R4 i implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
      assume A3: "p <>HIDDENR2 {}XBOOLE-0K1"
        and A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
      obtain q y where
        [ty]:"q be FinSequenceFINSEQ-1M1" "y be objectHIDDENM1" and 
        A5: "p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>)"
        using A3 finseq_1_th_46 sorry
      have A6: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>)"
        using A5 finseq_1_th_22 sorry
      have A7: "lenFINSEQ-1K4 (<*FINSEQ-1K10 y*>) =XBOOLE-0R4 \<one>\<^sub>M"
        using finseq_1_th_39 sorry
      show " ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
      proof-
        have cases: "q =FINSEQ-1R1 {}XBOOLE-0K1 or q <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "q =FINSEQ-1R1 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
        proof(rule impI)
          assume A8: "q =FINSEQ-1R1 {}XBOOLE-0K1"
          then have "p =HIDDENR1 <*FINSEQ-1K10 y*>"
            using A5 finseq_1_th_34 sorry
          also have "... = (<*FINSEQ-1K10 y*>)^FINSEQ-1K8 {}XBOOLE-0K1"
            using finseq_1_th_34 sorry
          finally have "p =HIDDENR1 (<*FINSEQ-1K10 y*>)^FINSEQ-1K8 {}XBOOLE-0K1"
             sorry
          thus " ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
            using A7 A6 A8 sorry
        qed
        have case2: "q <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
        proof(rule impI)
          assume "q <>HIDDENR2 {}XBOOLE-0K1"
          then obtain x r where
            [ty]:"x be objectHIDDENM1" "r be FinSequenceFINSEQ-1M1" and 
            A9: "q =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 r"and A10: "lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
            using A2 A4 A7 A6 sorry
          have A11: "lenFINSEQ-1K4 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>)) =XBOOLE-0R4 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
            using A7 finseq_1_th_22 sorry
          have "p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (r ^FINSEQ-1K8 (<*FINSEQ-1K10 y*>))"
            using A5 A9 finseq_1_th_32 sorry
          thus " ex x be objectHIDDENM1 st  ex q be FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
            using A7 A6 A10 A11 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    then have A12: " for i be NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A13: "?P(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_2 A13 A12 sorry
    thus " not ( for x be objectHIDDENM1 holds  for q be FinSequenceFINSEQ-1M1 holds  not (p =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 q & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem rewrite1_sch_1:
  fixes pf0 qf0 Pp2 
  assumes
[ty]: "pf0 be FinSequenceFINSEQ-1M1" and
  [ty]: "qf0 be FinSequenceFINSEQ-1M1" and
   A1: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 pf0 & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 pf0 implies Pp2(pf0 .FUNCT-1K1 i,pf0 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))" and
   A2: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 qf0 & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 qf0 implies Pp2(qf0 .FUNCT-1K1 i,qf0 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))" and
   A3: "(lenFINSEQ-1K4 pf0 >XXREAL-0R4 0NUMBERSK6 & lenFINSEQ-1K4 qf0 >XXREAL-0R4 0NUMBERSK6) & pf0 .FUNCT-1K1 lenFINSEQ-1K4 pf0 =XBOOLE-0R4 qf0 .FUNCT-1K1 \<one>\<^sub>M"
  shows " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (pf0 $^REWRITE1K1 qf0) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (pf0 $^REWRITE1K1 qf0) implies ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x =XBOOLE-0R4 (pf0 $^REWRITE1K1 qf0).FUNCT-1K1 i & y =XBOOLE-0R4 (pf0 $^REWRITE1K1 qf0).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies Pp2(x,y))"
  proof(rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    have "pf0 <>HIDDENR2 {}XBOOLE-0K1"
      using A3 sorry
    then obtain r a where
      [ty]:"r be FinSequenceFINSEQ-1M1" "a be objectHIDDENM1" and 
      A4: "pf0 =FINSEQ-1R1 r ^FINSEQ-1K8 (<*FINSEQ-1K10 a*>)"
      using finseq_1_th_46 sorry
    have "qf0 <>HIDDENR2 {}XBOOLE-0K1"
      using A3 sorry
    then have A5: "pf0 $^REWRITE1K1 qf0 =FINSEQ-1R1 r ^FINSEQ-1K8 qf0"
      using A4 rewrite1_th_2 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 qf0"
      using A3 nat_1_th_13 sorry
    then have A6: "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 qf0)"
      using finseq_1_th_1 sorry
    have A7: "SegFINSEQ-1K2 (lenFINSEQ-1K4 qf0) =XBOOLE-0R4 domFINSEQ-1K5 qf0"
      using finseq_1_def_3 sorry
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A8: "i inTARSKIR2 domFINSEQ-1K5 (pf0 $^REWRITE1K1 qf0)"
      and A9: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (pf0 $^REWRITE1K1 qf0)"
    have A10: "i >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using A8 rewrite1_lm_1 sorry
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    have A11: "i +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    have A12: "lenFINSEQ-1K4 pf0 =HIDDENR1 lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 a*>)"
      using A4 finseq_1_th_22 sorry
    also have "... = lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    finally have "lenFINSEQ-1K4 pf0 =HIDDENR1 lenFINSEQ-1K4 r +NAT-1K1 \<one>\<^sub>M"
       sorry
    assume A13: "x =XBOOLE-0R4 (pf0 $^REWRITE1K1 qf0).FUNCT-1K1 i"
      and A14: "y =XBOOLE-0R4 (pf0 $^REWRITE1K1 qf0).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
    show "Pp2(x,y)"
    proof-
      have cases: "i <XXREAL-0R3 lenFINSEQ-1K4 pf0 or i >=XXREAL-0R2 lenFINSEQ-1K4 pf0"
         sorry
      have case1: "i <XXREAL-0R3 lenFINSEQ-1K4 pf0 implies Pp2(x,y)"
      proof(rule impI)
        assume A15: "i <XXREAL-0R3 lenFINSEQ-1K4 pf0"
        then have "i inTARSKIR2 domFINSEQ-1K5 pf0 & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 pf0"
          using A10 rewrite1_lm_3 rewrite1_lm_4 sorry
        then have A16: "Pp2(pf0 .FUNCT-1K1 i,pf0 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
          using A1 sorry
        have A17: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 r implies y =XBOOLE-0R4 r .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) & r .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 pf0 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
        proof(rule impI)
          assume "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 r"
          then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 r)"
            using A11 finseq_1_th_1 sorry
          then have "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 r"
            using finseq_1_def_3 sorry
          thus "y =XBOOLE-0R4 r .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) & r .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 pf0 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
            using A14 A4 A5 finseq_1_def_7 sorry
        qed
        have A18: "i <=XXREAL-0R1 lenFINSEQ-1K4 r"
          using A12 A15 nat_1_th_13 sorry
        then have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 r)"
          using A10 finseq_1_th_1 sorry
        then have "i inTARSKIR2 domFINSEQ-1K5 r"
          using finseq_1_def_3 sorry
        then have A19: "x =XBOOLE-0R4 r .FUNCT-1K1 i & r .FUNCT-1K1 i =XBOOLE-0R4 pf0 .FUNCT-1K1 i"
          using A13 A4 A5 finseq_1_def_7 sorry
        have "i =XBOOLE-0R4 lenFINSEQ-1K4 r or i <XXREAL-0R3 lenFINSEQ-1K4 r"
          using A18 xxreal_0_th_1 sorry
        thus "Pp2(x,y)"
          using A3 A6 A7 A14 A5 A12 A16 A19 A17 finseq_1_def_7 nat_1_th_13 sorry
      qed
      have case2: "i >=XXREAL-0R2 lenFINSEQ-1K4 pf0 implies Pp2(x,y)"
      proof(rule impI)
        assume "i >=XXREAL-0R2 lenFINSEQ-1K4 pf0"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A20: "i =XBOOLE-0R4 lenFINSEQ-1K4 pf0 +XCMPLX-0K2 k"
          using nat_1_th_10 sorry
        have 
          [ty]:"k be NatNAT-1M1"
           sorry
        have A21: "i =XBOOLE-0R4 lenFINSEQ-1K4 r +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 k)"
          using A12 A20 sorry
        have "lenFINSEQ-1K4 (pf0 $^REWRITE1K1 qf0) =XBOOLE-0R4 lenFINSEQ-1K4 r +NAT-1K1 lenFINSEQ-1K4 qf0"
          using A5 finseq_1_th_22 sorry
        then have A22: "k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 qf0"
          using A9 A21 rewrite1_lm_2 xreal_1_th_7 sorry
        then have A23: "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 qf0"
          using rewrite1_lm_4 sorry
        have A24: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 qf0"
          using A22 rewrite1_lm_3 sorry
        then have A25: "x =XBOOLE-0R4 qf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A13 A5 A21 finseq_1_def_7 sorry
        have "(lenFINSEQ-1K4 r +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 k))+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 r +NAT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
           sorry
        then have "y =XBOOLE-0R4 qf0 .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using A14 A5 A12 A20 A23 finseq_1_def_7 sorry
        thus "Pp2(x,y)"
          using A2 A24 A23 A25 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"

mdef rewrite1_def_2 ("RedSequenceREWRITE1M1-of  _ " [70]70 ) where
  mlet "R be RelationRELAT-1M1"
"mode RedSequenceREWRITE1M1-of R \<rightarrow> FinSequenceFINSEQ-1M1 means
  (\<lambda>it. lenFINSEQ-1K4 it >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 it implies [TARSKIK4 it .FUNCT-1K1 i,it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 it implies [TARSKIK4 it .FUNCT-1K1 i,it .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
    proof-
      have " ex p be setHIDDENM2 st lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = <*FINSEQ-1K10 {}XBOOLE-0K1*>"
           sorry
        show " ex p be setHIDDENM2 st lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule impMI ,rule impI)
          show "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"
             sorry
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A1: "i inTARSKIR2 domFINSEQ-1K5 p"
            and A2: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
          have A3: "domFINSEQ-1K5 p =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using finseq_1_th_2 finseq_1_th_38 sorry
          then have "i =XBOOLE-0R4 \<one>\<^sub>M"
            using A1 tarski_def_1 sorry
          thus "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
            using A3 A2 tarski_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rewrite1_cl_1:
  mlet "R be RelationRELAT-1M1"
"cluster note-that  non emptyXBOOLE-0V1 for RedSequenceREWRITE1M1-of R"
proof
(*coherence*)
  show " for it be RedSequenceREWRITE1M1-of R holds it be  non emptyXBOOLE-0V1"
    using rewrite1_def_2 card_1_th_27 sorry
qed "sorry"

mtheorem rewrite1_th_6:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds <*FINSEQ-1K10 a*> be RedSequenceREWRITE1M1-of R"
proof(rule ballI,rule ballI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  let ?p = "<*FINSEQ-1K10 a*>"
  have "lenFINSEQ-1K4 (<*FINSEQ-1K10 a*>) >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 a*>) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 a*>) implies [TARSKIK4 (<*FINSEQ-1K10 a*>).FUNCT-1K1 i,(<*FINSEQ-1K10 a*>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
  proof(rule conjMI,rule ballI,rule impMI ,rule impI)
    show "lenFINSEQ-1K4 (<*FINSEQ-1K10 a*>) >XXREAL-0R4 0NUMBERSK6"
       sorry
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 ?p"
      and A2: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p"
    have A3: "domFINSEQ-1K5 ?p =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
      using finseq_1_th_2 finseq_1_th_38 sorry
    then have "i =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 tarski_def_1 sorry
    thus "[TARSKIK4 (<*FINSEQ-1K10 a*>).FUNCT-1K1 i,(<*FINSEQ-1K10 a*>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
      using A3 A2 tarski_def_1 sorry
  qed "sorry"
  thus "<*FINSEQ-1K10 a*> be RedSequenceREWRITE1M1-of R"
    using rewrite1_def_2 sorry
qed "sorry"

mtheorem rewrite1_th_7:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies <*FINSEQ-1K11 a,b *> be RedSequenceREWRITE1M1-of R"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  assume A1: "[TARSKIK4 a,b ] inHIDDENR3 R"
  let ?p = "<*FINSEQ-1K11 a,b *>"
  have "lenFINSEQ-1K4 (<*FINSEQ-1K11 a,b *>) >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 a,b *>) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K11 a,b *>) implies [TARSKIK4 (<*FINSEQ-1K11 a,b *>).FUNCT-1K1 i,(<*FINSEQ-1K11 a,b *>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
  proof(rule conjMI,rule ballI,rule impMI ,rule impI)
    show "lenFINSEQ-1K4 (<*FINSEQ-1K11 a,b *>) >XXREAL-0R4 0NUMBERSK6"
       sorry
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A2: "i inTARSKIR2 domFINSEQ-1K5 ?p"
      and A3: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p"
    have "lenFINSEQ-1K4 ?p =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_44 sorry
    then have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A3 rewrite1_lm_1 sorry
    then have A4: "i <=XXREAL-0R1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    have "i >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 rewrite1_lm_1 sorry
    then have "?p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & i =XBOOLE-0R4 \<one>\<^sub>M"
      using A4 finseq_1_th_44 xxreal_0_th_1 sorry
    thus "[TARSKIK4 (<*FINSEQ-1K11 a,b *>).FUNCT-1K1 i,(<*FINSEQ-1K11 a,b *>).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
      using A1 finseq_1_th_44 sorry
  qed "sorry"
  thus "<*FINSEQ-1K11 a,b *> be RedSequenceREWRITE1M1-of R"
    using rewrite1_def_2 sorry
qed "sorry"

mtheorem rewrite1_th_8:
" for R be RelationRELAT-1M1 holds  for p be RedSequenceREWRITE1M1-of R holds  for q be RedSequenceREWRITE1M1-of R holds p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M implies p $^REWRITE1K1 q be RedSequenceREWRITE1M1-of R"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix p assume [ty]: "p be RedSequenceREWRITE1M1-of R"
  fix q assume [ty]: "q be RedSequenceREWRITE1M1-of R"
  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. [TARSKIK4 Lamb1,Lamb2 ] inHIDDENR3 R"
  let ?r = "p $^REWRITE1K1 q"
  obtain p1 x where
    [ty]:"p1 be FinSequenceFINSEQ-1M1" "x be objectHIDDENM1" and 
    A1: "p =FINSEQ-1R1 p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
    using finseq_1_th_46 sorry
  assume "p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M"
  then have A2: "(lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & lenFINSEQ-1K4 q >XXREAL-0R4 0NUMBERSK6) & p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M"
     sorry
  have Cut332: "?r =FINSEQ-1R1 p1 ^FINSEQ-1K8 q"
    using A1 rewrite1_th_2 sorry
  have "lenFINSEQ-1K4 (p $^REWRITE1K1 q) >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 (p $^REWRITE1K1 q) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (p $^REWRITE1K1 q)) &  not [TARSKIK4 (p $^REWRITE1K1 q).FUNCT-1K1 i,(p $^REWRITE1K1 q).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
  proof(rule conjMI)
    show "lenFINSEQ-1K4 (p $^REWRITE1K1 q) >XXREAL-0R4 0NUMBERSK6"
      using Cut332 sorry
    have A3: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 q & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q implies ?P(q .FUNCT-1K1 i,q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
      using rewrite1_def_2 sorry
    have A4: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ?P(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
      using rewrite1_def_2 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (p $^REWRITE1K1 q) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (p $^REWRITE1K1 q) implies ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x =XBOOLE-0R4 (p $^REWRITE1K1 q).FUNCT-1K1 i & y =XBOOLE-0R4 (p $^REWRITE1K1 q).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) implies ?P(x,y))"
      using rewrite1_sch_1 A4 A3 A2 sorry
    thus " for i be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 (p $^REWRITE1K1 q) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (p $^REWRITE1K1 q)) &  not [TARSKIK4 (p $^REWRITE1K1 q).FUNCT-1K1 i,(p $^REWRITE1K1 q).FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
       sorry
  qed
  thus "p $^REWRITE1K1 q be RedSequenceREWRITE1M1-of R"
    using rewrite1_def_2 sorry
qed "sorry"

mtheorem rewrite1_th_9:
" for R be RelationRELAT-1M1 holds  for p be RedSequenceREWRITE1M1-of R holds RevFINSEQ-5K3 p be RedSequenceREWRITE1M1-of R ~RELAT-1K4"
proof(rule ballI,rule ballI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix p assume [ty]: "p be RedSequenceREWRITE1M1-of R"
  have Cut349: "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"
     sorry
  have "lenFINSEQ-1K4 (RevFINSEQ-5K3 p) >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 p) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 p) implies [TARSKIK4 RevFINSEQ-5K3 p .FUNCT-1K1 i,RevFINSEQ-5K3 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R ~RELAT-1K4)"
  proof(rule conjMI,rule ballI,rule impMI ,rule impI)
    show "lenFINSEQ-1K4 (RevFINSEQ-5K3 p) >XXREAL-0R4 0NUMBERSK6"
      using finseq_5_def_3 Cut349 sorry
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 p)"
      and A2: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 p)"
    have A3: "lenFINSEQ-1K4 (RevFINSEQ-5K3 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
      using finseq_5_def_3 sorry
    then have A4: "domFINSEQ-1K5 (RevFINSEQ-5K3 p) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    have "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A3 A2 rewrite1_lm_1 sorry
    then obtain k where 
      [ty]:"k be NatNAT-1M1" and kDef:"k = (lenFINSEQ-1K4 p -XCMPLX-0K6 (i +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
      using finseq_5_th_1 sorry
    have A5: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    then have A6: "k inTARSKIR2 domFINSEQ-1K5 p"
      using A4 A2 finseq_5_th_2 sorry
    have "k =XBOOLE-0R4 lenFINSEQ-1K4 p -XCMPLX-0K6 i"
       sorry
    then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
      using A4 A5 A1 finseq_5_th_2 sorry
    then have A7: "[TARSKIK4 p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
      using A6 rewrite1_def_2 sorry
    have "RevFINSEQ-5K3 p .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 ((lenFINSEQ-1K4 p -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M) & RevFINSEQ-5K3 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 ((lenFINSEQ-1K4 p -XCMPLX-0K6 (i +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)"
      using A1 A2 finseq_5_def_3 sorry
    thus "[TARSKIK4 RevFINSEQ-5K3 p .FUNCT-1K1 i,RevFINSEQ-5K3 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R ~RELAT-1K4"
      using A7 relat_1_def_7 sorry
  qed "sorry"
  thus "RevFINSEQ-5K3 p be RedSequenceREWRITE1M1-of R ~RELAT-1K4"
    using rewrite1_def_2 sorry
qed "sorry"

mtheorem rewrite1_th_10:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R c=RELAT-1R2 Q implies ( for p be RedSequenceREWRITE1M1-of R holds p be RedSequenceREWRITE1M1-of Q)"
proof(rule ballI,rule ballI,rule impI,rule ballI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix Q assume [ty]: "Q be RelationRELAT-1M1"
  assume A1: "R c=RELAT-1R2 Q"
  fix p assume [ty]: "p be RedSequenceREWRITE1M1-of R"
  have "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Q)"
  proof(rule conjMI,rule ballI,rule impI)
    show "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"
       sorry
    fix i assume [ty]: "i be NatNAT-1M1"
    assume "i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
    then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
      using rewrite1_def_2 sorry
    thus "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Q"
      using A1 sorry
  qed "sorry"
  thus "p be RedSequenceREWRITE1M1-of Q"
    using rewrite1_def_2 sorry
qed "sorry"

(*begin*)
mdef rewrite1_def_3 (" _ reducesREWRITE1R1'( _ , _ ')" [50,0,0]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred R reducesREWRITE1R1(a,b) means
   ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"..

mdef rewrite1_def_4 ("'( _ , _ ')are-convertible-wrtREWRITE1R2  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-convertible-wrtREWRITE1R2 R means
  R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b)"..

mtheorem rewrite1_th_11:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (R reducesREWRITE1R1(a,b) implies ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))) & (( ex p be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b)) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)) implies R reducesREWRITE1R1(a,b))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    show "R reducesREWRITE1R1(a,b) implies ( ex p be FinSequenceFINSEQ-1M1 st ((lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
    proof-
      have " not (R reducesREWRITE1R1(a,b) & ( for p be FinSequenceFINSEQ-1M1 holds  not ((( not lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) & ( for i be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p) &  not [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)))))"
      proof-
        have "( ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies ( ex tVar5 be FinSequenceFINSEQ-1M1 st (( not lenFINSEQ-1K4 tVar5 >XXREAL-0R4 0NUMBERSK6 & tVar5 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & tVar5 .FUNCT-1K1 lenFINSEQ-1K4 tVar5 =HIDDENR1 b) & ( for i be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 tVar5 & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 tVar5) &  not [TARSKIK4 tVar5 .FUNCT-1K1 i,tVar5 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)))"
        proof(rule impI)
          assume Given: " ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
          then obtain p where
            [ty]:"p be RedSequenceREWRITE1M1-of R" and 
            A1: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
             sorry
          show " ex tVar5 be FinSequenceFINSEQ-1M1 st (( not lenFINSEQ-1K4 tVar5 >XXREAL-0R4 0NUMBERSK6 & tVar5 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & tVar5 .FUNCT-1K1 lenFINSEQ-1K4 tVar5 =HIDDENR1 b) & ( for i be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 tVar5 & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 tVar5) &  not [TARSKIK4 tVar5 .FUNCT-1K1 i,tVar5 .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
          proof(rule bexI[of _ "p"])
            show "(( not lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) & ( for i be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p) &  not [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R))"
              using A1 rewrite1_def_2 sorry
          qed "sorry"
        qed
        thus " not (R reducesREWRITE1R1(a,b) & ( for p be FinSequenceFINSEQ-1M1 holds  not ((( not lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a) & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) & ( for i be NatNAT-1M1 holds  not ((i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p) &  not [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)))))"
          using rewrite1_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex p be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b)) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
    then obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M1" and 
      A2: "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"and A3: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"and A4: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
       sorry
    have 
      [ty]:"p be RedSequenceREWRITE1M1-of R"
      using A2 A4 rewrite1_def_2 sorry
    have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
    proof-
      show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
        using A3 sorry
    qed
    thus "R reducesREWRITE1R1(a,b)"
      using bexI[of _ "p"] rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_12:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds R reducesREWRITE1R1(a,a)"
proof(rule ballI,rule ballI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  obtain p where 
    [ty]:"p be RedSequenceREWRITE1M1-of R" and pDef:"p = <*FINSEQ-1K10 a*>"
    using rewrite1_th_6 sorry
  have Cut436: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_40 sorry
  have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 a"
  proof-
    show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 a"
      using finseq_1_th_40 Cut436 sorry
  qed
  thus "R reducesREWRITE1R1(a,a)"
    using bexI[of _ "p"] rewrite1_def_3 sorry
qed "sorry"

mtheorem rewrite1_th_13:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds {}XBOOLE-0K1 reducesREWRITE1R1(a,b) implies a =HIDDENR1 b"
proof-
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ({}XBOOLE-0K1 reducesREWRITE1R1(a,b) &  not a =HIDDENR1 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of {}XBOOLE-0K1 st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies a =HIDDENR1 b"
    proof(rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of {}XBOOLE-0K1 st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of {}XBOOLE-0K1" and 
        A1: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      have A2: "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M implies  False "
      proof(rule impI)
        assume "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M"
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
          using rewrite1_lm_3 rewrite1_lm_4 sorry
        thus " False "
          using rewrite1_def_2 sorry
      qed
      have "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      thus "a =HIDDENR1 b"
        using A1 A2 xxreal_0_th_1 sorry
    qed
    thus " not ({}XBOOLE-0K1 reducesREWRITE1R1(a,b) &  not a =HIDDENR1 b)"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_14:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) &  not a inHIDDENR3 fieldRELAT-1K3 R implies a =HIDDENR1 b"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((R reducesREWRITE1R1(a,b) &  not a inHIDDENR3 fieldRELAT-1K3 R) &  not a =HIDDENR1 b)"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies ( not a inHIDDENR3 fieldRELAT-1K3 R implies a =HIDDENR1 b)"
    proof(rule impI,rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A1: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A2: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      assume A3: " not a inHIDDENR3 fieldRELAT-1K3 R"
      have A4: "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M implies  False "
      proof(rule impI)
        assume "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M"
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
          using rewrite1_lm_3 rewrite1_lm_4 sorry
        then have "[TARSKIK4 p .FUNCT-1K1 \<one>\<^sub>M,p .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
          using rewrite1_def_2 sorry
        thus " False "
          using A1 A3 relat_1_th_15 sorry
      qed
      have "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      thus "a =HIDDENR1 b"
        using A1 A2 A4 xxreal_0_th_1 sorry
    qed
    thus " not ((R reducesREWRITE1R1(a,b) &  not a inHIDDENR3 fieldRELAT-1K3 R) &  not a =HIDDENR1 b)"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_15:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies R reducesREWRITE1R1(a,b)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  assume "[TARSKIK4 a,b ] inHIDDENR3 R"
  then obtain p where 
    [ty]:"p be RedSequenceREWRITE1M1-of R" and pDef:"p = <*FINSEQ-1K11 a,b *>"
    using rewrite1_th_7 sorry
  have Cut482: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<two>\<^sub>M"
    using finseq_1_th_44 sorry
  have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
  proof-
    show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      using finseq_1_th_44 Cut482 sorry
  qed
  thus "R reducesREWRITE1R1(a,b)"
    using bexI[of _ "p"] rewrite1_def_3 sorry
qed "sorry"

mtheorem rewrite1_th_16:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(b,c) implies R reducesREWRITE1R1(a,c)"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not ((R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(b,c)) &  not R reducesREWRITE1R1(a,c))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix c assume [ty]: "c be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies  not (R reducesREWRITE1R1(b,c) &  not R reducesREWRITE1R1(a,c))"
    proof(rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A1: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A2: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      have "( ex q be RedSequenceREWRITE1M1-of R st q .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 b & q .FUNCT-1K1 lenFINSEQ-1K4 q =HIDDENR1 c) implies R reducesREWRITE1R1(a,c)"
      proof(rule impI)
        assume Given: " ex q be RedSequenceREWRITE1M1-of R st q .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 b & q .FUNCT-1K1 lenFINSEQ-1K4 q =HIDDENR1 c"
        then obtain q where
          [ty]:"q be RedSequenceREWRITE1M1-of R" and 
          A3: "q .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 b"and A4: "q .FUNCT-1K1 lenFINSEQ-1K4 q =HIDDENR1 c"
           sorry
        obtain r where 
          [ty]:"r be RedSequenceREWRITE1M1-of R" and rDef:"r = p $^REWRITE1K1 q"
          using A2 A3 rewrite1_th_8 sorry
        obtain p1 x where
          [ty]:"p1 be FinSequenceFINSEQ-1M1" "x be objectHIDDENM1" and 
          A5: "p =FINSEQ-1R1 p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
          using finseq_1_th_46 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
          using nat_1_th_13 sorry
        then have "lenFINSEQ-1K4 q inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
          using finseq_1_th_1 sorry
        then have A6: "lenFINSEQ-1K4 q inTARSKIR2 domFINSEQ-1K5 q"
          using finseq_1_def_3 sorry
        have A7: "r =FINSEQ-1R1 p1 ^FINSEQ-1K8 q"
          using A5 rewrite1_th_2 sorry
        have "p1 =FINSEQ-1R1 {}XBOOLE-0K1 or lenFINSEQ-1K4 p1 >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "r =FINSEQ-1R1 q & p =FINSEQ-1R1 <*FINSEQ-1K10 x*> or \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1)"
          using A5 A7 finseq_1_th_1 finseq_1_th_34 sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p1 or lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M & r =FINSEQ-1R1 q"
          using finseq_1_th_40 finseq_1_def_3 sorry
        then have Cut509: "r .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p1 .FUNCT-1K1 \<one>\<^sub>M & p1 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a or r .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 b & b =HIDDENR1 a"
          using A1 A2 A3 A5 A7 finseq_1_def_7 sorry
        have "r .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & r .FUNCT-1K1 lenFINSEQ-1K4 r =HIDDENR1 c"
        proof(rule conjMI)
          show "r .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"
            using Cut509 sorry
          have "lenFINSEQ-1K4 r =XBOOLE-0R4 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 q"
            using A7 finseq_1_th_22 sorry
          thus "r .FUNCT-1K1 lenFINSEQ-1K4 r =HIDDENR1 c"
            using A4 A7 A6 finseq_1_def_7 sorry
        qed
        thus "R reducesREWRITE1R1(a,c)"
          using bexI[of _ "r"] rewrite1_def_3 sorry
      qed
      thus " not (R reducesREWRITE1R1(b,c) &  not R reducesREWRITE1R1(a,c))"
        using rewrite1_def_3 sorry
    qed
    thus " not ((R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(b,c)) &  not R reducesREWRITE1R1(a,c))"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_17:
" for R be RelationRELAT-1M1 holds  for p be RedSequenceREWRITE1M1-of R holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p & j inTARSKIR2 domFINSEQ-1K5 p) & i <=XXREAL-0R1 j implies R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 j)"
proof-
  have " for R be RelationRELAT-1M1 holds  for p be RedSequenceREWRITE1M1-of R holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & (j inTARSKIR2 domFINSEQ-1K5 p & i <=XXREAL-0R1 j) implies R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 j)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix p assume [ty]: "p be RedSequenceREWRITE1M1-of R"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    let ?Q = "\<lambda>Lamb1. i +XCMPLX-0K2 Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +XCMPLX-0K2 Lamb1))"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 p"
      and A2: "j inTARSKIR2 domFINSEQ-1K5 p"
      and A3: "i <=XXREAL-0R1 j"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "j =XBOOLE-0R4 i +XCMPLX-0K2 k"
      using A3 nat_1_th_10 sorry
    have " for j be NatNAT-1M1 holds (i +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +XCMPLX-0K2 j))) & i +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M)))"
    proof(rule ballI,rule impMI ,rule impI)
      have A5: "i >=XXREAL-0R2 \<one>\<^sub>M"
        using A1 rewrite1_lm_1 sorry
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A6: "i +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +XCMPLX-0K2 j))"
        and A7: "i +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 domFINSEQ-1K5 p"
      have A8: "i +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (i +XCMPLX-0K2 j)+NAT-1K1 \<one>\<^sub>M"
         sorry
      then have A9: "i +XCMPLX-0K2 j <XXREAL-0R3 lenFINSEQ-1K4 p"
        using A7 rewrite1_lm_2 sorry
      then have "i +XCMPLX-0K2 j inTARSKIR2 domFINSEQ-1K5 p"
        using A5 rewrite1_lm_3 sorry
      then have "[TARSKIK4 p .FUNCT-1K1 (i +XCMPLX-0K2 j),p .FUNCT-1K1 (i +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) ] inHIDDENR3 R"
        using A7 A8 rewrite1_def_2 sorry
      then have "R reducesREWRITE1R1(p .FUNCT-1K1 (i +XCMPLX-0K2 j),p .FUNCT-1K1 (i +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M)))"
        using rewrite1_th_15 sorry
      thus "R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M)))"
        using A6 A5 A9 rewrite1_lm_3 rewrite1_th_16 sorry
    qed "sorry"
    then have A10: " for k be NatNAT-1M1 holds ?Q(k) implies ?Q(k +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A11: "?Q(0NUMBERSK6)"
      using rewrite1_th_12 sorry
    have A12: " for j be NatNAT-1M1 holds ?Q(j)"
      using nat_1_sch_2 A11 A10 sorry
    show "R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 j)"
      using A2 A12 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_18:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & a <>HIDDENR2 b implies a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((R reducesREWRITE1R1(a,b) &  not a <>HIDDENR2 b) &  not (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R))"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of R st a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p) implies (a <>HIDDENR2 b implies a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R)"
    proof(rule impI,rule impI,rule conjMI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R st a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A1: "a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"and A2: "b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
         sorry
      have A3: "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      assume "a <>HIDDENR2 b"
      then have "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M"
        using A1 A2 A3 xxreal_0_th_1 sorry
      then have A4: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        using rewrite1_lm_4 sorry
      have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        using A3 rewrite1_lm_3 sorry
      then have A5: "[TARSKIK4 a,p .FUNCT-1K1 \<two>\<^sub>M ] inHIDDENR3 R"
        using A1 A4 rewrite1_def_2 sorry
      thus "a inHIDDENR3 fieldRELAT-1K3 R"
        using relat_1_th_15 sorry
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 Lamb1 inTARSKIR2 fieldRELAT-1K3 R"
      have A6: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
        using finseq_5_th_6 sorry
      have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 i inTARSKIR2 fieldRELAT-1K3 R) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 fieldRELAT-1K3 R"
      proof(rule ballI,rule impMI ,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "i inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 i inTARSKIR2 fieldRELAT-1K3 R"
          and A7: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        have A8: "i <XXREAL-0R3 lenFINSEQ-1K4 p"
          using A7 rewrite1_lm_2 sorry
        show "p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 fieldRELAT-1K3 R"
        proof-
          have cases: "i =XBOOLE-0R4 0NUMBERSK6 or i >XXREAL-0R4 0NUMBERSK6"
             sorry
          have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 fieldRELAT-1K3 R"
          proof(rule impI)
            assume "i =XBOOLE-0R4 0NUMBERSK6"
            thus "p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 fieldRELAT-1K3 R"
              using A1 A5 relat_1_th_15 sorry
          qed
          have case2: "i >XXREAL-0R4 0NUMBERSK6 implies p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 fieldRELAT-1K3 R"
          proof(rule impI)
            assume "i >XXREAL-0R4 0NUMBERSK6"
            then have "i inTARSKIR2 domFINSEQ-1K5 p"
              using A8 rewrite1_lm_3 sorry
            then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
              using A7 rewrite1_def_2 sorry
            thus "p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 fieldRELAT-1K3 R"
              using relat_1_th_15 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      then have A9: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A10: "?P(0NUMBERSK6)"
        using rewrite1_lm_1 sorry
      have " for i be NatNAT-1M1 holds ?P(i)"
        using nat_1_sch_2 A10 A9 sorry
      thus "b inHIDDENR3 fieldRELAT-1K3 R"
        using A2 A6 sorry
    qed
    thus " not ((R reducesREWRITE1R1(a,b) &  not a <>HIDDENR2 b) &  not (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R))"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_19:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies (a inHIDDENR3 fieldRELAT-1K3 R iff b inHIDDENR3 fieldRELAT-1K3 R)"
  using rewrite1_th_18 sorry

mtheorem rewrite1_th_20:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff a =HIDDENR1 b or [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (R reducesREWRITE1R1(a,b) implies (a <>HIDDENR2 b implies [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19)) & ((a =HIDDENR1 b or [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19) &  not R reducesREWRITE1R1(a,b) implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    show "R reducesREWRITE1R1(a,b) implies (a <>HIDDENR2 b implies [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19)"
    proof(rule impI,rule impI)
      assume A1: "R reducesREWRITE1R1(a,b)"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A2: "a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
         sorry
      have A3: " for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume "i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p"
        then have "i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
          using rewrite1_lm_3 rewrite1_lm_4 sorry
        thus "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
          using rewrite1_def_2 sorry
      qed "sorry"
      assume "a <>HIDDENR2 b"
      then have A4: "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
        using A1 rewrite1_th_18 sorry
      have "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19"
        using A2 A4 A3 finseq_1_def_16 sorry
    qed
    assume A5: "a =HIDDENR1 b or [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19"
      and A6: " not R reducesREWRITE1R1(a,b)"
    obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M1" and 
      A7: "lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M"and A8: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"and A9: " for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <XXREAL-0R3 lenFINSEQ-1K4 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
      using A5 A6 rewrite1_th_12 finseq_1_def_16 sorry
    have "p be RedSequenceREWRITE1M1-of R"
    proof-
      have "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"
      proof(rule conjMI,rule ballI,rule impMI ,rule impI)
        show "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"
          using A7 sorry
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A10: "i inTARSKIR2 domFINSEQ-1K5 p"
          and A11: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        have "i >=XXREAL-0R2 \<one>\<^sub>M"
          using A10 rewrite1_lm_1 sorry
        thus "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
          using A9 A11 rewrite1_lm_2 sorry
      qed "sorry"
      thus "p be RedSequenceREWRITE1M1-of R"
        using rewrite1_def_2 sorry
    qed
    thus " False "
      using A6 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_21:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff R [*]FINSEQ-1K19 reducesREWRITE1R1(a,b)"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (R reducesREWRITE1R1(a,b) implies R [*]FINSEQ-1K19 reducesREWRITE1R1(a,b)) &  not (R [*]FINSEQ-1K19 reducesREWRITE1R1(a,b) &  not R reducesREWRITE1R1(a,b))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "R reducesREWRITE1R1(a,b) iff a =HIDDENR1 b or [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19"
      using rewrite1_th_20 sorry
    thus "R reducesREWRITE1R1(a,b) implies R [*]FINSEQ-1K19 reducesREWRITE1R1(a,b)"
      using rewrite1_th_12 rewrite1_th_15 sorry
    have "( ex p be RedSequenceREWRITE1M1-of R [*]FINSEQ-1K19 st a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p) implies R reducesREWRITE1R1(a,b)"
    proof(rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R [*]FINSEQ-1K19 st a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R [*]FINSEQ-1K19" and 
        A1: "a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"and A2: "b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
         sorry
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 Lamb1)"
      have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 i)) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impMI ,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A3: "i inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 i)"
          and A4: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        have A5: "i <XXREAL-0R3 lenFINSEQ-1K4 p"
          using A4 rewrite1_lm_2 sorry
        show "R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
        proof-
          have cases: "i =XBOOLE-0R4 0NUMBERSK6 or i >XXREAL-0R4 0NUMBERSK6"
             sorry
          have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
          proof(rule impI)
            assume "i =XBOOLE-0R4 0NUMBERSK6"
            thus "R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
              using A1 rewrite1_th_12 sorry
          qed
          have case2: "i >XXREAL-0R4 0NUMBERSK6 implies R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
          proof(rule impI)
            assume A6: "i >XXREAL-0R4 0NUMBERSK6"
            then have "i inTARSKIR2 domFINSEQ-1K5 p"
              using A5 rewrite1_lm_3 sorry
            then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R [*]FINSEQ-1K19"
              using A4 rewrite1_def_2 sorry
            then have "R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
              using rewrite1_th_20 sorry
            thus "R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
              using A3 A5 A6 rewrite1_lm_3 rewrite1_th_16 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      then have A7: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A8: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
        using finseq_5_th_6 sorry
      have A9: "?P(0NUMBERSK6)"
        using rewrite1_lm_1 sorry
      have " for i be NatNAT-1M1 holds ?P(i)"
        using nat_1_sch_2 A9 A7 sorry
      thus "R reducesREWRITE1R1(a,b)"
        using A2 A8 sorry
    qed
    thus " not (R [*]FINSEQ-1K19 reducesREWRITE1R1(a,b) &  not R reducesREWRITE1R1(a,b))"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_22:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R c=RELAT-1R2 Q implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies Q reducesREWRITE1R1(a,b))"
proof-
  have " for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R c=RELAT-1R2 Q implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not (R reducesREWRITE1R1(a,b) &  not Q reducesREWRITE1R1(a,b)))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    assume A1: "R c=RELAT-1R2 Q"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies Q reducesREWRITE1R1(a,b)"
    proof(rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A2: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      have Cut684: "p be RedSequenceREWRITE1M1-of Q"
        using A1 rewrite1_th_10 sorry
      have " ex p be RedSequenceREWRITE1M1-of Q st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      proof-
        show " ex p be RedSequenceREWRITE1M1-of Q st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
          using A2 Cut684 sorry
      qed
      thus "Q reducesREWRITE1R1(a,b)"
        using rewrite1_def_3 sorry
    qed
    thus " not (R reducesREWRITE1R1(a,b) &  not Q reducesREWRITE1R1(a,b))"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_23:
" for R be RelationRELAT-1M1 holds  for X be setHIDDENM2 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) iff R \\/XBOOLE-0K2 idRELAT-1K7 X reducesREWRITE1R1(a,b)"
proof-
  have " for R be RelationRELAT-1M1 holds  for X be setHIDDENM2 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (R reducesREWRITE1R1(a,b) implies R \\/XBOOLE-0K2 idRELAT-1K7 X reducesREWRITE1R1(a,b)) &  not (R \\/XBOOLE-0K2 idRELAT-1K7 X reducesREWRITE1R1(a,b) &  not R reducesREWRITE1R1(a,b))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    show "R reducesREWRITE1R1(a,b) implies R \\/XBOOLE-0K2 idRELAT-1K7 X reducesREWRITE1R1(a,b)"
      using rewrite1_th_22 xboole_1_th_7 sorry
    have "( ex p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 idRELAT-1K7 X st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies R reducesREWRITE1R1(a,b)"
    proof(rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 idRELAT-1K7 X st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 idRELAT-1K7 X" and 
        A1: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A2: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 Lamb1)"
      have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 i)) implies (i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)))"
      proof(rule ballI,rule impI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A3: "i inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 i)"
        assume A4: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        show "R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 p or  not i inTARSKIR2 domFINSEQ-1K5 p"
             sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
          proof(rule impI)
            assume A5: "i inTARSKIR2 domFINSEQ-1K5 p"
            then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 idRELAT-1K7 X"
              using A4 rewrite1_def_2 sorry
            then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R or [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 idRELAT-1K7 X"
              using xboole_0_def_3 sorry
            then have "R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) or p .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
              using rewrite1_th_15 relat_1_def_10 sorry
            thus "R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
              using A3 A5 rewrite1_th_16 sorry
          qed
          have case2: " not i inTARSKIR2 domFINSEQ-1K5 p implies R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
          proof(rule impI)
            assume " not i inTARSKIR2 domFINSEQ-1K5 p"
            then have "i <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M or i >XXREAL-0R4 lenFINSEQ-1K4 p & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using A4 rewrite1_lm_1 rewrite1_lm_3 sorry
            then have "i =XBOOLE-0R4 0NUMBERSK6"
              using nat_1_th_13 sorry
            thus "R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
              using A1 rewrite1_th_12 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      then have A6: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A7: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
        using rewrite1_lm_3 sorry
      have A8: "?P(0NUMBERSK6)"
        using rewrite1_lm_1 sorry
      have " for i be NatNAT-1M1 holds ?P(i)"
        using nat_1_sch_2 A8 A6 sorry
      thus "R reducesREWRITE1R1(a,b)"
        using A2 A7 sorry
    qed
    thus " not (R \\/XBOOLE-0K2 idRELAT-1K7 X reducesREWRITE1R1(a,b) &  not R reducesREWRITE1R1(a,b))"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_24:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies R ~RELAT-1K4 reducesREWRITE1R1(b,a)"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not (R reducesREWRITE1R1(a,b) &  not R ~RELAT-1K4 reducesREWRITE1R1(b,a))"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies R ~RELAT-1K4 reducesREWRITE1R1(b,a)"
    proof(rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A1: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A2: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      obtain q where 
        [ty]:"q be RedSequenceREWRITE1M1-of R ~RELAT-1K4" and qDef:"q = RevFINSEQ-5K3 p"
        using rewrite1_th_9 sorry
      have Cut737: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
        using finseq_5_th_6 sorry
      have "q .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 b & q .FUNCT-1K1 lenFINSEQ-1K4 q =HIDDENR1 a"
      proof(rule conjMI)
        have "q .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 p .FUNCT-1K1 ((lenFINSEQ-1K4 p -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)"
          using finseq_5_def_3 Cut737 sorry
        also have "... = b"
          using A2 sorry
        finally show "q .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 b"
           sorry
        have "lenFINSEQ-1K4 q inTARSKIR2 domFINSEQ-1K5 q & lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p"
          using finseq_5_th_6 finseq_5_def_3 sorry
        then have "q .FUNCT-1K1 lenFINSEQ-1K4 q =HIDDENR1 p .FUNCT-1K1 ((lenFINSEQ-1K4 p -XCMPLX-0K6 lenFINSEQ-1K4 p)+XCMPLX-0K2 \<one>\<^sub>M)"
          using finseq_5_def_3 sorry
        also have "... = a"
          using A1 sorry
        finally show "q .FUNCT-1K1 lenFINSEQ-1K4 q =HIDDENR1 a"
           sorry
      qed
      thus "R ~RELAT-1K4 reducesREWRITE1R1(b,a)"
        using bexI[of _ "q"] rewrite1_def_3 sorry
    qed
    thus " not (R reducesREWRITE1R1(a,b) &  not R ~RELAT-1K4 reducesREWRITE1R1(b,a))"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rewrite1_lm_5:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (b,a)are-convertible-wrtREWRITE1R2 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (b,a)are-convertible-wrtREWRITE1R2 R)"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b) implies (b,a)are-convertible-wrtREWRITE1R2 R"
    proof(rule impI)
      assume "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b)"
      then have "(R \\/XBOOLE-0K2 R ~RELAT-1K4)~RELAT-1K4 reducesREWRITE1R1(b,a)"
        using rewrite1_th_24 sorry
      then have Cut753: "R ~RELAT-1K4 \\/XBOOLE-0K2 (R ~RELAT-1K4)~RELAT-1K4 reducesREWRITE1R1(b,a)"
        using relat_1_th_23 sorry
      have "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(b,a)"
      proof-
        show "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(b,a)"
          using Cut753 sorry
      qed
      thus "(b,a)are-convertible-wrtREWRITE1R2 R"
        using rewrite1_def_4 sorry
    qed
    thus " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (b,a)are-convertible-wrtREWRITE1R2 R)"
      using rewrite1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_25:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies (a,b)are-convertible-wrtREWRITE1R2 R & (b,a)are-convertible-wrtREWRITE1R2 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not (R reducesREWRITE1R1(a,b) &  not ((a,b)are-convertible-wrtREWRITE1R2 R & (b,a)are-convertible-wrtREWRITE1R2 R))"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies (a,b)are-convertible-wrtREWRITE1R2 R & (b,a)are-convertible-wrtREWRITE1R2 R"
    proof(rule impI,rule conjMI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A1: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      have "p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 R ~RELAT-1K4"
      proof-
        have "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4)"
        proof(rule conjMI,rule ballI,rule impI)
          show "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"
             sorry
          fix i assume [ty]: "i be NatNAT-1M1"
          assume "i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
          then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
            using rewrite1_def_2 sorry
          thus "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 R ~RELAT-1K4"
          using rewrite1_def_2 sorry
      qed
      then have "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b)"
        using A1 sorry
      thus "(a,b)are-convertible-wrtREWRITE1R2 R"
         sorry
      thus "(b,a)are-convertible-wrtREWRITE1R2 R"
        using rewrite1_lm_5 sorry
    qed
    thus " not (R reducesREWRITE1R1(a,b) &  not ((a,b)are-convertible-wrtREWRITE1R2 R & (b,a)are-convertible-wrtREWRITE1R2 R))"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_26:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds (a,a)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_th_12 sorry

mtheorem rewrite1_th_27:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 {}XBOOLE-0K1 implies a =HIDDENR1 b"
  using rewrite1_th_13 sorry

mtheorem rewrite1_th_28:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R &  not a inHIDDENR3 fieldRELAT-1K3 R implies a =HIDDENR1 b"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not (((a,b)are-convertible-wrtREWRITE1R2 R &  not a inHIDDENR3 fieldRELAT-1K3 R) &  not a =HIDDENR1 b)"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have A1: "fieldRELAT-1K3 R =XBOOLE-0R4 fieldRELAT-1K3 (R ~RELAT-1K4) & fieldRELAT-1K3 (R \\/XBOOLE-0K2 R ~RELAT-1K4) =XBOOLE-0R4 fieldRELAT-1K3 R \\/XBOOLE-0K2 fieldRELAT-1K3 (R ~RELAT-1K4)"
      using relat_1_th_18 relat_1_th_21 sorry
    have "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b) implies  not ( not a inHIDDENR3 fieldRELAT-1K3 R &  not a =HIDDENR1 b)"
    proof(rule impI)
      assume "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b)"
      thus " not ( not a inHIDDENR3 fieldRELAT-1K3 R &  not a =HIDDENR1 b)"
        using A1 rewrite1_th_14 sorry
    qed
    thus " not (((a,b)are-convertible-wrtREWRITE1R2 R &  not a inHIDDENR3 fieldRELAT-1K3 R) &  not a =HIDDENR1 b)"
      using rewrite1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_29:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  assume "[TARSKIK4 a,b ] inHIDDENR3 R"
  then have "R reducesREWRITE1R1(a,b)"
    using rewrite1_th_15 sorry
  thus "(a,b)are-convertible-wrtREWRITE1R2 R"
    using rewrite1_th_25 sorry
qed "sorry"

mtheorem rewrite1_th_30:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R & (b,c)are-convertible-wrtREWRITE1R2 R implies (a,c)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_th_16 sorry

mtheorem rewrite1_th_31:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (b,a)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_lm_5 sorry

mtheorem rewrite1_th_32:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R & a <>HIDDENR2 b implies a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not (((a,b)are-convertible-wrtREWRITE1R2 R &  not a <>HIDDENR2 b) &  not (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R))"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have A1: "fieldRELAT-1K3 (R \\/XBOOLE-0K2 R ~RELAT-1K4) =HIDDENR1 fieldRELAT-1K3 R \\/XBOOLE-0K2 fieldRELAT-1K3 (R ~RELAT-1K4)"
      using relat_1_th_18 sorry
    also have "... = fieldRELAT-1K3 R \\/XBOOLE-0K2 fieldRELAT-1K3 R"
      using relat_1_th_21 sorry
    also have "... = fieldRELAT-1K3 R"
       sorry
    finally have "fieldRELAT-1K3 (R \\/XBOOLE-0K2 R ~RELAT-1K4) =HIDDENR1 fieldRELAT-1K3 R"
       sorry
    have "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b) implies  not ( not a <>HIDDENR2 b &  not (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R))"
    proof(rule impI)
      assume "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b)"
      thus " not ( not a <>HIDDENR2 b &  not (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R))"
        using A1 rewrite1_th_18 sorry
    qed
    thus " not (((a,b)are-convertible-wrtREWRITE1R2 R &  not a <>HIDDENR2 b) &  not (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R))"
      using rewrite1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rewrite1_def_5 (" _ is-a-normal-form-wrtREWRITE1R3  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1"
"pred a is-a-normal-form-wrtREWRITE1R3 R means
   not ( ex b be objectHIDDENM1 st [TARSKIK4 a,b ] inHIDDENR3 R)"..

mtheorem rewrite1_th_33:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a is-a-normal-form-wrtREWRITE1R3 R & R reducesREWRITE1R1(a,b) implies a =HIDDENR1 b"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a is-a-normal-form-wrtREWRITE1R3 R & R reducesREWRITE1R1(a,b)) &  not a =HIDDENR1 b)"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have " not ( ex b be objectHIDDENM1 st [TARSKIK4 a,b ] inHIDDENR3 R) implies (R reducesREWRITE1R1(a,b) implies a =HIDDENR1 b)"
    proof(rule impI,rule impI)
      assume A1: " not ( ex b be objectHIDDENM1 st [TARSKIK4 a,b ] inHIDDENR3 R)"
      assume "R reducesREWRITE1R1(a,b)"
      then obtain p where
        [ty]:"p be FinSequenceFINSEQ-1M1" and 
        A2: "lenFINSEQ-1K4 p >XXREAL-0R4 0NUMBERSK6"and A3: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A4: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"and A5: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
        using rewrite1_th_11 sorry
      have A6: "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M implies  False "
      proof(rule impI)
        assume "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M"
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
          using rewrite1_lm_3 rewrite1_lm_4 sorry
        then have "[TARSKIK4 a,p .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
          using A3 A5 sorry
        thus " False "
          using A1 sorry
      qed
      have "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using A2 nat_1_th_13 sorry
      thus "a =HIDDENR1 b"
        using A3 A4 A6 xxreal_0_th_1 sorry
    qed
    thus " not ((a is-a-normal-form-wrtREWRITE1R3 R & R reducesREWRITE1R1(a,b)) &  not a =HIDDENR1 b)"
      using rewrite1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_34:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  not a inHIDDENR3 fieldRELAT-1K3 R implies a is-a-normal-form-wrtREWRITE1R3 R"
  using relat_1_th_15 sorry

mdef rewrite1_def_6 (" _ is-a-normal-form-ofREWRITE1R4'( _ , _ ')" [50,0,0]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred b is-a-normal-form-ofREWRITE1R4(a,R) means
  b is-a-normal-form-wrtREWRITE1R3 R & R reducesREWRITE1R1(a,b)"..

mdef rewrite1_def_7 ("'( _ , _ ')are-convergent-wrtREWRITE1R5  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-convergent-wrtREWRITE1R5 R means
   ex c be objectHIDDENM1 st R reducesREWRITE1R1(a,c) & R reducesREWRITE1R1(b,c)"..

mdef rewrite1_def_8 ("'( _ , _ ')are-divergent-wrtREWRITE1R6  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-divergent-wrtREWRITE1R6 R means
   ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"..

mdef rewrite1_def_9 ("'( _ , _ ')are-convergent<=1-wrtREWRITE1R7  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-convergent<=1-wrtREWRITE1R7 R means
   ex c be objectHIDDENM1 st ([TARSKIK4 a,c ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 b,c ] inHIDDENR3 R or b =HIDDENR1 c)"..

mdef rewrite1_def_10 ("'( _ , _ ')are-divergent<=1-wrtREWRITE1R8  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-divergent<=1-wrtREWRITE1R8 R means
   ex c be objectHIDDENM1 st ([TARSKIK4 c,a ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 c,b ] inHIDDENR3 R or b =HIDDENR1 c)"..

mtheorem rewrite1_th_35:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  not a inHIDDENR3 fieldRELAT-1K3 R implies a is-a-normal-form-ofREWRITE1R4(a,R)"
  using rewrite1_th_12 rewrite1_th_34 sorry

mtheorem rewrite1_th_36:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) implies (((a,b)are-convergent-wrtREWRITE1R5 R & (a,b)are-divergent-wrtREWRITE1R6 R) & (b,a)are-convergent-wrtREWRITE1R5 R) & (b,a)are-divergent-wrtREWRITE1R6 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not (R reducesREWRITE1R1(a,b) &  not ((((a,b)are-convergent-wrtREWRITE1R5 R & (a,b)are-divergent-wrtREWRITE1R6 R) & (b,a)are-convergent-wrtREWRITE1R5 R) & (b,a)are-divergent-wrtREWRITE1R6 R))"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "R reducesREWRITE1R1(a,a) & R reducesREWRITE1R1(b,b)"
      using rewrite1_th_12 sorry
    thus " not (R reducesREWRITE1R1(a,b) &  not ((((a,b)are-convergent-wrtREWRITE1R5 R & (a,b)are-divergent-wrtREWRITE1R6 R) & (b,a)are-convergent-wrtREWRITE1R5 R) & (b,a)are-divergent-wrtREWRITE1R6 R))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_37:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent-wrtREWRITE1R5 R or (a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  assume A1: "(a,b)are-convergent-wrtREWRITE1R5 R or (a,b)are-divergent-wrtREWRITE1R6 R"
  show "(a,b)are-convertible-wrtREWRITE1R2 R"
  proof-
    have cases: "(a,b)are-convergent-wrtREWRITE1R5 R or (a,b)are-divergent-wrtREWRITE1R6 R"
      using A1 sorry
    have case1: "(a,b)are-convergent-wrtREWRITE1R5 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
    proof(rule impI)
      assume "(a,b)are-convergent-wrtREWRITE1R5 R"
      then obtain c where
        [ty]:"c be objectHIDDENM1" and 
        A2: "R reducesREWRITE1R1(a,c) & R reducesREWRITE1R1(b,c)"
         sorry
      have "(a,c)are-convertible-wrtREWRITE1R2 R & (c,b)are-convertible-wrtREWRITE1R2 R"
        using A2 rewrite1_th_25 sorry
      thus "(a,b)are-convertible-wrtREWRITE1R2 R"
        using rewrite1_th_30 sorry
    qed
    have case2: "(a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
    proof(rule impI)
      assume "(a,b)are-divergent-wrtREWRITE1R6 R"
      then obtain c where
        [ty]:"c be objectHIDDENM1" and 
        A3: "R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"
         sorry
      have "(c,b)are-convertible-wrtREWRITE1R2 R & (a,c)are-convertible-wrtREWRITE1R2 R"
        using A3 rewrite1_th_25 sorry
      thus "(a,b)are-convertible-wrtREWRITE1R2 R"
        using rewrite1_th_30 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem rewrite1_th_38:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds (a,a)are-convergent-wrtREWRITE1R5 R & (a,a)are-divergent-wrtREWRITE1R6 R"
  using rewrite1_th_12 sorry

mtheorem rewrite1_th_39:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 or (a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1 implies a =HIDDENR1 b"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  have A1: "(a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 implies  not ( not ( not (a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 &  not (a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1) &  not a =HIDDENR1 b)"
  proof(rule impI)
    assume "(a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1"
    then obtain c where
      [ty]:"c be objectHIDDENM1" and 
      A2: "{}XBOOLE-0K1 reducesREWRITE1R1(a,c)"and A3: "{}XBOOLE-0K1 reducesREWRITE1R1(b,c)"
       sorry
    have "a =HIDDENR1 c"
      using A2 rewrite1_th_13 sorry
    thus " not ( not ( not (a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 &  not (a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1) &  not a =HIDDENR1 b)"
      using A3 rewrite1_th_13 sorry
  qed
  have A4: "(a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1 implies  not ( not ( not (a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 &  not (a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1) &  not a =HIDDENR1 b)"
  proof(rule impI)
    assume "(a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1"
    then obtain c where
      [ty]:"c be objectHIDDENM1" and 
      A5: "{}XBOOLE-0K1 reducesREWRITE1R1(c,a)"and A6: "{}XBOOLE-0K1 reducesREWRITE1R1(c,b)"
       sorry
    have "a =HIDDENR1 c"
      using A5 rewrite1_th_13 sorry
    thus " not ( not ( not (a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 &  not (a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1) &  not a =HIDDENR1 b)"
      using A6 rewrite1_th_13 sorry
  qed
  assume "(a,b)are-convergent-wrtREWRITE1R5 {}XBOOLE-0K1 or (a,b)are-divergent-wrtREWRITE1R6 {}XBOOLE-0K1"
  thus "a =HIDDENR1 b"
    using A1 A4 sorry
qed "sorry"

mtheorem rewrite1_th_40:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent-wrtREWRITE1R5 R implies (b,a)are-convergent-wrtREWRITE1R5 R"
   sorry

mtheorem rewrite1_th_41:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent-wrtREWRITE1R6 R implies (b,a)are-divergent-wrtREWRITE1R6 R"
   sorry

mtheorem rewrite1_th_42:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & (b,c)are-convergent-wrtREWRITE1R5 R or (a,b)are-convergent-wrtREWRITE1R5 R & R reducesREWRITE1R1(c,b) implies (a,c)are-convergent-wrtREWRITE1R5 R"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  fix c assume [ty]: "c be objectHIDDENM1"
  assume A1: "R reducesREWRITE1R1(a,b) & (b,c)are-convergent-wrtREWRITE1R5 R or (a,b)are-convergent-wrtREWRITE1R5 R & R reducesREWRITE1R1(c,b)"
  show "(a,c)are-convergent-wrtREWRITE1R5 R"
  proof-
    have cases: "R reducesREWRITE1R1(a,b) & (b,c)are-convergent-wrtREWRITE1R5 R or (a,b)are-convergent-wrtREWRITE1R5 R & R reducesREWRITE1R1(c,b)"
      using A1 sorry
    have case1: "R reducesREWRITE1R1(a,b) & (b,c)are-convergent-wrtREWRITE1R5 R implies (a,c)are-convergent-wrtREWRITE1R5 R"
    proof(rule impI)
      assume A2: "R reducesREWRITE1R1(a,b) & (b,c)are-convergent-wrtREWRITE1R5 R"
      then obtain d where
        [ty]:"d be objectHIDDENM1" and 
        A3: "R reducesREWRITE1R1(b,d)"and A4: "R reducesREWRITE1R1(c,d)"
         sorry
      have "R reducesREWRITE1R1(a,d)"
        using A2 A3 rewrite1_th_16 sorry
      thus "(a,c)are-convergent-wrtREWRITE1R5 R"
        using A4 sorry
    qed
    have case2: "(a,b)are-convergent-wrtREWRITE1R5 R & R reducesREWRITE1R1(c,b) implies (a,c)are-convergent-wrtREWRITE1R5 R"
    proof(rule impI)
      assume A5: "(a,b)are-convergent-wrtREWRITE1R5 R & R reducesREWRITE1R1(c,b)"
      then obtain d where
        [ty]:"d be objectHIDDENM1" and 
        A6: "R reducesREWRITE1R1(a,d)"and A7: "R reducesREWRITE1R1(b,d)"
         sorry
      have "R reducesREWRITE1R1(c,d)"
        using A5 A7 rewrite1_th_16 sorry
      thus "(a,c)are-convergent-wrtREWRITE1R5 R"
        using A6 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem rewrite1_th_43:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(b,a) & (b,c)are-divergent-wrtREWRITE1R6 R or (a,b)are-divergent-wrtREWRITE1R6 R & R reducesREWRITE1R1(b,c) implies (a,c)are-divergent-wrtREWRITE1R6 R"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  fix c assume [ty]: "c be objectHIDDENM1"
  assume A1: "R reducesREWRITE1R1(b,a) & (b,c)are-divergent-wrtREWRITE1R6 R or (a,b)are-divergent-wrtREWRITE1R6 R & R reducesREWRITE1R1(b,c)"
  show "(a,c)are-divergent-wrtREWRITE1R6 R"
  proof-
    have cases: "R reducesREWRITE1R1(b,a) & (b,c)are-divergent-wrtREWRITE1R6 R or (a,b)are-divergent-wrtREWRITE1R6 R & R reducesREWRITE1R1(b,c)"
      using A1 sorry
    have case1: "R reducesREWRITE1R1(b,a) & (b,c)are-divergent-wrtREWRITE1R6 R implies (a,c)are-divergent-wrtREWRITE1R6 R"
    proof(rule impI)
      assume A2: "R reducesREWRITE1R1(b,a) & (b,c)are-divergent-wrtREWRITE1R6 R"
      then obtain d where
        [ty]:"d be objectHIDDENM1" and 
        A3: "R reducesREWRITE1R1(d,b)"and A4: "R reducesREWRITE1R1(d,c)"
         sorry
      have "R reducesREWRITE1R1(d,a)"
        using A2 A3 rewrite1_th_16 sorry
      thus "(a,c)are-divergent-wrtREWRITE1R6 R"
        using A4 sorry
    qed
    have case2: "(a,b)are-divergent-wrtREWRITE1R6 R & R reducesREWRITE1R1(b,c) implies (a,c)are-divergent-wrtREWRITE1R6 R"
    proof(rule impI)
      assume A5: "(a,b)are-divergent-wrtREWRITE1R6 R & R reducesREWRITE1R1(b,c)"
      then obtain d where
        [ty]:"d be objectHIDDENM1" and 
        A6: "R reducesREWRITE1R1(d,a)"and A7: "R reducesREWRITE1R1(d,b)"
         sorry
      have "R reducesREWRITE1R1(d,c)"
        using A5 A7 rewrite1_th_16 sorry
      thus "(a,c)are-divergent-wrtREWRITE1R6 R"
        using A6 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem rewrite1_th_44:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convergent<=1-wrtREWRITE1R7 R implies (a,b)are-convergent-wrtREWRITE1R5 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convergent<=1-wrtREWRITE1R7 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex c be objectHIDDENM1 st ([TARSKIK4 a,c ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 b,c ] inHIDDENR3 R or b =HIDDENR1 c)) implies (a,b)are-convergent-wrtREWRITE1R5 R"
    proof(rule impI)
      assume Given: " ex c be objectHIDDENM1 st ([TARSKIK4 a,c ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 b,c ] inHIDDENR3 R or b =HIDDENR1 c)"
      then obtain c where
        [ty]:"c be objectHIDDENM1" and 
        A1: "([TARSKIK4 a,c ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 b,c ] inHIDDENR3 R or b =HIDDENR1 c)"
         sorry
      have "R reducesREWRITE1R1(a,c) & R reducesREWRITE1R1(b,c)"
      proof-
        show "R reducesREWRITE1R1(a,c) & R reducesREWRITE1R1(b,c)"
          using A1 rewrite1_th_12 rewrite1_th_15 sorry
      qed
      thus "(a,b)are-convergent-wrtREWRITE1R5 R"
        using bexI[of _ "c"] rewrite1_def_7 sorry
    qed
    thus " not ((a,b)are-convergent<=1-wrtREWRITE1R7 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
      using rewrite1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_45:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent<=1-wrtREWRITE1R8 R implies (a,b)are-divergent-wrtREWRITE1R6 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-divergent<=1-wrtREWRITE1R8 R &  not (a,b)are-divergent-wrtREWRITE1R6 R)"
  proof(rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "( ex c be objectHIDDENM1 st ([TARSKIK4 c,a ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 c,b ] inHIDDENR3 R or b =HIDDENR1 c)) implies (a,b)are-divergent-wrtREWRITE1R6 R"
    proof(rule impI)
      assume Given: " ex c be objectHIDDENM1 st ([TARSKIK4 c,a ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 c,b ] inHIDDENR3 R or b =HIDDENR1 c)"
      then obtain c where
        [ty]:"c be objectHIDDENM1" and 
        A1: "([TARSKIK4 c,a ] inHIDDENR3 R or a =HIDDENR1 c) & ([TARSKIK4 c,b ] inHIDDENR3 R or b =HIDDENR1 c)"
         sorry
      have "R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"
      proof-
        show "R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"
          using A1 rewrite1_th_12 rewrite1_th_15 sorry
      qed
      thus "(a,b)are-divergent-wrtREWRITE1R6 R"
        using bexI[of _ "c"] rewrite1_def_8 sorry
    qed
    thus " not ((a,b)are-divergent<=1-wrtREWRITE1R8 R &  not (a,b)are-divergent-wrtREWRITE1R6 R)"
      using rewrite1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rewrite1_def_11 (" _ has-a-normal-form-wrtREWRITE1R9  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1"
"pred a has-a-normal-form-wrtREWRITE1R9 R means
   ex b be objectHIDDENM1 st b is-a-normal-form-ofREWRITE1R4(a,R)"..

mtheorem rewrite1_th_46:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  not a inHIDDENR3 fieldRELAT-1K3 R implies a has-a-normal-form-wrtREWRITE1R9 R"
  using rewrite1_th_35 sorry

mdef rewrite1_def_12 ("nfREWRITE1K2'( _ , _ ')" [0,0]164 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1"
"assume a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c) func nfREWRITE1K2(a,R) \<rightarrow> setHIDDENM2 means
  \<lambda>it. it is-a-normal-form-ofREWRITE1R4(a,R)"
proof-
  (*existence*)
    show "a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c) implies ( ex it be setHIDDENM2 st it is-a-normal-form-ofREWRITE1R4(a,R))"
    proof(rule impI)
      assume Assume: "a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c)"
      have A1: "a has-a-normal-form-wrtREWRITE1R9 R"
        using Assume sorry
      have A2: " for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c"
        using Assume sorry
      show " ex it be setHIDDENM2 st it is-a-normal-form-ofREWRITE1R4(a,R)"
      proof-
        have " not ( for VarFor1 be setHIDDENM2 holds  not VarFor1 is-a-normal-form-ofREWRITE1R4(a,R))"
        proof-
          obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A3: "x is-a-normal-form-ofREWRITE1R4(a,R)"
            using A1 sorry
          have "x be setHIDDENM2"
            using tarski_th_1 sorry
          thus " not ( for VarFor1 be setHIDDENM2 holds  not VarFor1 is-a-normal-form-ofREWRITE1R4(a,R))"
            using A3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c) implies ( for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds it1 is-a-normal-form-ofREWRITE1R4(a,R) & it2 is-a-normal-form-ofREWRITE1R4(a,R) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "a has-a-normal-form-wrtREWRITE1R9 R & ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c)"
      have A1: "a has-a-normal-form-wrtREWRITE1R9 R"
        using Assume sorry
      have A2: " for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c"
        using Assume sorry
      show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds it1 is-a-normal-form-ofREWRITE1R4(a,R) & it2 is-a-normal-form-ofREWRITE1R4(a,R) implies it1 =HIDDENR1 it2"
        using A2 sorry
    qed
qed "sorry"

(*begin*)
mdef rewrite1_def_13 ("co-well-foundedREWRITE1V1" 70 ) where
"attr co-well-foundedREWRITE1V1 for RelationRELAT-1M1 means
  (\<lambda>R. R ~RELAT-1K4 be well-foundedWELLORD1V1)"..

mdef rewrite1_def_14 ("weakly-normalizingREWRITE1V2" 70 ) where
"attr weakly-normalizingREWRITE1V2 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies a has-a-normal-form-wrtREWRITE1R9 R)"..

mdef rewrite1_def_15 ("strongly-normalizingREWRITE1V3" 70 ) where
"attr strongly-normalizingREWRITE1V3 for RelationRELAT-1M1 means
  (\<lambda>R.  for f be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  ex i be NatNAT-1M1 st  not [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R)"..

abbreviation(input) REWRITE1V4("co-well-foundedREWRITE1V4" 70) where
  "co-well-foundedREWRITE1V4 \<equiv> co-well-foundedREWRITE1V1"

mtheorem rewrite1_def_16:
  mlet "R be RelationRELAT-1M1"
"redefine attr co-well-foundedREWRITE1V4 for RelationRELAT-1M1 means
  (\<lambda>R.  for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R)))"
proof
(*compatibility*)
  show " for R be RelationRELAT-1M1 holds R be co-well-foundedREWRITE1V4 iff ( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R)))"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be co-well-foundedREWRITE1V4 iff ( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R)))"
    proof-
      have "(R be co-well-foundedREWRITE1V1 implies ( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y implies (a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))))) & (( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))) implies R be co-well-foundedREWRITE1V1)"
      proof(rule conjMI)
        have A1: "fieldRELAT-1K3 R =XBOOLE-0R4 fieldRELAT-1K3 (R ~RELAT-1K4)"
          using relat_1_th_21 sorry
        show "R be co-well-foundedREWRITE1V1 implies ( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y implies (a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))))"
        proof(rule impI,rule ballI,rule impI)
          assume "R be co-well-foundedREWRITE1V1"
          then have A2: "R ~RELAT-1K4 be well-foundedWELLORD1V1"
             sorry
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume "Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1"
          then obtain a where
            [ty]:"a be objectHIDDENM1" and 
            A3: "a inHIDDENR3 Y"and A4: "(R ~RELAT-1K4)-SegWELLORD1K1 a missesXBOOLE-0R1 Y"
            using A1 A2 sorry
          show " ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y implies (a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))"
          proof(rule bexI[of _ "a"],rule conjMI,rule ballI,rule impI)
            show "a inHIDDENR3 Y"
              using A3 sorry
            fix b assume [ty]: "b be objectHIDDENM1"
            assume "b inHIDDENR3 Y"
            then have " not b inHIDDENR3 (R ~RELAT-1K4)-SegWELLORD1K1 a"
              using A4 xboole_0_th_3 sorry
            then have "a =HIDDENR1 b or  not [TARSKIK4 b,a ] inHIDDENR3 R ~RELAT-1K4"
              using wellord1_th_1 sorry
            thus "a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R"
              using relat_1_def_7 sorry
          qed "sorry"
        qed "sorry"
        show "( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))) implies R be co-well-foundedREWRITE1V1"
        proof(rule impI)
          assume A5: " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))"
          have "R ~RELAT-1K4 be well-foundedWELLORD1V1"
          proof-
            have " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 (R ~RELAT-1K4) & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar14 be objectHIDDENM1 st tVar14 inHIDDENR3 Y & (R ~RELAT-1K4)-SegWELLORD1K1 tVar14 missesXBOOLE-0R1 Y)"
            proof(rule ballI,rule impI)
              fix Y assume [ty]: "Y be setHIDDENM2"
              assume "Y c=TARSKIR1 fieldRELAT-1K3 (R ~RELAT-1K4) & Y <>HIDDENR2 {}XBOOLE-0K1"
              then obtain a where
                [ty]:"a be objectHIDDENM1" and 
                A6: "a inHIDDENR3 Y"and A7: " for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R"
                using A1 A5 sorry
              show " ex tVar14 be objectHIDDENM1 st tVar14 inHIDDENR3 Y & (R ~RELAT-1K4)-SegWELLORD1K1 tVar14 missesXBOOLE-0R1 Y"
              proof(rule bexI[of _ "a"],rule conjMI)
                show "a inHIDDENR3 Y"
                  using A6 sorry
                have "(R ~RELAT-1K4)-SegWELLORD1K1 a /\\XBOOLE-0K3 Y be  non emptyXBOOLE-0V1 implies  False "
                proof(rule impI)
                  assume "(R ~RELAT-1K4)-SegWELLORD1K1 a /\\XBOOLE-0K3 Y be  non emptyXBOOLE-0V1"
                  then obtain A where 
                    [ty]:"A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and ADef:"A = (R ~RELAT-1K4)-SegWELLORD1K1 a /\\XBOOLE-0K3 Y"
                     sorry
                  let ?x = "the ElementSUBSET-1M1-of A"
                  have A8: "?x inTARSKIR2 (R ~RELAT-1K4)-SegWELLORD1K1 a"
                    using xboole_0_def_4 sorry
                  then have "?x inTARSKIR2 Y & ?x <>HIDDENR2 a"
                    using wellord1_th_1 xboole_0_def_4 sorry
                  then have A9: " not [TARSKIK4 a,?x ] inHIDDENR3 R"
                    using A7 sorry
                  have "[TARSKIK4 ?x,a ] inHIDDENR3 R ~RELAT-1K4"
                    using A8 wellord1_th_1 sorry
                  thus " False "
                    using A9 relat_1_def_7 sorry
                qed
                thus "(R ~RELAT-1K4)-SegWELLORD1K1 a missesXBOOLE-0R1 Y"
                  using xboole_0_def_7 sorry
              qed "sorry"
            qed "sorry"
            thus "R ~RELAT-1K4 be well-foundedWELLORD1V1"
              using wellord1_def_2 sorry
          qed
          thus "R be co-well-foundedREWRITE1V1"
             sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

theorem rewrite1_sch_2:
  fixes Rf0 Pp1 
  assumes
[ty]: "Rf0 be RelationRELAT-1M1" and
   A1: "Rf0 be co-well-foundedREWRITE1V4" and
   A2: " for a be objectHIDDENM1 holds ( for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Rf0 & a <>HIDDENR2 b implies Pp1(b)) implies Pp1(a)"
  shows " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 Rf0 implies Pp1(a)"
  proof-
    have "( ex a be objectHIDDENM1 st a inHIDDENR3 fieldRELAT-1K3 Rf0 &  not Pp1(a)) implies  not  True "
    proof(rule impI)
      assume Given: " ex a be objectHIDDENM1 st a inHIDDENR3 fieldRELAT-1K3 Rf0 &  not Pp1(a)"
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A3: "a inHIDDENR3 fieldRELAT-1K3 Rf0"and A4: " not Pp1(a)"
         sorry
      obtain X where 
        [ty]:"X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and XDef:"X = fieldRELAT-1K3 Rf0"
        using A3 sorry
      have 
        [ty]:"a be ElementSUBSET-1M1-of X"
        using A3 sorry
      let ?Y = "{x where x be ElementSUBSET-1M1-of X :  not Pp1(x) }"
      have A5: "a inTARSKIR2 ?Y"
        using A4 sorry
      have "?Y c=TARSKIR1 fieldRELAT-1K3 Rf0"
      proof-
        have "{x where x be ElementSUBSET-1M1-of X :  not Pp1(x) } c=TARSKIR1 fieldRELAT-1K3 Rf0"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {x where x be ElementSUBSET-1M1-of X :  not Pp1(x) } implies y inHIDDENR3 fieldRELAT-1K3 Rf0"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 ?Y"
            then have " ex x be ElementSUBSET-1M1-of X st y =HIDDENR1 x &  not Pp1(x)"
               sorry
            thus "y inHIDDENR3 fieldRELAT-1K3 Rf0"
               sorry
          qed "sorry"
          thus "{x where x be ElementSUBSET-1M1-of X :  not Pp1(x) } c=TARSKIR1 fieldRELAT-1K3 Rf0"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A6: "a inHIDDENR3 ?Y"and A7: " for b be objectHIDDENM1 holds b inHIDDENR3 ?Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 Rf0"
        using A1 A5 sorry
      have A8: " for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 Rf0 & a <>HIDDENR2 b) &  not Pp1(b) implies  False "
      proof(rule ballI,rule impMI ,rule impI)
        fix b assume [ty]: "b be objectHIDDENM1"
        assume A9: "[TARSKIK4 a,b ] inHIDDENR3 Rf0 & a <>HIDDENR2 b"
          and A10: " not Pp1(b)"
        have " not b inHIDDENR3 ?Y & b inHIDDENR3 X"
          using A7 A9 relat_1_th_15 sorry
        thus " False "
          using A10 sorry
      qed "sorry"
      have " ex x be ElementSUBSET-1M1-of X st a =HIDDENR1 x &  not Pp1(x)"
        using A6 sorry
      thus " not  True "
        using A2 A8 sorry
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem rewrite1_cl_2:
"cluster strongly-normalizingREWRITE1V3 also-is irreflexiveRELAT-2V2\<bar>co-well-foundedREWRITE1V4 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be strongly-normalizingREWRITE1V3 implies it be irreflexiveRELAT-2V2\<bar>co-well-foundedREWRITE1V4"
  proof-
    have " for R be RelationRELAT-1M1 holds  not (R be strongly-normalizingREWRITE1V3 &  not (R be irreflexiveRELAT-2V2 & R be co-well-foundedREWRITE1V4))"
    proof(rule ballI)
      let ?Q = "\<lambda>Lamb1.  not  False "
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "( for f be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  ex i be NatNAT-1M1 st  not [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R) implies R be irreflexiveRELAT-2V2 & R be co-well-foundedREWRITE1V4"
      proof(rule impI,rule conjMI)
        assume A1: " for f be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  ex i be NatNAT-1M1 st  not [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
        show "R be irreflexiveRELAT-2V2"
        proof-
          have "( ex x be objectHIDDENM1 st x inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 x,x ] inHIDDENR3 R) implies  False "
          proof(rule impI)
            assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 x,x ] inHIDDENR3 R"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              "x inHIDDENR3 fieldRELAT-1K3 R"and A2: "[TARSKIK4 x,x ] inHIDDENR3 R"
               sorry
            have "domRELAT-1K1 (NATNUMBERSK1 -->FUNCOP-1K7 x) =XBOOLE-0R4 NATNUMBERSK1"
              using funcop_1_th_13 sorry
            then obtain f where 
              [ty]:"f be ManySortedSetPBOOLEM1-of NATNUMBERSK1" and fDef:"f = NATNUMBERSK1 -->FUNCOP-1K7 x"
              using partfun1_def_2 relat_1_def_18 sorry
            obtain i where
              [ty]:"i be NatNAT-1M1" and 
              A3: " not [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
              using A1 sorry
            have "i inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have "f .FUNCT-1K1 i =HIDDENR1 x"
              using funcop_1_th_7 sorry
            thus " False "
              using A2 A3 funcop_1_th_7 sorry
          qed
          thus "R be irreflexiveRELAT-2V2"
            using relat_2_def_2 relat_2_def_10 sorry
        qed
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. [TARSKIK4 Lamb1,Lamb2 ] inHIDDENR3 R"
        have " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & (Y <>HIDDENR2 {}XBOOLE-0K1 & ( for a be objectHIDDENM1 holds a inHIDDENR3 Y implies ( ex b be objectHIDDENM1 st (b inHIDDENR3 Y & a <>HIDDENR2 b) & [TARSKIK4 a,b ] inHIDDENR3 R))) implies  not  True "
        proof(rule ballI,rule impMI ,rule impMI ,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume "Y c=TARSKIR1 fieldRELAT-1K3 R"
            and A4: "Y <>HIDDENR2 {}XBOOLE-0K1"
            and A5: " for a be objectHIDDENM1 holds a inHIDDENR3 Y implies ( ex b be objectHIDDENM1 st (b inHIDDENR3 Y & a <>HIDDENR2 b) & [TARSKIK4 a,b ] inHIDDENR3 R)"
          have 
            [ty]:"Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
            using A4 sorry
          have " for x be setHIDDENM2 holds x inTARSKIR2 Y implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be setHIDDENM2"
            assume "x inTARSKIR2 Y"
            then have " ex b be objectHIDDENM1 st (b inHIDDENR3 Y & x <>HIDDENR2 b) & [TARSKIK4 x,b ] inHIDDENR3 R"
              using A5 sorry
            thus " ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 R"
               sorry
          qed "sorry"
          then have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 Y & ?Q(x) implies ( ex y be objectHIDDENM1 st (y inHIDDENR3 Y & ?P(x,y)) & ?Q(y))"
             sorry
          let ?y = "the ElementSUBSET-1M1-of Y"
          have A7: "?y inTARSKIR2 Y & ?Q(?y)"
             sorry
          obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A8: "(domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & rngRELAT-1K2 f c=TARSKIR1 Y) & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 ?y"and A9: " for k be NatNAT-1M1 holds ?P(f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & ?Q(f .FUNCT-1K1 k)"
            using trees_2_sch_5 A7 A6 sorry
          have "f be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
            using A8 partfun1_def_2 relat_1_def_18 sorry
          thus " not  True "
            using A1 A9 sorry
        qed "sorry"
        thus "R be co-well-foundedREWRITE1V4"
          using rewrite1_def_16 sorry
      qed
      thus " not (R be strongly-normalizingREWRITE1V3 &  not (R be irreflexiveRELAT-2V2 & R be co-well-foundedREWRITE1V4))"
        using rewrite1_def_15 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_cl_3:
"cluster co-well-foundedREWRITE1V4\<bar>irreflexiveRELAT-2V2 also-is strongly-normalizingREWRITE1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be co-well-foundedREWRITE1V4\<bar>irreflexiveRELAT-2V2 implies it be strongly-normalizingREWRITE1V3"
  proof-
    have " for R be RelationRELAT-1M1 holds  not ((R be co-well-foundedREWRITE1V4 & R be irreflexiveRELAT-2V2) &  not R be strongly-normalizingREWRITE1V3)"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "( for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))) implies  not (R be irreflexiveRELAT-2V2 &  not R be strongly-normalizingREWRITE1V3)"
      proof(rule impI)
        assume A10: " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex a be objectHIDDENM1 st a inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R))"
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 x,x ] inHIDDENR3 R) implies R be strongly-normalizingREWRITE1V3"
        proof(rule impI)
          assume A11: " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R implies  not [TARSKIK4 x,x ] inHIDDENR3 R"
          have " for f be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds ( for i be NatNAT-1M1 holds [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R) implies  False "
          proof(rule ballI,rule impI)
            fix f assume [ty]: "f be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
            assume A12: " for i be NatNAT-1M1 holds [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
            have A13: "rngRELAT-1K2 f c=TARSKIR1 fieldRELAT-1K3 R"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 f implies y inHIDDENR3 fieldRELAT-1K3 R"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume "y inHIDDENR3 rngRELAT-1K2 f"
                then obtain x where
                  [ty]:"x be objectHIDDENM1" and 
                  A14: "x inHIDDENR3 domRELAT-1K1 f"and A15: "y =HIDDENR1 f .FUNCT-1K1 x"
                  using funct_1_def_3 sorry
                have 
                  [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using A14 partfun1_def_2 sorry
                have "[TARSKIK4 y,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
                  using A12 A15 sorry
                thus "y inHIDDENR3 fieldRELAT-1K3 R"
                  using relat_1_th_15 sorry
              qed "sorry"
              thus "rngRELAT-1K2 f c=TARSKIR1 fieldRELAT-1K3 R"
                using tarski_def_3 sorry
            qed
            have A16: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
              using partfun1_def_2 sorry
            then have "f .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 rngRELAT-1K2 f"
              using funct_1_def_3 sorry
            then obtain a where
              [ty]:"a be objectHIDDENM1" and 
              A17: "a inHIDDENR3 rngRELAT-1K2 f"and A18: " for b be objectHIDDENM1 holds b inHIDDENR3 rngRELAT-1K2 f & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 R"
              using A10 A13 sorry
            obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A19: "x inHIDDENR3 domRELAT-1K1 f"and A20: "a =HIDDENR1 f .FUNCT-1K1 x"
              using A17 funct_1_def_3 sorry
            have 
              [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A19 partfun1_def_2 sorry
            have A21: "f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngRELAT-1K2 f"
              using A16 funct_1_def_3 sorry
            have A22: "[TARSKIK4 a,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
              using A12 A20 sorry
            then have "a <>HIDDENR2 f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M)"
              using A11 A13 A17 sorry
            thus " False "
              using A18 A22 A21 sorry
          qed "sorry"
          thus "R be strongly-normalizingREWRITE1V3"
            using rewrite1_def_15 sorry
        qed
        thus " not (R be irreflexiveRELAT-2V2 &  not R be strongly-normalizingREWRITE1V3)"
          using relat_2_def_2 relat_2_def_10 sorry
      qed
      thus " not ((R be co-well-foundedREWRITE1V4 & R be irreflexiveRELAT-2V2) &  not R be strongly-normalizingREWRITE1V3)"
        using rewrite1_def_16 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_cl_4:
"cluster emptyXBOOLE-0V1 also-is weakly-normalizingREWRITE1V2\<bar>strongly-normalizingREWRITE1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be weakly-normalizingREWRITE1V2\<bar>strongly-normalizingREWRITE1V3"
    using relat_1_th_40 sorry
qed "sorry"

mtheorem rewrite1_th_47:
" for Q be co-well-foundedREWRITE1V4\<bar>RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds R c=RELAT-1R2 Q implies R be co-well-foundedREWRITE1V4"
proof(rule ballI,rule ballI,rule impI)
  fix Q assume [ty]: "Q be co-well-foundedREWRITE1V4\<bar>RelationRELAT-1M1"
  fix R assume [ty]: "R be RelationRELAT-1M1"
  assume A1: "R c=RELAT-1R2 Q"
  have " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar15 be objectHIDDENM1 st tVar15 inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & tVar15 <>HIDDENR2 b implies  not [TARSKIK4 tVar15,b ] inHIDDENR3 R))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A2: "Y c=TARSKIR1 fieldRELAT-1K3 R"
      and A3: "Y <>HIDDENR2 {}XBOOLE-0K1"
    have "fieldRELAT-1K3 R c=TARSKIR1 fieldRELAT-1K3 Q"
      using A1 relat_1_th_16 sorry
    then have "Y c=TARSKIR1 fieldRELAT-1K3 Q"
      using A2 sorry
    then obtain a where
      [ty]:"a be objectHIDDENM1" and 
      A4: "a inHIDDENR3 Y"and A5: " for b be objectHIDDENM1 holds b inHIDDENR3 Y & a <>HIDDENR2 b implies  not [TARSKIK4 a,b ] inHIDDENR3 Q"
      using A3 rewrite1_def_16 sorry
    show " ex tVar15 be objectHIDDENM1 st tVar15 inHIDDENR3 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & tVar15 <>HIDDENR2 b implies  not [TARSKIK4 tVar15,b ] inHIDDENR3 R)"
    proof(rule bexI[of _ "a"],rule conjMI,rule ballI,rule impI)
      show "a inHIDDENR3 Y"
        using A4 sorry
      fix b assume [ty]: "b be objectHIDDENM1"
      assume "b inHIDDENR3 Y & a <>HIDDENR2 b"
      thus " not [TARSKIK4 a,b ] inHIDDENR3 R"
        using A1 A5 sorry
    qed "sorry"
  qed "sorry"
  thus "R be co-well-foundedREWRITE1V4"
    using rewrite1_def_16 sorry
qed "sorry"

mtheorem rewrite1_cl_5:
"cluster strongly-normalizingREWRITE1V3 also-is weakly-normalizingREWRITE1V2 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be strongly-normalizingREWRITE1V3 implies it be weakly-normalizingREWRITE1V2"
  proof-
    have " for R be RelationRELAT-1M1 holds R be strongly-normalizingREWRITE1V3 implies R be weakly-normalizingREWRITE1V2"
    proof(rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume A1: "R be strongly-normalizingREWRITE1V3"
      have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies a has-a-normal-form-wrtREWRITE1R9 R"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A2: "a inHIDDENR3 fieldRELAT-1K3 R"
        then obtain X where 
          [ty]:"X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and XDef:"X = fieldRELAT-1K3 R"
           sorry
        let ?Y = "{x where x be ElementSUBSET-1M1-of X : R reducesREWRITE1R1(a,x) }"
        have A3: "?Y c=TARSKIR1 fieldRELAT-1K3 R"
        proof-
          have "{x where x be ElementSUBSET-1M1-of X : R reducesREWRITE1R1(a,x) } c=TARSKIR1 fieldRELAT-1K3 R"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 {x where x be ElementSUBSET-1M1-of X : R reducesREWRITE1R1(a,x) } implies y inHIDDENR3 fieldRELAT-1K3 R"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 ?Y"
              then have " ex x be ElementSUBSET-1M1-of X st y =HIDDENR1 x & R reducesREWRITE1R1(a,x)"
                 sorry
              thus "y inHIDDENR3 fieldRELAT-1K3 R"
                 sorry
            qed "sorry"
            thus "{x where x be ElementSUBSET-1M1-of X : R reducesREWRITE1R1(a,x) } c=TARSKIR1 fieldRELAT-1K3 R"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "R reducesREWRITE1R1(a,a)"
          using rewrite1_th_12 sorry
        then have "a inHIDDENR3 ?Y"
          using A2 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A4: "x inHIDDENR3 ?Y"and A5: " for b be objectHIDDENM1 holds b inHIDDENR3 ?Y & x <>HIDDENR2 b implies  not [TARSKIK4 x,b ] inHIDDENR3 R"
          using A1 A3 rewrite1_def_16 sorry
        have A6: " ex y be ElementSUBSET-1M1-of X st x =HIDDENR1 y & R reducesREWRITE1R1(a,y)"
          using A4 sorry
        have "(( ex b be objectHIDDENM1 st [TARSKIK4 x,b ] inHIDDENR3 R) implies  False ) & R reducesREWRITE1R1(a,x)"
        proof(rule conjMI)
          show "( ex b be objectHIDDENM1 st [TARSKIK4 x,b ] inHIDDENR3 R) implies  False "
          proof(rule impI)
            have "R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R"
              using A1 relat_2_def_10 sorry
            then have A7: " not [TARSKIK4 x,x ] inHIDDENR3 R"
              using A3 A4 sorry
            assume Given: " ex b be objectHIDDENM1 st [TARSKIK4 x,b ] inHIDDENR3 R"
            then obtain b where
              [ty]:"b be objectHIDDENM1" and 
              A8: "[TARSKIK4 x,b ] inHIDDENR3 R"
               sorry
            have "R reducesREWRITE1R1(x,b)"
              using A8 rewrite1_th_15 sorry
            then have A9: "R reducesREWRITE1R1(a,b)"
              using A6 rewrite1_th_16 sorry
            have "b inHIDDENR3 X"
              using A8 relat_1_th_15 sorry
            then have "b inHIDDENR3 ?Y"
              using A9 sorry
            thus " False "
              using A5 A8 A7 sorry
          qed
          show "R reducesREWRITE1R1(a,x)"
            using A6 sorry
        qed
        then have "x is-a-normal-form-ofREWRITE1R4(a,R)"
          using rewrite1_def_5 rewrite1_def_6 sorry
        thus "a has-a-normal-form-wrtREWRITE1R9 R"
          using bexI[of _ "x"] rewrite1_def_11 sorry
      qed "sorry"
      thus "R be weakly-normalizingREWRITE1V2"
        using rewrite1_def_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
mdef rewrite1_def_17 (" _ commutes-weakly-withREWRITE1R10  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "Q be RelationRELAT-1M1"
"pred R commutes-weakly-withREWRITE1R10 Q means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 Q implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"..

mtheorem REWRITE1R10_symmetry:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R commutes-weakly-withREWRITE1R10 Q implies Q commutes-weakly-withREWRITE1R10 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 Q implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))) implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Q & [TARSKIK4 a,c ] inHIDDENR3 R implies ( ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & Q reducesREWRITE1R1(c,d)))"
  proof-
    have " for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 Q implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))) implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Q & [TARSKIK4 a,c ] inHIDDENR3 R implies  not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & Q reducesREWRITE1R1(c,d))))"
    proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      fix Q assume [ty]: "Q be RelationRELAT-1M1"
      assume A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 Q implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "[TARSKIK4 a,b ] inHIDDENR3 Q & [TARSKIK4 a,c ] inHIDDENR3 R"
      then have " ex d be objectHIDDENM1 st Q reducesREWRITE1R1(c,d) & R reducesREWRITE1R1(b,d)"
        using A1 sorry
      thus " not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & Q reducesREWRITE1R1(c,d)))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using rewrite1_def_17 sorry
qed

mdef rewrite1_def_18 (" _ commutes-withREWRITE1R11  _ " [50,50]50 ) where
  mlet "R be RelationRELAT-1M1", "Q be RelationRELAT-1M1"
"pred R commutes-withREWRITE1R11 Q means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"..

mtheorem REWRITE1R11_symmetry:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R commutes-withREWRITE1R11 Q implies Q commutes-withREWRITE1R11 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))) implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds Q reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & Q reducesREWRITE1R1(c,d)))"
  proof-
    have " for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))) implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds Q reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c) implies  not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & Q reducesREWRITE1R1(c,d))))"
    proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      fix Q assume [ty]: "Q be RelationRELAT-1M1"
      assume A2: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "Q reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c)"
      then have " ex d be objectHIDDENM1 st Q reducesREWRITE1R1(c,d) & R reducesREWRITE1R1(b,d)"
        using A2 sorry
      thus " not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & Q reducesREWRITE1R1(c,d)))"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using rewrite1_def_18 sorry
qed

mtheorem rewrite1_th_48:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds R commutes-withREWRITE1R11 Q implies R commutes-weakly-withREWRITE1R10 Q"
proof-
  have " for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  not (R commutes-withREWRITE1R11 Q &  not R commutes-weakly-withREWRITE1R10 Q)"
  proof(rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be RelationRELAT-1M1"
    have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))) implies R commutes-weakly-withREWRITE1R10 Q"
    proof(rule impI)
      assume A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 Q implies  not ( for d be objectHIDDENM1 holds  not (Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)))"
      proof(rule ballI,rule ballI,rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        fix c assume [ty]: "c be objectHIDDENM1"
        assume "[TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 Q"
        then have "R reducesREWRITE1R1(a,b) & Q reducesREWRITE1R1(a,c)"
          using rewrite1_th_15 sorry
        thus " not ( for d be objectHIDDENM1 holds  not (Q reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)))"
          using A1 sorry
      qed "sorry"
      thus "R commutes-weakly-withREWRITE1R10 Q"
        using rewrite1_def_17 sorry
    qed
    thus " not (R commutes-withREWRITE1R11 Q &  not R commutes-weakly-withREWRITE1R10 Q)"
      using rewrite1_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rewrite1_def_19 ("with-UN-propertyREWRITE1V5" 70 ) where
"attr with-UN-propertyREWRITE1V5 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a is-a-normal-form-wrtREWRITE1R3 R & b is-a-normal-form-wrtREWRITE1R3 R) & (a,b)are-convertible-wrtREWRITE1R2 R implies a =HIDDENR1 b)"..

mdef rewrite1_def_20 ("with-NF-propertyREWRITE1V6" 70 ) where
"attr with-NF-propertyREWRITE1V6 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a is-a-normal-form-wrtREWRITE1R3 R & (a,b)are-convertible-wrtREWRITE1R2 R implies R reducesREWRITE1R1(b,a))"..

mdef rewrite1_def_21 ("subcommutativeREWRITE1V7" 70 ) where
"attr subcommutativeREWRITE1V7 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent<=1-wrtREWRITE1R7 R)"..

mdef rewrite1_def_22 ("confluentREWRITE1V8" 70 ) where
"attr confluentREWRITE1V8 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convergent-wrtREWRITE1R5 R)"..

mdef rewrite1_def_23 ("with-Church-Rosser-propertyREWRITE1V9" 70 ) where
"attr with-Church-Rosser-propertyREWRITE1V9 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convergent-wrtREWRITE1R5 R)"..

mdef rewrite1_def_24 ("locally-confluentREWRITE1V10" 70 ) where
"attr locally-confluentREWRITE1V10 for RelationRELAT-1M1 means
  (\<lambda>R.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"..

mtheorem rewrite1_th_49:
" for R be RelationRELAT-1M1 holds R be subcommutativeREWRITE1V7 implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"
proof-
  have " for R be RelationRELAT-1M1 holds R be subcommutativeREWRITE1V7 implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not ((R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R) &  not (b,c)are-convergent-wrtREWRITE1R5 R))"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R be subcommutativeREWRITE1V7"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix c assume [ty]: "c be objectHIDDENM1"
    have "( ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies ([TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"
    proof(rule impI,rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of R st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of R" and 
        A2: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A3: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
         sorry
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies ( ex d be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 Lamb1,d ] inHIDDENR3 R or p .FUNCT-1K1 Lamb1 =HIDDENR1 d) & R reducesREWRITE1R1(c,d))"
      assume A4: "[TARSKIK4 a,c ] inHIDDENR3 R"
      have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies ?P(i)) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies (i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( ex d be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d) & R reducesREWRITE1R1(c,d)))"
      proof(rule ballI,rule impMI ,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A5: "i inTARSKIR2 domFINSEQ-1K5 p implies ?P(i)"
          and A6: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        show "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( ex d be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d) & R reducesREWRITE1R1(c,d))"
        proof-
          have cases: "i =XBOOLE-0R4 0NUMBERSK6 or i >XXREAL-0R4 0NUMBERSK6"
             sorry
          have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies (i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( ex d be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d) & R reducesREWRITE1R1(c,d)))"
          proof(rule impI)
            assume A7: "i =XBOOLE-0R4 0NUMBERSK6"
            have "R reducesREWRITE1R1(c,c)"
              using rewrite1_th_12 sorry
            thus "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( ex d be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d) & R reducesREWRITE1R1(c,d))"
              using A2 A4 A7 sorry
          qed
          have case2: "i >XXREAL-0R4 0NUMBERSK6 implies (i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( ex d be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d) & R reducesREWRITE1R1(c,d)))"
          proof(rule impI)
            assume A8: "i >XXREAL-0R4 0NUMBERSK6"
            have A9: "i <XXREAL-0R3 lenFINSEQ-1K4 p"
              using A6 rewrite1_lm_2 sorry
            then obtain d where
              [ty]:"d be objectHIDDENM1" and 
              A10: "[TARSKIK4 p .FUNCT-1K1 i,d ] inHIDDENR3 R or p .FUNCT-1K1 i =HIDDENR1 d"and A11: "R reducesREWRITE1R1(c,d)"
              using A5 A8 rewrite1_lm_3 sorry
            have "i inTARSKIR2 domFINSEQ-1K5 p"
              using A8 A9 rewrite1_lm_3 sorry
            then have A12: "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
              using A6 rewrite1_def_2 sorry
            have A13: "[TARSKIK4 p .FUNCT-1K1 i,d ] inHIDDENR3 R implies ( ex e be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 e) & R reducesREWRITE1R1(c,e))"
            proof(rule impI)
              assume "[TARSKIK4 p .FUNCT-1K1 i,d ] inHIDDENR3 R"
              then have "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d)are-convergent<=1-wrtREWRITE1R7 R"
                using A1 A12 sorry
              then obtain e where
                [ty]:"e be objectHIDDENM1" and 
                A14: "[TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 e"and A15: "[TARSKIK4 d,e ] inHIDDENR3 R or d =HIDDENR1 e"
                 sorry
              show " ex e be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 e) & R reducesREWRITE1R1(c,e)"
              proof(rule bexI[of _ "e"],rule conjMI)
                show "[TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 e"
                  using A14 sorry
                have "R reducesREWRITE1R1(d,e)"
                  using A15 rewrite1_th_12 rewrite1_th_15 sorry
                thus "R reducesREWRITE1R1(c,e)"
                  using A11 rewrite1_th_16 sorry
              qed "sorry"
            qed
            have "p .FUNCT-1K1 i =HIDDENR1 d implies R reducesREWRITE1R1(c,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
            proof(rule impI)
              assume "p .FUNCT-1K1 i =HIDDENR1 d"
              then have "R reducesREWRITE1R1(d,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
                using A12 rewrite1_th_15 sorry
              thus "R reducesREWRITE1R1(c,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
                using A11 rewrite1_th_16 sorry
            qed
            thus "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( ex d be objectHIDDENM1 st ([TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d ] inHIDDENR3 R or p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d) & R reducesREWRITE1R1(c,d))"
              using A10 A13 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      then have A16: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A17: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
        using finseq_5_th_6 sorry
      have A18: "?P(0NUMBERSK6)"
        using rewrite1_lm_1 sorry
      have " for i be NatNAT-1M1 holds ?P(i)"
        using nat_1_sch_2 A18 A16 sorry
      then obtain d where
        [ty]:"d be objectHIDDENM1" and 
        A19: "([TARSKIK4 b,d ] inHIDDENR3 R or b =HIDDENR1 d) & R reducesREWRITE1R1(c,d)"
        using A3 A17 sorry
      have "R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)"
      proof-
        show "R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)"
          using A19 rewrite1_th_12 rewrite1_th_15 sorry
      qed
      thus "(b,c)are-convergent-wrtREWRITE1R5 R"
        using bexI[of _ "d"] rewrite1_def_7 sorry
    qed
    thus " not ((R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R) &  not (b,c)are-convergent-wrtREWRITE1R5 R)"
      using rewrite1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_50:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff R commutes-withREWRITE1R11 R"
proof-
  have " for R be RelationRELAT-1M1 holds (R be confluentREWRITE1V8 implies R commutes-withREWRITE1R11 R) &  not (R commutes-withREWRITE1R11 R &  not R be confluentREWRITE1V8)"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be confluentREWRITE1V8 implies R commutes-withREWRITE1R11 R"
    proof(rule impI)
      assume A1: "R be confluentREWRITE1V8"
      show "R commutes-withREWRITE1R11 R"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c) implies  not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)))"
        proof(rule ballI,rule ballI,rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c)"
          then have "(b,c)are-divergent-wrtREWRITE1R6 R"
             sorry
          then have "(b,c)are-convergent-wrtREWRITE1R5 R"
            using A1 sorry
          thus " not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)))"
             sorry
        qed "sorry"
        thus "R commutes-withREWRITE1R11 R"
          using rewrite1_def_18 sorry
      qed
    qed
    have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))) implies R be confluentREWRITE1V8"
    proof(rule impI)
      assume A2: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c) implies ( ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
      proof(rule ballI,rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        have "( ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)) implies (a,b)are-convergent-wrtREWRITE1R5 R"
        proof(rule impI)
          assume Cut1501: " ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"
          have " ex d be objectHIDDENM1 st R reducesREWRITE1R1(a,d) & R reducesREWRITE1R1(b,d)"
          proof-
            show " ex d be objectHIDDENM1 st R reducesREWRITE1R1(a,d) & R reducesREWRITE1R1(b,d)"
              using A2 Cut1501 sorry
          qed
          thus "(a,b)are-convergent-wrtREWRITE1R5 R"
            using rewrite1_def_7 sorry
        qed
        thus " not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
          using rewrite1_def_8 sorry
      qed "sorry"
      thus "R be confluentREWRITE1V8"
        using rewrite1_def_22 sorry
    qed
    thus " not (R commutes-withREWRITE1R11 R &  not R be confluentREWRITE1V8)"
      using rewrite1_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_51:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"
proof-
  have " for R be RelationRELAT-1M1 holds (R be confluentREWRITE1V8 implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)) & (( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R) implies R be confluentREWRITE1V8)"
  proof(rule ballI,rule conjMI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be confluentREWRITE1V8 implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R)"
    proof(rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume A1: "R be confluentREWRITE1V8"
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "R reducesREWRITE1R1(a,b)"
        and A3: "[TARSKIK4 a,c ] inHIDDENR3 R"
      have "R reducesREWRITE1R1(a,c)"
        using A3 rewrite1_th_15 sorry
      then have "(b,c)are-divergent-wrtREWRITE1R6 R"
        using A2 sorry
      thus "(b,c)are-convergent-wrtREWRITE1R5 R"
        using A1 sorry
    qed "sorry"
    assume A4: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R"
    have " for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not ((b,c)are-divergent-wrtREWRITE1R6 R &  not (b,c)are-convergent-wrtREWRITE1R5 R)"
    proof(rule ballI,rule ballI)
      fix b assume [ty]: "b be objectHIDDENM1"
      fix c assume [ty]: "c be objectHIDDENM1"
      have "( ex a be objectHIDDENM1 st R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c)) implies (b,c)are-convergent-wrtREWRITE1R5 R"
      proof(rule impI)
        assume Given: " ex a be objectHIDDENM1 st R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c)"
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A5: "R reducesREWRITE1R1(a,b)"and A6: "R reducesREWRITE1R1(a,c)"
           sorry
        obtain p where
          [ty]:"p be RedSequenceREWRITE1M1-of R" and 
          A7: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A8: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
          using A5 sorry
        obtain q where
          [ty]:"q be RedSequenceREWRITE1M1-of R" and 
          A9: "q .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A10: "q .FUNCT-1K1 lenFINSEQ-1K4 q =HIDDENR1 c"
          using A6 sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (p .FUNCT-1K1 Lamb1,q .FUNCT-1K1 Lamb2)are-convergent-wrtREWRITE1R5 R"
        let ?Q = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies ( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 q implies ?P(Lamb1,j))"
        have A11: " for i be NatNAT-1M1 holds ?Q(i) implies ?Q(i +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies ( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 q implies (p .FUNCT-1K1 i,q .FUNCT-1K1 j)are-convergent-wrtREWRITE1R5 R)) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies ( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 q implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 j)are-convergent-wrtREWRITE1R5 R)"
          proof(rule ballI,rule impMI ,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume "i inTARSKIR2 domFINSEQ-1K5 p implies ( for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 q implies ?P(i,j))"
              and A12: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
            let ?R = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 q implies ?P(i +NAT-1K1 \<one>\<^sub>M,Lamb1)"
            have A13: " for j be NatNAT-1M1 holds ?R(j) implies ?R(j +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have " for j be NatNAT-1M1 holds (j inTARSKIR2 domFINSEQ-1K5 q implies ?P(i +NAT-1K1 \<one>\<^sub>M,j)) & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
              proof(rule ballI,rule impMI ,rule impI)
                have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                  using finseq_5_th_6 sorry
                then have A14: "R reducesREWRITE1R1(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
                  using A7 A12 rewrite1_th_17 nat_1_th_11 sorry
                fix j assume [ty]: "j be NatNAT-1M1"
                assume A15: "j inTARSKIR2 domFINSEQ-1K5 q implies ?P(i +NAT-1K1 \<one>\<^sub>M,j)"
                  and A16: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
                show "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                proof-
                  have cases: "j =XBOOLE-0R4 0NUMBERSK6 or j >XXREAL-0R4 0NUMBERSK6"
                     sorry
                  have case1: "j =XBOOLE-0R4 0NUMBERSK6 implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                  proof(rule impI)
                    assume "j =XBOOLE-0R4 0NUMBERSK6"
                    thus "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                      using A9 A14 rewrite1_th_36 sorry
                  qed
                  have case2: "j >XXREAL-0R4 0NUMBERSK6 implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                  proof(rule impI)
                    assume A17: "j >XXREAL-0R4 0NUMBERSK6"
                    have A18: "j <XXREAL-0R3 lenFINSEQ-1K4 q"
                      using A16 rewrite1_lm_2 sorry
                    then obtain d where
                      [ty]:"d be objectHIDDENM1" and 
                      A19: "R reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),d)"and A20: "R reducesREWRITE1R1(q .FUNCT-1K1 j,d)"
                      using A15 A17 rewrite1_def_7 rewrite1_lm_3 sorry
                    have "j inTARSKIR2 domFINSEQ-1K5 q"
                      using A17 A18 rewrite1_lm_3 sorry
                    then have "[TARSKIK4 q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R"
                      using A16 rewrite1_def_2 sorry
                    then have "(d,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                      using A4 A20 sorry
                    thus "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                      using A19 rewrite1_th_42 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have A21: "?R(0NUMBERSK6)"
              using rewrite1_lm_1 sorry
            show " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 q implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),q .FUNCT-1K1 j)are-convergent-wrtREWRITE1R5 R"
              using nat_1_sch_2 A21 A13 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A22: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p & lenFINSEQ-1K4 q inTARSKIR2 domFINSEQ-1K5 q"
          using finseq_5_th_6 sorry
        have A23: "?Q(0NUMBERSK6)"
          using rewrite1_lm_1 sorry
        have " for i be NatNAT-1M1 holds ?Q(i)"
          using nat_1_sch_2 A23 A11 sorry
        thus "(b,c)are-convergent-wrtREWRITE1R5 R"
          using A8 A10 A22 sorry
      qed
      thus " not ((b,c)are-divergent-wrtREWRITE1R6 R &  not (b,c)are-convergent-wrtREWRITE1R5 R)"
        using rewrite1_def_8 sorry
    qed "sorry"
    thus "R be confluentREWRITE1V8"
      using rewrite1_def_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_52:
" for R be RelationRELAT-1M1 holds R be locally-confluentREWRITE1V10 iff R commutes-weakly-withREWRITE1R10 R"
proof-
  have " for R be RelationRELAT-1M1 holds (R be locally-confluentREWRITE1V10 implies R commutes-weakly-withREWRITE1R10 R) &  not (R commutes-weakly-withREWRITE1R10 R &  not R be locally-confluentREWRITE1V10)"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be locally-confluentREWRITE1V10 implies R commutes-weakly-withREWRITE1R10 R"
    proof(rule impI)
      assume A1: "R be locally-confluentREWRITE1V10"
      show "R commutes-weakly-withREWRITE1R10 R"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies  not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)))"
        proof(rule ballI,rule ballI,rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "[TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R"
          then have "(b,c)are-convergent-wrtREWRITE1R5 R"
            using A1 sorry
          thus " not ( for d be objectHIDDENM1 holds  not (R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)))"
             sorry
        qed "sorry"
        thus "R commutes-weakly-withREWRITE1R10 R"
          using rewrite1_def_17 sorry
      qed
    qed
    have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies ( ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))) implies R be locally-confluentREWRITE1V10"
    proof(rule impI)
      assume A2: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies ( ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d))"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R"
      proof(rule ballI,rule ballI,rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        fix c assume [ty]: "c be objectHIDDENM1"
        assume Cut1599: "[TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R"
        have " ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)"
        proof-
          show " ex d be objectHIDDENM1 st R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)"
            using A2 Cut1599 sorry
        qed
        thus "(b,c)are-convergent-wrtREWRITE1R5 R"
          using rewrite1_def_7 sorry
      qed "sorry"
      thus "R be locally-confluentREWRITE1V10"
        using rewrite1_def_24 sorry
    qed
    thus " not (R commutes-weakly-withREWRITE1R10 R &  not R be locally-confluentREWRITE1V10)"
      using rewrite1_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_cl_6:
"cluster with-Church-Rosser-propertyREWRITE1V9 also-is confluentREWRITE1V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-Church-Rosser-propertyREWRITE1V9 implies it be confluentREWRITE1V8"
  proof-
    have " for R be RelationRELAT-1M1 holds  not (R be with-Church-Rosser-propertyREWRITE1V9 &  not R be confluentREWRITE1V8)"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convergent-wrtREWRITE1R5 R) implies R be confluentREWRITE1V8"
      proof(rule impI)
        assume A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convergent-wrtREWRITE1R5 R"
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convergent-wrtREWRITE1R5 R"
        proof(rule ballI,rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          assume "(a,b)are-divergent-wrtREWRITE1R6 R"
          then have "(a,b)are-convertible-wrtREWRITE1R2 R"
            using rewrite1_th_37 sorry
          thus "(a,b)are-convergent-wrtREWRITE1R5 R"
            using A1 sorry
        qed "sorry"
        thus "R be confluentREWRITE1V8"
          using rewrite1_def_22 sorry
      qed
      thus " not (R be with-Church-Rosser-propertyREWRITE1V9 &  not R be confluentREWRITE1V8)"
        using rewrite1_def_23 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_cl_7:
"cluster confluentREWRITE1V8 also-is locally-confluentREWRITE1V10\<bar>with-Church-Rosser-propertyREWRITE1V9 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be confluentREWRITE1V8 implies it be locally-confluentREWRITE1V10\<bar>with-Church-Rosser-propertyREWRITE1V9"
  proof-
    have " for R be RelationRELAT-1M1 holds  not (R be confluentREWRITE1V8 &  not (R be locally-confluentREWRITE1V10 & R be with-Church-Rosser-propertyREWRITE1V9))"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convergent-wrtREWRITE1R5 R) implies R be locally-confluentREWRITE1V10 & R be with-Church-Rosser-propertyREWRITE1V9"
      proof(rule impI)
        assume A2: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-divergent-wrtREWRITE1R6 R implies (a,b)are-convergent-wrtREWRITE1R5 R"
        have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R) & R be with-Church-Rosser-propertyREWRITE1V9"
        proof(rule conjMI)
          show " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R"
          proof(rule ballI,rule ballI,rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            fix b assume [ty]: "b be objectHIDDENM1"
            fix c assume [ty]: "c be objectHIDDENM1"
            assume "[TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R"
            then have "R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c)"
              using rewrite1_th_15 sorry
            then have "(b,c)are-divergent-wrtREWRITE1R6 R"
               sorry
            thus "(b,c)are-convergent-wrtREWRITE1R5 R"
              using A2 sorry
          qed "sorry"
          have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
          proof(rule ballI,rule ballI)
            fix a assume [ty]: "a be objectHIDDENM1"
            fix b assume [ty]: "b be objectHIDDENM1"
            have "( ex p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 R ~RELAT-1K4 st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b) implies (a,b)are-convergent-wrtREWRITE1R5 R"
            proof(rule impI)
              assume Given: " ex p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 R ~RELAT-1K4 st p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a & p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
              then obtain p where
                [ty]:"p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 R ~RELAT-1K4" and 
                A3: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a"and A4: "p .FUNCT-1K1 lenFINSEQ-1K4 p =HIDDENR1 b"
                 sorry
              let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 Lamb1)are-convergent-wrtREWRITE1R5 R"
              have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 i)are-convergent-wrtREWRITE1R5 R) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
              proof(rule ballI,rule impMI ,rule impI)
                fix i assume [ty]: "i be NatNAT-1M1"
                assume A5: "i inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 i)are-convergent-wrtREWRITE1R5 R"
                  and A6: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                show "(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                proof-
                  have cases: "i inTARSKIR2 domFINSEQ-1K5 p or  not i inTARSKIR2 domFINSEQ-1K5 p"
                     sorry
                  have case1: "i inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                  proof(rule impI)
                    assume A7: "i inTARSKIR2 domFINSEQ-1K5 p"
                    then obtain c where
                      [ty]:"c be objectHIDDENM1" and 
                      A8: "R reducesREWRITE1R1(a,c)"and A9: "R reducesREWRITE1R1(p .FUNCT-1K1 i,c)"
                      using A5 sorry
                    have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 R ~RELAT-1K4"
                      using A6 A7 rewrite1_def_2 sorry
                    then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R or [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R ~RELAT-1K4"
                      using xboole_0_def_3 sorry
                    then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R or [TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 i ] inHIDDENR3 R"
                      using relat_1_def_7 sorry
                    then have "R reducesREWRITE1R1(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) or R reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 i)"
                      using rewrite1_th_15 sorry
                    then have "(c,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-divergent-wrtREWRITE1R6 R or R reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),c)"
                      using A9 rewrite1_th_16 sorry
                    then have "(c,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R or (a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                      using A2 A8 sorry
                    thus "(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                      using A8 rewrite1_th_42 sorry
                  qed
                  have case2: " not i inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                  proof(rule impI)
                    assume " not i inTARSKIR2 domFINSEQ-1K5 p"
                    then have "i <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M or i >XXREAL-0R4 lenFINSEQ-1K4 p & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
                      using A6 rewrite1_lm_1 rewrite1_lm_3 sorry
                    then have "i =XBOOLE-0R4 0NUMBERSK6"
                      using nat_1_th_13 sorry
                    thus "(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                      using A3 rewrite1_th_38 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              then have A10: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have A11: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
                using finseq_5_th_6 sorry
              have A12: "?P(0NUMBERSK6)"
                using rewrite1_lm_1 sorry
              have " for i be NatNAT-1M1 holds ?P(i)"
                using nat_1_sch_2 A12 A10 sorry
              thus "(a,b)are-convergent-wrtREWRITE1R5 R"
                using A4 A11 sorry
            qed
            thus " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
              using rewrite1_def_3 rewrite1_def_4 sorry
          qed "sorry"
          thus "R be with-Church-Rosser-propertyREWRITE1V9"
            using rewrite1_def_23 sorry
        qed
        thus "R be locally-confluentREWRITE1V10 & R be with-Church-Rosser-propertyREWRITE1V9"
          using rewrite1_def_24 sorry
      qed
      thus " not (R be confluentREWRITE1V8 &  not (R be locally-confluentREWRITE1V10 & R be with-Church-Rosser-propertyREWRITE1V9))"
        using rewrite1_def_22 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_cl_8:
"cluster subcommutativeREWRITE1V7 also-is confluentREWRITE1V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be subcommutativeREWRITE1V7 implies it be confluentREWRITE1V8"
  proof-
    have " for R be RelationRELAT-1M1 holds R be subcommutativeREWRITE1V7 implies R be confluentREWRITE1V8"
    proof(rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume "R be subcommutativeREWRITE1V7"
      then have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R"
        using rewrite1_th_49 sorry
      thus "R be confluentREWRITE1V8"
        using rewrite1_th_51 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_cl_9:
"cluster with-Church-Rosser-propertyREWRITE1V9 also-is with-NF-propertyREWRITE1V6 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-Church-Rosser-propertyREWRITE1V9 implies it be with-NF-propertyREWRITE1V6"
  proof-
    have " for R be RelationRELAT-1M1 holds R be with-Church-Rosser-propertyREWRITE1V9 implies R be with-NF-propertyREWRITE1V6"
    proof(rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume A13: "R be with-Church-Rosser-propertyREWRITE1V9"
      have " for b be objectHIDDENM1 holds  for a be objectHIDDENM1 holds b is-a-normal-form-wrtREWRITE1R3 R implies ((b,a)are-convertible-wrtREWRITE1R2 R implies R reducesREWRITE1R1(a,b))"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix b assume [ty]: "b be objectHIDDENM1"
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A14: "b is-a-normal-form-wrtREWRITE1R3 R"
        assume "(b,a)are-convertible-wrtREWRITE1R2 R"
        then have "(b,a)are-convergent-wrtREWRITE1R5 R"
          using A13 sorry
        then have " ex c be objectHIDDENM1 st R reducesREWRITE1R1(b,c) & R reducesREWRITE1R1(a,c)"
           sorry
        thus "R reducesREWRITE1R1(a,b)"
          using A14 rewrite1_th_33 sorry
      qed "sorry"
      thus "R be with-NF-propertyREWRITE1V6"
        using rewrite1_def_20 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_cl_10:
"cluster with-NF-propertyREWRITE1V6 also-is with-UN-propertyREWRITE1V5 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-NF-propertyREWRITE1V6 implies it be with-UN-propertyREWRITE1V5"
    using rewrite1_th_33 sorry
qed "sorry"

mtheorem rewrite1_cl_11:
"cluster with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2 also-is with-Church-Rosser-propertyREWRITE1V9 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2 implies it be with-Church-Rosser-propertyREWRITE1V9"
  proof-
    have " for R be RelationRELAT-1M1 holds  not ((R be with-UN-propertyREWRITE1V5 & R be weakly-normalizingREWRITE1V2) &  not R be with-Church-Rosser-propertyREWRITE1V9)"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a is-a-normal-form-wrtREWRITE1R3 R & b is-a-normal-form-wrtREWRITE1R3 R) & (a,b)are-convertible-wrtREWRITE1R2 R implies a =HIDDENR1 b) & ( for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies a has-a-normal-form-wrtREWRITE1R9 R) implies R be with-Church-Rosser-propertyREWRITE1V9"
      proof(rule impMI ,rule impI)
        assume A15: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a is-a-normal-form-wrtREWRITE1R3 R & b is-a-normal-form-wrtREWRITE1R3 R) & (a,b)are-convertible-wrtREWRITE1R2 R implies a =HIDDENR1 b"
          and A16: " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies a has-a-normal-form-wrtREWRITE1R9 R"
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
        proof(rule ballI,rule ballI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          have "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b) implies (a,b)are-convergent-wrtREWRITE1R5 R"
          proof(rule impI)
            assume A17: "R \\/XBOOLE-0K2 R ~RELAT-1K4 reducesREWRITE1R1(a,b)"
            have A18: "fieldRELAT-1K3 (R \\/XBOOLE-0K2 R ~RELAT-1K4) =HIDDENR1 fieldRELAT-1K3 R \\/XBOOLE-0K2 fieldRELAT-1K3 (R ~RELAT-1K4)"
              using relat_1_th_18 sorry
            also have "... = fieldRELAT-1K3 R \\/XBOOLE-0K2 fieldRELAT-1K3 R"
              using relat_1_th_21 sorry
            also have "... = fieldRELAT-1K3 R"
               sorry
            finally have "fieldRELAT-1K3 (R \\/XBOOLE-0K2 R ~RELAT-1K4) =HIDDENR1 fieldRELAT-1K3 R"
               sorry
            show "(a,b)are-convergent-wrtREWRITE1R5 R"
            proof-
              have cases: "a =HIDDENR1 b or a <>HIDDENR2 b"
                 sorry
              have case1: "a =HIDDENR1 b implies (a,b)are-convergent-wrtREWRITE1R5 R"
              proof(rule impI)
                assume "a =HIDDENR1 b"
                thus "(a,b)are-convergent-wrtREWRITE1R5 R"
                  using rewrite1_th_38 sorry
              qed
              have case2: "a <>HIDDENR2 b implies (a,b)are-convergent-wrtREWRITE1R5 R"
              proof(rule impI)
                assume A19: "a <>HIDDENR2 b"
                then have "b inHIDDENR3 fieldRELAT-1K3 R"
                  using A17 A18 rewrite1_th_18 sorry
                then have "b has-a-normal-form-wrtREWRITE1R9 R"
                  using A16 sorry
                then obtain b9 where
                  [ty]:"b9 be objectHIDDENM1" and 
                  A20: "b9 is-a-normal-form-ofREWRITE1R4(b,R)"
                   sorry
                have "a inHIDDENR3 fieldRELAT-1K3 R"
                  using A17 A18 A19 rewrite1_th_18 sorry
                then have "a has-a-normal-form-wrtREWRITE1R9 R"
                  using A16 sorry
                then obtain a9 where
                  [ty]:"a9 be objectHIDDENM1" and 
                  A21: "a9 is-a-normal-form-ofREWRITE1R4(a,R)"
                   sorry
                have A22: "a9 is-a-normal-form-wrtREWRITE1R3 R"
                  using A21 sorry
                have A23: "(a,b)are-convertible-wrtREWRITE1R2 R"
                  using A17 sorry
                have A24: "R reducesREWRITE1R1(a,a9)"
                  using A21 sorry
                then have "(a9,a)are-convertible-wrtREWRITE1R2 R"
                  using rewrite1_th_25 sorry
                then have A25: "(a9,b)are-convertible-wrtREWRITE1R2 R"
                  using A23 rewrite1_th_30 sorry
                have A26: "b9 is-a-normal-form-wrtREWRITE1R3 R"
                  using A20 sorry
                have A27: "R reducesREWRITE1R1(b,b9)"
                  using A20 sorry
                then have "(b,b9)are-convertible-wrtREWRITE1R2 R"
                  using rewrite1_th_25 sorry
                then have "a9 =HIDDENR1 b9"
                  using A15 A22 A26 A25 rewrite1_th_30 sorry
                thus "(a,b)are-convergent-wrtREWRITE1R5 R"
                  using A24 A27 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
            using rewrite1_def_4 sorry
        qed "sorry"
        thus "R be with-Church-Rosser-propertyREWRITE1V9"
          using rewrite1_def_23 sorry
      qed
      thus " not ((R be with-UN-propertyREWRITE1V5 & R be weakly-normalizingREWRITE1V2) &  not R be with-Church-Rosser-propertyREWRITE1V9)"
        using rewrite1_def_14 rewrite1_def_19 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_cl_12:
"cluster emptyXBOOLE-0V1 also-is subcommutativeREWRITE1V7 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be subcommutativeREWRITE1V7"
     sorry
qed "sorry"

mtheorem rewrite1_th_53:
" for R be with-UN-propertyREWRITE1V5\<bar>RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c"
proof-
  have " for R be with-UN-propertyREWRITE1V5\<bar>RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  not ((b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R)) &  not b =HIDDENR1 c)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix R assume [ty]: "R be with-UN-propertyREWRITE1V5\<bar>RelationRELAT-1M1"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix c assume [ty]: "c be objectHIDDENM1"
    have "b is-a-normal-form-wrtREWRITE1R3 R & (R reducesREWRITE1R1(a,b) & (c is-a-normal-form-wrtREWRITE1R3 R & R reducesREWRITE1R1(a,c))) implies b =HIDDENR1 c"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impI)
      assume A1: "b is-a-normal-form-wrtREWRITE1R3 R"
        and A2: "R reducesREWRITE1R1(a,b)"
        and A3: "c is-a-normal-form-wrtREWRITE1R3 R"
        and A4: "R reducesREWRITE1R1(a,c)"
      have "(b,c)are-divergent-wrtREWRITE1R6 R"
        using A2 A4 sorry
      then have "(b,c)are-convertible-wrtREWRITE1R2 R"
        using rewrite1_th_37 sorry
      thus "b =HIDDENR1 c"
        using A1 A3 rewrite1_def_19 sorry
    qed
    thus " not ((b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R)) &  not b =HIDDENR1 c)"
      using rewrite1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_54:
" for R be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2\<bar>RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds nfREWRITE1K2(a,R) is-a-normal-form-ofREWRITE1R4(a,R)"
proof(rule ballI,rule ballI)
  fix R assume [ty]: "R be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2\<bar>RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  have "a inHIDDENR3 fieldRELAT-1K3 R or  not a inHIDDENR3 fieldRELAT-1K3 R"
     sorry
  then have A1: "a has-a-normal-form-wrtREWRITE1R9 R"
    using rewrite1_def_14 rewrite1_th_46 sorry
  have " for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds b is-a-normal-form-ofREWRITE1R4(a,R) & c is-a-normal-form-ofREWRITE1R4(a,R) implies b =HIDDENR1 c"
    using rewrite1_th_53 sorry
  thus "nfREWRITE1K2(a,R) is-a-normal-form-ofREWRITE1R4(a,R)"
    using A1 rewrite1_def_12 sorry
qed "sorry"

mtheorem rewrite1_th_55:
" for R be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2\<bar>RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R implies nfREWRITE1K2(a,R) =XBOOLE-0R4 nfREWRITE1K2(b,R)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be with-UN-propertyREWRITE1V5\<bar>weakly-normalizingREWRITE1V2\<bar>RelationRELAT-1M1"
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  have A1: "nfREWRITE1K2(b,R) is-a-normal-form-ofREWRITE1R4(b,R)"
    using rewrite1_th_54 sorry
  then have A2: "nfREWRITE1K2(b,R) is-a-normal-form-wrtREWRITE1R3 R"
     sorry
  have "R reducesREWRITE1R1(b,nfREWRITE1K2(b,R))"
    using A1 sorry
  then have A3: "(b,nfREWRITE1K2(b,R))are-convertible-wrtREWRITE1R2 R"
    using rewrite1_th_25 sorry
  have A4: "nfREWRITE1K2(a,R) is-a-normal-form-ofREWRITE1R4(a,R)"
    using rewrite1_th_54 sorry
  then have "R reducesREWRITE1R1(a,nfREWRITE1K2(a,R))"
     sorry
  then have A5: "(nfREWRITE1K2(a,R),a)are-convertible-wrtREWRITE1R2 R"
    using rewrite1_th_25 sorry
  assume "(a,b)are-convertible-wrtREWRITE1R2 R"
  then have "(nfREWRITE1K2(a,R),b)are-convertible-wrtREWRITE1R2 R"
    using A5 rewrite1_th_30 sorry
  then have A6: "(nfREWRITE1K2(a,R),nfREWRITE1K2(b,R))are-convertible-wrtREWRITE1R2 R"
    using A3 rewrite1_th_30 sorry
  have "nfREWRITE1K2(a,R) is-a-normal-form-wrtREWRITE1R3 R"
    using A4 sorry
  thus "nfREWRITE1K2(a,R) =XBOOLE-0R4 nfREWRITE1K2(b,R)"
    using A2 A6 rewrite1_def_19 sorry
qed "sorry"

mtheorem rewrite1_cl_13:
"cluster strongly-normalizingREWRITE1V3\<bar>locally-confluentREWRITE1V10 also-is confluentREWRITE1V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be strongly-normalizingREWRITE1V3\<bar>locally-confluentREWRITE1V10 implies it be confluentREWRITE1V8"
  proof-
    have " for R be RelationRELAT-1M1 holds R be strongly-normalizingREWRITE1V3 implies  not (R be locally-confluentREWRITE1V10 &  not R be confluentREWRITE1V8)"
    proof(rule ballI,rule impI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume A1: "R be strongly-normalizingREWRITE1V3"
      let ?P = "\<lambda>Lamb1.  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(Lamb1,b) & R reducesREWRITE1R1(Lamb1,c) implies (b,c)are-convergent-wrtREWRITE1R5 R"
      have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R) implies R be confluentREWRITE1V8"
      proof(rule impI)
        assume A2: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R"
        have A3: " for a be objectHIDDENM1 holds ( for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & a <>HIDDENR2 b implies ?P(b)) implies ?P(a)"
        proof-
          have " for a be objectHIDDENM1 holds ( for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & a <>HIDDENR2 b implies ?P(b)) implies ( for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c) implies (b,c)are-convergent-wrtREWRITE1R5 R)"
          proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume A4: " for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & a <>HIDDENR2 b implies ?P(b)"
            fix b assume [ty]: "b be objectHIDDENM1"
            fix c assume [ty]: "c be objectHIDDENM1"
            assume A5: "R reducesREWRITE1R1(a,b)"
              and A6: "R reducesREWRITE1R1(a,c)"
            obtain p where
              [ty]:"p be RedSequenceREWRITE1M1-of R" and 
              A7: "a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"and A8: "b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
              using A5 sorry
            have A9: "lenFINSEQ-1K4 p >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            obtain q where
              [ty]:"q be RedSequenceREWRITE1M1-of R" and 
              A10: "a =HIDDENR1 q .FUNCT-1K1 \<one>\<^sub>M"and A11: "c =HIDDENR1 q .FUNCT-1K1 lenFINSEQ-1K4 q"
              using A6 sorry
            have A12: "lenFINSEQ-1K4 q >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            show "(b,c)are-convergent-wrtREWRITE1R5 R"
            proof-
              have cases: "(lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M or lenFINSEQ-1K4 q =XBOOLE-0R4 \<one>\<^sub>M) or lenFINSEQ-1K4 p <>HIDDENR2 \<one>\<^sub>M & lenFINSEQ-1K4 q <>HIDDENR2 \<one>\<^sub>M"
                 sorry
              have case1: "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M implies (b,c)are-convergent-wrtREWRITE1R5 R"
              proof(rule impI)
                assume "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
                thus "(b,c)are-convergent-wrtREWRITE1R5 R"
                  using A6 A7 A8 rewrite1_th_36 sorry
              qed
              have case2: "lenFINSEQ-1K4 q =XBOOLE-0R4 \<one>\<^sub>M implies (b,c)are-convergent-wrtREWRITE1R5 R"
              proof(rule impI)
                assume "lenFINSEQ-1K4 q =XBOOLE-0R4 \<one>\<^sub>M"
                thus "(b,c)are-convergent-wrtREWRITE1R5 R"
                  using A5 A10 A11 rewrite1_th_36 sorry
              qed
              have case3: "lenFINSEQ-1K4 p <>HIDDENR2 \<one>\<^sub>M & lenFINSEQ-1K4 q <>HIDDENR2 \<one>\<^sub>M implies (b,c)are-convergent-wrtREWRITE1R5 R"
              proof(rule impI)
                assume A13: "lenFINSEQ-1K4 p <>HIDDENR2 \<one>\<^sub>M & lenFINSEQ-1K4 q <>HIDDENR2 \<one>\<^sub>M"
                then have "lenFINSEQ-1K4 q >XXREAL-0R4 \<one>\<^sub>M"
                  using A12 xxreal_0_th_1 sorry
                then have A14: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
                  using nat_1_th_13 sorry
                then have A15: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
                  using rewrite1_lm_3 sorry
                have "lenFINSEQ-1K4 q inTARSKIR2 domFINSEQ-1K5 q"
                  using finseq_5_th_6 sorry
                then have A16: "R reducesREWRITE1R1(q .FUNCT-1K1 \<two>\<^sub>M,c)"
                  using A11 A14 A15 rewrite1_th_17 sorry
                have "lenFINSEQ-1K4 p >XXREAL-0R4 \<one>\<^sub>M"
                  using A9 A13 xxreal_0_th_1 sorry
                then have A17: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
                  using nat_1_th_13 sorry
                then have A18: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                  using rewrite1_lm_3 sorry
                have "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
                  using finseq_5_th_6 sorry
                then have A19: "R reducesREWRITE1R1(p .FUNCT-1K1 \<two>\<^sub>M,b)"
                  using A8 A17 A18 rewrite1_th_17 sorry
                have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                  using A9 rewrite1_lm_3 sorry
                then have A20: "[TARSKIK4 a,p .FUNCT-1K1 \<two>\<^sub>M ] inHIDDENR3 R"
                  using A7 A18 rewrite1_def_2 sorry
                then have A21: "a inHIDDENR3 fieldRELAT-1K3 R"
                  using relat_1_th_15 sorry
                have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
                  using A12 rewrite1_lm_3 sorry
                then have A22: "[TARSKIK4 a,q .FUNCT-1K1 \<two>\<^sub>M ] inHIDDENR3 R"
                  using A10 A15 rewrite1_def_2 sorry
                then have "(p .FUNCT-1K1 \<two>\<^sub>M,q .FUNCT-1K1 \<two>\<^sub>M)are-convergent-wrtREWRITE1R5 R"
                  using A2 A20 sorry
                then obtain d where
                  [ty]:"d be objectHIDDENM1" and 
                  A23: "R reducesREWRITE1R1(p .FUNCT-1K1 \<two>\<^sub>M,d)"and A24: "R reducesREWRITE1R1(q .FUNCT-1K1 \<two>\<^sub>M,d)"
                   sorry
                have A25: "R is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 R"
                  using A1 relat_2_def_10 sorry
                then have A26: "a <>HIDDENR2 q .FUNCT-1K1 \<two>\<^sub>M"
                  using A22 A21 sorry
                have "a <>HIDDENR2 p .FUNCT-1K1 \<two>\<^sub>M"
                  using A20 A21 A25 sorry
                then have "(b,d)are-convergent-wrtREWRITE1R5 R"
                  using A4 A20 A23 A19 sorry
                then obtain e where
                  [ty]:"e be objectHIDDENM1" and 
                  A27: "R reducesREWRITE1R1(b,e)"and A28: "R reducesREWRITE1R1(d,e)"
                   sorry
                have "R reducesREWRITE1R1(q .FUNCT-1K1 \<two>\<^sub>M,e)"
                  using A24 A28 rewrite1_th_16 sorry
                then have "(e,c)are-convergent-wrtREWRITE1R5 R"
                  using A4 A22 A26 A16 sorry
                thus "(b,c)are-convergent-wrtREWRITE1R5 R"
                  using A27 rewrite1_th_42 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A29: "R be co-well-foundedREWRITE1V4"
          using A1 sorry
        have A30: " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies ?P(a)"
          using rewrite1_sch_2 A29 A3 sorry
        have "( ex a0 be objectHIDDENM1 st  ex b0 be objectHIDDENM1 st (a0,b0)are-divergent-wrtREWRITE1R6 R &  not (a0,b0)are-convergent-wrtREWRITE1R5 R) implies  not  True "
        proof(rule impI)
          assume Given: " ex a0 be objectHIDDENM1 st  ex b0 be objectHIDDENM1 st (a0,b0)are-divergent-wrtREWRITE1R6 R &  not (a0,b0)are-convergent-wrtREWRITE1R5 R"
          then obtain a0 b0 where
            [ty]:"a0 be objectHIDDENM1" "b0 be objectHIDDENM1" and 
            A31: "(a0,b0)are-divergent-wrtREWRITE1R6 R"and A32: " not (a0,b0)are-convergent-wrtREWRITE1R5 R"
             sorry
          obtain c0 where
            [ty]:"c0 be objectHIDDENM1" and 
            A33: "R reducesREWRITE1R1(c0,a0) & R reducesREWRITE1R1(c0,b0)"
            using A31 sorry
          have "a0 <>HIDDENR2 c0 or b0 <>HIDDENR2 c0"
            using A32 rewrite1_th_38 sorry
          then have "c0 inHIDDENR3 fieldRELAT-1K3 R"
            using A33 rewrite1_th_18 sorry
          thus " not  True "
            using A32 A33 A30 sorry
        qed
        thus "R be confluentREWRITE1V8"
          using rewrite1_def_22 sorry
      qed
      thus " not (R be locally-confluentREWRITE1V10 &  not R be confluentREWRITE1V8)"
        using rewrite1_def_24 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef rewrite1_def_25 ("completeREWRITE1V11" 70 ) where
"attr completeREWRITE1V11 for RelationRELAT-1M1 means
  (\<lambda>R. R be confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3)"..

mtheorem rewrite1_cl_14:
"cluster completeREWRITE1V11 also-is confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be completeREWRITE1V11 implies it be confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3"
     sorry
qed "sorry"

mtheorem rewrite1_cl_15:
"cluster confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3 also-is completeREWRITE1V11 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be confluentREWRITE1V8\<bar>strongly-normalizingREWRITE1V3 implies it be completeREWRITE1V11"
     sorry
qed "sorry"

mtheorem rewrite1_cl_16:
"cluster completeREWRITE1V11 for  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1 st it be completeREWRITE1V11"
  proof-
    have " ex tVar19 be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1 st tVar19 be completeREWRITE1V11"
    proof-
      obtain R where 
        [ty]:"R be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1" and RDef:"R = {TARSKIK1 [TARSKIK4 0NUMBERSK6,\<one>\<^sub>M ] }"
         sorry
      show " ex tVar19 be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1 st tVar19 be completeREWRITE1V11"
      proof(rule bexI[of _ "R"])
        have A1: "fieldRELAT-1K3 R =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
          using relat_1_th_17 sorry
        have "R be confluentREWRITE1V8 & R be strongly-normalizingREWRITE1V3"
        proof(rule conjMI)
          show "R be confluentREWRITE1V8"
          proof-
            have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
            proof(rule ballI,rule ballI)
              fix a assume [ty]: "a be objectHIDDENM1"
              fix b assume [ty]: "b be objectHIDDENM1"
              have "( ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)) implies (a,b)are-convergent-wrtREWRITE1R5 R"
              proof(rule impI)
                assume Given: " ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"
                then obtain c where
                  [ty]:"c be objectHIDDENM1" and 
                  A2: "R reducesREWRITE1R1(c,a)"and A3: "R reducesREWRITE1R1(c,b)"
                   sorry
                show "(a,b)are-convergent-wrtREWRITE1R5 R"
                proof-
                  have cases: "a =HIDDENR1 b or a <>HIDDENR2 b"
                     sorry
                  have case1: "a =HIDDENR1 b implies (a,b)are-convergent-wrtREWRITE1R5 R"
                  proof(rule impI)
                    assume "a =HIDDENR1 b"
                    thus "(a,b)are-convergent-wrtREWRITE1R5 R"
                      using rewrite1_th_38 sorry
                  qed
                  have case2: "a <>HIDDENR2 b implies (a,b)are-convergent-wrtREWRITE1R5 R"
                  proof(rule impI)
                    assume "a <>HIDDENR2 b"
                    then have "a <>HIDDENR2 c or b <>HIDDENR2 c"
                       sorry
                    then have A4: "c inHIDDENR3 fieldRELAT-1K3 R"
                      using A2 A3 rewrite1_th_18 sorry
                    then have "a inHIDDENR3 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
                      using A1 A2 rewrite1_th_18 sorry
                    then have A5: "a =HIDDENR1 0NUMBERSK6 or a =HIDDENR1 \<one>\<^sub>M"
                      using tarski_def_2 sorry
                    have "b inHIDDENR3 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
                      using A1 A3 A4 rewrite1_th_18 sorry
                    then have A6: "b =HIDDENR1 0NUMBERSK6 or b =HIDDENR1 \<one>\<^sub>M"
                      using tarski_def_2 sorry
                    have "[TARSKIK4 0NUMBERSK6,\<one>\<^sub>M ] inHIDDENR3 R"
                      using tarski_def_1 sorry
                    then have A7: "R reducesREWRITE1R1(0NUMBERSK6,\<one>\<^sub>M)"
                      using rewrite1_th_15 sorry
                    have "R reducesREWRITE1R1(\<one>\<^sub>M,\<one>\<^sub>M)"
                      using rewrite1_th_12 sorry
                    thus "(a,b)are-convergent-wrtREWRITE1R5 R"
                      using A5 A6 A7 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
                using rewrite1_def_8 sorry
            qed "sorry"
            thus "R be confluentREWRITE1V8"
              using rewrite1_def_22 sorry
          qed
          have A8: "R be co-well-foundedREWRITE1V4"
          proof-
            have " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 R & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar20 be objectHIDDENM1 st tVar20 inTARSKIR2 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & tVar20 <>HIDDENR2 b implies  not [TARSKIK4 tVar20,b ] inHIDDENR3 R))"
            proof(rule ballI,rule impMI ,rule impI)
              fix Y assume [ty]: "Y be setHIDDENM2"
              assume A9: "Y c=TARSKIR1 fieldRELAT-1K3 R"
                and A10: "Y <>HIDDENR2 {}XBOOLE-0K1"
              obtain Y9 where 
                [ty]:"Y9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and Y9Def:"Y9 = Y"
                using A10 sorry
              let ?y = "the ElementSUBSET-1M1-of Y9"
              show " ex tVar20 be objectHIDDENM1 st tVar20 inTARSKIR2 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & tVar20 <>HIDDENR2 b implies  not [TARSKIK4 tVar20,b ] inHIDDENR3 R)"
              proof-
                have cases: "\<one>\<^sub>M inTARSKIR2 Y or  not \<one>\<^sub>M inTARSKIR2 Y & ?y inTARSKIR2 Y"
                   sorry
                have case1: "\<one>\<^sub>M inTARSKIR2 Y implies ( ex tVar20 be objectHIDDENM1 st tVar20 inTARSKIR2 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & tVar20 <>HIDDENR2 b implies  not [TARSKIK4 tVar20,b ] inHIDDENR3 R))"
                proof(rule impI)
                  assume A11: "\<one>\<^sub>M inTARSKIR2 Y"
                  show " ex tVar20 be objectHIDDENM1 st tVar20 inTARSKIR2 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y & tVar20 <>HIDDENR2 b implies  not [TARSKIK4 tVar20,b ] inHIDDENR3 R)"
                  proof(rule bexI[of _ "\<one>\<^sub>M"],rule conjMI,rule ballI,rule impMI ,rule impI)
                    show "\<one>\<^sub>M inTARSKIR2 Y"
                      using A11 sorry
                    fix b assume [ty]: "b be objectHIDDENM1"
                    assume "b inHIDDENR3 Y"
                      and "\<one>\<^sub>M <>HIDDENR2 b"
                    have "[TARSKIK4 0NUMBERSK6,\<one>\<^sub>M ] <>HIDDENR2 [TARSKIK4 \<one>\<^sub>M,b ]"
                      using xtuple_0_th_1 sorry
                    thus " not [TARSKIK4 \<one>\<^sub>M,b ] inHIDDENR3 R"
                      using tarski_def_1 sorry
                  qed "sorry"
                qed
                have case2: " not \<one>\<^sub>M inTARSKIR2 Y & the ElementSUBSET-1M1-of Y9 inTARSKIR2 Y implies ( ex tVar21 be objectHIDDENM1 st tVar21 inTARSKIR2 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y implies  not ( not tVar21 <>HIDDENR2 b & [TARSKIK4 tVar21,b ] inHIDDENR3 R)))"
                proof(rule impI)
                  assume A12: " not \<one>\<^sub>M inTARSKIR2 Y & ?y inTARSKIR2 Y"
                  show " ex tVar21 be objectHIDDENM1 st tVar21 inTARSKIR2 Y & ( for b be objectHIDDENM1 holds b inHIDDENR3 Y implies  not ( not tVar21 <>HIDDENR2 b & [TARSKIK4 tVar21,b ] inHIDDENR3 R))"
                  proof(rule bexI[of _ "0NUMBERSK6"],rule conjMI,rule ballI,rule impI)
                    show "0NUMBERSK6 inTARSKIR2 Y"
                      using A1 A9 A12 tarski_def_2 sorry
                    fix b assume [ty]: "b be objectHIDDENM1"
                    assume "b inHIDDENR3 Y"
                    thus " not ( not 0NUMBERSK6 <>HIDDENR2 b & [TARSKIK4 0NUMBERSK6,b ] inHIDDENR3 R)"
                      using A1 A9 A12 tarski_def_2 sorry
                  qed "sorry"
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "R be co-well-foundedREWRITE1V4"
              using rewrite1_def_16 sorry
          qed
          have "R be irreflexiveRELAT-2V2"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 x,x ] inHIDDENR3 R implies  False "
            proof(rule ballI,rule impMI ,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 fieldRELAT-1K3 R"
                and A13: "[TARSKIK4 x,x ] inHIDDENR3 R"
              have A14: "[TARSKIK4 x,x ] =HIDDENR1 [TARSKIK4 0NUMBERSK6,\<one>\<^sub>M ]"
                using A13 tarski_def_1 sorry
              then have "x =HIDDENR1 0NUMBERSK6"
                using xtuple_0_th_1 sorry
              thus " False "
                using A14 xtuple_0_th_1 sorry
            qed "sorry"
            thus "R be irreflexiveRELAT-2V2"
              using relat_2_def_2 relat_2_def_10 sorry
          qed
          thus "R be strongly-normalizingREWRITE1V3"
            using A8 sorry
        qed
        thus "R be completeREWRITE1V11"
          using rewrite1_def_25 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rewrite1_th_56:
" for R be with-Church-Rosser-propertyREWRITE1V9\<bar>RelationRELAT-1M1 holds  for Q be with-Church-Rosser-propertyREWRITE1V9\<bar>RelationRELAT-1M1 holds R commutes-withREWRITE1R11 Q implies R \\/XBOOLE-0K2 Q be with-Church-Rosser-propertyREWRITE1V9"
proof(rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be with-Church-Rosser-propertyREWRITE1V9\<bar>RelationRELAT-1M1"
  fix Q assume [ty]: "Q be with-Church-Rosser-propertyREWRITE1V9\<bar>RelationRELAT-1M1"
  assume A1: "R commutes-withREWRITE1R11 Q"
  have "R \\/XBOOLE-0K2 Q be confluentREWRITE1V8"
  proof-
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-divergent-wrtREWRITE1R6 R \\/XBOOLE-0K2 Q &  not (a,b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q)"
    proof(rule ballI,rule ballI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      have "( ex c be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(c,a) & R \\/XBOOLE-0K2 Q reducesREWRITE1R1(c,b)) implies (a,b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
      proof(rule impI)
        assume Given: " ex c be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(c,a) & R \\/XBOOLE-0K2 Q reducesREWRITE1R1(c,b)"
        then obtain c where
          [ty]:"c be objectHIDDENM1" and 
          A2: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(c,a)"and A3: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(c,b)"
           sorry
        obtain p where
          [ty]:"p be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 Q" and 
          A4: "c =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"and A5: "a =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
          using A2 sorry
        let ?Z = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies (p .FUNCT-1K1 Lamb1,b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
        have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies (p .FUNCT-1K1 i,b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
        proof(rule ballI,rule impMI ,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A6: "i inTARSKIR2 domFINSEQ-1K5 p implies (p .FUNCT-1K1 i,b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
            and A7: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
          show "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
          proof-
            have cases: "i =XBOOLE-0R4 0NUMBERSK6 or i >XXREAL-0R4 0NUMBERSK6"
               sorry
            have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
            proof(rule impI)
              assume "i =XBOOLE-0R4 0NUMBERSK6"
              thus "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
                using A3 A4 rewrite1_th_36 sorry
            qed
            have case2: "i >XXREAL-0R4 0NUMBERSK6 implies (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
            proof(rule impI)
              assume A8: "i >XXREAL-0R4 0NUMBERSK6"
              have A9: "i <XXREAL-0R3 lenFINSEQ-1K4 p"
                using A7 rewrite1_lm_2 sorry
              then obtain d where
                [ty]:"d be objectHIDDENM1" and 
                A10: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 i,d)"and A11: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(b,d)"
                using A6 A8 rewrite1_lm_3 sorry
              obtain q where
                [ty]:"q be RedSequenceREWRITE1M1-of R \\/XBOOLE-0K2 Q" and 
                A12: "p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 \<one>\<^sub>M"and A13: "d =HIDDENR1 q .FUNCT-1K1 lenFINSEQ-1K4 q"
                using A10 sorry
              let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 q implies ( ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 Lamb1,e) or Q reducesREWRITE1R1(q .FUNCT-1K1 Lamb1,e)))"
              have "i inTARSKIR2 domFINSEQ-1K5 p"
                using A8 A9 rewrite1_lm_3 sorry
              then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 Q"
                using A7 rewrite1_def_2 sorry
              then have A14: "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R or [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Q"
                using xboole_0_def_3 sorry
              have " for j be NatNAT-1M1 holds (j inTARSKIR2 domFINSEQ-1K5 q implies ( ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 j,e) or Q reducesREWRITE1R1(q .FUNCT-1K1 j,e)))) & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q implies ( ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e)))"
              proof(rule ballI,rule impMI ,rule impI)
                fix j assume [ty]: "j be NatNAT-1M1"
                assume A15: "j inTARSKIR2 domFINSEQ-1K5 q implies ( ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 j,e) or Q reducesREWRITE1R1(q .FUNCT-1K1 j,e)))"
                  and A16: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
                have A17: "j <XXREAL-0R3 lenFINSEQ-1K4 q"
                  using A16 rewrite1_lm_2 sorry
                show " ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e))"
                proof-
                  have cases: "j =XBOOLE-0R4 0NUMBERSK6 or j >XXREAL-0R4 0NUMBERSK6"
                     sorry
                  have case1: "j =XBOOLE-0R4 0NUMBERSK6 implies ( ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e)))"
                  proof(rule impI)
                    assume A18: "j =XBOOLE-0R4 0NUMBERSK6"
                    have A19: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
                      using rewrite1_th_12 sorry
                    have "R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))"
                      using A12 A14 A18 rewrite1_th_15 sorry
                    thus " ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e))"
                      using A19 sorry
                  qed
                  have case2: "j >XXREAL-0R4 0NUMBERSK6 implies ( ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e)))"
                  proof(rule impI)
                    assume A20: "j >XXREAL-0R4 0NUMBERSK6"
                    then obtain e where
                      [ty]:"e be objectHIDDENM1" and 
                      A21: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e)"and A22: "R reducesREWRITE1R1(q .FUNCT-1K1 j,e) or Q reducesREWRITE1R1(q .FUNCT-1K1 j,e)"
                      using A15 A17 rewrite1_lm_3 sorry
                    have A23: "R reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & Q reducesREWRITE1R1(q .FUNCT-1K1 j,e) implies ( ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)))"
                    proof(rule impI)
                      assume "R reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & Q reducesREWRITE1R1(q .FUNCT-1K1 j,e)"
                      then obtain x where
                        [ty]:"x be objectHIDDENM1" and 
                        A24: "Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)"and A25: "R reducesREWRITE1R1(e,x)"
                        using A1 sorry
                      show " ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                      proof(rule bexI[of _ "x"])
                        have "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(e,x)"
                          using A25 rewrite1_th_22 xboole_1_th_7 sorry
                        thus "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                          using A21 A24 rewrite1_th_16 sorry
                      qed "sorry"
                    qed
                    have A26: "Q reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & Q reducesREWRITE1R1(q .FUNCT-1K1 j,e) implies ( ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)))"
                    proof(rule impI)
                      assume "Q reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & Q reducesREWRITE1R1(q .FUNCT-1K1 j,e)"
                      then have "(e,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-divergent-wrtREWRITE1R6 Q"
                         sorry
                      then have "(e,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 Q"
                        using rewrite1_def_22 sorry
                      then obtain x where
                        [ty]:"x be objectHIDDENM1" and 
                        A27: "Q reducesREWRITE1R1(e,x)"and A28: "Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)"
                         sorry
                      show " ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                      proof(rule bexI[of _ "x"])
                        have "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(e,x)"
                          using A27 rewrite1_th_22 xboole_1_th_7 sorry
                        thus "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                          using A21 A28 rewrite1_th_16 sorry
                      qed "sorry"
                    qed
                    have A29: "R reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & R reducesREWRITE1R1(q .FUNCT-1K1 j,e) implies ( ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)))"
                    proof(rule impI)
                      assume "R reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & R reducesREWRITE1R1(q .FUNCT-1K1 j,e)"
                      then have "(e,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-divergent-wrtREWRITE1R6 R"
                         sorry
                      then have "(e,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convergent-wrtREWRITE1R5 R"
                        using rewrite1_def_22 sorry
                      then obtain x where
                        [ty]:"x be objectHIDDENM1" and 
                        A30: "R reducesREWRITE1R1(e,x)"and A31: "R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)"
                         sorry
                      show " ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                      proof(rule bexI[of _ "x"])
                        have "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(e,x)"
                          using A30 rewrite1_th_22 xboole_1_th_7 sorry
                        thus "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                          using A21 A31 rewrite1_th_16 sorry
                      qed "sorry"
                    qed
                    have A32: "Q reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & R reducesREWRITE1R1(q .FUNCT-1K1 j,e) implies ( ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)))"
                    proof(rule impI)
                      assume "Q reducesREWRITE1R1(q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)) & R reducesREWRITE1R1(q .FUNCT-1K1 j,e)"
                      then obtain x where
                        [ty]:"x be objectHIDDENM1" and 
                        A33: "R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x)"and A34: "Q reducesREWRITE1R1(e,x)"
                        using A1 rewrite1_def_18 sorry
                      show " ex x be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                      proof(rule bexI[of _ "x"])
                        have "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(e,x)"
                          using A34 rewrite1_th_22 xboole_1_th_7 sorry
                        thus "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),x) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),x))"
                          using A21 A33 rewrite1_th_16 sorry
                      qed "sorry"
                    qed
                    have "j inTARSKIR2 domFINSEQ-1K5 q"
                      using A17 A20 rewrite1_lm_3 sorry
                    then have "[TARSKIK4 q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 Q"
                      using A16 rewrite1_def_2 sorry
                    then have "[TARSKIK4 q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R or [TARSKIK4 q .FUNCT-1K1 j,q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Q"
                      using xboole_0_def_3 sorry
                    thus " ex e be objectHIDDENM1 st R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & (R reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e) or Q reducesREWRITE1R1(q .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),e))"
                      using A22 A29 A26 A23 A32 rewrite1_th_15 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              then have A35: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have A36: "?P(0NUMBERSK6)"
                using rewrite1_lm_1 sorry
              have A37: " for j be NatNAT-1M1 holds ?P(j)"
                using nat_1_sch_2 A36 A35 sorry
              show "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
              proof-
                have "lenFINSEQ-1K4 q inTARSKIR2 domFINSEQ-1K5 q"
                  using finseq_5_th_6 sorry
                then obtain e where
                  [ty]:"e be objectHIDDENM1" and 
                  A38: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e)"and A39: "R reducesREWRITE1R1(d,e) or Q reducesREWRITE1R1(d,e)"
                  using A13 A37 sorry
                have Cut2115: "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(d,e)"
                  using A39 rewrite1_th_22 xboole_1_th_7 sorry
                have "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & R \\/XBOOLE-0K2 Q reducesREWRITE1R1(b,e)"
                proof-
                  show "R \\/XBOOLE-0K2 Q reducesREWRITE1R1(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),e) & R \\/XBOOLE-0K2 Q reducesREWRITE1R1(b,e)"
                    using A11 A38 rewrite1_th_16 Cut2115 sorry
                qed
                thus "(p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
                  using bexI[of _ "e"] rewrite1_def_7 sorry
              qed
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        then have A40: " for k be NatNAT-1M1 holds ?Z(k) implies ?Z(k +NAT-1K1 \<one>\<^sub>M)"
           sorry
        have A41: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
          using finseq_5_th_6 sorry
        have A42: "?Z(0NUMBERSK6)"
          using rewrite1_lm_1 sorry
        have " for i be NatNAT-1M1 holds ?Z(i)"
          using nat_1_sch_2 A42 A40 sorry
        thus "(a,b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q"
          using A5 A41 sorry
      qed
      thus " not ((a,b)are-divergent-wrtREWRITE1R6 R \\/XBOOLE-0K2 Q &  not (a,b)are-convergent-wrtREWRITE1R5 R \\/XBOOLE-0K2 Q)"
        using rewrite1_def_8 sorry
    qed "sorry"
    thus "R \\/XBOOLE-0K2 Q be confluentREWRITE1V8"
      using rewrite1_def_22 sorry
  qed
  thus "R \\/XBOOLE-0K2 Q be with-Church-Rosser-propertyREWRITE1V9"
     sorry
qed "sorry"

mtheorem rewrite1_th_57:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10"
proof-
  have " for R be RelationRELAT-1M1 holds (R be confluentREWRITE1V8 implies R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10) &  not (R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10 &  not R be confluentREWRITE1V8)"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be confluentREWRITE1V8 implies R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10"
    proof(rule impI)
      assume A1: "R be confluentREWRITE1V8"
      show "R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19 implies (b,c)are-convergent-wrtREWRITE1R5 R [*]FINSEQ-1K19"
        proof(rule ballI,rule ballI,rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "[TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19"
          then have "R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c)"
            using rewrite1_th_20 sorry
          then have "(b,c)are-divergent-wrtREWRITE1R6 R"
             sorry
          then have "(b,c)are-convergent-wrtREWRITE1R5 R"
            using A1 sorry
          then obtain d where
            [ty]:"d be objectHIDDENM1" and 
            A2: "R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)"
             sorry
          have "R [*]FINSEQ-1K19 reducesREWRITE1R1(b,d) & R [*]FINSEQ-1K19 reducesREWRITE1R1(c,d)"
          proof-
            show "R [*]FINSEQ-1K19 reducesREWRITE1R1(b,d) & R [*]FINSEQ-1K19 reducesREWRITE1R1(c,d)"
              using A2 rewrite1_th_21 sorry
          qed
          thus "(b,c)are-convergent-wrtREWRITE1R5 R [*]FINSEQ-1K19"
            using bexI[of _ "d"] rewrite1_def_7 sorry
        qed "sorry"
        thus "R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10"
          using rewrite1_def_24 sorry
      qed
    qed
    have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19 implies (b,c)are-convergent-wrtREWRITE1R5 R [*]FINSEQ-1K19) implies R be confluentREWRITE1V8"
    proof(rule impI)
      assume A3: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19 implies (b,c)are-convergent-wrtREWRITE1R5 R [*]FINSEQ-1K19"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
      proof(rule ballI,rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        have "( ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)) implies (a,b)are-convergent-wrtREWRITE1R5 R"
        proof(rule impI)
          assume Given: " ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"
          then obtain c where
            [ty]:"c be objectHIDDENM1" and 
            A4: "R reducesREWRITE1R1(c,a)"and A5: "R reducesREWRITE1R1(c,b)"
             sorry
          have A6: "[TARSKIK4 c,b ] inHIDDENR3 R [*]FINSEQ-1K19 or c =HIDDENR1 b"
            using A5 rewrite1_th_20 sorry
          have "[TARSKIK4 c,a ] inHIDDENR3 R [*]FINSEQ-1K19 or c =HIDDENR1 a"
            using A4 rewrite1_th_20 sorry
          then have "((a,b)are-convergent-wrtREWRITE1R5 R [*]FINSEQ-1K19 or R [*]FINSEQ-1K19 reducesREWRITE1R1(a,b)) or R [*]FINSEQ-1K19 reducesREWRITE1R1(b,a)"
            using A3 A6 rewrite1_th_15 rewrite1_th_38 sorry
          then have "(a,b)are-convergent-wrtREWRITE1R5 R [*]FINSEQ-1K19"
            using rewrite1_th_36 sorry
          then obtain d where
            [ty]:"d be objectHIDDENM1" and 
            A7: "R [*]FINSEQ-1K19 reducesREWRITE1R1(a,d) & R [*]FINSEQ-1K19 reducesREWRITE1R1(b,d)"
             sorry
          have "R reducesREWRITE1R1(a,d) & R reducesREWRITE1R1(b,d)"
          proof-
            show "R reducesREWRITE1R1(a,d) & R reducesREWRITE1R1(b,d)"
              using A7 rewrite1_th_21 sorry
          qed
          thus "(a,b)are-convergent-wrtREWRITE1R5 R"
            using bexI[of _ "d"] rewrite1_def_7 sorry
        qed
        thus " not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
          using rewrite1_def_8 sorry
      qed "sorry"
      thus "R be confluentREWRITE1V8"
        using rewrite1_def_22 sorry
    qed
    thus " not (R [*]FINSEQ-1K19 be locally-confluentREWRITE1V10 &  not R be confluentREWRITE1V8)"
      using rewrite1_def_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_58:
" for R be RelationRELAT-1M1 holds R be confluentREWRITE1V8 iff R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7"
proof-
  have " for R be RelationRELAT-1M1 holds (R be confluentREWRITE1V8 implies R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7) &  not (R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7 &  not R be confluentREWRITE1V8)"
  proof(rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "R be confluentREWRITE1V8 implies R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7"
    proof(rule impI)
      assume A1: "R be confluentREWRITE1V8"
      show "R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19 implies (b,c)are-convergent<=1-wrtREWRITE1R7 R [*]FINSEQ-1K19"
        proof(rule ballI,rule ballI,rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "[TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19"
          then have "R reducesREWRITE1R1(a,b) & R reducesREWRITE1R1(a,c)"
            using rewrite1_th_20 sorry
          then have "(b,c)are-divergent-wrtREWRITE1R6 R"
             sorry
          then have "(b,c)are-convergent-wrtREWRITE1R5 R"
            using A1 sorry
          then obtain d where
            [ty]:"d be objectHIDDENM1" and 
            A2: "R reducesREWRITE1R1(b,d) & R reducesREWRITE1R1(c,d)"
             sorry
          have " not ( not [TARSKIK4 b,d ] inHIDDENR3 R [*]FINSEQ-1K19 &  not b =HIDDENR1 d) &  not ( not [TARSKIK4 c,d ] inHIDDENR3 R [*]FINSEQ-1K19 &  not c =HIDDENR1 d)"
          proof-
            show " not ( not [TARSKIK4 b,d ] inHIDDENR3 R [*]FINSEQ-1K19 &  not b =HIDDENR1 d) &  not ( not [TARSKIK4 c,d ] inHIDDENR3 R [*]FINSEQ-1K19 &  not c =HIDDENR1 d)"
              using A2 rewrite1_th_20 sorry
          qed
          thus "(b,c)are-convergent<=1-wrtREWRITE1R7 R [*]FINSEQ-1K19"
            using bexI[of _ "d"] rewrite1_def_9 sorry
        qed "sorry"
        thus "R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7"
          using rewrite1_def_21 sorry
      qed
    qed
    have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19 implies (b,c)are-convergent<=1-wrtREWRITE1R7 R [*]FINSEQ-1K19) implies R be confluentREWRITE1V8"
    proof(rule impI)
      assume A3: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R [*]FINSEQ-1K19 & [TARSKIK4 a,c ] inHIDDENR3 R [*]FINSEQ-1K19 implies (b,c)are-convergent<=1-wrtREWRITE1R7 R [*]FINSEQ-1K19"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
      proof(rule ballI,rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        have "( ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)) implies (a,b)are-convergent-wrtREWRITE1R5 R"
        proof(rule impI)
          assume Given: " ex c be objectHIDDENM1 st R reducesREWRITE1R1(c,a) & R reducesREWRITE1R1(c,b)"
          then obtain c where
            [ty]:"c be objectHIDDENM1" and 
            A4: "R reducesREWRITE1R1(c,a)"and A5: "R reducesREWRITE1R1(c,b)"
             sorry
          have A6: "[TARSKIK4 c,b ] inHIDDENR3 R [*]FINSEQ-1K19 or c =HIDDENR1 b"
            using A5 rewrite1_th_20 sorry
          have "[TARSKIK4 c,a ] inHIDDENR3 R [*]FINSEQ-1K19 or c =HIDDENR1 a"
            using A4 rewrite1_th_20 sorry
          then have "(a,b)are-convergent<=1-wrtREWRITE1R7 R [*]FINSEQ-1K19"
            using A3 A6 sorry
          then have "(a,b)are-convergent-wrtREWRITE1R5 R [*]FINSEQ-1K19"
            using rewrite1_th_44 sorry
          then obtain d where
            [ty]:"d be objectHIDDENM1" and 
            A7: "R [*]FINSEQ-1K19 reducesREWRITE1R1(a,d) & R [*]FINSEQ-1K19 reducesREWRITE1R1(b,d)"
             sorry
          have "R reducesREWRITE1R1(a,d) & R reducesREWRITE1R1(b,d)"
          proof-
            show "R reducesREWRITE1R1(a,d) & R reducesREWRITE1R1(b,d)"
              using A7 rewrite1_th_21 sorry
          qed
          thus "(a,b)are-convergent-wrtREWRITE1R5 R"
            using bexI[of _ "d"] rewrite1_def_7 sorry
        qed
        thus " not ((a,b)are-divergent-wrtREWRITE1R6 R &  not (a,b)are-convergent-wrtREWRITE1R5 R)"
          using rewrite1_def_8 sorry
      qed "sorry"
      thus "R be confluentREWRITE1V8"
        using rewrite1_def_22 sorry
    qed
    thus " not (R [*]FINSEQ-1K19 be subcommutativeREWRITE1V7 &  not R be confluentREWRITE1V8)"
      using rewrite1_def_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef rewrite1_def_26 ("'( _ , _ ')are-equivalentREWRITE1R12" [0,0]50 ) where
  mlet "R be RelationRELAT-1M1", "Q be RelationRELAT-1M1"
"pred (R,Q)are-equivalentREWRITE1R12 means
   for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convertible-wrtREWRITE1R2 Q"..

mtheorem REWRITE1R12_symmetry:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds (R,Q)are-equivalentREWRITE1R12 implies (Q,R)are-equivalentREWRITE1R12"
proof-
  have " for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convertible-wrtREWRITE1R2 Q) implies ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 Q iff (a,b)are-convertible-wrtREWRITE1R2 R)"
     sorry
  thus " ?thesis "
    using rewrite1_def_26 sorry
qed

mdef rewrite1_def_27 ("'( _ , _ ')are-critical-wrtREWRITE1R13  _ " [0,0,50]50 ) where
  mlet "R be RelationRELAT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"pred (a,b)are-critical-wrtREWRITE1R13 R means
  (a,b)are-divergent<=1-wrtREWRITE1R8 R &  not (a,b)are-convergent-wrtREWRITE1R5 R"..

mtheorem rewrite1_th_59:
" for R be RelationRELAT-1M1 holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-critical-wrtREWRITE1R13 R implies (a,b)are-convertible-wrtREWRITE1R2 R"
  using rewrite1_th_37 rewrite1_th_45 sorry

mtheorem rewrite1_th_60:
" for R be RelationRELAT-1M1 holds  not ( ex a be objectHIDDENM1 st  ex b be objectHIDDENM1 st (a,b)are-critical-wrtREWRITE1R13 R) implies R be locally-confluentREWRITE1V10"
proof(rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  assume A1: " not ( ex a be objectHIDDENM1 st  ex b be objectHIDDENM1 st (a,b)are-critical-wrtREWRITE1R13 R)"
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R implies (b,c)are-convergent-wrtREWRITE1R5 R"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix c assume [ty]: "c be objectHIDDENM1"
    assume "[TARSKIK4 a,b ] inHIDDENR3 R & [TARSKIK4 a,c ] inHIDDENR3 R"
    then have A2: "(b,c)are-divergent<=1-wrtREWRITE1R8 R"
       sorry
    have " not (b,c)are-critical-wrtREWRITE1R13 R"
      using A1 sorry
    thus "(b,c)are-convergent-wrtREWRITE1R5 R"
      using A2 sorry
  qed "sorry"
  thus "R be locally-confluentREWRITE1V10"
    using rewrite1_def_24 sorry
qed "sorry"

mtheorem rewrite1_th_61:
" for R be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Q implies (a,b)are-critical-wrtREWRITE1R13 R) implies (R,R \\/XBOOLE-0K2 Q)are-equivalentREWRITE1R12"
proof(rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix Q assume [ty]: "Q be RelationRELAT-1M1"
  assume A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 Q implies (a,b)are-critical-wrtREWRITE1R13 R"
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ((a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convertible-wrtREWRITE1R2 R \\/XBOOLE-0K2 Q) &  not ((a,b)are-convertible-wrtREWRITE1R2 R \\/XBOOLE-0K2 Q &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have A2: "R c=RELAT-1R2 R \\/XBOOLE-0K2 Q"
      using xboole_1_th_7 sorry
    have A3: "R ~RELAT-1K4 c=RELAT-1R2 (R \\/XBOOLE-0K2 Q)~RELAT-1K4"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4 implies [TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 Q)~RELAT-1K4"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "[TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4"
        then have "[TARSKIK4 y,x ] inHIDDENR3 R"
          using relat_1_def_7 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 (R \\/XBOOLE-0K2 Q)~RELAT-1K4"
          using A2 relat_1_def_7 sorry
      qed "sorry"
      thus "R ~RELAT-1K4 c=RELAT-1R2 (R \\/XBOOLE-0K2 Q)~RELAT-1K4"
        using relat_1_def_3 sorry
    qed
    show "(a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convertible-wrtREWRITE1R2 R \\/XBOOLE-0K2 Q"
      using A2 A3 rewrite1_th_22 xboole_1_th_13 sorry
    have "( ex p be RedSequenceREWRITE1M1-of (R \\/XBOOLE-0K2 Q)\\/XBOOLE-0K2 (R \\/XBOOLE-0K2 Q)~RELAT-1K4 st a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p) implies (a,b)are-convertible-wrtREWRITE1R2 R"
    proof(rule impI)
      assume Given: " ex p be RedSequenceREWRITE1M1-of (R \\/XBOOLE-0K2 Q)\\/XBOOLE-0K2 (R \\/XBOOLE-0K2 Q)~RELAT-1K4 st a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
      then obtain p where
        [ty]:"p be RedSequenceREWRITE1M1-of (R \\/XBOOLE-0K2 Q)\\/XBOOLE-0K2 (R \\/XBOOLE-0K2 Q)~RELAT-1K4" and 
        A4: "a =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"and A5: "b =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
         sorry
      let ?Z = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 Lamb1)are-convertible-wrtREWRITE1R2 R"
      have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 i)are-convertible-wrtREWRITE1R2 R) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
      proof(rule ballI,rule impMI ,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A6: "i inTARSKIR2 domFINSEQ-1K5 p implies (a,p .FUNCT-1K1 i)are-convertible-wrtREWRITE1R2 R"
          and A7: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        have A8: "i <XXREAL-0R3 lenFINSEQ-1K4 p"
          using A7 rewrite1_lm_2 sorry
        show "(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
        proof-
          have cases: "i =XBOOLE-0R4 0NUMBERSK6 or i >XXREAL-0R4 0NUMBERSK6"
             sorry
          have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies (a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
          proof(rule impI)
            assume "i =XBOOLE-0R4 0NUMBERSK6"
            thus "(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
              using A4 rewrite1_th_26 sorry
          qed
          have case2: "i >XXREAL-0R4 0NUMBERSK6 implies (a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
          proof(rule impI)
            assume A9: "i >XXREAL-0R4 0NUMBERSK6"
            then have "i inTARSKIR2 domFINSEQ-1K5 p"
              using A8 rewrite1_lm_3 sorry
            then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 (R \\/XBOOLE-0K2 Q)\\/XBOOLE-0K2 (R \\/XBOOLE-0K2 Q)~RELAT-1K4"
              using A7 rewrite1_def_2 sorry
            then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 Q or [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 (R \\/XBOOLE-0K2 Q)~RELAT-1K4"
              using xboole_0_def_3 sorry
            then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R \\/XBOOLE-0K2 Q or [TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 i ] inHIDDENR3 R \\/XBOOLE-0K2 Q"
              using relat_1_def_7 sorry
            then have "(([TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 R or [TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Q) or [TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 i ] inHIDDENR3 R) or [TARSKIK4 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 i ] inHIDDENR3 Q"
              using xboole_0_def_3 sorry
            then have "(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R or (p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 i)are-convertible-wrtREWRITE1R2 R"
              using A1 rewrite1_th_29 rewrite1_th_59 sorry
            then have "(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
              using rewrite1_lm_5 sorry
            thus "(a,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
              using A6 A8 A9 rewrite1_lm_3 rewrite1_th_30 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      then have A10: " for k be NatNAT-1M1 holds ?Z(k) implies ?Z(k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A11: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
        using finseq_5_th_6 sorry
      have A12: "?Z(0NUMBERSK6)"
        using rewrite1_lm_1 sorry
      have " for i be NatNAT-1M1 holds ?Z(i)"
        using nat_1_sch_2 A12 A10 sorry
      thus "(a,b)are-convertible-wrtREWRITE1R2 R"
        using A5 A11 sorry
    qed
    thus " not ((a,b)are-convertible-wrtREWRITE1R2 R \\/XBOOLE-0K2 Q &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
      using rewrite1_def_3 rewrite1_def_4 sorry
  qed "sorry"
  thus "(R,R \\/XBOOLE-0K2 Q)are-equivalentREWRITE1R12"
    using rewrite1_def_26 sorry
qed "sorry"

mtheorem rewrite1_th_62:
" for R be RelationRELAT-1M1 holds  ex Q be completeREWRITE1V11\<bar>RelationRELAT-1M1 st fieldRELAT-1K3 Q c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 Q)"
proof-
  have " for R be RelationRELAT-1M1 holds  ex E be setHIDDENM2 st fieldRELAT-1K3 E c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 E) &  not ((a,b)are-convergent-wrtREWRITE1R5 E &  not (a,b)are-convertible-wrtREWRITE1R2 R))"
  proof(rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show " ex E be setHIDDENM2 st fieldRELAT-1K3 E c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 E) &  not ((a,b)are-convergent-wrtREWRITE1R5 E &  not (a,b)are-convertible-wrtREWRITE1R2 R))"
    proof-
      have cases: "R =RELAT-1R1 {}XBOOLE-0K1 or R <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "R =RELAT-1R1 {}XBOOLE-0K1 implies ( ex E be setHIDDENM2 st fieldRELAT-1K3 E c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 E) &  not ((a,b)are-convergent-wrtREWRITE1R5 E &  not (a,b)are-convertible-wrtREWRITE1R2 R)))"
      proof(rule impI)
        assume A1: "R =RELAT-1R1 {}XBOOLE-0K1"
        obtain E where 
          [ty]:"E be setHIDDENM2" and EDef:"E = {}XBOOLE-0K1"
           sorry
        show " ex E be setHIDDENM2 st fieldRELAT-1K3 E c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 E) &  not ((a,b)are-convergent-wrtREWRITE1R5 E &  not (a,b)are-convertible-wrtREWRITE1R2 R))"
        proof(rule bexI[of _ "E"],rule conjMI,rule ballI,rule ballI)
          show "fieldRELAT-1K3 E c=TARSKIR1 fieldRELAT-1K3 R"
             sorry
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          have "(a,b)are-convertible-wrtREWRITE1R2 R iff a =HIDDENR1 b"
            using A1 rewrite1_th_26 rewrite1_th_27 sorry
          thus " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 E) &  not ((a,b)are-convergent-wrtREWRITE1R5 E &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
            using rewrite1_th_38 rewrite1_th_39 sorry
        qed "sorry"
      qed
      have case2: "R <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar34 be completeREWRITE1V11\<bar>RelationRELAT-1M1 st fieldRELAT-1K3 tVar34 c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 tVar34) &  not ((a,b)are-convergent-wrtREWRITE1R5 tVar34 &  not (a,b)are-convertible-wrtREWRITE1R2 R)))"
      proof(rule impI)
        assume "R <>HIDDENR2 {}XBOOLE-0K1"
        then obtain R9 where 
          [ty]:"R9 be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1" and R9Def:"R9 = R"
           sorry
        let ?xx = "the ElementSUBSET-1M1-of R9"
        obtain x1 x2 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
          A2: "?xx =HIDDENR1 [TARSKIK4 x1,x2 ]"
          using relat_1_def_1 sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1,Lamb2)are-convertible-wrtREWRITE1R2 R"
        have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?P(x,y) implies ?P(y,x)"
          using rewrite1_lm_5 sorry
        have A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(y,z) implies ?P(x,z)"
          using rewrite1_th_30 sorry
        have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R implies ?P(x,x)"
          using rewrite1_th_26 sorry
        obtain Q where
          [ty]:"Q be Equivalence-RelationEQREL-1M2-of fieldRELAT-1K3 R" and 
          A6: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Q iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ?P(x,y)"
          using eqrel_1_sch_1 A5 A3 A4 sorry
        have A7: "( for X be setHIDDENM2 holds X inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q implies X <>HIDDENR2 {}XBOOLE-0K1) & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q & Y inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q) & X <>HIDDENR2 Y implies X missesXBOOLE-0R1 Y)"
          using eqrel_1_def_4 sorry
        have "x1 inHIDDENR3 fieldRELAT-1K3 R"
          using A2 relat_1_th_15 sorry
        then have "ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,x1) inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q"
          using eqrel_1_def_3 sorry
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A8: " for A be setHIDDENM2 holds A inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q implies ( ex x be objectHIDDENM1 st X /\\XBOOLE-0K3 A =XBOOLE-0R4 {TARSKIK1 x})"
          using A7 wellord2_th_18 sorry
        let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 <>HIDDENR2 Lamb2 & (Lamb1,Lamb2)are-convertible-wrtREWRITE1R2 R) & Lamb2 inHIDDENR3 X"
        obtain P where
          [ty]:"P be RelationRELAT-1M1" and 
          A9: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 P iff (x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R) & ?Z(x,y)"
          using relat_1_sch_1 sorry
        have A10: "P be locally-confluentREWRITE1V10"
        proof-
          have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 P & [TARSKIK4 a,c ] inHIDDENR3 P implies (b,c)are-convergent-wrtREWRITE1R5 P"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            fix b assume [ty]: "b be objectHIDDENM1"
            fix c assume [ty]: "c be objectHIDDENM1"
            assume A11: "[TARSKIK4 a,b ] inHIDDENR3 P"
              and A12: "[TARSKIK4 a,c ] inHIDDENR3 P"
            have A13: "a inHIDDENR3 fieldRELAT-1K3 R"
              using A9 A11 sorry
            then have "ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,a) inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q"
              using eqrel_1_def_3 sorry
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A14: "X /\\SUBSET-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> (ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,a)) =XBOOLE-0R4 {TARSKIK1 x}"
              using A8 sorry
            have "c inHIDDENR3 fieldRELAT-1K3 R & (a,c)are-convertible-wrtREWRITE1R2 R"
              using A9 A12 sorry
            then have "[TARSKIK4 a,c ] inHIDDENR3 Q"
              using A6 A13 sorry
            then have "[TARSKIK4 c,a ] inHIDDENR3 Q"
              using eqrel_1_th_6 sorry
            then have A15: "c inHIDDENR3 ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,a)"
              using eqrel_1_th_19 sorry
            have "c inHIDDENR3 X"
              using A9 A12 sorry
            then have "c inHIDDENR3 {TARSKIK1 x}"
              using A15 A14 xboole_0_def_4 sorry
            then have A16: "c =HIDDENR1 x"
              using tarski_def_1 sorry
            have "b inHIDDENR3 fieldRELAT-1K3 R & (a,b)are-convertible-wrtREWRITE1R2 R"
              using A9 A11 sorry
            then have "[TARSKIK4 a,b ] inHIDDENR3 Q"
              using A6 A13 sorry
            then have "[TARSKIK4 b,a ] inHIDDENR3 Q"
              using eqrel_1_th_6 sorry
            then have A17: "b inHIDDENR3 ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,a)"
              using eqrel_1_th_19 sorry
            have "b inHIDDENR3 X"
              using A9 A11 sorry
            then have "b inHIDDENR3 {TARSKIK1 x}"
              using A17 A14 xboole_0_def_4 sorry
            then have Cut2367: "b =HIDDENR1 x"
              using tarski_def_1 sorry
            have "P reducesREWRITE1R1(b,b) & P reducesREWRITE1R1(c,b)"
            proof-
              show "P reducesREWRITE1R1(b,b) & P reducesREWRITE1R1(c,b)"
                using A16 rewrite1_th_12 Cut2367 sorry
            qed
            thus "(b,c)are-convergent-wrtREWRITE1R5 P"
              using bexI[of _ "b"] rewrite1_def_7 sorry
          qed "sorry"
          thus "P be locally-confluentREWRITE1V10"
            using rewrite1_def_24 sorry
        qed
        have A18: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds P reducesREWRITE1R1(x,y) implies (x,y)are-convertible-wrtREWRITE1R2 R"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (P reducesREWRITE1R1(x,y) &  not (x,y)are-convertible-wrtREWRITE1R2 R)"
          proof(rule ballI,rule ballI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            have "( ex p be RedSequenceREWRITE1M1-of P st x =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & y =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p) implies (x,y)are-convertible-wrtREWRITE1R2 R"
            proof(rule impI)
              assume Given: " ex p be RedSequenceREWRITE1M1-of P st x =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M & y =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
              then obtain p where
                [ty]:"p be RedSequenceREWRITE1M1-of P" and 
                A19: "x =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"and A20: "y =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"
                 sorry
              let ?Z = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 p implies (x,p .FUNCT-1K1 Lamb1)are-convertible-wrtREWRITE1R2 R"
              have " for i be NatNAT-1M1 holds (i inTARSKIR2 domFINSEQ-1K5 p implies (x,p .FUNCT-1K1 i)are-convertible-wrtREWRITE1R2 R) & i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies (x,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
              proof(rule ballI,rule impMI ,rule impI)
                fix i assume [ty]: "i be NatNAT-1M1"
                assume A21: "i inTARSKIR2 domFINSEQ-1K5 p implies (x,p .FUNCT-1K1 i)are-convertible-wrtREWRITE1R2 R"
                  and A22: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                have A23: "i <XXREAL-0R3 lenFINSEQ-1K4 p"
                  using A22 rewrite1_lm_2 sorry
                show "(x,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
                proof-
                  have cases: "i =XBOOLE-0R4 0NUMBERSK6 or i >XXREAL-0R4 0NUMBERSK6"
                     sorry
                  have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies (x,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
                  proof(rule impI)
                    assume "i =XBOOLE-0R4 0NUMBERSK6"
                    thus "(x,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
                      using A19 rewrite1_th_26 sorry
                  qed
                  have case2: "i >XXREAL-0R4 0NUMBERSK6 implies (x,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
                  proof(rule impI)
                    assume A24: "i >XXREAL-0R4 0NUMBERSK6"
                    then have "i inTARSKIR2 domFINSEQ-1K5 p"
                      using A23 rewrite1_lm_3 sorry
                    then have "[TARSKIK4 p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P"
                      using A22 rewrite1_def_2 sorry
                    then have "(p .FUNCT-1K1 i,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
                      using A9 sorry
                    thus "(x,p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
                      using A21 A23 A24 rewrite1_lm_3 rewrite1_th_30 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              then have A25: " for k be NatNAT-1M1 holds ?Z(k) implies ?Z(k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have A26: "lenFINSEQ-1K4 p inTARSKIR2 domFINSEQ-1K5 p"
                using finseq_5_th_6 sorry
              have A27: "?Z(0NUMBERSK6)"
                using rewrite1_lm_1 sorry
              have " for i be NatNAT-1M1 holds ?Z(i)"
                using nat_1_sch_2 A27 A25 sorry
              thus "(x,y)are-convertible-wrtREWRITE1R2 R"
                using A20 A26 sorry
            qed
            thus " not (P reducesREWRITE1R1(x,y) &  not (x,y)are-convertible-wrtREWRITE1R2 R)"
              using rewrite1_def_3 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "P be strongly-normalizingREWRITE1V3"
        proof-
          have " for f be ManySortedSetPBOOLEM1-of NATNUMBERSK1 holds  not ( for i be NatNAT-1M1 holds [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P)"
          proof(rule ballI)
            fix f assume [ty]: "f be ManySortedSetPBOOLEM1-of NATNUMBERSK1"
            show " not ( for i be NatNAT-1M1 holds [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P)"
            proof-
              have cases: " not [TARSKIK4 f .FUNCT-1K1 (0NUMBERSK6),f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P or [TARSKIK4 f .FUNCT-1K1 (0NUMBERSK6),f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P"
                 sorry
              have case1: " not [TARSKIK4 f .FUNCT-1K1 (0NUMBERSK6),f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P implies  not ( for i be NatNAT-1M1 holds [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P)"
              proof(rule impI)
                assume " not [TARSKIK4 f .FUNCT-1K1 (0NUMBERSK6),f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P"
                thus " not ( for i be NatNAT-1M1 holds [TARSKIK4 f .FUNCT-1K1 i,f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P)"
                   sorry
              qed
              have case2: "[TARSKIK4 f .FUNCT-1K1 (0NUMBERSK6),f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P implies ( ex j be ElementSUBSET-1M1-of NATNUMBERSK1 st [TARSKIK4 f .FUNCT-1K1 j,f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P implies  False )"
              proof(rule impI)
                assume A28: "[TARSKIK4 f .FUNCT-1K1 (0NUMBERSK6),f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P"
                obtain j where 
                  [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                   sorry
                show " ex j be ElementSUBSET-1M1-of NATNUMBERSK1 st [TARSKIK4 f .FUNCT-1K1 j,f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P implies  False "
                proof(rule bexI[of _ "j"],rule impI)
                  have A29: "f .FUNCT-1K1 j inTARSKIR2 X"
                    using A9 A28 sorry
                  assume A30: "[TARSKIK4 f .FUNCT-1K1 j,f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 P"
                  then have A31: "f .FUNCT-1K1 j inTARSKIR2 fieldRELAT-1K3 R"
                    using A9 sorry
                  then have "ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,f .FUNCT-1K1 j) inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q"
                    using eqrel_1_def_3 sorry
                  then obtain x where
                    [ty]:"x be objectHIDDENM1" and 
                    A32: "X /\\SUBSET-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> (ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,f .FUNCT-1K1 j)) =XBOOLE-0R4 {TARSKIK1 x}"
                    using A8 sorry
                  have "f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 fieldRELAT-1K3 R & (f .FUNCT-1K1 j,f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M))are-convertible-wrtREWRITE1R2 R"
                    using A9 A30 sorry
                  then have "[TARSKIK4 f .FUNCT-1K1 j,f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Q"
                    using A6 A31 sorry
                  then have "[TARSKIK4 f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 j ] inHIDDENR3 Q"
                    using eqrel_1_th_6 sorry
                  then have A33: "f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,f .FUNCT-1K1 j)"
                    using eqrel_1_th_19 sorry
                  have "f .FUNCT-1K1 j inTARSKIR2 ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,f .FUNCT-1K1 j)"
                    using A31 eqrel_1_th_20 sorry
                  then have "f .FUNCT-1K1 j inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> (ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,f .FUNCT-1K1 j))"
                    using A29 xboole_0_def_4 sorry
                  then have A34: "f .FUNCT-1K1 j =HIDDENR1 x"
                    using A32 tarski_def_1 sorry
                  have "f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 X"
                    using A9 A30 sorry
                  then have "f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> (ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,f .FUNCT-1K1 j))"
                    using A33 xboole_0_def_4 sorry
                  then have "f .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x"
                    using A32 tarski_def_1 sorry
                  thus " False "
                    using A9 A30 A34 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus "P be strongly-normalizingREWRITE1V3"
            using rewrite1_def_15 sorry
        qed
        then have 
          [ty]:"P be strongly-normalizingREWRITE1V3\<bar>locally-confluentREWRITE1V10\<bar>RelationRELAT-1M1"
          using A10 sorry
        show " ex tVar34 be completeREWRITE1V11\<bar>RelationRELAT-1M1 st fieldRELAT-1K3 tVar34 c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 tVar34) &  not ((a,b)are-convergent-wrtREWRITE1R5 tVar34 &  not (a,b)are-convertible-wrtREWRITE1R2 R))"
        proof(rule bexI[of _ "P"],rule conjMI,rule ballI,rule ballI)
          show "fieldRELAT-1K3 P c=TARSKIR1 fieldRELAT-1K3 R"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 P implies x inHIDDENR3 fieldRELAT-1K3 R"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 fieldRELAT-1K3 P"
              then have "x inHIDDENR3 domRELAT-1K1 P or x inHIDDENR3 rngRELAT-1K2 P"
                using xboole_0_def_3 sorry
              then have "( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 P) or ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 P)"
                using xtuple_0_def_12 xtuple_0_def_13 sorry
              thus "x inHIDDENR3 fieldRELAT-1K3 R"
                using A9 sorry
            qed "sorry"
            thus "fieldRELAT-1K3 P c=TARSKIR1 fieldRELAT-1K3 R"
              using tarski_def_3 sorry
          qed
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          show " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 P) &  not ((a,b)are-convergent-wrtREWRITE1R5 P &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
          proof-
            show " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 P) &  not ((a,b)are-convergent-wrtREWRITE1R5 P &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
            proof-
              have cases: "a =HIDDENR1 b or a <>HIDDENR2 b"
                 sorry
              have case1: "a =HIDDENR1 b implies  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 P) &  not ((a,b)are-convergent-wrtREWRITE1R5 P &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
              proof(rule impI)
                assume "a =HIDDENR1 b"
                thus " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 P) &  not ((a,b)are-convergent-wrtREWRITE1R5 P &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
                  using rewrite1_th_26 rewrite1_th_38 sorry
              qed
              have case2: "a <>HIDDENR2 b implies ((a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convergent-wrtREWRITE1R5 P) &  not ((a,b)are-convergent-wrtREWRITE1R5 P &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
              proof(rule impI,rule conjMI)
                assume A35: "a <>HIDDENR2 b"
                show "(a,b)are-convertible-wrtREWRITE1R2 R implies (a,b)are-convergent-wrtREWRITE1R5 P"
                proof(rule impI)
                  assume A36: "(a,b)are-convertible-wrtREWRITE1R2 R"
                  then have A37: "b inHIDDENR3 fieldRELAT-1K3 R"
                    using A35 rewrite1_th_32 sorry
                  then have "ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,b) inTARSKIR2 ClassEQREL-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> Q"
                    using eqrel_1_def_3 sorry
                  then obtain x where
                    [ty]:"x be objectHIDDENM1" and 
                    A38: "X /\\SUBSET-1K9\<^bsub>(fieldRELAT-1K3 R)\<^esub> (ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,b)) =XBOOLE-0R4 {TARSKIK1 x}"
                    using A8 sorry
                  have A39: "a inHIDDENR3 fieldRELAT-1K3 R"
                    using A35 A36 rewrite1_th_32 sorry
                  then have A40: "[TARSKIK4 a,b ] inHIDDENR3 Q"
                    using A6 A36 A37 sorry
                  show "(a,b)are-convergent-wrtREWRITE1R5 P"
                  proof-
                    have A41: "x inHIDDENR3 {TARSKIK1 x}"
                      using tarski_def_1 sorry
                    then have A42: "x inHIDDENR3 X"
                      using A38 xboole_0_def_4 sorry
                    have A43: "x inHIDDENR3 ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,b)"
                      using A38 A41 xboole_0_def_4 sorry
                    then have "[TARSKIK4 x,b ] inHIDDENR3 Q"
                      using eqrel_1_th_19 sorry
                    then have "[TARSKIK4 b,x ] inHIDDENR3 Q"
                      using eqrel_1_th_6 sorry
                    then have "(b,x)are-convertible-wrtREWRITE1R2 R"
                      using A6 sorry
                    then have A44: "b =HIDDENR1 x or [TARSKIK4 b,x ] inHIDDENR3 P"
                      using A9 A37 A38 A41 A42 sorry
                    have "a inHIDDENR3 ClassEQREL-1K7\<^bsub>(fieldRELAT-1K3 R,fieldRELAT-1K3 R)\<^esub>(Q,b)"
                      using A40 eqrel_1_th_19 sorry
                    then have "[TARSKIK4 a,x ] inHIDDENR3 Q"
                      using A43 eqrel_1_th_22 sorry
                    then have "(a,x)are-convertible-wrtREWRITE1R2 R"
                      using A6 sorry
                    then have Cut2485: "a =HIDDENR1 x or [TARSKIK4 a,x ] inHIDDENR3 P"
                      using A9 A39 A38 A41 A42 sorry
                    have "P reducesREWRITE1R1(a,x) & P reducesREWRITE1R1(b,x)"
                    proof-
                      show "P reducesREWRITE1R1(a,x) & P reducesREWRITE1R1(b,x)"
                        using A44 rewrite1_th_12 rewrite1_th_15 Cut2485 sorry
                    qed
                    thus "(a,b)are-convergent-wrtREWRITE1R5 P"
                      using bexI[of _ "x"] rewrite1_def_7 sorry
                  qed
                qed
                have "( ex c be objectHIDDENM1 st P reducesREWRITE1R1(a,c) & P reducesREWRITE1R1(b,c)) implies (a,b)are-convertible-wrtREWRITE1R2 R"
                proof(rule impI)
                  assume Given: " ex c be objectHIDDENM1 st P reducesREWRITE1R1(a,c) & P reducesREWRITE1R1(b,c)"
                  then obtain c where
                    [ty]:"c be objectHIDDENM1" and 
                    A45: "P reducesREWRITE1R1(a,c) & P reducesREWRITE1R1(b,c)"
                     sorry
                  have "(a,c)are-convertible-wrtREWRITE1R2 R & (c,b)are-convertible-wrtREWRITE1R2 R"
                    using A18 A45 rewrite1_lm_5 sorry
                  thus "(a,b)are-convertible-wrtREWRITE1R2 R"
                    using rewrite1_th_30 sorry
                qed
                thus " not ((a,b)are-convergent-wrtREWRITE1R5 P &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
                  using rewrite1_def_7 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rewrite1_def_28 ("CompletionREWRITE1M2-of  _ " [70]70 ) where
  mlet "R be RelationRELAT-1M1"
"mode CompletionREWRITE1M2-of R \<rightarrow> completeREWRITE1V11\<bar>RelationRELAT-1M1 means
  (\<lambda>it.  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 it)"
proof-
  (*existence*)
    show " ex it be completeREWRITE1V11\<bar>RelationRELAT-1M1 st  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 it"
    proof-
      have " not ( for VarFor1 be completeREWRITE1V11\<bar>RelationRELAT-1M1 holds  not ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 VarFor1) &  not ((a,b)are-convergent-wrtREWRITE1R5 VarFor1 &  not (a,b)are-convertible-wrtREWRITE1R2 R)))"
      proof-
        have " ex Q be completeREWRITE1V11\<bar>RelationRELAT-1M1 st fieldRELAT-1K3 Q c=TARSKIR1 fieldRELAT-1K3 R & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 Q)"
          using rewrite1_th_62 sorry
        thus " not ( for VarFor1 be completeREWRITE1V11\<bar>RelationRELAT-1M1 holds  not ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 VarFor1) &  not ((a,b)are-convergent-wrtREWRITE1R5 VarFor1 &  not (a,b)are-convertible-wrtREWRITE1R2 R)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rewrite1_th_63:
" for R be RelationRELAT-1M1 holds  for C be CompletionREWRITE1M2-of R holds (R,C)are-equivalentREWRITE1R12"
proof(rule ballI,rule ballI)
  fix R assume [ty]: "R be RelationRELAT-1M1"
  fix C assume [ty]: "C be CompletionREWRITE1M2-of R"
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convertible-wrtREWRITE1R2 C) &  not ((a,b)are-convertible-wrtREWRITE1R2 C &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "(a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 C"
      using rewrite1_def_28 sorry
    thus " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convertible-wrtREWRITE1R2 C) &  not ((a,b)are-convertible-wrtREWRITE1R2 C &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
      using rewrite1_def_23 rewrite1_th_37 sorry
  qed "sorry"
  thus "(R,C)are-equivalentREWRITE1R12"
    using rewrite1_def_26 sorry
qed "sorry"

mtheorem rewrite1_th_64:
" for R be RelationRELAT-1M1 holds  for Q be completeREWRITE1V11\<bar>RelationRELAT-1M1 holds (R,Q)are-equivalentREWRITE1R12 implies Q be CompletionREWRITE1M2-of R"
proof-
  have " for R be RelationRELAT-1M1 holds  for Q be completeREWRITE1V11\<bar>RelationRELAT-1M1 holds  not ((R,Q)are-equivalentREWRITE1R12 &  not Q be CompletionREWRITE1M2-of R)"
  proof(rule ballI,rule ballI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix Q assume [ty]: "Q be completeREWRITE1V11\<bar>RelationRELAT-1M1"
    have "( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convertible-wrtREWRITE1R2 Q) implies Q be CompletionREWRITE1M2-of R"
    proof(rule impI)
      assume A1: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convertible-wrtREWRITE1R2 Q"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 Q) &  not ((a,b)are-convergent-wrtREWRITE1R5 Q &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
      proof(rule ballI,rule ballI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        have "(a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convertible-wrtREWRITE1R2 Q"
          using A1 sorry
        thus " not ((a,b)are-convertible-wrtREWRITE1R2 R &  not (a,b)are-convergent-wrtREWRITE1R5 Q) &  not ((a,b)are-convergent-wrtREWRITE1R5 Q &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
          using rewrite1_def_23 rewrite1_th_37 sorry
      qed "sorry"
      thus "Q be CompletionREWRITE1M2-of R"
        using rewrite1_def_28 sorry
    qed
    thus " not ((R,Q)are-equivalentREWRITE1R12 &  not Q be CompletionREWRITE1M2-of R)"
      using rewrite1_def_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rewrite1_th_65:
" for R be RelationRELAT-1M1 holds  for C be CompletionREWRITE1M2-of R holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a,b)are-convertible-wrtREWRITE1R2 R iff nfREWRITE1K2(a,C) =XBOOLE-0R4 nfREWRITE1K2(b,C)"
proof-
  have " for R be RelationRELAT-1M1 holds  for C be CompletionREWRITE1M2-of R holds  for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ((a,b)are-convertible-wrtREWRITE1R2 R implies nfREWRITE1K2(a,C) =XBOOLE-0R4 nfREWRITE1K2(b,C)) &  not (nfREWRITE1K2(a,C) =XBOOLE-0R4 nfREWRITE1K2(b,C) &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix C assume [ty]: "C be CompletionREWRITE1M2-of R"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    have "nfREWRITE1K2(a,C) is-a-normal-form-ofREWRITE1R4(a,C)"
      using rewrite1_th_54 sorry
    then have A1: "C reducesREWRITE1R1(a,nfREWRITE1K2(a,C))"
       sorry
    have "(a,b)are-convergent-wrtREWRITE1R5 C implies (a,b)are-convertible-wrtREWRITE1R2 C"
      using rewrite1_th_37 sorry
    thus "(a,b)are-convertible-wrtREWRITE1R2 R implies nfREWRITE1K2(a,C) =XBOOLE-0R4 nfREWRITE1K2(b,C)"
      using rewrite1_def_28 rewrite1_th_55 sorry
    have "nfREWRITE1K2(b,C) is-a-normal-form-ofREWRITE1R4(b,C)"
      using rewrite1_th_54 sorry
    then have A2: "C reducesREWRITE1R1(b,nfREWRITE1K2(b,C))"
       sorry
    have "(a,b)are-convertible-wrtREWRITE1R2 R iff (a,b)are-convergent-wrtREWRITE1R5 C"
      using rewrite1_def_28 sorry
    thus " not (nfREWRITE1K2(a,C) =XBOOLE-0R4 nfREWRITE1K2(b,C) &  not (a,b)are-convertible-wrtREWRITE1R2 R)"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
