theory fcont_3
  imports limfunc1 fcont_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, X for "setHIDDENM2"
reserve x0, r1, r2, g, g1, g2, p, s for "RealXREAL-0M1"
reserve r for "RealXREAL-0M1"
reserve n, m for "NatORDINAL1M6"
reserve a, b, d for "Real-SequenceSEQ-1M1"
reserve f for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem fcont_3_cl_1:
"cluster [#]SUBSET-1K2 REALNUMBERSK2 as-term-is closedRCOMP-1V2"
proof
(*coherence*)
  show "[#]SUBSET-1K2 REALNUMBERSK2 be closedRCOMP-1V2"
    using xreal_0_def_1 sorry
qed "sorry"

mtheorem fcont_3_cl_2:
"cluster emptyXBOOLE-0V1 also-is closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be emptyXBOOLE-0V1 implies it be closedRCOMP-1V2"
    using xboole_1_th_3 sorry
qed "sorry"

mtheorem fcont_3_cl_3:
"cluster [#]SUBSET-1K2 REALNUMBERSK2 as-term-is openRCOMP-1V3"
proof
(*coherence*)
  show "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3"
  proof-
    have "([#]SUBSET-1K2 REALNUMBERSK2)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> =XBOOLE-0R4 {}SUBSET-1K1 REALNUMBERSK2"
      using xboole_1_th_37 sorry
    thus "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3"
       sorry
  qed
qed "sorry"

mtheorem fcont_3_cl_4:
"cluster emptyXBOOLE-0V1 also-is openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be emptyXBOOLE-0V1 implies it be openRCOMP-1V3"
  proof-
    have " for S be SubsetSUBSET-1M2-of REALNUMBERSK2 holds S be emptyXBOOLE-0V1 implies S be openRCOMP-1V3"
    proof(rule ballI,rule impI)
      fix S assume [ty]: "S be SubsetSUBSET-1M2-of REALNUMBERSK2"
      assume "S be emptyXBOOLE-0V1"
      then have "S `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
         sorry
      thus "S be openRCOMP-1V3"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_3_cl_5:
  mlet "r be RealXREAL-0M1"
"cluster right-closed-halflineLIMFUNC1K3 r as-term-is closedRCOMP-1V2"
proof
(*coherence*)
  show "right-closed-halflineLIMFUNC1K3 r be closedRCOMP-1V2"
  proof-
    let ?b = "seq-constSEQ-1K1 r"
    have " for a be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 right-closed-halflineLIMFUNC1K3 r & a be convergentSEQ-2V5 implies limSEQ-2K1 a inHIDDENR3 right-closed-halflineLIMFUNC1K3 r"
    proof(rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
      assume A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 right-closed-halflineLIMFUNC1K3 r"
        and A2: "a be convergentSEQ-2V5"
      have A3: " for n be NatORDINAL1M6 holds (seq-constSEQ-1K1 r).FUNCT-1K1 n <=XXREAL-0R1 a .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatORDINAL1M6"
        have "a .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
          using valued_0_th_28 sorry
        then have "a .FUNCT-1K1 n inTARSKIR2 right-closed-halflineLIMFUNC1K3 r"
          using A1 sorry
        then have "a .FUNCT-1K1 n inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : r <=XXREAL-0R1 g1 }"
          using xxreal_1_th_232 sorry
        then have " ex r1 be RealXREAL-0M1 st a .FUNCT-1K1 n =COMPLEX1R1 r1 & r <=XXREAL-0R1 r1"
           sorry
        thus "(seq-constSEQ-1K1 r).FUNCT-1K1 n <=XXREAL-0R1 a .FUNCT-1K1 n"
          using seq_1_th_57 sorry
      qed "sorry"
      have "limSEQ-2K1 ?b =HIDDENR1 ?b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using seq_4_th_26 sorry
      also have "... = r"
        using seq_1_th_57 sorry
      finally have "limSEQ-2K1 ?b =HIDDENR1 r"
         sorry
      then have "r <=XXREAL-0R1 limSEQ-2K1 a"
        using A2 A3 seq_2_th_18 sorry
      then have "limSEQ-2K1 a inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : r <=XXREAL-0R1 g1 }"
         sorry
      thus "limSEQ-2K1 a inHIDDENR3 right-closed-halflineLIMFUNC1K3 r"
        using xxreal_1_th_232 sorry
    qed "sorry"
    thus "right-closed-halflineLIMFUNC1K3 r be closedRCOMP-1V2"
      using rcomp_1_def_4 sorry
  qed
qed "sorry"

mtheorem fcont_3_cl_6:
  mlet "r be RealXREAL-0M1"
"cluster left-closed-halflineLIMFUNC1K2 r as-term-is closedRCOMP-1V2"
proof
(*coherence*)
  show "left-closed-halflineLIMFUNC1K2 r be closedRCOMP-1V2"
  proof-
    let ?b = "seq-constSEQ-1K1 r"
    have " for a be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 left-closed-halflineLIMFUNC1K2 r & a be convergentSEQ-2V5 implies limSEQ-2K1 a inHIDDENR3 left-closed-halflineLIMFUNC1K2 r"
    proof(rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
      assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 left-closed-halflineLIMFUNC1K2 r"
        and A5: "a be convergentSEQ-2V5"
      have A6: " for n be NatORDINAL1M6 holds a .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 r).FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatORDINAL1M6"
        have "a .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
          using valued_0_th_28 sorry
        then have "a .FUNCT-1K1 n inTARSKIR2 left-closed-halflineLIMFUNC1K2 r"
          using A4 sorry
        then have "a .FUNCT-1K1 n inTARSKIR2 {g where g be RealXREAL-0M1 : g <=XXREAL-0R1 r }"
          using xxreal_1_th_231 sorry
        then have " ex r1 be RealXREAL-0M1 st a .FUNCT-1K1 n =COMPLEX1R1 r1 & r1 <=XXREAL-0R1 r"
           sorry
        thus "a .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 r).FUNCT-1K1 n"
          using seq_1_th_57 sorry
      qed "sorry"
      have "limSEQ-2K1 ?b =HIDDENR1 ?b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using seq_4_th_26 sorry
      also have "... = r"
        using seq_1_th_57 sorry
      finally have "limSEQ-2K1 ?b =HIDDENR1 r"
         sorry
      then have "limSEQ-2K1 a <=XXREAL-0R1 r"
        using A5 A6 seq_2_th_18 sorry
      then have "limSEQ-2K1 a inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : g1 <=XXREAL-0R1 r }"
         sorry
      thus "limSEQ-2K1 a inHIDDENR3 left-closed-halflineLIMFUNC1K2 r"
        using xxreal_1_th_231 sorry
    qed "sorry"
    thus "left-closed-halflineLIMFUNC1K2 r be closedRCOMP-1V2"
      using rcomp_1_def_4 sorry
  qed
qed "sorry"

mtheorem fcont_3_cl_7:
  mlet "r be RealXREAL-0M1"
"cluster right-open-halflineLIMFUNC1K4 r as-term-is openRCOMP-1V3"
proof
(*coherence*)
  show "right-open-halflineLIMFUNC1K4 r be openRCOMP-1V3"
  proof-
    have "(right-open-halflineLIMFUNC1K4 r)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> =XBOOLE-0R4 left-closed-halflineLIMFUNC1K2 r"
      using xxreal_1_th_224 xxreal_1_th_296 sorry
    thus "right-open-halflineLIMFUNC1K4 r be openRCOMP-1V3"
       sorry
  qed
qed "sorry"

mtheorem fcont_3_cl_8:
  mlet "r be RealXREAL-0M1"
"cluster halflinePROB-1K10 r as-term-is openRCOMP-1V3"
proof
(*coherence*)
  show "halflinePROB-1K10 r be openRCOMP-1V3"
  proof-
    have "(left-open-halflineLIMFUNC1K1 r)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> =XBOOLE-0R4 right-closed-halflineLIMFUNC1K3 r"
      using xxreal_1_th_224 xxreal_1_th_290 sorry
    thus "halflinePROB-1K10 r be openRCOMP-1V3"
       sorry
  qed
qed "sorry"

mtheorem fcont_3_th_1:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
proof-
  have " for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies  not  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
    then have A1: " ex g1 be RealXREAL-0M1 st (g1 =COMPLEX1R1 g & x0 -XCMPLX-0K6 r <XXREAL-0R3 g1) & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 r"
       sorry
    show " not  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
    proof-
      have cases: "x0 <=XXREAL-0R1 g or g <=XXREAL-0R1 x0"
         sorry
      have case1: "x0 <=XXREAL-0R1 g implies  not  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
      proof(rule impI)
        assume A2: "x0 <=XXREAL-0R1 g"
        have A3: "g -XCMPLX-0K6 x0 <XXREAL-0R3 (x0 +XCMPLX-0K2 r)-XCMPLX-0K6 x0"
          using A1 xreal_1_th_14 sorry
        have "0NUMBERSK6 <=XXREAL-0R1 g -XCMPLX-0K6 x0"
          using A2 xreal_1_th_48 sorry
        thus " not  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
          using A3 absvalue_def_1 sorry
      qed
      have case2: "g <=XXREAL-0R1 x0 implies  not  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
      proof(rule impI)
        assume "g <=XXREAL-0R1 x0"
        then have "0NUMBERSK6 <=XXREAL-0R1 x0 -XCMPLX-0K6 g"
          using xreal_1_th_48 sorry
        then have A4: "x0 -XCMPLX-0K6 g =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (g -XCMPLX-0K6 x0) .|"
          using absvalue_def_1 sorry
        also have "... =  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .|"
          using complex1_th_52 sorry
        finally have "x0 -XCMPLX-0K6 g =HIDDENR1  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .|"
           sorry
        have "x0 -XCMPLX-0K6 g <XXREAL-0R3 x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 r)"
          using A1 xreal_1_th_15 sorry
        thus " not  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
          using A4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_2:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies g -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
proof-
  have " for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies g -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?r1 = "g -XCMPLX-0K6 x0"
    assume "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
    then have " |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
      using fcont_3_th_1 sorry
    then have " |.COMPLEX1K10 ?r1 -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
       sorry
    then have "?r1 inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6 -XCMPLX-0K6 r,0NUMBERSK6 +XCMPLX-0K2 r .["
      using rcomp_1_th_1 sorry
    thus "g -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_3:
" for x0 be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g =COMPLEX1R1 x0 +XCMPLX-0K2 r1 &  |.COMPLEX1K10 r1.| <XXREAL-0R3 r implies 0NUMBERSK6 <XXREAL-0R3 r & g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
proof-
  have " for x0 be RealXREAL-0M1 holds  for r1 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g =COMPLEX1R1 x0 +XCMPLX-0K2 r1 &  |.COMPLEX1K10 r1.| <XXREAL-0R3 r implies 0NUMBERSK6 <XXREAL-0R3 r & g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "g =COMPLEX1R1 x0 +XCMPLX-0K2 r1"
      and A2: " |.COMPLEX1K10 r1.| <XXREAL-0R3 r"
    show "0NUMBERSK6 <XXREAL-0R3 r"
      using A2 complex1_th_46 sorry
    have " |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
      using A1 A2 sorry
    thus "g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
      using rcomp_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_4:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .[ implies 0NUMBERSK6 <XXREAL-0R3 r & g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
proof-
  have " for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds g -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .[ implies  not 0NUMBERSK6 <XXREAL-0R3 r & g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?r1 = "g -XCMPLX-0K6 x0"
    assume "?r1 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
    then have " ex g1 be RealXREAL-0M1 st (g1 =COMPLEX1R1 ?r1 & -XCMPLX-0K4 r <XXREAL-0R3 g1) & g1 <XXREAL-0R3 r"
       sorry
    then have A1: " |.COMPLEX1K10 ?r1.| <XXREAL-0R3 r"
      using seq_2_th_1 sorry
    have "x0 +XCMPLX-0K2 ?r1 =COMPLEX1R1 g"
       sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 r & g inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
      using A1 fcont_3_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_5:
" for p be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for x0 be RealXREAL-0M1 holds ( for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) implies a be convergentSEQ-2V5 & limSEQ-2K1 a =COMPLEX1R1 x0"
proof-
  have " for p be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for x0 be RealXREAL-0M1 holds ( for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) implies a be convergentSEQ-2V5 & limSEQ-2K1 a =HIDDENR1 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    let ?F = "\<lambda>Lamb1. p /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)"
    obtain d where
      [ty]:"d be Real-SequenceSEQ-1M1" and 
      A1: " for n be NatORDINAL1M6 holds d .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    let ?b = "seq-constSEQ-1K1 x0"
    assume A2: " for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq-constSEQ-1K1 x0 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq-constSEQ-1K1 x0 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq-constSEQ-1K1 x0).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_15 sorry
      also have "... = x0 -XCMPLX-0K6 d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_57 sorry
      also have "... = x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
        using A1 sorry
      also have "... = a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A2 sorry
      finally show "(seq-constSEQ-1K1 x0 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A3: "a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?b -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
      using funct_2_th_63 sorry
    have A4: "d be convergentSEQ-2V5"
      using A1 seq_4_th_31 sorry
    thus "a be convergentSEQ-2V5"
      using A3 sorry
    have A5: "limSEQ-2K1 ?b =HIDDENR1 ?b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = x0"
      using seq_1_th_57 sorry
    finally have "limSEQ-2K1 ?b =HIDDENR1 x0"
       sorry
    have "limSEQ-2K1 d =COMPLEX1R1 0NUMBERSK6"
      using A1 seq_4_th_31 sorry
    then have "limSEQ-2K1 a =HIDDENR1 x0 -XCMPLX-0K6 0NUMBERSK6"
      using A4 A5 A3 seq_2_th_12 sorry
    also have "... = x0"
       sorry
    finally show "limSEQ-2K1 a =HIDDENR1 x0"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_6:
" for p be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for x0 be RealXREAL-0M1 holds ( for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) implies a be convergentSEQ-2V5 & limSEQ-2K1 a =COMPLEX1R1 x0"
proof-
  have " for p be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for x0 be RealXREAL-0M1 holds ( for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) implies a be convergentSEQ-2V5 & limSEQ-2K1 a =HIDDENR1 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    let ?F = "\<lambda>Lamb1. p /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)"
    obtain d where
      [ty]:"d be Real-SequenceSEQ-1M1" and 
      A1: " for n be NatORDINAL1M6 holds d .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    let ?b = "seq-constSEQ-1K1 x0"
    assume A2: " for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq-constSEQ-1K1 x0 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq-constSEQ-1K1 x0 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (seq-constSEQ-1K1 x0).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_1 sorry
      also have "... = x0 +XCMPLX-0K2 d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_57 sorry
      also have "... = x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
        using A1 sorry
      also have "... = a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A2 sorry
      finally show "(seq-constSEQ-1K1 x0 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A3: "a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
      using funct_2_th_63 sorry
    have A4: "d be convergentSEQ-2V5"
      using A1 seq_4_th_31 sorry
    thus "a be convergentSEQ-2V5"
      using A3 sorry
    have A5: "limSEQ-2K1 ?b =HIDDENR1 ?b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = x0"
      using seq_1_th_57 sorry
    finally have "limSEQ-2K1 ?b =HIDDENR1 x0"
       sorry
    have "limSEQ-2K1 d =COMPLEX1R1 0NUMBERSK6"
      using A1 seq_4_th_31 sorry
    then have "limSEQ-2K1 a =HIDDENR1 x0 +XCMPLX-0K2 0NUMBERSK6"
      using A4 A5 A3 seq_2_th_6 sorry
    also have "... = x0"
       sorry
    finally show "limSEQ-2K1 a =HIDDENR1 x0"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_7:
" for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-continuous-inFCONT-1R1 x0 & f .FUNCT-1K1 x0 <>HIDDENR2 r) & ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 N implies f .FUNCT-1K1 g <>HIDDENR2 r))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 & f .FUNCT-1K1 x0 <>HIDDENR2 r implies (( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( for N be NeighbourhoodRCOMP-1M1-of x0 holds  not N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f or ( ex g be RealXREAL-0M1 st g inHIDDENR3 N & f .FUNCT-1K1 g =COMPLEX1R1 r)) implies  False ))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-continuous-inFCONT-1R1 x0"
      and A2: "f .FUNCT-1K1 x0 <>HIDDENR2 r"
    assume Given: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A3: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 p"and A5: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 p,x0 +XCMPLX-0K2 p .["
      using rcomp_1_def_6 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. ((x0 -XCMPLX-0K6 p /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 Lamb2 & Lamb2 <XXREAL-0R3 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)) & f .FUNCT-1K1 Lamb2 =COMPLEX1R1 r) & Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A6: " for N be NeighbourhoodRCOMP-1M1-of x0 holds  not N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f or ( ex g be RealXREAL-0M1 st g inHIDDENR3 N & f .FUNCT-1K1 g =COMPLEX1R1 r)"
    have A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,g)"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 tVar1 & tVar1 <XXREAL-0R3 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) & (f .FUNCT-1K1 tVar1 =COMPLEX1R1 r & tVar1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A8: "0NUMBERSK6 <=XXREAL-0R1 n"
          using nat_1_th_2 sorry
        then obtain Nn where 
          [ty]:"Nn be NeighbourhoodRCOMP-1M1-of x0" and NnDef:"Nn = ].RCOMP-1K2 x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M),x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) .["
          using A4 rcomp_1_def_6 xreal_1_th_139 sorry
        have A9: "Nn c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Nn implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Nn"
            then obtain g2 where
              [ty]:"g2 be RealXREAL-0M1" and 
              A10: "g2 =HIDDENR1 x"and A11: "x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 g2"and A12: "g2 <XXREAL-0R3 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
               sorry
            have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 n +XCMPLX-0K2 \<one>\<^sub>M"
              using A8 xreal_1_th_7 sorry
            then have A13: "p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <=XXREAL-0R1 p /XCMPLX-0K7 \<one>\<^sub>M"
              using A4 xreal_1_th_118 sorry
            then have "x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <=XXREAL-0R1 x0 +XCMPLX-0K2 p"
              using xreal_1_th_7 sorry
            then have A14: "g2 <XXREAL-0R3 x0 +XCMPLX-0K2 p"
              using A12 xxreal_0_th_2 sorry
            have "x0 -XCMPLX-0K6 p <=XXREAL-0R1 x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
              using A13 xreal_1_th_13 sorry
            then have "x0 -XCMPLX-0K6 p <XXREAL-0R3 g2"
              using A11 xxreal_0_th_2 sorry
            then have "x inHIDDENR3 N"
              using A5 A10 A14 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A3 sorry
          qed "sorry"
          thus "Nn c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using tarski_def_3 sorry
        qed
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A15: "g inHIDDENR3 Nn"and A16: "f .FUNCT-1K1 g =COMPLEX1R1 r"
          using A6 sorry
        have 
          [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        show " ex tVar1 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 tVar1 & tVar1 <XXREAL-0R3 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)) & (f .FUNCT-1K1 tVar1 =COMPLEX1R1 r & tVar1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
        proof(rule bexI[of _ "g"],rule conjMI,rule conjMI)
          have " ex g1 be RealXREAL-0M1 st (g1 =COMPLEX1R1 g & x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 g1) & g1 <XXREAL-0R3 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
            using A15 sorry
          thus "x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 g & g <XXREAL-0R3 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
             sorry
          show "f .FUNCT-1K1 g =COMPLEX1R1 r"
            using A16 sorry
          show "g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A9 A15 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain d where
      [ty]:"d be Real-SequenceSEQ-1M1" and 
      A17: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
      using funct_2_sch_3 A7 sorry
    have A18: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> d c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> d implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> d"
        then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using funct_2_th_113 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A17 sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> d c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using tarski_def_3 sorry
    qed
    have A19: " for r2 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r2 implies ( ex n be NatORDINAL1M6 st  for m be NatORDINAL1M6 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 r2)"
    proof(rule ballI,rule impI)
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A20: "0NUMBERSK6 <XXREAL-0R3 r2"
      obtain n where 
        [ty]:"n be NatORDINAL1M6" and nDef:"n = 0NUMBERSK6"
         sorry
      show " ex n be NatORDINAL1M6 st  for m be NatORDINAL1M6 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 r2"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatORDINAL1M6"
        assume "n <=XXREAL-0R1 m"
        have A21: "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d .FUNCT-1K1 m -XCMPLX-0K6 r .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 (d .FUNCT-1K1 m) -XCMPLX-0K6 r .|"
          using A18 funct_2_th_108 A21 sorry
        also have "... =  |.COMPLEX1K10 r -XCMPLX-0K6 r .|"
          using A17 A21 sorry
        also have "... = 0NUMBERSK6"
          using absvalue_th_2 sorry
        finally have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d .FUNCT-1K1 m -XCMPLX-0K6 r .| =HIDDENR1 0NUMBERSK6"
           sorry
        thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 r2"
          using A20 sorry
      qed "sorry"
    qed "sorry"
    let ?F = "\<lambda>Lamb1. x0 -XCMPLX-0K6 p /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)"
    obtain a where
      [ty]:"a be Real-SequenceSEQ-1M1" and 
      A22: " for n be NatORDINAL1M6 holds a .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    let ?F = "\<lambda>Lamb1. x0 +XCMPLX-0K2 p /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)"
    obtain b where
      [ty]:"b be Real-SequenceSEQ-1M1" and 
      A23: " for n be NatORDINAL1M6 holds b .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    have A24: " for n be NatORDINAL1M6 holds a .FUNCT-1K1 n <=XXREAL-0R1 d .FUNCT-1K1 n & d .FUNCT-1K1 n <=XXREAL-0R1 b .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatORDINAL1M6"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "x0 -XCMPLX-0K6 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 d .FUNCT-1K1 n & d .FUNCT-1K1 n <XXREAL-0R3 x0 +XCMPLX-0K2 p /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
        using A17 sorry
      thus "a .FUNCT-1K1 n <=XXREAL-0R1 d .FUNCT-1K1 n & d .FUNCT-1K1 n <=XXREAL-0R1 b .FUNCT-1K1 n"
        using A22 A23 sorry
    qed "sorry"
    have A25: "b be convergentSEQ-2V5 & limSEQ-2K1 b =COMPLEX1R1 x0"
      using A23 fcont_3_th_6 sorry
    have "a be convergentSEQ-2V5 & limSEQ-2K1 a =COMPLEX1R1 x0"
      using A22 fcont_3_th_5 sorry
    then have "d be convergentSEQ-2V5 & limSEQ-2K1 d =COMPLEX1R1 x0"
      using A25 A24 seq_2_th_19 seq_2_th_20 sorry
    then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
      using A1 A18 fcont_1_def_1 sorry
    thus " False "
      using A2 A19 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
          using A1 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
        proof(rule impI)
          assume A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
          have "( ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2) & r1 <>HIDDENR2 r2) implies  False "
          proof(rule impI)
            assume Given: " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2) & r1 <>HIDDENR2 r2"
            then obtain r1 r2 where
              [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" "r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A3: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"and A4: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"and A5: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"and A6: "r1 <>HIDDENR2 r2"
               sorry
            have A7: "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A3 A4 relat_1_th_61 sorry
            have " False "
            proof-
              show " False "
              proof-
                have cases: "r1 <XXREAL-0R3 r2 or r2 <XXREAL-0R3 r1"
                  using A6 xxreal_0_th_1 sorry
                have case1: "r1 <XXREAL-0R3 r2 implies  False "
                proof(rule impI)
                  assume "r1 <XXREAL-0R3 r2"
                  then have "f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
                    using A2 A7 rfunct_2_th_20 sorry
                  then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
                    using A3 funct_1_th_47 sorry
                  thus " False "
                    using A4 A5 funct_1_th_47 sorry
                qed
                have case2: "r2 <XXREAL-0R3 r1 implies  False "
                proof(rule impI)
                  assume "r2 <XXREAL-0R3 r1"
                  then have "f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
                    using A2 A7 rfunct_2_th_20 sorry
                  then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
                    using A4 funct_1_th_47 sorry
                  thus " False "
                    using A3 A5 funct_1_th_47 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " False "
               sorry
          qed
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
            using partfun1_th_8 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
        proof(rule impI)
          assume A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
          have "( ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2) & r1 <>HIDDENR2 r2) implies  False "
          proof(rule impI)
            assume Given: " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2) & r1 <>HIDDENR2 r2"
            then obtain r1 r2 where
              [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" "r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A9: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"and A10: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"and A11: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"and A12: "r1 <>HIDDENR2 r2"
               sorry
            have A13: "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A9 A10 relat_1_th_61 sorry
            have " False "
            proof-
              show " False "
              proof-
                have cases: "r1 <XXREAL-0R3 r2 or r2 <XXREAL-0R3 r1"
                  using A12 xxreal_0_th_1 sorry
                have case1: "r1 <XXREAL-0R3 r2 implies  False "
                proof(rule impI)
                  assume "r1 <XXREAL-0R3 r2"
                  then have "f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
                    using A8 A13 rfunct_2_th_21 sorry
                  then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
                    using A10 funct_1_th_47 sorry
                  thus " False "
                    using A9 A11 funct_1_th_47 sorry
                qed
                have case2: "r2 <XXREAL-0R3 r1 implies  False "
                proof(rule impI)
                  assume "r2 <XXREAL-0R3 r1"
                  then have "f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
                    using A8 A13 rfunct_2_th_21 sorry
                  then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
                    using A9 funct_1_th_47 sorry
                  thus " False "
                    using A10 A11 funct_1_th_47 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " False "
               sorry
          qed
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
            using partfun1_th_8 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be one-to-oneFUNCT-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_9:
" for X be setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be increasingRFUNCT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1 &  not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be increasingRFUNCT-2V1 implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
      and A2: " not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be increasingRFUNCT-2V1"
    obtain r1 r2 where
      [ty]:"r1 be RealXREAL-0M1" "r2 be RealXREAL-0M1" and 
      A3: "r1 inHIDDENR3 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A4: "r2 inHIDDENR3 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A5: "r1 <XXREAL-0R3 r2"and A6: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 >=XXREAL-0R2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
      using A2 rfunct_2_th_20 sorry
    have A7: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using relat_1_th_115 sorry
    then have A8: "r1 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using A3 xboole_0_def_4 sorry
    have A9: "r2 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using A4 A7 xboole_0_def_4 sorry
    have A10: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be increasingRFUNCT-2V1"
      using A1 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 <>HIDDENR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
           sorry
        have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 implies  False "
        proof(rule impI)
          assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
          then have "r1 =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2)"
            using A8 funct_1_th_35 sorry
          also have "... = r2"
            using A9 funct_1_th_35 sorry
          finally have "r1 =HIDDENR1 r2"
             sorry
          thus " False "
            using A5 sorry
        qed
        have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 <>HIDDENR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 implies  False "
        proof(rule impI)
          assume A11: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 <>HIDDENR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
          have A12: "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(X)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
             sorry
          also have "... = X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using relat_1_th_61 sorry
          finally have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
             sorry
          have "((r1 inHIDDENR3 REALNUMBERSK2 & r2 inHIDDENR3 REALNUMBERSK2) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 inTARSKIR2 REALNUMBERSK2) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have A13: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using A8 A9 partfun2_th_60 sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1"
            using A6 A11 xxreal_0_th_1 sorry
          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2) <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1)"
            using A10 A13 A12 rfunct_2_th_20 sorry
          then have "r2 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1)"
            using A9 funct_1_th_35 sorry
          thus " False "
            using A5 A8 funct_1_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_10:
" for X be setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be decreasingRFUNCT-2V2"
proof-
  have " for X be setHIDDENM2 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2 &  not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be decreasingRFUNCT-2V2 implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
      and A2: " not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be decreasingRFUNCT-2V2"
    obtain r1 r2 where
      [ty]:"r1 be RealXREAL-0M1" "r2 be RealXREAL-0M1" and 
      A3: "r1 inHIDDENR3 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A4: "r2 inHIDDENR3 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"and A5: "r1 <XXREAL-0R3 r2"and A6: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
      using A2 rfunct_2_th_21 sorry
    have A7: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using relat_1_th_115 sorry
    then have A8: "r1 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using A3 xboole_0_def_4 sorry
    have A9: "r2 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using A4 A7 xboole_0_def_4 sorry
    have A10: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be decreasingRFUNCT-2V2"
      using A1 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 <>HIDDENR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
           sorry
        have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 implies  False "
        proof(rule impI)
          assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
          then have "r1 =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2)"
            using A8 funct_1_th_35 sorry
          also have "... = r2"
            using A9 funct_1_th_35 sorry
          finally have "r1 =HIDDENR1 r2"
             sorry
          thus " False "
            using A5 sorry
        qed
        have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 <>HIDDENR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 implies  False "
        proof(rule impI)
          assume A11: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 <>HIDDENR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2"
          have A12: "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(X)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
             sorry
          also have "... = X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using relat_1_th_61 sorry
          finally have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
             sorry
          have "((r1 inHIDDENR3 REALNUMBERSK2 & r2 inHIDDENR3 REALNUMBERSK2) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 inTARSKIR2 REALNUMBERSK2) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have A13: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using A8 A9 partfun2_th_60 sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1"
            using A6 A11 xxreal_0_th_1 sorry
          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r2) <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1)"
            using A10 A13 A12 rfunct_2_th_21 sorry
          then have "r2 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 r1)"
            using A9 funct_1_th_35 sorry
          thus " False "
            using A5 A8 funct_1_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_11:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 implies (( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5"
    assume Given: " ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 p"
    then obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A3: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-open-halflineLIMFUNC1K1 p"
       sorry
    let ?L = "left-open-halflineLIMFUNC1K1 p"
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          using A2 rfunct_2_def_5 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
          then have A4: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A5: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using funct_1_def_6 sorry
            then have A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
              using A3 relat_1_th_129 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain N2 where
                [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A8: "N2 c=TARSKIR1 ?L"
                using A7 rcomp_1_th_18 sorry
              obtain N3 where
                [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A9: "N3 c=TARSKIR1 N1"and A10: "N3 c=TARSKIR1 N2"
                using rcomp_1_th_17 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A11: "r >XXREAL-0R4 0NUMBERSK6"and A12: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have A13: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have A15: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A11 xreal_1_th_29 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                using xreal_1_th_9 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A14 xxreal_0_th_2 sorry
              then have A16: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A13 sorry
              then have "?M2 inTARSKIR2 N2"
                using A10 A12 sorry
              then obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A17: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A18: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A5 A8 partfun2_th_59 sorry
              have A19: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have A20: "r2 <XXREAL-0R3 x0 implies  False "
              proof(rule impI)
                assume A21: "r2 <XXREAL-0R3 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A17 xboole_0_def_4 sorry
                thus " False "
                  using A4 A18 A19 A21 rfunct_2_th_22 sorry
              qed
              let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A22: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A14 xreal_1_th_19 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A15 xxreal_0_th_2 sorry
              then have A23: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A22 sorry
              then have "?M1 inTARSKIR2 N2"
                using A10 A12 sorry
              then obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A24: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A25: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A5 A8 partfun2_th_59 sorry
              have A26: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              then have A27: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A28: "x0 <XXREAL-0R3 r1 implies  False "
              proof(rule impI)
                assume A29: "x0 <XXREAL-0R3 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A24 xboole_0_def_4 sorry
                thus " False "
                  using A4 A25 A27 A29 rfunct_2_th_22 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A11 A18 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 <XXREAL-0R3 r2"
                using A20 xxreal_0_th_1 sorry
              then have A30: "r2 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(x0 -XCMPLX-0K6 r1,r2 -XCMPLX-0K6 x0)"
              have A31: "?R <=XXREAL-0R1 r2 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A25 A26 xreal_1_th_19 sorry
              then have "r1 <XXREAL-0R3 x0"
                using A28 xxreal_0_th_1 sorry
              then have "x0 -XCMPLX-0K6 r1 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A30 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A32: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A33: "x inHIDDENR3 N"
                have A34: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A32 xboole_1_th_28 sorry
                have A35: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A33 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A36: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r1"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r1"
                  using A36 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r1)"
                  using xreal_1_th_24 sorry
                then have A37: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A24 xboole_0_def_4 sorry
                then have A38: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A4 A37 A34 rfunct_2_th_22 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A35 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r2 -XCMPLX-0K6 x0"
                  using A31 xxreal_0_th_2 sorry
                then have A39: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A17 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A4 A39 A34 rfunct_2_th_22 sorry
                then have A40: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                  using A25 A18 A38 sorry
                have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A23 A16 xxreal_2_def_12 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                  using A12 A40 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A9 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          then have A41: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A42: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A43: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using funct_1_def_6 sorry
            then have A44: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
              using A3 relat_1_th_129 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain N2 where
                [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A45: "N2 c=TARSKIR1 ?L"
                using A44 rcomp_1_th_18 sorry
              obtain N3 where
                [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A46: "N3 c=TARSKIR1 N1"and A47: "N3 c=TARSKIR1 N2"
                using rcomp_1_th_17 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A48: "r >XXREAL-0R4 0NUMBERSK6"and A49: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have A50: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A51: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have A52: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A48 xreal_1_th_29 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                using xreal_1_th_9 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A51 xxreal_0_th_2 sorry
              then have A53: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A50 sorry
              then have "?M2 inTARSKIR2 N2"
                using A47 A49 sorry
              then obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A54: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A55: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A42 A45 partfun2_th_59 sorry
              have A56: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have A57: "r2 >XXREAL-0R4 x0 implies  False "
              proof(rule impI)
                assume A58: "r2 >XXREAL-0R4 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A43 A54 xboole_0_def_4 sorry
                thus " False "
                  using A41 A55 A56 A58 rfunct_2_th_23 sorry
              qed
              let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A59: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A51 xreal_1_th_19 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A52 xxreal_0_th_2 sorry
              then have A60: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A59 sorry
              then have "?M1 inTARSKIR2 N2"
                using A47 A49 sorry
              then obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A61: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A62: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A42 A45 partfun2_th_59 sorry
              have A63: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              then have A64: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A65: "x0 >XXREAL-0R4 r1 implies  False "
              proof(rule impI)
                assume A66: "x0 >XXREAL-0R4 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A43 A61 xboole_0_def_4 sorry
                thus " False "
                  using A41 A62 A64 A66 rfunct_2_th_23 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A48 A55 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 >XXREAL-0R4 r2"
                using A57 xxreal_0_th_1 sorry
              then have A67: "x0 -XCMPLX-0K6 r2 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(r1 -XCMPLX-0K6 x0,x0 -XCMPLX-0K6 r2)"
              have A68: "?R <=XXREAL-0R1 r1 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A62 A63 xreal_1_th_19 sorry
              then have "r1 >XXREAL-0R4 x0"
                using A65 xxreal_0_th_1 sorry
              then have "r1 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A67 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A69: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A70: "x inHIDDENR3 N"
                have A71: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A69 xboole_1_th_28 sorry
                have A72: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A70 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A73: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A72 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r1 -XCMPLX-0K6 x0"
                  using A68 xxreal_0_th_2 sorry
                then have A74: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A61 xboole_0_def_4 sorry
                then have A75: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A41 A74 A71 rfunct_2_th_23 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r2"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r2"
                  using A73 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r2)"
                  using xreal_1_th_24 sorry
                then have A76: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A54 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A41 A76 A71 rfunct_2_th_23 sorry
                then have A77: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                  using A62 A55 A75 sorry
                have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A60 A53 xxreal_2_def_12 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                  using A49 A77 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A46 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_12:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 implies (( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5"
    assume Given: " ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 p"
    then obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A3: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 p"
       sorry
    let ?L = "right-open-halflineLIMFUNC1K4 p"
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          using A2 rfunct_2_def_5 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
          then have A4: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A5: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using funct_1_def_6 sorry
            then have A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
              using A3 relat_1_th_129 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain N2 where
                [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A8: "N2 c=TARSKIR1 ?L"
                using A7 rcomp_1_th_18 sorry
              obtain N3 where
                [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A9: "N3 c=TARSKIR1 N1"and A10: "N3 c=TARSKIR1 N2"
                using rcomp_1_th_17 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A11: "r >XXREAL-0R4 0NUMBERSK6"and A12: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have A13: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have A15: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A11 xreal_1_th_29 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                using xreal_1_th_9 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A14 xxreal_0_th_2 sorry
              then have A16: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A13 sorry
              then have "?M2 inTARSKIR2 N2"
                using A10 A12 sorry
              then obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A17: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A18: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A5 A8 partfun2_th_59 sorry
              have A19: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have A20: "r2 <XXREAL-0R3 x0 implies  False "
              proof(rule impI)
                assume A21: "r2 <XXREAL-0R3 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A17 xboole_0_def_4 sorry
                thus " False "
                  using A4 A18 A19 A21 rfunct_2_th_22 sorry
              qed
              let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A22: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A14 xreal_1_th_19 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A15 xxreal_0_th_2 sorry
              then have A23: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A22 sorry
              then have "?M1 inTARSKIR2 N2"
                using A10 A12 sorry
              then obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A24: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A25: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A5 A8 partfun2_th_59 sorry
              have A26: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              then have A27: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A28: "x0 <XXREAL-0R3 r1 implies  False "
              proof(rule impI)
                assume A29: "x0 <XXREAL-0R3 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A24 xboole_0_def_4 sorry
                thus " False "
                  using A4 A25 A27 A29 rfunct_2_th_22 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A11 A18 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 <XXREAL-0R3 r2"
                using A20 xxreal_0_th_1 sorry
              then have A30: "r2 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(x0 -XCMPLX-0K6 r1,r2 -XCMPLX-0K6 x0)"
              have A31: "?R <=XXREAL-0R1 r2 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A25 A26 xreal_1_th_19 sorry
              then have "r1 <XXREAL-0R3 x0"
                using A28 xxreal_0_th_1 sorry
              then have "x0 -XCMPLX-0K6 r1 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A30 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A32: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A33: "x inHIDDENR3 N"
                have A34: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A32 xboole_1_th_28 sorry
                have A35: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A33 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A36: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r1"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r1"
                  using A36 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r1)"
                  using xreal_1_th_24 sorry
                then have A37: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A24 xboole_0_def_4 sorry
                then have A38: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A4 A37 A34 rfunct_2_th_22 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A35 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r2 -XCMPLX-0K6 x0"
                  using A31 xxreal_0_th_2 sorry
                then have A39: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A17 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A4 A39 A34 rfunct_2_th_22 sorry
                then have A40: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                  using A25 A18 A38 sorry
                have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A23 A16 xxreal_2_def_12 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                  using A12 A40 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A9 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          then have A41: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A42: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A43: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using funct_1_def_6 sorry
            then have A44: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
              using A3 relat_1_th_129 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain N2 where
                [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A45: "N2 c=TARSKIR1 ?L"
                using A44 rcomp_1_th_18 sorry
              obtain N3 where
                [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A46: "N3 c=TARSKIR1 N1"and A47: "N3 c=TARSKIR1 N2"
                using rcomp_1_th_17 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A48: "r >XXREAL-0R4 0NUMBERSK6"and A49: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have A50: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A51: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have A52: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A48 xreal_1_th_29 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                using xreal_1_th_9 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A51 xxreal_0_th_2 sorry
              then have A53: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A50 sorry
              then have "?M2 inTARSKIR2 N2"
                using A47 A49 sorry
              then obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A54: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A55: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A42 A45 partfun2_th_59 sorry
              have A56: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have A57: "r2 >XXREAL-0R4 x0 implies  False "
              proof(rule impI)
                assume A58: "r2 >XXREAL-0R4 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A43 A54 xboole_0_def_4 sorry
                thus " False "
                  using A41 A55 A56 A58 rfunct_2_th_23 sorry
              qed
              let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A59: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A51 xreal_1_th_19 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A52 xxreal_0_th_2 sorry
              then have A60: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A59 sorry
              then have "?M1 inTARSKIR2 N2"
                using A47 A49 sorry
              then obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A61: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A62: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A42 A45 partfun2_th_59 sorry
              have A63: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              then have A64: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A65: "x0 >XXREAL-0R4 r1 implies  False "
              proof(rule impI)
                assume A66: "x0 >XXREAL-0R4 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A43 A61 xboole_0_def_4 sorry
                thus " False "
                  using A41 A62 A64 A66 rfunct_2_th_23 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A48 A55 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 >XXREAL-0R4 r2"
                using A57 xxreal_0_th_1 sorry
              then have A67: "x0 -XCMPLX-0K6 r2 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(r1 -XCMPLX-0K6 x0,x0 -XCMPLX-0K6 r2)"
              have A68: "?R <=XXREAL-0R1 r1 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A62 A63 xreal_1_th_19 sorry
              then have "r1 >XXREAL-0R4 x0"
                using A65 xxreal_0_th_1 sorry
              then have "r1 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A67 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A69: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A70: "x inHIDDENR3 N"
                have A71: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A69 xboole_1_th_28 sorry
                have A72: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A70 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A73: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A72 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r1 -XCMPLX-0K6 x0"
                  using A68 xxreal_0_th_2 sorry
                then have A74: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A61 xboole_0_def_4 sorry
                then have A75: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A41 A74 A71 rfunct_2_th_23 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r2"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r2"
                  using A73 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r2)"
                  using xreal_1_th_24 sorry
                then have A76: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A54 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A41 A76 A71 rfunct_2_th_23 sorry
                then have A77: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                  using A62 A55 A75 sorry
                have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A60 A53 xxreal_2_def_12 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                  using A49 A77 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A46 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_13:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-closed-halflineLIMFUNC1K2 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 implies (( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-closed-halflineLIMFUNC1K2 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5"
    assume Given: " ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-closed-halflineLIMFUNC1K2 p"
    then obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A3: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 left-closed-halflineLIMFUNC1K2 p"
       sorry
    let ?L = "left-open-halflineLIMFUNC1K1 p"
    let ?l = "left-closed-halflineLIMFUNC1K2 p"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      have A4: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
        using relat_1_th_129 sorry
      have A5: "?L c=TARSKIR1 ?l"
        using xxreal_1_th_21 sorry
      assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      then have "x0 inHIDDENR3 X"
         sorry
      then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
        using A1 xboole_0_def_4 sorry
      then have A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        using relat_1_th_61 sorry
      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
        using funct_1_def_6 sorry
      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 p} \\/XBOOLE-0K2 ?L"
        using A3 A4 xxreal_1_th_423 sorry
      then have A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 p} or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
        using xboole_0_def_3 sorry
      have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
      proof(rule ballI)
        fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
        have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
        proof-
          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
          proof-
            have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
              using A2 rfunct_2_def_5 sorry
            have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1)"
            proof(rule impI)
              assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
              then have A8: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
                 sorry
              have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof-
                show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                proof-
                  have cases: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    using A7 tarski_def_1 sorry
                  have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 left-open-halflineLIMFUNC1K1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
                    then obtain N2 where
                      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A9: "N2 c=TARSKIR1 ?L"
                      using rcomp_1_th_18 sorry
                    obtain N3 where
                      [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A10: "N3 c=TARSKIR1 N1"and A11: "N3 c=TARSKIR1 N2"
                      using rcomp_1_th_17 sorry
                    obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A12: "r >XXREAL-0R4 0NUMBERSK6"and A13: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A15: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    have A16: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A12 xreal_1_th_29 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                      using xreal_1_th_9 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A15 xxreal_0_th_2 sorry
                    then have A17: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A14 sorry
                    then have "?M2 inTARSKIR2 N2"
                      using A11 A13 sorry
                    then have "?M2 inTARSKIR2 ?L"
                      using A9 sorry
                    then obtain r2 where
                      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A18: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A19: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A20: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    have A21: "r2 <XXREAL-0R3 x0 implies  False "
                    proof(rule impI)
                      assume A22: "r2 <XXREAL-0R3 x0"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A18 xboole_0_def_4 sorry
                      thus " False "
                        using A8 A19 A20 A22 rfunct_2_th_22 sorry
                    qed
                    let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A23: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A15 xreal_1_th_19 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A16 xxreal_0_th_2 sorry
                    then have A24: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A23 sorry
                    then have "?M1 inTARSKIR2 N2"
                      using A11 A13 sorry
                    then have "?M1 inTARSKIR2 ?L"
                      using A9 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A25: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A26: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A27: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    then have A28: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using xreal_1_th_19 sorry
                    have A29: "x0 <XXREAL-0R3 r1 implies  False "
                    proof(rule impI)
                      assume A30: "x0 <XXREAL-0R3 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A25 xboole_0_def_4 sorry
                      thus " False "
                        using A8 A26 A28 A30 rfunct_2_th_22 sorry
                    qed
                    have "x0 <>HIDDENR2 r2"
                      using A12 A19 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "x0 <XXREAL-0R3 r2"
                      using A21 xxreal_0_th_1 sorry
                    then have A31: "r2 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    let ?R = "minXXREAL-0K4(x0 -XCMPLX-0K6 r1,r2 -XCMPLX-0K6 x0)"
                    have A32: "?R <=XXREAL-0R1 r2 -XCMPLX-0K6 x0"
                      using xxreal_0_th_17 sorry
                    have "r1 <>HIDDENR2 x0"
                      using A26 A27 xreal_1_th_19 sorry
                    then have "r1 <XXREAL-0R3 x0"
                      using A29 xxreal_0_th_1 sorry
                    then have "x0 -XCMPLX-0K6 r1 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    then have "?R >XXREAL-0R4 0NUMBERSK6"
                      using A31 xxreal_0_th_15 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                      using rcomp_1_def_6 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A33: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A34: "x inHIDDENR3 N"
                      have A35: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A33 xboole_1_th_28 sorry
                      have A36: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                        using A34 sorry
                      then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                        using xreal_1_th_19 sorry
                      then have A37: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                        using xreal_1_th_9 sorry
                      have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r1"
                        using xxreal_0_th_17 sorry
                      then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r1"
                        using A37 xxreal_0_th_2 sorry
                      then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r1)"
                        using xreal_1_th_24 sorry
                      then have A38: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A25 xboole_0_def_4 sorry
                      then have A39: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A8 A38 A35 rfunct_2_th_22 sorry
                      have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                        using A36 xreal_1_th_19 sorry
                      then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r2 -XCMPLX-0K6 x0"
                        using A32 xxreal_0_th_2 sorry
                      then have A40: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A18 xboole_0_def_4 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                        using A8 A40 A35 rfunct_2_th_22 sorry
                      then have A41: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                        using A26 A19 A39 sorry
                      have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                        using A24 A17 xxreal_2_def_12 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                        using A13 A41 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A10 sorry
                    qed "sorry"
                  qed
                  have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume A42: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    then obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A43: "r >XXREAL-0R4 0NUMBERSK6"and A44: "N1 =XBOOLE-0R4 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    let ?R = "r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A45: "p <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                      using A43 xreal_1_th_29 xreal_1_th_215 sorry
                    have A46: "p -XCMPLX-0K6 ?R <XXREAL-0R3 p"
                      using A43 xreal_1_th_44 xreal_1_th_215 sorry
                    then have "p -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : s <XXREAL-0R3 p }"
                       sorry
                    then have "p -XCMPLX-0K6 ?R inTARSKIR2 ?L"
                      using xxreal_1_th_229 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A47: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A48: "p -XCMPLX-0K6 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A49: "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                      using A47 xboole_0_def_4 sorry
                    have A50: "x0 <XXREAL-0R3 r1 implies  False "
                    proof(rule impI)
                      assume A51: "x0 <XXREAL-0R3 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A47 xboole_0_def_4 sorry
                      thus " False "
                        using A8 A42 A46 A48 A51 rfunct_2_th_22 sorry
                    qed
                    have "r1 <>HIDDENR2 x0"
                      using A42 A43 A48 xreal_1_th_44 xreal_1_th_215 sorry
                    then have "r1 <XXREAL-0R3 x0"
                      using A50 xxreal_0_th_1 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 r1),x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 r1) .["
                      using rcomp_1_def_6 xreal_1_th_50 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A52: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A53: "x inHIDDENR3 N"
                      have A54: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 r1) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 r1)"
                        using A53 sorry
                      have A55: "?R <XXREAL-0R3 r"
                        using A43 xreal_1_th_216 sorry
                      then have A56: "p -XCMPLX-0K6 r <XXREAL-0R3 p -XCMPLX-0K6 ?R"
                        using xreal_1_th_15 sorry
                      have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 ?l"
                        using A3 A4 A52 funct_1_def_6 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : s <=XXREAL-0R1 p }"
                        using xxreal_1_th_231 sorry
                      then have " ex s be RealXREAL-0M1 st s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & s <=XXREAL-0R1 p"
                         sorry
                      then have A57: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 p +XCMPLX-0K2 ?R"
                        using A45 xxreal_0_th_2 sorry
                      have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A52 xboole_0_def_4 sorry
                      then have "p -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A8 A48 A49 A54 rfunct_2_th_22 sorry
                      then have A58: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .]"
                        using A57 sorry
                      have "p <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A43 xreal_1_th_29 sorry
                      then have "p -XCMPLX-0K6 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A46 xxreal_0_th_2 sorry
                      then have A59: "p -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A56 sorry
                      have A60: "p +XCMPLX-0K2 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A55 xreal_1_th_6 sorry
                      have "p -XCMPLX-0K6 r <XXREAL-0R3 p"
                        using A43 xreal_1_th_44 sorry
                      then have "p -XCMPLX-0K6 r <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                        using A45 xxreal_0_th_2 sorry
                      then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A60 sorry
                      then have "[.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                        using A44 A59 xxreal_2_def_12 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A58 sorry
                    qed "sorry"
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
                 sorry
            qed
            have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1)"
            proof(rule impI)
              assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
              then have A61: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
                 sorry
              have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof-
                show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                proof-
                  have cases: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    using A7 tarski_def_1 sorry
                  have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 left-open-halflineLIMFUNC1K1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
                    then obtain N2 where
                      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A62: "N2 c=TARSKIR1 ?L"
                      using rcomp_1_th_18 sorry
                    obtain N3 where
                      [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A63: "N3 c=TARSKIR1 N1"and A64: "N3 c=TARSKIR1 N2"
                      using rcomp_1_th_17 sorry
                    obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A65: "r >XXREAL-0R4 0NUMBERSK6"and A66: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    have A67: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A68: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    have A69: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A65 xreal_1_th_29 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                      using xreal_1_th_9 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A68 xxreal_0_th_2 sorry
                    then have A70: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A67 sorry
                    then have "?M2 inTARSKIR2 N2"
                      using A64 A66 sorry
                    then have "?M2 inTARSKIR2 ?L"
                      using A62 sorry
                    then obtain r2 where
                      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A71: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A72: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A73: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    have A74: "r2 >XXREAL-0R4 x0 implies  False "
                    proof(rule impI)
                      assume A75: "r2 >XXREAL-0R4 x0"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A71 xboole_0_def_4 sorry
                      thus " False "
                        using A61 A72 A73 A75 rfunct_2_th_23 sorry
                    qed
                    let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A76: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A68 xreal_1_th_19 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A69 xxreal_0_th_2 sorry
                    then have A77: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A76 sorry
                    then have "?M1 inTARSKIR2 N2"
                      using A64 A66 sorry
                    then have "?M1 inTARSKIR2 ?L"
                      using A62 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A78: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A79: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A80: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    then have A81: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using xreal_1_th_19 sorry
                    have A82: "x0 >XXREAL-0R4 r1 implies  False "
                    proof(rule impI)
                      assume A83: "x0 >XXREAL-0R4 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A78 xboole_0_def_4 sorry
                      thus " False "
                        using A61 A79 A81 A83 rfunct_2_th_23 sorry
                    qed
                    have "x0 <>HIDDENR2 r2"
                      using A65 A72 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "x0 >XXREAL-0R4 r2"
                      using A74 xxreal_0_th_1 sorry
                    then have A84: "x0 -XCMPLX-0K6 r2 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    let ?R = "minXXREAL-0K4(r1 -XCMPLX-0K6 x0,x0 -XCMPLX-0K6 r2)"
                    have A85: "?R <=XXREAL-0R1 r1 -XCMPLX-0K6 x0"
                      using xxreal_0_th_17 sorry
                    have "r1 <>HIDDENR2 x0"
                      using A79 A80 xreal_1_th_19 sorry
                    then have "r1 >XXREAL-0R4 x0"
                      using A82 xxreal_0_th_1 sorry
                    then have "r1 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    then have "?R >XXREAL-0R4 0NUMBERSK6"
                      using A84 xxreal_0_th_15 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                      using rcomp_1_def_6 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A86: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A87: "x inHIDDENR3 N"
                      have A88: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A86 xboole_1_th_28 sorry
                      have A89: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                        using A87 sorry
                      then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                        using xreal_1_th_19 sorry
                      then have A90: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                        using xreal_1_th_9 sorry
                      have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                        using A89 xreal_1_th_19 sorry
                      then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r1 -XCMPLX-0K6 x0"
                        using A85 xxreal_0_th_2 sorry
                      then have A91: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A78 xboole_0_def_4 sorry
                      then have A92: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A61 A91 A88 rfunct_2_th_23 sorry
                      have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r2"
                        using xxreal_0_th_17 sorry
                      then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r2"
                        using A90 xxreal_0_th_2 sorry
                      then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r2)"
                        using xreal_1_th_24 sorry
                      then have A93: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A71 xboole_0_def_4 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                        using A61 A93 A88 rfunct_2_th_23 sorry
                      then have A94: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                        using A79 A72 A92 sorry
                      have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                        using A77 A70 xxreal_2_def_12 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                        using A66 A94 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A63 sorry
                    qed "sorry"
                  qed
                  have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume A95: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    then obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A96: "r >XXREAL-0R4 0NUMBERSK6"and A97: "N1 =XBOOLE-0R4 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    let ?R = "r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A98: "p <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                      using A96 xreal_1_th_29 xreal_1_th_215 sorry
                    have A99: "p -XCMPLX-0K6 ?R <XXREAL-0R3 p"
                      using A96 xreal_1_th_44 xreal_1_th_215 sorry
                    then have "p -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : s <XXREAL-0R3 p }"
                       sorry
                    then have "p -XCMPLX-0K6 ?R inTARSKIR2 ?L"
                      using xxreal_1_th_229 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A100: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A101: "p -XCMPLX-0K6 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A102: "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                      using A100 xboole_0_def_4 sorry
                    have A103: "x0 >XXREAL-0R4 r1 implies  False "
                    proof(rule impI)
                      assume A104: "x0 >XXREAL-0R4 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A100 xboole_0_def_4 sorry
                      thus " False "
                        using A61 A95 A99 A101 A104 rfunct_2_th_23 sorry
                    qed
                    have "r1 <>HIDDENR2 x0"
                      using A95 A96 A101 xreal_1_th_44 xreal_1_th_215 sorry
                    then have "r1 >XXREAL-0R4 x0"
                      using A103 xxreal_0_th_1 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (r1 -XCMPLX-0K6 x0),x0 +XCMPLX-0K2 (r1 -XCMPLX-0K6 x0) .["
                      using rcomp_1_def_6 xreal_1_th_50 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A105: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A106: "x inHIDDENR3 N"
                      have A107: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (r1 -XCMPLX-0K6 x0) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (r1 -XCMPLX-0K6 x0)"
                        using A106 sorry
                      have A108: "?R <XXREAL-0R3 r"
                        using A96 xreal_1_th_216 sorry
                      then have A109: "p -XCMPLX-0K6 r <XXREAL-0R3 p -XCMPLX-0K6 ?R"
                        using xreal_1_th_15 sorry
                      have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 ?l"
                        using A3 A4 A105 funct_1_def_6 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : s <=XXREAL-0R1 p }"
                        using xxreal_1_th_231 sorry
                      then have " ex s be RealXREAL-0M1 st s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & s <=XXREAL-0R1 p"
                         sorry
                      then have A110: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 p +XCMPLX-0K2 ?R"
                        using A98 xxreal_0_th_2 sorry
                      have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A105 xboole_0_def_4 sorry
                      then have "p -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A61 A101 A102 A107 rfunct_2_th_23 sorry
                      then have A111: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .]"
                        using A110 sorry
                      have "p <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A96 xreal_1_th_29 sorry
                      then have "p -XCMPLX-0K6 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A99 xxreal_0_th_2 sorry
                      then have A112: "p -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A109 sorry
                      have A113: "p +XCMPLX-0K2 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A108 xreal_1_th_6 sorry
                      have "p -XCMPLX-0K6 r <XXREAL-0R3 p"
                        using A96 xreal_1_th_44 sorry
                      then have "p -XCMPLX-0K6 r <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                        using A98 xxreal_0_th_2 sorry
                      then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A113 sorry
                      then have "[.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                        using A97 A112 xxreal_2_def_12 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A111 sorry
                    qed "sorry"
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
           sorry
      qed "sorry"
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
        using fcont_1_th_4 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using fcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_14:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-closed-halflineLIMFUNC1K3 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 implies (( ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-closed-halflineLIMFUNC1K3 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5"
    assume Given: " ex p be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-closed-halflineLIMFUNC1K3 p"
    then obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A3: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 right-closed-halflineLIMFUNC1K3 p"
       sorry
    let ?L = "right-open-halflineLIMFUNC1K4 p"
    let ?l = "right-closed-halflineLIMFUNC1K3 p"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      have A4: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
        using relat_1_th_129 sorry
      have A5: "?L c=TARSKIR1 ?l"
        using xxreal_1_th_22 sorry
      assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      then have "x0 inHIDDENR3 X"
         sorry
      then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
        using A1 xboole_0_def_4 sorry
      then have A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        using relat_1_th_61 sorry
      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
        using funct_1_def_6 sorry
      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 p} \\/XBOOLE-0K2 ?L"
        using A3 A4 xxreal_1_th_427 sorry
      then have A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 p} or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
        using xboole_0_def_3 sorry
      have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
      proof(rule ballI)
        fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
        have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
        proof-
          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
          proof-
            have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
              using A2 rfunct_2_def_5 sorry
            have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1)"
            proof(rule impI)
              assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
              then have A8: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
                 sorry
              have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof-
                show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                proof-
                  have cases: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    using A7 tarski_def_1 sorry
                  have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 right-open-halflineLIMFUNC1K4 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
                    then obtain N2 where
                      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A9: "N2 c=TARSKIR1 ?L"
                      using rcomp_1_th_18 sorry
                    obtain N3 where
                      [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A10: "N3 c=TARSKIR1 N1"and A11: "N3 c=TARSKIR1 N2"
                      using rcomp_1_th_17 sorry
                    obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A12: "r >XXREAL-0R4 0NUMBERSK6"and A13: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A15: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    have A16: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A12 xreal_1_th_29 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                      using xreal_1_th_9 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A15 xxreal_0_th_2 sorry
                    then have A17: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A14 sorry
                    then have "?M2 inTARSKIR2 N2"
                      using A11 A13 sorry
                    then have "?M2 inTARSKIR2 ?L"
                      using A9 sorry
                    then obtain r2 where
                      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A18: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A19: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A20: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    have A21: "r2 <XXREAL-0R3 x0 implies  False "
                    proof(rule impI)
                      assume A22: "r2 <XXREAL-0R3 x0"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A18 xboole_0_def_4 sorry
                      thus " False "
                        using A8 A19 A20 A22 rfunct_2_th_22 sorry
                    qed
                    let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A23: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A15 xreal_1_th_19 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A16 xxreal_0_th_2 sorry
                    then have A24: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A23 sorry
                    then have "?M1 inTARSKIR2 N2"
                      using A11 A13 sorry
                    then have "?M1 inTARSKIR2 ?L"
                      using A9 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A25: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A26: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A27: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A12 xreal_1_th_29 xreal_1_th_215 sorry
                    then have A28: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using xreal_1_th_19 sorry
                    have A29: "x0 <XXREAL-0R3 r1 implies  False "
                    proof(rule impI)
                      assume A30: "x0 <XXREAL-0R3 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A25 xboole_0_def_4 sorry
                      thus " False "
                        using A8 A26 A28 A30 rfunct_2_th_22 sorry
                    qed
                    have "x0 <>HIDDENR2 r2"
                      using A12 A19 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "x0 <XXREAL-0R3 r2"
                      using A21 xxreal_0_th_1 sorry
                    then have A31: "r2 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    let ?R = "minXXREAL-0K4(x0 -XCMPLX-0K6 r1,r2 -XCMPLX-0K6 x0)"
                    have A32: "?R <=XXREAL-0R1 r2 -XCMPLX-0K6 x0"
                      using xxreal_0_th_17 sorry
                    have "r1 <>HIDDENR2 x0"
                      using A26 A27 xreal_1_th_19 sorry
                    then have "r1 <XXREAL-0R3 x0"
                      using A29 xxreal_0_th_1 sorry
                    then have "x0 -XCMPLX-0K6 r1 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    then have "?R >XXREAL-0R4 0NUMBERSK6"
                      using A31 xxreal_0_th_15 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                      using rcomp_1_def_6 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A33: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A34: "x inHIDDENR3 N"
                      have A35: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A33 xboole_1_th_28 sorry
                      have A36: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                        using A34 sorry
                      then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                        using xreal_1_th_19 sorry
                      then have A37: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                        using xreal_1_th_9 sorry
                      have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r1"
                        using xxreal_0_th_17 sorry
                      then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r1"
                        using A37 xxreal_0_th_2 sorry
                      then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r1)"
                        using xreal_1_th_24 sorry
                      then have A38: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A25 xboole_0_def_4 sorry
                      then have A39: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A8 A38 A35 rfunct_2_th_22 sorry
                      have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                        using A36 xreal_1_th_19 sorry
                      then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r2 -XCMPLX-0K6 x0"
                        using A32 xxreal_0_th_2 sorry
                      then have A40: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A18 xboole_0_def_4 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                        using A8 A40 A35 rfunct_2_th_22 sorry
                      then have A41: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                        using A26 A19 A39 sorry
                      have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                        using A24 A17 xxreal_2_def_12 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                        using A13 A41 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A10 sorry
                    qed "sorry"
                  qed
                  have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume A42: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    then obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A43: "r >XXREAL-0R4 0NUMBERSK6"and A44: "N1 =XBOOLE-0R4 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    let ?R = "r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A45: "p -XCMPLX-0K6 ?R <XXREAL-0R3 p"
                      using A43 xreal_1_th_44 xreal_1_th_215 sorry
                    have A46: "p <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                      using A43 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "p +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p <XXREAL-0R3 s }"
                       sorry
                    then have "p +XCMPLX-0K2 ?R inTARSKIR2 ?L"
                      using xxreal_1_th_230 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A47: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A48: "p +XCMPLX-0K2 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A49: "x0 >XXREAL-0R4 r1 implies  False "
                    proof(rule impI)
                      assume A50: "x0 >XXREAL-0R4 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A47 xboole_0_def_4 sorry
                      thus " False "
                        using A8 A42 A46 A48 A50 rfunct_2_th_22 sorry
                    qed
                    have "r1 <>HIDDENR2 x0"
                      using A42 A43 A48 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "r1 >XXREAL-0R4 x0"
                      using A49 xxreal_0_th_1 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (r1 -XCMPLX-0K6 x0),x0 +XCMPLX-0K2 (r1 -XCMPLX-0K6 x0) .["
                      using rcomp_1_def_6 xreal_1_th_50 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A51: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A52: "x inHIDDENR3 N"
                      have A53: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (r1 -XCMPLX-0K6 x0) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (r1 -XCMPLX-0K6 x0)"
                        using A52 sorry
                      have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 ?l"
                        using A3 A4 A51 funct_1_def_6 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p <=XXREAL-0R1 s }"
                        using xxreal_1_th_232 sorry
                      then have " ex s be RealXREAL-0M1 st s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & p <=XXREAL-0R1 s"
                         sorry
                      then have A54: "p -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A45 xxreal_0_th_2 sorry
                      have A55: "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A47 xboole_0_def_4 sorry
                      have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A51 xboole_0_def_4 sorry
                      then have "p +XCMPLX-0K2 ?R >=XXREAL-0R2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A8 A48 A55 A53 rfunct_2_th_22 sorry
                      then have A56: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .]"
                        using A54 sorry
                      have A57: "?R <XXREAL-0R3 r"
                        using A43 xreal_1_th_216 sorry
                      then have A58: "p -XCMPLX-0K6 r <XXREAL-0R3 p -XCMPLX-0K6 ?R"
                        using xreal_1_th_15 sorry
                      have "p <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A43 xreal_1_th_29 sorry
                      then have "p -XCMPLX-0K6 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A45 xxreal_0_th_2 sorry
                      then have A59: "p -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A58 sorry
                      have A60: "p +XCMPLX-0K2 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A57 xreal_1_th_6 sorry
                      have "p -XCMPLX-0K6 r <XXREAL-0R3 p"
                        using A43 xreal_1_th_44 sorry
                      then have "p -XCMPLX-0K6 r <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                        using A46 xxreal_0_th_2 sorry
                      then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A60 sorry
                      then have "[.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                        using A44 A59 xxreal_2_def_12 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A56 sorry
                    qed "sorry"
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
                 sorry
            qed
            have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1)"
            proof(rule impI)
              assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
              then have A61: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
                 sorry
              have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof-
                show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                proof-
                  have cases: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    using A7 tarski_def_1 sorry
                  have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 right-open-halflineLIMFUNC1K4 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
                    then obtain N2 where
                      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A62: "N2 c=TARSKIR1 ?L"
                      using rcomp_1_th_18 sorry
                    obtain N3 where
                      [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                      A63: "N3 c=TARSKIR1 N1"and A64: "N3 c=TARSKIR1 N2"
                      using rcomp_1_th_17 sorry
                    obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A65: "r >XXREAL-0R4 0NUMBERSK6"and A66: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    have A67: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A68: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    have A69: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A65 xreal_1_th_29 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                      using xreal_1_th_9 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A68 xxreal_0_th_2 sorry
                    then have A70: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A67 sorry
                    then have "?M2 inTARSKIR2 N2"
                      using A64 A66 sorry
                    then have "?M2 inTARSKIR2 ?L"
                      using A62 sorry
                    then obtain r2 where
                      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A71: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A72: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A73: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    have A74: "r2 >XXREAL-0R4 x0 implies  False "
                    proof(rule impI)
                      assume A75: "r2 >XXREAL-0R4 x0"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A71 xboole_0_def_4 sorry
                      thus " False "
                        using A61 A72 A73 A75 rfunct_2_th_23 sorry
                    qed
                    let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A76: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using A68 xreal_1_th_19 sorry
                    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                      using A69 xxreal_0_th_2 sorry
                    then have A77: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                      using A76 sorry
                    then have "?M1 inTARSKIR2 N2"
                      using A64 A66 sorry
                    then have "?M1 inTARSKIR2 ?L"
                      using A62 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A78: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A79: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A80: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                      using A65 xreal_1_th_29 xreal_1_th_215 sorry
                    then have A81: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                      using xreal_1_th_19 sorry
                    have A82: "x0 >XXREAL-0R4 r1 implies  False "
                    proof(rule impI)
                      assume A83: "x0 >XXREAL-0R4 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A78 xboole_0_def_4 sorry
                      thus " False "
                        using A61 A79 A81 A83 rfunct_2_th_23 sorry
                    qed
                    have "x0 <>HIDDENR2 r2"
                      using A65 A72 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "x0 >XXREAL-0R4 r2"
                      using A74 xxreal_0_th_1 sorry
                    then have A84: "x0 -XCMPLX-0K6 r2 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    let ?R = "minXXREAL-0K4(r1 -XCMPLX-0K6 x0,x0 -XCMPLX-0K6 r2)"
                    have A85: "?R <=XXREAL-0R1 r1 -XCMPLX-0K6 x0"
                      using xxreal_0_th_17 sorry
                    have "r1 <>HIDDENR2 x0"
                      using A79 A80 xreal_1_th_19 sorry
                    then have "r1 >XXREAL-0R4 x0"
                      using A82 xxreal_0_th_1 sorry
                    then have "r1 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                      using xreal_1_th_50 sorry
                    then have "?R >XXREAL-0R4 0NUMBERSK6"
                      using A84 xxreal_0_th_15 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                      using rcomp_1_def_6 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A86: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A87: "x inHIDDENR3 N"
                      have A88: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A86 xboole_1_th_28 sorry
                      have A89: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                        using A87 sorry
                      then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                        using xreal_1_th_19 sorry
                      then have A90: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                        using xreal_1_th_9 sorry
                      have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                        using A89 xreal_1_th_19 sorry
                      then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r1 -XCMPLX-0K6 x0"
                        using A85 xxreal_0_th_2 sorry
                      then have A91: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A78 xboole_0_def_4 sorry
                      then have A92: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A61 A91 A88 rfunct_2_th_23 sorry
                      have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r2"
                        using xxreal_0_th_17 sorry
                      then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r2"
                        using A90 xxreal_0_th_2 sorry
                      then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r2)"
                        using xreal_1_th_24 sorry
                      then have A93: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                        using xreal_1_th_6 sorry
                      have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A71 xboole_0_def_4 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                        using A61 A93 A88 rfunct_2_th_23 sorry
                      then have A94: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                        using A79 A72 A92 sorry
                      have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                        using A77 A70 xxreal_2_def_12 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                        using A66 A94 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A63 sorry
                    qed "sorry"
                  qed
                  have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                  proof(rule impI)
                    assume A95: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                    then obtain r where
                      [ty]:"r be RealXREAL-0M1" and 
                      A96: "r >XXREAL-0R4 0NUMBERSK6"and A97: "N1 =XBOOLE-0R4 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                      using rcomp_1_def_6 sorry
                    have 
                      [ty]:"r be RealXREAL-0M1"
                       sorry
                    let ?R = "r /XCMPLX-0K7 \<two>\<^sub>M"
                    have A98: "p -XCMPLX-0K6 ?R <XXREAL-0R3 p"
                      using A96 xreal_1_th_44 xreal_1_th_215 sorry
                    have A99: "p <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                      using A96 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "p +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p <XXREAL-0R3 s }"
                       sorry
                    then have "p +XCMPLX-0K2 ?R inTARSKIR2 ?L"
                      using xxreal_1_th_230 sorry
                    then obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                      A100: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A101: "p +XCMPLX-0K2 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                      using A3 A4 A5 partfun2_th_59 sorry
                    have A102: "x0 <XXREAL-0R3 r1 implies  False "
                    proof(rule impI)
                      assume A103: "x0 <XXREAL-0R3 r1"
                      have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A6 A100 xboole_0_def_4 sorry
                      thus " False "
                        using A61 A95 A99 A101 A103 rfunct_2_th_23 sorry
                    qed
                    have "r1 <>HIDDENR2 x0"
                      using A95 A96 A101 xreal_1_th_29 xreal_1_th_215 sorry
                    then have "r1 <XXREAL-0R3 x0"
                      using A102 xxreal_0_th_1 sorry
                    then obtain N where 
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 r1),x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 r1) .["
                      using rcomp_1_def_6 xreal_1_th_50 sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                      fix x assume [ty]: "x be RealXREAL-0M1"
                      assume A104: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        and A105: "x inHIDDENR3 N"
                      have A106: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 r1) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 r1)"
                        using A105 sorry
                      have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 ?l"
                        using A3 A4 A104 funct_1_def_6 sorry
                      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p <=XXREAL-0R1 s }"
                        using xxreal_1_th_232 sorry
                      then have " ex s be RealXREAL-0M1 st s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & p <=XXREAL-0R1 s"
                         sorry
                      then have A107: "p -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A98 xxreal_0_th_2 sorry
                      have A108: "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A100 xboole_0_def_4 sorry
                      have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                        using A104 xboole_0_def_4 sorry
                      then have "p +XCMPLX-0K2 ?R >=XXREAL-0R2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                        using A61 A101 A108 A106 rfunct_2_th_23 sorry
                      then have A109: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .]"
                        using A107 sorry
                      have A110: "?R <XXREAL-0R3 r"
                        using A96 xreal_1_th_216 sorry
                      then have A111: "p -XCMPLX-0K6 r <XXREAL-0R3 p -XCMPLX-0K6 ?R"
                        using xreal_1_th_15 sorry
                      have "p <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A96 xreal_1_th_29 sorry
                      then have "p -XCMPLX-0K6 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A98 xxreal_0_th_2 sorry
                      then have A112: "p -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A111 sorry
                      have A113: "p +XCMPLX-0K2 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                        using A110 xreal_1_th_6 sorry
                      have "p -XCMPLX-0K6 r <XXREAL-0R3 p"
                        using A96 xreal_1_th_44 sorry
                      then have "p -XCMPLX-0K6 r <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                        using A99 xxreal_0_th_2 sorry
                      then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                        using A113 sorry
                      then have "[.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                        using A97 A112 xxreal_2_def_12 sorry
                      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                        using A109 sorry
                    qed "sorry"
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 inTARSKIR2 N1"
           sorry
      qed "sorry"
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
        using fcont_1_th_4 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using fcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_15:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 ].RCOMP-1K2 p,g .[) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 implies (( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 ].RCOMP-1K2 p,g .[) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5"
    assume Given: " ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 ].RCOMP-1K2 p,g .["
    then obtain p g where
      [ty]:"p be RealXREAL-0M1" "g be RealXREAL-0M1" and 
      A3: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 ].RCOMP-1K2 p,g .["
       sorry
    let ?L = "].RCOMP-1K2 p,g .["
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          using A2 rfunct_2_def_5 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
          then have A4: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A5: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using funct_1_def_6 sorry
            then have A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
              using A3 relat_1_th_129 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain N2 where
                [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A8: "N2 c=TARSKIR1 ?L"
                using A7 rcomp_1_th_18 sorry
              obtain N3 where
                [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A9: "N3 c=TARSKIR1 N1"and A10: "N3 c=TARSKIR1 N2"
                using rcomp_1_th_17 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A11: "r >XXREAL-0R4 0NUMBERSK6"and A12: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have A13: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have A15: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A11 xreal_1_th_29 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                using xreal_1_th_9 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A14 xxreal_0_th_2 sorry
              then have A16: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A13 sorry
              then have "?M2 inTARSKIR2 N2"
                using A10 A12 sorry
              then obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A17: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A18: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A5 A8 partfun2_th_59 sorry
              have A19: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have A20: "r2 <XXREAL-0R3 x0 implies  False "
              proof(rule impI)
                assume A21: "r2 <XXREAL-0R3 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A17 xboole_0_def_4 sorry
                thus " False "
                  using A4 A18 A19 A21 rfunct_2_th_22 sorry
              qed
              let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A22: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A14 xreal_1_th_19 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A15 xxreal_0_th_2 sorry
              then have A23: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A22 sorry
              then have "?M1 inTARSKIR2 N2"
                using A10 A12 sorry
              then obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A24: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A25: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A5 A8 partfun2_th_59 sorry
              have A26: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A11 xreal_1_th_29 xreal_1_th_215 sorry
              then have A27: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A28: "x0 <XXREAL-0R3 r1 implies  False "
              proof(rule impI)
                assume A29: "x0 <XXREAL-0R3 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A24 xboole_0_def_4 sorry
                thus " False "
                  using A4 A25 A27 A29 rfunct_2_th_22 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A11 A18 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 <XXREAL-0R3 r2"
                using A20 xxreal_0_th_1 sorry
              then have A30: "r2 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(x0 -XCMPLX-0K6 r1,r2 -XCMPLX-0K6 x0)"
              have A31: "?R <=XXREAL-0R1 r2 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A25 A26 xreal_1_th_19 sorry
              then have "r1 <XXREAL-0R3 x0"
                using A28 xxreal_0_th_1 sorry
              then have "x0 -XCMPLX-0K6 r1 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A30 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A32: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A33: "x inHIDDENR3 N"
                have A34: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A32 xboole_1_th_28 sorry
                have A35: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A33 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A36: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r1"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r1"
                  using A36 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r1)"
                  using xreal_1_th_24 sorry
                then have A37: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A24 xboole_0_def_4 sorry
                then have A38: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A4 A37 A34 rfunct_2_th_22 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A35 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r2 -XCMPLX-0K6 x0"
                  using A31 xxreal_0_th_2 sorry
                then have A39: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A17 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A4 A39 A34 rfunct_2_th_22 sorry
                then have A40: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                  using A25 A18 A38 sorry
                have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A23 A16 xxreal_2_def_12 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                  using A12 A40 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A9 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          then have A41: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A42: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A43: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using funct_1_def_6 sorry
            then have A44: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ?L"
              using A3 relat_1_th_129 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain N2 where
                [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A45: "N2 c=TARSKIR1 ?L"
                using A44 rcomp_1_th_18 sorry
              obtain N3 where
                [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                A46: "N3 c=TARSKIR1 N1"and A47: "N3 c=TARSKIR1 N2"
                using rcomp_1_th_17 sorry
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A48: "r >XXREAL-0R4 0NUMBERSK6"and A49: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have A50: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A51: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have A52: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A48 xreal_1_th_29 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                using xreal_1_th_9 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A51 xxreal_0_th_2 sorry
              then have A53: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A50 sorry
              then have "?M2 inTARSKIR2 N2"
                using A47 A49 sorry
              then obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A54: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A55: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A42 A45 partfun2_th_59 sorry
              have A56: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have A57: "r2 >XXREAL-0R4 x0 implies  False "
              proof(rule impI)
                assume A58: "r2 >XXREAL-0R4 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A43 A54 xboole_0_def_4 sorry
                thus " False "
                  using A41 A55 A56 A58 rfunct_2_th_23 sorry
              qed
              let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
              have A59: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A51 xreal_1_th_19 sorry
              then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                using A52 xxreal_0_th_2 sorry
              then have A60: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using A59 sorry
              then have "?M1 inTARSKIR2 N2"
                using A47 A49 sorry
              then obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A61: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A62: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A42 A45 partfun2_th_59 sorry
              have A63: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A48 xreal_1_th_29 xreal_1_th_215 sorry
              then have A64: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A65: "x0 >XXREAL-0R4 r1 implies  False "
              proof(rule impI)
                assume A66: "x0 >XXREAL-0R4 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A43 A61 xboole_0_def_4 sorry
                thus " False "
                  using A41 A62 A64 A66 rfunct_2_th_23 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A48 A55 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 >XXREAL-0R4 r2"
                using A57 xxreal_0_th_1 sorry
              then have A67: "x0 -XCMPLX-0K6 r2 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(r1 -XCMPLX-0K6 x0,x0 -XCMPLX-0K6 r2)"
              have A68: "?R <=XXREAL-0R1 r1 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A62 A63 xreal_1_th_19 sorry
              then have "r1 >XXREAL-0R4 x0"
                using A65 xxreal_0_th_1 sorry
              then have "r1 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A67 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A69: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A70: "x inHIDDENR3 N"
                have A71: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A69 xboole_1_th_28 sorry
                have A72: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A70 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A73: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A72 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r1 -XCMPLX-0K6 x0"
                  using A68 xxreal_0_th_2 sorry
                then have A74: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A61 xboole_0_def_4 sorry
                then have A75: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A41 A74 A71 rfunct_2_th_23 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r2"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r2"
                  using A73 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r2)"
                  using xreal_1_th_24 sorry
                then have A76: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A54 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A41 A76 A71 rfunct_2_th_23 sorry
                then have A77: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                  using A62 A55 A75 sorry
                have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A60 A53 xxreal_2_def_12 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                  using A49 A77 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A46 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_16:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5) & f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 REALNUMBERSK2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 & f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 REALNUMBERSK2) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5"
      and A3: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 REALNUMBERSK2"
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          using A2 rfunct_2_def_5 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
          then have A4: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A5: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A7: "r >XXREAL-0R4 0NUMBERSK6"and A8: "N1 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be RealXREAL-0M1"
                 sorry
              have A9: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A7 xreal_1_th_29 xreal_1_th_215 sorry
              obtain M1 where 
                [ty]:"M1 be ElementSUBSET-1M1-of REALNUMBERSK2" and M1Def:"M1 = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                using xreal_0_def_1 sorry
              obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A10: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A11: "M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A5 partfun2_th_59 sorry
              have A12: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A7 xreal_1_th_29 xreal_1_th_215 sorry
              then have A13: "M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A14: "x0 <XXREAL-0R3 r1 implies  False "
              proof(rule impI)
                assume A15: "x0 <XXREAL-0R3 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A10 xboole_0_def_4 sorry
                thus " False "
                  using A4 A11 A13 A15 rfunct_2_th_22 sorry
              qed
              obtain M2 where 
                [ty]:"M2 be ElementSUBSET-1M1-of REALNUMBERSK2" and M2Def:"M2 = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using xreal_0_def_1 sorry
              obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A16: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A17: "M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A5 partfun2_th_59 sorry
              have A18: "M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A7 xreal_1_th_29 xreal_1_th_215 sorry
              have A19: "r2 <XXREAL-0R3 x0 implies  False "
              proof(rule impI)
                assume A20: "r2 <XXREAL-0R3 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A6 A16 xboole_0_def_4 sorry
                thus " False "
                  using A4 A17 A18 A20 rfunct_2_th_22 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A7 A17 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 <XXREAL-0R3 r2"
                using A19 xxreal_0_th_1 sorry
              then have A21: "r2 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(x0 -XCMPLX-0K6 r1,r2 -XCMPLX-0K6 x0)"
              have A22: "?R <=XXREAL-0R1 r2 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A11 A12 xreal_1_th_19 sorry
              then have "r1 <XXREAL-0R3 x0"
                using A14 xxreal_0_th_1 sorry
              then have "x0 -XCMPLX-0K6 r1 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A21 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A23: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A24: "x inHIDDENR3 N"
                have A25: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A23 xboole_1_th_28 sorry
                have A26: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                  using A7 xreal_1_th_29 xreal_1_th_215 sorry
                have A27: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                  using A7 xreal_1_th_29 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                  using xreal_1_th_9 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                  using A9 xxreal_0_th_2 sorry
                then have A28: "M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A26 sorry
                have A29: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                  using A7 xreal_1_th_29 xreal_1_th_215 sorry
                have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                  using A9 xreal_1_th_19 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                  using A27 xxreal_0_th_2 sorry
                then have "M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A29 sorry
                then have A30: "[.RCOMP-1K1 M1,M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A28 xxreal_2_def_12 sorry
                have A31: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A24 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A32: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r1"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r1"
                  using A32 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r1)"
                  using xreal_1_th_24 sorry
                then have A33: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A10 xboole_0_def_4 sorry
                then have A34: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A4 A33 A25 rfunct_2_th_22 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A31 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r2 -XCMPLX-0K6 x0"
                  using A22 xxreal_0_th_2 sorry
                then have A35: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A16 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A4 A35 A25 rfunct_2_th_22 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 M1,M2 .]"
                  using A11 A17 A34 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A8 A30 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
          then have A36: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
             sorry
          have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          proof(rule ballI,rule impI)
            fix x0 assume [ty]: "x0 be RealXREAL-0M1"
            have A37: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_129 sorry
            assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "x0 inHIDDENR3 X"
               sorry
            then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A1 xboole_0_def_4 sorry
            then have A38: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
            proof(rule ballI)
              fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
              obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A39: "r >XXREAL-0R4 0NUMBERSK6"and A40: "N1 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                using rcomp_1_def_6 sorry
              have 
                [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
                using xreal_0_def_1 sorry
              have A41: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A39 xreal_1_th_29 xreal_1_th_215 sorry
              obtain M1 where 
                [ty]:"M1 be ElementSUBSET-1M1-of REALNUMBERSK2" and M1Def:"M1 = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                using xreal_0_def_1 sorry
              obtain r1 where
                [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A42: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X"and A43: "M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1"
                using A3 A37 partfun2_th_59 sorry
              have A44: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using A39 xreal_1_th_29 xreal_1_th_215 sorry
              then have A45: "M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using xreal_1_th_19 sorry
              have A46: "x0 >XXREAL-0R4 r1 implies  False "
              proof(rule impI)
                assume A47: "x0 >XXREAL-0R4 r1"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A38 A42 xboole_0_def_4 sorry
                thus " False "
                  using A36 A43 A45 A47 rfunct_2_th_23 sorry
              qed
              obtain M2 where 
                [ty]:"M2 be ElementSUBSET-1M1-of REALNUMBERSK2" and M2Def:"M2 = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                using xreal_0_def_1 sorry
              obtain r2 where
                [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                A48: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X"and A49: "M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                using A3 A37 partfun2_th_59 sorry
              have A50: "M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                using A39 xreal_1_th_29 xreal_1_th_215 sorry
              have A51: "r2 >XXREAL-0R4 x0 implies  False "
              proof(rule impI)
                assume A52: "r2 >XXREAL-0R4 x0"
                have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A38 A48 xboole_0_def_4 sorry
                thus " False "
                  using A36 A49 A50 A52 rfunct_2_th_23 sorry
              qed
              have "x0 <>HIDDENR2 r2"
                using A39 A49 xreal_1_th_29 xreal_1_th_215 sorry
              then have "x0 >XXREAL-0R4 r2"
                using A51 xxreal_0_th_1 sorry
              then have A53: "x0 -XCMPLX-0K6 r2 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              let ?R = "minXXREAL-0K4(r1 -XCMPLX-0K6 x0,x0 -XCMPLX-0K6 r2)"
              have A54: "?R <=XXREAL-0R1 r1 -XCMPLX-0K6 x0"
                using xxreal_0_th_17 sorry
              have "r1 <>HIDDENR2 x0"
                using A43 A44 xreal_1_th_19 sorry
              then have "r1 >XXREAL-0R4 x0"
                using A46 xxreal_0_th_1 sorry
              then have "r1 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then have "?R >XXREAL-0R4 0NUMBERSK6"
                using A53 xxreal_0_th_15 sorry
              then obtain N where 
                [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                using rcomp_1_def_6 sorry
              show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
              proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be RealXREAL-0M1"
                assume A55: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and A56: "x inHIDDENR3 N"
                have A57: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A55 xboole_1_th_28 sorry
                have A58: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                  using A39 xreal_1_th_29 xreal_1_th_215 sorry
                have A59: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                  using A39 xreal_1_th_29 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                  using xreal_1_th_9 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                  using A41 xxreal_0_th_2 sorry
                then have A60: "M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A58 sorry
                have A61: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                  using A39 xreal_1_th_29 xreal_1_th_215 sorry
                have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                  using A41 xreal_1_th_19 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                  using A59 xxreal_0_th_2 sorry
                then have "M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A61 sorry
                then have A62: "[.RCOMP-1K1 M1,M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                  using A60 xxreal_2_def_12 sorry
                have A63: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                  using A56 sorry
                then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                  using xreal_1_th_19 sorry
                then have A64: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                  using xreal_1_th_9 sorry
                have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                  using A63 xreal_1_th_19 sorry
                then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 r1 -XCMPLX-0K6 x0"
                  using A54 xxreal_0_th_2 sorry
                then have A65: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (r1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A42 xboole_0_def_4 sorry
                then have A66: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                  using A36 A65 A57 rfunct_2_th_23 sorry
                have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 r2"
                  using xxreal_0_th_17 sorry
                then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 r2"
                  using A64 xxreal_0_th_2 sorry
                then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 r2)"
                  using xreal_1_th_24 sorry
                then have A67: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (r2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                  using xreal_1_th_6 sorry
                have "r2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  using A48 xboole_0_def_4 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r2"
                  using A36 A67 A57 rfunct_2_th_23 sorry
                then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 M1,M2 .]"
                  using A43 A49 A66 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                  using A40 A62 sorry
              qed "sorry"
            qed "sorry"
            thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
              using fcont_1_th_4 sorry
          qed "sorry"
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            using fcont_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_17:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2) & ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2) & ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2"
      and A2: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
    proof-
      show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2"
          using A1 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1"
          have A4: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A5: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ].RCOMP-1K2 p,g .["and A6: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
              using A5 xboole_0_def_4 sorry
            then have A7: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)).FUNCT-1K1 s"
              using A6 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
              using A7 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A8: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
            using relat_1_th_61 sorry
          also have "... = ].RCOMP-1K2 p,g .["
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) =HIDDENR1 ].RCOMP-1K2 p,g .["
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be increasingRFUNCT-2V1"
            using A3 fcont_3_th_9 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
            using A4 A8 fcont_3_th_15 subset_1_th_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A9: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2"
          have A10: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A11: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ].RCOMP-1K2 p,g .["and A12: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
              using A11 xboole_0_def_4 sorry
            then have A13: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)).FUNCT-1K1 s"
              using A12 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
              using A13 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
            using relat_1_th_61 sorry
          also have "... = ].RCOMP-1K2 p,g .["
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) =HIDDENR1 ].RCOMP-1K2 p,g .["
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be decreasingRFUNCT-2V2"
            using A9 fcont_3_th_10 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
            using A10 A14 fcont_3_th_15 subset_1_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_18:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2) & left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
proof-
  have " for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2) & left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "left-open-halflineLIMFUNC1K1 p"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
      and A2: "?L c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
    proof-
      show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          using A1 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
          have A4: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A5: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A6: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A5 xboole_0_def_4 sorry
            then have A7: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A6 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A7 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A8: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be increasingRFUNCT-2V1"
            using A3 fcont_3_th_9 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
            using A4 A8 fcont_3_th_11 subset_1_th_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A9: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          have A10: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A11: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A12: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A11 xboole_0_def_4 sorry
            then have A13: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A12 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A13 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be decreasingRFUNCT-2V2"
            using A9 fcont_3_th_10 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
            using A10 A14 fcont_3_th_11 subset_1_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_19:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2) & right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
proof-
  have " for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2) & right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "right-open-halflineLIMFUNC1K4 p"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
      and A2: "?L c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
    proof-
      show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          using A1 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
          have A4: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A5: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A6: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A5 xboole_0_def_4 sorry
            then have A7: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A6 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A7 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A8: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be increasingRFUNCT-2V1"
            using A3 fcont_3_th_9 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
            using A4 A8 fcont_3_th_12 subset_1_th_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A9: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          have A10: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A11: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A12: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A11 xboole_0_def_4 sorry
            then have A13: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A12 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A13 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be decreasingRFUNCT-2V2"
            using A9 fcont_3_th_10 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
            using A10 A14 fcont_3_th_12 subset_1_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_20:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be decreasingRFUNCT-2V2) & left-closed-halflineLIMFUNC1K2 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
proof-
  have " for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be decreasingRFUNCT-2V2) & left-closed-halflineLIMFUNC1K2 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "left-closed-halflineLIMFUNC1K2 p"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
      and A2: "?L c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
    proof-
      show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          using A1 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
          have A4: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A5: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A6: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A5 xboole_0_def_4 sorry
            then have A7: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A6 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A7 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A8: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be increasingRFUNCT-2V1"
            using A3 fcont_3_th_9 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
            using A4 A8 fcont_3_th_13 subset_1_th_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A9: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          have A10: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A11: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A12: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A11 xboole_0_def_4 sorry
            then have A13: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A12 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A13 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be decreasingRFUNCT-2V2"
            using A9 fcont_3_th_10 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
            using A10 A14 fcont_3_th_13 subset_1_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 p)) be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_21:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be decreasingRFUNCT-2V2) & right-closed-halflineLIMFUNC1K3 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
proof-
  have " for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be decreasingRFUNCT-2V2) & right-closed-halflineLIMFUNC1K3 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "right-closed-halflineLIMFUNC1K3 p"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
      and A2: "?L c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
    proof-
      show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          using A1 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
          have A4: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A5: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A6: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A5 xboole_0_def_4 sorry
            then have A7: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A6 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A7 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A8: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be increasingRFUNCT-2V1"
            using A3 fcont_3_th_9 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
            using A4 A8 fcont_3_th_14 subset_1_th_2 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
        proof(rule impI)
          assume A9: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
          have A10: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p) implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
            then obtain s where
              [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A11: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s inTARSKIR2 ?L"and A12: "r =COMPLEX1R1 f .FUNCT-1K1 s"
              using partfun2_th_59 sorry
            have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
              using A11 xboole_0_def_4 sorry
            then have A13: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using relat_1_th_61 sorry
            then have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
              using A12 funct_1_th_47 sorry
            then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
              using A13 funct_1_def_3 sorry
            thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using funct_1_th_33 sorry
          qed "sorry"
          have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using relat_1_th_61 sorry
          also have "... = ?L"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 ?L"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be decreasingRFUNCT-2V2"
            using A9 fcont_3_th_10 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
            using A10 A14 fcont_3_th_14 subset_1_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 p)) be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_22:
" for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2) & f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
proof(rule ballI,rule impMI ,rule impI)
  let ?L = "[#]SUBSET-1K2 REALNUMBERSK2"
  fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2"
    and A2: "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
  have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
    using A2 partfun1_def_2 sorry
  have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
  proof-
    show "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
    proof-
      have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
        using A1 sorry
      have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
      proof(rule impI)
        assume A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
        have A5: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
          assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
          then obtain s where
            [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A6: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and "s inTARSKIR2 ?L"and A7: "r =COMPLEX1R1 f .FUNCT-1K1 s"
            using partfun2_th_59 sorry
          have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using A6 xboole_0_def_4 sorry
          then have A8: "s inTARSKIR2 domRELSET-1K1\<^bsub>([#]SUBSET-1K2 REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_61 sorry
          have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
            using A7 sorry
          then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using A8 funct_1_def_3 sorry
          thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
        qed "sorry"
        have A9: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
          using relat_1_th_115 sorry
        also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using funct_1_th_33 sorry
        also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using relat_1_th_113 sorry
        also have "... = domRELSET-1K1\<^bsub>([#]SUBSET-1K2 REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
          using funct_1_th_33 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
          using relat_1_th_61 sorry
        also have "... = REALNUMBERSK2"
          using A3 sorry
        finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 REALNUMBERSK2"
           sorry
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be increasingRFUNCT-2V1"
          using A4 fcont_3_th_9 sorry
        then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be continuousFCONT-1V1"
          using A5 A9 fcont_3_th_16 subset_1_th_2 sorry
        then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
          using A3 relat_1_th_113 sorry
        thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
           sorry
      qed
      have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2 implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
      proof(rule impI)
        assume A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
        have A11: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 implies r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
          assume "r inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
          then obtain s where
            [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A12: "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and "s inTARSKIR2 ?L"and A13: "r =COMPLEX1R1 f .FUNCT-1K1 s"
            using partfun2_th_59 sorry
          have "s inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
            using A12 xboole_0_def_4 sorry
          then have A14: "s inTARSKIR2 domRELSET-1K1\<^bsub>([#]SUBSET-1K2 REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using relat_1_th_61 sorry
          have "r =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L).FUNCT-1K1 s"
            using A13 sorry
          then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
            using A14 funct_1_def_3 sorry
          thus "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
        qed "sorry"
        have A15: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
          using relat_1_th_115 sorry
        also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using funct_1_th_33 sorry
        also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using relat_1_th_113 sorry
        also have "... = domRELSET-1K1\<^bsub>([#]SUBSET-1K2 REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)"
          using funct_1_th_33 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
          using relat_1_th_61 sorry
        also have "... = REALNUMBERSK2"
          using A3 sorry
        finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) =HIDDENR1 REALNUMBERSK2"
           sorry
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be decreasingRFUNCT-2V2"
          using A10 fcont_3_th_10 sorry
        then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L) be continuousFCONT-1V1"
          using A11 A15 fcont_3_th_16 subset_1_th_2 sorry
        then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
          using A3 relat_1_th_113 sorry
        thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
     sorry
qed "sorry"

mtheorem fcont_3_th_23:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2"
    have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) implies ( ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)))"
    proof(rule ballI,rule impI)
      fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      let ?f1 = "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
      assume "r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      then obtain x0 where
        [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A4: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A5: "?f1 .FUNCT-1K1 x0 =COMPLEX1R1 r1"
        using partfun1_th_3 sorry
      have A6: "r1 =COMPLEX1R1 f .FUNCT-1K1 x0"
        using A4 A5 funct_1_th_47 sorry
      have A7: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
        using A4 relat_1_th_61 sorry
      then have "x0 inTARSKIR2 ].RCOMP-1K2 p,g .["
        using xboole_0_def_4 sorry
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A8: "N c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using rcomp_1_th_18 sorry
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A9: "0NUMBERSK6 <XXREAL-0R3 r"and A10: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
        using rcomp_1_def_6 sorry
      have 
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A9 xreal_1_th_215 sorry
      then have A11: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 sorry
      have A12: "r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r"
        using A9 xreal_1_th_216 sorry
      then have A13: "x0 -REAL-1K5 r <XXREAL-0R3 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_15 sorry
      have A14: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 A8 sorry
      let ?fp = "f .FUNCT-1K1 (x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
      let ?fm = "f .FUNCT-1K1 (x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M)"
      have A15: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A12 xreal_1_th_8 sorry
      have A16: "x0 <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A9 xreal_1_th_29 xreal_1_th_215 sorry
      then have A17: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A11 xxreal_0_th_2 sorry
      have "x0 <XXREAL-0R3 x0 +REAL-1K3 r"
        using A9 xreal_1_th_29 sorry
      then have "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A11 xxreal_0_th_2 sorry
      then have A18: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A13 sorry
      then have A19: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A10 A14 xboole_0_def_4 sorry
      have "x0 -REAL-1K5 r <XXREAL-0R3 x0"
        using A9 xreal_1_th_44 sorry
      then have "x0 -REAL-1K5 r <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A16 xxreal_0_th_2 sorry
      then have A20: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A15 sorry
      then have A21: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 (].RCOMP-1K2 p,g .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A10 A14 xboole_0_def_4 sorry
      have A22: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A18 A20 xxreal_2_def_12 sorry
      have A23: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 ].RCOMP-1K2 p,g .["
        using A8 A10 A18 A20 xxreal_2_def_12 sorry
      then have A24: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]) be continuousFCONT-1V1"
        using A2 fcont_1_th_16 sorry
      have " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
      proof-
        show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
        proof-
          have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2"
            using A3 sorry
          have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)))"
          proof(rule impI)
            assume A25: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingRFUNCT-2V1"
            let ?R = "minXXREAL-0K4(f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm,?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fp"
              using A7 A16 A21 A25 rfunct_2_th_20 sorry
            then have A26: "0NUMBERSK6 <XXREAL-0R3 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            have "?fm <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A7 A11 A19 A25 rfunct_2_th_20 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A26 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
            proof(rule bexI[of _ "N1"])
              have "?fm <XXREAL-0R3 ?fp"
                using A17 A21 A19 A25 rfunct_2_th_20 sorry
              then have "[.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A27: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fm,?fp .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A28: "].RCOMP-1K2 ?fm,?fp .[ c=TARSKIR1 [.RCOMP-1K1 ?fm,?fp .]"
                    using xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A29: "r2 =HIDDENR1 x"and A30: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A31: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A6 sorry
                  have "?R <=XXREAL-0R1 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A32: "r2 <XXREAL-0R3 ?fp"
                    using A31 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fm <XXREAL-0R3 r2"
                    using A30 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fm,?fp .["
                    using A32 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A33: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A34: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A1 A23 A24 A17 A27 A29 A28 fcont_2_th_15 xboole_1_th_1 sorry
                  have "s inHIDDENR3 N"
                    using A10 A22 A33 sorry
                  then have "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
                    using A8 A14 xboole_0_def_4 sorry
                  then have A35: "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                    using relat_1_th_61 sorry
                  then have "x =HIDDENR1 ?f1 .FUNCT-1K1 s"
                    using A34 funct_1_th_47 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
                    using A35 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)))"
          proof(rule impI)
            assume A36: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingRFUNCT-2V2"
            let ?R = "minXXREAL-0K4(?fm -XCMPLX-0K6 f .FUNCT-1K1 x0,f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp)"
            have "?fp <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A7 A16 A21 A36 rfunct_2_th_21 sorry
            then have A37: "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
              using xreal_1_th_50 sorry
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fm"
              using A7 A11 A19 A36 rfunct_2_th_21 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A37 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
            proof(rule bexI[of _ "N1"])
              have "?fp <XXREAL-0R3 ?fm"
                using A17 A21 A19 A36 rfunct_2_th_21 sorry
              then have "[.RCOMP-1K1 ?fm,?fp .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A38: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fp,?fm .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A39: "].RCOMP-1K2 ?fp,?fm .[ c=TARSKIR1 [.RCOMP-1K1 ?fp,?fm .]"
                    using xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A40: "r2 =HIDDENR1 x"and A41: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A42: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A6 sorry
                  have "?R <=XXREAL-0R1 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fm -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A43: "r2 <XXREAL-0R3 ?fm"
                    using A42 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fp <XXREAL-0R3 r2"
                    using A41 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fp,?fm .["
                    using A43 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A44: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A45: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A1 A23 A24 A17 A38 A40 A39 fcont_2_th_15 xboole_1_th_1 sorry
                  have "s inHIDDENR3 N"
                    using A10 A22 A44 sorry
                  then have "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)"
                    using A8 A14 xboole_0_def_4 sorry
                  then have A46: "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                    using relat_1_th_61 sorry
                  then have "x =HIDDENR1 ?f1 .FUNCT-1K1 s"
                    using A45 funct_1_th_47 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
                    using A46 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
         sorry
    qed "sorry"
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
      using rcomp_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_24:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be continuousFCONT-1V1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "left-open-halflineLIMFUNC1K1 p"
    assume A1: "left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be continuousFCONT-1V1"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
    have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) implies ( ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)))"
    proof(rule ballI,rule impI)
      fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      let ?f1 = "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
      assume "r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      then obtain x0 where
        [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A4: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A5: "?f1 .FUNCT-1K1 x0 =COMPLEX1R1 r1"
        using partfun1_th_3 sorry
      have A6: "r1 =COMPLEX1R1 f .FUNCT-1K1 x0"
        using A4 A5 funct_1_th_47 sorry
      have A7: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
        using A4 relat_1_th_61 sorry
      then have "x0 inTARSKIR2 ?L"
        using xboole_0_def_4 sorry
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A8: "N c=TARSKIR1 ?L"
        using rcomp_1_th_18 sorry
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A9: "0NUMBERSK6 <XXREAL-0R3 r"and A10: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
        using rcomp_1_def_6 sorry
      have 
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A9 xreal_1_th_215 sorry
      then have A11: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 sorry
      have A12: "r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r"
        using A9 xreal_1_th_216 sorry
      then have A13: "x0 -REAL-1K5 r <XXREAL-0R3 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_15 sorry
      have A14: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 A8 sorry
      let ?fp = "f .FUNCT-1K1 (x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
      let ?fm = "f .FUNCT-1K1 (x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M)"
      have A15: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A12 xreal_1_th_8 sorry
      have A16: "x0 <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A9 xreal_1_th_29 xreal_1_th_215 sorry
      then have A17: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A11 xxreal_0_th_2 sorry
      have "x0 <XXREAL-0R3 x0 +REAL-1K3 r"
        using A9 xreal_1_th_29 sorry
      then have "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A11 xxreal_0_th_2 sorry
      then have A18: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A13 sorry
      then have A19: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ?L /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A10 A14 xboole_0_def_4 sorry
      have "x0 -REAL-1K5 r <XXREAL-0R3 x0"
        using A9 xreal_1_th_44 sorry
      then have "x0 -REAL-1K5 r <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A16 xxreal_0_th_2 sorry
      then have A20: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A15 sorry
      then have A21: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ?L /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A10 A14 xboole_0_def_4 sorry
      have A22: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A18 A20 xxreal_2_def_12 sorry
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N be continuousFCONT-1V1"
        using A2 A8 fcont_1_th_16 sorry
      then have A23: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]) be continuousFCONT-1V1"
        using A10 A22 fcont_1_th_16 sorry
      have A24: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 ?L"
        using A8 A10 A18 A20 xxreal_2_def_12 sorry
      have " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
      proof-
        show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
        proof-
          have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
            using A3 sorry
          have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingRFUNCT-2V1 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)))"
          proof(rule impI)
            assume A25: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
            let ?R = "minXXREAL-0K4(f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm,?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fp"
              using A7 A16 A21 A25 rfunct_2_th_20 sorry
            then have A26: "0NUMBERSK6 <XXREAL-0R3 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            have "?fm <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A7 A11 A19 A25 rfunct_2_th_20 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A26 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
            proof(rule bexI[of _ "N1"])
              have "?fm <XXREAL-0R3 ?fp"
                using A17 A21 A19 A25 rfunct_2_th_20 sorry
              then have "[.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A27: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fm,?fp .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A28: "].RCOMP-1K2 ?fm,?fp .[ c=TARSKIR1 [.RCOMP-1K1 ?fm,?fp .]"
                    using xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A29: "r2 =HIDDENR1 x"and A30: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A31: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A6 sorry
                  have "?R <=XXREAL-0R1 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A32: "r2 <XXREAL-0R3 ?fp"
                    using A31 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fm <XXREAL-0R3 r2"
                    using A30 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fm,?fp .["
                    using A32 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A33: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A34: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A1 A24 A23 A17 A27 A29 A28 fcont_2_th_15 xboole_1_th_1 sorry
                  have "s inHIDDENR3 N"
                    using A10 A22 A33 sorry
                  then have "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
                    using A8 A14 xboole_0_def_4 sorry
                  then have A35: "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                    using relat_1_th_61 sorry
                  then have "x =HIDDENR1 ?f1 .FUNCT-1K1 s"
                    using A34 funct_1_th_47 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
                    using A35 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingRFUNCT-2V2 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)))"
          proof(rule impI)
            assume A36: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
            let ?R = "minXXREAL-0K4(?fm -XCMPLX-0K6 f .FUNCT-1K1 x0,f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp)"
            have "?fp <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A7 A16 A21 A36 rfunct_2_th_21 sorry
            then have A37: "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
              using xreal_1_th_50 sorry
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fm"
              using A7 A11 A19 A36 rfunct_2_th_21 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A37 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
            proof(rule bexI[of _ "N1"])
              have "?fp <XXREAL-0R3 ?fm"
                using A17 A21 A19 A36 rfunct_2_th_21 sorry
              then have "[.RCOMP-1K1 ?fm,?fp .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A38: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fp,?fm .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A39: "].RCOMP-1K2 ?fp,?fm .[ c=TARSKIR1 [.RCOMP-1K1 ?fp,?fm .]"
                    using xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A40: "r2 =HIDDENR1 x"and A41: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A42: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A6 sorry
                  have "?R <=XXREAL-0R1 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fm -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A43: "r2 <XXREAL-0R3 ?fm"
                    using A42 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fp <XXREAL-0R3 r2"
                    using A41 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fp,?fm .["
                    using A43 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A44: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A45: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A1 A24 A23 A17 A38 A40 A39 fcont_2_th_15 xboole_1_th_1 sorry
                  have "s inHIDDENR3 N"
                    using A10 A22 A44 sorry
                  then have "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
                    using A8 A14 xboole_0_def_4 sorry
                  then have A46: "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                    using relat_1_th_61 sorry
                  then have "x =HIDDENR1 ?f1 .FUNCT-1K1 s"
                    using A45 funct_1_th_47 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
                    using A46 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
         sorry
    qed "sorry"
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
      using rcomp_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_25:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be continuousFCONT-1V1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "right-open-halflineLIMFUNC1K4 p"
    assume A1: "right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be continuousFCONT-1V1"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
    have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) implies ( ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)))"
    proof(rule ballI,rule impI)
      fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      let ?f1 = "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L"
      assume "r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      then obtain x0 where
        [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A4: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A5: "?f1 .FUNCT-1K1 x0 =COMPLEX1R1 r1"
        using partfun1_th_3 sorry
      have A6: "r1 =COMPLEX1R1 f .FUNCT-1K1 x0"
        using A4 A5 funct_1_th_47 sorry
      have A7: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
        using A4 relat_1_th_61 sorry
      then have "x0 inTARSKIR2 ?L"
        using xboole_0_def_4 sorry
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A8: "N c=TARSKIR1 ?L"
        using rcomp_1_th_18 sorry
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A9: "0NUMBERSK6 <XXREAL-0R3 r"and A10: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
        using rcomp_1_def_6 sorry
      have 
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A9 xreal_1_th_215 sorry
      then have A11: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 sorry
      have A12: "r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r"
        using A9 xreal_1_th_216 sorry
      then have A13: "x0 -REAL-1K5 r <XXREAL-0R3 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_15 sorry
      have A14: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 A8 sorry
      let ?fp = "f .FUNCT-1K1 (x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
      let ?fm = "f .FUNCT-1K1 (x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M)"
      have A15: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A12 xreal_1_th_8 sorry
      have A16: "x0 <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A9 xreal_1_th_29 xreal_1_th_215 sorry
      then have A17: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A11 xxreal_0_th_2 sorry
      have "x0 <XXREAL-0R3 x0 +REAL-1K3 r"
        using A9 xreal_1_th_29 sorry
      then have "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A11 xxreal_0_th_2 sorry
      then have A18: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A13 sorry
      then have A19: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ?L /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A10 A14 xboole_0_def_4 sorry
      have "x0 -REAL-1K5 r <XXREAL-0R3 x0"
        using A9 xreal_1_th_44 sorry
      then have "x0 -REAL-1K5 r <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A16 xxreal_0_th_2 sorry
      then have A20: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A15 sorry
      then have A21: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ?L /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A10 A14 xboole_0_def_4 sorry
      have A22: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A18 A20 xxreal_2_def_12 sorry
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N be continuousFCONT-1V1"
        using A2 A8 fcont_1_th_16 sorry
      then have A23: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]) be continuousFCONT-1V1"
        using A10 A22 fcont_1_th_16 sorry
      have A24: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 ?L"
        using A8 A10 A18 A20 xxreal_2_def_12 sorry
      have " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
      proof-
        show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
        proof-
          have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
            using A3 sorry
          have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingRFUNCT-2V1 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)))"
          proof(rule impI)
            assume A25: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
            let ?R = "minXXREAL-0K4(f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm,?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fp"
              using A7 A16 A21 A25 rfunct_2_th_20 sorry
            then have A26: "0NUMBERSK6 <XXREAL-0R3 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            have "?fm <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A7 A11 A19 A25 rfunct_2_th_20 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A26 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
            proof(rule bexI[of _ "N1"])
              have "?fm <XXREAL-0R3 ?fp"
                using A17 A21 A19 A25 rfunct_2_th_20 sorry
              then have "[.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A27: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fm,?fp .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A28: "].RCOMP-1K2 ?fm,?fp .[ c=TARSKIR1 [.RCOMP-1K1 ?fm,?fp .]"
                    using xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A29: "r2 =HIDDENR1 x"and A30: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A31: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A6 sorry
                  have "?R <=XXREAL-0R1 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A32: "r2 <XXREAL-0R3 ?fp"
                    using A31 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fm <XXREAL-0R3 r2"
                    using A30 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fm,?fp .["
                    using A32 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A33: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A34: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A1 A24 A23 A17 A27 A29 A28 fcont_2_th_15 xboole_1_th_1 sorry
                  have "s inHIDDENR3 N"
                    using A10 A22 A33 sorry
                  then have "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
                    using A8 A14 xboole_0_def_4 sorry
                  then have A35: "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                    using relat_1_th_61 sorry
                  then have "x =HIDDENR1 ?f1 .FUNCT-1K1 s"
                    using A34 funct_1_th_47 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
                    using A35 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingRFUNCT-2V2 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)))"
          proof(rule impI)
            assume A36: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
            let ?R = "minXXREAL-0K4(?fm -XCMPLX-0K6 f .FUNCT-1K1 x0,f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp)"
            have "?fp <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A7 A16 A21 A36 rfunct_2_th_21 sorry
            then have A37: "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
              using xreal_1_th_50 sorry
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fm"
              using A7 A11 A19 A36 rfunct_2_th_21 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A37 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
            proof(rule bexI[of _ "N1"])
              have "?fp <XXREAL-0R3 ?fm"
                using A17 A21 A19 A36 rfunct_2_th_21 sorry
              then have "[.RCOMP-1K1 ?fm,?fp .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A38: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fp,?fm .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A39: "].RCOMP-1K2 ?fp,?fm .[ c=TARSKIR1 [.RCOMP-1K1 ?fp,?fm .]"
                    using xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A40: "r2 =HIDDENR1 x"and A41: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A42: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A6 sorry
                  have "?R <=XXREAL-0R1 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fm -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A43: "r2 <XXREAL-0R3 ?fm"
                    using A42 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fp <XXREAL-0R3 r2"
                    using A41 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fp,?fm .["
                    using A43 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A44: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A45: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A1 A24 A23 A17 A38 A40 A39 fcont_2_th_15 xboole_1_th_1 sorry
                  have "s inHIDDENR3 N"
                    using A10 A22 A44 sorry
                  then have "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?L"
                    using A8 A14 xboole_0_def_4 sorry
                  then have A46: "s inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                    using relat_1_th_61 sorry
                  then have "x =HIDDENR1 ?f1 .FUNCT-1K1 s"
                    using A45 funct_1_th_47 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
                    using A46 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
         sorry
    qed "sorry"
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
      using rcomp_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_3_th_26:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be continuousFCONT-1V1) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be continuousFCONT-1V1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "[#]SUBSET-1K2 REALNUMBERSK2"
    assume A1: "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be continuousFCONT-1V1"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
    have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
    proof(rule ballI,rule impI)
      fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume "r1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
      then obtain x0 where
        [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A4: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A5: "f .FUNCT-1K1 x0 =COMPLEX1R1 r1"
        using partfun1_th_3 sorry
      have A6: "x0 inTARSKIR2 ?L /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      let ?N = "the NeighbourhoodRCOMP-1M1-of x0"
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A7: "0NUMBERSK6 <XXREAL-0R3 r"and A8: "?N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
        using rcomp_1_def_6 sorry
      have 
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A7 xreal_1_th_215 sorry
      then have A9: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 sorry
      have A10: "r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r"
        using A7 xreal_1_th_216 sorry
      then have A11: "x0 -REAL-1K5 r <XXREAL-0R3 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_15 sorry
      have A12: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A10 xreal_1_th_8 sorry
      have A13: "?N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 sorry
      let ?fp = "f .FUNCT-1K1 (x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)"
      let ?fm = "f .FUNCT-1K1 (x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M)"
      have A14: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]) be continuousFCONT-1V1"
        using A2 fcont_1_th_16 sorry
      have A15: "x0 <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A7 xreal_1_th_29 xreal_1_th_215 sorry
      then have A16: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A9 xxreal_0_th_2 sorry
      have "x0 -REAL-1K5 r <XXREAL-0R3 x0"
        using A7 xreal_1_th_44 sorry
      then have "x0 -REAL-1K5 r <XXREAL-0R3 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A15 xxreal_0_th_2 sorry
      then have A17: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A12 sorry
      then have A18: "x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ?L /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A13 xboole_0_def_4 sorry
      have "x0 <XXREAL-0R3 x0 +REAL-1K3 r"
        using A7 xreal_1_th_29 sorry
      then have "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 x0 +REAL-1K3 r"
        using A9 xxreal_0_th_2 sorry
      then have A19: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A11 sorry
      then have A20: "x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 ?L /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 A13 xboole_0_def_4 sorry
      have A21: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 ].RCOMP-1K2 x0 -REAL-1K5 r,x0 +REAL-1K3 r .["
        using A19 A17 xxreal_2_def_12 sorry
      have " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof-
        show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof-
          have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
            using A3 sorry
          have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingRFUNCT-2V1 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
          proof(rule impI)
            assume A22: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be increasingRFUNCT-2V1"
            let ?R = "minXXREAL-0K4(f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm,?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fp"
              using A15 A18 A6 A22 rfunct_2_th_20 sorry
            then have A23: "0NUMBERSK6 <XXREAL-0R3 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            have "?fm <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A9 A20 A6 A22 rfunct_2_th_20 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A23 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "N1"])
              have "?fm <XXREAL-0R3 ?fp"
                using A16 A18 A20 A22 rfunct_2_th_20 sorry
              then have "[.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A24: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fm,?fp .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A25: "[.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ].RCOMP-1K2 ?fm,?fp .[ c=TARSKIR1 [.RCOMP-1K1 ?fm,?fp .]"
                    using A1 xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A26: "r2 =HIDDENR1 x"and A27: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A28: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A5 sorry
                  have "?R <=XXREAL-0R1 ?fp -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fp -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A29: "r2 <XXREAL-0R3 ?fp"
                    using A28 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fm) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fm <XXREAL-0R3 r2"
                    using A27 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fm,?fp .["
                    using A29 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A30: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A31: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A9 A15 A14 A24 A26 A25 fcont_2_th_15 xxreal_0_th_2 sorry
                  have "s inHIDDENR3 ?N"
                    using A8 A21 A30 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
                    using A13 A31 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingRFUNCT-2V2 implies ( ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
          proof(rule impI)
            assume A32: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be decreasingRFUNCT-2V2"
            let ?R = "minXXREAL-0K4(?fm -XCMPLX-0K6 f .FUNCT-1K1 x0,f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp)"
            have "?fp <XXREAL-0R3 f .FUNCT-1K1 x0"
              using A15 A18 A6 A32 rfunct_2_th_21 sorry
            then have A33: "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
              using xreal_1_th_50 sorry
            have "f .FUNCT-1K1 x0 <XXREAL-0R3 ?fm"
              using A9 A20 A6 A32 rfunct_2_th_21 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using xreal_1_th_50 sorry
            then have "0NUMBERSK6 <XXREAL-0R3 ?R"
              using A33 xxreal_0_th_15 sorry
            then obtain N1 where 
              [ty]:"N1 be NeighbourhoodRCOMP-1M1-of r1" and N1Def:"N1 = ].RCOMP-1K2 r1 -XCMPLX-0K6 ?R,r1 +XCMPLX-0K2 ?R .["
              using rcomp_1_def_6 sorry
            show " ex N1 be NeighbourhoodRCOMP-1M1-of r1 st N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof(rule bexI[of _ "N1"])
              have "?fp <XXREAL-0R3 ?fm"
                using A16 A18 A20 A32 rfunct_2_th_21 sorry
              then have "[.RCOMP-1K1 ?fm,?fp .] =XBOOLE-0R4 {}XBOOLE-0K1"
                using xxreal_1_th_29 sorry
              then have A34: "[.RCOMP-1K1 ?fm,?fp .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?fp,?fm .] =XBOOLE-0R4 [.RCOMP-1K1 ?fp,?fm .]"
                 sorry
              show "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 N1 implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  have A35: "].RCOMP-1K2 ?fp,?fm .[ c=TARSKIR1 [.RCOMP-1K1 ?fp,?fm .]"
                    using xxreal_1_th_25 sorry
                  assume "x inHIDDENR3 N1"
                  then obtain r2 where
                    [ty]:"r2 be RealXREAL-0M1" and 
                    A36: "r2 =HIDDENR1 x"and A37: "f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R <XXREAL-0R3 r2"and A38: "r2 <XXREAL-0R3 f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R"
                    using A5 sorry
                  have "?R <=XXREAL-0R1 ?fm -XCMPLX-0K6 f .FUNCT-1K1 x0"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 +XCMPLX-0K2 ?R <=XXREAL-0R1 f .FUNCT-1K1 x0 +XCMPLX-0K2 (?fm -XCMPLX-0K6 f .FUNCT-1K1 x0)"
                    using xreal_1_th_7 sorry
                  then have A39: "r2 <XXREAL-0R3 ?fm"
                    using A38 xxreal_0_th_2 sorry
                  have "?R <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp"
                    using xxreal_0_th_17 sorry
                  then have "f .FUNCT-1K1 x0 -XCMPLX-0K6 (f .FUNCT-1K1 x0 -XCMPLX-0K6 ?fp) <=XXREAL-0R1 f .FUNCT-1K1 x0 -XCMPLX-0K6 ?R"
                    using xreal_1_th_13 sorry
                  then have "?fp <XXREAL-0R3 r2"
                    using A37 xxreal_0_th_2 sorry
                  then have "r2 inHIDDENR3 ].RCOMP-1K2 ?fp,?fm .["
                    using A39 sorry
                  then obtain s where
                    [ty]:"s be RealXREAL-0M1" and 
                    A40: "s inHIDDENR3 [.RCOMP-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M,x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M .]"and A41: "x =HIDDENR1 f .FUNCT-1K1 s"
                    using A1 A14 A16 A34 A36 A35 fcont_2_th_15 xboole_1_th_1 sorry
                  have "s inHIDDENR3 ?N"
                    using A8 A21 A40 sorry
                  thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
                    using A13 A41 funct_1_def_3 sorry
                qed "sorry"
                thus "N1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using tarski_def_3 sorry
              qed
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ex N be NeighbourhoodRCOMP-1M1-of r1 st N c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
         sorry
    qed "sorry"
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
      using rcomp_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
