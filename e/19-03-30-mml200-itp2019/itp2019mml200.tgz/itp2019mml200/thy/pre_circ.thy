theory pre_circ
  imports funct_7 trees_4 orders_1 seq_4 binarith
   "../mizar_extension/E_number"
begin
(*begin*)
theorem pre_circ_sch_1:
  fixes Af0 Ff1 Pp1 
  assumes
[ty]: "Af0 be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } be finiteFINSET-1V1"
  proof-
    let ?B = "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : x inTARSKIR2 Af0 }"
    have A1: "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } c=TARSKIR1 ?B"
    proof-
      have "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } c=TARSKIR1 {Ff1(x) where x be ElementSUBSET-1M1-of Af0 : x inTARSKIR2 Af0 }"
      proof-
        have " for a be objectHIDDENM1 holds a inHIDDENR3 {Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } implies a inHIDDENR3 {Ff1(x) where x be ElementSUBSET-1M1-of Af0 : x inTARSKIR2 Af0 }"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 {Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) }"
          then have " ex b be ElementSUBSET-1M1-of Af0 st Ff1(b) =HIDDENR1 a & Pp1(b)"
             sorry
          thus "a inHIDDENR3 {Ff1(x) where x be ElementSUBSET-1M1-of Af0 : x inTARSKIR2 Af0 }"
             sorry
        qed "sorry"
        thus "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } c=TARSKIR1 {Ff1(x) where x be ElementSUBSET-1M1-of Af0 : x inTARSKIR2 Af0 }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A2: "Af0 be finiteFINSET-1V1"
       sorry
    have "?B be finiteFINSET-1V1"
      using fraenkel_sch_21 A2 sorry
    thus "{Ff1(x) where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } be finiteFINSET-1V1"
      using A1 sorry
  qed

(*begin*)
(*\$CT*)
mtheorem pre_circ_th_2:
" for I be setHIDDENM2 holds  for MSS be ManySortedSetPBOOLEM1-of I holds (MSS #FINSEQ-2K6\<^bsub>(I)\<^esub>).FUNCT-1K1 <*>FINSEQ-1K7 I =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for I be setHIDDENM2 holds  for MSS be ManySortedSetPBOOLEM1-of I holds (MSS #FINSEQ-2K6\<^bsub>(I)\<^esub>).FUNCT-1K1 <*>FINSEQ-1K7 I =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix MSS assume [ty]: "MSS be ManySortedSetPBOOLEM1-of I"
    obtain eI where 
      [ty]:"eI be ElementFINSEQ-2M2\<^bsub>(I)\<^esub>-of I * FINSEQ-2K3" and eIDef:"eI = <*>FINSEQ-1K7 I"
      using finseq_1_th_49 sorry
    have "(MSS #FINSEQ-2K6\<^bsub>(I)\<^esub>).FUNCT-1K1 <*>FINSEQ-1K7 I =HIDDENR1 productCARD-3K4 (MSS *FUNCT-1K3 eI)"
      using finseq_2_def_5 sorry
    also have "... = {TARSKIK1 {}XBOOLE-0K1 }"
      using card_3_th_10 sorry
    finally show "(MSS #FINSEQ-2K6\<^bsub>(I)\<^esub>).FUNCT-1K1 <*>FINSEQ-1K7 I =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve i, j, x, y for "objectHIDDENM1"
reserve f, g for "FunctionFUNCT-1M1"
theorem pre_circ_sch_2:
  fixes If0 Ff1 Gf1 Pp1 
  assumes
[ty]: "If0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1"
  shows " ex f be ManySortedSetPBOOLEM1-of If0 st  for i be ElementSUBSET-1M1-of If0 holds i inTARSKIR2 If0 implies (Pp1(i) implies f .FUNCT-1K1 i =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies f .FUNCT-1K1 i =HIDDENR1 Gf1(i))"
  proof-
    have " ex tVar3 be ManySortedSetPBOOLEM1-of If0 st  for i be ElementSUBSET-1M1-of If0 holds  not (i inTARSKIR2 If0 &  not ( not (Pp1(i) &  not tVar3 .FUNCT-1K1 i =HIDDENR1 Ff1(i)) &  not ( not Pp1(i) &  not tVar3 .FUNCT-1K1 i =HIDDENR1 Gf1(i))))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. (Pp1(Lamb1) implies Lamb2 =HIDDENR1 Ff1(Lamb1)) & ( not Pp1(Lamb1) implies Lamb2 =HIDDENR1 Gf1(Lamb1))"
      have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( ex j be objectHIDDENM1 st (Pp1(i) implies j =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies j =HIDDENR1 Gf1(i)))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 If0"
        show " ex j be objectHIDDENM1 st (Pp1(i) implies j =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies j =HIDDENR1 Gf1(i))"
        proof-
          have " ex tVar1 be objectHIDDENM1 st (Pp1(i) implies tVar1 =HIDDENR1 tVar1) & ( not Pp1(i) implies tVar1 =HIDDENR1 Gf1(i))"
          proof-
            show " ex tVar1 be objectHIDDENM1 st (Pp1(i) implies tVar1 =HIDDENR1 tVar1) & ( not Pp1(i) implies tVar1 =HIDDENR1 Gf1(i))"
            proof-
              have cases: "Pp1(i) or  not Pp1(i)"
                 sorry
              have case1: "Pp1(i) implies ( ex tVar1 be objectHIDDENM1 st (Pp1(i) implies tVar1 =HIDDENR1 tVar1) & ( not Pp1(i) implies tVar1 =HIDDENR1 Gf1(i)))"
              proof(rule impI)
                assume A2: "Pp1(i)"
                show " ex tVar1 be objectHIDDENM1 st (Pp1(i) implies tVar1 =HIDDENR1 tVar1) & ( not Pp1(i) implies tVar1 =HIDDENR1 Gf1(i))"
                proof(rule bexI[of _ "Ff1(i)"])
                  show "(Pp1(i) implies Ff1(i) =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies Ff1(i) =HIDDENR1 Gf1(i))"
                    using A2 sorry
                qed "sorry"
              qed
              have case2: " not Pp1(i) implies ( ex tVar2 be objectHIDDENM1 st (Pp1(i) implies tVar2 =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies tVar2 =HIDDENR1 tVar2))"
              proof(rule impI)
                assume A3: " not Pp1(i)"
                show " ex tVar2 be objectHIDDENM1 st (Pp1(i) implies tVar2 =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies tVar2 =HIDDENR1 tVar2)"
                proof(rule bexI[of _ "Gf1(i)"])
                  show "(Pp1(i) implies Gf1(i) =HIDDENR1 Ff1(i)) & ( not Pp1(i) implies Gf1(i) =HIDDENR1 Gf1(i))"
                    using A3 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
      qed "sorry"
      obtain f where
        [ty]:"f be ManySortedSetPBOOLEM1-of If0" and 
        A4: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ?Q(i,f .FUNCT-1K1 i)"
        using pboole_sch_3 A1 sorry
      show " ex tVar3 be ManySortedSetPBOOLEM1-of If0 st  for i be ElementSUBSET-1M1-of If0 holds  not (i inTARSKIR2 If0 &  not ( not (Pp1(i) &  not tVar3 .FUNCT-1K1 i =HIDDENR1 Ff1(i)) &  not ( not Pp1(i) &  not tVar3 .FUNCT-1K1 i =HIDDENR1 Gf1(i))))"
      proof(rule bexI[of _ "f"])
        show " for i be ElementSUBSET-1M1-of If0 holds  not (i inTARSKIR2 If0 &  not ( not (Pp1(i) &  not f .FUNCT-1K1 i =HIDDENR1 Ff1(i)) &  not ( not Pp1(i) &  not f .FUNCT-1K1 i =HIDDENR1 Gf1(i))))"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem pre_circ_cl_1:
  mlet "I be setHIDDENM2"
"cluster non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3 for ManySortedSetPBOOLEM1-of I"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of I st it be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
  proof-
    have " ex tVar4 be ManySortedSetPBOOLEM1-of I st tVar4 be non-emptyRELAT-1V2 & tVar4 be finite-yieldingFINSET-1V3"
    proof-
      obtain f where 
        [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      have 
        [ty]:"f be ManySortedSetPBOOLEM1-of I"
         sorry
      show " ex tVar4 be ManySortedSetPBOOLEM1-of I st tVar4 be non-emptyRELAT-1V2 & tVar4 be finite-yieldingFINSET-1V3"
      proof(rule bexI[of _ "f"],rule conjMI)
        show "f be non-emptyRELAT-1V2"
           sorry
        show "f be finite-yieldingFINSET-1V3"
          using funcop_1_th_7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pre_circ_cl_2:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "A be SubsetSUBSET-1M2-of I"
"cluster M  |RELAT-1K8 A as-term-is totalPARTFUN1V1\<^bsub>(A)\<^esub> for A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 M  |RELAT-1K8 A implies it be totalPARTFUN1V1\<^bsub>(A)\<^esub>"
  proof-
    have " for VarFor1 be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 M  |RELAT-1K8 A &  not VarFor1 be totalPARTFUN1V1\<^bsub>(A)\<^esub>)"
    proof-
      let ?B = "M  |RELAT-1K8 A"
      have "domRELAT-1K1 ?B =XBOOLE-0R4 domRELAT-1K1 M /\\SUBSET-1K9\<^bsub>(I)\<^esub> A & domRELAT-1K1 M =XBOOLE-0R4 I"
        using partfun1_def_2 relat_1_th_61 sorry
      then have "domRELAT-1K1 ?B =XBOOLE-0R4 A"
        using xboole_1_th_28 sorry
      thus " for VarFor1 be A -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 M  |RELAT-1K8 A &  not VarFor1 be totalPARTFUN1V1\<^bsub>(A)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pre_circ_cl_3:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "A be SubsetSUBSET-1M2-of I"
"cluster M  |RELAT-1K8 A as-term-is totalPARTFUN1V1\<^bsub>(A)\<^esub>"
proof
(*coherence*)
  show "M  |RELAT-1K8 A be totalPARTFUN1V1\<^bsub>(A)\<^esub>"
     sorry
qed "sorry"

mtheorem pre_circ_cl_4:
  mlet "M be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1", "A be setHIDDENM2"
"cluster M  |RELAT-1K8 A as-term-is non-emptyFUNCT-1V4"
proof
(*coherence*)
  show "M  |RELAT-1K8 A be non-emptyFUNCT-1V4"
  proof-
    have "M  |RELAT-1K8 A be non-emptyRELAT-1V2"
    proof-
      have Cut151: "rngFUNCT-1K2 (M  |RELAT-1K8 A) c=TARSKIR1 rngFUNCT-1K2 M"
        using relat_1_th_70 sorry
      have " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 (M  |RELAT-1K8 A)"
      proof-
        show " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 (M  |RELAT-1K8 A)"
          using relat_1_def_9 Cut151 sorry
      qed
      thus "M  |RELAT-1K8 A be non-emptyRELAT-1V2"
        using relat_1_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pre_circ_th_3:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds unionTARSKIK3 (rngFUNCT-1K2 B) be  non emptyXBOOLE-0V1"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  not unionTARSKIK3 (rngFUNCT-1K2 B) be emptyXBOOLE-0V1"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    let ?i = "the ElementSUBSET-1M1-of I"
    have "?i inTARSKIR2 I"
       sorry
    then have "?i inTARSKIR2 domRELAT-1K1 B"
      using partfun1_def_2 sorry
    then have "B .FUNCT-1K1 ?i inTARSKIR2 rngFUNCT-1K2 B"
      using funct_1_def_3 sorry
    thus " not unionTARSKIK3 (rngFUNCT-1K2 B) be emptyXBOOLE-0V1"
      using orders_1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_4:
" for I be setHIDDENM2 holds uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
proof(rule ballI)
  fix I assume [ty]: "I be setHIDDENM2"
  show "uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
  proof-
    have cases: "I =XBOOLE-0R4 {}XBOOLE-0K1 or I <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have case1: "I =XBOOLE-0R4 {}XBOOLE-0K1 implies uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
    proof(rule impI)
      assume "I =XBOOLE-0R4 {}XBOOLE-0K1"
      thus "uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
        using funct_5_th_43 sorry
    qed
    have case2: "I <>HIDDENR2 {}XBOOLE-0K1 implies uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
    proof(rule impI)
      assume "I <>HIDDENR2 {}XBOOLE-0K1"
      then have "rngFUNCT-1K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
        using funcop_1_th_8 sorry
      also have "... = FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1)"
        using funct_5_th_57 sorry
      finally have "rngFUNCT-1K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =HIDDENR1 FuncsFUNCT-2K1({}XBOOLE-0K1,{}XBOOLE-0K1)"
         sorry
      then have "domRELAT-1K1 (uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1)) =HIDDENR1 [:ZFMISC-1K2 domRELAT-1K1 (I -->FUNCOP-1K7 {}XBOOLE-0K1),{}XBOOLE-0K1 :]"
        using funct_5_th_26 sorry
      also have "... = {}XBOOLE-0K1"
        using zfmisc_1_th_90 sorry
      finally have "domRELAT-1K1 (uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1)) =HIDDENR1 {}XBOOLE-0K1"
         sorry
      thus "uncurryFUNCT-5K2 (I -->FUNCOP-1K7 {}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem pre_circ_th_5:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(I -->FUNCOP-1K7 A,B) holds domRELAT-1K1 (commuteFUNCT-6K9 F) =XBOOLE-0R4 A"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
  fix F assume [ty]: "F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(I -->FUNCOP-1K7 A,B)"
  have A1: "domRELAT-1K1 B =XBOOLE-0R4 I"
    using partfun1_def_2 sorry
  have A2: "domRELAT-1K1 F =XBOOLE-0R4 I"
    using partfun1_def_2 sorry
  show "domRELAT-1K1 (commuteFUNCT-6K9 F) =XBOOLE-0R4 A"
  proof-
    have cases: "A be emptyXBOOLE-0V1 or A be  non emptyXBOOLE-0V1"
       sorry
    have case1: "A be emptyXBOOLE-0V1 implies domRELAT-1K1 (commuteFUNCT-6K9 F) =XBOOLE-0R4 A"
    proof(rule impI)
      assume A3: "A be emptyXBOOLE-0V1"
      have "rngFUNCT-1K2 F c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 F"
          then obtain i where
            [ty]:"i be objectHIDDENM1" and 
            A4: "i inHIDDENR3 I & x =HIDDENR1 F .FUNCT-1K1 i"
            using A2 funct_1_def_3 sorry
          have "(I -->FUNCOP-1K7 A).FUNCT-1K1 i =XBOOLE-0R4 A & x be FunctionFUNCT-2M1-of((I -->FUNCOP-1K7 A).FUNCT-1K1 i,B .FUNCT-1K1 i)"
            using A4 funcop_1_th_7 pboole_def_15 sorry
          then have "x =HIDDENR1 {}XBOOLE-0K1"
            using A3 sorry
          thus "x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
            using tarski_def_1 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 F c=TARSKIR1 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_3 sorry
      qed
      then have "rngFUNCT-1K2 F =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        using zfmisc_1_th_33 sorry
      then have A5: "F =PBOOLER9\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {}XBOOLE-0K1"
        using A2 funcop_1_th_9 sorry
      have "commuteFUNCT-6K9 F =HIDDENR1 curry'FUNCT-5K3 (uncurryFUNCT-5K2 F)"
        using funct_6_def_10 sorry
      also have "... = {}XBOOLE-0K1"
        using A5 pre_circ_th_4 funct_5_th_42 sorry
      finally have "commuteFUNCT-6K9 F =HIDDENR1 {}XBOOLE-0K1"
         sorry
      thus "domRELAT-1K1 (commuteFUNCT-6K9 F) =XBOOLE-0R4 A"
        using A3 sorry
    qed
    have case2: "A be  non emptyXBOOLE-0V1 implies domRELAT-1K1 (commuteFUNCT-6K9 F) =XBOOLE-0R4 A"
    proof(rule impI)
      assume A6: "A be  non emptyXBOOLE-0V1"
      have "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(A,unionTARSKIK3 (rngFUNCT-1K2 B))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies x inHIDDENR3 FuncsFUNCT-2K1(A,unionTARSKIK3 (rngFUNCT-1K2 B))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 F"
          then obtain i where
            [ty]:"i be objectHIDDENM1" and 
            A7: "i inHIDDENR3 domRELAT-1K1 F"and A8: "x =HIDDENR1 F .FUNCT-1K1 i"
            using funct_1_def_3 sorry
          have "(I -->FUNCOP-1K7 A).FUNCT-1K1 i =XBOOLE-0R4 A"
            using A2 A7 funcop_1_th_7 sorry
          then obtain x9 where 
            [ty]:"x9 be FunctionFUNCT-2M1-of(A,B .FUNCT-1K1 i)" and x9Def:"x9 = x"
            using A2 A7 A8 pboole_def_15 sorry
          have "B .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 B"
            using A1 A2 A7 funct_1_def_3 sorry
          then have "rngFUNCT-1K2 x9 c=TARSKIR1 B .FUNCT-1K1 i & B .FUNCT-1K1 i c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 B)"
            using relat_1_def_19 zfmisc_1_th_74 sorry
          then have A9: "rngFUNCT-1K2 x9 c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 B)"
             sorry
          have "domRELAT-1K1 x9 =XBOOLE-0R4 A"
            using A2 A7 funct_2_def_1 sorry
          thus "x inHIDDENR3 FuncsFUNCT-2K1(A,unionTARSKIK3 (rngFUNCT-1K2 B))"
            using A9 funct_2_def_2 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 F c=TARSKIR1 FuncsFUNCT-2K1(A,unionTARSKIK3 (rngFUNCT-1K2 B))"
          using tarski_def_3 sorry
      qed
      then have "F inTARSKIR2 FuncsFUNCT-2K1(I,FuncsFUNCT-2K1(A,unionTARSKIK3 (rngFUNCT-1K2 B)))"
        using A2 funct_2_def_2 sorry
      then have "commuteFUNCT-6K9 F inTARSKIR2 FuncsFUNCT-2K1(A,FuncsFUNCT-2K1(I,unionTARSKIK3 (rngFUNCT-1K2 B)))"
        using A6 funct_6_th_55 sorry
      then have A10: "commuteFUNCT-6K9 F be FunctionFUNCT-2M1-of(A,FuncsFUNCT-2K1(I,unionTARSKIK3 (rngFUNCT-1K2 B)))"
        using funct_2_th_66 sorry
      have "unionTARSKIK3 (rngFUNCT-1K2 B) be  non emptyXBOOLE-0V1"
        using pre_circ_th_3 sorry
      then have "FuncsFUNCT-2K1(I,unionTARSKIK3 (rngFUNCT-1K2 B)) be  non emptyXBOOLE-0V1"
        using funct_2_th_8 sorry
      thus "domRELAT-1K1 (commuteFUNCT-6K9 F) =XBOOLE-0R4 A"
        using A10 funct_2_def_1 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

theorem pre_circ_sch_3:
  fixes Df0 Af0 Ff2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty_func]: "\<And> x1 x2. x1 be NatNAT-1M1 \<Longrightarrow> x2 be ElementSUBSET-1M1-of Df0 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Df0"
  shows "( ex f be sequenceNAT-1M2-of Df0 st f .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f .NAT-1K8\<^bsub>(Df0)\<^esub> i))) & ( for f1 be sequenceNAT-1M2-of Df0 holds  for f2 be sequenceNAT-1M2-of Df0 holds (f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f1 .NAT-1K8\<^bsub>(Df0)\<^esub> i))) & (f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f2 .NAT-1K8\<^bsub>(Df0)\<^esub> i))) implies f1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Df0)\<^esub> f2)"
  proof-
    have "( ex f be sequenceNAT-1M2-of Df0 st f .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f .NAT-1K8\<^bsub>(Df0)\<^esub> i))) & ( for f1 be sequenceNAT-1M2-of Df0 holds  for f2 be sequenceNAT-1M2-of Df0 holds f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & (( for i be NatNAT-1M1 holds f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f1 .NAT-1K8\<^bsub>(Df0)\<^esub> i)) & (f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f2 .NAT-1K8\<^bsub>(Df0)\<^esub> i)))) implies f1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Df0)\<^esub> f2)"
    proof(rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
      show " ex f be sequenceNAT-1M2-of Df0 st f .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for i be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f .NAT-1K8\<^bsub>(Df0)\<^esub> i))"
        using nat_1_sch_12 sorry
      fix f1 assume [ty]: "f1 be sequenceNAT-1M2-of Df0"
      fix f2 assume [ty]: "f2 be sequenceNAT-1M2-of Df0"
      assume A1: "f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"
        and A2: " for i be NatNAT-1M1 holds f1 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f1 .NAT-1K8\<^bsub>(Df0)\<^esub> i)"
        and A3: "f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"
        and A4: " for i be NatNAT-1M1 holds f2 .NAT-1K8\<^bsub>(Df0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(i,f2 .NAT-1K8\<^bsub>(Df0)\<^esub> i)"
      show "f1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Df0)\<^esub> f2"
        using nat_1_sch_16 A1 A2 A3 A4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem pre_circ_sch_4:
  fixes Jf0 If0 Af0 Bf0 Ff1 
  assumes
[ty]: "Jf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "If0 be SubsetSUBSET-1M2-of Jf0" and
  [ty]: "Af0 be ManySortedSetPBOOLEM1-of If0" and
  [ty]: "Bf0 be ManySortedSetPBOOLEM1-of If0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: " for i be ElementSUBSET-1M1-of Jf0 holds i inTARSKIR2 If0 implies Ff1(i) be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i)"
  shows " ex f be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be ElementSUBSET-1M1-of Jf0 holds i inTARSKIR2 If0 implies f .FUNCT-1K1 i =XBOOLE-0R4 Ff1(i)"
  proof-
    have " ex tVar5 be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be ElementSUBSET-1M1-of Jf0 holds  not (i inTARSKIR2 If0 &  not tVar5 .FUNCT-1K1 i =XBOOLE-0R4 Ff1(i))"
    proof-
      obtain f where
        [ty]:"f be ManySortedSetPBOOLEM1-of If0" and 
        A2: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies f .FUNCT-1K1 i =XBOOLE-0R4 Ff1(i)"
        using pboole_sch_4 sorry
      have "f be Function-yieldingFUNCOP-1V1"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be setHIDDENM2"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 domRELAT-1K1 f"
          then have A3: "i inHIDDENR3 If0"
            using partfun1_def_2 sorry
          then have "Ff1(i) be FunctionFUNCT-1M1"
            using A1 sorry
          thus "f .FUNCT-1K1 i be setHIDDENM2"
            using A2 A3 sorry
        qed "sorry"
        thus "f be Function-yieldingFUNCOP-1V1"
          using funcop_1_def_6 sorry
      qed
      then have 
        [ty]:"f be ManySortedFunctionPBOOLEM2-of If0"
         sorry
      have "f be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0)"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies f .FUNCT-1K1 i be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i :])"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A4: "i inHIDDENR3 If0"
          then have "Ff1(i) be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i)"
            using A1 sorry
          thus "f .FUNCT-1K1 i be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i :])"
            using A2 A4 sorry
        qed "sorry"
        thus "f be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0)"
          using pboole_def_15 sorry
      qed
      then have 
        [ty]:"f be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0)"
         sorry
      show " ex tVar5 be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be ElementSUBSET-1M1-of Jf0 holds  not (i inTARSKIR2 If0 &  not tVar5 .FUNCT-1K1 i =XBOOLE-0R4 Ff1(i))"
      proof(rule bexI[of _ "f"])
        show " for i be ElementSUBSET-1M1-of Jf0 holds  not (i inTARSKIR2 If0 &  not f .FUNCT-1K1 i =XBOOLE-0R4 Ff1(i))"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem pre_circ_th_6:
" for I be setHIDDENM2 holds  for f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for g be FunctionFUNCT-1M1 holds  for s be ElementSUBSET-1M1-of productCARD-3K4 f holds domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f & ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x) implies s +*FUNCT-4K1 g be ElementSUBSET-1M1-of productCARD-3K4 f"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix I assume [ty]: "I be setHIDDENM2"
  fix f assume [ty]: "f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix s assume [ty]: "s be ElementSUBSET-1M1-of productCARD-3K4 f"
  assume A1: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
    and A2: " for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
  have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (s +*FUNCT-4K1 g).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A4: "x inHIDDENR3 domRELAT-1K1 f"
    show "(s +*FUNCT-4K1 g).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    proof-
      have cases: "x inHIDDENR3 domRELAT-1K1 g or  not x inHIDDENR3 domRELAT-1K1 g"
         sorry
      have case1: "x inHIDDENR3 domRELAT-1K1 g implies (s +*FUNCT-4K1 g).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
      proof(rule impI)
        assume A5: "x inHIDDENR3 domRELAT-1K1 g"
        then have "(s +*FUNCT-4K1 g).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          using funct_4_th_13 sorry
        thus "(s +*FUNCT-4K1 g).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          using A2 A5 sorry
      qed
      have case2: " not x inHIDDENR3 domRELAT-1K1 g implies (s +*FUNCT-4K1 g).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
      proof(rule impI)
        assume A6: " not x inHIDDENR3 domRELAT-1K1 g"
        have A7: " ex g9 be FunctionFUNCT-1M1 st (s =FUNCT-1R1 g9 & domRELAT-1K1 g9 =XBOOLE-0R4 domRELAT-1K1 f) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g9 .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x)"
          using card_3_def_5 sorry
        have "(s +*FUNCT-4K1 g).FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 x"
          using A6 funct_4_th_11 sorry
        thus "(s +*FUNCT-4K1 g).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
          using A4 A7 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  have "domRELAT-1K1 (s +*FUNCT-4K1 g) =XBOOLE-0R4 domRELAT-1K1 s \\/XBOOLE-0K2 domRELAT-1K1 g & domRELAT-1K1 s =XBOOLE-0R4 domRELAT-1K1 f"
    using card_3_th_9 funct_4_def_1 sorry
  then have "domRELAT-1K1 (s +*FUNCT-4K1 g) =XBOOLE-0R4 domRELAT-1K1 f"
    using A1 xboole_1_th_12 sorry
  thus "s +*FUNCT-4K1 g be ElementSUBSET-1M1-of productCARD-3K4 f"
    using A3 card_3_th_9 sorry
qed "sorry"

mtheorem pre_circ_th_7:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of A holds  for InpFs be ManySortedFunctionPBOOLEM5\<^bsub>(A)\<^esub>-of(A -->FUNCOP-1K7 B,C) holds  for b be ElementSUBSET-1M1-of B holds  ex c be ManySortedSetPBOOLEM1-of A st c =FUNCT-1R1 (commuteFUNCT-6K9 InpFs).FUNCT-1K1 b & c inPBOOLER3\<^bsub>(A)\<^esub> C"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of A holds  for InpFs be ManySortedFunctionPBOOLEM5\<^bsub>(A)\<^esub>-of(A -->FUNCOP-1K7 B,C) holds  for b be ElementSUBSET-1M1-of B holds  ex tVar6 be ManySortedSetPBOOLEM1-of A st tVar6 =FUNCT-1R1 (commuteFUNCT-6K9 InpFs).FUNCT-1K1 b & tVar6 inPBOOLER3\<^bsub>(A)\<^esub> C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix C assume [ty]: "C be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of A"
    fix InpFs assume [ty]: "InpFs be ManySortedFunctionPBOOLEM5\<^bsub>(A)\<^esub>-of(A -->FUNCOP-1K7 B,C)"
    fix b assume [ty]: "b be ElementSUBSET-1M1-of B"
    have A1: "domRELAT-1K1 InpFs =XBOOLE-0R4 A"
      using partfun1_def_2 sorry
    have "domRELAT-1K1 (uncurryFUNCT-5K2 InpFs) =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
    proof-
      have "domRELAT-1K1 (uncurryFUNCT-5K2 InpFs) c=TARSKIR1 [:ZFMISC-1K2 A,B :] & [:ZFMISC-1K2 A,B :] c=TARSKIR1 domRELAT-1K1 (uncurryFUNCT-5K2 InpFs)"
      proof(rule conjMI)
        show "domRELAT-1K1 (uncurryFUNCT-5K2 InpFs) c=TARSKIR1 [:ZFMISC-1K2 A,B :]"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 InpFs) implies i inHIDDENR3 [:ZFMISC-1K2 A,B :]"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 InpFs)"
            then obtain x g y where
              [ty]:"x be objectHIDDENM1" "g be FunctionFUNCT-1M1" "y be objectHIDDENM1" and 
              A2: "i =HIDDENR1 [TARSKIK4 x,y ]"and A3: "x inHIDDENR3 domRELAT-1K1 InpFs"and A4: "g =FUNCT-1R1 InpFs .FUNCT-1K1 x"and A5: "y inHIDDENR3 domRELAT-1K1 g"
              using funct_5_def_2 sorry
            have "g be FunctionFUNCT-2M1-of((A -->FUNCOP-1K7 B).FUNCT-1K1 x,C .FUNCT-1K1 x)"
              using A1 A3 A4 pboole_def_15 sorry
            then have "domRELAT-1K1 g =XBOOLE-0R4 (A -->FUNCOP-1K7 B).FUNCT-1K1 x"
              using A1 A3 funct_2_def_1 sorry
            then have "domRELAT-1K1 g =XBOOLE-0R4 B"
              using A1 A3 funcop_1_th_7 sorry
            thus "i inHIDDENR3 [:ZFMISC-1K2 A,B :]"
              using A1 A2 A3 A5 zfmisc_1_th_87 sorry
          qed "sorry"
          thus "domRELAT-1K1 (uncurryFUNCT-5K2 InpFs) c=TARSKIR1 [:ZFMISC-1K2 A,B :]"
            using tarski_def_3 sorry
        qed
        have " for i1 be objectHIDDENM1 holds  for i2 be objectHIDDENM1 holds [TARSKIK4 i1,i2 ] inHIDDENR3 [:ZFMISC-1K2 A,B :] implies [TARSKIK4 i1,i2 ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 InpFs)"
        proof(rule ballI,rule ballI,rule impI)
          fix i1 assume [ty]: "i1 be objectHIDDENM1"
          fix i2 assume [ty]: "i2 be objectHIDDENM1"
          obtain g where 
            [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = InpFs .FUNCT-1K1 [TARSKIK4 i1,i2 ] `1XTUPLE-0K1"
             sorry
          assume A6: "[TARSKIK4 i1,i2 ] inHIDDENR3 [:ZFMISC-1K2 A,B :]"
          then have A7: "[TARSKIK4 i1,i2 ] `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 InpFs"
            using A1 mcart_1_th_10 sorry
          have "g be FunctionFUNCT-2M1-of((A -->FUNCOP-1K7 B).FUNCT-1K1 [TARSKIK4 i1,i2 ] `1XTUPLE-0K1,C .FUNCT-1K1 [TARSKIK4 i1,i2 ] `1XTUPLE-0K1)"
            using A6 mcart_1_th_10 pboole_def_15 sorry
          then have "domRELAT-1K1 g =XBOOLE-0R4 (A -->FUNCOP-1K7 B).FUNCT-1K1 [TARSKIK4 i1,i2 ] `1XTUPLE-0K1"
            using A1 A7 funct_2_def_1 sorry
          then have "domRELAT-1K1 g =XBOOLE-0R4 B"
            using A6 funcop_1_th_7 mcart_1_th_10 sorry
          then have A8: "[TARSKIK4 i1,i2 ] `2XTUPLE-0K2 inHIDDENR3 domRELAT-1K1 g"
            using A6 mcart_1_th_10 sorry
          show "[TARSKIK4 i1,i2 ] inHIDDENR3 domRELAT-1K1 (uncurryFUNCT-5K2 InpFs)"
            using A7 A8 funct_5_th_38 sorry
        qed "sorry"
        thus "[:ZFMISC-1K2 A,B :] c=TARSKIR1 domRELAT-1K1 (uncurryFUNCT-5K2 InpFs)"
          using relat_1_def_3 sorry
      qed
      thus "domRELAT-1K1 (uncurryFUNCT-5K2 InpFs) =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
        using xboole_0_def_10 sorry
    qed
    then have A9: "commuteFUNCT-6K9 InpFs =FUNCT-1R1 curry'FUNCT-5K3 (uncurryFUNCT-5K2 InpFs) & ( ex g be FunctionFUNCT-1M1 st ((curry'FUNCT-5K3 (uncurryFUNCT-5K2 InpFs) .FUNCT-1K1 b =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 A) & rngFUNCT-1K2 g c=TARSKIR1 rngFUNCT-1K2 (uncurryFUNCT-5K2 InpFs)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 A implies g .FUNCT-1K1 i =XBOOLE-0R4 uncurryFUNCT-5K2 InpFs .BINOP-1K1(i,b)))"
      using funct_5_th_32 funct_6_def_10 sorry
    then obtain c where 
      [ty]:"c be ManySortedSetPBOOLEM1-of A" and cDef:"c = (commuteFUNCT-6K9 InpFs).FUNCT-1K1 b"
      using partfun1_def_2 relat_1_def_18 sorry
    show " ex tVar6 be ManySortedSetPBOOLEM1-of A st tVar6 =FUNCT-1R1 (commuteFUNCT-6K9 InpFs).FUNCT-1K1 b & tVar6 inPBOOLER3\<^bsub>(A)\<^esub> C"
    proof(rule bexI[of _ "c"],rule conjMI)
      show "c =FUNCT-1R1 (commuteFUNCT-6K9 InpFs).FUNCT-1K1 b"
         sorry
      have " for i be objectHIDDENM1 holds i inHIDDENR3 A implies c .FUNCT-1K1 i inTARSKIR2 C .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        obtain h where 
          [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = InpFs .FUNCT-1K1 i"
           sorry
        assume A10: "i inHIDDENR3 A"
        then have "(A -->FUNCOP-1K7 B).FUNCT-1K1 i =XBOOLE-0R4 B"
          using funcop_1_th_7 sorry
        then have A11: "h be FunctionFUNCT-2M1-of(B,C .FUNCT-1K1 i)"
          using A10 pboole_def_15 sorry
        then have A12: "domRELAT-1K1 h =XBOOLE-0R4 B"
          using A10 funct_2_def_1 sorry
        have "c .FUNCT-1K1 i =HIDDENR1 uncurryFUNCT-5K2 InpFs .BINOP-1K1(i,b)"
          using A9 A10 sorry
        also have "... = h .FUNCT-1K1 b"
          using A1 A10 A12 funct_5_th_38 sorry
        finally have "c .FUNCT-1K1 i =HIDDENR1 h .FUNCT-1K1 b"
           sorry
        thus "c .FUNCT-1K1 i inTARSKIR2 C .FUNCT-1K1 i"
          using A10 A11 funct_2_th_5 sorry
      qed "sorry"
      thus "c inPBOOLER3\<^bsub>(A)\<^esub> C"
        using pboole_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_8:
" for n be NatNAT-1M1 holds  for a be setHIDDENM2 holds productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a}) =XBOOLE-0R4 {TARSKIK1 n  |->FINSEQ-2K2 a }"
proof(rule ballI,rule ballI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix a assume [ty]: "a be setHIDDENM2"
  have " for i be objectHIDDENM1 holds (i inHIDDENR3 productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a}) implies i =HIDDENR1 n  |->FINSEQ-2K2 a) & (i =HIDDENR1 n  |->FINSEQ-2K2 a implies i inHIDDENR3 productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a}))"
  proof(rule ballI,rule conjMI,rule impI)
    fix i assume [ty]: "i be objectHIDDENM1"
    show "i inHIDDENR3 productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a}) implies i =HIDDENR1 n  |->FINSEQ-2K2 a"
    proof(rule impI)
      assume "i inHIDDENR3 productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a})"
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A1: "i =HIDDENR1 g"and A2: "domRELAT-1K1 g =XBOOLE-0R4 domFINSEQ-1K5 (n  |->FINSEQ-2K2 {TARSKIK1 a})"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (n  |->FINSEQ-2K2 {TARSKIK1 a}) implies g .FUNCT-1K1 x inTARSKIR2 (n  |->FINSEQ-2K2 {TARSKIK1 a}).FUNCT-1K1 x"
        using card_3_def_5 sorry
      have A4: "domRELAT-1K1 g =XBOOLE-0R4 SegFINSEQ-1K2 n"
        using A2 funcop_1_th_13 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 a"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 domRELAT-1K1 g"
        then have "g .FUNCT-1K1 x inTARSKIR2 (n  |->FINSEQ-2K2 {TARSKIK1 a}).FUNCT-1K1 x"
          using A2 A3 sorry
        then have "g .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 a}"
          using A4 A5 funcop_1_th_7 sorry
        thus "g .FUNCT-1K1 x =XBOOLE-0R4 a"
          using tarski_def_1 sorry
      qed "sorry"
      thus "i =HIDDENR1 n  |->FINSEQ-2K2 a"
        using A1 A4 funcop_1_th_11 sorry
    qed
    assume A6: "i =HIDDENR1 n  |->FINSEQ-2K2 a"
    then obtain g where 
      [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = i"
       sorry
    have A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (n  |->FINSEQ-2K2 {TARSKIK1 a}) implies g .FUNCT-1K1 x inTARSKIR2 (n  |->FINSEQ-2K2 {TARSKIK1 a}).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domFINSEQ-1K5 (n  |->FINSEQ-2K2 {TARSKIK1 a})"
      then have "x inHIDDENR3 SegFINSEQ-1K2 n"
        using funcop_1_th_13 sorry
      then have "g .FUNCT-1K1 x =XBOOLE-0R4 a & (n  |->FINSEQ-2K2 {TARSKIK1 a}).FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 a}"
        using A6 funcop_1_th_7 sorry
      thus "g .FUNCT-1K1 x inTARSKIR2 (n  |->FINSEQ-2K2 {TARSKIK1 a}).FUNCT-1K1 x"
        using tarski_def_1 sorry
    qed "sorry"
    have "domRELAT-1K1 g =HIDDENR1 SegFINSEQ-1K2 n"
      using A6 funcop_1_th_13 sorry
    also have "... = domFINSEQ-1K5 (n  |->FINSEQ-2K2 {TARSKIK1 a})"
      using funcop_1_th_13 sorry
    finally have "domRELAT-1K1 g =HIDDENR1 domFINSEQ-1K5 (n  |->FINSEQ-2K2 {TARSKIK1 a})"
       sorry
    thus "i inHIDDENR3 productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a})"
      using A7 card_3_th_9 sorry
  qed "sorry"
  thus "productCARD-3K4 (n  |->FINSEQ-2K2 {TARSKIK1 a}) =XBOOLE-0R4 {TARSKIK1 n  |->FINSEQ-2K2 a }"
    using tarski_def_1 sorry
qed "sorry"

(*begin*)
reserve T, T1 for "finiteFINSET-1V1\<bar>TreeTREES-1M1"
reserve t, p for "ElementTREES-1M2-of T"
reserve t1 for "ElementTREES-1M2-of T1"
mtheorem pre_circ_cl_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of FinTreesTREES-3K5 D holds it be finiteFINSET-1V1"
  proof-
    have " for t be ElementSUBSET-1M1-of FinTreesTREES-3K5 D holds t be finiteFINSET-1V1"
    proof(rule ballI)
      fix t assume [ty]: "t be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
      have "domRELAT-1K1 t be finiteFINSET-1V1"
         sorry
      thus "t be finiteFINSET-1V1"
        using finset_1_th_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pre_circ_cl_6:
  mlet "T be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4", "t be ElementTREES-1M2-of domRELAT-1K1 T"
"cluster T  |TREES-2K5 t as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "T  |TREES-2K5 t be finiteFINSET-1V1"
  proof-
    have "domRELAT-1K1 (T  |TREES-2K5 t) =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 t"
      using trees_2_def_10 sorry
    thus "T  |TREES-2K5 t be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mtheorem pre_circ_th_9:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds (T  |TREES-1K4 p,{t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t })are-equipotentTARSKIR3"
proof-
  have " for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds (T  |TREES-1K4 p,{t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t })are-equipotentTARSKIR3"
  proof(rule ballI,rule ballI)
    fix T assume [ty]: "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix p assume [ty]: "p be ElementTREES-1M2-of T"
    let ?X = "{t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t }"
    let ?F = "\<lambda>Lamb1. p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 T  |TREES-1K4 p"and A2: " for n be ElementTREES-1M2-of T  |TREES-1K4 p holds f .FUNCT-1K1 n =XBOOLE-0R4 ?F(n)"
      using funct_1_sch_4 sorry
    have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 T  |TREES-1K4 p & proj2XTUPLE-0K13 f =HIDDENR1 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t })"
    proof(rule conjMI,rule conjMI)
      show "f be one-to-oneFUNCT-1V2"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A3: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
            and A4: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
          obtain m n where 
            [ty]:"m be ElementTREES-1M2-of T  |TREES-1K4 p" and mDef:"m = x" and
            [ty]:"n be ElementTREES-1M2-of T  |TREES-1K4 p" and nDef:"n = y"
            using A1 A3 sorry
          have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> m =HIDDENR1 f .FUNCT-1K1 n"
            using A2 A4 sorry
          also have "... = p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
            using A2 sorry
          finally have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> m =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
             sorry
          thus "x =HIDDENR1 y"
            using finseq_1_th_33 sorry
        qed "sorry"
        thus "f be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      show "domRELAT-1K1 f =XBOOLE-0R4 T  |TREES-1K4 p"
        using A1 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t } & {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t } c=TARSKIR1 proj2XTUPLE-0K13 f"
      proof(rule conjMI)
        show "rngFUNCT-1K2 f c=TARSKIR1 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t }"
        proof-
          have "rngFUNCT-1K2 f c=TARSKIR1 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t }"
          proof-
            have " for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 f implies i inHIDDENR3 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t }"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be objectHIDDENM1"
              assume "i inHIDDENR3 rngFUNCT-1K2 f"
              then obtain n where
                [ty]:"n be objectHIDDENM1" and 
                A5: "n inHIDDENR3 domRELAT-1K1 f"and A6: "i =HIDDENR1 f .FUNCT-1K1 n"
                using funct_1_def_3 sorry
              have 
                [ty]:"n be ElementTREES-1M2-of T  |TREES-1K4 p"
                using A1 A5 sorry
              obtain t where 
                [ty]:"t be ElementTREES-1M2-of T" and tDef:"t = p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                using trees_1_def_6 sorry
              have "f .FUNCT-1K1 n =XBOOLE-0R4 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n & p is-a-prefix-ofTREES-1R2 t"
                using A2 trees_1_th_1 sorry
              thus "i inHIDDENR3 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t }"
                using A6 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t }"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have " for i be objectHIDDENM1 holds i inHIDDENR3 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t } implies i inHIDDENR3 proj2XTUPLE-0K13 f"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 ?X"
          then have A7: " ex t be ElementTREES-1M2-of T st i =HIDDENR1 t & p is-a-prefix-ofTREES-1R2 t"
             sorry
          then obtain n where
            [ty]:"n be FinSequenceFINSEQ-1M1" and 
            A8: "i =HIDDENR1 p ^FINSEQ-1K8 n"
            using trees_1_th_1 sorry
          have "n be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
            using A7 A8 finseq_1_th_36 sorry
          then have 
            [ty]:"n be ElementTREES-1M2-of T  |TREES-1K4 p"
            using A7 A8 trees_1_def_6 sorry
          have "i =HIDDENR1 f .FUNCT-1K1 n"
            using A2 A8 sorry
          thus "i inHIDDENR3 proj2XTUPLE-0K13 f"
            using A1 funct_1_def_3 sorry
        qed "sorry"
        thus "{t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t } c=TARSKIR1 proj2XTUPLE-0K13 f"
          using tarski_def_3 sorry
      qed
      thus "proj2XTUPLE-0K13 f =HIDDENR1 {t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t }"
        using xboole_0_def_10 sorry
    qed
    thus "(T  |TREES-1K4 p,{t where t be ElementTREES-1M2-of T : p is-a-prefix-ofTREES-1R2 t })are-equipotentTARSKIR3"
      using bexI[of _ "f"] wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_cl_7:
  mlet "T be finiteFINSET-1V1\<bar>DecoratedTree-likeTREES-2V3\<bar>FunctionFUNCT-1M1", "t be ElementTREES-1M2-of domRELAT-1K1 T", "T1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4"
"cluster T with-replacementTREES-2K7(t,T1) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "T with-replacementTREES-2K7(t,T1) be finiteFINSET-1V1"
  proof-
    have "domRELAT-1K1 (T with-replacementTREES-2K7(t,T1)) =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(t,domRELAT-1K1 T1)"
      using trees_2_def_11 sorry
    thus "T with-replacementTREES-2K7(t,T1) be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mtheorem pre_circ_th_10:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds T with-replacementTREES-1K5(p,T1) =XBOOLE-0R4 ({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  })"
proof-
  have " for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds T with-replacementTREES-1K5(p,T1) =HIDDENR1 ({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K8 t1 where t1 be ElementTREES-1M2-of T1 :  not  False  })"
  proof(rule ballI,rule ballI,rule ballI)
    fix T assume [ty]: "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix p assume [ty]: "p be ElementTREES-1M2-of T"
    let ?P2 = "\<lambda>Lamb1.  not  False "
    let ?P1 = "\<lambda>Lamb1. Lamb1 =XBOOLE-0R4 Lamb1"
    let ?F = "\<lambda>Lamb1. p ^FINSEQ-1K8 Lamb1"
    let ?A = "{t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
    let ?B = "{?F(t1) where t1 be ElementTREES-1M2-of T1 : ?P1(t1) }"
    let ?C = "{t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t }"
    let ?D = "{?F(t1) where t1 be ElementTREES-1M2-of T1 : ?P2(t1) }"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t } or x inHIDDENR3 {TARSKIK1 p}) & (x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t } or x inHIDDENR3 {TARSKIK1 p} implies x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t })"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t } implies x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t } or x inHIDDENR3 {TARSKIK1 p}"
      proof(rule impI)
        assume "x inHIDDENR3 ?A"
        then obtain t where
          [ty]:"t be ElementTREES-1M2-of T" and 
          A1: "x =HIDDENR1 t"and A2: " not p is-a-proper-prefix-ofTREES-1R3 t"
           sorry
        have " not p is-a-prefix-ofTREES-1R2 t or t =FINSEQ-1R1 p"
          using A2 sorry
        thus "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t } or x inHIDDENR3 {TARSKIK1 p}"
          using A1 tarski_def_1 sorry
      qed
      assume "x inHIDDENR3 ?C or x inHIDDENR3 {TARSKIK1 p}"
      then have "x =HIDDENR1 p or ( ex t be ElementTREES-1M2-of T st t =HIDDENR1 x &  not p is-a-prefix-ofTREES-1R2 t)"
        using tarski_def_1 sorry
      then obtain t where
        [ty]:"t be ElementTREES-1M2-of T" and 
        A3: "t =HIDDENR1 x"and A4: "t =FINSEQ-1R1 p or  not p is-a-prefix-ofTREES-1R2 t"
         sorry
      have " not p is-a-proper-prefix-ofTREES-1R3 t"
        using A4 sorry
      thus "x inHIDDENR3 {t where t be ElementTREES-1M2-of T :  not p is-a-proper-prefix-ofTREES-1R3 t }"
        using A3 sorry
    qed "sorry"
    then have A5: "?A =XBOOLE-0R4 ?C \\/XBOOLE-0K2 {TARSKIK1 p}"
      using xboole_0_def_3 sorry
    have "{}XBOOLE-0K1 be ElementTREES-1M2-of T1 & p ^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 p"
      using finseq_1_th_34 trees_1_th_22 sorry
    then have A6: "p inTARSKIR2 ?D"
       sorry
    have "T with-replacementTREES-1K5(p,T1) =HIDDENR1 (({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 {TARSKIK1 p})\\/XBOOLE-0K2 ({p ^FINSEQ-1K8 t1 where t1 be ElementTREES-1M2-of T1 :  not  False  })"
      using A5 trees_1_th_32 sorry
    also have "... = ({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({TARSKIK1 p} \\/XBOOLE-0K2 ({p ^FINSEQ-1K8 t1 where t1 be ElementTREES-1M2-of T1 :  not  False  }))"
      using xboole_1_th_4 sorry
    also have "... = ({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K8 t1 where t1 be ElementTREES-1M2-of T1 :  not  False  })"
      using A6 zfmisc_1_th_40 sorry
    finally show "T with-replacementTREES-1K5(p,T1) =HIDDENR1 ({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K8 t1 where t1 be ElementTREES-1M2-of T1 :  not  False  })"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_11:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds f inTARSKIR2 T with-replacementTREES-1K5(p,T1) & p is-a-prefix-ofTREES-1R2 f implies ( ex t1 be ElementTREES-1M2-of T1 st f =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1)"
proof-
  have " for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds f inTARSKIR2 T with-replacementTREES-1K5(p,T1) & p is-a-prefix-ofTREES-1R2 f implies  not ( for t1 be ElementTREES-1M2-of T1 holds  not f =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix T assume [ty]: "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix p assume [ty]: "p be ElementTREES-1M2-of T"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A1: "f inTARSKIR2 T with-replacementTREES-1K5(p,T1)"
      and A2: "p is-a-prefix-ofTREES-1R2 f"
    have A3: " not f inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t }"
    proof-
      have "f inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t } implies  False "
      proof(rule impI)
        assume "f inTARSKIR2 {t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t }"
        then have " ex t be ElementTREES-1M2-of T st f =FINSEQ-1R1 t &  not p is-a-prefix-ofTREES-1R2 t"
           sorry
        thus " False "
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "T with-replacementTREES-1K5(p,T1) =XBOOLE-0R4 ({t where t be ElementTREES-1M2-of T :  not p is-a-prefix-ofTREES-1R2 t })\\/XBOOLE-0K2 ({p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  })"
      using pre_circ_th_10 sorry
    then have "f inTARSKIR2 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
      using A1 A3 xboole_0_def_3 sorry
    thus " not ( for t1 be ElementTREES-1M2-of T1 holds  not f =FINSEQ-1R1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_12:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p implies (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>) =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
  fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
  assume "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
  then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
    using finseq_3_th_25 sorry
  then have "k <XXREAL-0R3 lenFINSEQ-1K4 p"
    using nat_1_th_13 sorry
  thus "(treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>) =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
    using trees_3_th_49 sorry
qed "sorry"

mtheorem pre_circ_th_13:
" for q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds  for k be NatNAT-1M1 holds k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q implies <*FINSEQ-1K10 k*> inTARSKIR2 treeTREES-3K11 domsFUNCT-6K1 q"
proof(rule ballI,rule ballI,rule impI)
  fix q assume [ty]: "q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  have A1: "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
    using xreal_1_th_29 sorry
  have A2: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q) & SegFINSEQ-1K2 (lenFINSEQ-1K4 (domsFUNCT-6K1 q)) =XBOOLE-0R4 domFINSEQ-1K5 (domsFUNCT-6K1 q)"
    using finseq_1_def_3 sorry
  assume A3: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
  then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
    using finseq_3_th_25 sorry
  then have "k <XXREAL-0R3 lenFINSEQ-1K4 q"
    using A1 xxreal_0_th_2 sorry
  then have A4: "k <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 q)"
    using A2 finseq_1_th_6 trees_3_th_37 sorry
  have "domFINSEQ-1K5 (domsFUNCT-6K1 q) =XBOOLE-0R4 domFINSEQ-1K5 q"
    using trees_3_th_37 sorry
  then have "domsFUNCT-6K1 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) be TreeTREES-1M1"
    using A3 trees_3_th_22 sorry
  then have A5: "{}XBOOLE-0K1 inTARSKIR2 domsFUNCT-6K1 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
    using trees_1_th_22 sorry
  have "<*FINSEQ-1K10 k*> =FINSEQ-1R1 (<*FINSEQ-1K10 k*>)^FINSEQ-1K8 {}XBOOLE-0K1"
    using finseq_1_th_34 sorry
  thus "<*FINSEQ-1K10 k*> inTARSKIR2 treeTREES-3K11 domsFUNCT-6K1 q"
    using A5 A4 trees_3_def_15 sorry
qed "sorry"

mtheorem pre_circ_th_14:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i) implies ( for t be TreeTREES-1M1 holds q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t implies treeTREES-3K11 q =TREES-2R1 (treeTREES-3K11 p)with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,t))"
proof-
  have " for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & (k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) implies ( for t be TreeTREES-1M1 holds q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t implies treeTREES-3K11 q =TREES-2R1 (treeTREES-3K11 p)with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,t))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
    fix p assume [ty]: "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
      and A2: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
      and A3: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
    fix t assume [ty]: "t be TreeTREES-1M1"
    let ?o = "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>"
    have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A2 finseq_3_th_25 sorry
    then have A4: "k <XXREAL-0R3 lenFINSEQ-1K4 p"
      using nat_1_th_13 sorry
    assume A5: "q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 t"
    have A6: " for s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (s inTARSKIR2 treeTREES-3K11 q implies s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)) & (s inTARSKIR2 treeTREES-3K11 p &  not ?o is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 ?o ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies s inTARSKIR2 treeTREES-3K11 q)"
    proof(rule ballI,rule conjMI,rule impI)
      fix s assume [ty]: "s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      show "s inTARSKIR2 treeTREES-3K11 q implies s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      proof(rule impI)
        assume A7: "s inTARSKIR2 treeTREES-3K11 q"
        show "s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
        proof-
          have cases: "s =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 q & r inTARSKIR2 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r)"
            using A7 trees_3_def_15 sorry
          have case1: "s =FINSEQ-1R1 {}XBOOLE-0K1 implies s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          proof(rule impI)
            assume "s =FINSEQ-1R1 {}XBOOLE-0K1"
            thus "s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
              using trees_1_th_22 sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 q & r inTARSKIR2 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r) implies s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          proof(rule impI)
            assume " ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 q & r inTARSKIR2 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
            then obtain n r where
              [ty]:"n be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
              A8: "n <XXREAL-0R3 lenFINSEQ-1K4 q"and A9: "r inTARSKIR2 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A10: "s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
               sorry
            have "n =XBOOLE-0R4 k & ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) or n <>HIDDENR2 k & (n <>HIDDENR2 k implies s inTARSKIR2 treeTREES-3K11 p & (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s implies  False ))"
            proof-
              show "n =XBOOLE-0R4 k & ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) or n <>HIDDENR2 k & (n <>HIDDENR2 k implies s inTARSKIR2 treeTREES-3K11 p & (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s implies  False ))"
              proof-
                have cases: "n =XBOOLE-0R4 k or n <>HIDDENR2 k"
                   sorry
                have case1: "n =XBOOLE-0R4 k implies ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
                proof(rule impI)
                  assume A11: "n =XBOOLE-0R4 k"
                  have 
                    [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                    using A10 finseq_1_th_36 sorry
                  show " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                  proof(rule bexI[of _ "r"])
                    show "r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                      using A5 A9 A10 A11 sorry
                  qed "sorry"
                qed
                have case2: "n <>HIDDENR2 k implies s inTARSKIR2 treeTREES-3K11 p & (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s implies  False )"
                proof(rule impI,rule conjMI,rule impI)
                  assume A12: "n <>HIDDENR2 k"
                  have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
                    using A1 A8 nat_1_th_11 nat_1_th_13 sorry
                  then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                    using finseq_3_th_25 sorry
                  then have "q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                    using A3 A12 xcmplx_1_th_2 sorry
                  thus "s inTARSKIR2 treeTREES-3K11 p"
                    using A1 A8 A9 A10 trees_3_def_15 sorry
                  assume "?o is-a-proper-prefix-ofTREES-1R3 s"
                  then have "?o is-a-prefix-ofTREES-1R2 s"
                     sorry
                  then have " ex s1 be FinSequenceFINSEQ-1M1 st s =FINSEQ-1R1 ?o ^FINSEQ-1K8 s1"
                    using trees_1_th_1 sorry
                  then have "k =HIDDENR1 s .FUNCT-1K1 \<one>\<^sub>M"
                    using finseq_1_th_41 sorry
                  also have "... = n"
                    using A10 finseq_1_th_41 sorry
                  finally have "k =HIDDENR1 n"
                     sorry
                  thus " False "
                    using A12 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      assume A13: "s inTARSKIR2 treeTREES-3K11 p &  not ?o is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 ?o ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      show "s inTARSKIR2 treeTREES-3K11 q"
      proof-
        have cases: "s inTARSKIR2 treeTREES-3K11 p &  not ?o is-a-proper-prefix-ofTREES-1R3 s or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 ?o ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
          using A13 sorry
        have case1: "s inTARSKIR2 treeTREES-3K11 p &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-proper-prefix-ofTREES-1R3 s implies s inTARSKIR2 treeTREES-3K11 q"
        proof(rule impMI ,rule impI)
          assume A14: "s inTARSKIR2 treeTREES-3K11 p"
            and A15: " not ?o is-a-proper-prefix-ofTREES-1R3 s"
          have "s inTARSKIR2 treeTREES-3K11 q"
          proof-
            show "s inTARSKIR2 treeTREES-3K11 q"
            proof-
              have cases: "s =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & r inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r)"
                using A14 trees_3_def_15 sorry
              have case1: "s =FINSEQ-1R1 {}XBOOLE-0K1 implies s inTARSKIR2 treeTREES-3K11 q"
              proof(rule impI)
                assume "s =FINSEQ-1R1 {}XBOOLE-0K1"
                thus "s inTARSKIR2 treeTREES-3K11 q"
                  using trees_1_th_22 sorry
              qed
              have case2: "( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & r inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r) implies s inTARSKIR2 treeTREES-3K11 q"
              proof(rule impI)
                assume " ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & r inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
                then obtain n r where
                  [ty]:"n be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
                  A16: "n <XXREAL-0R3 lenFINSEQ-1K4 p"and A17: "r inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A18: "s =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
                   sorry
                have "s inTARSKIR2 treeTREES-3K11 q"
                proof-
                  show "s inTARSKIR2 treeTREES-3K11 q"
                  proof-
                    have cases: "r =FINSEQ-1R1 {}XBOOLE-0K1 or r <>HIDDENR2 {}XBOOLE-0K1"
                       sorry
                    have case1: "r =FINSEQ-1R1 {}XBOOLE-0K1 implies s inTARSKIR2 treeTREES-3K11 q"
                    proof(rule impI)
                      assume A19: "r =FINSEQ-1R1 {}XBOOLE-0K1"
                      have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
                        using A1 A16 nat_1_th_11 nat_1_th_13 sorry
                      then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
                        using finseq_3_th_25 sorry
                      then have "q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) be TreeTREES-1M1"
                        using trees_3_th_22 sorry
                      then have "r inTARSKIR2 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                        using A19 trees_1_th_22 sorry
                      thus "s inTARSKIR2 treeTREES-3K11 q"
                        using A1 A16 A18 trees_3_def_15 sorry
                    qed
                    have case2: "r <>HIDDENR2 {}XBOOLE-0K1 implies s inTARSKIR2 treeTREES-3K11 q"
                    proof(rule impI)
                      assume "r <>HIDDENR2 {}XBOOLE-0K1"
                      then have A20: "n <>HIDDENR2 k"
                        using A15 A18 finseq_1_th_87 trees_1_th_1 sorry
                      have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
                        using A16 nat_1_th_11 nat_1_th_13 sorry
                      then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                        using finseq_3_th_25 sorry
                      then have "q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                        using A3 A20 xcmplx_1_th_2 sorry
                      thus "s inTARSKIR2 treeTREES-3K11 q"
                        using A1 A16 A17 A18 trees_3_def_15 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "s inTARSKIR2 treeTREES-3K11 q"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "s inTARSKIR2 treeTREES-3K11 q"
             sorry
        qed
        have case2: "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies s inTARSKIR2 treeTREES-3K11 q"
        proof(rule impI)
          assume " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 t & s =FINSEQ-1R1 ?o ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
          thus "s inTARSKIR2 treeTREES-3K11 q"
            using A1 A4 A5 trees_3_def_15 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    have "p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) be TreeTREES-1M1"
      using A2 trees_3_th_22 sorry
    then have A21: "{}XBOOLE-0K1 inTARSKIR2 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
      using trees_1_th_22 sorry
    have "?o =FINSEQ-1R1 ?o ^FINSEQ-1K8 {}XBOOLE-0K1"
      using finseq_1_th_34 sorry
    then have "?o inTARSKIR2 treeTREES-3K11 p"
      using A4 A21 trees_3_def_15 sorry
    thus "treeTREES-3K11 q =TREES-2R1 (treeTREES-3K11 p)with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,t)"
      using A6 trees_1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_15:
" for e1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for e2 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> inTARSKIR2 domRELAT-1K1 e1 & e1 =TREES-4R1 x -treeTREES-4K4 p implies ( ex q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st ((e1 with-replacementTREES-2K7(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,e2) =TREES-4R1 x -treeTREES-4K4 q & lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p) & q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 e2) & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p & i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies q .FUNCT-1K1 i =FUNCT-1R1 p .FUNCT-1K1 i))"
proof-
  have " for e1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for e2 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for x be setHIDDENM2 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> inTARSKIR2 domRELAT-1K1 e1 & e1 =TREES-4R1 x -treeTREES-4K4 p implies ( ex tVar9 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st e1 with-replacementTREES-2K7(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,e2) =TREES-4R1 x -treeTREES-4K4 tVar9 & (lenFINSEQ-1K4 tVar9 =XBOOLE-0R4 lenFINSEQ-1K4 p & (tVar9 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 e2 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies  not ( not i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M &  not tVar9 .FUNCT-1K1 i =FUNCT-1R1 p .FUNCT-1K1 i)))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix e1 assume [ty]: "e1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4"
    fix e2 assume [ty]: "e2 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4"
    fix x assume [ty]: "x be setHIDDENM2"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix p assume [ty]: "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> inTARSKIR2 domRELAT-1K1 e1"
      and A2: "e1 =TREES-4R1 x -treeTREES-4K4 p"
    obtain j T w where
      [ty]:"j be NatNAT-1M1" "T be DecoratedTreeTREES-2M4" "w be NodeTREES-4M1-of T" and 
      A3: "j <XXREAL-0R3 lenFINSEQ-1K4 p"and "T =FUNCT-1R1 p .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)"and A4: "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> =FINSEQ-1R1 (<*FINSEQ-1K10 j*>)^FINSEQ-1K8 w"
      using A1 A2 trees_4_th_11 sorry
    obtain pp where
      [ty]:"pp be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1" and 
      A5: "p =FINSEQ-1R1 pp"and A6: "domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 pp"
      using trees_4_def_4 sorry
    have A7: "domFINSEQ-1K5 (domsFUNCT-6K1 pp) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using A5 trees_3_th_37 sorry
    let ?F = "\<lambda>Lamb1. IFEQFUNCOP-1K15(Lamb1,k +NAT-1K1 \<one>\<^sub>M,e2,p .FUNCT-1K1 Lamb1)"
    let ?o = "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>"
    obtain q where
      [ty]:"q be FinSequenceFINSEQ-1M1" and 
      A8: "lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p"and A9: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 i =XBOOLE-0R4 ?F(i)"
      using finseq_1_sch_2 sorry
    have A10: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using A8 finseq_1_def_3 sorry
    have A11: "domFINSEQ-1K5 q =XBOOLE-0R4 domFINSEQ-1K5 p"
      using A8 finseq_3_th_29 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 q implies q .FUNCT-1K1 x be DecoratedTreeTREES-2M4"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A12: "x inHIDDENR3 domFINSEQ-1K5 q"
      then obtain i where 
        [ty]:"i be NatNAT-1M1" and iDef:"i = x"
         sorry
      have A13: "i =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M or i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
         sorry
      have "q .FUNCT-1K1 i =XBOOLE-0R4 IFEQFUNCOP-1K15(i,k +NAT-1K1 \<one>\<^sub>M,e2,p .FUNCT-1K1 i)"
        using A9 A12 sorry
      then have "q .FUNCT-1K1 i =XBOOLE-0R4 e2 or q .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
        using A13 funcop_1_def_8 sorry
      thus "q .FUNCT-1K1 x be DecoratedTreeTREES-2M4"
        using A11 A12 trees_3_th_24 sorry
    qed "sorry"
    then have 
      [ty]:"q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
      using trees_3_th_24 sorry
    obtain qq where
      [ty]:"qq be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1" and 
      A14: "q =FINSEQ-1R1 qq"and A15: "domRELAT-1K1 (x -treeTREES-4K4 q) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 qq"
      using trees_4_def_4 sorry
    have A16: "lenFINSEQ-1K4 (domsFUNCT-6K1 pp) =HIDDENR1 lenFINSEQ-1K4 p"
      using A5 trees_3_th_38 sorry
    also have "... = lenFINSEQ-1K4 (domsFUNCT-6K1 qq)"
      using A8 A14 trees_3_th_38 sorry
    finally have "lenFINSEQ-1K4 (domsFUNCT-6K1 pp) =HIDDENR1 lenFINSEQ-1K4 (domsFUNCT-6K1 qq)"
       sorry
    have A17: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    have A18: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (domsFUNCT-6K1 pp) & i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M implies domsFUNCT-6K1 pp .FUNCT-1K1 i =HIDDENR1 domsFUNCT-6K1 qq .FUNCT-1K1 i"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A19: "i inTARSKIR2 domFINSEQ-1K5 (domsFUNCT-6K1 pp)"
        and A20: "i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
      have A21: "q .FUNCT-1K1 i =HIDDENR1 IFEQFUNCOP-1K15(i,k +NAT-1K1 \<one>\<^sub>M,e2,p .FUNCT-1K1 i)"
        using A9 A10 A17 A7 A19 sorry
      also have "... = p .FUNCT-1K1 i"
        using A20 funcop_1_def_8 sorry
      finally have "q .FUNCT-1K1 i =HIDDENR1 p .FUNCT-1K1 i"
         sorry
      obtain pii where 
        [ty]:"pii be DecoratedTreeTREES-2M4" and piiDef:"pii = p .FUNCT-1K1 i"
        using A7 A19 trees_3_th_24 sorry
      have "domsFUNCT-6K1 pp .FUNCT-1K1 i =HIDDENR1 domRELAT-1K1 pii"
        using A5 A7 A19 funct_6_th_22 sorry
      also have "... = domsFUNCT-6K1 qq .FUNCT-1K1 i"
        using A11 A14 A7 A19 A21 funct_6_th_22 sorry
      finally show "domsFUNCT-6K1 pp .FUNCT-1K1 i =HIDDENR1 domsFUNCT-6K1 qq .FUNCT-1K1 i"
         sorry
    qed "sorry"
    obtain dqq where 
      [ty]:"dqq be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1" and dqqDef:"dqq = domsFUNCT-6K1 qq"
       sorry
    show " ex tVar9 be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st e1 with-replacementTREES-2K7(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,e2) =TREES-4R1 x -treeTREES-4K4 tVar9 & (lenFINSEQ-1K4 tVar9 =XBOOLE-0R4 lenFINSEQ-1K4 p & (tVar9 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 e2 & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies  not ( not i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M &  not tVar9 .FUNCT-1K1 i =FUNCT-1R1 p .FUNCT-1K1 i))))"
    proof(rule bexI[of _ "q"],rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impI)
      have "<*FINSEQ-1K10 j*> =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>"
        using A4 finseq_1_th_88 sorry
      then have A22: "j =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>).FUNCT-1K1 \<one>\<^sub>M"
        using finseq_1_def_8 sorry
      also have "... = k"
        using finseq_1_def_8 sorry
      finally have "j =HIDDENR1 k"
         sorry
      then have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M & k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
        using A3 nat_1_th_11 nat_1_th_13 sorry
      then have A23: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
        using finseq_3_th_25 sorry
      then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        using finseq_1_def_3 sorry
      then have A24: "q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 IFEQFUNCOP-1K15(k +NAT-1K1 \<one>\<^sub>M,k +NAT-1K1 \<one>\<^sub>M,e2,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
        using A9 A10 sorry
      also have "... = e2"
        using funcop_1_def_8 sorry
      finally have "q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 e2"
         sorry
      then have "domsFUNCT-6K1 qq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 domRELAT-1K1 e2"
        using A11 A23 A14 funct_6_th_22 sorry
      then have A25: "domRELAT-1K1 (x -treeTREES-4K4 q) =TREES-2R1 domRELAT-1K1 e1 with-replacementTREES-1K5(?o,domRELAT-1K1 e2)"
        using A2 A23 A15 A6 A16 A7 A18 pre_circ_th_14 sorry
      have " for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds f inTARSKIR2 domRELAT-1K1 e1 with-replacementTREES-1K5(?o,domRELAT-1K1 e2) implies  not ?o is-a-prefix-ofTREES-1R2 f & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e1 .FUNCT-1K1 f or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 e2 & f =FINSEQ-1R1 ?o ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 r)"
      proof-
        have " for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds f inTARSKIR2 domRELAT-1K1 e1 with-replacementTREES-1K5(?o,domRELAT-1K1 e2) implies (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-prefix-ofTREES-1R2 f or (x -treeTREES-4K4 q).FUNCT-1K1 f <>HIDDENR2 e1 .FUNCT-1K1 f implies  not ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((r inTARSKIR2 domRELAT-1K1 e2 & f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 r)))"
        proof(rule ballI,rule impI)
          obtain o9 where 
            [ty]:"o9 be ElementTREES-1M2-of domRELAT-1K1 e1" and o9Def:"o9 = ?o"
            using A1 sorry
          fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          assume A26: "f inTARSKIR2 domRELAT-1K1 e1 with-replacementTREES-1K5(?o,domRELAT-1K1 e2)"
          show "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-prefix-ofTREES-1R2 f or (x -treeTREES-4K4 q).FUNCT-1K1 f <>HIDDENR2 e1 .FUNCT-1K1 f implies  not ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((r inTARSKIR2 domRELAT-1K1 e2 & f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 r))"
          proof-
            have cases: " not o9 is-a-prefix-ofTREES-1R2 f or ( ex t1 be ElementTREES-1M2-of domRELAT-1K1 e2 st f =FINSEQ-1R1 o9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1)"
              using A26 pre_circ_th_11 sorry
            have case1: " not o9 is-a-prefix-ofTREES-1R2 f implies (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-prefix-ofTREES-1R2 f or (x -treeTREES-4K4 q).FUNCT-1K1 f <>HIDDENR2 e1 .FUNCT-1K1 f implies  not ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((r inTARSKIR2 domRELAT-1K1 e2 & f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 r)))"
            proof(rule impI,rule impI)
              assume A27: " not o9 is-a-prefix-ofTREES-1R2 f"
              have A28: "(x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e1 .FUNCT-1K1 f"
              proof-
                have "(x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 e1 .FUNCT-1K1 f"
                proof-
                  show "(x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 e1 .FUNCT-1K1 f"
                  proof-
                    have cases: "f =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex w be NatNAT-1M1 st  ex u be FinSequenceFINSEQ-1M1 st (w <XXREAL-0R3 lenFINSEQ-1K4 dqq & u inTARSKIR2 dqq .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)) & f =FINSEQ-1R1 (<*FINSEQ-1K10 w*>)^FINSEQ-1K8 u)"
                      using A15 A25 A26 trees_3_def_15 sorry
                    have case1: "f =FINSEQ-1R1 {}XBOOLE-0K1 implies (x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 e1 .FUNCT-1K1 f"
                    proof(rule impI)
                      assume A29: "f =FINSEQ-1R1 {}XBOOLE-0K1"
                      then have "(x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 x"
                        using trees_4_def_4 sorry
                      also have "... = e1 .FUNCT-1K1 f"
                        using A2 A29 trees_4_def_4 sorry
                      finally show "(x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 e1 .FUNCT-1K1 f"
                         sorry
                    qed
                    have case2: "( ex w be NatNAT-1M1 st  ex u be FinSequenceFINSEQ-1M1 st (w <XXREAL-0R3 lenFINSEQ-1K4 dqq & u inTARSKIR2 dqq .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)) & f =FINSEQ-1R1 (<*FINSEQ-1K10 w*>)^FINSEQ-1K8 u) implies (x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 e1 .FUNCT-1K1 f"
                    proof(rule impI)
                      assume " ex w be NatNAT-1M1 st  ex u be FinSequenceFINSEQ-1M1 st (w <XXREAL-0R3 lenFINSEQ-1K4 dqq & u inTARSKIR2 dqq .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)) & f =FINSEQ-1R1 (<*FINSEQ-1K10 w*>)^FINSEQ-1K8 u"
                      then obtain w u where
                        [ty]:"w be NatNAT-1M1" "u be FinSequenceFINSEQ-1M1" and 
                        A30: "w <XXREAL-0R3 lenFINSEQ-1K4 (domsFUNCT-6K1 q)"and A31: "u inTARSKIR2 domsFUNCT-6K1 q .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"and A32: "f =FINSEQ-1R1 (<*FINSEQ-1K10 w*>)^FINSEQ-1K8 u"
                        using A14 sorry
                      have 
                        [ty]:"u be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                        using A32 finseq_1_th_36 sorry
                      have 
                        [ty]:"w be ElementSUBSET-1M1-of NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      obtain ww where 
                        [ty]:"ww be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and wwDef:"ww = <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> w*>"
                         sorry
                      have A33: "w +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M"
                        using A27 A32 trees_1_th_1 sorry
                      have A34: " ex pp be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 st p =FINSEQ-1R1 pp & domRELAT-1K1 (x -treeTREES-4K4 p) =TREES-2R1 treeTREES-3K11 domsFUNCT-6K1 pp"
                        using trees_4_def_4 sorry
                      have A35: "w <XXREAL-0R3 lenFINSEQ-1K4 q"
                        using A30 trees_3_th_38 sorry
                      then have A36: "(x -treeTREES-4K4 q) |TREES-2K5 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> w*>) =FUNCT-1R1 q .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                        using trees_4_def_4 sorry
                      have "\<one>\<^sub>M <=XXREAL-0R1 w +NAT-1K1 \<one>\<^sub>M & w +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
                        using A8 A35 nat_1_th_11 nat_1_th_13 sorry
                      then have A37: "w +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
                        using finseq_3_th_25 sorry
                      then obtain pw1 where 
                        [ty]:"pw1 be DecoratedTreeTREES-2M4" and pw1Def:"pw1 = p .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                        using trees_3_th_24 sorry
                      have A38: "q .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 IFEQFUNCOP-1K15(w +NAT-1K1 \<one>\<^sub>M,k +NAT-1K1 \<one>\<^sub>M,e2,p .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M))"
                        using A9 A10 A17 A37 sorry
                      also have "... = p .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                        using A33 funcop_1_def_8 sorry
                      finally have "q .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                         sorry
                      have "w +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (domsFUNCT-6K1 p)"
                        using A37 trees_3_th_37 sorry
                      then have A39: "domRELAT-1K1 (x -treeTREES-4K4 p)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> w*>) =HIDDENR1 domsFUNCT-6K1 p .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                        using A34 pre_circ_th_12 sorry
                      also have "... = domRELAT-1K1 pw1"
                        using A37 funct_6_th_22 sorry
                      also have "... = domsFUNCT-6K1 q .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                        using A11 A37 A38 funct_6_th_22 sorry
                      finally have "domRELAT-1K1 (x -treeTREES-4K4 p)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> w*>) =HIDDENR1 domsFUNCT-6K1 q .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                         sorry
                      have "w +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (domsFUNCT-6K1 q)"
                        using A11 A37 trees_3_th_37 sorry
                      then have "domRELAT-1K1 (x -treeTREES-4K4 q)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> w*>) =XBOOLE-0R4 domsFUNCT-6K1 q .FUNCT-1K1 (w +NAT-1K1 \<one>\<^sub>M)"
                        using A14 A15 pre_circ_th_12 sorry
                      then have "(x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 ((x -treeTREES-4K4 q) |TREES-2K5 ww).FUNCT-1K1 u"
                        using A31 A32 trees_2_def_10 sorry
                      also have "... = ((x -treeTREES-4K4 p) |TREES-2K5 ww).FUNCT-1K1 u"
                        using A8 A35 A36 A38 trees_4_def_4 sorry
                      also have "... = e1 .FUNCT-1K1 f"
                        using A2 A31 A32 A39 trees_2_def_10 sorry
                      finally show "(x -treeTREES-4K4 q).FUNCT-1K1 f =HIDDENR1 e1 .FUNCT-1K1 f"
                         sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " ?thesis "
                   sorry
              qed
              assume "?o is-a-prefix-ofTREES-1R2 f or (x -treeTREES-4K4 q).FUNCT-1K1 f <>HIDDENR2 e1 .FUNCT-1K1 f"
              thus " not ( for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not ((r inTARSKIR2 domRELAT-1K1 e2 & f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 r))"
                using A27 A28 sorry
            qed
            have case2: "( ex t1 be ElementTREES-1M2-of domRELAT-1K1 e2 st f =FINSEQ-1R1 o9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1) implies (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*> is-a-prefix-ofTREES-1R2 f or (x -treeTREES-4K4 q).FUNCT-1K1 f <>HIDDENR2 e1 .FUNCT-1K1 f implies ( ex tVar10 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st tVar10 inTARSKIR2 domRELAT-1K1 e2 & (f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> tVar10 & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 tVar10)))"
            proof(rule impI,rule impI)
              assume " ex t1 be ElementTREES-1M2-of domRELAT-1K1 e2 st f =FINSEQ-1R1 o9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1"
              then obtain r where
                [ty]:"r be ElementTREES-1M2-of domRELAT-1K1 e2" and 
                A40: "f =FINSEQ-1R1 ?o ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                 sorry
              assume "?o is-a-prefix-ofTREES-1R2 f or (x -treeTREES-4K4 q).FUNCT-1K1 f <>HIDDENR2 e1 .FUNCT-1K1 f"
              have A41: "(x -treeTREES-4K4 q) |TREES-2K5 ?o =FUNCT-1R1 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                using A8 A3 A22 trees_4_def_4 sorry
              have 
                [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                 sorry
              show " ex tVar10 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st tVar10 inTARSKIR2 domRELAT-1K1 e2 & (f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> tVar10 & (x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 tVar10)"
              proof(rule bexI[of _ "r"],rule conjMI,rule conjMI)
                show A42: "r inTARSKIR2 domRELAT-1K1 e2"
                   sorry
                show "f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
                  using A40 sorry
                have "r inTARSKIR2 domRELAT-1K1 (x -treeTREES-4K4 q)  |TREES-1K4 ?o"
                  using A1 A25 A42 trees_1_th_33 sorry
                thus "(x -treeTREES-4K4 q).FUNCT-1K1 f =XBOOLE-0R4 e2 .FUNCT-1K1 r"
                  using A24 A40 A41 trees_2_def_10 sorry
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "e1 with-replacementTREES-2K7(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>,e2) =TREES-4R1 x -treeTREES-4K4 q"
        using A1 A25 trees_2_def_11 sorry
      show "lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 p"
        using A8 sorry
      show "q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 e2"
        using A24 sorry
      fix i assume [ty]: "i be NatNAT-1M1"
      assume "i inTARSKIR2 domFINSEQ-1K5 p"
      then have "q .FUNCT-1K1 i =XBOOLE-0R4 IFEQFUNCOP-1K15(i,k +NAT-1K1 \<one>\<^sub>M,e2,p .FUNCT-1K1 i)"
        using A9 A10 A17 sorry
      thus " not ( not i <>HIDDENR2 k +NAT-1K1 \<one>\<^sub>M &  not q .FUNCT-1K1 i =FUNCT-1R1 p .FUNCT-1K1 i)"
        using funcop_1_def_8 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_16:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds p <>HIDDENR2 {}XBOOLE-0K1 implies cardCARD-1K4 (T  |TREES-1K4 p) <XXREAL-0R3 cardCARD-1K4 T"
proof-
  have " for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds p <>HIDDENR2 {}XBOOLE-0K1 implies  not cardCARD-1K4 (T  |TREES-1K4 p) <XXREAL-0R3 cardCARD-1K4 T"
  proof(rule ballI,rule ballI,rule impI)
    fix T assume [ty]: "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix p assume [ty]: "p be ElementTREES-1M2-of T"
    obtain p9 where 
      [ty]:"p9 be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3" and p9Def:"p9 = p"
      using finseq_1_def_11 sorry
    let ?X = "{p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p }"
    have A1: "(T  |TREES-1K4 p,?X)are-equipotentTARSKIR3"
    proof-
      have "(T  |TREES-1K4 p,{p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p })are-equipotentTARSKIR3"
      proof-
        let ?F = "\<lambda>Lamb1. p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A2: "domRELAT-1K1 f =XBOOLE-0R4 T  |TREES-1K4 p"and A3: " for n be ElementTREES-1M2-of T  |TREES-1K4 p holds f .FUNCT-1K1 n =XBOOLE-0R4 ?F(n)"
          using funct_1_sch_4 sorry
        have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 T  |TREES-1K4 p & proj2XTUPLE-0K13 f =HIDDENR1 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p })"
        proof(rule conjMI,rule conjMI)
          show "f be one-to-oneFUNCT-1V2"
          proof-
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A4: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
                and A5: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
              obtain m n where 
                [ty]:"m be ElementTREES-1M2-of T  |TREES-1K4 p" and mDef:"m = x" and
                [ty]:"n be ElementTREES-1M2-of T  |TREES-1K4 p" and nDef:"n = y"
                using A2 A4 sorry
              have "p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> m =HIDDENR1 f .FUNCT-1K1 n"
                using A3 A5 sorry
              also have "... = p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                using A3 sorry
              finally have "p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> m =HIDDENR1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                 sorry
              thus "x =HIDDENR1 y"
                using finseq_1_th_33 sorry
            qed "sorry"
            thus "f be one-to-oneFUNCT-1V2"
              using funct_1_def_4 sorry
          qed
          show "domRELAT-1K1 f =XBOOLE-0R4 T  |TREES-1K4 p"
            using A2 sorry
          have "rngFUNCT-1K2 f c=TARSKIR1 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p } & {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p } c=TARSKIR1 proj2XTUPLE-0K13 f"
          proof(rule conjMI)
            show "rngFUNCT-1K2 f c=TARSKIR1 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p }"
            proof-
              have " for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 f implies i inHIDDENR3 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p }"
              proof(rule ballI,rule impI)
                fix i assume [ty]: "i be objectHIDDENM1"
                assume "i inHIDDENR3 rngFUNCT-1K2 f"
                then obtain n where
                  [ty]:"n be objectHIDDENM1" and 
                  A6: "n inHIDDENR3 domRELAT-1K1 f"and A7: "i =HIDDENR1 f .FUNCT-1K1 n"
                  using funct_1_def_3 sorry
                have "T  |TREES-1K4 p c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                  using trees_1_def_3 sorry
                then have 
                  [ty]:"n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3"
                  using A2 A6 sorry
                have "f .FUNCT-1K1 n =XBOOLE-0R4 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                  using A2 A3 A6 sorry
                thus "i inHIDDENR3 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p }"
                  using A2 A6 A7 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 f c=TARSKIR1 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p }"
                using tarski_def_3 sorry
            qed
            have " for i be objectHIDDENM1 holds i inHIDDENR3 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p } implies i inHIDDENR3 proj2XTUPLE-0K13 f"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be objectHIDDENM1"
              assume "i inHIDDENR3 ?X"
              then obtain n where
                [ty]:"n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3" and 
                A8: "i =HIDDENR1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"and A9: "n inTARSKIR2 T  |TREES-1K4 p"
                 sorry
              have 
                [ty]:"n be ElementTREES-1M2-of T  |TREES-1K4 p"
                using A9 sorry
              have "i =HIDDENR1 f .FUNCT-1K1 n"
                using A3 A8 sorry
              thus "i inHIDDENR3 proj2XTUPLE-0K13 f"
                using A2 funct_1_def_3 sorry
            qed "sorry"
            thus "{p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p } c=TARSKIR1 proj2XTUPLE-0K13 f"
              using tarski_def_3 sorry
          qed
          thus "proj2XTUPLE-0K13 f =HIDDENR1 {p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p }"
            using xboole_0_def_10 sorry
        qed
        thus "(T  |TREES-1K4 p,{p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n where n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 : n inTARSKIR2 T  |TREES-1K4 p })are-equipotentTARSKIR3"
          using bexI[of _ "f"] wellord2_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain X where 
      [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = ?X"
      using card_1_th_38 sorry
    have A10: "cardCARD-1K4 X =XBOOLE-0R4 cardCARD-1K4 (T  |TREES-1K4 p)"
      using A1 card_1_th_5 sorry
    assume A11: "p <>HIDDENR2 {}XBOOLE-0K1"
    have A12: "X <>HIDDENR2 T"
    proof-
      have "X =XBOOLE-0R4 T implies  False "
      proof(rule impI)
        assume "X =XBOOLE-0R4 T"
        then have "{}XBOOLE-0K1 inTARSKIR2 X"
          using trees_1_th_22 sorry
        then have " ex n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 st {}XBOOLE-0K1 =FINSEQ-1R1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n & n inTARSKIR2 T  |TREES-1K4 p"
           sorry
        thus " False "
          using A11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "X c=TARSKIR1 T"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 X implies i inHIDDENR3 T"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 X"
        then have " ex n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3 st i =HIDDENR1 p9 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n & n inTARSKIR2 T  |TREES-1K4 p"
           sorry
        thus "i inHIDDENR3 T"
          using trees_1_def_6 sorry
      qed "sorry"
      thus "X c=TARSKIR1 T"
        using tarski_def_3 sorry
    qed
    then have "X c<XBOOLE-0R2 T"
      using A12 sorry
    thus " not cardCARD-1K4 (T  |TREES-1K4 p) <XXREAL-0R3 cardCARD-1K4 T"
      using A10 card_2_th_48 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_17:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds cardCARD-1K4 (T with-replacementTREES-1K5(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-1K4 p) =XBOOLE-0R4 cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
proof-
  have " for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T holds cardCARD-1K4 (T with-replacementTREES-1K5(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-1K4 p) =HIDDENR1 cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
  proof(rule ballI,rule ballI,rule ballI)
    fix T assume [ty]: "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix T1 assume [ty]: "T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    fix p assume [ty]: "p be ElementTREES-1M2-of T"
    let ?P1 = "\<lambda>Lamb1.  not p is-a-prefix-ofTREES-1R2 Lamb1"
    let ?P2 = "\<lambda>Lamb1. p is-a-prefix-ofTREES-1R2 Lamb1"
    let ?A = "{t where t be ElementTREES-1M2-of T : ?P1(t) }"
    let ?B = "{t where t be ElementTREES-1M2-of T : ?P2(t) }"
    let ?C = "{p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
    have A1: "?A be SubsetSUBSET-1M2-of T"
      using domain_1_sch_7 sorry
    have A2: "?B be SubsetSUBSET-1M2-of T"
      using domain_1_sch_7 sorry
    have A3: "(T1,?C)are-equipotentTARSKIR3"
    proof-
      have "(T1,{p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  })are-equipotentTARSKIR3"
      proof-
        let ?F = "\<lambda>Lamb1. p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A4: "domRELAT-1K1 f =XBOOLE-0R4 T1"and A5: " for n be ElementTREES-1M2-of T1 holds f .FUNCT-1K1 n =XBOOLE-0R4 ?F(n)"
          using funct_1_sch_4 sorry
        have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 T1 & proj2XTUPLE-0K13 f =HIDDENR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  })"
        proof(rule conjMI,rule conjMI)
          show "f be one-to-oneFUNCT-1V2"
          proof-
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A6: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
                and A7: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
              obtain m n where 
                [ty]:"m be ElementTREES-1M2-of T1" and mDef:"m = x" and
                [ty]:"n be ElementTREES-1M2-of T1" and nDef:"n = y"
                using A4 A6 sorry
              have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> m =HIDDENR1 f .FUNCT-1K1 n"
                using A5 A7 sorry
              also have "... = p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                using A5 sorry
              finally have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> m =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                 sorry
              thus "x =HIDDENR1 y"
                using finseq_1_th_33 sorry
            qed "sorry"
            thus "f be one-to-oneFUNCT-1V2"
              using funct_1_def_4 sorry
          qed
          show "domRELAT-1K1 f =XBOOLE-0R4 T1"
            using A4 sorry
          have "rngFUNCT-1K2 f c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  } & {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  } c=TARSKIR1 proj2XTUPLE-0K13 f"
          proof(rule conjMI)
            show "rngFUNCT-1K2 f c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
            proof-
              have "rngFUNCT-1K2 f c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
              proof-
                have " for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 f implies i inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
                proof(rule ballI,rule impI)
                  fix i assume [ty]: "i be objectHIDDENM1"
                  assume "i inHIDDENR3 rngFUNCT-1K2 f"
                  then obtain n where
                    [ty]:"n be objectHIDDENM1" and 
                    A8: "n inHIDDENR3 domRELAT-1K1 f"and A9: "i =HIDDENR1 f .FUNCT-1K1 n"
                    using funct_1_def_3 sorry
                  have "T1 c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                    using trees_1_def_3 sorry
                  then have 
                    [ty]:"n be ElementFINSEQ-2M2\<^bsub>(NATNUMBERSK1)\<^esub>-of NATNUMBERSK1 * FINSEQ-2K3"
                    using A4 A8 sorry
                  have "f .FUNCT-1K1 n =XBOOLE-0R4 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                    using A4 A5 A8 sorry
                  thus "i inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
                    using A4 A8 A9 sorry
                qed "sorry"
                thus "rngFUNCT-1K2 f c=TARSKIR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have " for i be objectHIDDENM1 holds i inHIDDENR3 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  } implies i inHIDDENR3 proj2XTUPLE-0K13 f"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be objectHIDDENM1"
              assume "i inHIDDENR3 ?C"
              then obtain n where
                [ty]:"n be ElementTREES-1M2-of T1" and 
                A10: "i =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> n"
                 sorry
              have "i =HIDDENR1 f .FUNCT-1K1 n"
                using A5 A10 sorry
              thus "i inHIDDENR3 proj2XTUPLE-0K13 f"
                using A4 funct_1_def_3 sorry
            qed "sorry"
            thus "{p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  } c=TARSKIR1 proj2XTUPLE-0K13 f"
              using tarski_def_3 sorry
          qed
          thus "proj2XTUPLE-0K13 f =HIDDENR1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
            using xboole_0_def_10 sorry
        qed
        thus "(T1,{p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  })are-equipotentTARSKIR3"
          using bexI[of _ "f"] wellord2_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    obtain A B where 
      [ty]:"A be finiteFINSET-1V1\<bar>setHIDDENM2" and ADef:"A = ?A" and
      [ty]:"B be finiteFINSET-1V1\<bar>setHIDDENM2" and BDef:"B = ?B"
      using A1 A2 sorry
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 T implies x inHIDDENR3 A or x inHIDDENR3 B) & (x inHIDDENR3 A or x inHIDDENR3 B implies x inHIDDENR3 T)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 T implies x inHIDDENR3 A or x inHIDDENR3 B"
      proof(rule impI)
        assume "x inHIDDENR3 T"
        then obtain t where 
          [ty]:"t be ElementTREES-1M2-of T" and tDef:"t = x"
           sorry
        have "p is-a-prefix-ofTREES-1R2 t or  not p is-a-prefix-ofTREES-1R2 t"
           sorry
        thus "x inHIDDENR3 A or x inHIDDENR3 B"
           sorry
      qed
      assume "x inHIDDENR3 A or x inHIDDENR3 B"
      thus "x inHIDDENR3 T"
        using A1 A2 sorry
    qed "sorry"
    then have A11: "T =XBOOLE-0R4 A \\/XBOOLE-0K2 B"
      using xboole_0_def_3 sorry
    have A12: "A missesXBOOLE-0R1 ?C"
    proof-
      have " not A missesXBOOLE-0R1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  } implies  False "
      proof(rule impI)
        assume " not A missesXBOOLE-0R1 {p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1 where t1 be ElementTREES-1M2-of T1 :  True  }"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A13: "x inHIDDENR3 A /\\XBOOLE-0K3 ?C"
          using xboole_0_th_4 sorry
        have "x inHIDDENR3 ?C"
          using A13 xboole_0_def_4 sorry
        then have A14: " ex t1 be ElementTREES-1M2-of T1 st x =HIDDENR1 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1"
           sorry
        have "x inHIDDENR3 A"
          using A13 xboole_0_def_4 sorry
        then have " ex t be ElementTREES-1M2-of T st x =HIDDENR1 t &  not p is-a-prefix-ofTREES-1R2 t"
           sorry
        thus " False "
          using A14 trees_1_th_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A15: "A missesXBOOLE-0R1 B"
    proof-
      have " not A missesXBOOLE-0R1 B implies  False "
      proof(rule impI)
        assume " not A missesXBOOLE-0R1 B"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A16: "x inHIDDENR3 A /\\XBOOLE-0K3 B"
          using xboole_0_th_4 sorry
        have "x inHIDDENR3 B"
          using A16 xboole_0_def_4 sorry
        then have A17: " ex t be ElementTREES-1M2-of T st x =HIDDENR1 t & p is-a-prefix-ofTREES-1R2 t"
           sorry
        have "x inHIDDENR3 A"
          using A16 xboole_0_def_4 sorry
        then have " ex t be ElementTREES-1M2-of T st x =HIDDENR1 t &  not p is-a-prefix-ofTREES-1R2 t"
           sorry
        thus " False "
          using A17 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A18: "T with-replacementTREES-1K5(p,T1) =XBOOLE-0R4 A \\/XBOOLE-0K2 ?C"
      using pre_circ_th_10 sorry
    obtain C where 
      [ty]:"C be finiteFINSET-1V1\<bar>setHIDDENM2" and CDef:"C = ?C"
      using A3 card_1_th_38 sorry
    have A19: "cardCARD-1K4 T1 =XBOOLE-0R4 cardCARD-1K4 C"
      using A3 card_1_th_5 sorry
    have "(T  |TREES-1K4 p,B)are-equipotentTARSKIR3"
      using pre_circ_th_9 sorry
    then have "cardCARD-1K4 (T  |TREES-1K4 p) =XBOOLE-0R4 cardCARD-1K4 B"
      using card_1_th_5 sorry
    then have "cardCARD-1K4 (T with-replacementTREES-1K5(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-1K4 p) =HIDDENR1 (cardCARD-1K4 A +NAT-1K1 cardCARD-1K4 C)+NAT-1K1 cardCARD-1K4 B"
      using A18 A12 card_2_th_40 sorry
    also have "... = (cardCARD-1K4 A +NAT-1K1 cardCARD-1K4 B)+NAT-1K1 cardCARD-1K4 C"
       sorry
    also have "... = cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
      using A11 A15 A19 card_2_th_40 sorry
    finally show "cardCARD-1K4 (T with-replacementTREES-1K5(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-1K4 p) =HIDDENR1 cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_18:
" for T be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for T1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds cardCARD-1K4 (T with-replacementTREES-2K7(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-2K5 p) =XBOOLE-0R4 cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
proof(rule ballI,rule ballI,rule ballI)
  fix T assume [ty]: "T be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4"
  fix T1 assume [ty]: "T1 be finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M4"
  fix p assume [ty]: "p be ElementTREES-1M2-of domRELAT-1K1 T"
  have A1: "cardCARD-1K4 (domRELAT-1K1 T) =XBOOLE-0R4 cardCARD-1K4 T & cardCARD-1K4 (domRELAT-1K1 T1) =XBOOLE-0R4 cardCARD-1K4 T1"
    using card_1_th_62 sorry
  have A2: "cardCARD-1K4 (domRELAT-1K1 (T with-replacementTREES-2K7(p,T1))) =XBOOLE-0R4 cardCARD-1K4 (T with-replacementTREES-2K7(p,T1)) & cardCARD-1K4 (domRELAT-1K1 (T  |TREES-2K5 p)) =XBOOLE-0R4 cardCARD-1K4 (T  |TREES-2K5 p)"
    using card_1_th_62 sorry
  have "domRELAT-1K1 (T with-replacementTREES-2K7(p,T1)) =TREES-2R1 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T1) & domRELAT-1K1 (T  |TREES-2K5 p) =TREES-2R1 domRELAT-1K1 T  |TREES-1K4 p"
    using trees_2_def_10 trees_2_def_11 sorry
  thus "cardCARD-1K4 (T with-replacementTREES-2K7(p,T1)) +NAT-1K1 cardCARD-1K4 (T  |TREES-2K5 p) =XBOOLE-0R4 cardCARD-1K4 T +NAT-1K1 cardCARD-1K4 T1"
    using A1 A2 pre_circ_th_17 sorry
qed "sorry"

mtheorem pre_circ_cl_8:
  mlet "x be objectHIDDENM1"
"cluster root-treeTREES-4K1 x as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "root-treeTREES-4K1 x be finiteFINSET-1V1"
  proof-
    have "root-treeTREES-4K1 x =FUNCT-1R1 {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,x ] }"
      using trees_4_th_6 sorry
    thus "root-treeTREES-4K1 x be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem pre_circ_th_19:
" for x be setHIDDENM2 holds cardCARD-1K4 (root-treeTREES-4K1 x) =XBOOLE-0R4 \<one>\<^sub>M"
proof(rule ballI)
  fix x assume [ty]: "x be setHIDDENM2"
  have "root-treeTREES-4K1 x =FUNCT-1R1 {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,x ] }"
    using trees_4_th_6 sorry
  thus "cardCARD-1K4 (root-treeTREES-4K1 x) =XBOOLE-0R4 \<one>\<^sub>M"
    using card_1_th_30 sorry
qed "sorry"

(*begin*)
mtheorem pre_circ_th_20:
" for F be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
proof(rule ballI)
  fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
  have "cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
    using nat_1_th_14 xreal_1_th_48 sorry
  thus "cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
qed "sorry"

mtheorem pre_circ_th_21:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f,domRELAT-1K1 g)are-equipotentTARSKIR3 iff (f,g)are-equipotentTARSKIR3"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ((domRELAT-1K1 f,domRELAT-1K1 g)are-equipotentTARSKIR3 implies (f,g)are-equipotentTARSKIR3) & ((f,g)are-equipotentTARSKIR3 implies (domRELAT-1K1 f,domRELAT-1K1 g)are-equipotentTARSKIR3)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have A1: "cardCARD-1K1 f =XBOOLE-0R4 cardCARD-1K1 (domRELAT-1K1 f) & cardCARD-1K1 g =XBOOLE-0R4 cardCARD-1K1 (domRELAT-1K1 g)"
      using card_1_th_62 sorry
    show "(domRELAT-1K1 f,domRELAT-1K1 g)are-equipotentTARSKIR3 implies (f,g)are-equipotentTARSKIR3"
    proof(rule impI)
      assume "(domRELAT-1K1 f,domRELAT-1K1 g)are-equipotentTARSKIR3"
      then have "cardCARD-1K1 (domRELAT-1K1 f) =XBOOLE-0R4 cardCARD-1K1 (domRELAT-1K1 g)"
        using card_1_th_5 sorry
      thus "(f,g)are-equipotentTARSKIR3"
        using A1 card_1_th_5 sorry
    qed
    assume "(f,g)are-equipotentTARSKIR3"
    then have "cardCARD-1K1 f =XBOOLE-0R4 cardCARD-1K1 g"
      using card_1_th_5 sorry
    thus "(domRELAT-1K1 f,domRELAT-1K1 g)are-equipotentTARSKIR3"
      using A1 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_22:
" for f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for g be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g implies cardCARD-1K4 (f +*FUNCT-4K1 g) =XBOOLE-0R4 cardCARD-1K4 f +NAT-1K1 cardCARD-1K4 g"
proof-
  have " for f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for g be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g implies cardCARD-1K4 (f +*FUNCT-4K1 g) =HIDDENR1 cardCARD-1K4 f +NAT-1K1 cardCARD-1K4 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g"
    have "cardCARD-1K4 (f +*FUNCT-4K1 g) =HIDDENR1 cardCARD-1K4 (domRELAT-1K1 (f +*FUNCT-4K1 g))"
      using card_1_th_62 sorry
    also have "... = cardCARD-1K4 (domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g)"
      using funct_4_def_1 sorry
    also have "... = cardCARD-1K4 (domRELAT-1K1 f) +NAT-1K1 cardCARD-1K4 (domRELAT-1K1 g)"
      using A1 card_2_th_40 sorry
    also have "... = cardCARD-1K4 (domRELAT-1K1 f) +NAT-1K1 cardCARD-1K4 g"
      using card_1_th_62 sorry
    also have "... = cardCARD-1K4 f +NAT-1K1 cardCARD-1K4 g"
      using card_1_th_62 sorry
    finally show "cardCARD-1K4 (f +*FUNCT-4K1 g) =HIDDENR1 cardCARD-1K4 f +NAT-1K1 cardCARD-1K4 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_23:
" for n be NatNAT-1M1 holds {k where k be NatNAT-1M1 : k >XXREAL-0R4 n } be infiniteFINSET-1V2"
proof-
  have " for n be NatNAT-1M1 holds {k where k be NatNAT-1M1 : k >XXREAL-0R4 n } be finiteFINSET-1V1 implies  False "
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?X = "{k where k be NatNAT-1M1 : k >XXREAL-0R4 n }"
    have A1: "?X c=TARSKIR1 NATNUMBERSK1"
    proof-
      have "{k where k be NatNAT-1M1 :  not k >XXREAL-0R4 n } c=TARSKIR1 NATNUMBERSK1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be NatNAT-1M1 : k >XXREAL-0R4 n } implies x inHIDDENR3 NATNUMBERSK1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then have " ex k be NatNAT-1M1 st x =HIDDENR1 k & k >XXREAL-0R4 n"
             sorry
          thus "x inHIDDENR3 NATNUMBERSK1"
            using ordinal1_def_12 sorry
        qed "sorry"
        thus "{k where k be NatNAT-1M1 :  not k >XXREAL-0R4 n } c=TARSKIR1 NATNUMBERSK1"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n +NAT-1K1 0NUMBERSK6"
      using xreal_1_th_8 sorry
    then have A2: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 ?X"
       sorry
    assume "?X be finiteFINSET-1V1"
    then obtain X where 
      [ty]:"X be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1" and XDef:"X = ?X"
      using A1 A2 sorry
    let ?m = "maxXXREAL-2K6 X"
    have "?m inHIDDENR3 X"
      using xxreal_2_def_8 sorry
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A3: "?m =HIDDENR1 k"and A4: "k >XXREAL-0R4 n"
       sorry
    have "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 k +NAT-1K1 0NUMBERSK6"
      using xreal_1_th_8 sorry
    then have "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n"
      using A4 xxreal_0_th_2 sorry
    then have "?m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 X"
      using A3 sorry
    then have "?m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ?m +NAT-1K1 0NUMBERSK6"
      using xxreal_2_def_8 sorry
    thus " False "
      using xreal_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_24:
" for D be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for k be NatNAT-1M1 holds cardCARD-1K4 D =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies ( ex x be ElementSUBSET-1M1-of D st  ex C be SubsetSUBSET-1M2-of D st D =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x} & cardCARD-1K4 C =XBOOLE-0R4 k)"
proof-
  have " for D be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for k be NatNAT-1M1 holds cardCARD-1K4 D =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M implies ( ex tVar13 be ElementSUBSET-1M1-of D st  ex tVar14 be SubsetSUBSET-1M2-of D st D =XBOOLE-0R4 tVar14 \\/XBOOLE-0K2 {TARSKIK1 tVar13} & cardCARD-1K4 tVar14 =XBOOLE-0R4 k)"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be finiteFINSET-1V1\<bar>setHIDDENM2"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "cardCARD-1K4 D =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
    then have "D <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 D"
      using xboole_0_def_1 sorry
    obtain C where 
      [ty]:"C be SubsetSUBSET-1M2-of D" and CDef:"C = D \\SUBSET-1K6 {TARSKIK1 x}"
       sorry
    have 
      [ty]:"x be ElementSUBSET-1M1-of D"
      using A2 sorry
    show " ex tVar13 be ElementSUBSET-1M1-of D st  ex tVar14 be SubsetSUBSET-1M2-of D st D =XBOOLE-0R4 tVar14 \\/XBOOLE-0K2 {TARSKIK1 tVar13} & cardCARD-1K4 tVar14 =XBOOLE-0R4 k"
    proof(rule bexI[of _ "x"])
      show " ex tVar14 be SubsetSUBSET-1M2-of D st D =XBOOLE-0R4 tVar14 \\/XBOOLE-0K2 {TARSKIK1 x} & cardCARD-1K4 tVar14 =XBOOLE-0R4 k"
      proof(rule bexI[of _ "C"],rule conjMI)
        have "x inTARSKIR2 {TARSKIK1 x}"
          using tarski_def_1 sorry
        then have A3: " not x inTARSKIR2 C"
          using xboole_0_def_5 sorry
        have "{TARSKIK1 x} c=TARSKIR1 D"
          using A2 zfmisc_1_th_31 sorry
        thus "D =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"
          using xboole_1_th_45 sorry
        then have "cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C +NAT-1K1 \<one>\<^sub>M"
          using A3 card_2_th_41 sorry
        thus "cardCARD-1K4 C =XBOOLE-0R4 k"
          using A1 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pre_circ_th_25:
" for D be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 D =XBOOLE-0R4 \<one>\<^sub>M implies ( ex x be ElementSUBSET-1M1-of D st D =XBOOLE-0R4 {TARSKIK1 x})"
proof-
  have " for D be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 D =XBOOLE-0R4 \<one>\<^sub>M implies ( ex tVar15 be ElementSUBSET-1M1-of D st D =XBOOLE-0R4 {TARSKIK1 tVar15})"
  proof(rule ballI,rule impI)
    fix D assume [ty]: "D be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume "cardCARD-1K4 D =XBOOLE-0R4 \<one>\<^sub>M"
    then have "cardCARD-1K4 D =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
       sorry
    then obtain x C where
      [ty]:"x be ElementSUBSET-1M1-of D" "C be SubsetSUBSET-1M2-of D" and 
      A1: "D =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"and A2: "cardCARD-1K4 C =XBOOLE-0R4 0NUMBERSK6"
      using pre_circ_th_24 sorry
    show " ex tVar15 be ElementSUBSET-1M1-of D st D =XBOOLE-0R4 {TARSKIK1 tVar15}"
    proof(rule bexI[of _ "x"])
      have "C =XBOOLE-0R4 {}XBOOLE-0K1"
        using A2 sorry
      thus "D =XBOOLE-0R4 {TARSKIK1 x}"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve k for "NatNAT-1M1"
theorem pre_circ_sch_5:
  fixes Df0 Ff1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be ElementSUBSET-1M1-of Df0 \<Longrightarrow> Ff1(x1) be RealXREAL-0M1"
  shows " ex x be ElementSUBSET-1M1-of Df0 st  for y be ElementSUBSET-1M1-of Df0 holds Ff1(x) <=XXREAL-0R1 Ff1(y)"
  proof-
    have " ex tVar19 be ElementSUBSET-1M1-of Df0 st  for y be ElementSUBSET-1M1-of Df0 holds Ff1(tVar19) <=XXREAL-0R1 Ff1(y)"
    proof-
      let ?P = "\<lambda>Lamb1.  for A be SubsetSUBSET-1M2-of Df0 holds Lamb1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A implies ( ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y)))"
      have A1: "(cardCARD-1K4 Df0 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (cardCARD-1K4 Df0 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
        using pre_circ_th_20 sorry
      also have "... = cardCARD-1K4 Df0"
         sorry
      finally have "(cardCARD-1K4 Df0 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 cardCARD-1K4 Df0"
         sorry
      have A2: "Df0 c=TARSKIR1 Df0"
         sorry
      have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for k be NatNAT-1M1 holds ( for A be SubsetSUBSET-1M2-of Df0 holds k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A implies ( ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y)))) implies ( for A be SubsetSUBSET-1M2-of Df0 holds (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A implies ( ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y))))"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A4: "?P(k)"
          have " for A be SubsetSUBSET-1M2-of Df0 holds (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A implies ( ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y)))"
          proof(rule ballI,rule impI)
            fix A assume [ty]: "A be SubsetSUBSET-1M2-of Df0"
            assume A5: "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A"
            then have A6: "A <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            obtain x C where
              [ty]:"x be ElementSUBSET-1M1-of A" "C be SubsetSUBSET-1M2-of A" and 
              A7: "A =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"and A8: "cardCARD-1K4 C =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              using A5 pre_circ_th_24 sorry
            have "x inTARSKIR2 A"
              using A6 sorry
            then have 
              [ty]:"x be ElementSUBSET-1M1-of Df0"
               sorry
            have 
              [ty]:"C be SubsetSUBSET-1M2-of Df0"
              using xboole_1_th_1 sorry
            obtain z where
              [ty]:"z be ElementSUBSET-1M1-of Df0" and 
              A9: "z inTARSKIR2 C"and A10: " for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 C implies Ff1(z) <=XXREAL-0R1 Ff1(y)"
              using A4 A8 sorry
            show " ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y))"
            proof-
              have cases: "Ff1(x) <=XXREAL-0R1 Ff1(z) or Ff1(x) >XXREAL-0R4 Ff1(z)"
                 sorry
              have case1: "Ff1(x) <=XXREAL-0R1 Ff1(z) implies ( ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y)))"
              proof(rule impI)
                assume A11: "Ff1(x) <=XXREAL-0R1 Ff1(z)"
                show " ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y))"
                proof(rule bexI[of _ "x"],rule conjMI)
                  show "x inTARSKIR2 A"
                    using A6 sorry
                  show " for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y)"
                  proof(rule ballI,rule impI)
                    fix y assume [ty]: "y be ElementSUBSET-1M1-of Df0"
                    assume A12: "y inTARSKIR2 A"
                    show "Ff1(x) <=XXREAL-0R1 Ff1(y)"
                    proof-
                      have cases: "y inTARSKIR2 C or y inTARSKIR2 {TARSKIK1 x}"
                        using A7 A12 xboole_0_def_3 sorry
                      have case1: "y inTARSKIR2 C implies Ff1(x) <=XXREAL-0R1 Ff1(y)"
                      proof(rule impI)
                        assume "y inTARSKIR2 C"
                        then have "Ff1(z) <=XXREAL-0R1 Ff1(y)"
                          using A10 sorry
                        thus "Ff1(x) <=XXREAL-0R1 Ff1(y)"
                          using A11 xxreal_0_th_2 sorry
                      qed
                      have case2: "y inTARSKIR2 {TARSKIK1 x} implies Ff1(x) <=XXREAL-0R1 Ff1(y)"
                      proof(rule impI)
                        assume "y inTARSKIR2 {TARSKIK1 x}"
                        thus "Ff1(x) <=XXREAL-0R1 Ff1(y)"
                          using tarski_def_1 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                qed "sorry"
              qed
              have case2: "Ff1(x) >XXREAL-0R4 Ff1(z) implies ( ex z be ElementSUBSET-1M1-of Df0 st z inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(z) <=XXREAL-0R1 Ff1(y)))"
              proof(rule impI)
                assume A13: "Ff1(x) >XXREAL-0R4 Ff1(z)"
                show " ex z be ElementSUBSET-1M1-of Df0 st z inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(z) <=XXREAL-0R1 Ff1(y))"
                proof(rule bexI[of _ "z"],rule conjMI)
                  show "z inTARSKIR2 A"
                    using A9 sorry
                  show " for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(z) <=XXREAL-0R1 Ff1(y)"
                  proof(rule ballI,rule impI)
                    fix y assume [ty]: "y be ElementSUBSET-1M1-of Df0"
                    assume A14: "y inTARSKIR2 A"
                    show "Ff1(z) <=XXREAL-0R1 Ff1(y)"
                    proof-
                      have cases: "y inTARSKIR2 C or y inTARSKIR2 {TARSKIK1 x}"
                        using A7 A14 xboole_0_def_3 sorry
                      have case1: "y inTARSKIR2 C implies Ff1(z) <=XXREAL-0R1 Ff1(y)"
                      proof(rule impI)
                        assume "y inTARSKIR2 C"
                        thus "Ff1(z) <=XXREAL-0R1 Ff1(y)"
                          using A10 sorry
                      qed
                      have case2: "y inTARSKIR2 {TARSKIK1 x} implies Ff1(z) <=XXREAL-0R1 Ff1(y)"
                      proof(rule impI)
                        assume "y inTARSKIR2 {TARSKIK1 x}"
                        thus "Ff1(z) <=XXREAL-0R1 Ff1(y)"
                          using A13 tarski_def_1 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " for A be SubsetSUBSET-1M2-of Df0 holds (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A implies ( ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 A implies Ff1(x) <=XXREAL-0R1 Ff1(y)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A15: "?P(0NUMBERSK6)"
      proof-
        have " for A be SubsetSUBSET-1M2-of Df0 holds 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A implies ( ex tVar18 be ElementSUBSET-1M1-of Df0 st tVar18 inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds  not (y inTARSKIR2 A &  not Ff1(tVar18) <=XXREAL-0R1 Ff1(y))))"
        proof(rule ballI,rule impI)
          fix A assume [ty]: "A be SubsetSUBSET-1M2-of Df0"
          assume "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 A"
          then obtain x where
            [ty]:"x be ElementSUBSET-1M1-of A" and 
            A16: "A =XBOOLE-0R4 {TARSKIK1 x}"
            using pre_circ_th_25 sorry
          have 
            [ty]:"x be ElementSUBSET-1M1-of Df0"
            using A16 zfmisc_1_th_31 sorry
          show " ex tVar18 be ElementSUBSET-1M1-of Df0 st tVar18 inTARSKIR2 A & ( for y be ElementSUBSET-1M1-of Df0 holds  not (y inTARSKIR2 A &  not Ff1(tVar18) <=XXREAL-0R1 Ff1(y)))"
          proof(rule bexI[of _ "x"],rule conjMI)
            show "x inTARSKIR2 A"
              using A16 sorry
            show " for y be ElementSUBSET-1M1-of Df0 holds  not (y inTARSKIR2 A &  not Ff1(x) <=XXREAL-0R1 Ff1(y))"
              using A16 tarski_def_1 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for k be NatNAT-1M1 holds ?P(k)"
        using nat_1_sch_2 A15 A3 sorry
      then have "(cardCARD-1K4 Df0 -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 Df0 implies ( ex x be ElementSUBSET-1M1-of Df0 st x inTARSKIR2 Df0 & ( for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 Df0 implies Ff1(x) <=XXREAL-0R1 Ff1(y)))"
        using A2 sorry
      then obtain x where
        [ty]:"x be ElementSUBSET-1M1-of Df0" and 
        "x inTARSKIR2 Df0"and A17: " for y be ElementSUBSET-1M1-of Df0 holds y inTARSKIR2 Df0 implies Ff1(x) <=XXREAL-0R1 Ff1(y)"
        using A1 sorry
      show " ex tVar19 be ElementSUBSET-1M1-of Df0 st  for y be ElementSUBSET-1M1-of Df0 holds Ff1(tVar19) <=XXREAL-0R1 Ff1(y)"
      proof(rule bexI[of _ "x"],rule ballI)
        fix y assume [ty]: "y be ElementSUBSET-1M1-of Df0"
        show "Ff1(x) <=XXREAL-0R1 Ff1(y)"
          using A17 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

end
