theory series_4
  imports series_3 wsierp_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n for "NatNAT-1M1"
reserve a, b, c, d for "RealXREAL-0M1"
reserve s for "Real-SequenceSEQ-1M1"
mlemma series_4_lm_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds \<four>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M & (a +XCMPLX-0K2 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds \<four>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M & (a +XCMPLX-0K2 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: "(a +XCMPLX-0K2 b) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a +XCMPLX-0K2 b) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using newton_th_6 sorry
    also have "... = (a +XCMPLX-0K2 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
       sorry
    also have "... = (a *XCMPLX-0K3 a +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 b)"
       sorry
    also have "... = (a *XCMPLX-0K3 a +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    finally have "(a +XCMPLX-0K2 b) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    have "\<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using wsierp_1_th_1 sorry
    also have "... = \<four>\<^sub>M"
       sorry
    finally have "\<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M =HIDDENR1 \<four>\<^sub>M"
       sorry
    thus "\<four>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M & (a +XCMPLX-0K2 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_4_lm_2:
" for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_6 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M) |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M +NAT-1K1 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    finally have "((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    thus "((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_4_lm_3:
" for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_6 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M) |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M +NAT-1K1 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    finally have "((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    thus "((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_4_lm_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a *XCMPLX-0K3 a -XCMPLX-0K6 b *XCMPLX-0K3 b"
       sorry
    also have "... = a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 b *XCMPLX-0K3 b"
      using wsierp_1_th_1 sorry
    also have "... = a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M"
      using wsierp_1_th_1 sorry
    finally have "(a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    thus "(a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_4_lm_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(a -XCMPLX-0K6 b) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a -XCMPLX-0K6 b) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 b)"
      using newton_th_6 sorry
    also have "... = (a -XCMPLX-0K6 b)*XCMPLX-0K3 (a -XCMPLX-0K6 b)"
       sorry
    also have "... = (a *XCMPLX-0K3 a -XCMPLX-0K6 a *XCMPLX-0K3 b)-XCMPLX-0K6 (a *XCMPLX-0K3 b -XCMPLX-0K6 b *XCMPLX-0K3 b)"
       sorry
    also have "... = (a *XCMPLX-0K3 a -XCMPLX-0K6 a *XCMPLX-0K3 b)-XCMPLX-0K6 (a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)-XCMPLX-0K6 (a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    finally have "(a -XCMPLX-0K6 b) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    thus "(a -XCMPLX-0K6 b) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_4_lm_6:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 \<one>\<^sub>M implies (((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
proof-
  have " for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 \<one>\<^sub>M implies (((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a <>HIDDENR2 \<one>\<^sub>M"
    then have A1: "\<one>\<^sub>M -XCMPLX-0K6 a <>HIDDENR2 0NUMBERSK6"
       sorry
    then have "(((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a)))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
      using xcmplx_1_th_91 sorry
    also have "... = (((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
      using xcmplx_1_th_120 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))*XCMPLX-0K3 \<one>\<^sub>M)"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)))"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a)))"
      using xcmplx_1_th_76 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a)))"
       sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a)))"
      using newton_th_6 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((\<one>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a)))"
      using series_4_lm_5 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((\<one>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((\<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M)"
       sorry
    also have "... = (((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 ((n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M"
      using xcmplx_1_th_74 sorry
    also have "... = ((((a -XCMPLX-0K6 a *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((((n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 ((n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 ((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M"
      using xcmplx_1_th_62 sorry
    also have "... = ((((a -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 n)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (((n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 ((n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 ((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M"
      using newton_th_6 sorry
    also have "... = ((a -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a)-XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (a -XCMPLX-0K6 a  |^NEWTONK1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M"
       sorry
    also have "... = ((a -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a)-XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (a -XCMPLX-0K6 a *XCMPLX-0K3 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M"
      using wsierp_1_th_1 sorry
    also have "... = (a -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M"
      using xcmplx_1_th_120 sorry
    also have "... = (a -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))"
      using wsierp_1_th_1 sorry
    also have "... = (a -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (((((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      using xcmplx_1_th_83 sorry
    also have "... = (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      using A1 xcmplx_1_th_87 sorry
    also have "... = (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      using newton_th_6 sorry
    also have "... = (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
    finally have "(((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
    thus "(((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_4_lm_7:
" for n be NatNAT-1M1 holds \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    then have "\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) >XXREAL-0R4 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
      using prepower_th_28 sorry
    then have "\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
      using xreal_1_th_9 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 (\<one>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)))"
      using xcmplx_1_th_91 sorry
    also have "... = (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M)  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)  |^NEWTONK1 \<two>\<^sub>M)"
      using series_4_lm_4 sorry
    also have "... = (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)  |^NEWTONK1 \<two>\<^sub>M)"
      using prepower_th_19 sorry
    also have "... = (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M))"
      using prepower_th_19 sorry
    also have "... = \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    finally have "(\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    thus "\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using newton_th_6 sorry
    also have "... = ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)*XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
       sorry
    also have "... = (((a *XCMPLX-0K3 a +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 ((a *XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)"
       sorry
    also have "... = (((a *XCMPLX-0K3 a +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 ((a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)"
      using wsierp_1_th_1 sorry
    also have "... = (((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 ((a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)"
      using wsierp_1_th_1 sorry
    also have "... = (((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 ((a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    finally have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    thus "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(a +XCMPLX-0K2 b) |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a +XCMPLX-0K2 b) |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using series_4_lm_1 sorry
    also have "... = ((a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)"
       sorry
    also have "... = ((a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 b +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 b +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)"
       sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 a)+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)"
       sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 a)+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)"
       sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a)+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    finally have "(a +XCMPLX-0K2 b) |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    thus "(a +XCMPLX-0K2 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a -XCMPLX-0K6 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a -XCMPLX-0K6 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    have "((a -XCMPLX-0K6 b)+XCMPLX-0K2 c) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 c) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 c)"
      using newton_th_6 sorry
    also have "... = ((a -XCMPLX-0K6 b)+XCMPLX-0K2 c)*XCMPLX-0K3 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 c)"
       sorry
    also have "... = (((a *XCMPLX-0K3 a -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b *XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)"
       sorry
    also have "... = (((a *XCMPLX-0K3 a -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)"
      using wsierp_1_th_1 sorry
    also have "... = (((a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)"
      using wsierp_1_th_1 sorry
    also have "... = (((a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c))+XCMPLX-0K2 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    finally have "((a -XCMPLX-0K6 b)+XCMPLX-0K2 c) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    thus "((a -XCMPLX-0K6 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a -XCMPLX-0K6 b)-XCMPLX-0K6 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a -XCMPLX-0K6 b)-XCMPLX-0K6 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    have "((a -XCMPLX-0K6 b)-XCMPLX-0K6 c) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 c) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 c)"
      using newton_th_6 sorry
    also have "... = ((a -XCMPLX-0K6 b)-XCMPLX-0K6 c)*XCMPLX-0K3 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 c)"
       sorry
    also have "... = (((a *XCMPLX-0K3 a -XCMPLX-0K6 a *XCMPLX-0K3 b)-XCMPLX-0K6 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b *XCMPLX-0K3 b)-XCMPLX-0K6 b *XCMPLX-0K3 c))-XCMPLX-0K6 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)-XCMPLX-0K6 c *XCMPLX-0K3 c)"
       sorry
    also have "... = (((a *XCMPLX-0K3 a -XCMPLX-0K6 a *XCMPLX-0K3 b)-XCMPLX-0K6 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 b *XCMPLX-0K3 c))-XCMPLX-0K6 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)-XCMPLX-0K6 c *XCMPLX-0K3 c)"
      using wsierp_1_th_1 sorry
    also have "... = (((a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)-XCMPLX-0K6 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 b *XCMPLX-0K3 c))-XCMPLX-0K6 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)-XCMPLX-0K6 c *XCMPLX-0K3 c)"
      using wsierp_1_th_1 sorry
    also have "... = (((a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)-XCMPLX-0K6 a *XCMPLX-0K3 c)-XCMPLX-0K6 ((a *XCMPLX-0K3 b -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 b *XCMPLX-0K3 c))-XCMPLX-0K6 ((a *XCMPLX-0K3 c -XCMPLX-0K6 c *XCMPLX-0K3 b)-XCMPLX-0K6 c  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    finally have "((a -XCMPLX-0K6 b)-XCMPLX-0K6 c) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M"
       sorry
    thus "((a -XCMPLX-0K6 b)-XCMPLX-0K6 c) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a -XCMPLX-0K6 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(a -XCMPLX-0K6 b) |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a -XCMPLX-0K6 b) |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 b)"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a -XCMPLX-0K6 b)"
      using series_4_lm_5 sorry
    also have "... = ((a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 a -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)"
       sorry
    also have "... = ((a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 a -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 b -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 b -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M)"
       sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    also have "... = (((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    also have "... = (((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    finally have "(a -XCMPLX-0K6 b) |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    thus "(a -XCMPLX-0K6 b) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 ((a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 \<four>\<^sub>M =HIDDENR1 (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a +XCMPLX-0K2 b) |^NEWTONK1 \<four>\<^sub>M =HIDDENR1 (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(a +XCMPLX-0K2 b) |^NEWTONK1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a +XCMPLX-0K2 b) |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using series_4_th_2 sorry
    also have "... = (((a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)"
       sorry
    also have "... = (((a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 b +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)*XCMPLX-0K3 b))+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (b *XCMPLX-0K3 b)))+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
       sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (b  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 b)))+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
       sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 (((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a *XCMPLX-0K3 a) +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a)*XCMPLX-0K3 b))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
       sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 a) +XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)*XCMPLX-0K3 a))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
       sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 a))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a))+XCMPLX-0K2 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M"
       sorry
    finally have "(a +XCMPLX-0K2 b) |^NEWTONK1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M"
       sorry
    thus "(a +XCMPLX-0K2 b) |^NEWTONK1 \<four>\<^sub>M =HIDDENR1 (((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 d  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 d))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 d  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 d))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    have "(((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using newton_th_6 sorry
    also have "... = (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d)*XCMPLX-0K3 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d)"
       sorry
    also have "... = (((((a *XCMPLX-0K3 a +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 a *XCMPLX-0K3 d)+XCMPLX-0K2 (((a *XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 b *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)+XCMPLX-0K2 c *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 d +XCMPLX-0K2 d *XCMPLX-0K3 b)+XCMPLX-0K2 d *XCMPLX-0K3 c)+XCMPLX-0K2 d *XCMPLX-0K3 d)"
       sorry
    also have "... = (((((a *XCMPLX-0K3 a +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 a *XCMPLX-0K3 d)+XCMPLX-0K2 (((a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 b *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)+XCMPLX-0K2 c *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 d +XCMPLX-0K2 d *XCMPLX-0K3 b)+XCMPLX-0K2 d *XCMPLX-0K3 c)+XCMPLX-0K2 d *XCMPLX-0K3 d)"
      using wsierp_1_th_1 sorry
    also have "... = (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 a *XCMPLX-0K3 d)+XCMPLX-0K2 (((a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 b *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c *XCMPLX-0K3 c)+XCMPLX-0K2 c *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 d +XCMPLX-0K2 d *XCMPLX-0K3 b)+XCMPLX-0K2 d *XCMPLX-0K3 c)+XCMPLX-0K2 d *XCMPLX-0K3 d)"
      using wsierp_1_th_1 sorry
    also have "... = (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 a *XCMPLX-0K3 d)+XCMPLX-0K2 (((a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 b *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 d +XCMPLX-0K2 d *XCMPLX-0K3 b)+XCMPLX-0K2 d *XCMPLX-0K3 c)+XCMPLX-0K2 d *XCMPLX-0K3 d)"
      using wsierp_1_th_1 sorry
    also have "... = (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 a *XCMPLX-0K3 d)+XCMPLX-0K2 (((a *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 b *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 d))+XCMPLX-0K2 (((a *XCMPLX-0K3 d +XCMPLX-0K2 d *XCMPLX-0K3 b)+XCMPLX-0K2 d *XCMPLX-0K3 c)+XCMPLX-0K2 d  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 d  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 d))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 d"
       sorry
    finally have "(((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 d  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 d))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 d"
       sorry
    thus "(((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 d  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 d))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b))+XCMPLX-0K2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b))+XCMPLX-0K2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using newton_th_6 sorry
    also have "... = (((((a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using series_4_th_1 sorry
    also have "... = ((((((a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 c)"
       sorry
    also have "... = ((((((a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 c)"
      using newton_th_6 sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 c))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 c)"
      using newton_th_6 sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b *XCMPLX-0K3 b))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (c *XCMPLX-0K3 c)))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 c))"
      using newton_th_6 sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b *XCMPLX-0K3 b))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (c *XCMPLX-0K3 c)))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 c))"
       sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b *XCMPLX-0K3 b))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (c *XCMPLX-0K3 c)))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 c))"
      using newton_th_6 sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (b  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (c *XCMPLX-0K3 c)))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 c))"
       sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 a))*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (c *XCMPLX-0K3 c)))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 c))"
      using newton_th_6 sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (c *XCMPLX-0K3 c)))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 c))"
      using wsierp_1_th_1 sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 c))"
      using wsierp_1_th_1 sorry
    also have "... = ((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 ((b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 ((c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (b *XCMPLX-0K3 b))*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)"
      using wsierp_1_th_1 sorry
    also have "... = ((((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)+XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c))+XCMPLX-0K2 (c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c))+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M))+XCMPLX-0K2 ((((\<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b)"
      using wsierp_1_th_1 sorry
    also have "... = (((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b))+XCMPLX-0K2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
       sorry
    finally have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b))+XCMPLX-0K2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
       sorry
    thus "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 c))+XCMPLX-0K2 ((\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 b))+XCMPLX-0K2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_9:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    have "((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_6 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (a *XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
      using newton_th_7 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (a *XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
      using A1 xcmplx_1_th_106 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (a *XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
      using A1 xcmplx_1_th_106 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (a *XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 (a *XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (a *XCMPLX-0K3 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (a  |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
      using wsierp_1_th_1 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 \<two>\<^sub>M"
      using newton_th_9 sorry
    also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
      using wsierp_1_th_1 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
      using newton_th_9 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    finally have "((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    thus "((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_10:
" for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
proof-
  have " for n be NatNAT-1M1 holds  for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M implies (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
    assume "a <>HIDDENR2 \<one>\<^sub>M"
    then have A1: "\<one>\<^sub>M -XCMPLX-0K6 a <>HIDDENR2 0NUMBERSK6"
       sorry
    assume A2: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n"
    have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M"
          using A2 sorry
        also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
          using A1 xcmplx_1_th_60 sorry
        also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using xcmplx_1_th_74 sorry
        also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using xcmplx_1_th_62 sorry
        also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a  |^NEWTONK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using newton_th_6 sorry
        also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
        finally show "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = a  |^NEWTONK1 (0NUMBERSK6)"
      using A2 sorry
    also have "... = \<one>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
    then have A4: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A4 A3 sorry
    thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_11:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds (a <>HIDDENR2 \<one>\<^sub>M & a <>HIDDENR2 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
proof-
  have " for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & a <>HIDDENR2 0NUMBERSK6 implies (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    assume A1: "a <>HIDDENR2 \<one>\<^sub>M"
      and A2: "a <>HIDDENR2 0NUMBERSK6"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 Lamb1 -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
    assume A3: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n"
    have A4: "\<one>\<^sub>M -XCMPLX-0K6 a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    have A5: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M"
          using A3 sorry
        also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
          using A4 xcmplx_1_th_60 sorry
        also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using xcmplx_1_th_74 sorry
        also have "... = (((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)+XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using xcmplx_1_th_62 sorry
        also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
        also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))*XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using newton_th_6 sorry
        also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 a))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
        also have "... = ((((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using A2 xcmplx_1_th_106 sorry
        also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
        finally show "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (0NUMBERSK6)"
      using A3 sorry
    also have "... = \<one>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      using A4 xcmplx_1_th_60 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (0NUMBERSK6) -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      using newton_th_4 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (0NUMBERSK6) -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
    then have A6: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A6 A5 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n -XCMPLX-0K6 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_12:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<one>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)+XCMPLX-0K2 ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<one>\<zero>\<^sub>M)/XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<three>\<^sub>M)"
           sorry
        also have "... = ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<one>\<zero>\<^sub>M)/XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 ((((n  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 n)*XCMPLX-0K3 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<three>\<^sub>M)"
          using series_4_lm_1 sorry
        also have "... = ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<one>\<zero>\<^sub>M)/XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 ((((n  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<three>\<^sub>M)"
           sorry
        also have "... = ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<one>\<zero>\<^sub>M)/XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 ((n  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 n)*XCMPLX-0K3 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M)"
          using series_4_lm_1 sorry
        also have "... = ((\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<one>\<zero>\<^sub>M)/XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<two>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
          using series_4_lm_1 sorry
        also have "... = (\<one>\<zero>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<two>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
          using newton_th_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<two>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (\<one>\<zero>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) +NAT-1K1 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+NAT-1K1 \<one>\<^sub>M"
      using A1 sorry
    also have "... = (\<one>\<zero>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (\<one>\<zero>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    also have "... = (\<one>\<zero>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<zero>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<nine>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_13:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
proof-
  have " for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (Lamb1  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 Lamb1"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 ((\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
          using A1 sorry
        also have "... = ((((n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        also have "... = ((((n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
          using newton_th_6 sorry
        also have "... = (((n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        also have "... = (((n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
          using newton_th_6 sorry
        also have "... = (((n  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = (((n  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 n)*XCMPLX-0K3 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using series_4_lm_1 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6)"
      using A1 sorry
    also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6) |^NEWTONK11 \<two>\<^sub>M"
      using newton_th_11 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6) |^NEWTONK11 \<two>\<^sub>M"
      using newton_th_4 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6) |^NEWTONK11 \<two>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n  |^NEWTONK1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_14:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
proof-
  have " for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 Lamb1)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 Lamb1"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = (\<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = (((\<two>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = (((\<two>\<^sub>M -XCMPLX-0K6 ((\<four>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)-XCMPLX-0K6 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 n *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = (((\<two>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)))-XCMPLX-0K6 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 (n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = (((\<two>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 (n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = (\<two>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 n *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))"
           sorry
        also have "... = (\<two>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = \<two>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<three>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (0NUMBERSK6)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6)"
      using A1 sorry
    also have "... = \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6)*NAT-1K2 \<one>\<^sub>M"
       sorry
    also have "... = \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6)"
      using newton_th_4 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6)"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 (\<two>\<^sub>M +XCMPLX-0K2 n)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_15:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 Lamb1 /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 Lamb1)+XCMPLX-0K2 \<three>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)+XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M"
          using A1 sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)+XCMPLX-0K2 (((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M)"
          using series_4_lm_2 sorry
        also have "... = (((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        also have "... = (((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M))+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
          using newton_th_6 sorry
        also have "... = ((((-XCMPLX-0K4 ((\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M))/XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
          using newton_th_6 sorry
        also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 (\<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<four>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
          using newton_th_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)) |^NEWTONK1 \<two>\<^sub>M"
      using A1 sorry
    also have "... = (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)) |^NEWTONK11 \<two>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
      using series_4_lm_1 sorry
    also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<four>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_16:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 Lamb1 /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 Lamb1)+XCMPLX-0K2 \<three>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 n +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n) |^NEWTONK1 \<two>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)+XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 \<two>\<^sub>M"
          using A1 sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)+XCMPLX-0K2 (((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M)"
          using series_4_lm_3 sorry
        also have "... = (((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        also have "... = (((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M))+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
          using newton_th_6 sorry
        also have "... = ((((-XCMPLX-0K4 ((\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M))/XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
          using newton_th_6 sorry
        also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 (\<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<nine>\<^sub>M)/XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
          using newton_th_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<three>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)) |^NEWTONK1 \<two>\<^sub>M"
      using A1 sorry
    also have "... = (\<one>\<^sub>M +NAT-1K1 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)) |^NEWTONK11 \<two>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
      using series_4_lm_1 sorry
    also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6))+XCMPLX-0K2 \<three>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) |^NEWTONK1 n /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<nine>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<eight>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_17:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (Lamb1 *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = n *XCMPLX-0K3 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M) +NAT-1K1 \<two>\<^sub>M"
           sorry
        also have "... = n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M"
          using newton_th_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (0NUMBERSK6)*NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)"
      using A1 sorry
    also have "... = ((0NUMBERSK6)*NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    also have "... = ((0NUMBERSK6)*NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ((0NUMBERSK6)*NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_18:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 Lamb1 *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK1 n"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = (n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (\<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<three>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
           sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
          using newton_th_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)"
      using A1 sorry
    also have "... = (0NUMBERSK6)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      using newton_th_4 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (0NUMBERSK6)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_19:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 a  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
proof-
  have " for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 a  |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    assume A1: "a <>HIDDENR2 \<one>\<^sub>M"
      and A2: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n *XCMPLX-0K3 a  |^NEWTONK1 n"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 Lamb1))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (Lamb1 *XCMPLX-0K3 a  |^NEWTONK1 (Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
    have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 sorry
        also have "... = (((a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a))+XCMPLX-0K2 n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
          using A1 series_4_lm_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (0NUMBERSK6)*XCMPLX-0K3 a  |^NEWTONK1 (0NUMBERSK6)"
      using A2 sorry
    also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((0NUMBERSK6)*XCMPLX-0K3 a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
    also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (0NUMBERSK6))*XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((0NUMBERSK6)*XCMPLX-0K3 a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
      using newton_th_4 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 (0NUMBERSK6))*XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 ((0NUMBERSK6)*XCMPLX-0K3 a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
    then have A4: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A4 A3 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 n))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a) |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 (n *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_20:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 n)) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 n)) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 n)"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))"
          using A1 sorry
        also have "... = \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))"
          using series_4_lm_7 sorry
        also have "... = \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M)"
           sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<two>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M -RootPREPOWERK2 (0NUMBERSK6))"
      using A1 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M -RootPREPOWERK2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 0NUMBERSK6)"
      using prepower_def_2 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
      using prepower_th_20 sorry
    also have "... = \<two>\<^sub>M -RootPREPOWERK2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using prepower_th_20 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M -RootPREPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_21:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 Lamb1)+XCMPLX-0K2 \<one>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ((\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))"
          using A1 sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = ((((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = (((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = ((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M"
           sorry
        also have "... = ((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((-XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6)"
      using A1 sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6)"
      using newton_th_4 sorry
    also have "... = (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using newton_th_4 sorry
    also have "... = (\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    also have "... = (\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M"
      using newton_th_4 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M) |^NEWTONK1 n)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_22:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 n +XCMPLX-0K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 n +XCMPLX-0K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 n +XCMPLX-0K2 n /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
    then have A2: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ((0NUMBERSK6)!NEWTONK7)*NAT-1K2 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)/XCMPLX-0K7 ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
       sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
    have A3: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A4: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
        have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A4 series_1_def_1 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))+XCMPLX-0K2 (((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7))"
          using A1 sorry
        also have "... = (((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 +NAT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
        also have "... = (((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!NEWTONK7)"
          using xcmplx_1_th_91 sorry
        also have "... = (((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7))+XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!NEWTONK7)"
          using newton_th_15 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!NEWTONK7))"
           sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 ((n +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!NEWTONK7)"
          using xcmplx_1_th_120 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
          using newton_th_15 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A2 series_1_def_1 sorry
    also have "... = (\<one>\<^sub>M !NEWTONK7)*NAT-1K2 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      using A1 sorry
    also have "... = (((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      using newton_th_13 newton_th_14 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 (((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
       sorry
    then have A5: "?X(\<one>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A5 A3 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_23:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M))"
proof-
  have " for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a <>HIDDENR2 \<one>\<^sub>M implies (( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M))))"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 Lamb1 -XCMPLX-0K6 \<one>\<^sub>M)"
    assume "a <>HIDDENR2 \<one>\<^sub>M"
    then have A1: "a -XCMPLX-0K6 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6"
       sorry
    assume A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
    have A3: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A4: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M)"
        have A5: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A4 series_1_def_1 sorry
        also have "... = (a *XCMPLX-0K3 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 a)+XCMPLX-0K2 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 A5 sorry
        also have "... = (a *XCMPLX-0K3 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n +XCMPLX-0K2 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 a"
           sorry
        also have "... = (a *XCMPLX-0K3 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n +XCMPLX-0K2 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n *XCMPLX-0K3 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)))-XCMPLX-0K6 a"
          using newton_th_6 sorry
        also have "... = (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) -XCMPLX-0K6 a"
           sorry
        also have "... = (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M))) -XCMPLX-0K6 a"
          using xcmplx_1_th_99 sorry
        also have "... = (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M))) -XCMPLX-0K6 a"
           sorry
        also have "... = (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 ((a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M))) -XCMPLX-0K6 a"
          using A1 xcmplx_1_th_60 sorry
        also have "... = (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 (((a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M))) -XCMPLX-0K6 a"
          using xcmplx_1_th_62 sorry
        also have "... = a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n *XCMPLX-0K3 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M))) -XCMPLX-0K6 a"
           sorry
        also have "... = a *XCMPLX-0K3 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a"
          using newton_th_6 sorry
        also have "... = a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using series_1_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using series_1_def_1 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A2 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 \<one>\<^sub>M"
      using A2 sorry
    also have "... = (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 a)-XCMPLX-0K6 a"
       sorry
    also have "... = (a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) +XCMPLX-0K2 a *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 a"
      using xcmplx_1_th_99 sorry
    also have "... = (a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) +XCMPLX-0K2 a *XCMPLX-0K3 ((a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)))-XCMPLX-0K6 a"
      using A1 xcmplx_1_th_60 sorry
    also have "... = a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) -XCMPLX-0K6 a"
       sorry
    also have "... = a *XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) -XCMPLX-0K6 a"
      using xcmplx_1_th_62 sorry
    also have "... = a *XCMPLX-0K3 (a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    also have "... = a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    then have A6: "?X(\<one>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A6 A3 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a *XCMPLX-0K3 ((a /XCMPLX-0K7 (a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_24:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 Lamb1 *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 Lamb1 -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A3: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M"
        have A4: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A3 series_1_def_1 sorry
        also have "... = (\<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<three>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M)"
          using A1 A4 sorry
        also have "... = (\<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
           sorry
        also have "... = (\<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 (\<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
          using newton_th_6 sorry
        also have "... = (\<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M"
           sorry
        also have "... = \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<three>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M"
          using newton_th_6 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<three>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using series_1_def_1 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A1 sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *XCMPLX-0K3 ((\<three>\<^sub>M *NAT-1K2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M)"
      using A1 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
    also have "... = ((\<three>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    also have "... = ((\<three>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    also have "... = (\<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M *NAT-1K2 \<one>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M *NAT-1K2 \<one>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    then have A5: "?X(\<one>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A5 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ((\<three>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<four>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_25:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<two>\<^sub>M)"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))*XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_3_def_1 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
          using A1 sorry
        also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)"
          using xcmplx_1_th_74 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)"
          using xcmplx_1_th_106 sorry
        finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)"
           sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)"
      using A1 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)"
       sorry
    finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_26:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
proof-
  have " for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((Lamb1 +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))*XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_3_def_1 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using A1 sorry
        also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using xcmplx_1_th_74 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using xcmplx_1_th_78 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!NEWTONK7)"
          using newton_th_15 sorry
        finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)!NEWTONK7)"
           sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      using A1 newton_th_13 sorry
    finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
       sorry
    then have A3: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A3 A2 sorry
    thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_27:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n !NEWTONK7)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n !NEWTONK7))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 Lamb1 !NEWTONK7"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n !NEWTONK7 implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A3: "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n !NEWTONK7"
        have A4: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_3_def_1 sorry
        also have "... = (n !NEWTONK7)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 A3 A4 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
          using newton_th_15 sorry
        finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
           sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A1 sorry
    also have "... = \<one>\<^sub>M !NEWTONK7"
      using A1 newton_th_13 sorry
    finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M !NEWTONK7"
       sorry
    then have A5: "?X(\<one>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A5 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n !NEWTONK7)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_28:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a /XCMPLX-0K7 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n /XCMPLX-0K7 (n !NEWTONK7))"
proof-
  have " for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a /XCMPLX-0K7 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n /XCMPLX-0K7 (n !NEWTONK7)))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 a  |^NEWTONK1 Lamb1 /XCMPLX-0K7 (Lamb1 !NEWTONK7)"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a /XCMPLX-0K7 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n /XCMPLX-0K7 (n !NEWTONK7) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A3: "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n /XCMPLX-0K7 (n !NEWTONK7)"
        have A4: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_3_def_1 sorry
        also have "... = (a  |^NEWTONK1 n /XCMPLX-0K7 (n !NEWTONK7))*XCMPLX-0K3 (a /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
          using A1 A3 A4 sorry
        also have "... = (a  |^NEWTONK1 n *XCMPLX-0K3 a)/XCMPLX-0K7 ((n !NEWTONK7)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
          using xcmplx_1_th_76 sorry
        also have "... = a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n !NEWTONK7)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
          using newton_th_6 sorry
        also have "... = a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
          using newton_th_15 sorry
        finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A1 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 \<one>\<^sub>M"
      using A1 sorry
    also have "... = a  |^NEWTONK1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M !NEWTONK7)"
      using newton_th_13 sorry
    finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 a  |^NEWTONK1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M !NEWTONK7)"
       sorry
    then have A5: "?X(\<one>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A5 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n /XCMPLX-0K7 (n !NEWTONK7))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_29:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n)"
proof-
  have " for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 a  |^NEWTONK1 Lamb1"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A3: "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n"
        have A4: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_3_def_1 sorry
        also have "... = a  |^NEWTONK1 n *XCMPLX-0K3 a"
          using A1 A3 A4 sorry
        also have "... = a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A1 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 a"
      using A1 sorry
    also have "... = a  |^NEWTONK1 \<one>\<^sub>M"
       sorry
    finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 a  |^NEWTONK1 \<one>\<^sub>M"
       sorry
    then have A5: "?X(\<one>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A5 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 a  |^NEWTONK1 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_4_th_30:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 n  |^NEWTONK1 \<two>\<^sub>M & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 n  |^NEWTONK1 \<two>\<^sub>M & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<two>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n)))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =HIDDENR1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1)"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 n  |^NEWTONK1 \<two>\<^sub>M & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "n >=XXREAL-0R2 \<two>\<^sub>M"
          and A4: "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n)"
        have A5: "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A3 nat_1_th_13 sorry
        have "(n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
           sorry
        then have A6: "(n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6"
          using wsierp_1_th_1 sorry
        have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_3_def_1 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)"
          using A1 A4 A5 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)"
          using A6 xcmplx_1_th_60 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)"
          using xcmplx_1_th_120 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)"
           sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))*XCMPLX-0K3 ((((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)"
          using series_4_lm_4 sorry
        also have "... = ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n *XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) |^NEWTONK11 \<two>\<^sub>M)"
          using xcmplx_1_th_76 sorry
        also have "... = (((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 ((\<two>\<^sub>M *XCMPLX-0K3 n)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))"
          using wsierp_1_th_1 sorry
        also have "... = (((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 ((n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))"
           sorry
        also have "... = (((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 n)/XCMPLX-0K7 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))"
          using xcmplx_1_th_76 sorry
        also have "... = (((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n /XCMPLX-0K7 n))*XCMPLX-0K3 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))"
          using xcmplx_1_th_76 sorry
        also have "... = (\<one>\<^sub>M *XCMPLX-0K3 (n /XCMPLX-0K7 n))*XCMPLX-0K3 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))"
          using xcmplx_1_th_60 sorry
        also have "... = (\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))"
          using A3 xcmplx_1_th_60 sorry
        also have "... = (n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
           sorry
        finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))"
           sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M"
      using series_3_def_1 sorry
    also have "... = (Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)*XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M"
      using series_3_def_1 sorry
    also have "... = (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)*XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M"
      using series_3_def_1 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)*XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M"
      using A1 sorry
    also have "... = (\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M"
      using A1 sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
      using A1 series_4_lm_1 sorry
    also have "... = (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
       sorry
    then have A7: "?X(\<two>\<^sub>M)"
       sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<two>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A7 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<two>\<^sub>M &  not Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
