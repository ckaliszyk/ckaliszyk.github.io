theory wellord2
  imports mcart_1 wellord1 ordinal1
begin
(*begin*)
reserve X, Y, Z for "setHIDDENM2"
reserve a, b, c, d, x, y, z, u for "objectHIDDENM1"
reserve R for "RelationRELAT-1M1"
reserve A, B, C for "OrdinalORDINAL1M3"
mdef wellord2_def_1 ("RelInclWELLORD2K1  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func RelInclWELLORD2K1 X \<rightarrow> RelationRELAT-1M1 means
  \<lambda>it. fieldRELAT-1K3 it =XBOOLE-0R4 X & ( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 it iff Y c=TARSKIR1 Z))"
proof-
  (*existence*)
    show " ex it be RelationRELAT-1M1 st fieldRELAT-1K3 it =XBOOLE-0R4 X & ( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 it iff Y c=TARSKIR1 Z))"
    proof-
      have " ex tVar1 be RelationRELAT-1M1 st fieldRELAT-1K3 tVar1 =XBOOLE-0R4 X & ( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 tVar1 implies Y c=TARSKIR1 Z) &  not (Y c=TARSKIR1 Z &  not [TARSKIK4 Y,Z ] inHIDDENR3 tVar1))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex D1 be setHIDDENM2 st  ex D2 be setHIDDENM2 st (D1 =HIDDENR1 Lamb1 & D2 =HIDDENR1 Lamb2) & D1 c=TARSKIR1 D2"
        obtain R where
          [ty]:"R be RelationRELAT-1M1" and 
          A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 X & y inHIDDENR3 X) & ?P(x,y)"
          using relat_1_sch_1 sorry
        show " ex tVar1 be RelationRELAT-1M1 st fieldRELAT-1K3 tVar1 =XBOOLE-0R4 X & ( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 tVar1 implies Y c=TARSKIR1 Z) &  not (Y c=TARSKIR1 Z &  not [TARSKIK4 Y,Z ] inHIDDENR3 tVar1))"
        proof(rule bexI[of _ "R"],rule conjMI,rule ballI,rule ballI,rule impI,rule conjMI)
          show "fieldRELAT-1K3 R =XBOOLE-0R4 X"
          proof-
            have "( for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R implies x inHIDDENR3 X) & X c=TARSKIR1 fieldRELAT-1K3 R"
            proof(rule conjMI)
              show " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R implies x inHIDDENR3 X"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                have A2: "x inHIDDENR3 domRELAT-1K1 R implies  not (x inHIDDENR3 fieldRELAT-1K3 R &  not x inHIDDENR3 X)"
                proof(rule impI)
                  assume "x inHIDDENR3 domRELAT-1K1 R"
                  then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
                    using xtuple_0_def_12 sorry
                  thus " not (x inHIDDENR3 fieldRELAT-1K3 R &  not x inHIDDENR3 X)"
                    using A1 sorry
                qed
                have A3: "x inHIDDENR3 rngRELAT-1K2 R implies  not (x inHIDDENR3 fieldRELAT-1K3 R &  not x inHIDDENR3 X)"
                proof(rule impI)
                  assume "x inHIDDENR3 rngRELAT-1K2 R"
                  then have " ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 R"
                    using xtuple_0_def_13 sorry
                  thus " not (x inHIDDENR3 fieldRELAT-1K3 R &  not x inHIDDENR3 X)"
                    using A1 sorry
                qed
                assume "x inHIDDENR3 fieldRELAT-1K3 R"
                thus "x inHIDDENR3 X"
                  using A2 A3 xboole_0_def_3 sorry
              qed "sorry"
              have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 fieldRELAT-1K3 R"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 X"
                then have "[TARSKIK4 x,x ] inHIDDENR3 R"
                  using A1 sorry
                thus "x inHIDDENR3 fieldRELAT-1K3 R"
                  using relat_1_th_15 sorry
              qed "sorry"
              thus "X c=TARSKIR1 fieldRELAT-1K3 R"
                using tarski_def_3 sorry
            qed
            thus "fieldRELAT-1K3 R =XBOOLE-0R4 X"
              using tarski_def_3 xboole_0_def_10 sorry
          qed
          fix Y assume [ty]: "Y be setHIDDENM2"
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume A4: "Y inTARSKIR2 X & Z inTARSKIR2 X"
          show "[TARSKIK4 Y,Z ] inHIDDENR3 R implies Y c=TARSKIR1 Z"
          proof(rule impI)
            assume "[TARSKIK4 Y,Z ] inHIDDENR3 R"
            then have "?P(Y,Z)"
              using A1 sorry
            thus "Y c=TARSKIR1 Z"
               sorry
          qed
          show " not (Y c=TARSKIR1 Z &  not [TARSKIK4 Y,Z ] inHIDDENR3 R)"
            using A1 A4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RelationRELAT-1M1 holds  for it2 be RelationRELAT-1M1 holds (fieldRELAT-1K3 it1 =XBOOLE-0R4 X & ( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 it1 iff Y c=TARSKIR1 Z))) & (fieldRELAT-1K3 it2 =XBOOLE-0R4 X & ( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 it2 iff Y c=TARSKIR1 Z))) implies it1 =HIDDENR1 it2"
    proof-
      have " for R1 be RelationRELAT-1M1 holds  for R2 be RelationRELAT-1M1 holds fieldRELAT-1K3 R1 =XBOOLE-0R4 X & (( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 R1 iff Y c=TARSKIR1 Z)) & (fieldRELAT-1K3 R2 =XBOOLE-0R4 X & ( for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 R2 iff Y c=TARSKIR1 Z)))) implies R1 =HIDDENR1 R2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix R1 assume [ty]: "R1 be RelationRELAT-1M1"
        fix R2 assume [ty]: "R2 be RelationRELAT-1M1"
        assume A5: "fieldRELAT-1K3 R1 =XBOOLE-0R4 X"
          and A6: " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 R1 iff Y c=TARSKIR1 Z)"
          and A7: "fieldRELAT-1K3 R2 =XBOOLE-0R4 X"
          and A8: " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 X & Z inTARSKIR2 X implies ([TARSKIK4 Y,Z ] inHIDDENR3 R2 iff Y c=TARSKIR1 Z)"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 R1 implies [TARSKIK4 x,y ] inHIDDENR3 R2) & ([TARSKIK4 x,y ] inHIDDENR3 R2 implies [TARSKIK4 x,y ] inHIDDENR3 R1)"
        proof(rule ballI,rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          show "[TARSKIK4 x,y ] inHIDDENR3 R1 implies [TARSKIK4 x,y ] inHIDDENR3 R2"
          proof(rule impI)
            assume A9: "[TARSKIK4 x,y ] inHIDDENR3 R1"
            then have A10: "x inHIDDENR3 fieldRELAT-1K3 R1 & y inHIDDENR3 fieldRELAT-1K3 R1"
              using relat_1_th_15 sorry
            have 
              [ty]:"x be setHIDDENM2" and
              [ty]:"y be setHIDDENM2"
              using tarski_th_1 sorry
            have "x c=TARSKIR1 y"
              using A5 A6 A9 A10 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 R2"
              using A5 A8 A10 sorry
          qed
          assume A11: "[TARSKIK4 x,y ] inHIDDENR3 R2"
          then have A12: "x inHIDDENR3 fieldRELAT-1K3 R2 & y inHIDDENR3 fieldRELAT-1K3 R2"
            using relat_1_th_15 sorry
          have 
            [ty]:"x be setHIDDENM2" and
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          have "x c=TARSKIR1 y"
            using A7 A8 A11 A12 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R1"
            using A6 A7 A12 sorry
        qed "sorry"
        thus "R1 =HIDDENR1 R2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

(*\$CT 6*)
mtheorem wellord2_cl_1:
  mlet "X be setHIDDENM2"
"cluster RelInclWELLORD2K1 X as-term-is reflexiveRELAT-2V1"
proof
(*coherence*)
  show "RelInclWELLORD2K1 X be reflexiveRELAT-2V1"
  proof-
    have A1: "fieldRELAT-1K3 (RelInclWELLORD2K1 X) =XBOOLE-0R4 X"
      using wellord2_def_1 sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X) implies [TARSKIK4 a,a ] inHIDDENR3 RelInclWELLORD2K1 X"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume "a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X)"
      thus "[TARSKIK4 a,a ] inHIDDENR3 RelInclWELLORD2K1 X"
        using A1 wellord2_def_1 sorry
    qed "sorry"
    thus "RelInclWELLORD2K1 X be reflexiveRELAT-2V1"
      using relat_2_def_1 relat_2_def_9 sorry
  qed
qed "sorry"

mtheorem wellord2_cl_2:
  mlet "X be setHIDDENM2"
"cluster RelInclWELLORD2K1 X as-term-is transitiveRELAT-2V8"
proof
(*coherence*)
  show "RelInclWELLORD2K1 X be transitiveRELAT-2V8"
  proof-
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X) & (b inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X) & (c inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X) & ([TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X & [TARSKIK4 b,c ] inHIDDENR3 RelInclWELLORD2K1 X))) implies [TARSKIK4 a,c ] inHIDDENR3 RelInclWELLORD2K1 X"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X)"
        and A3: "b inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X)"
        and A4: "c inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X)"
        and A5: "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X & [TARSKIK4 b,c ] inHIDDENR3 RelInclWELLORD2K1 X"
      have 
        [ty]:"a be setHIDDENM2" and
        [ty]:"b be setHIDDENM2" and
        [ty]:"c be setHIDDENM2"
        using tarski_th_1 sorry
      have "fieldRELAT-1K3 (RelInclWELLORD2K1 X) =XBOOLE-0R4 X"
        using wellord2_def_1 sorry
      then have "a c=TARSKIR1 b & b c=TARSKIR1 c"
        using A2 A3 A4 A5 wellord2_def_1 sorry
      then have A6: "a c=TARSKIR1 c"
         sorry
      have "a inTARSKIR2 X & c inTARSKIR2 X"
        using A2 A4 wellord2_def_1 sorry
      thus "[TARSKIK4 a,c ] inHIDDENR3 RelInclWELLORD2K1 X"
        using A6 wellord2_def_1 sorry
    qed "sorry"
    thus "RelInclWELLORD2K1 X be transitiveRELAT-2V8"
      using relat_2_def_8 relat_2_def_16 sorry
  qed
qed "sorry"

mtheorem wellord2_cl_3:
  mlet "X be setHIDDENM2"
"cluster RelInclWELLORD2K1 X as-term-is antisymmetricRELAT-2V4"
proof
(*coherence*)
  show "RelInclWELLORD2K1 X be antisymmetricRELAT-2V4"
  proof-
    have A7: "fieldRELAT-1K3 (RelInclWELLORD2K1 X) =XBOOLE-0R4 X"
      using wellord2_def_1 sorry
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ((a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X) & b inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X)) & [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X) & [TARSKIK4 b,a ] inHIDDENR3 RelInclWELLORD2K1 X implies a =HIDDENR1 b"
    proof(rule ballI,rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A8: "((a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X) & b inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 X)) & [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X) & [TARSKIK4 b,a ] inHIDDENR3 RelInclWELLORD2K1 X"
      have 
        [ty]:"a be setHIDDENM2" and
        [ty]:"b be setHIDDENM2"
        using tarski_th_1 sorry
      have "a c=TARSKIR1 b & b c=TARSKIR1 a"
        using A7 wellord2_def_1 A8 sorry
      thus "a =HIDDENR1 b"
        using xboole_0_def_10 sorry
    qed "sorry"
    thus "RelInclWELLORD2K1 X be antisymmetricRELAT-2V4"
      using relat_2_def_4 relat_2_def_12 sorry
  qed
qed "sorry"

mtheorem wellord2_cl_4:
  mlet "A be OrdinalORDINAL1M3"
"cluster RelInclWELLORD2K1 A as-term-is connectedRELAT-2V6"
proof
(*coherence*)
  show "RelInclWELLORD2K1 A be connectedRELAT-2V6"
  proof-
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds (a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 A) & b inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 A)) & a <>HIDDENR2 b implies  not ( not [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 A &  not [TARSKIK4 b,a ] inHIDDENR3 RelInclWELLORD2K1 A)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A1: "a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 A) & b inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 A)"
        and "a <>HIDDENR2 b"
      have A2: "fieldRELAT-1K3 (RelInclWELLORD2K1 A) =XBOOLE-0R4 A"
        using wellord2_def_1 sorry
      then obtain Y Z where 
        [ty]:"Y be OrdinalORDINAL1M3" and YDef:"Y = a" and
        [ty]:"Z be OrdinalORDINAL1M3" and ZDef:"Z = b"
        using A1 sorry
      have "Y c=ORDINAL1R1 Z or Z c=ORDINAL1R1 Y"
         sorry
      thus " not ( not [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 A &  not [TARSKIK4 b,a ] inHIDDENR3 RelInclWELLORD2K1 A)"
        using A1 A2 wellord2_def_1 sorry
    qed "sorry"
    thus "RelInclWELLORD2K1 A be connectedRELAT-2V6"
      using relat_2_def_6 relat_2_def_14 sorry
  qed
qed "sorry"

mtheorem wellord2_cl_5:
  mlet "A be OrdinalORDINAL1M3"
"cluster RelInclWELLORD2K1 A as-term-is well-foundedWELLORD1V1"
proof
(*coherence*)
  show "RelInclWELLORD2K1 A be well-foundedWELLORD1V1"
  proof-
    have " for Y be setHIDDENM2 holds Y c=TARSKIR1 fieldRELAT-1K3 (RelInclWELLORD2K1 A) & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar2 be objectHIDDENM1 st tVar2 inTARSKIR2 Y & (RelInclWELLORD2K1 A)-SegWELLORD1K1 tVar2 missesXBOOLE-0R1 Y)"
    proof(rule ballI,rule impMI ,rule impI)
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume A3: "Y c=TARSKIR1 fieldRELAT-1K3 (RelInclWELLORD2K1 A)"
        and A4: "Y <>HIDDENR2 {}XBOOLE-0K1"
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 Y"
      let ?x = "the ElementSUBSET-1M1-of Y"
      have A5: "fieldRELAT-1K3 (RelInclWELLORD2K1 A) =XBOOLE-0R4 A"
        using wellord2_def_1 sorry
      then have "?x inTARSKIR2 A"
        using A3 A4 sorry
      then obtain x where 
        [ty]:"x be OrdinalORDINAL1M3" and xDef:"x = ?x"
         sorry
      have "x inTARSKIR2 Y"
        using A4 sorry
      then have A6: " ex B be OrdinalORDINAL1M3 st ?P(B)"
         sorry
      obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A7: "?P(B) & ( for C be OrdinalORDINAL1M3 holds ?P(C) implies B c=ORDINAL1R1 C)"
        using ordinal1_sch_1 A6 sorry
      obtain x where 
        [ty]:"x be setHIDDENM2" and xDef:"x = B"
         sorry
      show " ex tVar2 be objectHIDDENM1 st tVar2 inTARSKIR2 Y & (RelInclWELLORD2K1 A)-SegWELLORD1K1 tVar2 missesXBOOLE-0R1 Y"
      proof(rule bexI[of _ "x"],rule conjMI)
        show "x inTARSKIR2 Y"
          using A7 sorry
        let ?y = "the ElementSUBSET-1M1-of (RelInclWELLORD2K1 A)-SegWELLORD1K1 x /\\XBOOLE-0K3 Y"
        have "(RelInclWELLORD2K1 A)-SegWELLORD1K1 x /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1 implies  False "
        proof(rule impI)
          assume A8: "(RelInclWELLORD2K1 A)-SegWELLORD1K1 x /\\XBOOLE-0K3 Y <>HIDDENR2 {}XBOOLE-0K1"
          then have A9: "?y inTARSKIR2 Y"
            using xboole_0_def_4 sorry
          then obtain C where 
            [ty]:"C be OrdinalORDINAL1M3" and CDef:"C = ?y"
            using A3 A5 sorry
          have A10: "?y inTARSKIR2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 x"
            using A8 xboole_0_def_4 sorry
          then have "[TARSKIK4 ?y,x ] inHIDDENR3 RelInclWELLORD2K1 A"
            using wellord1_th_1 sorry
          then have A11: "C c=ORDINAL1R1 B"
            using A3 A5 A7 A9 wellord2_def_1 sorry
          have A12: "?y <>HIDDENR2 x"
            using A10 wellord1_th_1 sorry
          have "B c=ORDINAL1R1 C"
            using A7 A9 sorry
          thus " False "
            using A12 A11 sorry
        qed
        thus "(RelInclWELLORD2K1 A)-SegWELLORD1K1 x missesXBOOLE-0R1 Y"
          using xboole_0_def_7 sorry
      qed "sorry"
    qed "sorry"
    thus "RelInclWELLORD2K1 A be well-foundedWELLORD1V1"
      using wellord1_def_2 sorry
  qed
qed "sorry"

mtheorem wellord2_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X implies RelInclWELLORD2K1 X  |-2WELLORD1K2 Y =RELAT-1R1 RelInclWELLORD2K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y c=TARSKIR1 X implies RelInclWELLORD2K1 X  |-2WELLORD1K2 Y =RELAT-1R1 RelInclWELLORD2K1 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 X"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X  |-2WELLORD1K2 Y implies [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 Y) & ([TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 Y implies [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X  |-2WELLORD1K2 Y)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      show "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X  |-2WELLORD1K2 Y implies [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 Y"
      proof(rule impI)
        assume A2: "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X  |-2WELLORD1K2 Y"
        then have "[TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 Y,Y :]"
          using xboole_0_def_4 sorry
        then have A3: "a inHIDDENR3 Y & b inHIDDENR3 Y"
          using zfmisc_1_th_87 sorry
        have 
          [ty]:"a be setHIDDENM2" and
          [ty]:"b be setHIDDENM2"
          using tarski_th_1 sorry
        have "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X"
          using A2 xboole_0_def_4 sorry
        then have "a c=TARSKIR1 b"
          using A1 A3 wellord2_def_1 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 Y"
          using A3 wellord2_def_1 sorry
      qed
      assume A4: "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 Y"
      then have A5: "a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 Y) & b inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 Y)"
        using relat_1_th_15 sorry
      have 
        [ty]:"a be setHIDDENM2" and
        [ty]:"b be setHIDDENM2"
        using tarski_th_1 sorry
      have A6: "fieldRELAT-1K3 (RelInclWELLORD2K1 Y) =XBOOLE-0R4 Y"
        using wellord2_def_1 sorry
      then have "a c=TARSKIR1 b"
        using A4 A5 wellord2_def_1 sorry
      then have A7: "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X"
        using A1 A5 A6 wellord2_def_1 sorry
      have "[TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 Y,Y :]"
        using A5 A6 zfmisc_1_th_87 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X  |-2WELLORD1K2 Y"
        using A7 xboole_0_def_4 sorry
    qed "sorry"
    thus "RelInclWELLORD2K1 X  |-2WELLORD1K2 Y =RELAT-1R1 RelInclWELLORD2K1 Y"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem wellord2_th_8:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies RelInclWELLORD2K1 X be well-orderingWELLORD1V2"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds  not (X c=TARSKIR1 A &  not RelInclWELLORD2K1 X be well-orderingWELLORD1V2)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    have "RelInclWELLORD2K1 A  |-2WELLORD1K2 X be well-orderingWELLORD1V2"
      using wellord1_th_25 sorry
    thus " not (X c=TARSKIR1 A &  not RelInclWELLORD2K1 X be well-orderingWELLORD1V2)"
      using wellord2_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve H for "FunctionFUNCT-1M1"
mtheorem wellord2_th_9:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies A =XBOOLE-0R4 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies A =XBOOLE-0R4 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "A inTARSKIR2 B"
    have "( for a be objectHIDDENM1 holds a inHIDDENR3 A implies a inHIDDENR3 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A) & (RelInclWELLORD2K1 B)-SegWELLORD1K1 A c=TARSKIR1 A"
    proof(rule conjMI)
      show " for a be objectHIDDENM1 holds a inHIDDENR3 A implies a inHIDDENR3 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A2: "a inHIDDENR3 A"
        then obtain C where 
          [ty]:"C be OrdinalORDINAL1M3" and CDef:"C = a"
           sorry
        have 
          [ty]:"a be setHIDDENM2"
          using tarski_th_1 sorry
        have " not a inTARSKIR2 a"
           sorry
        then have A3: "a <>HIDDENR2 A"
          using A2 sorry
        have A4: "A c=ORDINAL1R1 B"
          using A1 ordinal1_def_2 sorry
        have "C c=ORDINAL1R1 A"
          using A2 ordinal1_def_2 sorry
        then have "[TARSKIK4 C,A ] inHIDDENR3 RelInclWELLORD2K1 B"
          using A1 A2 A4 wellord2_def_1 sorry
        thus "a inHIDDENR3 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
          using A3 wellord1_th_1 sorry
      qed "sorry"
      have " for a be objectHIDDENM1 holds a inHIDDENR3 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A implies a inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A5: "a inHIDDENR3 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
        then have A6: "a <>HIDDENR2 A"
          using wellord1_th_1 sorry
        have A7: "[TARSKIK4 a,A ] inHIDDENR3 RelInclWELLORD2K1 B"
          using A5 wellord1_th_1 sorry
        then have A8: "a inHIDDENR3 fieldRELAT-1K3 (RelInclWELLORD2K1 B)"
          using relat_1_th_15 sorry
        have A9: "fieldRELAT-1K3 (RelInclWELLORD2K1 B) =XBOOLE-0R4 B"
          using wellord2_def_1 sorry
        then obtain C where 
          [ty]:"C be OrdinalORDINAL1M3" and CDef:"C = a"
          using A8 sorry
        have "C c=ORDINAL1R1 A"
          using A1 A7 A8 A9 wellord2_def_1 sorry
        then have "C c<XBOOLE-0R2 A"
          using A6 sorry
        thus "a inHIDDENR3 A"
          using ordinal1_th_11 sorry
      qed "sorry"
      thus "(RelInclWELLORD2K1 B)-SegWELLORD1K1 A c=TARSKIR1 A"
        using tarski_def_3 sorry
    qed
    thus "A =XBOOLE-0R4 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem wellord2_th_10:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (RelInclWELLORD2K1 A,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4 implies A =XBOOLE-0R4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (RelInclWELLORD2K1 A,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4 implies (A <>HIDDENR2 B implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have A1: "fieldRELAT-1K3 (RelInclWELLORD2K1 A) =XBOOLE-0R4 A"
      using wellord2_def_1 sorry
    assume A2: "(RelInclWELLORD2K1 A,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
    have A3: "A inTARSKIR2 B implies  False "
    proof(rule impI)
      have A4: "fieldRELAT-1K3 (RelInclWELLORD2K1 B) =XBOOLE-0R4 B"
        using wellord2_def_1 sorry
      assume A5: "A inTARSKIR2 B"
      then have "A =XBOOLE-0R4 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
        using wellord2_th_9 sorry
      then have "RelInclWELLORD2K1 A =RELAT-1R1 RelInclWELLORD2K1 B  |-2WELLORD1K2 (RelInclWELLORD2K1 B)-SegWELLORD1K1 A"
        using A4 wellord2_th_7 wellord1_th_9 sorry
      thus " False "
        using A2 A5 A4 wellord1_th_40 wellord1_th_46 sorry
    qed
    assume "A <>HIDDENR2 B"
    then have A6: "A inTARSKIR2 B or B inTARSKIR2 A"
      using ordinal1_th_14 sorry
    then have "B =XBOOLE-0R4 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B"
      using A3 wellord2_th_9 sorry
    then have "RelInclWELLORD2K1 B =RELAT-1R1 RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B"
      using A1 wellord2_th_7 wellord1_th_9 sorry
    thus " False "
      using A2 A6 A3 A1 wellord1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem wellord2_th_11:
" for R be RelationRELAT-1M1 holds  for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4 & (R,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4 implies A =XBOOLE-0R4 B"
proof-
  have " for R be RelationRELAT-1M1 holds  for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4 & (R,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4 implies A =XBOOLE-0R4 B"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "(R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
      and A2: "(R,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
    have "(RelInclWELLORD2K1 A,R)are-isomorphicWELLORD1R4"
      using A1 wellord1_th_40 sorry
    thus "A =XBOOLE-0R4 B"
      using A2 wellord2_th_10 wellord1_th_42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem wellord2_th_12:
" for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 & ( for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies ( ex A be OrdinalORDINAL1M3 st (R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)) implies ( ex A be OrdinalORDINAL1M3 st (R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)"
proof-
  have " for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 implies (( for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies ( ex A be OrdinalORDINAL1M3 st (R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)) implies ( ex tVar4 be OrdinalORDINAL1M3 st (R,RelInclWELLORD2K1 tVar4)are-isomorphicWELLORD1R4))"
  proof(rule ballI,rule impI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R be well-orderingWELLORD1V2"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for A be OrdinalORDINAL1M3 holds A =HIDDENR1 Lamb2 iff (R  |-2WELLORD1K2 R -SegWELLORD1K1 Lamb1,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
    assume A2: " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies ( ex A be OrdinalORDINAL1M3 st (R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)"
    have A3: " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies ( ex b be objectHIDDENM1 st ?P(a,b))"
    proof-
      have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies ( ex tVar3 be objectHIDDENM1 st  for B be OrdinalORDINAL1M3 holds (B =XBOOLE-0R4 tVar3 implies (R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4) & ((R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4 implies B =HIDDENR1 tVar3))"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 fieldRELAT-1K3 R"
        then obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A4: "(R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
          using A2 sorry
        obtain b where 
          [ty]:"b be setHIDDENM2" and bDef:"b = A"
           sorry
        show " ex tVar3 be objectHIDDENM1 st  for B be OrdinalORDINAL1M3 holds (B =XBOOLE-0R4 tVar3 implies (R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4) & ((R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4 implies B =HIDDENR1 tVar3)"
        proof(rule bexI[of _ "b"],rule ballI,rule conjMI,rule impI)
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          show "B =XBOOLE-0R4 b implies (R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
            using A4 sorry
          assume "(R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
          thus "B =HIDDENR1 b"
            using A4 wellord2_th_11 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  for d be objectHIDDENM1 holds (b inHIDDENR3 fieldRELAT-1K3 R & ?P(b,c)) & ?P(b,d) implies c =HIDDENR1 d"
    proof-
      have " for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds  for d be objectHIDDENM1 holds b inHIDDENR3 fieldRELAT-1K3 R & (( for A be OrdinalORDINAL1M3 holds A =HIDDENR1 c iff (R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4) & ( for B be OrdinalORDINAL1M3 holds B =HIDDENR1 d iff (R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4)) implies c =HIDDENR1 d"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix b assume [ty]: "b be objectHIDDENM1"
        fix c assume [ty]: "c be objectHIDDENM1"
        fix d assume [ty]: "d be objectHIDDENM1"
        assume A6: "b inHIDDENR3 fieldRELAT-1K3 R"
          and A7: " for A be OrdinalORDINAL1M3 holds A =HIDDENR1 c iff (R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
          and A8: " for B be OrdinalORDINAL1M3 holds B =HIDDENR1 d iff (R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A9: "(R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
          using A2 A6 sorry
        have "A =HIDDENR1 c"
          using A7 A9 sorry
        thus "c =HIDDENR1 d"
          using A8 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain H where
      [ty]:"H be FunctionFUNCT-1M1" and 
      A10: "domRELAT-1K1 H =XBOOLE-0R4 fieldRELAT-1K3 R & ( for b be objectHIDDENM1 holds b inHIDDENR3 fieldRELAT-1K3 R implies ?P(b,H .FUNCT-1K1 b))"
      using funct_1_sch_2 A5 A3 sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 rngFUNCT-1K2 H implies a be OrdinalORDINAL1M3"
    proof-
      have " for b be objectHIDDENM1 holds b inHIDDENR3 rngFUNCT-1K2 H implies b be OrdinalORDINAL1M3"
      proof(rule ballI,rule impI)
        fix b assume [ty]: "b be objectHIDDENM1"
        assume "b inHIDDENR3 rngFUNCT-1K2 H"
        then obtain c where
          [ty]:"c be objectHIDDENM1" and 
          A11: "c inHIDDENR3 domRELAT-1K1 H"and A12: "b =HIDDENR1 H .FUNCT-1K1 c"
          using funct_1_def_3 sorry
        have " ex A be OrdinalORDINAL1M3 st (R  |-2WELLORD1K2 R -SegWELLORD1K1 c,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
          using A2 A10 A11 sorry
        thus "b be OrdinalORDINAL1M3"
          using A10 A11 A12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then obtain C where
      [ty]:"C be OrdinalORDINAL1M3" and 
      A13: "rngFUNCT-1K2 H c=TARSKIR1 C"
      using ordinal1_th_24 sorry
    have A14: " for b be objectHIDDENM1 holds b inHIDDENR3 rngFUNCT-1K2 H implies ( for c be objectHIDDENM1 holds [TARSKIK4 c,b ] inHIDDENR3 RelInclWELLORD2K1 C implies c inHIDDENR3 rngFUNCT-1K2 H)"
    proof(rule ballI,rule impI,rule ballI,rule impI)
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A15: "b inHIDDENR3 rngFUNCT-1K2 H"
      then obtain b9 where
        [ty]:"b9 be objectHIDDENM1" and 
        A16: "b9 inHIDDENR3 domRELAT-1K1 H"and A17: "b =HIDDENR1 H .FUNCT-1K1 b9"
        using funct_1_def_3 sorry
      let ?V = "R -SegWELLORD1K1 b9"
      let ?P = "R  |-2WELLORD1K2 ?V"
      obtain A where
        [ty]:"A be OrdinalORDINAL1M3" and 
        A18: "(?P,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
        using A2 A10 A16 sorry
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A19: "[TARSKIK4 c,b ] inHIDDENR3 RelInclWELLORD2K1 C"
      have A20: "A =HIDDENR1 b"
        using A10 A16 A17 A18 sorry
      have "c <>HIDDENR2 b implies c inHIDDENR3 rngFUNCT-1K2 H"
      proof(rule impI)
        have A21: "C =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 C)"
          using wellord2_def_1 sorry
        then have A22: "c inHIDDENR3 C"
          using A19 relat_1_th_15 sorry
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = c"
           sorry
        have "b inHIDDENR3 C"
          using A19 A21 relat_1_th_15 sorry
        then have A23: "B c=ORDINAL1R1 A"
          using A20 A19 A22 wellord2_def_1 sorry
        then have A24: "RelInclWELLORD2K1 A  |-2WELLORD1K2 B =RELAT-1R1 RelInclWELLORD2K1 B"
          using wellord2_th_7 sorry
        assume "c <>HIDDENR2 b"
        then have A25: "B c<XBOOLE-0R2 A"
          using A20 A23 sorry
        then have A26: "B =XBOOLE-0R4 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B"
          using wellord2_th_9 ordinal1_th_11 sorry
        have A27: "A =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 A)"
          using wellord2_def_1 sorry
        have "(RelInclWELLORD2K1 A,?P)are-isomorphicWELLORD1R4"
          using A18 wellord1_th_40 sorry
        then have "canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 A,?P) is-isomorphism-ofWELLORD1R3(RelInclWELLORD2K1 A,?P)"
          using wellord1_def_9 sorry
        then obtain d where
          [ty]:"d be objectHIDDENM1" and 
          A28: "d inHIDDENR3 fieldRELAT-1K3 ?P"and A29: "(RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B,?P  |-2WELLORD1K2 ?P -SegWELLORD1K1 d)are-isomorphicWELLORD1R4"
          using A25 A27 ordinal1_th_11 wellord1_th_50 sorry
        have A30: "d inHIDDENR3 fieldRELAT-1K3 R"
          using A28 wellord1_th_12 sorry
        have A31: "?P -SegWELLORD1K1 d =XBOOLE-0R4 R -SegWELLORD1K1 d"
          using A1 A28 wellord1_th_12 wellord1_th_27 sorry
        have "d inHIDDENR3 ?V"
          using A28 wellord1_th_12 sorry
        then have "[TARSKIK4 d,b9 ] inHIDDENR3 R"
          using wellord1_th_1 sorry
        then have "R -SegWELLORD1K1 d c=TARSKIR1 R -SegWELLORD1K1 b9"
          using A1 A10 A16 A30 wellord1_th_29 sorry
        then have "(RelInclWELLORD2K1 B,R  |-2WELLORD1K2 R -SegWELLORD1K1 d)are-isomorphicWELLORD1R4"
          using A29 A26 A24 A31 wellord1_th_22 sorry
        then have "(R  |-2WELLORD1K2 R -SegWELLORD1K1 d,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
          using wellord1_th_40 sorry
        then have "B =XBOOLE-0R4 H .FUNCT-1K1 d"
          using A10 A30 sorry
        thus "c inHIDDENR3 rngFUNCT-1K2 H"
          using A10 A30 funct_1_def_3 sorry
      qed
      thus "c inHIDDENR3 rngFUNCT-1K2 H"
        using A15 sorry
    qed "sorry"
    have A32: "( ex a be objectHIDDENM1 st a inHIDDENR3 C & rngFUNCT-1K2 H =XBOOLE-0R4 (RelInclWELLORD2K1 C)-SegWELLORD1K1 a) implies rngFUNCT-1K2 H be OrdinalORDINAL1M3"
      using wellord2_th_9 sorry
    have "C =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 C) & RelInclWELLORD2K1 C be well-orderingWELLORD1V2"
      using wellord2_def_1 sorry
    then obtain A where 
      [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = rngFUNCT-1K2 H"
      using A13 A14 A32 wellord1_th_28 sorry
    show " ex tVar4 be OrdinalORDINAL1M3 st (R,RelInclWELLORD2K1 tVar4)are-isomorphicWELLORD1R4"
    proof(rule bexI[of _ "A"])
      have "domRELAT-1K1 H =XBOOLE-0R4 fieldRELAT-1K3 R & (rngFUNCT-1K2 H =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 A) & (H be one-to-oneFUNCT-1V2 & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 R implies (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 H .FUNCT-1K1 a,H .FUNCT-1K1 b ] inHIDDENR3 RelInclWELLORD2K1 A) & (a inHIDDENR3 fieldRELAT-1K3 R & (b inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 H .FUNCT-1K1 a,H .FUNCT-1K1 b ] inHIDDENR3 RelInclWELLORD2K1 A) implies ( not [TARSKIK4 a,b ] inHIDDENR3 R implies  False )))))"
      proof(rule conjMI,rule conjMI,rule conjMI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI,rule impI)
        show "domRELAT-1K1 H =XBOOLE-0R4 fieldRELAT-1K3 R"
          using A10 sorry
        show "rngFUNCT-1K2 H =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 A)"
          using wellord2_def_1 sorry
        have A33: " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 H implies H .FUNCT-1K1 a be OrdinalORDINAL1M3"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 H implies H .FUNCT-1K1 a be OrdinalORDINAL1M3"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 domRELAT-1K1 H"
            then have "H .FUNCT-1K1 a inTARSKIR2 A"
              using funct_1_def_3 sorry
            thus "H .FUNCT-1K1 a be OrdinalORDINAL1M3"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show A34: "H be one-to-oneFUNCT-1V2"
        proof-
          have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 H & (b inHIDDENR3 domRELAT-1K1 H & H .FUNCT-1K1 a =XBOOLE-0R4 H .FUNCT-1K1 b) implies a =HIDDENR1 b"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            fix b assume [ty]: "b be objectHIDDENM1"
            assume A35: "a inHIDDENR3 domRELAT-1K1 H"
              and A36: "b inHIDDENR3 domRELAT-1K1 H"
              and A37: "H .FUNCT-1K1 a =XBOOLE-0R4 H .FUNCT-1K1 b"
            obtain B where 
              [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = H .FUNCT-1K1 a"
              using A33 A35 sorry
            have "(R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
              using A10 A36 A37 sorry
            then have A38: "(RelInclWELLORD2K1 B,R  |-2WELLORD1K2 R -SegWELLORD1K1 b)are-isomorphicWELLORD1R4"
              using wellord1_th_40 sorry
            have "(R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 B)are-isomorphicWELLORD1R4"
              using A10 A35 sorry
            then have "(R  |-2WELLORD1K2 R -SegWELLORD1K1 a,R  |-2WELLORD1K2 R -SegWELLORD1K1 b)are-isomorphicWELLORD1R4"
              using A38 wellord1_th_42 sorry
            thus "a =HIDDENR1 b"
              using A1 A10 A35 A36 wellord1_th_47 sorry
          qed "sorry"
          thus "H be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        show "[TARSKIK4 a,b ] inHIDDENR3 R implies (a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R) & [TARSKIK4 H .FUNCT-1K1 a,H .FUNCT-1K1 b ] inHIDDENR3 RelInclWELLORD2K1 A"
        proof(rule impI,rule conjMI)
          let ?Z = "R -SegWELLORD1K1 b"
          let ?P = "R  |-2WELLORD1K2 ?Z"
          have A39: "A =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 A) & ?P be well-orderingWELLORD1V2"
            using A1 wellord2_def_1 wellord1_th_25 sorry
          assume A40: "[TARSKIK4 a,b ] inHIDDENR3 R"
          thus A41: "a inHIDDENR3 fieldRELAT-1K3 R & b inHIDDENR3 fieldRELAT-1K3 R"
            using relat_1_th_15 sorry
          then obtain A9 B9 where 
            [ty]:"A9 be OrdinalORDINAL1M3" and A9Def:"A9 = H .FUNCT-1K1 a" and
            [ty]:"B9 be OrdinalORDINAL1M3" and B9Def:"B9 = H .FUNCT-1K1 b"
            using A10 A33 sorry
          have A42: "(R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 B9)are-isomorphicWELLORD1R4"
            using A10 A41 sorry
          have A43: "A9 inTARSKIR2 A"
            using A10 A41 funct_1_def_3 sorry
          have A44: "B9 inTARSKIR2 A"
            using A10 A41 funct_1_def_3 sorry
          have A45: "(R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 A9)are-isomorphicWELLORD1R4"
            using A10 A41 sorry
          have "a <>HIDDENR2 b implies [TARSKIK4 A9,B9 ] inHIDDENR3 RelInclWELLORD2K1 A"
          proof(rule impI)
            assume "a <>HIDDENR2 b"
            then have A46: "a inHIDDENR3 ?Z"
              using A40 wellord1_th_1 sorry
            then have A47: "?P -SegWELLORD1K1 a =XBOOLE-0R4 R -SegWELLORD1K1 a"
              using A1 wellord1_th_27 sorry
            have "?Z c=TARSKIR1 fieldRELAT-1K3 R"
              using wellord1_th_9 sorry
            then have A48: "a inHIDDENR3 fieldRELAT-1K3 ?P"
              using A1 A46 wellord1_th_31 sorry
            have "A9 c=ORDINAL1R1 A"
              using A43 ordinal1_def_2 sorry
            then have A49: "RelInclWELLORD2K1 A  |-2WELLORD1K2 A9 =RELAT-1R1 RelInclWELLORD2K1 A9"
              using wellord2_th_7 sorry
            have "A9 =XBOOLE-0R4 (RelInclWELLORD2K1 A)-SegWELLORD1K1 A9 & R -SegWELLORD1K1 a c=TARSKIR1 R -SegWELLORD1K1 b"
              using A1 A40 A41 A43 wellord2_th_9 wellord1_th_29 sorry
            then have A50: "(?P  |-2WELLORD1K2 ?P -SegWELLORD1K1 a,RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 A9)are-isomorphicWELLORD1R4"
              using A45 A49 A47 wellord1_th_22 sorry
            have "B9 =XBOOLE-0R4 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B9 & B9 c=ORDINAL1R1 A"
              using A44 wellord2_th_9 ordinal1_def_2 sorry
            then have "(?P,RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B9)are-isomorphicWELLORD1R4"
              using A42 wellord2_th_7 sorry
            thus "[TARSKIK4 A9,B9 ] inHIDDENR3 RelInclWELLORD2K1 A"
              using A43 A44 A39 A48 A50 wellord1_th_51 sorry
          qed
          thus "[TARSKIK4 H .FUNCT-1K1 a,H .FUNCT-1K1 b ] inHIDDENR3 RelInclWELLORD2K1 A"
            using A43 wellord2_def_1 sorry
        qed
        assume A51: "a inHIDDENR3 fieldRELAT-1K3 R"
          and A52: "b inHIDDENR3 fieldRELAT-1K3 R"
          and A53: "[TARSKIK4 H .FUNCT-1K1 a,H .FUNCT-1K1 b ] inHIDDENR3 RelInclWELLORD2K1 A"
        assume A54: " not [TARSKIK4 a,b ] inHIDDENR3 R"
        have "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R"
          using A1 relat_2_def_9 sorry
        then have A55: "a <>HIDDENR2 b"
          using A51 A54 sorry
        have "R is-connected-inRELAT-2R6 fieldRELAT-1K3 R"
          using A1 relat_2_def_14 sorry
        then have A56: "[TARSKIK4 b,a ] inHIDDENR3 R"
          using A51 A52 A54 A55 sorry
        then have A57: "R -SegWELLORD1K1 b c=TARSKIR1 R -SegWELLORD1K1 a"
          using A1 A51 A52 wellord1_th_29 sorry
        have A58: "RelInclWELLORD2K1 A is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 (RelInclWELLORD2K1 A)"
          using relat_2_def_12 sorry
        have A59: "A =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 A)"
          using wellord2_def_1 sorry
        obtain A9 B9 where 
          [ty]:"A9 be OrdinalORDINAL1M3" and A9Def:"A9 = H .FUNCT-1K1 a" and
          [ty]:"B9 be OrdinalORDINAL1M3" and B9Def:"B9 = H .FUNCT-1K1 b"
          using A10 A33 A51 A52 sorry
        have A60: "(R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 A9)are-isomorphicWELLORD1R4"
          using A10 A51 sorry
        have A61: "(R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 B9)are-isomorphicWELLORD1R4"
          using A10 A52 sorry
        have A62: "B9 inTARSKIR2 A"
          using A10 A52 funct_1_def_3 sorry
        then have "B9 c=ORDINAL1R1 A"
          using ordinal1_def_2 sorry
        then have A63: "RelInclWELLORD2K1 A  |-2WELLORD1K2 B9 =RELAT-1R1 RelInclWELLORD2K1 B9"
          using wellord2_th_7 sorry
        let ?Z = "R -SegWELLORD1K1 a"
        let ?P = "R  |-2WELLORD1K2 ?Z"
        have A64: "A9 inTARSKIR2 A"
          using A10 A51 funct_1_def_3 sorry
        then have "A9 =XBOOLE-0R4 (RelInclWELLORD2K1 A)-SegWELLORD1K1 A9 & A9 c=ORDINAL1R1 A"
          using wellord2_th_9 ordinal1_def_2 sorry
        then have A65: "(?P,RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 A9)are-isomorphicWELLORD1R4"
          using A60 wellord2_th_7 sorry
        have A66: "b inHIDDENR3 ?Z"
          using A54 A56 wellord1_th_1 sorry
        then have A67: "?P -SegWELLORD1K1 b =XBOOLE-0R4 R -SegWELLORD1K1 b"
          using A1 wellord1_th_27 sorry
        have "B9 =XBOOLE-0R4 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B9"
          using A62 wellord2_th_9 sorry
        then have A68: "(?P  |-2WELLORD1K2 ?P -SegWELLORD1K1 b,RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 B9)are-isomorphicWELLORD1R4"
          using A61 A63 A67 A57 wellord1_th_22 sorry
        have "?Z c=TARSKIR1 fieldRELAT-1K3 R"
          using wellord1_th_9 sorry
        then have A69: "b inHIDDENR3 fieldRELAT-1K3 ?P"
          using A1 A66 wellord1_th_31 sorry
        have "?P be well-orderingWELLORD1V2"
          using A1 wellord1_th_25 sorry
        then have "[TARSKIK4 B9,A9 ] inHIDDENR3 RelInclWELLORD2K1 A"
          using A69 A64 A62 A59 A65 A68 wellord1_th_51 sorry
        then have "H .FUNCT-1K1 a =XBOOLE-0R4 H .FUNCT-1K1 b"
          using A53 A58 A64 A62 A59 sorry
        thus " False "
          using A10 A34 A51 A52 A55 sorry
      qed "sorry"
      then have "H is-isomorphism-ofWELLORD1R3(R,RelInclWELLORD2K1 A)"
        using wellord1_def_7 sorry
      thus "(R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
        using bexI[of _ "H"] wellord1_def_8 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem wellord2_th_13:
" for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 implies ( ex A be OrdinalORDINAL1M3 st (R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)"
proof-
  have " for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 implies  not ( for A be OrdinalORDINAL1M3 holds  not (R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)"
  proof(rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R be well-orderingWELLORD1V2"
    let ?P = "\<lambda>Lamb1.  ex A be OrdinalORDINAL1M3 st (R  |-2WELLORD1K2 R -SegWELLORD1K1 Lamb1,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
    obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A2: " for a be objectHIDDENM1 holds a inHIDDENR3 Z iff a inHIDDENR3 fieldRELAT-1K3 R & ?P(a)"
      using xboole_0_sch_1 sorry
    have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R & R -SegWELLORD1K1 a c=TARSKIR1 Z implies a inHIDDENR3 Z"
    proof(rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A3: "a inHIDDENR3 fieldRELAT-1K3 R"
        and A4: "R -SegWELLORD1K1 a c=TARSKIR1 Z"
      let ?P = "R  |-2WELLORD1K2 R -SegWELLORD1K1 a"
      have " for b be objectHIDDENM1 holds b inHIDDENR3 fieldRELAT-1K3 (R  |-2WELLORD1K2 R -SegWELLORD1K1 a) implies ( ex A be OrdinalORDINAL1M3 st ((R  |-2WELLORD1K2 R -SegWELLORD1K1 a) |-2WELLORD1K2 (R  |-2WELLORD1K2 R -SegWELLORD1K1 a)-SegWELLORD1K1 b,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)"
      proof(rule ballI,rule impI)
        fix b assume [ty]: "b be objectHIDDENM1"
        assume A5: "b inHIDDENR3 fieldRELAT-1K3 ?P"
        then have A6: "b inHIDDENR3 R -SegWELLORD1K1 a"
          using wellord1_th_12 sorry
        then have A7: "[TARSKIK4 b,a ] inHIDDENR3 R"
          using wellord1_th_1 sorry
        have "b inHIDDENR3 fieldRELAT-1K3 R"
          using A5 wellord1_th_12 sorry
        then have A8: "R -SegWELLORD1K1 b c=TARSKIR1 R -SegWELLORD1K1 a"
          using A1 A3 A7 wellord1_th_29 sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A9: "(R  |-2WELLORD1K2 R -SegWELLORD1K1 b,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
          using A2 A4 A6 sorry
        show " ex A be OrdinalORDINAL1M3 st ((R  |-2WELLORD1K2 R -SegWELLORD1K1 a) |-2WELLORD1K2 (R  |-2WELLORD1K2 R -SegWELLORD1K1 a)-SegWELLORD1K1 b,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
        proof(rule bexI[of _ "A"])
          have "?P -SegWELLORD1K1 b =XBOOLE-0R4 R -SegWELLORD1K1 b"
            using A1 A5 wellord1_th_12 wellord1_th_27 sorry
          thus "((R  |-2WELLORD1K2 R -SegWELLORD1K1 a) |-2WELLORD1K2 (R  |-2WELLORD1K2 R -SegWELLORD1K1 a)-SegWELLORD1K1 b,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
            using A9 A8 wellord1_th_22 sorry
        qed "sorry"
      qed "sorry"
      then have " ex A be OrdinalORDINAL1M3 st (?P,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
        using A1 wellord2_th_12 wellord1_th_25 sorry
      thus "a inHIDDENR3 Z"
        using A2 A3 sorry
    qed "sorry"
    then have "fieldRELAT-1K3 R c=TARSKIR1 Z"
      using A1 wellord1_th_33 sorry
    then have " for a be objectHIDDENM1 holds a inHIDDENR3 fieldRELAT-1K3 R implies ( ex A be OrdinalORDINAL1M3 st (R  |-2WELLORD1K2 R -SegWELLORD1K1 a,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)"
      using A2 sorry
    thus " not ( for A be OrdinalORDINAL1M3 holds  not (R,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4)"
      using A1 wellord2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef wellord2_def_2 ("order-type-ofWELLORD2K2  _ " [132]132 ) where
  mlet "R be RelationRELAT-1M1"
"assume R be well-orderingWELLORD1V2 func order-type-ofWELLORD2K2 R \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it. (R,RelInclWELLORD2K1 it)are-isomorphicWELLORD1R4"
proof-
  (*existence*)
    show "R be well-orderingWELLORD1V2 implies ( ex it be OrdinalORDINAL1M3 st (R,RelInclWELLORD2K1 it)are-isomorphicWELLORD1R4)"
    proof(rule impI)
      assume Assume: "R be well-orderingWELLORD1V2"
      have A1: "R be well-orderingWELLORD1V2"
        using Assume sorry
      show " ex it be OrdinalORDINAL1M3 st (R,RelInclWELLORD2K1 it)are-isomorphicWELLORD1R4"
        using A1 wellord2_th_13 sorry
    qed
  (*uniqueness*)
    show "R be well-orderingWELLORD1V2 implies ( for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds (R,RelInclWELLORD2K1 it1)are-isomorphicWELLORD1R4 & (R,RelInclWELLORD2K1 it2)are-isomorphicWELLORD1R4 implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "R be well-orderingWELLORD1V2"
      have A1: "R be well-orderingWELLORD1V2"
        using Assume sorry
      show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds (R,RelInclWELLORD2K1 it1)are-isomorphicWELLORD1R4 & (R,RelInclWELLORD2K1 it2)are-isomorphicWELLORD1R4 implies it1 =HIDDENR1 it2"
        using wellord2_th_11 sorry
    qed
qed "sorry"

mdef wellord2_def_3 (" _ is-order-type-ofWELLORD2R1  _ " [50,50]50 ) where
  mlet "A be OrdinalORDINAL1M3", "R be RelationRELAT-1M1"
"pred A is-order-type-ofWELLORD2R1 R means
  A =XBOOLE-0R4 order-type-ofWELLORD2K2 R"..

mtheorem wellord2_th_14:
" for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 A implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 A"
proof-
  have " for X be setHIDDENM2 holds  for A be OrdinalORDINAL1M3 holds X c=TARSKIR1 A implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 A"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "X c=TARSKIR1 A"
    then have A2: "RelInclWELLORD2K1 A  |-2WELLORD1K2 X =RELAT-1R1 RelInclWELLORD2K1 X"
      using wellord2_th_7 sorry
    have A3: "RelInclWELLORD2K1 X be well-orderingWELLORD1V2"
      using A1 wellord2_th_8 sorry
    have A4: "(RelInclWELLORD2K1 A,RelInclWELLORD2K1 A  |-2WELLORD1K2 X)are-isomorphicWELLORD1R4 implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 A"
    proof(rule impI)
      assume "(RelInclWELLORD2K1 A,RelInclWELLORD2K1 A  |-2WELLORD1K2 X)are-isomorphicWELLORD1R4"
      then have "(RelInclWELLORD2K1 X,RelInclWELLORD2K1 A)are-isomorphicWELLORD1R4"
        using A2 wellord1_th_40 sorry
      thus "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 A"
        using A3 wellord2_def_2 sorry
    qed
    have A5: "( ex a be objectHIDDENM1 st a inHIDDENR3 A & (RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 a,RelInclWELLORD2K1 A  |-2WELLORD1K2 X)are-isomorphicWELLORD1R4) implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 A"
    proof(rule impI)
      assume Given: " ex a be objectHIDDENM1 st a inHIDDENR3 A & (RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 a,RelInclWELLORD2K1 A  |-2WELLORD1K2 X)are-isomorphicWELLORD1R4"
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A6: "a inHIDDENR3 A"and A7: "(RelInclWELLORD2K1 A  |-2WELLORD1K2 (RelInclWELLORD2K1 A)-SegWELLORD1K1 a,RelInclWELLORD2K1 A  |-2WELLORD1K2 X)are-isomorphicWELLORD1R4"
         sorry
      have 
        [ty]:"a be OrdinalORDINAL1M3"
        using A6 sorry
      have A8: "(RelInclWELLORD2K1 A)-SegWELLORD1K1 a =XBOOLE-0R4 a"
        using A6 wellord2_th_9 sorry
      have A9: "a c=ORDINAL1R1 A"
        using A6 ordinal1_def_2 sorry
      then have "RelInclWELLORD2K1 A  |-2WELLORD1K2 a =RELAT-1R1 RelInclWELLORD2K1 a"
        using wellord2_th_7 sorry
      then have "(RelInclWELLORD2K1 X,RelInclWELLORD2K1 a)are-isomorphicWELLORD1R4"
        using A2 A7 A8 wellord1_th_40 sorry
      thus "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 A"
        using A3 A9 wellord2_def_2 sorry
    qed
    have "fieldRELAT-1K3 (RelInclWELLORD2K1 A) =XBOOLE-0R4 A"
      using wellord2_def_1 sorry
    thus "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 A"
      using A1 A4 A5 wellord1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f, g for "FunctionFUNCT-1M1"
abbreviation(input) WELLORD2R2("'( _ , _ ')are-equipotentWELLORD2R2" [0,0]50) where
  "(X,Y)are-equipotentWELLORD2R2 \<equiv> (X,Y)are-equipotentTARSKIR3"

mtheorem wellord2_def_4:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"redefine pred (X,Y)are-equipotentWELLORD2R2 means
   ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
proof
(*compatibility*)
  show "(X,Y)are-equipotentWELLORD2R2 iff ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y)"
  proof-
    have "((X,Y)are-equipotentTARSKIR3 implies ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y)) &  not ( not ( for f be FunctionFUNCT-1M1 holds  not ((f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y)) &  not (X,Y)are-equipotentTARSKIR3)"
    proof(rule conjMI)
      show "(X,Y)are-equipotentTARSKIR3 implies ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y)"
      proof-
        have "(X,Y)are-equipotentTARSKIR3 implies ( ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 Y))"
        proof(rule impI)
          assume "(X,Y)are-equipotentTARSKIR3"
          then obtain Z where
            [ty]:"Z be setHIDDENM2" and 
            A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 Z)"and A2: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 Z)"and A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for u be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z implies (x =HIDDENR1 z iff y =HIDDENR1 u)"
             sorry
          let ?F = "Z /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :])"
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 ?F & [TARSKIK4 x,z ] inHIDDENR3 ?F implies y =HIDDENR1 z"
          proof-
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]) & [TARSKIK4 x,z ] inHIDDENR3 Z /\\XBOOLE-0K3 ([:ZFMISC-1K2 X,Y :]) implies y =HIDDENR1 z"
            proof(rule ballI,rule ballI,rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "[TARSKIK4 x,y ] inHIDDENR3 ?F & [TARSKIK4 x,z ] inHIDDENR3 ?F"
              then have "[TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 x,z ] inHIDDENR3 Z"
                using xboole_0_def_4 sorry
              thus "y =HIDDENR1 z"
                using A3 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then obtain F where 
            [ty]:"F be FunctionFUNCT-1M1" and FDef:"F = ?F"
            using funct_1_def_1 sorry
          obtain f where 
            [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F"
             sorry
          show " ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 Y)"
          proof(rule bexI[of _ "f"],rule conjMI)
            show "f be one-to-oneFUNCT-1V2"
            proof-
              have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & (y inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y) implies x =HIDDENR1 y"
              proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A4: "x inHIDDENR3 domRELAT-1K1 f"
                  and A5: "y inHIDDENR3 domRELAT-1K1 f"
                  and A6: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
                have "[TARSKIK4 y,f .FUNCT-1K1 y ] inHIDDENR3 f"
                  using A5 funct_1_th_1 sorry
                then have A7: "[TARSKIK4 y,f .FUNCT-1K1 y ] inHIDDENR3 Z"
                  using xboole_0_def_4 sorry
                have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
                  using A4 funct_1_th_1 sorry
                then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Z"
                  using xboole_0_def_4 sorry
                thus "x =HIDDENR1 y"
                  using A3 A6 A7 sorry
              qed "sorry"
              thus "f be one-to-oneFUNCT-1V2"
                using funct_1_def_4 sorry
            qed
            have "domRELAT-1K1 f c=TARSKIR1 X & (X c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 f =XBOOLE-0R4 Y)"
            proof(rule conjMI,rule conjMI)
              show "domRELAT-1K1 f c=TARSKIR1 X"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 X"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 domRELAT-1K1 f"
                  then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
                    using funct_1_th_1 sorry
                  then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
                    using xboole_0_def_4 sorry
                  thus "x inHIDDENR3 X"
                    using zfmisc_1_th_87 sorry
                qed "sorry"
                thus "domRELAT-1K1 f c=TARSKIR1 X"
                  using tarski_def_3 sorry
              qed
              show "X c=TARSKIR1 domRELAT-1K1 f"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 f"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume A8: "x inHIDDENR3 X"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A9: "y inHIDDENR3 Y"and A10: "[TARSKIK4 x,y ] inHIDDENR3 Z"
                    using A1 sorry
                  have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
                    using A8 A9 zfmisc_1_th_87 sorry
                  then have "[TARSKIK4 x,y ] inHIDDENR3 f"
                    using A10 xboole_0_def_4 sorry
                  thus "x inHIDDENR3 domRELAT-1K1 f"
                    using funct_1_th_1 sorry
                qed "sorry"
                thus "X c=TARSKIR1 domRELAT-1K1 f"
                  using tarski_def_3 sorry
              qed
              have "rngFUNCT-1K2 f c=TARSKIR1 Y & Y c=TARSKIR1 rngFUNCT-1K2 f"
              proof(rule conjMI)
                show "rngFUNCT-1K2 f c=TARSKIR1 Y"
                proof-
                  have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 Y"
                  proof(rule ballI,rule impI)
                    fix y assume [ty]: "y be objectHIDDENM1"
                    assume "y inHIDDENR3 rngFUNCT-1K2 f"
                    then obtain x where
                      [ty]:"x be objectHIDDENM1" and 
                      A11: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
                      using funct_1_def_3 sorry
                    have "[TARSKIK4 x,y ] inHIDDENR3 f"
                      using A11 funct_1_th_1 sorry
                    then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
                      using xboole_0_def_4 sorry
                    thus "y inHIDDENR3 Y"
                      using zfmisc_1_th_87 sorry
                  qed "sorry"
                  thus "rngFUNCT-1K2 f c=TARSKIR1 Y"
                    using tarski_def_3 sorry
                qed
                show "Y c=TARSKIR1 rngFUNCT-1K2 f"
                proof-
                  have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 rngFUNCT-1K2 f"
                  proof(rule ballI,rule impI)
                    fix y assume [ty]: "y be objectHIDDENM1"
                    assume A12: "y inHIDDENR3 Y"
                    then obtain x where
                      [ty]:"x be objectHIDDENM1" and 
                      A13: "x inHIDDENR3 X"and A14: "[TARSKIK4 x,y ] inHIDDENR3 Z"
                      using A2 sorry
                    have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
                      using A12 A13 zfmisc_1_th_87 sorry
                    then have "[TARSKIK4 x,y ] inHIDDENR3 f"
                      using A14 xboole_0_def_4 sorry
                    then have "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
                      using funct_1_th_1 sorry
                    thus "y inHIDDENR3 rngFUNCT-1K2 f"
                      using funct_1_def_3 sorry
                  qed "sorry"
                  thus "Y c=TARSKIR1 rngFUNCT-1K2 f"
                    using tarski_def_3 sorry
                qed
              qed
              thus "rngFUNCT-1K2 f =XBOOLE-0R4 Y"
                using xboole_0_def_10 sorry
            qed
            thus "domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
              using xboole_0_def_10 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      have "( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y) implies ( ex Z be setHIDDENM2 st (( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 Z)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 Z))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for u be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z implies (x =HIDDENR1 z iff y =HIDDENR1 u)))"
      proof-
        have "( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y) implies ( ex Z be FunctionFUNCT-1M1 st ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 Z)) & (( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 Z)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for u be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z implies  not (x =HIDDENR1 z &  not y =HIDDENR1 u) &  not (y =HIDDENR1 u &  not x =HIDDENR1 z))))"
        proof(rule impI)
          assume Given: " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A15: "f be one-to-oneFUNCT-1V2"and A16: "domRELAT-1K1 f =XBOOLE-0R4 X"and A17: "rngFUNCT-1K2 f =XBOOLE-0R4 Y"
             sorry
          obtain Z where 
            [ty]:"Z be FunctionFUNCT-1M1" and ZDef:"Z = f"
             sorry
          show " ex Z be FunctionFUNCT-1M1 st ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 Z)) & (( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 Z)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for u be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z implies  not (x =HIDDENR1 z &  not y =HIDDENR1 u) &  not (y =HIDDENR1 u &  not x =HIDDENR1 z)))"
          proof(rule bexI[of _ "Z"],rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
            show " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 Z)"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex tVar9 be objectHIDDENM1 st tVar9 inTARSKIR2 Y & [TARSKIK4 x,tVar9 ] inHIDDENR3 Z)"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A18: "x inHIDDENR3 X"
                show " ex tVar9 be objectHIDDENM1 st tVar9 inTARSKIR2 Y & [TARSKIK4 x,tVar9 ] inHIDDENR3 Z"
                proof(rule bexI[of _ "f .FUNCT-1K1 x"],rule conjMI)
                  show "f .FUNCT-1K1 x inTARSKIR2 Y"
                    using A16 A17 A18 funct_1_def_3 sorry
                  show "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Z"
                    using A16 A18 funct_1_th_1 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            show " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 Z)"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex tVar10 be objectHIDDENM1 st tVar10 inTARSKIR2 X & [TARSKIK4 tVar10,y ] inHIDDENR3 Z)"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A19: "y inHIDDENR3 Y"
                show " ex tVar10 be objectHIDDENM1 st tVar10 inTARSKIR2 X & [TARSKIK4 tVar10,y ] inHIDDENR3 Z"
                proof(rule bexI[of _ "f \<inverse>FUNCT-1K4 .FUNCT-1K1 y"],rule conjMI)
                  have A20: "domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
                    using A15 funct_1_th_33 sorry
                  then have A21: "f \<inverse>FUNCT-1K4 .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4)"
                    using A17 A19 funct_1_def_3 sorry
                  have A22: "rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 f"
                    using A15 funct_1_th_33 sorry
                  thus "f \<inverse>FUNCT-1K4 .FUNCT-1K1 y inTARSKIR2 X"
                    using A16 A17 A19 A20 funct_1_def_3 sorry
                  have "y =HIDDENR1 f .FUNCT-1K1 (f \<inverse>FUNCT-1K4 .FUNCT-1K1 y)"
                    using A15 A17 A19 funct_1_th_35 sorry
                  thus "[TARSKIK4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y,y ] inHIDDENR3 Z"
                    using A22 A21 funct_1_th_1 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            fix u assume [ty]: "u be objectHIDDENM1"
            assume A23: "[TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z"
            then have A24: "x inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 domRELAT-1K1 f"
              using funct_1_th_1 sorry
            have "y =HIDDENR1 f .FUNCT-1K1 x & u =HIDDENR1 f .FUNCT-1K1 z"
              using A23 funct_1_th_1 sorry
            thus " not (x =HIDDENR1 z &  not y =HIDDENR1 u) &  not (y =HIDDENR1 u &  not x =HIDDENR1 z)"
              using A15 A24 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not ( not ( for f be FunctionFUNCT-1M1 holds  not ((f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y)) &  not (X,Y)are-equipotentTARSKIR3)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem WELLORD2R2_reflexivity:
" for Y be setHIDDENM2 holds (Y,Y)are-equipotentWELLORD2R2"
proof-
  have " for Y be setHIDDENM2 holds  ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 Y) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
  proof-
    have " for X be setHIDDENM2 holds  ex tVar11 be FunctionFUNCT-1M1 st (tVar11 be one-to-oneFUNCT-1V2 & domRELAT-1K1 tVar11 =XBOOLE-0R4 X) & rngFUNCT-1K2 tVar11 =XBOOLE-0R4 X"
    proof(rule ballI)
      fix X assume [ty]: "X be setHIDDENM2"
      show " ex tVar11 be FunctionFUNCT-1M1 st (tVar11 be one-to-oneFUNCT-1V2 & domRELAT-1K1 tVar11 =XBOOLE-0R4 X) & rngFUNCT-1K2 tVar11 =XBOOLE-0R4 X"
      proof(rule bexI[of _ "idRELAT-1K7 X"])
        show "(idRELAT-1K7 X be one-to-oneFUNCT-1V2 & domRELAT-1K1 (idRELAT-1K7 X) =XBOOLE-0R4 X) & rngFUNCT-1K2 (idRELAT-1K7 X) =XBOOLE-0R4 X"
           sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using wellord2_def_4 sorry
qed

mtheorem WELLORD2R2_symmetry:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X,Y)are-equipotentWELLORD2R2 implies (Y,X)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y) implies ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 Y) & rngFUNCT-1K2 f =XBOOLE-0R4 X)"
  proof-
    have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y) implies ( ex tVar12 be FunctionFUNCT-1M1 st (tVar12 be one-to-oneFUNCT-1V2 & domRELAT-1K1 tVar12 =XBOOLE-0R4 Y) & rngFUNCT-1K2 tVar12 =XBOOLE-0R4 X)"
    proof(rule ballI,rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume Given: " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A25: "(f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
         sorry
      show " ex tVar12 be FunctionFUNCT-1M1 st (tVar12 be one-to-oneFUNCT-1V2 & domRELAT-1K1 tVar12 =XBOOLE-0R4 Y) & rngFUNCT-1K2 tVar12 =XBOOLE-0R4 X"
      proof(rule bexI[of _ "f \<inverse>FUNCT-1K4"])
        show "(f \<inverse>FUNCT-1K4 be one-to-oneFUNCT-1V2 & domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 Y) & rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 X"
          using A25 funct_1_th_33 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using wellord2_def_4 sorry
qed

mtheorem wellord2_th_15:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X,Y)are-equipotentWELLORD2R2 & (Y,Z)are-equipotentWELLORD2R2 implies (X,Z)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not (((X,Y)are-equipotentWELLORD2R2 & (Y,Z)are-equipotentWELLORD2R2) &  not (X,Z)are-equipotentWELLORD2R2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y) implies  not ((Y,Z)are-equipotentWELLORD2R2 &  not (X,Z)are-equipotentWELLORD2R2)"
    proof(rule impI)
      assume Given: " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "(f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
         sorry
      have "( ex g be FunctionFUNCT-1M1 st (g be one-to-oneFUNCT-1V2 & domRELAT-1K1 g =XBOOLE-0R4 Y) & rngFUNCT-1K2 g =XBOOLE-0R4 Z) implies (X,Z)are-equipotentWELLORD2R2"
      proof(rule impI)
        assume Given: " ex g be FunctionFUNCT-1M1 st (g be one-to-oneFUNCT-1V2 & domRELAT-1K1 g =XBOOLE-0R4 Y) & rngFUNCT-1K2 g =XBOOLE-0R4 Z"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A2: "(g be one-to-oneFUNCT-1V2 & domRELAT-1K1 g =XBOOLE-0R4 Y) & rngFUNCT-1K2 g =XBOOLE-0R4 Z"
           sorry
        have "(g *FUNCT-1K3 f be one-to-oneFUNCT-1V2 & domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 X) & rngFUNCT-1K2 (g *FUNCT-1K3 f) =XBOOLE-0R4 Z"
        proof-
          show "(g *FUNCT-1K3 f be one-to-oneFUNCT-1V2 & domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 X) & rngFUNCT-1K2 (g *FUNCT-1K3 f) =XBOOLE-0R4 Z"
            using A1 A2 relat_1_th_27 relat_1_th_28 sorry
        qed
        thus "(X,Z)are-equipotentWELLORD2R2"
          using bexI[of _ "g *FUNCT-1K3 f"] wellord2_def_4 sorry
      qed
      thus " not ((Y,Z)are-equipotentWELLORD2R2 &  not (X,Z)are-equipotentWELLORD2R2)"
        using wellord2_def_4 sorry
    qed
    thus " not (((X,Y)are-equipotentWELLORD2R2 & (Y,Z)are-equipotentWELLORD2R2) &  not (X,Z)are-equipotentWELLORD2R2)"
      using wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem wellord2_th_16:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R well-ordersWELLORD1R2 X implies fieldRELAT-1K3 (R  |-2WELLORD1K2 X) =XBOOLE-0R4 X & R  |-2WELLORD1K2 X be well-orderingWELLORD1V2"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  not (R well-ordersWELLORD1R2 X &  not (fieldRELAT-1K3 (R  |-2WELLORD1K2 X) =XBOOLE-0R4 X & R  |-2WELLORD1K2 X be well-orderingWELLORD1V2))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "R is-reflexive-inRELAT-2R1 X & (R is-transitive-inRELAT-2R8 X & (R is-antisymmetric-inRELAT-2R4 X & (R is-connected-inRELAT-2R6 X & R is-well-founded-inWELLORD1R1 X))) implies fieldRELAT-1K3 (R  |-2WELLORD1K2 X) =XBOOLE-0R4 X & R  |-2WELLORD1K2 X be well-orderingWELLORD1V2"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
      assume A1: "R is-reflexive-inRELAT-2R1 X"
        and A2: "R is-transitive-inRELAT-2R8 X"
        and A3: "R is-antisymmetric-inRELAT-2R4 X"
        and A4: "R is-connected-inRELAT-2R6 X"
        and A5: "R is-well-founded-inWELLORD1R1 X"
      have A6: "R  |-2WELLORD1K2 X is-antisymmetric-inRELAT-2R4 X"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & ([TARSKIK4 x,y ] inHIDDENR3 R  |-2WELLORD1K2 X & [TARSKIK4 y,x ] inHIDDENR3 R  |-2WELLORD1K2 X) implies x =HIDDENR1 y"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A7: "x inHIDDENR3 X & y inHIDDENR3 X"
            and A8: "[TARSKIK4 x,y ] inHIDDENR3 R  |-2WELLORD1K2 X & [TARSKIK4 y,x ] inHIDDENR3 R  |-2WELLORD1K2 X"
          have "[TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,x ] inHIDDENR3 R"
            using A8 xboole_0_def_4 sorry
          thus "x =HIDDENR1 y"
            using A3 A7 sorry
        qed "sorry"
        thus "R  |-2WELLORD1K2 X is-antisymmetric-inRELAT-2R4 X"
          using relat_2_def_4 sorry
      qed
      have A9: "R  |-2WELLORD1K2 X is-well-founded-inWELLORD1R1 X"
      proof-
        have " for Y be setHIDDENM2 holds Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar14 be objectHIDDENM1 st tVar14 inHIDDENR3 Y & ( not (R  |-2WELLORD1K2 X)-SegWELLORD1K1 tVar14 missesXBOOLE-0R1 Y implies  False ))"
        proof(rule ballI,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          assume "Y c=TARSKIR1 X & Y <>HIDDENR2 {}XBOOLE-0K1"
          then obtain a where
            [ty]:"a be objectHIDDENM1" and 
            A10: "a inHIDDENR3 Y"and A11: "R -SegWELLORD1K1 a missesXBOOLE-0R1 Y"
            using A5 sorry
          show " ex tVar14 be objectHIDDENM1 st tVar14 inHIDDENR3 Y & ( not (R  |-2WELLORD1K2 X)-SegWELLORD1K1 tVar14 missesXBOOLE-0R1 Y implies  False )"
          proof(rule bexI[of _ "a"],rule conjMI,rule impI)
            show "a inHIDDENR3 Y"
              using A10 sorry
            assume " not (R  |-2WELLORD1K2 X)-SegWELLORD1K1 a missesXBOOLE-0R1 Y"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A12: "x inHIDDENR3 (R  |-2WELLORD1K2 X)-SegWELLORD1K1 a"and A13: "x inHIDDENR3 Y"
              using xboole_0_th_3 sorry
            have "[TARSKIK4 x,a ] inHIDDENR3 R  |-2WELLORD1K2 X"
              using A12 wellord1_th_1 sorry
            then have A14: "[TARSKIK4 x,a ] inHIDDENR3 R"
              using xboole_0_def_4 sorry
            have "x <>HIDDENR2 a"
              using A12 wellord1_th_1 sorry
            then have "x inHIDDENR3 R -SegWELLORD1K1 a"
              using A14 wellord1_th_1 sorry
            thus " False "
              using A11 A13 xboole_0_th_3 sorry
          qed "sorry"
        qed "sorry"
        thus "R  |-2WELLORD1K2 X is-well-founded-inWELLORD1R1 X"
          using wellord1_def_3 sorry
      qed
      have A15: "R  |-2WELLORD1K2 X is-transitive-inRELAT-2R8 X"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 X & (y inHIDDENR3 X & (z inHIDDENR3 X & ([TARSKIK4 x,y ] inHIDDENR3 R  |-2WELLORD1K2 X & [TARSKIK4 y,z ] inHIDDENR3 R  |-2WELLORD1K2 X))) implies [TARSKIK4 x,z ] inHIDDENR3 R  |-2WELLORD1K2 X"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A16: "x inHIDDENR3 X"
            and A17: "y inHIDDENR3 X"
            and A18: "z inHIDDENR3 X"
            and A19: "[TARSKIK4 x,y ] inHIDDENR3 R  |-2WELLORD1K2 X & [TARSKIK4 y,z ] inHIDDENR3 R  |-2WELLORD1K2 X"
          have "[TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,z ] inHIDDENR3 R"
            using A19 xboole_0_def_4 sorry
          then have A20: "[TARSKIK4 x,z ] inHIDDENR3 R"
            using A2 A16 A17 A18 sorry
          have "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
            using A16 A18 zfmisc_1_th_87 sorry
          thus "[TARSKIK4 x,z ] inHIDDENR3 R  |-2WELLORD1K2 X"
            using A20 xboole_0_def_4 sorry
        qed "sorry"
        thus "R  |-2WELLORD1K2 X is-transitive-inRELAT-2R8 X"
          using relat_2_def_8 sorry
      qed
      have A21: "R  |-2WELLORD1K2 X is-connected-inRELAT-2R6 X"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 X & y inHIDDENR3 X) & x <>HIDDENR2 y implies  not ( not [TARSKIK4 x,y ] inHIDDENR3 R  |-2WELLORD1K2 X &  not [TARSKIK4 y,x ] inHIDDENR3 R  |-2WELLORD1K2 X)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A22: "x inHIDDENR3 X & y inHIDDENR3 X"
            and A23: "x <>HIDDENR2 y"
          have A24: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,X :] & [TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
            using A22 zfmisc_1_th_87 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 R or [TARSKIK4 y,x ] inHIDDENR3 R"
            using A4 A22 A23 sorry
          thus " not ( not [TARSKIK4 x,y ] inHIDDENR3 R  |-2WELLORD1K2 X &  not [TARSKIK4 y,x ] inHIDDENR3 R  |-2WELLORD1K2 X)"
            using A24 xboole_0_def_4 sorry
        qed "sorry"
        thus "R  |-2WELLORD1K2 X is-connected-inRELAT-2R6 X"
          using relat_2_def_6 sorry
      qed
      show A25: "fieldRELAT-1K3 (R  |-2WELLORD1K2 X) =XBOOLE-0R4 X"
      proof-
        have "fieldRELAT-1K3 (R  |-2WELLORD1K2 X) c=TARSKIR1 X & X c=TARSKIR1 fieldRELAT-1K3 (R  |-2WELLORD1K2 X)"
        proof(rule conjMI)
          show "fieldRELAT-1K3 (R  |-2WELLORD1K2 X) c=TARSKIR1 X"
            using wellord1_th_13 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 fieldRELAT-1K3 (R  |-2WELLORD1K2 X)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            then have "[TARSKIK4 x,x ] inHIDDENR3 R & [TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
              using A1 zfmisc_1_th_87 sorry
            then have "[TARSKIK4 x,x ] inHIDDENR3 R  |-2WELLORD1K2 X"
              using xboole_0_def_4 sorry
            thus "x inHIDDENR3 fieldRELAT-1K3 (R  |-2WELLORD1K2 X)"
              using relat_1_th_15 sorry
          qed "sorry"
          thus "X c=TARSKIR1 fieldRELAT-1K3 (R  |-2WELLORD1K2 X)"
            using tarski_def_3 sorry
        qed
        thus "fieldRELAT-1K3 (R  |-2WELLORD1K2 X) =XBOOLE-0R4 X"
          using xboole_0_def_10 sorry
      qed
      have "R  |-2WELLORD1K2 X is-reflexive-inRELAT-2R1 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 R  |-2WELLORD1K2 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have "[TARSKIK4 x,x ] inHIDDENR3 R & [TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
            using A1 zfmisc_1_th_87 sorry
          thus "[TARSKIK4 x,x ] inHIDDENR3 R  |-2WELLORD1K2 X"
            using xboole_0_def_4 sorry
        qed "sorry"
        thus "R  |-2WELLORD1K2 X is-reflexive-inRELAT-2R1 X"
          using relat_2_def_1 sorry
      qed
      then have "R  |-2WELLORD1K2 X well-ordersWELLORD1R2 X"
        using A15 A6 A21 A9 sorry
      thus "R  |-2WELLORD1K2 X be well-orderingWELLORD1V2"
        using A25 wellord1_th_4 sorry
    qed
    thus " not (R well-ordersWELLORD1R2 X &  not (fieldRELAT-1K3 (R  |-2WELLORD1K2 X) =XBOOLE-0R4 X & R  |-2WELLORD1K2 X be well-orderingWELLORD1V2))"
      using wellord1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma wellord2_lm_1:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 & (X,fieldRELAT-1K3 R)are-equipotentWELLORD2R2 implies ( ex R be RelationRELAT-1M1 st R well-ordersWELLORD1R2 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 implies  not ((X,fieldRELAT-1K3 R)are-equipotentWELLORD2R2 & ( for R be RelationRELAT-1M1 holds  not R well-ordersWELLORD1R2 X))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R be well-orderingWELLORD1V2"
    have "( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 fieldRELAT-1K3 R) implies ( ex tVar15 be RelationRELAT-1M1 st tVar15 well-ordersWELLORD1R2 X)"
    proof(rule impI)
      assume Given: " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 fieldRELAT-1K3 R"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "f be one-to-oneFUNCT-1V2"and A3: "domRELAT-1K1 f =XBOOLE-0R4 X"and A4: "rngFUNCT-1K2 f =XBOOLE-0R4 fieldRELAT-1K3 R"
         sorry
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. [TARSKIK4 f .FUNCT-1K1 Lamb1,f .FUNCT-1K1 Lamb2 ] inHIDDENR3 R"
      obtain Q where
        [ty]:"Q be RelationRELAT-1M1" and 
        A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Q iff (x inHIDDENR3 X & y inHIDDENR3 X) & ?P(x,y)"
        using relat_1_sch_1 sorry
      show " ex tVar15 be RelationRELAT-1M1 st tVar15 well-ordersWELLORD1R2 X"
      proof(rule bexI[of _ "Q"])
        have A6: "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R"
          using A1 relat_2_def_9 sorry
        have A7: "fieldRELAT-1K3 Q =XBOOLE-0R4 X"
        proof-
          have "fieldRELAT-1K3 Q c=TARSKIR1 X & X c=TARSKIR1 fieldRELAT-1K3 Q"
          proof(rule conjMI)
            show "fieldRELAT-1K3 Q c=TARSKIR1 X"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 Q &  not x inHIDDENR3 X implies  False "
              proof(rule ballI,rule impMI ,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A8: "x inHIDDENR3 fieldRELAT-1K3 Q"
                  and A9: " not x inHIDDENR3 X"
                have " for y be objectHIDDENM1 holds  not [TARSKIK4 y,x ] inHIDDENR3 Q"
                  using A5 A9 sorry
                then have A10: " not x inHIDDENR3 rngRELAT-1K2 Q"
                  using xtuple_0_def_13 sorry
                have " for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 Q"
                  using A5 A9 sorry
                then have " not x inHIDDENR3 domRELAT-1K1 Q"
                  using xtuple_0_def_12 sorry
                thus " False "
                  using A8 A10 xboole_0_def_3 sorry
              qed "sorry"
              thus "fieldRELAT-1K3 Q c=TARSKIR1 X"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 fieldRELAT-1K3 Q"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A11: "x inHIDDENR3 X"
              then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
                using A3 funct_1_def_3 sorry
              then have "[TARSKIK4 f .FUNCT-1K1 x,f .FUNCT-1K1 x ] inHIDDENR3 R"
                using A6 A4 sorry
              then have "[TARSKIK4 x,x ] inHIDDENR3 Q"
                using A5 A11 sorry
              thus "x inHIDDENR3 fieldRELAT-1K3 Q"
                using relat_1_th_15 sorry
            qed "sorry"
            thus "X c=TARSKIR1 fieldRELAT-1K3 Q"
              using tarski_def_3 sorry
          qed
          thus "fieldRELAT-1K3 Q =XBOOLE-0R4 X"
            using xboole_0_def_10 sorry
        qed
        have "f is-isomorphism-ofWELLORD1R3(Q,R)"
          using A2 A3 A4 A7 A5 sorry
        then have "f \<inverse>FUNCT-1K4 is-isomorphism-ofWELLORD1R3(R,Q)"
          using wellord1_th_39 sorry
        then have "Q be well-orderingWELLORD1V2"
          using A1 wellord1_th_44 sorry
        thus "Q well-ordersWELLORD1R2 X"
          using A7 wellord1_th_4 sorry
      qed "sorry"
    qed
    thus " not ((X,fieldRELAT-1K3 R)are-equipotentWELLORD2R2 & ( for R be RelationRELAT-1M1 holds  not R well-ordersWELLORD1R2 X))"
      using wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Zermelo Theorem*)
mtheorem wellord2_th_17:
" for X be setHIDDENM2 holds  ex R be RelationRELAT-1M1 st R well-ordersWELLORD1R2 X"
proof-
  have " for X be setHIDDENM2 holds  not ( for R be RelationRELAT-1M1 holds  not R well-ordersWELLORD1R2 X)"
  proof(rule ballI)
    let ?F = "\<lambda>Lamb1. {TARSKIK1 Lamb1}"
    let ?P = "\<lambda>Lamb1. Lamb1 be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    obtain Class where
      [ty]:"Class be setHIDDENM2" and 
      A1: "X inTARSKIR2 Class"and A2: " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 Class & Z c=TARSKIR1 Y implies Z inTARSKIR2 Class"and " for Y be setHIDDENM2 holds Y inTARSKIR2 Class implies boolZFMISC-1K1 Y inTARSKIR2 Class"and A3: " for Y be setHIDDENM2 holds Y c=TARSKIR1 Class implies (Y,Class)are-equipotentWELLORD2R2 or Y inTARSKIR2 Class"
      using zfmisc_1_th_112 sorry
    obtain ON where
      [ty]:"ON be setHIDDENM2" and 
      A4: " for x be objectHIDDENM1 holds x inHIDDENR3 ON iff x inHIDDENR3 Class & ?P(x)"
      using xboole_0_sch_1 sorry
    have " for Y be setHIDDENM2 holds Y inTARSKIR2 ON implies Y be OrdinalORDINAL1M3 & Y c=TARSKIR1 ON"
    proof(rule ballI,rule impI,rule conjMI)
      fix Y assume [ty]: "Y be setHIDDENM2"
      assume A5: "Y inTARSKIR2 ON"
      thus "Y be OrdinalORDINAL1M3"
        using A4 sorry
      obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = Y"
        using A4 A5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 ON"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 Y"
        then have "x inHIDDENR3 A"
           sorry
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
           sorry
        have A7: "B c=ORDINAL1R1 A"
          using A6 ordinal1_def_2 sorry
        have "A inTARSKIR2 Class"
          using A4 A5 sorry
        then have "B inTARSKIR2 Class"
          using A2 A7 sorry
        thus "x inHIDDENR3 ON"
          using A4 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 ON"
        using tarski_def_3 sorry
    qed "sorry"
    then have 
      [ty]:"ON be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2"
      using ordinal1_th_19 sorry
    have A8: "ON c=TARSKIR1 Class"
      using A4 sorry
    have A9: "(ON,Class)are-equipotentWELLORD2R2"
    proof-
      have " not (ON,Class)are-equipotentWELLORD2R2 implies  False "
      proof(rule impI)
        assume " not (ON,Class)are-equipotentWELLORD2R2"
        then have "ON inTARSKIR2 Class"
          using A3 A8 sorry
        then have "ON inTARSKIR2 ON"
          using A4 sorry
        thus " False "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "fieldRELAT-1K3 (RelInclWELLORD2K1 ON) =XBOOLE-0R4 ON"
      using wellord2_def_1 sorry
    then obtain R where
      [ty]:"R be RelationRELAT-1M1" and 
      A10: "R well-ordersWELLORD1R2 Class"
      using A9 wellord2_lm_1 sorry
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A11: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
      using funct_1_sch_3 sorry
    have A12: "rngFUNCT-1K2 f c=TARSKIR1 Class"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 Class"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 f"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A13: "y inHIDDENR3 domRELAT-1K1 f"and A14: "x =HIDDENR1 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have A15: "{TARSKIK1 y} c=TARSKIR1 X"
          using A11 A13 tarski_def_1 sorry
        have "f .FUNCT-1K1 y =XBOOLE-0R4 {TARSKIK1 y}"
          using A11 A13 sorry
        thus "x inHIDDENR3 Class"
          using A1 A2 A14 A15 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 Class"
        using tarski_def_3 sorry
    qed
    have A16: "(X,rngFUNCT-1K2 f)are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 f)"
      proof(rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A17: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
              and A18: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            have "f .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x} & f .FUNCT-1K1 y =XBOOLE-0R4 {TARSKIK1 y}"
              using A11 A17 sorry
            thus "x =HIDDENR1 y"
              using A18 zfmisc_1_th_3 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 f"
          using A11 sorry
      qed
      thus "(X,rngFUNCT-1K2 f)are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    let ?Q = "R  |-2WELLORD1K2 Class"
    have "fieldRELAT-1K3 ?Q =XBOOLE-0R4 Class"
      using A10 wellord2_th_16 sorry
    then have A19: "fieldRELAT-1K3 (?Q  |-2WELLORD1K2 rngFUNCT-1K2 f) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using A10 A12 wellord2_th_16 wellord1_th_31 sorry
    have "?Q be well-orderingWELLORD1V2"
      using A10 wellord2_th_16 sorry
    thus " not ( for R be RelationRELAT-1M1 holds  not R well-ordersWELLORD1R2 X)"
      using A16 A19 wellord2_lm_1 wellord1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve M for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
(*\$N Axiom of Choice*)
mtheorem wellord2_th_18:
" for M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1) & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X inTARSKIR2 M & Y inTARSKIR2 M) & X <>HIDDENR2 Y implies X missesXBOOLE-0R1 Y) implies ( ex Choice be setHIDDENM2 st  for X be setHIDDENM2 holds X inTARSKIR2 M implies ( ex x be objectHIDDENM1 st Choice /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}))"
proof-
  have " for M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1) & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X inTARSKIR2 M & Y inTARSKIR2 M) & X <>HIDDENR2 Y implies X missesXBOOLE-0R1 Y) implies ( ex Choice be setHIDDENM2 st  for X be setHIDDENM2 holds X inTARSKIR2 M implies ( ex x be setHIDDENM2 st Choice /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}))"
  proof(rule ballI,rule impMI ,rule impI)
    fix M assume [ty]: "M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X inTARSKIR2 M & Y inTARSKIR2 M) & X <>HIDDENR2 Y implies X missesXBOOLE-0R1 Y"
    obtain R where
      [ty]:"R be RelationRELAT-1M1" and 
      A3: "R well-ordersWELLORD1R2 unionTARSKIK3 M"
      using wellord2_th_17 sorry
    have A4: "R is-reflexive-inRELAT-2R1 unionTARSKIK3 M"
      using A3 sorry
    have A5: "R is-connected-inRELAT-2R6 unionTARSKIK3 M"
      using A3 sorry
    let ?Ch = "\<lambda>Lamb1. \<lambda>Lamb2.  ex D1 be setHIDDENM2 st (D1 =HIDDENR1 Lamb1 & Lamb2 inHIDDENR3 D1) & ( for z be objectHIDDENM1 holds z inHIDDENR3 D1 implies [TARSKIK4 Lamb2,z ] inHIDDENR3 R)"
    have A6: "R is-antisymmetric-inRELAT-2R4 unionTARSKIK3 M"
      using A3 sorry
    have A7: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 M & ?Ch(x,y)) & ?Ch(x,z) implies y =HIDDENR1 z"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 M implies (( ex X be setHIDDENM2 st (X =HIDDENR1 x & y inHIDDENR3 X) & ( for u be objectHIDDENM1 holds u inHIDDENR3 X implies [TARSKIK4 y,u ] inHIDDENR3 R)) implies (( ex X be setHIDDENM2 st (X =HIDDENR1 x & z inHIDDENR3 X) & ( for u be objectHIDDENM1 holds u inHIDDENR3 X implies [TARSKIK4 z,u ] inHIDDENR3 R)) implies y =HIDDENR1 z))"
      proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A8: "x inHIDDENR3 M"
        assume Given: " ex X be setHIDDENM2 st (X =HIDDENR1 x & y inHIDDENR3 X) & ( for u be objectHIDDENM1 holds u inHIDDENR3 X implies [TARSKIK4 y,u ] inHIDDENR3 R)"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A9: "X =HIDDENR1 x"and A10: "y inHIDDENR3 X"and A11: " for u be objectHIDDENM1 holds u inHIDDENR3 X implies [TARSKIK4 y,u ] inHIDDENR3 R"
           sorry
        have A12: "y inHIDDENR3 unionTARSKIK3 M"
          using A8 A10 tarski_def_4 A9 sorry
        assume Given: " ex X be setHIDDENM2 st (X =HIDDENR1 x & z inHIDDENR3 X) & ( for u be objectHIDDENM1 holds u inHIDDENR3 X implies [TARSKIK4 z,u ] inHIDDENR3 R)"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A13: "X =HIDDENR1 x"and A14: "z inHIDDENR3 X"and A15: " for u be objectHIDDENM1 holds u inHIDDENR3 X implies [TARSKIK4 z,u ] inHIDDENR3 R"
           sorry
        have A16: "z inHIDDENR3 unionTARSKIK3 M"
          using A8 A14 tarski_def_4 A13 sorry
        have "[TARSKIK4 y,z ] inHIDDENR3 R & [TARSKIK4 z,y ] inHIDDENR3 R"
          using A10 A11 A14 A15 A9 A13 sorry
        thus "y =HIDDENR1 z"
          using A6 A12 A16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A17: "R is-well-founded-inWELLORD1R1 unionTARSKIK3 M"
      using A3 sorry
    have A18: " for x be objectHIDDENM1 holds x inHIDDENR3 M implies ( ex y be objectHIDDENM1 st ?Ch(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 M implies ( ex tVar17 be objectHIDDENM1 st  ex tVar18 be setHIDDENM2 st tVar18 =HIDDENR1 x & (tVar17 inHIDDENR3 tVar18 & ( for z be objectHIDDENM1 holds z inHIDDENR3 tVar18 implies [TARSKIK4 tVar17,z ] inHIDDENR3 R)))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A19: "x inHIDDENR3 M"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        have A20: "xx c=TARSKIR1 unionTARSKIK3 M"
          using zfmisc_1_th_74 A19 sorry
        have "x <>HIDDENR2 {}XBOOLE-0K1"
          using A1 A19 sorry
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A21: "y inHIDDENR3 xx"and A22: "R -SegWELLORD1K1 y missesXBOOLE-0R1 xx"
          using A17 A20 sorry
        show " ex tVar17 be objectHIDDENM1 st  ex tVar18 be setHIDDENM2 st tVar18 =HIDDENR1 x & (tVar17 inHIDDENR3 tVar18 & ( for z be objectHIDDENM1 holds z inHIDDENR3 tVar18 implies [TARSKIK4 tVar17,z ] inHIDDENR3 R))"
        proof(rule bexI[of _ "y"])
          show " ex tVar18 be setHIDDENM2 st tVar18 =HIDDENR1 x & (y inHIDDENR3 tVar18 & ( for z be objectHIDDENM1 holds z inHIDDENR3 tVar18 implies [TARSKIK4 y,z ] inHIDDENR3 R))"
          proof(rule bexI[of _ "xx"],rule conjMI,rule conjMI,rule ballI,rule impI)
            show "xx =HIDDENR1 x"
               sorry
            show "y inHIDDENR3 xx"
              using A21 sorry
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A23: "z inHIDDENR3 xx"
            then have A24: " not z inHIDDENR3 R -SegWELLORD1K1 y"
              using A22 xboole_0_th_3 sorry
            have "y <>HIDDENR2 z implies [TARSKIK4 y,z ] inHIDDENR3 R or [TARSKIK4 z,y ] inHIDDENR3 R"
              using A5 A20 A21 A23 sorry
            thus "[TARSKIK4 y,z ] inHIDDENR3 R"
              using A4 A20 A23 A24 wellord1_th_1 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A25: "domRELAT-1K1 f =XBOOLE-0R4 M & ( for x be objectHIDDENM1 holds x inHIDDENR3 M implies ?Ch(x,f .FUNCT-1K1 x))"
      using funct_1_sch_2 A7 A18 sorry
    obtain Choice where 
      [ty]:"Choice be setHIDDENM2" and ChoiceDef:"Choice = rngFUNCT-1K2 f"
       sorry
    show " ex Choice be setHIDDENM2 st  for X be setHIDDENM2 holds X inTARSKIR2 M implies ( ex x be setHIDDENM2 st Choice /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x})"
    proof(rule bexI[of _ "Choice"],rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume A26: "X inTARSKIR2 M"
      obtain x where 
        [ty]:"x be setHIDDENM2" and xDef:"x = f .FUNCT-1K1 X"
         sorry
      show " ex x be setHIDDENM2 st Choice /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}"
      proof(rule bexI[of _ "x"])
        have "Choice /\\XBOOLE-0K3 X c=TARSKIR1 {TARSKIK1 x} & {TARSKIK1 x} c=TARSKIR1 Choice /\\XBOOLE-0K3 X"
        proof(rule conjMI)
          show "Choice /\\XBOOLE-0K3 X c=TARSKIR1 {TARSKIK1 x}"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 Choice /\\XBOOLE-0K3 X implies ( not y inHIDDENR3 {TARSKIK1 x} implies  False )"
            proof(rule ballI,rule impI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A27: "y inHIDDENR3 Choice /\\XBOOLE-0K3 X"
              then have A28: "y inHIDDENR3 X"
                using xboole_0_def_4 sorry
              have "y inHIDDENR3 Choice"
                using A27 xboole_0_def_4 sorry
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A29: "z inHIDDENR3 domRELAT-1K1 f"and A30: "y =HIDDENR1 f .FUNCT-1K1 z"
                using funct_1_def_3 sorry
              have 
                [ty]:"z be setHIDDENM2"
                using tarski_th_1 sorry
              assume " not y inHIDDENR3 {TARSKIK1 x}"
              then have "X <>HIDDENR2 z"
                using A30 tarski_def_1 sorry
              then have "X missesXBOOLE-0R1 z"
                using A2 A25 A26 A29 sorry
              then have A31: "X /\\XBOOLE-0K3 z =XBOOLE-0R4 {}XBOOLE-0K1"
                 sorry
              have "?Ch(z,f .FUNCT-1K1 z)"
                using A25 A29 sorry
              then have "f .FUNCT-1K1 z inTARSKIR2 z"
                 sorry
              thus " False "
                using A28 A30 A31 xboole_0_def_4 sorry
            qed "sorry"
            thus "Choice /\\XBOOLE-0K3 X c=TARSKIR1 {TARSKIK1 x}"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies y inHIDDENR3 Choice /\\XBOOLE-0K3 X"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 {TARSKIK1 x}"
            then have A32: "y =HIDDENR1 x"
              using tarski_def_1 sorry
            have "?Ch(X,f .FUNCT-1K1 X)"
              using A25 A26 sorry
            then have A33: "y inHIDDENR3 X"
              using A32 sorry
            have "y inHIDDENR3 Choice"
              using A25 A26 A32 funct_1_def_3 sorry
            thus "y inHIDDENR3 Choice /\\XBOOLE-0K3 X"
              using A33 xboole_0_def_4 sorry
          qed "sorry"
          thus "{TARSKIK1 x} c=TARSKIR1 Choice /\\XBOOLE-0K3 X"
            using tarski_def_3 sorry
        qed
        thus "Choice /\\XBOOLE-0K3 X =XBOOLE-0R4 {TARSKIK1 x}"
          using xboole_0_def_10 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem wellord2_th_19:
" for X be setHIDDENM2 holds RelInclWELLORD2K1 X is-reflexive-inRELAT-2R1 X"
  using wellord2_def_1 sorry

mtheorem wellord2_th_20:
" for X be setHIDDENM2 holds RelInclWELLORD2K1 X is-transitive-inRELAT-2R8 X"
proof(rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  have "RelInclWELLORD2K1 X be transitiveRELAT-2V8 & fieldRELAT-1K3 (RelInclWELLORD2K1 X) =XBOOLE-0R4 X"
    using wellord2_def_1 sorry
  thus "RelInclWELLORD2K1 X is-transitive-inRELAT-2R8 X"
     sorry
qed "sorry"

mtheorem wellord2_th_21:
" for X be setHIDDENM2 holds RelInclWELLORD2K1 X is-antisymmetric-inRELAT-2R4 X"
proof(rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  have "RelInclWELLORD2K1 X be antisymmetricRELAT-2V4 & fieldRELAT-1K3 (RelInclWELLORD2K1 X) =XBOOLE-0R4 X"
    using wellord2_def_1 sorry
  thus "RelInclWELLORD2K1 X is-antisymmetric-inRELAT-2R4 X"
     sorry
qed "sorry"

mtheorem wellord2_cl_6:
"cluster RelInclWELLORD2K1 ({}XBOOLE-0K1) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RelInclWELLORD2K1 ({}XBOOLE-0K1) be emptyXBOOLE-0V1"
  proof-
    have " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 {}XBOOLE-0K1 & Z inTARSKIR2 {}XBOOLE-0K1 implies ([TARSKIK4 Y,Z ] inHIDDENR3 {}XBOOLE-0K1 iff Y c=TARSKIR1 Z)"
       sorry
    thus "RelInclWELLORD2K1 ({}XBOOLE-0K1) be emptyXBOOLE-0V1"
      using wellord2_def_1 relat_1_th_40 sorry
  qed
qed "sorry"

mtheorem wellord2_cl_7:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster RelInclWELLORD2K1 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RelInclWELLORD2K1 X be  non emptyXBOOLE-0V1"
  proof-
    have " not RelInclWELLORD2K1 X be emptyXBOOLE-0V1"
    proof-
      let ?a = "the ElementSUBSET-1M1-of X"
      have "[TARSKIK4 ?a,?a ] inHIDDENR3 RelInclWELLORD2K1 X"
        using wellord2_def_1 sorry
      thus " not RelInclWELLORD2K1 X be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem wellord2_th_22:
" for x be objectHIDDENM1 holds RelInclWELLORD2K1 {TARSKIK1 x} =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,x ] }"
proof-
  have " for x be objectHIDDENM1 holds RelInclWELLORD2K1 {TARSKIK1 x} =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,x ] }"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 {TARSKIK1 x} & Z inTARSKIR2 {TARSKIK1 x} implies ([TARSKIK4 Y,Z ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] } iff Y c=TARSKIR1 Z)"
    proof-
      have " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y inTARSKIR2 {TARSKIK1 x} & Z inTARSKIR2 {TARSKIK1 x} implies ([TARSKIK4 Y,Z ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] } implies Y c=TARSKIR1 Z) &  not (Y c=TARSKIR1 Z &  not [TARSKIK4 Y,Z ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] })"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
        fix Y assume [ty]: "Y be setHIDDENM2"
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume A2: "Y inTARSKIR2 {TARSKIK1 x}"
          and A3: "Z inTARSKIR2 {TARSKIK1 x}"
        have A4: "Y =HIDDENR1 x"
          using A2 tarski_def_1 sorry
        thus "[TARSKIK4 Y,Z ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] } implies Y c=TARSKIR1 Z"
          using A3 tarski_def_1 sorry
        have "Z =HIDDENR1 x"
          using A3 tarski_def_1 sorry
        thus " not (Y c=TARSKIR1 Z &  not [TARSKIK4 Y,Z ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] })"
          using A4 tarski_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } =XBOOLE-0R4 {TARSKIK1 x}"
      using relat_1_th_173 sorry
    thus "RelInclWELLORD2K1 {TARSKIK1 x} =RELAT-1R1 {TARSKIK1 [TARSKIK4 x,x ] }"
      using A1 wellord2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem wellord2_th_23:
" for X be setHIDDENM2 holds RelInclWELLORD2K1 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
proof-
  have " for X be setHIDDENM2 holds RelInclWELLORD2K1 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?R = "RelInclWELLORD2K1 X"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 X implies [TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
    proof(rule ballI,rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      assume A1: "[TARSKIK4 a,b ] inHIDDENR3 ?R"
      then have "b inHIDDENR3 fieldRELAT-1K3 ?R"
        using relat_1_th_15 sorry
      then have A2: "b inHIDDENR3 X"
        using wellord2_def_1 sorry
      have "a inHIDDENR3 fieldRELAT-1K3 ?R"
        using A1 relat_1_th_15 sorry
      then have "a inHIDDENR3 X"
        using wellord2_def_1 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
        using A2 zfmisc_1_th_87 sorry
    qed "sorry"
    thus "RelInclWELLORD2K1 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
