theory classes2
  imports card_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve m for "CardinalCARD-1M1"
reserve A, B, C for "OrdinalORDINAL1M3"
reserve x, y, z, X, Y, Z, W for "setHIDDENM2"
reserve f for "FunctionFUNCT-1M1"
mlemma classes2_lm_1:
" for X be setHIDDENM2 holds Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
proof-
  have " for X be setHIDDENM2 holds Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "Tarski-ClassCLASSES1K1 X is-Tarski-Class-ofCLASSES1R1 X"
      using classes1_def_4 sorry
    thus "Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_cl_1:
"cluster TarskiCLASSES1V2 also-is subset-closedCLASSES1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be TarskiCLASSES1V2 implies it be subset-closedCLASSES1V1"
     sorry
qed "sorry"

mtheorem classes2_cl_2:
  mlet "X be setHIDDENM2"
"cluster Tarski-ClassCLASSES1K1 X as-term-is TarskiCLASSES1V2"
proof
(*coherence*)
  show "Tarski-ClassCLASSES1K1 X be TarskiCLASSES1V2"
    using classes2_lm_1 sorry
qed "sorry"

mtheorem classes2_th_1:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be subset-closedCLASSES1V1 & X inTARSKIR2 W implies  not (X,W)are-equipotentTARSKIR3 & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be subset-closedCLASSES1V1 implies (X inTARSKIR2 W implies  not (X,W)are-equipotentTARSKIR3 & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be subset-closedCLASSES1V1"
    assume A2: "X inTARSKIR2 W"
    have "boolSETFAM-1K9 X c=TARSKIR1 W"
      using A1 A2 sorry
    then have A3: "cardCARD-1K1 (boolSETFAM-1K9 X) c=ORDINAL1R1 cardCARD-1K1 W"
      using card_1_th_11 sorry
    have A4: "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (boolSETFAM-1K9 X)"
      using card_1_th_14 sorry
    then have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      using A3 sorry
    then have "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 W"
       sorry
    thus " not (X,W)are-equipotentTARSKIR3 & cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      using A4 A3 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_2:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for W be setHIDDENM2 holds (W be TarskiCLASSES1V2 & x inTARSKIR2 W) & y inTARSKIR2 W implies {TARSKIK1 x} inTARSKIR2 W & {TARSKIK2 x,y } inTARSKIR2 W"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & (x inTARSKIR2 W & y inTARSKIR2 W) implies {TARSKIK1 x} inTARSKIR2 W & {TARSKIK2 x,y } inTARSKIR2 W"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    let ?C = "\<lambda>Lamb1. Lamb1 =HIDDENR1 {}XBOOLE-0K1"
    assume A1: "W be TarskiCLASSES1V2"
      and A2: "x inTARSKIR2 W"
      and A3: "y inTARSKIR2 W"
    have A4: "{TARSKIK1 x} c=TARSKIR1 boolSETFAM-1K9 x"
      using zfmisc_1_th_68 sorry
    have "boolSETFAM-1K9 x inTARSKIR2 W"
      using A1 A2 sorry
    thus "{TARSKIK1 x} inTARSKIR2 W"
      using A1 A4 classes1_def_1 sorry
    then have A5: "boolSETFAM-1K9 {TARSKIK1 x} inTARSKIR2 W"
      using A1 sorry
    let ?g = "\<lambda>Lamb1. x"
    let ?f = "\<lambda>Lamb1. y"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A6: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} } & ( for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} } implies (?C(z) implies f .FUNCT-1K1 z =XBOOLE-0R4 ?f(z)) & ( not ?C(z) implies f .FUNCT-1K1 z =XBOOLE-0R4 ?g(z)))"
      using partfun1_sch_1 sorry
    have "{TARSKIK2 x,y } c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        have A7: "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
          using tarski_def_2 sorry
        have A8: "{TARSKIK1 x} inTARSKIR2 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
          using tarski_def_2 sorry
        assume "z inHIDDENR3 {TARSKIK2 x,y }"
        then have "z =HIDDENR1 x or z =HIDDENR1 y"
          using tarski_def_2 sorry
        then have "f .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 z or f .FUNCT-1K1 {TARSKIK1 x} =HIDDENR1 z"
          using A6 A7 A8 sorry
        thus "z inHIDDENR3 rngFUNCT-1K2 f"
          using A6 A7 A8 funct_1_def_3 sorry
      qed "sorry"
      thus "{TARSKIK2 x,y } c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    then have A9: "cardCARD-1K1 {TARSKIK2 x,y } c=ORDINAL1R1 cardCARD-1K1 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
      using A6 card_1_th_12 sorry
    have A10: "{TARSKIK2 x,y } c=TARSKIR1 W"
      using A2 A3 tarski_def_2 sorry
    have "boolSETFAM-1K9 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
      using zfmisc_1_th_24 sorry
    then have "cardCARD-1K1 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} } inTARSKIR2 cardCARD-1K1 W"
      using A1 A5 classes2_th_1 sorry
    then have "cardCARD-1K1 {TARSKIK2 x,y } inTARSKIR2 cardCARD-1K1 W"
      using A9 ordinal1_th_12 sorry
    thus "{TARSKIK2 x,y } inTARSKIR2 W"
      using A1 A10 classes1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_3:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for W be setHIDDENM2 holds (W be TarskiCLASSES1V2 & x inTARSKIR2 W) & y inTARSKIR2 W implies [TARSKIK4 x,y ] inHIDDENR3 W"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies (x inTARSKIR2 W & y inTARSKIR2 W implies [TARSKIK4 x,y ] inHIDDENR3 W)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    assume A2: "x inTARSKIR2 W"
      and A3: "y inTARSKIR2 W"
    have A4: "{TARSKIK1 x} inTARSKIR2 W"
      using A1 A2 classes2_th_2 sorry
    have "{TARSKIK2 x,y } inTARSKIR2 W"
      using A1 A2 A3 classes2_th_2 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 W"
      using A1 A4 classes2_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_4:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & X inTARSKIR2 W implies Tarski-ClassCLASSES1K1 X c=TARSKIR1 W"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & X inTARSKIR2 W implies Tarski-ClassCLASSES1K1 X c=TARSKIR1 W"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
      and A2: "X inTARSKIR2 W"
    obtain D where 
      [ty]:"D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and DDef:"D = W"
      using A2 sorry
    have "D is-Tarski-Class-ofCLASSES1R1 X"
      using A1 A2 sorry
    thus "Tarski-ClassCLASSES1K1 X c=TARSKIR1 W"
      using classes1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_5:
" for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & A inTARSKIR2 W implies succORDINAL1K1 A inTARSKIR2 W & A c=TARSKIR1 W"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds  not ((W be TarskiCLASSES1V2 & A inTARSKIR2 W) &  not (succORDINAL1K1 A inTARSKIR2 W & A c=TARSKIR1 W))"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix W assume [ty]: "W be setHIDDENM2"
    have "( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 W & Y c=TARSKIR1 X implies Y inTARSKIR2 W) & (( for X be setHIDDENM2 holds X inTARSKIR2 W implies boolSETFAM-1K9 X inTARSKIR2 W) & (( for X be setHIDDENM2 holds X c=TARSKIR1 W implies (X,W)are-equipotentTARSKIR3 or X inTARSKIR2 W) & A inTARSKIR2 W)) implies succORDINAL1K1 A inTARSKIR2 W & A c=TARSKIR1 W"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
      assume A1: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 W & Y c=TARSKIR1 X implies Y inTARSKIR2 W"
        and A2: " for X be setHIDDENM2 holds X inTARSKIR2 W implies boolSETFAM-1K9 X inTARSKIR2 W"
        and " for X be setHIDDENM2 holds X c=TARSKIR1 W implies (X,W)are-equipotentTARSKIR3 or X inTARSKIR2 W"
        and A3: "A inTARSKIR2 W"
      have "boolSETFAM-1K9 A inTARSKIR2 W"
        using A2 A3 sorry
      thus "succORDINAL1K1 A inTARSKIR2 W"
        using A1 ordinal2_th_3 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 W"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 A"
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
           sorry
        have "B c=ORDINAL1R1 A"
          using A4 ordinal1_def_2 sorry
        thus "x inHIDDENR3 W"
          using A1 A3 sorry
      qed "sorry"
      thus "A c=TARSKIR1 W"
        using tarski_def_3 sorry
    qed
    thus " not ((W be TarskiCLASSES1V2 & A inTARSKIR2 W) &  not (succORDINAL1K1 A inTARSKIR2 W & A c=TARSKIR1 W))"
      using classes1_def_1 classes1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_6:
" for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds A inTARSKIR2 Tarski-ClassCLASSES1K1 W implies succORDINAL1K1 A inTARSKIR2 Tarski-ClassCLASSES1K1 W & A c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
  using classes2_th_5 sorry

mtheorem classes2_th_7:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds (W be subset-closedCLASSES1V1 & X be epsilon-transitiveORDINAL1V1) & X inTARSKIR2 W implies X c=TARSKIR1 W"
   sorry

mtheorem classes2_th_8:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 & X inTARSKIR2 Tarski-ClassCLASSES1K1 W implies X c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
  using classes2_th_7 sorry

mtheorem classes2_th_9:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies OnORDINAL1K2 W =XBOOLE-0R4 cardCARD-1K1 W"
proof-
  have " for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies OnORDINAL1K2 W =XBOOLE-0R4 cardCARD-1K1 W"
  proof(rule ballI,rule impI)
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    have " for X be setHIDDENM2 holds X inTARSKIR2 OnORDINAL1K2 W implies X be OrdinalORDINAL1M3 & X c=TARSKIR1 OnORDINAL1K2 W"
    proof(rule ballI,rule impI,rule conjMI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume A2: "X inTARSKIR2 OnORDINAL1K2 W"
      thus "X be OrdinalORDINAL1M3"
        using ordinal1_def_9 sorry
      obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = X"
        using A2 ordinal1_def_9 sorry
      have A3: "X inTARSKIR2 W"
        using A2 ordinal1_def_9 sorry
      show "X c=TARSKIR1 OnORDINAL1K2 W"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 OnORDINAL1K2 W"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 X"
          then have "x inHIDDENR3 A"
             sorry
          then obtain B where 
            [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
             sorry
          have "B c=ORDINAL1R1 A"
            using A4 ordinal1_def_2 sorry
          then have "B inTARSKIR2 W"
            using A1 A3 classes1_def_1 sorry
          thus "x inHIDDENR3 OnORDINAL1K2 W"
            using ordinal1_def_9 sorry
        qed "sorry"
        thus "X c=TARSKIR1 OnORDINAL1K2 W"
          using tarski_def_3 sorry
      qed
    qed "sorry"
    then obtain ON where 
      [ty]:"ON be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2" and ONDef:"ON = OnORDINAL1K2 W"
      using ordinal1_th_19 sorry
    have A5: "ON inTARSKIR2 W implies  False "
    proof(rule impI)
      assume "ON inTARSKIR2 W"
      then have "ON inTARSKIR2 ON"
        using ordinal1_def_9 sorry
      thus " False "
         sorry
    qed
    have "ON c=TARSKIR1 W"
      using ordinal2_th_7 sorry
    then have A6: "(ON,W)are-equipotentTARSKIR3 or ON inTARSKIR2 W"
      using A1 sorry
    have " for A be OrdinalORDINAL1M3 holds (A,ON)are-equipotentTARSKIR3 &  not ON c=ORDINAL1R1 A implies  False "
    proof(rule ballI,rule impMI ,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A7: "(A,ON)are-equipotentTARSKIR3"
        and A8: " not ON c=ORDINAL1R1 A"
      have "A inTARSKIR2 ON"
        using A8 ordinal1_th_16 sorry
      then have "A inTARSKIR2 W"
        using ordinal1_def_9 sorry
      thus " False "
        using A1 A6 A5 A7 classes2_th_1 wellord2_th_15 sorry
    qed "sorry"
    then have 
      [ty]:"ON be CardinalCARD-1M1"
      using card_1_def_1 sorry
    have "ON =XBOOLE-0R4 cardCARD-1K1 ON"
       sorry
    thus "OnORDINAL1K2 W =XBOOLE-0R4 cardCARD-1K1 W"
      using A6 A5 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_10:
" for W be setHIDDENM2 holds OnORDINAL1K2 Tarski-ClassCLASSES1K1 W =XBOOLE-0R4 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
  using classes2_th_9 sorry

mtheorem classes2_th_11:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & X inTARSKIR2 W implies cardCARD-1K1 X inTARSKIR2 W"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & X inTARSKIR2 W implies cardCARD-1K1 X inTARSKIR2 W"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
      and A2: "X inTARSKIR2 W"
    have A3: "cardCARD-1K1 W =XBOOLE-0R4 OnORDINAL1K2 W"
      using A1 classes2_th_9 sorry
    have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      using A1 A2 classes2_th_1 sorry
    thus "cardCARD-1K1 X inTARSKIR2 W"
      using A3 ordinal1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_12:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds X inTARSKIR2 Tarski-ClassCLASSES1K1 W implies cardCARD-1K1 X inTARSKIR2 Tarski-ClassCLASSES1K1 W"
  using classes2_th_11 sorry

mtheorem classes2_th_13:
" for x be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & x inTARSKIR2 cardCARD-1K1 W implies x inTARSKIR2 W"
proof-
  have " for x be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies (x inTARSKIR2 cardCARD-1K1 W implies x inTARSKIR2 W)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    assume "x inTARSKIR2 cardCARD-1K1 W"
    then have "x inTARSKIR2 OnORDINAL1K2 W"
      using A1 classes2_th_9 sorry
    thus "x inTARSKIR2 W"
      using ordinal1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_14:
" for x be setHIDDENM2 holds  for W be setHIDDENM2 holds x inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W implies x inTARSKIR2 Tarski-ClassCLASSES1K1 W"
  using classes2_th_13 sorry

mtheorem classes2_th_15:
" for m be CardinalCARD-1M1 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & m inTARSKIR2 cardCARD-1K1 W implies m inTARSKIR2 W"
proof-
  have " for m be CardinalCARD-1M1 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies (m inTARSKIR2 cardCARD-1K1 W implies m inTARSKIR2 W)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix m assume [ty]: "m be CardinalCARD-1M1"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    assume "m inTARSKIR2 cardCARD-1K1 W"
    then have "m inTARSKIR2 OnORDINAL1K2 W"
      using A1 classes2_th_9 sorry
    thus "m inTARSKIR2 W"
      using ordinal1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_16:
" for m be CardinalCARD-1M1 holds  for W be setHIDDENM2 holds m inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W implies m inTARSKIR2 Tarski-ClassCLASSES1K1 W"
proof-
  have " for m be CardinalCARD-1M1 holds  for W be setHIDDENM2 holds m inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W implies m inTARSKIR2 Tarski-ClassCLASSES1K1 W"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be CardinalCARD-1M1"
    fix W assume [ty]: "W be setHIDDENM2"
    assume "m inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
    then have "m inTARSKIR2 OnORDINAL1K2 Tarski-ClassCLASSES1K1 W"
      using classes2_th_9 sorry
    thus "m inTARSKIR2 Tarski-ClassCLASSES1K1 W"
      using ordinal1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_17:
" for m be CardinalCARD-1M1 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & m inTARSKIR2 W implies m c=TARSKIR1 W"
  using classes2_th_5 sorry

mtheorem classes2_th_18:
" for m be CardinalCARD-1M1 holds  for W be setHIDDENM2 holds m inTARSKIR2 Tarski-ClassCLASSES1K1 W implies m c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
  using classes2_th_5 sorry

mtheorem classes2_th_19:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies cardCARD-1K1 W be limit-ordinalORDINAL1V4"
proof-
  have " for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies cardCARD-1K1 W be limit-ordinalORDINAL1V4"
  proof(rule ballI,rule impI)
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 cardCARD-1K1 W implies succORDINAL1K1 A inTARSKIR2 cardCARD-1K1 W"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume "A inTARSKIR2 cardCARD-1K1 W"
      then have "A inTARSKIR2 W"
        using A1 classes2_th_13 sorry
      then have "succORDINAL1K1 A inTARSKIR2 W"
        using A1 classes2_th_5 sorry
      then have "succORDINAL1K1 A inTARSKIR2 OnORDINAL1K2 W"
        using ordinal1_def_9 sorry
      thus "succORDINAL1K1 A inTARSKIR2 cardCARD-1K1 W"
        using A1 classes2_th_9 sorry
    qed "sorry"
    thus "cardCARD-1K1 W be limit-ordinalORDINAL1V4"
      using ordinal1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_20:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & W <>HIDDENR2 {}XBOOLE-0K1 implies (cardCARD-1K1 W <>HIDDENR2 0NUMBERSK6 & cardCARD-1K1 W <>HIDDENR2 {}XBOOLE-0K1) & cardCARD-1K1 W be limit-ordinalORDINAL1V4"
  using classes2_th_19 sorry

mtheorem classes2_th_21:
" for W be setHIDDENM2 holds (cardCARD-1K1 Tarski-ClassCLASSES1K1 W <>HIDDENR2 0NUMBERSK6 & cardCARD-1K1 Tarski-ClassCLASSES1K1 W <>HIDDENR2 {}XBOOLE-0K1) & cardCARD-1K1 Tarski-ClassCLASSES1K1 W be limit-ordinalORDINAL1V4"
proof-
  have " for W be setHIDDENM2 holds cardCARD-1K1 Tarski-ClassCLASSES1K1 W <>HIDDENR2 0NUMBERSK6 & (cardCARD-1K1 Tarski-ClassCLASSES1K1 W <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K1 Tarski-ClassCLASSES1K1 W be limit-ordinalORDINAL1V4)"
  proof(rule ballI,rule conjMI,rule conjMI)
    fix W assume [ty]: "W be setHIDDENM2"
    show "cardCARD-1K1 Tarski-ClassCLASSES1K1 W <>HIDDENR2 0NUMBERSK6"
       sorry
    show "cardCARD-1K1 Tarski-ClassCLASSES1K1 W <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W implies succORDINAL1K1 A inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume "A inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
      then have "A inTARSKIR2 Tarski-ClassCLASSES1K1 W"
        using classes2_th_13 sorry
      then have "succORDINAL1K1 A inTARSKIR2 Tarski-ClassCLASSES1K1 W"
        using classes2_th_5 sorry
      then have "succORDINAL1K1 A inTARSKIR2 OnORDINAL1K2 Tarski-ClassCLASSES1K1 W"
        using ordinal1_def_9 sorry
      thus "succORDINAL1K1 A inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
        using classes2_th_9 sorry
    qed "sorry"
    thus "cardCARD-1K1 Tarski-ClassCLASSES1K1 W be limit-ordinalORDINAL1V4"
      using ordinal1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f, g for "FunctionFUNCT-1M1"
reserve L for "SequenceORDINAL1M4"
reserve F for "Cardinal-FunctionCARD-3M1"
mtheorem classes2_th_22:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & ((X inTARSKIR2 W & W be epsilon-transitiveORDINAL1V1 or X inTARSKIR2 W & X c=TARSKIR1 W) or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W & X c=TARSKIR1 W) implies FuncsFUNCT-2K1(X,W) c=TARSKIR1 W"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies ((X inTARSKIR2 W & W be epsilon-transitiveORDINAL1V1 or X inTARSKIR2 W & X c=TARSKIR1 W) or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W & X c=TARSKIR1 W implies FuncsFUNCT-2K1(X,W) c=TARSKIR1 W)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    assume A2: "(X inTARSKIR2 W & W be epsilon-transitiveORDINAL1V1 or X inTARSKIR2 W & X c=TARSKIR1 W) or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W & X c=TARSKIR1 W"
    have A3: "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      using A1 A2 classes2_th_1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(X,W) implies x inHIDDENR3 W"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 FuncsFUNCT-2K1(X,W)"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A5: "x =HIDDENR1 f"and A6: "domRELAT-1K1 f =XBOOLE-0R4 X"and A7: "rngFUNCT-1K2 f c=TARSKIR1 W"
        using funct_2_def_2 sorry
      have A8: "X c=TARSKIR1 W"
        using A2 sorry
      have A9: "f c=RELAT-1R2 W"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 f implies y inHIDDENR3 W"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A10: "y inHIDDENR3 f"
          then obtain y1 y2 where
            [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
            A11: "[TARSKIK4 y1,y2 ] =HIDDENR1 y"
            using relat_1_def_1 sorry
          have A12: "y1 inHIDDENR3 domRELAT-1K1 f"
            using A10 A11 funct_1_th_1 sorry
          have "y2 =HIDDENR1 f .FUNCT-1K1 y1"
            using A10 A11 funct_1_th_1 sorry
          then have "y2 inHIDDENR3 rngFUNCT-1K2 f"
            using A12 funct_1_def_3 sorry
          thus "y inHIDDENR3 W"
            using A1 A8 A6 A7 A11 A12 classes2_th_3 sorry
        qed "sorry"
        thus "f c=RELAT-1R2 W"
          using tarski_def_3 sorry
      qed
      have "cardCARD-1K1 f =XBOOLE-0R4 cardCARD-1K1 X"
        using A4 A5 card_2_th_3 sorry
      thus "x inHIDDENR3 W"
        using A1 A3 A5 A9 classes1_th_1 sorry
    qed "sorry"
    thus "FuncsFUNCT-2K1(X,W) c=TARSKIR1 W"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_23:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds (X inTARSKIR2 Tarski-ClassCLASSES1K1 W & W be epsilon-transitiveORDINAL1V1 or X inTARSKIR2 Tarski-ClassCLASSES1K1 W & X c=TARSKIR1 Tarski-ClassCLASSES1K1 W) or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W & X c=TARSKIR1 Tarski-ClassCLASSES1K1 W implies FuncsFUNCT-2K9(X,Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds (X inTARSKIR2 Tarski-ClassCLASSES1K1 W & W be epsilon-transitiveORDINAL1V1 or X inTARSKIR2 Tarski-ClassCLASSES1K1 W & X c=TARSKIR1 Tarski-ClassCLASSES1K1 W) or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W & X c=TARSKIR1 Tarski-ClassCLASSES1K1 W implies FuncsFUNCT-2K9(X,Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "(X inTARSKIR2 Tarski-ClassCLASSES1K1 W & W be epsilon-transitiveORDINAL1V1 or X inTARSKIR2 Tarski-ClassCLASSES1K1 W & X c=TARSKIR1 Tarski-ClassCLASSES1K1 W) or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W & X c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
    have A2: "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
      using A1 classes1_th_24 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K9(X,Tarski-ClassCLASSES1K1 W) implies x inHIDDENR3 Tarski-ClassCLASSES1K1 W"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 FuncsFUNCT-2K9(X,Tarski-ClassCLASSES1K1 W)"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A4: "x =HIDDENR1 f"and A5: "domRELAT-1K1 f =XBOOLE-0R4 X"and A6: "rngFUNCT-1K2 f c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
        using funct_2_def_2 sorry
      have "W be epsilon-transitiveORDINAL1V1 implies Tarski-ClassCLASSES1K1 W be epsilon-transitiveORDINAL1V1"
        using classes1_th_23 sorry
      then have A7: "X c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
        using A1 sorry
      have A8: "f c=RELAT-1R2 Tarski-ClassCLASSES1K1 W"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 f implies y inHIDDENR3 Tarski-ClassCLASSES1K1 W"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A9: "y inHIDDENR3 f"
          then obtain y1 y2 where
            [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
            A10: "[TARSKIK4 y1,y2 ] =HIDDENR1 y"
            using relat_1_def_1 sorry
          have A11: "y1 inHIDDENR3 domRELAT-1K1 f"
            using A9 A10 funct_1_th_1 sorry
          have "y2 =HIDDENR1 f .FUNCT-1K1 y1"
            using A9 A10 funct_1_th_1 sorry
          then have "y2 inHIDDENR3 rngFUNCT-1K2 f"
            using A11 funct_1_def_3 sorry
          thus "y inHIDDENR3 Tarski-ClassCLASSES1K1 W"
            using A7 A5 A6 A10 A11 classes1_th_27 sorry
        qed "sorry"
        thus "f c=RELAT-1R2 Tarski-ClassCLASSES1K1 W"
          using tarski_def_3 sorry
      qed
      have "cardCARD-1K1 f =XBOOLE-0R4 cardCARD-1K1 X"
        using A3 A4 card_2_th_3 sorry
      thus "x inHIDDENR3 Tarski-ClassCLASSES1K1 W"
        using A2 A4 A8 classes1_th_6 sorry
    qed "sorry"
    thus "FuncsFUNCT-2K9(X,Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_24:
" for L be SequenceORDINAL1M4 holds domRELAT-1K1 L be limit-ordinalORDINAL1V4 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies L .FUNCT-1K1 A =XBOOLE-0R4 RankCLASSES1K4 A) implies RankCLASSES1K4 (domRELAT-1K1 L) =XBOOLE-0R4 UnionCARD-3K3 L"
proof-
  have " for L be SequenceORDINAL1M4 holds domRELAT-1K1 L be limit-ordinalORDINAL1V4 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies L .FUNCT-1K1 A =XBOOLE-0R4 RankCLASSES1K4 A) implies RankCLASSES1K4 (domRELAT-1K1 L) =XBOOLE-0R4 UnionCARD-3K3 L"
  proof(rule ballI,rule impMI ,rule impI)
    fix L assume [ty]: "L be SequenceORDINAL1M4"
    assume A1: "domRELAT-1K1 L be limit-ordinalORDINAL1V4"
      and A2: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies L .FUNCT-1K1 A =XBOOLE-0R4 RankCLASSES1K4 A"
    have A3: "unionTARSKIK3 (rngFUNCT-1K2 L) =XBOOLE-0R4 UnionCARD-3K3 L"
      using card_3_def_4 sorry
    have "domRELAT-1K1 L <>HIDDENR2 {}XBOOLE-0K1 implies RankCLASSES1K4 (domRELAT-1K1 L) c=TARSKIR1 UnionCARD-3K3 L & UnionCARD-3K3 L c=TARSKIR1 RankCLASSES1K4 (domRELAT-1K1 L)"
    proof(rule impI,rule conjMI)
      assume A4: "domRELAT-1K1 L <>HIDDENR2 {}XBOOLE-0K1"
      show "RankCLASSES1K4 (domRELAT-1K1 L) c=TARSKIR1 UnionCARD-3K3 L"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 RankCLASSES1K4 (domRELAT-1K1 L) implies x inHIDDENR3 UnionCARD-3K3 L"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 RankCLASSES1K4 (domRELAT-1K1 L)"
          then obtain A where
            [ty]:"A be OrdinalORDINAL1M3" and 
            A5: "A inTARSKIR2 domRELAT-1K1 L"and A6: "x inHIDDENR3 RankCLASSES1K4 A"
            using A1 A4 classes1_th_31 sorry
          have "L .FUNCT-1K1 A =XBOOLE-0R4 RankCLASSES1K4 A"
            using A2 A5 sorry
          then have "RankCLASSES1K4 A inTARSKIR2 rngFUNCT-1K2 L"
            using A5 funct_1_def_3 sorry
          thus "x inHIDDENR3 UnionCARD-3K3 L"
            using A3 A6 tarski_def_4 sorry
        qed "sorry"
        thus "RankCLASSES1K4 (domRELAT-1K1 L) c=TARSKIR1 UnionCARD-3K3 L"
          using tarski_def_3 sorry
      qed
      show "UnionCARD-3K3 L c=TARSKIR1 RankCLASSES1K4 (domRELAT-1K1 L)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 UnionCARD-3K3 L implies x inHIDDENR3 RankCLASSES1K4 (domRELAT-1K1 L)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 UnionCARD-3K3 L"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A7: "x inHIDDENR3 X"and A8: "X inTARSKIR2 rngFUNCT-1K2 L"
            using A3 tarski_def_4 sorry
          obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A9: "y inHIDDENR3 domRELAT-1K1 L"and A10: "X =XBOOLE-0R4 L .FUNCT-1K1 y"
            using A8 funct_1_def_3 sorry
          have 
            [ty]:"y be OrdinalORDINAL1M3"
            using A9 sorry
          have "X =XBOOLE-0R4 RankCLASSES1K4 y"
            using A2 A9 A10 sorry
          thus "x inHIDDENR3 RankCLASSES1K4 (domRELAT-1K1 L)"
            using A1 A7 A9 classes1_th_31 sorry
        qed "sorry"
        thus "UnionCARD-3K3 L c=TARSKIR1 RankCLASSES1K4 (domRELAT-1K1 L)"
          using tarski_def_3 sorry
      qed
    qed
    thus "RankCLASSES1K4 (domRELAT-1K1 L) =XBOOLE-0R4 UnionCARD-3K3 L"
      using A3 classes1_th_29 relat_1_th_42 zfmisc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma classes2_lm_2:
"W be TarskiCLASSES1V2 & 0NUMBERSK6 inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 (0NUMBERSK6) inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 (0NUMBERSK6) inTARSKIR2 W"
  using classes2_th_9 classes1_th_29 ordinal1_def_9 sorry

mlemma classes2_lm_3:
" for A be OrdinalORDINAL1M3 holds (W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W) implies (W be TarskiCLASSES1V2 & succORDINAL1K1 A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 (succORDINAL1K1 A) inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 (succORDINAL1K1 A) inTARSKIR2 W)"
proof-
  have " for A be OrdinalORDINAL1M3 holds (W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W) implies ( for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & succORDINAL1K1 A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 (succORDINAL1K1 A) inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 (succORDINAL1K1 A) inTARSKIR2 W)"
  proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume A1: "W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W"
    have A2: "A inTARSKIR2 succORDINAL1K1 A"
      using ordinal1_th_6 sorry
    fix W assume [ty]: "W be setHIDDENM2"
    assume A3: "W be TarskiCLASSES1V2"
      and A4: "succORDINAL1K1 A inTARSKIR2 OnORDINAL1K2 W"
    have "cardCARD-1K1 W =XBOOLE-0R4 OnORDINAL1K2 W"
      using A3 classes2_th_9 sorry
    then have "A inTARSKIR2 OnORDINAL1K2 W"
      using A4 A2 ordinal1_th_10 sorry
    then have "RankCLASSES1K4 A inTARSKIR2 W"
      using A1 A3 sorry
    then have A5: "boolSETFAM-1K9 RankCLASSES1K4 A inTARSKIR2 W"
      using A3 sorry
    have "RankCLASSES1K4 (succORDINAL1K1 A) =XBOOLE-0R4 boolSETFAM-1K9 RankCLASSES1K4 A"
      using classes1_th_30 sorry
    thus "cardCARD-1K1 RankCLASSES1K4 (succORDINAL1K1 A) inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 (succORDINAL1K1 A) inTARSKIR2 W"
      using A3 A5 classes2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma classes2_lm_4:
" for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0NUMBERSK6 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (W be TarskiCLASSES1V2 & B inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 B inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 B inTARSKIR2 W)) implies (W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W)"
proof-
  have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0NUMBERSK6 & (A be limit-ordinalORDINAL1V4 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (W be TarskiCLASSES1V2 & B inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 B inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 B inTARSKIR2 W))) implies ( for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W)"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?f = "\<lambda>Lamb1. RankCLASSES1K4 Lamb1"
    assume A1: "A <>HIDDENR2 0NUMBERSK6"
      and A2: "A be limit-ordinalORDINAL1V4"
      and A3: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (W be TarskiCLASSES1V2 & B inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 B inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 B inTARSKIR2 W)"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A4: "W be TarskiCLASSES1V2"
      and A5: "A inTARSKIR2 OnORDINAL1K2 W"
    obtain L where
      [ty]:"L be SequenceORDINAL1M4" and 
      A6: "domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 ?f(B))"
      using ordinal2_sch_2 sorry
    let ?g = "\<lambda>Lamb1. cardCARD-1K1 (boolSETFAM-1K9 (L .FUNCT-1K1 Lamb1))"
    obtain F where
      [ty]:"F be Cardinal-FunctionCARD-3M1" and 
      A7: "domRELAT-1K1 F =XBOOLE-0R4 A & ( for x be setHIDDENM2 holds x inTARSKIR2 A implies F .FUNCT-1K1 x =XBOOLE-0R4 ?g(x))"
      using card_3_sch_1 sorry
    have A8: "productCARD-3K4 F c=TARSKIR1 FuncsFUNCT-2K1(A,W)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 F implies x inHIDDENR3 FuncsFUNCT-2K1(A,W)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 F"
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A9: "x =HIDDENR1 f"and A10: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 F"and A11: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies f .FUNCT-1K1 x inTARSKIR2 F .FUNCT-1K1 x"
          using card_3_def_5 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 W"
        proof-
          have A12: "A inTARSKIR2 W"
            using A5 ordinal1_def_9 sorry
          have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 f implies z inHIDDENR3 W"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A13: "y inHIDDENR3 domRELAT-1K1 f"and A14: "z =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A7 A10 A13 sorry
            have A15: "f .FUNCT-1K1 y inTARSKIR2 F .FUNCT-1K1 y"
              using A10 A11 A13 sorry
            have "y c=ORDINAL1R1 A"
              using A7 A10 A13 ordinal1_def_2 sorry
            then have "y inTARSKIR2 W"
              using A4 A12 classes1_def_1 sorry
            then have A16: "y inTARSKIR2 OnORDINAL1K2 W"
              using ordinal1_def_9 sorry
            have "L .FUNCT-1K1 y =XBOOLE-0R4 RankCLASSES1K4 y"
              using A6 A7 A10 A13 sorry
            then have "L .FUNCT-1K1 y inTARSKIR2 W"
              using A3 A4 A7 A10 A13 A16 sorry
            then have "boolSETFAM-1K9 (L .FUNCT-1K1 y) inTARSKIR2 W"
              using A4 sorry
            then have A17: "cardCARD-1K1 (boolSETFAM-1K9 (L .FUNCT-1K1 y)) inTARSKIR2 W"
              using A4 classes2_th_11 sorry
            have "F .FUNCT-1K1 y =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 (L .FUNCT-1K1 y))"
              using A7 A10 A13 sorry
            then have "F .FUNCT-1K1 y c=TARSKIR1 W"
              using A4 A17 classes2_th_5 sorry
            thus "z inHIDDENR3 W"
              using A14 A15 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 W"
            using tarski_def_3 sorry
        qed
        thus "x inHIDDENR3 FuncsFUNCT-2K1(A,W)"
          using A7 A9 A10 funct_2_def_2 sorry
      qed "sorry"
      thus "productCARD-3K4 F c=TARSKIR1 FuncsFUNCT-2K1(A,W)"
        using tarski_def_3 sorry
    qed
    have A18: "ProductCARD-3K7 F =XBOOLE-0R4 cardCARD-1K1 (productCARD-3K4 F)"
      using card_3_def_8 sorry
    have A19: "A inTARSKIR2 W"
      using A5 ordinal1_def_9 sorry
    then have "A c=TARSKIR1 W"
      using A4 classes2_th_5 sorry
    then have "FuncsFUNCT-2K1(A,W) c=TARSKIR1 W"
      using A4 A19 classes2_th_22 sorry
    then have "productCARD-3K4 F c=TARSKIR1 W"
      using A8 sorry
    then have A20: "ProductCARD-3K7 F c=ORDINAL1R1 cardCARD-1K1 W"
      using A18 card_1_th_11 sorry
    have A21: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 L) implies CardCARD-3K1 L .FUNCT-1K1 x inTARSKIR2 F .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A22: "cardCARD-1K1 (L .FUNCT-1K1 x) inTARSKIR2 cardCARD-1K1 (boolSETFAM-1K9 (L .FUNCT-1K1 x))"
        using card_1_th_14 sorry
      assume "x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 L)"
      then have A23: "x inHIDDENR3 domRELAT-1K1 L"
        using card_3_def_2 sorry
      then have "F .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 (L .FUNCT-1K1 x))"
        using A6 A7 sorry
      thus "CardCARD-3K1 L .FUNCT-1K1 x inTARSKIR2 F .FUNCT-1K1 x"
        using A23 A22 card_3_def_2 sorry
    qed "sorry"
    have "domRELAT-1K1 (CardCARD-3K1 L) =XBOOLE-0R4 domRELAT-1K1 L"
      using card_3_def_2 sorry
    then have A24: "SumCARD-3K6 (CardCARD-3K1 L) inTARSKIR2 ProductCARD-3K7 F"
      using A6 A7 A21 card_3_th_41 sorry
    have A25: "RankCLASSES1K4 A c=TARSKIR1 W"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 RankCLASSES1K4 A implies x inHIDDENR3 W"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 RankCLASSES1K4 A"
        then obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A26: "B inTARSKIR2 A"and A27: "x inHIDDENR3 RankCLASSES1K4 B"
          using A1 A2 classes1_th_31 sorry
        have "B c=ORDINAL1R1 A"
          using A26 ordinal1_def_2 sorry
        then have "B inTARSKIR2 W"
          using A4 A19 classes1_def_1 sorry
        then have "B inTARSKIR2 OnORDINAL1K2 W"
          using ordinal1_def_9 sorry
        then have "RankCLASSES1K4 B c=TARSKIR1 W"
          using A3 A4 A26 classes2_th_7 sorry
        thus "x inHIDDENR3 W"
          using A27 sorry
      qed "sorry"
      thus "RankCLASSES1K4 A c=TARSKIR1 W"
        using tarski_def_3 sorry
    qed
    have A28: "RankCLASSES1K4 A =XBOOLE-0R4 UnionCARD-3K3 L"
      using A2 A6 classes2_th_24 sorry
    thus "cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W"
      using A24 A20 card_3_th_39 ordinal1_th_12 sorry
    have "cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 ProductCARD-3K7 F"
      using A28 A24 card_3_th_39 ordinal1_th_12 sorry
    thus "RankCLASSES1K4 A inTARSKIR2 W"
      using A4 A20 A25 classes1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_25:
" for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds  not ((W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W) &  not (cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W))"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix W assume [ty]: "W be setHIDDENM2"
    have " for B be OrdinalORDINAL1M3 holds W be TarskiCLASSES1V2 & B inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 B inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 B inTARSKIR2 W"
      using ordinal2_sch_1 classes2_lm_2 classes2_lm_3 classes2_lm_4 sorry
    thus " not ((W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W) &  not (cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W & RankCLASSES1K4 A inTARSKIR2 W))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_26:
" for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds A inTARSKIR2 OnORDINAL1K2 Tarski-ClassCLASSES1K1 W implies cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W & RankCLASSES1K4 A inTARSKIR2 Tarski-ClassCLASSES1K1 W"
  using classes2_th_25 sorry

mtheorem classes2_th_27:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies RankCLASSES1K4 (cardCARD-1K1 W) c=TARSKIR1 W"
proof-
  have " for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies RankCLASSES1K4 (cardCARD-1K1 W) c=TARSKIR1 W"
  proof(rule ballI,rule impI)
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    have "W <>HIDDENR2 {}XBOOLE-0K1 implies RankCLASSES1K4 (cardCARD-1K1 W) c=TARSKIR1 W"
    proof(rule impI)
      assume A2: "W <>HIDDENR2 {}XBOOLE-0K1"
      show "RankCLASSES1K4 (cardCARD-1K1 W) c=TARSKIR1 W"
      proof-
        have A3: "cardCARD-1K1 W be limit-ordinalORDINAL1V4"
          using A1 classes2_th_19 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 W) implies x inHIDDENR3 W"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 W)"
          then obtain A where
            [ty]:"A be OrdinalORDINAL1M3" and 
            A4: "A inTARSKIR2 cardCARD-1K1 W"and A5: "x inHIDDENR3 RankCLASSES1K4 A"
            using A2 A3 classes1_th_31 sorry
          have "A inTARSKIR2 OnORDINAL1K2 W"
            using A1 A4 classes2_th_9 sorry
          then have "RankCLASSES1K4 A c=TARSKIR1 W"
            using A1 classes2_th_7 classes2_th_25 sorry
          thus "x inHIDDENR3 W"
            using A5 sorry
        qed "sorry"
        thus "RankCLASSES1K4 (cardCARD-1K1 W) c=TARSKIR1 W"
          using tarski_def_3 sorry
      qed
    qed
    thus "RankCLASSES1K4 (cardCARD-1K1 W) c=TARSKIR1 W"
      using classes1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_28:
" for W be setHIDDENM2 holds RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
proof-
  have " for W be setHIDDENM2 holds RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
  proof(rule ballI)
    fix W assume [ty]: "W be setHIDDENM2"
    have A1: "cardCARD-1K1 Tarski-ClassCLASSES1K1 W be limit-ordinalORDINAL1V4"
      using classes2_th_21 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) implies x inHIDDENR3 Tarski-ClassCLASSES1K1 W"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W)"
      then obtain A where
        [ty]:"A be OrdinalORDINAL1M3" and 
        A2: "A inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"and A3: "x inHIDDENR3 RankCLASSES1K4 A"
        using A1 classes1_th_31 sorry
      have "A inTARSKIR2 OnORDINAL1K2 Tarski-ClassCLASSES1K1 W"
        using A2 classes2_th_9 sorry
      then have "RankCLASSES1K4 A c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
        using classes2_th_7 classes2_th_25 sorry
      thus "x inHIDDENR3 Tarski-ClassCLASSES1K1 W"
        using A3 sorry
    qed "sorry"
    thus "RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_29:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds (W be TarskiCLASSES1V2 & W be epsilon-transitiveORDINAL1V1) & X inTARSKIR2 W implies the-rank-ofCLASSES1K7 X inTARSKIR2 W"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & W be epsilon-transitiveORDINAL1V1 implies (X inTARSKIR2 W &  not the-rank-ofCLASSES1K7 X inTARSKIR2 W implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
      and A2: "W be epsilon-transitiveORDINAL1V1"
    have A3: "OnORDINAL1K2 W =XBOOLE-0R4 cardCARD-1K1 W"
      using A1 classes2_th_9 sorry
    let ?P = "\<lambda>Lamb1.  ex X be setHIDDENM2 st (Lamb1 =XBOOLE-0R4 the-rank-ofCLASSES1K7 X & X inTARSKIR2 W) &  not Lamb1 inTARSKIR2 W"
    assume A4: "X inTARSKIR2 W"
      and A5: " not the-rank-ofCLASSES1K7 X inTARSKIR2 W"
    have A6: " ex A be OrdinalORDINAL1M3 st ?P(A)"
      using A4 A5 sorry
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A7: "?P(A)"and A8: " for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B"
      using ordinal1_sch_1 A6 sorry
    obtain X where
      [ty]:"X be setHIDDENM2" and 
      A9: "A =XBOOLE-0R4 the-rank-ofCLASSES1K7 X"and A10: "X inTARSKIR2 W"and A11: " not A inTARSKIR2 W"
      using A7 sorry
    let ?P = "\<lambda>Lamb1.  ex Y be setHIDDENM2 st Y inTARSKIR2 X & Lamb1 =HIDDENR1 the-rank-ofCLASSES1K7 Y"
    obtain LL where
      [ty]:"LL be setHIDDENM2" and 
      A12: " for x be objectHIDDENM1 holds x inHIDDENR3 LL iff x inHIDDENR3 OnORDINAL1K2 W & ?P(x)"
      using xboole_0_sch_1 sorry
    obtain ff where
      [ty]:"ff be Cardinal-FunctionCARD-3M1" and 
      A13: "domRELAT-1K1 ff =XBOOLE-0R4 LL & ( for x be setHIDDENM2 holds x inTARSKIR2 LL implies ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 x))"
      using card_3_sch_1 sorry
    have A14: "LL c=TARSKIR1 OnORDINAL1K2 W"
      using A12 sorry
    have A15: "productCARD-3K4 ff c=TARSKIR1 FuncsFUNCT-2K1(LL,W)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 ff implies x inHIDDENR3 FuncsFUNCT-2K1(LL,W)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 ff"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A16: "x =HIDDENR1 g"and A17: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ff"and A18: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ff implies g .FUNCT-1K1 x inTARSKIR2 ff .FUNCT-1K1 x"
          using card_3_def_5 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 W"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 W"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 g"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A19: "x inHIDDENR3 domRELAT-1K1 g"and A20: "y =HIDDENR1 g .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have 
              [ty]:"x be setHIDDENM2"
              using tarski_th_1 sorry
            have A21: "ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 x)"
              using A13 A17 A19 sorry
            have "x inTARSKIR2 W"
              using A14 A13 A17 A19 ordinal1_def_9 sorry
            then have "boolSETFAM-1K9 x inTARSKIR2 W"
              using A1 sorry
            then have "cardCARD-1K1 (boolSETFAM-1K9 x) inTARSKIR2 W"
              using A1 classes2_th_11 sorry
            then have A22: "cardCARD-1K1 (boolSETFAM-1K9 x) c=TARSKIR1 W"
              using A1 classes2_th_5 sorry
            have "y inHIDDENR3 ff .FUNCT-1K1 x"
              using A17 A18 A19 A20 sorry
            thus "y inHIDDENR3 W"
              using A21 A22 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 g c=TARSKIR1 W"
            using tarski_def_3 sorry
        qed
        thus "x inHIDDENR3 FuncsFUNCT-2K1(LL,W)"
          using A13 A16 A17 funct_2_def_2 sorry
      qed "sorry"
      thus "productCARD-3K4 ff c=TARSKIR1 FuncsFUNCT-2K1(LL,W)"
        using tarski_def_3 sorry
    qed
    have " for Z be setHIDDENM2 holds Z inTARSKIR2 unionTARSKIK3 LL implies Z be OrdinalORDINAL1M3 & Z c=TARSKIR1 unionTARSKIK3 LL"
    proof(rule ballI,rule impI,rule conjMI)
      fix Z assume [ty]: "Z be setHIDDENM2"
      assume "Z inTARSKIR2 unionTARSKIK3 LL"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A23: "Z inTARSKIR2 Y"and A24: "Y inTARSKIR2 LL"
        using tarski_def_4 sorry
      have "Y inTARSKIR2 OnORDINAL1K2 W"
        using A12 A24 sorry
      then have 
        [ty]:"Y be OrdinalORDINAL1M3"
        using ordinal1_def_9 sorry
      have A25: "Y c=TARSKIR1 unionTARSKIK3 LL"
        using A24 zfmisc_1_th_74 sorry
      have A26: "Z inTARSKIR2 Y"
        using A23 sorry
      thus "Z be OrdinalORDINAL1M3"
         sorry
      obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = Z"
        using A26 sorry
      have "A c=ORDINAL1R1 Y"
        using A23 ordinal1_def_2 sorry
      thus "Z c=TARSKIR1 unionTARSKIK3 LL"
        using A25 sorry
    qed "sorry"
    then obtain ULL where 
      [ty]:"ULL be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2" and ULLDef:"ULL = unionTARSKIK3 LL"
      using ordinal1_th_19 sorry
    have A27: "domRELAT-1K1 (CardCARD-3K1 (idRELAT-1K7 LL)) =XBOOLE-0R4 domRELAT-1K1 (idRELAT-1K7 LL)"
      using card_3_def_2 sorry
    have A28: "domRELAT-1K1 (idRELAT-1K7 LL) =XBOOLE-0R4 LL"
      using relat_1_th_45 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 (idRELAT-1K7 LL)) implies CardCARD-3K1 (idRELAT-1K7 LL) .FUNCT-1K1 x inTARSKIR2 ff .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A29: "x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 (idRELAT-1K7 LL))"
      then have A30: "CardCARD-3K1 (idRELAT-1K7 LL) .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (idRELAT-1K7 LL .FUNCT-1K1 x)"
        using A27 card_3_def_2 sorry
      have A31: "idRELAT-1K7 LL .FUNCT-1K1 x =HIDDENR1 x"
        using A28 A27 A29 funct_1_th_18 sorry
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      have "ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 xx)"
        using A13 A28 A27 A29 sorry
      thus "CardCARD-3K1 (idRELAT-1K7 LL) .FUNCT-1K1 x inTARSKIR2 ff .FUNCT-1K1 x"
        using A31 A30 card_1_th_14 sorry
    qed "sorry"
    then have A32: "SumCARD-3K6 (CardCARD-3K1 (idRELAT-1K7 LL)) inTARSKIR2 ProductCARD-3K7 ff"
      using A13 A28 A27 card_3_th_41 sorry
    have "UnionCARD-3K3 idRELAT-1K7 LL =HIDDENR1 unionTARSKIK3 (rngFUNCT-1K2 (idRELAT-1K7 LL))"
      using card_3_def_4 sorry
    also have "... = ULL"
      using relat_1_th_45 sorry
    finally have "UnionCARD-3K3 idRELAT-1K7 LL =HIDDENR1 ULL"
       sorry
    then have A33: "cardCARD-1K1 ULL inTARSKIR2 ProductCARD-3K7 ff"
      using A32 card_3_th_39 ordinal1_th_12 sorry
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A34: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 the-rank-ofCLASSES1K6 x)"
      using funct_1_sch_3 sorry
    have "LL c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 LL implies x inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 LL"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A35: "Y inTARSKIR2 X"and A36: "x =HIDDENR1 the-rank-ofCLASSES1K7 Y"
          using A12 sorry
        have "f .FUNCT-1K1 Y =HIDDENR1 x"
          using A34 A35 A36 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 f"
          using A34 A35 funct_1_def_3 sorry
      qed "sorry"
      thus "LL c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    then have A37: "cardCARD-1K1 LL c=ORDINAL1R1 cardCARD-1K1 X"
      using A34 card_1_th_12 sorry
    have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      using A1 A10 classes2_th_1 sorry
    then have "cardCARD-1K1 LL <>HIDDENR2 cardCARD-1K1 W"
      using A37 ordinal1_th_12 sorry
    then have A38: " not (LL,W)are-equipotentTARSKIR3"
      using card_1_th_5 sorry
    have A39: "cardCARD-1K1 (productCARD-3K4 ff) =XBOOLE-0R4 ProductCARD-3K7 ff"
      using card_3_def_8 sorry
    have A40: "X c=TARSKIR1 W"
      using A2 A10 sorry
    have "X c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 W)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        assume A41: "x inHIDDENR3 X"
        then have " not A c=ORDINAL1R1 the-rank-ofCLASSES1K7 xx"
          using A9 classes1_th_68 ordinal1_th_5 sorry
        then have "the-rank-ofCLASSES1K7 xx inTARSKIR2 W"
          using A8 A40 A41 sorry
        then have "the-rank-ofCLASSES1K7 xx inTARSKIR2 cardCARD-1K1 W"
          using A3 ordinal1_def_9 sorry
        then have A42: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 xx) inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
          using classes1_th_36 sorry
        have "xx c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 xx)"
          using classes1_def_9 sorry
        thus "x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 W)"
          using A42 classes1_th_41 sorry
      qed "sorry"
      thus "X c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W)"
        using tarski_def_3 sorry
    qed
    then have A43: "A c=TARSKIR1 OnORDINAL1K2 W"
      using A9 A3 classes1_th_65 sorry
    have "OnORDINAL1K2 W c=TARSKIR1 ULL"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 W implies x inHIDDENR3 ULL"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A44: "x inHIDDENR3 OnORDINAL1K2 W"
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
          using ordinal1_def_9 sorry
        have "( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 B) implies  False "
        proof(rule impI)
          assume A45: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 B"
          have "X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 B)"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B)"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              obtain yy where 
                [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
                using tarski_th_1 sorry
              assume "y inHIDDENR3 X"
              then have "the-rank-ofCLASSES1K7 yy c=ORDINAL1R1 B"
                using A45 sorry
              then have "the-rank-ofCLASSES1K7 yy inTARSKIR2 succORDINAL1K1 B"
                using ordinal1_th_22 sorry
              thus "y inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 B)"
                using classes1_th_66 sorry
            qed "sorry"
            thus "X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 B)"
              using tarski_def_3 sorry
          qed
          then have A46: "A c=ORDINAL1R1 succORDINAL1K1 B"
            using A9 classes1_th_65 sorry
          have "B inTARSKIR2 W"
            using A44 ordinal1_def_9 sorry
          then have "succORDINAL1K1 B inTARSKIR2 W"
            using A1 classes2_th_5 sorry
          thus " False "
            using A1 A11 A46 classes1_def_1 sorry
        qed
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A47: "Y inTARSKIR2 X"and A48: " not the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 B"
           sorry
        have "the-rank-ofCLASSES1K7 Y inTARSKIR2 A"
          using A9 A47 classes1_th_68 sorry
        then have "the-rank-ofCLASSES1K7 Y inTARSKIR2 LL"
          using A43 A12 A47 sorry
        then have A49: "the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 ULL"
          using zfmisc_1_th_74 sorry
        have "B inTARSKIR2 the-rank-ofCLASSES1K7 Y"
          using A48 ordinal1_th_16 sorry
        thus "x inHIDDENR3 ULL"
          using A49 sorry
      qed "sorry"
      thus "OnORDINAL1K2 W c=TARSKIR1 ULL"
        using tarski_def_3 sorry
    qed
    then have A50: "cardCARD-1K1 (OnORDINAL1K2 W) c=ORDINAL1R1 cardCARD-1K1 ULL"
      using card_1_th_11 sorry
    have "OnORDINAL1K2 W c=TARSKIR1 W"
      using ordinal2_th_7 sorry
    then have "LL c=TARSKIR1 W"
      using A14 sorry
    then have "LL inTARSKIR2 W"
      using A1 A38 sorry
    then have "FuncsFUNCT-2K1(LL,W) c=TARSKIR1 W"
      using A1 A2 classes2_th_22 sorry
    then have "productCARD-3K4 ff c=TARSKIR1 W"
      using A15 sorry
    then have A51: "ProductCARD-3K7 ff c=ORDINAL1R1 cardCARD-1K1 W"
      using A39 card_1_th_11 sorry
    have "OnORDINAL1K2 W =XBOOLE-0R4 cardCARD-1K1 W"
      using A1 classes2_th_9 sorry
    thus " False "
      using A33 A51 A50 card_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_30:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & W be epsilon-transitiveORDINAL1V1 implies W c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W)"
proof-
  have " for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & W be epsilon-transitiveORDINAL1V1 implies W c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W)"
  proof(rule ballI,rule impMI ,rule impI)
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
      and A2: "W be epsilon-transitiveORDINAL1V1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 W implies x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 W)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      assume "x inHIDDENR3 W"
      then have "the-rank-ofCLASSES1K7 xx inTARSKIR2 W"
        using A1 A2 classes2_th_29 sorry
      then have A3: "the-rank-ofCLASSES1K7 xx inTARSKIR2 OnORDINAL1K2 W"
        using ordinal1_def_9 sorry
      have "OnORDINAL1K2 W =XBOOLE-0R4 cardCARD-1K1 W"
        using A1 classes2_th_9 sorry
      then have A4: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 xx) inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
        using A3 classes1_th_36 sorry
      have "xx c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 xx)"
        using classes1_def_9 sorry
      thus "x inHIDDENR3 RankCLASSES1K4 (cardCARD-1K1 W)"
        using A4 classes1_th_41 sorry
    qed "sorry"
    thus "W c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_31:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & W be epsilon-transitiveORDINAL1V1 implies RankCLASSES1K4 (cardCARD-1K1 W) =XBOOLE-0R4 W"
  using classes2_th_27 classes2_th_30 sorry

mtheorem classes2_th_32:
" for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A c=ORDINAL1R1 cardCARD-1K1 W"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & A inTARSKIR2 OnORDINAL1K2 W implies cardCARD-1K1 RankCLASSES1K4 A c=ORDINAL1R1 cardCARD-1K1 W"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
      and A2: "A inTARSKIR2 OnORDINAL1K2 W"
    have "cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 W"
      using A1 A2 classes2_th_25 sorry
    thus "cardCARD-1K1 RankCLASSES1K4 A c=ORDINAL1R1 cardCARD-1K1 W"
      using card_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_33:
" for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds A inTARSKIR2 OnORDINAL1K2 Tarski-ClassCLASSES1K1 W implies cardCARD-1K1 RankCLASSES1K4 A c=ORDINAL1R1 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for W be setHIDDENM2 holds A inTARSKIR2 OnORDINAL1K2 Tarski-ClassCLASSES1K1 W implies cardCARD-1K1 RankCLASSES1K4 A c=ORDINAL1R1 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix W assume [ty]: "W be setHIDDENM2"
    assume "A inTARSKIR2 OnORDINAL1K2 Tarski-ClassCLASSES1K1 W"
    then have "cardCARD-1K1 RankCLASSES1K4 A inTARSKIR2 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
      using classes2_th_25 sorry
    thus "cardCARD-1K1 RankCLASSES1K4 A c=ORDINAL1R1 cardCARD-1K1 Tarski-ClassCLASSES1K1 W"
      using card_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_34:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies cardCARD-1K1 W =XBOOLE-0R4 cardCARD-1K1 RankCLASSES1K4 (cardCARD-1K1 W)"
proof-
  have " for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies cardCARD-1K1 W =XBOOLE-0R4 cardCARD-1K1 RankCLASSES1K4 (cardCARD-1K1 W)"
  proof(rule ballI,rule impI)
    fix W assume [ty]: "W be setHIDDENM2"
    assume "W be TarskiCLASSES1V2"
    then have A1: "cardCARD-1K1 RankCLASSES1K4 (cardCARD-1K1 W) c=ORDINAL1R1 cardCARD-1K1 W"
      using classes2_th_27 card_1_th_11 sorry
    have "cardCARD-1K1 (cardCARD-1K1 W) c=ORDINAL1R1 cardCARD-1K1 RankCLASSES1K4 (cardCARD-1K1 W)"
      using card_1_th_11 classes1_th_38 sorry
    thus "cardCARD-1K1 W =XBOOLE-0R4 cardCARD-1K1 RankCLASSES1K4 (cardCARD-1K1 W)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_35:
" for W be setHIDDENM2 holds cardCARD-1K1 Tarski-ClassCLASSES1K1 W =XBOOLE-0R4 cardCARD-1K1 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W)"
  using classes2_th_34 sorry

mtheorem classes2_th_36:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & X c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W) implies (X,RankCLASSES1K4 (cardCARD-1K1 W))are-equipotentTARSKIR3 or X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 & (X c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W) &  not (X,RankCLASSES1K4 (cardCARD-1K1 W))are-equipotentTARSKIR3) implies X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
      and A2: "X c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W)"
      and A3: " not (X,RankCLASSES1K4 (cardCARD-1K1 W))are-equipotentTARSKIR3"
    let ?P = "\<lambda>Lamb1.  ex Y be setHIDDENM2 st Y inTARSKIR2 X & Lamb1 =HIDDENR1 the-rank-ofCLASSES1K7 Y"
    obtain LL where
      [ty]:"LL be setHIDDENM2" and 
      A4: " for x be objectHIDDENM1 holds x inHIDDENR3 LL iff x inHIDDENR3 OnORDINAL1K2 W & ?P(x)"
      using xboole_0_sch_1 sorry
    obtain ff where
      [ty]:"ff be Cardinal-FunctionCARD-3M1" and 
      A5: "domRELAT-1K1 ff =XBOOLE-0R4 LL & ( for x be setHIDDENM2 holds x inTARSKIR2 LL implies ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 x))"
      using card_3_sch_1 sorry
    have A6: "LL c=TARSKIR1 OnORDINAL1K2 W"
      using A4 sorry
    have A7: "productCARD-3K4 ff c=TARSKIR1 FuncsFUNCT-2K1(LL,W)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 productCARD-3K4 ff implies x inHIDDENR3 FuncsFUNCT-2K1(LL,W)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 productCARD-3K4 ff"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A8: "x =HIDDENR1 g"and A9: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 ff"and A10: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ff implies g .FUNCT-1K1 x inTARSKIR2 ff .FUNCT-1K1 x"
          using card_3_def_5 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 W"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 W"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 g"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A11: "x inHIDDENR3 domRELAT-1K1 g"and A12: "y =HIDDENR1 g .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have 
              [ty]:"x be setHIDDENM2"
              using tarski_th_1 sorry
            have A13: "ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 x)"
              using A5 A9 A11 sorry
            have "x inTARSKIR2 W"
              using A6 A5 A9 A11 ordinal1_def_9 sorry
            then have "boolSETFAM-1K9 x inTARSKIR2 W"
              using A1 sorry
            then have "cardCARD-1K1 (boolSETFAM-1K9 x) inTARSKIR2 W"
              using A1 classes2_th_11 sorry
            then have A14: "cardCARD-1K1 (boolSETFAM-1K9 x) c=TARSKIR1 W"
              using A1 classes2_th_5 sorry
            have "y inHIDDENR3 ff .FUNCT-1K1 x"
              using A9 A10 A11 A12 sorry
            thus "y inHIDDENR3 W"
              using A13 A14 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 g c=TARSKIR1 W"
            using tarski_def_3 sorry
        qed
        thus "x inHIDDENR3 FuncsFUNCT-2K1(LL,W)"
          using A5 A8 A9 funct_2_def_2 sorry
      qed "sorry"
      thus "productCARD-3K4 ff c=TARSKIR1 FuncsFUNCT-2K1(LL,W)"
        using tarski_def_3 sorry
    qed
    have A15: "cardCARD-1K1 W =XBOOLE-0R4 cardCARD-1K1 RankCLASSES1K4 (cardCARD-1K1 W)"
      using A1 classes2_th_34 sorry
    then have A16: "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 W"
      using A3 card_1_th_5 sorry
    have "OnORDINAL1K2 W c=TARSKIR1 W"
      using ordinal2_th_7 sorry
    then have A17: "LL c=TARSKIR1 W"
      using A6 sorry
    have " for Z be setHIDDENM2 holds Z inTARSKIR2 unionTARSKIK3 LL implies Z be OrdinalORDINAL1M3 & Z c=TARSKIR1 unionTARSKIK3 LL"
    proof(rule ballI,rule impI,rule conjMI)
      fix Z assume [ty]: "Z be setHIDDENM2"
      assume "Z inTARSKIR2 unionTARSKIK3 LL"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A18: "Z inTARSKIR2 Y"and A19: "Y inTARSKIR2 LL"
        using tarski_def_4 sorry
      have "Y inTARSKIR2 OnORDINAL1K2 W"
        using A4 A19 sorry
      then have 
        [ty]:"Y be OrdinalORDINAL1M3"
        using ordinal1_def_9 sorry
      have A20: "Y c=TARSKIR1 unionTARSKIK3 LL"
        using A19 zfmisc_1_th_74 sorry
      have A21: "Z inTARSKIR2 Y"
        using A18 sorry
      thus "Z be OrdinalORDINAL1M3"
         sorry
      obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = Z"
        using A21 sorry
      have "A c=ORDINAL1R1 Y"
        using A18 ordinal1_def_2 sorry
      thus "Z c=TARSKIR1 unionTARSKIK3 LL"
        using A20 sorry
    qed "sorry"
    then obtain ULL where 
      [ty]:"ULL be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2" and ULLDef:"ULL = unionTARSKIK3 LL"
      using ordinal1_th_19 sorry
    have A22: "domRELAT-1K1 (CardCARD-3K1 (idRELAT-1K7 LL)) =XBOOLE-0R4 domRELAT-1K1 (idRELAT-1K7 LL)"
      using card_3_def_2 sorry
    have A23: "domRELAT-1K1 (idRELAT-1K7 LL) =XBOOLE-0R4 LL"
      using relat_1_th_45 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 (idRELAT-1K7 LL)) implies CardCARD-3K1 (idRELAT-1K7 LL) .FUNCT-1K1 x inTARSKIR2 ff .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A24: "x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 (idRELAT-1K7 LL))"
      then have A25: "CardCARD-3K1 (idRELAT-1K7 LL) .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (idRELAT-1K7 LL .FUNCT-1K1 x)"
        using A22 card_3_def_2 sorry
      have A26: "idRELAT-1K7 LL .FUNCT-1K1 x =HIDDENR1 x"
        using A23 A22 A24 funct_1_th_18 sorry
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      have "ff .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (boolSETFAM-1K9 xx)"
        using A5 A23 A22 A24 sorry
      thus "CardCARD-3K1 (idRELAT-1K7 LL) .FUNCT-1K1 x inTARSKIR2 ff .FUNCT-1K1 x"
        using A26 A25 card_1_th_14 sorry
    qed "sorry"
    then have A27: "SumCARD-3K6 (CardCARD-3K1 (idRELAT-1K7 LL)) inTARSKIR2 ProductCARD-3K7 ff"
      using A5 A23 A22 card_3_th_41 sorry
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A28: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 the-rank-ofCLASSES1K6 x)"
      using funct_1_sch_3 sorry
    have "LL c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 LL implies x inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 LL"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A29: "Y inTARSKIR2 X"and A30: "x =HIDDENR1 the-rank-ofCLASSES1K7 Y"
          using A4 sorry
        have "f .FUNCT-1K1 Y =HIDDENR1 x"
          using A28 A29 A30 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 f"
          using A28 A29 funct_1_def_3 sorry
      qed "sorry"
      thus "LL c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    then have A31: "cardCARD-1K1 LL c=ORDINAL1R1 cardCARD-1K1 X"
      using A28 card_1_th_12 sorry
    have A32: "cardCARD-1K1 (productCARD-3K4 ff) =XBOOLE-0R4 ProductCARD-3K7 ff"
      using card_3_def_8 sorry
    have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 W"
      using A2 A15 card_1_th_11 sorry
    then have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      using A16 card_1_th_3 sorry
    then have "cardCARD-1K1 LL <>HIDDENR2 cardCARD-1K1 W"
      using A31 ordinal1_th_12 sorry
    then have " not (LL,W)are-equipotentTARSKIR3"
      using card_1_th_5 sorry
    then have "LL inTARSKIR2 W"
      using A1 A17 sorry
    then have "FuncsFUNCT-2K1(LL,W) c=TARSKIR1 W"
      using A1 A17 classes2_th_22 sorry
    then have "productCARD-3K4 ff c=TARSKIR1 W"
      using A7 sorry
    then have A33: "ProductCARD-3K7 ff c=ORDINAL1R1 cardCARD-1K1 W"
      using A32 card_1_th_11 sorry
    have A34: "cardCARD-1K1 W be limit-ordinalORDINAL1V4"
      using A1 classes2_th_19 sorry
    have A35: "cardCARD-1K1 W =XBOOLE-0R4 OnORDINAL1K2 W"
      using A1 classes2_th_9 sorry
    have "X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 ULL)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 ULL)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 cardCARD-1K1 W & xx c=TARSKIR1 RankCLASSES1K4 Lamb1"
        assume A36: "x inHIDDENR3 X"
        then have A37: "f .FUNCT-1K1 x =XBOOLE-0R4 the-rank-ofCLASSES1K7 xx"
          using A28 sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A38: "A inTARSKIR2 cardCARD-1K1 W"and A39: "x inHIDDENR3 RankCLASSES1K4 A"
          using A2 A34 A36 classes1_th_29 classes1_th_31 sorry
        have "?P(A)"
          using A38 A39 ordinal1_def_2 sorry
        then have A40: " ex A be OrdinalORDINAL1M3 st ?P(A)"
           sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A41: "?P(A)"and A42: " for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B"
          using ordinal1_sch_1 A40 sorry
        have " for B be OrdinalORDINAL1M3 holds xx c=TARSKIR1 RankCLASSES1K4 B implies A c=ORDINAL1R1 B"
        proof(rule ballI,rule impI)
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          assume "xx c=TARSKIR1 RankCLASSES1K4 B"
          then have "A c=ORDINAL1R1 cardCARD-1K1 W & cardCARD-1K1 W c=ORDINAL1R1 B or A c=ORDINAL1R1 B"
            using A41 A42 ordinal1_th_16 sorry
          thus "A c=ORDINAL1R1 B"
             sorry
        qed "sorry"
        then have "A =XBOOLE-0R4 the-rank-ofCLASSES1K7 xx"
          using A41 classes1_def_9 sorry
        then have "f .FUNCT-1K1 x inTARSKIR2 LL"
          using A4 A35 A36 A37 A41 sorry
        then have "the-rank-ofCLASSES1K7 xx c=ORDINAL1R1 ULL"
          using A37 zfmisc_1_th_74 sorry
        then have A43: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 xx) c=TARSKIR1 RankCLASSES1K4 ULL"
          using classes1_th_37 sorry
        have "xx c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 xx)"
          using classes1_def_9 sorry
        then have "xx c=TARSKIR1 RankCLASSES1K4 ULL"
          using A43 sorry
        thus "x inHIDDENR3 RankCLASSES1K4 (succORDINAL1K1 ULL)"
          using classes1_th_32 sorry
      qed "sorry"
      thus "X c=TARSKIR1 RankCLASSES1K4 (succORDINAL1K1 ULL)"
        using tarski_def_3 sorry
    qed
    then have A44: "X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 (succORDINAL1K1 ULL))"
      using classes1_th_32 sorry
    have "UnionCARD-3K3 idRELAT-1K7 LL =HIDDENR1 unionTARSKIK3 (rngFUNCT-1K2 (idRELAT-1K7 LL))"
      using card_3_def_4 sorry
    also have "... = ULL"
      using relat_1_th_45 sorry
    finally have "UnionCARD-3K3 idRELAT-1K7 LL =HIDDENR1 ULL"
       sorry
    then have "cardCARD-1K1 ULL inTARSKIR2 cardCARD-1K1 W"
      using A27 A33 card_3_th_39 ordinal1_th_12 sorry
    then have A45: "ULL <>HIDDENR2 OnORDINAL1K2 W"
      using A35 sorry
    have "unionTARSKIK3 (cardCARD-1K1 W) =XBOOLE-0R4 cardCARD-1K1 W"
      using A34 sorry
    then have "ULL c=TARSKIR1 OnORDINAL1K2 W"
      using A6 A35 zfmisc_1_th_77 sorry
    then have "ULL c<XBOOLE-0R2 OnORDINAL1K2 W"
      using A45 sorry
    then have "ULL inTARSKIR2 cardCARD-1K1 W"
      using A35 ordinal1_th_11 sorry
    then have "succORDINAL1K1 ULL inTARSKIR2 cardCARD-1K1 W"
      using A34 ordinal1_th_28 sorry
    then have "succORDINAL1K1 (succORDINAL1K1 ULL) inTARSKIR2 cardCARD-1K1 W"
      using A34 ordinal1_th_28 sorry
    thus "X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
      using A34 A44 classes1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_37:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds X c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) implies (X,RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W))are-equipotentTARSKIR3 or X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W)"
  using classes2_th_36 sorry

mtheorem classes2_th_38:
" for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies RankCLASSES1K4 (cardCARD-1K1 W) be TarskiCLASSES1V2"
proof-
  have " for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies RankCLASSES1K4 (cardCARD-1K1 W) be TarskiCLASSES1V2"
  proof(rule ballI,rule impI)
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    let ?B = "RankCLASSES1K4 (cardCARD-1K1 W)"
    have "( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W) & Y c=TARSKIR1 X implies Y inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)) & (( for VarFor1 be setHIDDENM2 holds  not (VarFor1 inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W) &  not boolSETFAM-1K9 VarFor1 inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W))) & ( for VarFor1 be setHIDDENM2 holds  not ((VarFor1 c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W) &  not (VarFor1,RankCLASSES1K4 (cardCARD-1K1 W))are-equipotentTARSKIR3) &  not VarFor1 inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W))))"
    proof(rule conjMI)
      show " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W) & Y c=TARSKIR1 X implies Y inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
        using classes1_th_41 sorry
      have "W <>HIDDENR2 {}XBOOLE-0K1 implies ( for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W) implies boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W))"
      proof(rule impI)
        have A2: "cardCARD-1K1 W be limit-ordinalORDINAL1V4"
          using A1 classes2_th_19 sorry
        assume A3: "W <>HIDDENR2 {}XBOOLE-0K1"
        show " for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W) implies boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
        proof(rule ballI,rule impI)
          fix X assume [ty]: "X be setHIDDENM2"
          assume "X inTARSKIR2 ?B"
          then obtain A where
            [ty]:"A be OrdinalORDINAL1M3" and 
            A4: "A inTARSKIR2 cardCARD-1K1 W"and A5: "X inTARSKIR2 RankCLASSES1K4 A"
            using A3 A2 classes1_th_31 sorry
          have A6: "boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
            using A5 classes1_th_42 sorry
          have "succORDINAL1K1 A inTARSKIR2 cardCARD-1K1 W"
            using A2 A4 ordinal1_th_28 sorry
          thus "boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
            using A2 A6 classes1_th_31 sorry
        qed "sorry"
      qed
      thus "( for VarFor1 be setHIDDENM2 holds  not (VarFor1 inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W) &  not boolSETFAM-1K9 VarFor1 inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W))) & ( for VarFor1 be setHIDDENM2 holds  not ((VarFor1 c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 W) &  not (VarFor1,RankCLASSES1K4 (cardCARD-1K1 W))are-equipotentTARSKIR3) &  not VarFor1 inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)))"
        using A1 classes2_th_36 classes1_th_29 sorry
    qed
    thus "RankCLASSES1K4 (cardCARD-1K1 W) be TarskiCLASSES1V2"
      using classes1_def_1 classes1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_39:
" for W be setHIDDENM2 holds RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) be TarskiCLASSES1V2"
  using classes2_th_38 sorry

mtheorem classes2_th_40:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 & A inTARSKIR2 the-rank-ofCLASSES1K7 X implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X & the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 A)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 & A inTARSKIR2 the-rank-ofCLASSES1K7 X implies ( not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 A))) implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X be epsilon-transitiveORDINAL1V1"
      and A2: "A inTARSKIR2 the-rank-ofCLASSES1K7 X"
    let ?P = "\<lambda>Lamb1.  ex Y be setHIDDENM2 st (A inTARSKIR2 Lamb1 & Y inTARSKIR2 X) & the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 Lamb1"
    assume A3: " not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 A)))"
    have A4: " ex B be OrdinalORDINAL1M3 st ?P(B)"
    proof-
      have "( for B be OrdinalORDINAL1M3 holds  for Y be setHIDDENM2 holds A inTARSKIR2 B & Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y <>HIDDENR2 B) implies  False "
      proof(rule impI)
        assume A5: " for B be OrdinalORDINAL1M3 holds  for Y be setHIDDENM2 holds A inTARSKIR2 B & Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y <>HIDDENR2 B"
        have "X c=TARSKIR1 RankCLASSES1K4 A"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 RankCLASSES1K4 A"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            obtain xx where 
              [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
              using tarski_th_1 sorry
            assume A6: "x inHIDDENR3 X"
            then have A7: "the-rank-ofCLASSES1K7 xx <>HIDDENR2 A"
              using A3 sorry
            have "the-rank-ofCLASSES1K7 xx c=ORDINAL1R1 A"
              using A5 A6 ordinal1_th_16 sorry
            then have "the-rank-ofCLASSES1K7 xx c<XBOOLE-0R2 A"
              using A7 sorry
            then have "the-rank-ofCLASSES1K7 xx inTARSKIR2 A"
              using ordinal1_th_11 sorry
            thus "x inHIDDENR3 RankCLASSES1K4 A"
              using classes1_th_66 sorry
          qed "sorry"
          thus "X c=TARSKIR1 RankCLASSES1K4 A"
            using tarski_def_3 sorry
        qed
        then have "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 A"
          using classes1_th_65 sorry
        thus " False "
          using A2 ordinal1_th_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A8: "?P(B)"and A9: " for C be OrdinalORDINAL1M3 holds ?P(C) implies B c=ORDINAL1R1 C"
      using ordinal1_sch_1 A4 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A10: "A inTARSKIR2 B"and A11: "Y inTARSKIR2 X"and A12: "the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 B"
      using A8 sorry
    have "Y c=TARSKIR1 RankCLASSES1K4 A"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 RankCLASSES1K4 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        have A13: "Y c=TARSKIR1 X"
          using A1 A11 sorry
        assume A14: "x inHIDDENR3 Y"
        then have "the-rank-ofCLASSES1K7 xx inTARSKIR2 B"
          using A12 classes1_th_68 sorry
        then have " not A inTARSKIR2 the-rank-ofCLASSES1K7 xx"
          using A9 A14 A13 ordinal1_th_5 sorry
        then have A15: "the-rank-ofCLASSES1K7 xx c=ORDINAL1R1 A"
          using ordinal1_th_16 sorry
        have "the-rank-ofCLASSES1K7 xx <>HIDDENR2 A"
          using A3 A14 A13 sorry
        then have "the-rank-ofCLASSES1K7 xx c<XBOOLE-0R2 A"
          using A15 sorry
        then have "the-rank-ofCLASSES1K7 xx inTARSKIR2 A"
          using ordinal1_th_11 sorry
        thus "x inHIDDENR3 RankCLASSES1K4 A"
          using classes1_th_66 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 RankCLASSES1K4 A"
        using tarski_def_3 sorry
    qed
    then have "the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 A"
      using classes1_th_65 sorry
    thus " False "
      using A10 A12 ordinal1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_41:
" for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies cardCARD-1K1 the-rank-ofCLASSES1K7 X c=ORDINAL1R1 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies cardCARD-1K1 the-rank-ofCLASSES1K7 X c=ORDINAL1R1 cardCARD-1K1 X"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 the-rank-ofCLASSES1K6 x)"
      using funct_1_sch_3 sorry
    assume A2: "X be epsilon-transitiveORDINAL1V1"
    have "the-rank-ofCLASSES1K7 X c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 the-rank-ofCLASSES1K7 X implies x inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 the-rank-ofCLASSES1K7 X"
        then obtain x9 where 
          [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
           sorry
        obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A4: "Y inTARSKIR2 X"and A5: "the-rank-ofCLASSES1K7 Y =XBOOLE-0R4 x9"
          using A2 A3 classes2_th_40 sorry
        have "f .FUNCT-1K1 Y =HIDDENR1 x"
          using A1 A4 A5 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 f"
          using A1 A4 funct_1_def_3 sorry
      qed "sorry"
      thus "the-rank-ofCLASSES1K7 X c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "cardCARD-1K1 the-rank-ofCLASSES1K7 X c=ORDINAL1R1 cardCARD-1K1 X"
      using A1 card_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_42:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds (W be TarskiCLASSES1V2 & X be epsilon-transitiveORDINAL1V1) & X inTARSKIR2 W implies X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
proof-
  have " for X be setHIDDENM2 holds  for W be setHIDDENM2 holds W be TarskiCLASSES1V2 implies (X be epsilon-transitiveORDINAL1V1 implies (X inTARSKIR2 W implies X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix W assume [ty]: "W be setHIDDENM2"
    assume A1: "W be TarskiCLASSES1V2"
    assume A2: "X be epsilon-transitiveORDINAL1V1"
    assume "X inTARSKIR2 W"
    then have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 W"
      using A1 classes2_th_1 sorry
    then have A3: "cardCARD-1K1 the-rank-ofCLASSES1K7 X inTARSKIR2 cardCARD-1K1 W"
      using A2 classes2_th_41 ordinal1_th_12 sorry
    have "cardCARD-1K1 (cardCARD-1K1 W) =XBOOLE-0R4 cardCARD-1K1 W"
       sorry
    then have "the-rank-ofCLASSES1K7 X inTARSKIR2 cardCARD-1K1 W"
      using A3 card_3_th_43 sorry
    then have A4: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
      using classes1_th_36 sorry
    have "X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
      using classes1_def_9 sorry
    thus "X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 W)"
      using A4 classes1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_43:
" for X be setHIDDENM2 holds  for W be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 & X inTARSKIR2 Tarski-ClassCLASSES1K1 W implies X inTARSKIR2 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W)"
  using classes2_th_42 sorry

mtheorem classes2_th_44:
" for W be setHIDDENM2 holds W be epsilon-transitiveORDINAL1V1 implies RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) is-Tarski-Class-ofCLASSES1R1 W"
  using classes1_th_2 classes2_th_38 classes2_th_42 sorry

mtheorem classes2_th_45:
" for W be setHIDDENM2 holds W be epsilon-transitiveORDINAL1V1 implies RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 W"
proof-
  have " for W be setHIDDENM2 holds W be epsilon-transitiveORDINAL1V1 implies RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 W"
  proof(rule ballI,rule impI)
    fix W assume [ty]: "W be setHIDDENM2"
    assume "W be epsilon-transitiveORDINAL1V1"
    then have Cut1114: "RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) is-Tarski-Class-ofCLASSES1R1 W"
      using classes2_th_44 sorry
    have "RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W & Tarski-ClassCLASSES1K1 W c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W)"
    proof-
      show "RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) c=TARSKIR1 Tarski-ClassCLASSES1K1 W & Tarski-ClassCLASSES1K1 W c=TARSKIR1 RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W)"
        using classes2_th_28 classes1_def_4 Cut1114 sorry
    qed
    thus "RankCLASSES1K4 (cardCARD-1K1 Tarski-ClassCLASSES1K1 W) =XBOOLE-0R4 Tarski-ClassCLASSES1K1 W"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef classes2_def_1 ("universalCLASSES2V1" 70 ) where
"attr universalCLASSES2V1 for setHIDDENM2 means
  (\<lambda>IT. IT be epsilon-transitiveORDINAL1V1 & IT be TarskiCLASSES1V2)"..

mtheorem classes2_cl_3:
"cluster universalCLASSES2V1 also-is epsilon-transitiveORDINAL1V1\<bar>TarskiCLASSES1V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be universalCLASSES2V1 implies it be epsilon-transitiveORDINAL1V1\<bar>TarskiCLASSES1V2"
     sorry
qed "sorry"

mtheorem classes2_cl_4:
"cluster epsilon-transitiveORDINAL1V1\<bar>TarskiCLASSES1V2 also-is universalCLASSES2V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be epsilon-transitiveORDINAL1V1\<bar>TarskiCLASSES1V2 implies it be universalCLASSES2V1"
     sorry
qed "sorry"

mtheorem classes2_cl_5:
"cluster universalCLASSES2V1\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be universalCLASSES2V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex V be setHIDDENM2 st V be universalCLASSES2V1 &  not V be emptyXBOOLE-0V1"
    proof-
      let ?X = "the setHIDDENM2"
      obtain V where 
        [ty]:"V be setHIDDENM2" and VDef:"V = Tarski-ClassCLASSES1K1 (the-transitive-closure-ofCLASSES1K5 ?X)"
         sorry
      show " ex V be setHIDDENM2 st V be universalCLASSES2V1 &  not V be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "V"])
        have "V be epsilon-transitiveORDINAL1V1 & (V be TarskiCLASSES1V2 &  not V be emptyXBOOLE-0V1)"
        proof(rule conjMI)
          show "V be epsilon-transitiveORDINAL1V1"
            using classes1_th_23 sorry
          show "V be TarskiCLASSES1V2 &  not V be emptyXBOOLE-0V1"
             sorry
        qed
        thus "V be universalCLASSES2V1 &  not V be emptyXBOOLE-0V1"
          using classes2_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CLASSES2M1 :: "Ty" ("UniverseCLASSES2M1" 70)
translations "UniverseCLASSES2M1" \<rightharpoonup> "universalCLASSES2V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"

reserve U1, U2, U for "UniverseCLASSES2M1"
mtheorem classes2_th_46:
" for U be UniverseCLASSES2M1 holds OnORDINAL1K2 U be OrdinalORDINAL1M3"
proof-
  have " for U be UniverseCLASSES2M1 holds OnORDINAL1K2 U be OrdinalORDINAL1M3"
  proof(rule ballI)
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    have "OnORDINAL1K2 U =XBOOLE-0R4 cardCARD-1K1 U"
      using classes2_th_9 sorry
    thus "OnORDINAL1K2 U be OrdinalORDINAL1M3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_47:
" for X be setHIDDENM2 holds X be epsilon-transitiveORDINAL1V1 implies Tarski-ClassCLASSES1K1 X be universalCLASSES2V1"
  using classes1_th_23 sorry

mtheorem classes2_th_48:
" for U be UniverseCLASSES2M1 holds Tarski-ClassCLASSES1K1 U be UniverseCLASSES2M1"
  using classes2_th_47 sorry

mtheorem classes2_cl_6:
  mlet "U be UniverseCLASSES2M1"
"cluster OnORDINAL1K2 U as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "OnORDINAL1K2 U be ordinalORDINAL1V3"
    using classes2_th_46 sorry
qed "sorry"

mtheorem classes2_cl_7:
  mlet "U be UniverseCLASSES2M1"
"cluster Tarski-ClassCLASSES1K1 U as-term-is universalCLASSES2V1"
proof
(*coherence*)
  show "Tarski-ClassCLASSES1K1 U be universalCLASSES2V1"
    using classes2_th_47 sorry
qed "sorry"

mtheorem classes2_th_49:
" for A be OrdinalORDINAL1M3 holds Tarski-ClassCLASSES1K1 A be universalCLASSES2V1"
  using classes1_th_23 sorry

mtheorem classes2_cl_8:
  mlet "A be OrdinalORDINAL1M3"
"cluster Tarski-ClassCLASSES1K1 A as-term-is universalCLASSES2V1"
proof
(*coherence*)
  show "Tarski-ClassCLASSES1K1 A be universalCLASSES2V1"
    using classes2_th_49 sorry
qed "sorry"

mtheorem classes2_th_50:
" for U be UniverseCLASSES2M1 holds U =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U)"
proof-
  have " for U be UniverseCLASSES2M1 holds U =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U)"
  proof(rule ballI)
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    have "cardCARD-1K1 U =XBOOLE-0R4 OnORDINAL1K2 U"
      using classes2_th_9 sorry
    thus "U =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U)"
      using classes2_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_51:
" for U be UniverseCLASSES2M1 holds OnORDINAL1K2 U <>HIDDENR2 {}XBOOLE-0K1 & OnORDINAL1K2 U be limit-ordinalORDINAL1V4"
proof-
  have " for U be UniverseCLASSES2M1 holds  not OnORDINAL1K2 U <>HIDDENR2 {}XBOOLE-0K1 & OnORDINAL1K2 U be limit-ordinalORDINAL1V4"
  proof(rule ballI)
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    have "cardCARD-1K1 U =XBOOLE-0R4 OnORDINAL1K2 U"
      using classes2_th_9 sorry
    thus " not OnORDINAL1K2 U <>HIDDENR2 {}XBOOLE-0K1 & OnORDINAL1K2 U be limit-ordinalORDINAL1V4"
      using classes2_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_52:
" for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds (U1 inTARSKIR2 U2 or U1 =XBOOLE-0R4 U2) or U2 inTARSKIR2 U1"
proof-
  have " for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds  not (( not U1 inTARSKIR2 U2 &  not U1 =XBOOLE-0R4 U2) &  not U2 inTARSKIR2 U1)"
  proof(rule ballI,rule ballI)
    fix U1 assume [ty]: "U1 be UniverseCLASSES2M1"
    fix U2 assume [ty]: "U2 be UniverseCLASSES2M1"
    have A1: "(OnORDINAL1K2 U1 inTARSKIR2 OnORDINAL1K2 U2 or OnORDINAL1K2 U1 =XBOOLE-0R4 OnORDINAL1K2 U2) or OnORDINAL1K2 U2 inTARSKIR2 OnORDINAL1K2 U1"
      using ordinal1_th_14 sorry
    have A2: "U2 =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U2)"
      using classes2_th_50 sorry
    have "U1 =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U1)"
      using classes2_th_50 sorry
    thus " not (( not U1 inTARSKIR2 U2 &  not U1 =XBOOLE-0R4 U2) &  not U2 inTARSKIR2 U1)"
      using A1 A2 classes1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_53:
" for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds U1 c=TARSKIR1 U2 or U2 inTARSKIR2 U1"
proof-
  have " for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds  not ( not U1 c=TARSKIR1 U2 &  not U2 inTARSKIR2 U1)"
  proof(rule ballI,rule ballI)
    fix U1 assume [ty]: "U1 be UniverseCLASSES2M1"
    fix U2 assume [ty]: "U2 be UniverseCLASSES2M1"
    have A1: "OnORDINAL1K2 U1 c=ORDINAL1R1 OnORDINAL1K2 U2 or OnORDINAL1K2 U2 inTARSKIR2 OnORDINAL1K2 U1"
      using ordinal1_th_16 sorry
    have A2: "U2 =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U2)"
      using classes2_th_50 sorry
    have "U1 =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U1)"
      using classes2_th_50 sorry
    thus " not ( not U1 c=TARSKIR1 U2 &  not U2 inTARSKIR2 U1)"
      using A1 A2 classes1_th_36 classes1_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_54:
" for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds (U1,U2)are-c=-comparableXBOOLE-0R3"
proof-
  have " for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds (U1,U2)are-c=-comparableXBOOLE-0R3"
  proof(rule ballI,rule ballI)
    fix U1 assume [ty]: "U1 be UniverseCLASSES2M1"
    fix U2 assume [ty]: "U2 be UniverseCLASSES2M1"
    have A1: "OnORDINAL1K2 U1 c=ORDINAL1R1 OnORDINAL1K2 U2 or OnORDINAL1K2 U2 c=ORDINAL1R1 OnORDINAL1K2 U1"
       sorry
    have A2: "U2 =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U2)"
      using classes2_th_50 sorry
    have Cut1219: "U1 =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U1)"
      using classes2_th_50 sorry
    have "U1 c=TARSKIR1 U2 or U2 c=TARSKIR1 U1"
    proof-
      show "U1 c=TARSKIR1 U2 or U2 c=TARSKIR1 U1"
        using A1 A2 classes1_th_37 Cut1219 sorry
    qed
    thus "(U1,U2)are-c=-comparableXBOOLE-0R3"
      using xboole_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_55:
" for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds U1 \\/XBOOLE-0K2 U2 be UniverseCLASSES2M1 & U1 /\\XBOOLE-0K3 U2 be UniverseCLASSES2M1"
proof-
  have " for U1 be UniverseCLASSES2M1 holds  for U2 be UniverseCLASSES2M1 holds U1 \\/XBOOLE-0K2 U2 be UniverseCLASSES2M1 & U1 /\\XBOOLE-0K3 U2 be UniverseCLASSES2M1"
  proof(rule ballI,rule ballI)
    fix U1 assume [ty]: "U1 be UniverseCLASSES2M1"
    fix U2 assume [ty]: "U2 be UniverseCLASSES2M1"
    have "(U1,U2)are-c=-comparableXBOOLE-0R3"
      using classes2_th_54 sorry
    then have "U1 c=TARSKIR1 U2 or U2 c=TARSKIR1 U1"
       sorry
    thus "U1 \\/XBOOLE-0K2 U2 be UniverseCLASSES2M1 & U1 /\\XBOOLE-0K3 U2 be UniverseCLASSES2M1"
      using xboole_1_th_12 xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_56:
" for U be UniverseCLASSES2M1 holds {}XBOOLE-0K1 inTARSKIR2 U"
proof-
  have " for U be UniverseCLASSES2M1 holds {}XBOOLE-0K1 inTARSKIR2 U"
  proof(rule ballI)
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    have "{}XBOOLE-0K1 c=TARSKIR1 the ElementSUBSET-1M1-of U"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 U"
      using classes1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_57:
" for x be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds x inTARSKIR2 U implies {TARSKIK1 x} inTARSKIR2 U"
  using classes2_th_2 sorry

mtheorem classes2_th_58:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds x inTARSKIR2 U & y inTARSKIR2 U implies {TARSKIK2 x,y } inTARSKIR2 U & [TARSKIK4 x,y ] inHIDDENR3 U"
  using classes2_th_2 classes2_th_3 sorry

mtheorem classes2_th_59:
" for X be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds X inTARSKIR2 U implies (boolSETFAM-1K9 X inTARSKIR2 U & unionTARSKIK3 X inTARSKIR2 U) & meetSETFAM-1K1 X inTARSKIR2 U"
proof-
  have " for X be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds X inTARSKIR2 U implies boolSETFAM-1K9 X inTARSKIR2 U & (unionTARSKIK3 X inTARSKIR2 U & meetSETFAM-1K1 X inTARSKIR2 U)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    assume A1: "X inTARSKIR2 U"
    thus "boolSETFAM-1K9 X inTARSKIR2 U"
      using classes1_def_2 sorry
    have "U =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 U)"
      using classes2_th_50 sorry
    thus A2: "unionTARSKIK3 X inTARSKIR2 U"
      using A1 classes1_th_35 sorry
    have "meetSETFAM-1K1 X c=TARSKIR1 unionTARSKIK3 X"
      using setfam_1_th_2 sorry
    thus "meetSETFAM-1K1 X inTARSKIR2 U"
      using A2 classes1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_60:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds X inTARSKIR2 U & Y inTARSKIR2 U implies ((X \\/XBOOLE-0K2 Y inTARSKIR2 U & X /\\XBOOLE-0K3 Y inTARSKIR2 U) & X \\SUBSET-1K6 Y inTARSKIR2 U) & X \\+\\XBOOLE-0K5 Y inTARSKIR2 U"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds X inTARSKIR2 U & Y inTARSKIR2 U implies (X \\/XBOOLE-0K2 Y inTARSKIR2 U & X /\\XBOOLE-0K3 Y inTARSKIR2 U) & (X \\SUBSET-1K6 Y inTARSKIR2 U & X \\+\\XBOOLE-0K5 Y inTARSKIR2 U)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    assume A1: "X inTARSKIR2 U"
      and A2: "Y inTARSKIR2 U"
    have A3: "unionTARSKIK3 {TARSKIK2 X,Y } =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
      using zfmisc_1_th_75 sorry
    have A4: "meetSETFAM-1K1 {TARSKIK2 X,Y } =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
      using setfam_1_th_11 sorry
    have "{TARSKIK2 X,Y } inTARSKIR2 U"
      using A1 A2 classes2_th_2 sorry
    thus A5: "X \\/XBOOLE-0K2 Y inTARSKIR2 U & X /\\XBOOLE-0K3 Y inTARSKIR2 U"
      using A3 A4 classes2_th_59 sorry
    have "X \\+\\XBOOLE-0K5 Y =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)\\SUBSET-1K6 X /\\XBOOLE-0K3 Y"
      using xboole_1_th_101 sorry
    thus "X \\SUBSET-1K6 Y inTARSKIR2 U & X \\+\\XBOOLE-0K5 Y inTARSKIR2 U"
      using A1 A5 classes1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_61:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds X inTARSKIR2 U & Y inTARSKIR2 U implies [:ZFMISC-1K2 X,Y :] inTARSKIR2 U & FuncsFUNCT-2K1(X,Y) inTARSKIR2 U"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for U be UniverseCLASSES2M1 holds X inTARSKIR2 U & Y inTARSKIR2 U implies [:ZFMISC-1K2 X,Y :] inTARSKIR2 U & FuncsFUNCT-2K1(X,Y) inTARSKIR2 U"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    assume A1: "X inTARSKIR2 U"
      and A2: "Y inTARSKIR2 U"
    have "X \\/XBOOLE-0K2 Y inTARSKIR2 U"
      using A1 A2 classes2_th_60 sorry
    then have "boolSETFAM-1K9 (X \\/XBOOLE-0K2 Y) inTARSKIR2 U"
      using classes2_th_59 sorry
    then have A3: "boolSETFAM-1K9 (boolSETFAM-1K9 (X \\/XBOOLE-0K2 Y)) inTARSKIR2 U"
      using classes2_th_59 sorry
    have "[:ZFMISC-1K2 X,Y :] c=TARSKIR1 boolSETFAM-1K9 (boolSETFAM-1K9 (X \\/XBOOLE-0K2 Y))"
      using zfmisc_1_th_86 sorry
    thus "[:ZFMISC-1K2 X,Y :] inTARSKIR2 U"
      using A3 classes1_def_1 sorry
    then have A4: "boolSETFAM-1K9 ([:ZFMISC-1K2 X,Y :]) inTARSKIR2 U"
      using classes2_th_59 sorry
    have "FuncsFUNCT-2K1(X,Y) c=TARSKIR1 boolSETFAM-1K9 ([:ZFMISC-1K2 X,Y :])"
      using fraenkel_th_2 sorry
    thus "FuncsFUNCT-2K1(X,Y) inTARSKIR2 U"
      using A4 classes1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve u, v for "ElementSUBSET-1M1-of U"
mtheorem classes2_cl_9:
  mlet "U1 be UniverseCLASSES2M1"
"cluster  non emptyXBOOLE-0V1 for ElementSUBSET-1M1-of U1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of U1 st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar2 be ElementSUBSET-1M1-of U1 st  not tVar2 be emptyXBOOLE-0V1"
    proof-
      have "{}XBOOLE-0K1 inTARSKIR2 U1"
        using classes2_th_56 sorry
      then obtain x where 
        [ty]:"x be ElementSUBSET-1M1-of U1" and xDef:"x = boolSETFAM-1K9 ({}XBOOLE-0K1)"
        using classes2_th_59 sorry
      show " ex tVar2 be ElementSUBSET-1M1-of U1 st  not tVar2 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "x"])
        show " not x be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CLASSES2K1 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("{CLASSES2K1\<^bsub>'( _ ')\<^esub>  _ }" [0,0]356)
translations "{CLASSES2K1\<^bsub>(U)\<^esub> u}" \<rightharpoonup> "{TARSKIK1 u}"

mtheorem classes2_add_1:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U"
"cluster {TARSKIK1 u} as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "{TARSKIK1 u} be ElementSUBSET-1M1-of U"
    using classes2_th_2 sorry
qed "sorry"

syntax CLASSES2K2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("boolCLASSES2K2\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "boolCLASSES2K2\<^bsub>(U)\<^esub> u" \<rightharpoonup> "boolZFMISC-1K1 u"

mtheorem classes2_add_2:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U"
"cluster boolZFMISC-1K1 u as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "boolZFMISC-1K1 u be ElementSUBSET-1M1-of U"
    using classes2_th_59 sorry
qed "sorry"

syntax CLASSES2K3 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("unionCLASSES2K3\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "unionCLASSES2K3\<^bsub>(U)\<^esub> u" \<rightharpoonup> "unionTARSKIK3 u"

mtheorem classes2_add_3:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U"
"cluster unionTARSKIK3 u as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "unionTARSKIK3 u be ElementSUBSET-1M1-of U"
    using classes2_th_59 sorry
qed "sorry"

syntax CLASSES2K4 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("meetCLASSES2K4\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "meetCLASSES2K4\<^bsub>(U)\<^esub> u" \<rightharpoonup> "meetSETFAM-1K1 u"

mtheorem classes2_add_4:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U"
"cluster meetSETFAM-1K1 u as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "meetSETFAM-1K1 u be ElementSUBSET-1M1-of U"
    using classes2_th_59 sorry
qed "sorry"

syntax CLASSES2K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{CLASSES2K5\<^bsub>'( _ ')\<^esub> _ , _ }" [0,0,0]356)
translations "{CLASSES2K5\<^bsub>(U)\<^esub> u,v }" \<rightharpoonup> "{TARSKIK2 u,v }"

mtheorem classes2_add_5:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster {TARSKIK2 u,v } as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "{TARSKIK2 u,v } be ElementSUBSET-1M1-of U"
    using classes2_th_2 sorry
qed "sorry"

syntax CLASSES2K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[CLASSES2K6\<^bsub>'( _ ')\<^esub> _ , _ ]" [0,0,0]356)
translations "[CLASSES2K6\<^bsub>(U)\<^esub> u,v ]" \<rightharpoonup> "[TARSKIK4 u,v ]"

mtheorem classes2_add_6:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster [TARSKIK4 u,v ] as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "[TARSKIK4 u,v ] be ElementSUBSET-1M1-of U"
    using classes2_th_3 sorry
qed "sorry"

syntax CLASSES2K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\'/CLASSES2K7\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "u \\/CLASSES2K7\<^bsub>(U)\<^esub> v" \<rightharpoonup> "u \\/XBOOLE-0K2 v"

mtheorem classes2_add_7:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster u \\/XBOOLE-0K2 v as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "u \\/XBOOLE-0K2 v be ElementSUBSET-1M1-of U"
    using classes2_th_60 sorry
qed "sorry"

syntax CLASSES2K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\CLASSES2K8\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "u /\\CLASSES2K8\<^bsub>(U)\<^esub> v" \<rightharpoonup> "u /\\XBOOLE-0K3 v"

mtheorem classes2_add_8:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster u /\\XBOOLE-0K3 v as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "u /\\XBOOLE-0K3 v be ElementSUBSET-1M1-of U"
    using classes2_th_60 sorry
qed "sorry"

syntax CLASSES2K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\CLASSES2K9\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "u \\CLASSES2K9\<^bsub>(U)\<^esub> v" \<rightharpoonup> "u \\XBOOLE-0K4 v"

mtheorem classes2_add_9:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster u \\XBOOLE-0K4 v as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "u \\XBOOLE-0K4 v be ElementSUBSET-1M1-of U"
    using classes2_th_60 sorry
qed "sorry"

syntax CLASSES2K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\+'\\CLASSES2K10\<^bsub>'( _ ')\<^esub>  _ " [130,0,130]130)
translations "u \\+\\CLASSES2K10\<^bsub>(U)\<^esub> v" \<rightharpoonup> "u \\+\\XBOOLE-0K5 v"

mtheorem classes2_add_10:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster u \\+\\XBOOLE-0K5 v as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "u \\+\\XBOOLE-0K5 v be ElementSUBSET-1M1-of U"
    using classes2_th_60 sorry
qed "sorry"

syntax CLASSES2K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[:CLASSES2K11\<^bsub>'( _ ')\<^esub> _ , _ :]" [0,0,0]164)
translations "[:CLASSES2K11\<^bsub>(U)\<^esub> u,v :]" \<rightharpoonup> "[:ZFMISC-1K2 u,v :]"

mtheorem classes2_add_11:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster [:ZFMISC-1K2 u,v :] as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "[:ZFMISC-1K2 u,v :] be ElementSUBSET-1M1-of U"
    using classes2_th_61 sorry
qed "sorry"

syntax CLASSES2K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("FuncsCLASSES2K12\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]228)
translations "FuncsCLASSES2K12\<^bsub>(U)\<^esub>(u,v)" \<rightharpoonup> "FuncsFUNCT-2K1(u,v)"

mtheorem classes2_add_12:
  mlet "U be UniverseCLASSES2M1", "u be ElementSUBSET-1M1-of U", "v be ElementSUBSET-1M1-of U"
"cluster FuncsFUNCT-2K1(u,v) as-term-is ElementSUBSET-1M1-of U"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(u,v) be ElementSUBSET-1M1-of U"
    using classes2_th_61 sorry
qed "sorry"

mdef classes2_def_2 ("FinSETSCLASSES2K13" 300 ) where
"func FinSETSCLASSES2K13 \<rightarrow> UniverseCLASSES2M1 equals
  Tarski-ClassCLASSES1K1 ({}XBOOLE-0K1)"
proof-
  (*coherence*)
    show "Tarski-ClassCLASSES1K1 ({}XBOOLE-0K1) be UniverseCLASSES2M1"
       sorry
qed "sorry"

mlemma classes2_lm_5:
"omegaORDINAL1K4 be limit-ordinalORDINAL1V4"
  using ordinal1_def_11 sorry

mtheorem classes2_th_62:
"cardCARD-1K1 RankCLASSES1K4 (omegaORDINAL1K4) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)"
proof-
  let ?h = "\<lambda>Lamb1. RankCLASSES1K4 Lamb1"
  obtain L where
    [ty]:"L be SequenceORDINAL1M4" and 
    A1: "domRELAT-1K1 L =XBOOLE-0R4 omegaORDINAL1K4 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 omegaORDINAL1K4 implies L .FUNCT-1K1 A =XBOOLE-0R4 ?h(A))"
    using ordinal2_sch_2 sorry
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 rngFUNCT-1K2 L implies (Y inTARSKIR2 rngFUNCT-1K2 L implies (X,Y)are-c=-comparableXBOOLE-0R3)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X inTARSKIR2 rngFUNCT-1K2 L"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 domRELAT-1K1 L"and A3: "X =XBOOLE-0R4 L .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    assume "Y inTARSKIR2 rngFUNCT-1K2 L"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A4: "y inHIDDENR3 domRELAT-1K1 L"and A5: "Y =XBOOLE-0R4 L .FUNCT-1K1 y"
      using funct_1_def_3 sorry
    have 
      [ty]:"x be OrdinalORDINAL1M3" and
      [ty]:"y be OrdinalORDINAL1M3"
      using A2 A4 sorry
    have A6: "Y =XBOOLE-0R4 RankCLASSES1K4 y"
      using A1 A4 A5 sorry
    have A7: "x c=ORDINAL1R1 y or y c=ORDINAL1R1 x"
       sorry
    have "X =XBOOLE-0R4 RankCLASSES1K4 x"
      using A1 A2 A3 sorry
    then have "X c=TARSKIR1 Y or Y c=TARSKIR1 X"
      using A6 A7 classes1_th_37 sorry
    thus "(X,Y)are-c=-comparableXBOOLE-0R3"
       sorry
  qed "sorry"
  then have A8: "rngFUNCT-1K2 L be c=-linearORDINAL1V6"
     sorry
  have A9: "cardCARD-1K1 (omegaORDINAL1K4) c=ORDINAL1R1 cardCARD-1K1 RankCLASSES1K4 (omegaORDINAL1K4)"
    using card_1_th_11 classes1_th_38 sorry
  have A10: " for X be setHIDDENM2 holds X inTARSKIR2 rngFUNCT-1K2 L implies cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (omegaORDINAL1K4)"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X inTARSKIR2 rngFUNCT-1K2 L"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A11: "x inHIDDENR3 domRELAT-1K1 L"and A12: "X =XBOOLE-0R4 L .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    have 
      [ty]:"x be OrdinalORDINAL1M3"
      using A11 sorry
    have "X =XBOOLE-0R4 RankCLASSES1K4 x"
      using A1 A11 A12 sorry
    thus "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (omegaORDINAL1K4)"
      using A1 A11 card_2_th_67 card_3_th_42 sorry
  qed "sorry"
  have "RankCLASSES1K4 (omegaORDINAL1K4) =HIDDENR1 UnionCARD-3K3 L"
    using A1 classes2_lm_5 classes2_th_24 sorry
  also have "... = unionTARSKIK3 (rngFUNCT-1K2 L)"
    using card_3_def_4 sorry
  finally have "RankCLASSES1K4 (omegaORDINAL1K4) =HIDDENR1 unionTARSKIK3 (rngFUNCT-1K2 L)"
     sorry
  then have "cardCARD-1K1 RankCLASSES1K4 (omegaORDINAL1K4) c=ORDINAL1R1 cardCARD-1K1 (omegaORDINAL1K4)"
    using A8 A10 card_3_th_46 sorry
  thus "cardCARD-1K1 RankCLASSES1K4 (omegaORDINAL1K4) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)"
    using A9 sorry
qed

mtheorem classes2_th_63:
"RankCLASSES1K4 (omegaORDINAL1K4) be TarskiCLASSES1V2"
proof-
  have "( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4) & Y c=TARSKIR1 X implies Y inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)) & (( for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4) implies boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)) & ( for X be setHIDDENM2 holds X c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4) implies (X,RankCLASSES1K4 (omegaORDINAL1K4))are-equipotentTARSKIR3 or X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)))"
  proof(rule conjMI,rule conjMI)
    show " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4) & Y c=TARSKIR1 X implies Y inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)"
      using classes1_th_41 sorry
    show " for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4) implies boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)"
    proof-
      have " for X be setHIDDENM2 holds X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4) implies boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        assume "X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)"
        then obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A1: "A inTARSKIR2 omegaORDINAL1K4"and A2: "X inTARSKIR2 RankCLASSES1K4 A"
          using classes2_lm_5 classes1_th_31 sorry
        have A3: "boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (succORDINAL1K1 A)"
          using A2 classes1_th_42 sorry
        have "succORDINAL1K1 A inTARSKIR2 omegaORDINAL1K4"
          using A1 classes2_lm_5 ordinal1_th_28 sorry
        thus "boolSETFAM-1K9 X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)"
          using A3 classes2_lm_5 classes1_th_31 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " for X be setHIDDENM2 holds X c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4) implies (X,RankCLASSES1K4 (omegaORDINAL1K4))are-equipotentTARSKIR3 or X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)"
    proof-
      have " for X be setHIDDENM2 holds X c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4) & ( not (X,RankCLASSES1K4 (omegaORDINAL1K4))are-equipotentTARSKIR3 &  not X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)) implies  not  True "
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        have A4: "0NUMBERSK6 inTARSKIR2 omegaORDINAL1K4"
           sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. the-rank-ofCLASSES1K6 Lamb2 c=ORDINAL1R1 the-rank-ofCLASSES1K6 Lamb1"
        assume A5: "X c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4)"
          and A6: " not (X,RankCLASSES1K4 (omegaORDINAL1K4))are-equipotentTARSKIR3"
          and A7: " not X inTARSKIR2 RankCLASSES1K4 (omegaORDINAL1K4)"
        have A8: "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 (omegaORDINAL1K4)"
          using A6 classes2_th_62 card_1_th_5 sorry
        have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 (omegaORDINAL1K4)"
          using A5 classes2_th_62 card_1_th_11 sorry
        then have "cardCARD-1K1 X inTARSKIR2 omegaORDINAL1K4"
          using A8 card_1_th_3 sorry
        then have 
          [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2"
           sorry
        have A9: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?P(x,y) or ?P(y,x)"
           sorry
        have A10: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(y,z) implies ?P(x,z)"
          using xboole_1_th_1 sorry
        have "omegaORDINAL1K4 c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4)"
          using classes1_th_38 sorry
        then have A11: "X <>HIDDENR2 {}XBOOLE-0K1"
          using A7 A4 sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A12: "x inHIDDENR3 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies ?P(x,y))"
          using card_2_sch_2 A11 A9 A10 sorry
        let ?A = "the-rank-ofCLASSES1K6 x"
        have " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies the-rank-ofCLASSES1K7 Y inTARSKIR2 succORDINAL1K1 ?A"
          using A12 ordinal1_th_22 sorry
        then have A13: "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 succORDINAL1K1 ?A"
          using classes1_th_69 sorry
        have "?A inTARSKIR2 omegaORDINAL1K4"
          using A5 A12 classes1_th_66 sorry
        then have "succORDINAL1K1 ?A inTARSKIR2 omegaORDINAL1K4"
          using classes2_lm_5 ordinal1_th_28 sorry
        then have "the-rank-ofCLASSES1K7 X inTARSKIR2 omegaORDINAL1K4"
          using A13 ordinal1_th_12 sorry
        thus " not  True "
          using A7 classes1_th_66 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  qed
  thus "RankCLASSES1K4 (omegaORDINAL1K4) be TarskiCLASSES1V2"
    using classes1_def_1 classes1_def_2 sorry
qed

mtheorem classes2_th_64:
"FinSETSCLASSES2K13 =XBOOLE-0R4 RankCLASSES1K4 (omegaORDINAL1K4)"
proof-
  have A1: "omegaORDINAL1K4 c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4)"
    using classes1_th_38 sorry
  then obtain M where 
    [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = RankCLASSES1K4 (omegaORDINAL1K4)"
     sorry
  have "0NUMBERSK6 inTARSKIR2 omegaORDINAL1K4"
     sorry
  then have Cut1435: "M is-Tarski-Class-ofCLASSES1R1 {}XBOOLE-0K1"
    using A1 classes2_th_63 sorry
  have "FinSETSCLASSES2K13 c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4) & RankCLASSES1K4 (omegaORDINAL1K4) c=TARSKIR1 FinSETSCLASSES2K13"
  proof(rule conjMI)
    show "FinSETSCLASSES2K13 c=TARSKIR1 RankCLASSES1K4 (omegaORDINAL1K4)"
      using classes1_def_4 Cut1435 sorry
    have A2: "{}XBOOLE-0K1 inTARSKIR2 OnORDINAL1K2 FinSETSCLASSES2K13"
      using classes2_th_51 ordinal3_th_8 sorry
    have A3: "FinSETSCLASSES2K13 =XBOOLE-0R4 RankCLASSES1K4 (OnORDINAL1K2 FinSETSCLASSES2K13)"
      using classes2_th_50 sorry
    have "OnORDINAL1K2 FinSETSCLASSES2K13 be limit-ordinalORDINAL1V4"
      using classes2_th_51 sorry
    then have "omegaORDINAL1K4 c=ORDINAL1R1 OnORDINAL1K2 FinSETSCLASSES2K13"
      using A2 ordinal1_def_11 sorry
    thus "RankCLASSES1K4 (omegaORDINAL1K4) c=TARSKIR1 FinSETSCLASSES2K13"
      using A3 classes1_th_37 sorry
  qed
  thus "FinSETSCLASSES2K13 =XBOOLE-0R4 RankCLASSES1K4 (omegaORDINAL1K4)"
    using xboole_0_def_10 sorry
qed

mdef classes2_def_3 ("SETSCLASSES2K14" 300 ) where
"func SETSCLASSES2K14 \<rightarrow> UniverseCLASSES2M1 equals
  Tarski-ClassCLASSES1K1 (FinSETSCLASSES2K13)"
proof-
  (*coherence*)
    show "Tarski-ClassCLASSES1K1 (FinSETSCLASSES2K13) be UniverseCLASSES2M1"
       sorry
qed "sorry"

mtheorem classes2_cl_10:
  mlet "X be setHIDDENM2"
"cluster the-transitive-closure-ofCLASSES1K5 X as-term-is epsilon-transitiveORDINAL1V1"
proof
(*coherence*)
  show "the-transitive-closure-ofCLASSES1K5 X be epsilon-transitiveORDINAL1V1"
     sorry
qed "sorry"

mtheorem classes2_cl_11:
  mlet "X be epsilon-transitiveORDINAL1V1\<bar>setHIDDENM2"
"cluster Tarski-ClassCLASSES1K1 X as-term-is epsilon-transitiveORDINAL1V1"
proof
(*coherence*)
  show "Tarski-ClassCLASSES1K1 X be epsilon-transitiveORDINAL1V1"
    using classes1_th_23 sorry
qed "sorry"

mdef classes2_def_4 ("Universe-closureCLASSES2K15  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func Universe-closureCLASSES2K15 X \<rightarrow> UniverseCLASSES2M1 means
  \<lambda>it. X c=TARSKIR1 it & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies it c=TARSKIR1 Y)"
proof-
  (*uniqueness*)
    show " for it1 be UniverseCLASSES2M1 holds  for it2 be UniverseCLASSES2M1 holds (X c=TARSKIR1 it1 & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies it1 c=TARSKIR1 Y)) & (X c=TARSKIR1 it2 & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies it2 c=TARSKIR1 Y)) implies it1 =HIDDENR1 it2"
       sorry
  (*existence*)
    show " ex it be UniverseCLASSES2M1 st X c=TARSKIR1 it & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies it c=TARSKIR1 Y)"
    proof-
      have " ex tVar3 be UniverseCLASSES2M1 st X c=TARSKIR1 tVar3 & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies tVar3 c=TARSKIR1 Y)"
      proof-
        show " ex tVar3 be UniverseCLASSES2M1 st X c=TARSKIR1 tVar3 & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies tVar3 c=TARSKIR1 Y)"
        proof-
          have cases: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) be UniverseCLASSES2M1 or  not RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) be UniverseCLASSES2M1"
             sorry
          have case1: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) be UniverseCLASSES2M1 implies ( ex tVar3 be UniverseCLASSES2M1 st X c=TARSKIR1 tVar3 & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies tVar3 c=TARSKIR1 Y))"
          proof(rule impI)
            assume "RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) be UniverseCLASSES2M1"
            then obtain R where 
              [ty]:"R be UniverseCLASSES2M1" and RDef:"R = RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
               sorry
            show " ex tVar3 be UniverseCLASSES2M1 st X c=TARSKIR1 tVar3 & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies tVar3 c=TARSKIR1 Y)"
            proof(rule bexI[of _ "R"],rule conjMI,rule ballI,rule impI)
              show "X c=TARSKIR1 R"
                using classes1_def_9 sorry
              fix Y assume [ty]: "Y be UniverseCLASSES2M1"
              assume "X c=TARSKIR1 Y"
              then have "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
                using classes1_th_67 sorry
              then have A1: "R c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 Y)"
                using classes1_th_37 sorry
              have A2: "RankCLASSES1K4 (cardCARD-1K1 Y) =XBOOLE-0R4 Y"
                using classes2_th_31 sorry
              then have "the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 cardCARD-1K1 Y"
                using classes1_def_9 sorry
              then have "RankCLASSES1K4 (the-rank-ofCLASSES1K7 Y) c=TARSKIR1 Y"
                using A2 classes1_th_37 sorry
              thus "R c=TARSKIR1 Y"
                using A1 sorry
            qed "sorry"
          qed
          have case2: " not RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) be UniverseCLASSES2M1 implies ( ex R be setHIDDENM2 st X c=TARSKIR1 R & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies R c=TARSKIR1 Y))"
          proof(rule impI)
            assume A3: " not RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) be UniverseCLASSES2M1"
            obtain R where 
              [ty]:"R be setHIDDENM2" and RDef:"R = Tarski-ClassCLASSES1K1 (RankCLASSES1K4 (the-rank-ofCLASSES1K7 X))"
               sorry
            show " ex R be setHIDDENM2 st X c=TARSKIR1 R & ( for Y be UniverseCLASSES2M1 holds X c=TARSKIR1 Y implies R c=TARSKIR1 Y)"
            proof(rule bexI[of _ "R"],rule conjMI,rule ballI,rule impI)
              have A4: "RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) inTARSKIR2 R"
                using classes1_th_2 sorry
              have "X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
                using classes1_def_9 sorry
              then have "X inTARSKIR2 R"
                using A4 classes1_def_1 sorry
              thus "X c=TARSKIR1 R"
                using ordinal1_def_2 sorry
              fix Y assume [ty]: "Y be UniverseCLASSES2M1"
              assume "X c=TARSKIR1 Y"
              then have A5: "the-rank-ofCLASSES1K7 X c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
                using classes1_th_67 sorry
              have A6: "RankCLASSES1K4 (cardCARD-1K1 Y) =XBOOLE-0R4 Y"
                using classes2_th_31 sorry
              then have A7: "the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 cardCARD-1K1 Y"
                using classes1_def_9 sorry
              have "Y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 Y)"
                using classes1_def_9 sorry
              then have "cardCARD-1K1 Y c=ORDINAL1R1 the-rank-ofCLASSES1K7 Y"
                using A6 classes1_th_37 sorry
              then have "cardCARD-1K1 Y =XBOOLE-0R4 the-rank-ofCLASSES1K7 Y"
                using A7 sorry
              then have "the-rank-ofCLASSES1K7 X c<XBOOLE-0R2 cardCARD-1K1 Y"
                using A3 A5 A6 sorry
              then have "the-rank-ofCLASSES1K7 X inTARSKIR2 cardCARD-1K1 Y"
                using ordinal1_th_11 sorry
              then have "RankCLASSES1K4 (the-rank-ofCLASSES1K7 X) inTARSKIR2 Y"
                using A6 classes1_th_36 sorry
              then have "Y is-Tarski-Class-ofCLASSES1R1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 X)"
                 sorry
              thus "R c=TARSKIR1 Y"
                using classes1_def_4 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

syntax CLASSES2M2 :: "Ty" ("FinSetCLASSES2M2" 70)
translations "FinSetCLASSES2M2" \<rightharpoonup> "ElementSUBSET-1M1-of FinSETSCLASSES2K13"

syntax CLASSES2M3 :: "Ty" ("SetCLASSES2M3" 70)
translations "SetCLASSES2M3" \<rightharpoonup> "ElementSUBSET-1M1-of SETSCLASSES2K14"

mdef classes2_def_5 ("UNIVERSECLASSES2K16  _ " [164]164 ) where
  mlet "A be OrdinalORDINAL1M3"
"func UNIVERSECLASSES2K16 A \<rightarrow> setHIDDENM2 means
  \<lambda>it.  ex L be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  ex L be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        have "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((it1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((it2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) implies it1 =HIDDENR1 it2"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        have "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C))))) &  not ( for L be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma classes2_lm_6:
"UNIVERSECLASSES2K16 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13 & (( for A be OrdinalORDINAL1M3 holds UNIVERSECLASSES2K16 succORDINAL1K1 A =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (UNIVERSECLASSES2K16 A)) & ( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds (A <>HIDDENR2 0NUMBERSK6 & A be limit-ordinalORDINAL1V4) & (domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 UNIVERSECLASSES2K16 B)) implies UNIVERSECLASSES2K16 A =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L)))"
proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
  have A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 UNIVERSECLASSES2K16 A iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L  |RELAT-1K8 C)))"
    using classes2_def_5 sorry
  show "UNIVERSECLASSES2K16 (0NUMBERSK6) =XBOOLE-0R4 FinSETSCLASSES2K13"
    using ordinal2_sch_8 A1 sorry
  show " for A be OrdinalORDINAL1M3 holds UNIVERSECLASSES2K16 succORDINAL1K1 A =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (UNIVERSECLASSES2K16 A)"
    using ordinal2_sch_9 A1 sorry
  fix A assume [ty]: "A be OrdinalORDINAL1M3"
  fix L assume [ty]: "L be SequenceORDINAL1M4"
  assume A2: "A <>HIDDENR2 0NUMBERSK6 & A be limit-ordinalORDINAL1V4"
    and A3: "domRELAT-1K1 L =XBOOLE-0R4 A"
    and A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 UNIVERSECLASSES2K16 B"
  show "UNIVERSECLASSES2K16 A =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L)"
    using ordinal2_sch_10 A1 A2 A3 A4 sorry
qed "sorry"

mtheorem classes2_cl_12:
  mlet "A be OrdinalORDINAL1M3"
"cluster UNIVERSECLASSES2K16 A as-term-is universalCLASSES2V1\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "UNIVERSECLASSES2K16 A be universalCLASSES2V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have "UNIVERSECLASSES2K16 A be universalCLASSES2V1 &  not UNIVERSECLASSES2K16 A be emptyXBOOLE-0V1"
    proof-
      let ?P = "\<lambda>Lamb1. UNIVERSECLASSES2K16 Lamb1 be UniverseCLASSES2M1"
      have A1: " for B be OrdinalORDINAL1M3 holds ?P(B) implies ?P(succORDINAL1K1 B)"
      proof-
        have " for B be OrdinalORDINAL1M3 holds UNIVERSECLASSES2K16 B be UniverseCLASSES2M1 implies UNIVERSECLASSES2K16 succORDINAL1K1 B be UniverseCLASSES2M1"
        proof(rule ballI,rule impI)
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          assume "?P(B)"
          then obtain UU where 
            [ty]:"UU be UniverseCLASSES2M1" and UUDef:"UU = UNIVERSECLASSES2K16 B"
             sorry
          have "UNIVERSECLASSES2K16 succORDINAL1K1 B =XBOOLE-0R4 Tarski-ClassCLASSES1K1 UU"
            using classes2_lm_6 sorry
          thus "UNIVERSECLASSES2K16 succORDINAL1K1 B be UniverseCLASSES2M1"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A2: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0NUMBERSK6 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
      proof-
        have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0NUMBERSK6 & (A be limit-ordinalORDINAL1V4 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies UNIVERSECLASSES2K16 B be UniverseCLASSES2M1)) implies UNIVERSECLASSES2K16 A be UniverseCLASSES2M1"
        proof(rule ballI,rule impMI ,rule impMI ,rule impI)
          fix A assume [ty]: "A be OrdinalORDINAL1M3"
          assume A3: "A <>HIDDENR2 0NUMBERSK6"
            and A4: "A be limit-ordinalORDINAL1V4"
            and " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)"
          obtain L where
            [ty]:"L be SequenceORDINAL1M4" and 
            A5: "domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 UNIVERSECLASSES2K16 B)"
            using ordinal2_sch_2 sorry
          have "UNIVERSECLASSES2K16 A =HIDDENR1 Universe-closureCLASSES2K15 (UnionCARD-3K3 L)"
            using A3 A4 A5 classes2_lm_6 sorry
          also have "... = Universe-closureCLASSES2K15 unionTARSKIK3 (rngFUNCT-1K2 L)"
            using card_3_def_4 sorry
          finally have "UNIVERSECLASSES2K16 A =HIDDENR1 Universe-closureCLASSES2K15 unionTARSKIK3 (rngFUNCT-1K2 L)"
             sorry
          thus "UNIVERSECLASSES2K16 A be UniverseCLASSES2M1"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A6: "?P(0NUMBERSK6)"
        using classes2_lm_6 sorry
      have " for A be OrdinalORDINAL1M3 holds ?P(A)"
        using ordinal2_sch_1 A6 A1 A2 sorry
      thus "UNIVERSECLASSES2K16 A be universalCLASSES2V1 &  not UNIVERSECLASSES2K16 A be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem classes2_th_65:
"UNIVERSECLASSES2K16 {}XBOOLE-0K1 =XBOOLE-0R4 FinSETSCLASSES2K13"
  using classes2_lm_6 sorry

mtheorem classes2_th_66:
" for A be OrdinalORDINAL1M3 holds UNIVERSECLASSES2K16 succORDINAL1K1 A =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (UNIVERSECLASSES2K16 A)"
  using classes2_lm_6 sorry

mlemma classes2_lm_7:
"\<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 (0NUMBERSK6)"
   sorry

mtheorem classes2_th_67:
"UNIVERSECLASSES2K16 \<one>\<^sub>M =XBOOLE-0R4 SETSCLASSES2K14"
  using classes2_lm_6 classes2_lm_7 sorry

mtheorem classes2_th_68:
" for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds ((A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4) & domRELAT-1K1 L =XBOOLE-0R4 A) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 UNIVERSECLASSES2K16 B) implies UNIVERSECLASSES2K16 A =XBOOLE-0R4 Universe-closureCLASSES2K15 (UnionCARD-3K3 L)"
  using classes2_lm_6 sorry

mtheorem classes2_th_69:
" for U be UniverseCLASSES2M1 holds (FinSETSCLASSES2K13 c=TARSKIR1 U & Tarski-ClassCLASSES1K1 ({}XBOOLE-0K1) c=TARSKIR1 U) & UNIVERSECLASSES2K16 {}XBOOLE-0K1 c=TARSKIR1 U"
proof-
  have " for U be UniverseCLASSES2M1 holds (FinSETSCLASSES2K13 c=TARSKIR1 U & Tarski-ClassCLASSES1K1 ({}XBOOLE-0K1) c=TARSKIR1 U) & UNIVERSECLASSES2K16 {}XBOOLE-0K1 c=TARSKIR1 U"
  proof(rule ballI)
    fix U assume [ty]: "U be UniverseCLASSES2M1"
    have A1: "OnORDINAL1K2 U c=TARSKIR1 RankCLASSES1K4 (OnORDINAL1K2 U)"
      using classes1_th_38 sorry
    have A2: "RankCLASSES1K4 (OnORDINAL1K2 U) =XBOOLE-0R4 U"
      using classes2_th_50 sorry
    have "{}XBOOLE-0K1 inTARSKIR2 OnORDINAL1K2 U"
      using classes2_th_51 ordinal3_th_8 sorry
    thus "(FinSETSCLASSES2K13 c=TARSKIR1 U & Tarski-ClassCLASSES1K1 ({}XBOOLE-0K1) c=TARSKIR1 U) & UNIVERSECLASSES2K16 {}XBOOLE-0K1 c=TARSKIR1 U"
      using A2 A1 classes2_lm_6 classes2_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_70:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B iff UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A inTARSKIR2 B implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B) & (UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B &  not A inTARSKIR2 B implies  False )"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1.  for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Lamb1 implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 Lamb1"
    have A1: " for B be OrdinalORDINAL1M3 holds ?P(B) implies ?P(succORDINAL1K1 B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B) implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 succORDINAL1K1 B implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 succORDINAL1K1 B)"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A2: "?P(B)"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A3: "A inTARSKIR2 succORDINAL1K1 B"
        have "A c<XBOOLE-0R2 B iff A c=ORDINAL1R1 B & A <>HIDDENR2 B"
           sorry
        then have "A inTARSKIR2 B or A =XBOOLE-0R4 B"
          using A3 ordinal1_th_11 ordinal1_th_22 sorry
        then have A4: "UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B or UNIVERSECLASSES2K16 A =XBOOLE-0R4 UNIVERSECLASSES2K16 B"
          using A2 sorry
        have "UNIVERSECLASSES2K16 succORDINAL1K1 B =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (UNIVERSECLASSES2K16 B)"
          using classes2_lm_6 sorry
        then have "UNIVERSECLASSES2K16 B inTARSKIR2 UNIVERSECLASSES2K16 succORDINAL1K1 B"
          using classes1_th_2 sorry
        thus "UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 succORDINAL1K1 B"
          using A4 ordinal1_th_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0NUMBERSK6 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0NUMBERSK6 & (B be limit-ordinalORDINAL1V4 & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 C implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 C))) implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A6: "B <>HIDDENR2 0NUMBERSK6"
          and A7: "B be limit-ordinalORDINAL1V4"
          and " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 C implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 C)"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        obtain L where
          [ty]:"L be SequenceORDINAL1M4" and 
          A8: "domRELAT-1K1 L =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies L .FUNCT-1K1 C =XBOOLE-0R4 UNIVERSECLASSES2K16 C)"
          using ordinal2_sch_2 sorry
        assume "A inTARSKIR2 B"
        then have A9: "succORDINAL1K1 A inTARSKIR2 B"
          using A7 ordinal1_th_28 sorry
        then have "L .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 UNIVERSECLASSES2K16 succORDINAL1K1 A"
          using A8 sorry
        then have "UNIVERSECLASSES2K16 succORDINAL1K1 A inTARSKIR2 rngFUNCT-1K2 L"
          using A9 A8 funct_1_def_3 sorry
        then have A10: "UNIVERSECLASSES2K16 succORDINAL1K1 A c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 L)"
          using zfmisc_1_th_74 sorry
        have "UNIVERSECLASSES2K16 B =HIDDENR1 Universe-closureCLASSES2K15 (UnionCARD-3K3 L)"
          using A6 A7 A8 classes2_lm_6 sorry
        also have "... = Universe-closureCLASSES2K15 unionTARSKIK3 (rngFUNCT-1K2 L)"
          using card_3_def_4 sorry
        finally have "UNIVERSECLASSES2K16 B =HIDDENR1 Universe-closureCLASSES2K15 unionTARSKIK3 (rngFUNCT-1K2 L)"
           sorry
        then have "unionTARSKIK3 (rngFUNCT-1K2 L) c=TARSKIR1 UNIVERSECLASSES2K16 B"
          using classes2_def_4 sorry
        then have A11: "UNIVERSECLASSES2K16 succORDINAL1K1 A c=TARSKIR1 UNIVERSECLASSES2K16 B"
          using A10 sorry
        have A12: "UNIVERSECLASSES2K16 A inTARSKIR2 Tarski-ClassCLASSES1K1 (UNIVERSECLASSES2K16 A)"
          using classes1_th_2 sorry
        have "UNIVERSECLASSES2K16 succORDINAL1K1 A =XBOOLE-0R4 Tarski-ClassCLASSES1K1 (UNIVERSECLASSES2K16 A)"
          using classes2_lm_6 sorry
        thus "UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B"
          using A12 A11 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A13: "?P(0NUMBERSK6)"
       sorry
    have A14: " for B be OrdinalORDINAL1M3 holds ?P(B)"
      using ordinal2_sch_1 A13 A1 A5 sorry
    thus "A inTARSKIR2 B implies UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B"
       sorry
    assume A15: "UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B"
      and A16: " not A inTARSKIR2 B"
    have "B inTARSKIR2 A or B =XBOOLE-0R4 A"
      using A16 ordinal1_th_16 sorry
    thus " False "
      using A14 A15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_71:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds UNIVERSECLASSES2K16 A =XBOOLE-0R4 UNIVERSECLASSES2K16 B implies A =XBOOLE-0R4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds UNIVERSECLASSES2K16 A =XBOOLE-0R4 UNIVERSECLASSES2K16 B & A <>HIDDENR2 B implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "UNIVERSECLASSES2K16 A =XBOOLE-0R4 UNIVERSECLASSES2K16 B"
      and A2: "A <>HIDDENR2 B"
    have "A inTARSKIR2 B or B inTARSKIR2 A"
      using A2 ordinal1_th_14 sorry
    then have "UNIVERSECLASSES2K16 A inTARSKIR2 UNIVERSECLASSES2K16 B or UNIVERSECLASSES2K16 B inTARSKIR2 UNIVERSECLASSES2K16 A"
      using classes2_th_70 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem classes2_th_72:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B iff UNIVERSECLASSES2K16 A c=TARSKIR1 UNIVERSECLASSES2K16 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A c=ORDINAL1R1 B implies UNIVERSECLASSES2K16 A c=TARSKIR1 UNIVERSECLASSES2K16 B) & (UNIVERSECLASSES2K16 A c=TARSKIR1 UNIVERSECLASSES2K16 B implies ( not A c=ORDINAL1R1 B implies  False ))"
  proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    show "A c=ORDINAL1R1 B implies UNIVERSECLASSES2K16 A c=TARSKIR1 UNIVERSECLASSES2K16 B"
    proof-
      have "A c=ORDINAL1R1 B implies ( not UNIVERSECLASSES2K16 A c=TARSKIR1 UNIVERSECLASSES2K16 B implies  False )"
      proof(rule impI,rule impI)
        assume A1: "A c=ORDINAL1R1 B"
        assume " not UNIVERSECLASSES2K16 A c=TARSKIR1 UNIVERSECLASSES2K16 B"
        then have "UNIVERSECLASSES2K16 B inTARSKIR2 UNIVERSECLASSES2K16 A"
          using classes2_th_53 sorry
        then have "B inTARSKIR2 A"
          using classes2_th_70 sorry
        thus " False "
          using A1 ordinal1_th_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "UNIVERSECLASSES2K16 A c=TARSKIR1 UNIVERSECLASSES2K16 B"
    assume " not A c=ORDINAL1R1 B"
    then have "B inTARSKIR2 A"
      using ordinal1_th_16 sorry
    then have "UNIVERSECLASSES2K16 B inTARSKIR2 UNIVERSECLASSES2K16 A"
      using classes2_th_70 sorry
    thus " False "
      using A2 ordinal1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve u, v for "ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X"
mtheorem classes2_th_73:
" for X be setHIDDENM2 holds Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) inTARSKIR2 Tarski-ClassCLASSES1K3(X,\<one>\<^sub>M) & Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) <>HIDDENR2 Tarski-ClassCLASSES1K3(X,\<one>\<^sub>M)"
proof-
  have " for X be setHIDDENM2 holds Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) inTARSKIR2 Tarski-ClassCLASSES1K3(X,\<one>\<^sub>M) & (Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,\<one>\<^sub>M) implies  False )"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?F = "\<lambda>Lamb1. Tarski-ClassCLASSES1K3(X,Lamb1)"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. (({u where u be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X :  ex v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X st v inTARSKIR2 Lamb2 & u c=TARSKIR1 v })\\/XBOOLE-0K2 ({boolSETFAM-1K9 v where v be ElementSUBSET-1M1-of Tarski-ClassCLASSES1K1 X : v inTARSKIR2 Lamb2 }))\\/XBOOLE-0K2 boolSETFAM-1K9 Lamb2 /\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 Lamb2)\<^esub> Tarski-ClassCLASSES1K1 X"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 (rngFUNCT-1K2 Lamb2) /\\XBOOLE-0K3 Tarski-ClassCLASSES1K1 X"
    have A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 ?F(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 {TARSKIK1 X}) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0NUMBERSK6) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,L  |RELAT-1K8 C)))"
      using classes1_def_5 sorry
    have A2: "?F(0NUMBERSK6) =XBOOLE-0R4 {TARSKIK1 X}"
      using ordinal2_sch_8 A1 sorry
    then have "X inTARSKIR2 Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1)"
      using tarski_def_1 sorry
    then have A3: "boolSETFAM-1K9 X inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      using classes1_th_4 sorry
    have "{TARSKIK1 X} c=TARSKIR1 boolSETFAM-1K9 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 X} implies x inHIDDENR3 boolSETFAM-1K9 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {TARSKIK1 X}"
        then have "x =HIDDENR1 X"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 boolSETFAM-1K9 X"
          using zfmisc_1_def_1 sorry
      qed "sorry"
      thus "{TARSKIK1 X} c=TARSKIR1 boolSETFAM-1K9 X"
        using tarski_def_3 sorry
    qed
    then have "\<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 (0NUMBERSK6) & {TARSKIK1 X} inTARSKIR2 Tarski-ClassCLASSES1K1 X"
      using A3 classes1_th_3 sorry
    thus A4: "Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) inTARSKIR2 Tarski-ClassCLASSES1K3(X,\<one>\<^sub>M)"
      using A2 classes1_th_10 sorry
    assume "Tarski-ClassCLASSES1K3(X,{}XBOOLE-0K1) =XBOOLE-0R4 Tarski-ClassCLASSES1K3(X,\<one>\<^sub>M)"
    thus " False "
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
