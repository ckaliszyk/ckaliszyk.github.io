theory arithm
  imports xcmplx_0
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "ComplexXCMPLX-0M1"
mtheorem arithm_th_1:
" for x be ComplexXCMPLX-0M1 holds x +XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 x"
proof-
  have " for x be ComplexXCMPLX-0M1 holds x +XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
       sorry
    then obtain Z where 
      [ty]:"Z be ElementSUBSET-1M1-of REALNUMBERSK2" and ZDef:"Z = 0NUMBERSK6"
      using numbers_th_19 sorry
    have "x inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain x1 x2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
      using arytm_0_th_9 sorry
    have "0NUMBERSK6 =HIDDENR1 [*ARYTM-0K5 Z,Z *]"
      using arytm_0_def_5 sorry
    then have "x +XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 [*ARYTM-0K5 +ARYTM-0K1(x1,Z),+ARYTM-0K1(x2,Z) *]"
      using A1 xcmplx_0_def_4 sorry
    also have "... = [*ARYTM-0K5 x1,+ARYTM-0K1(x2,Z) *]"
      using arytm_0_th_11 sorry
    also have "... = x"
      using A1 arytm_0_th_11 sorry
    finally have "x +XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 x"
       sorry
    thus "x +XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arithm_lm_1:
"-XCMPLX-0K4 0NUMBERSK6 =HIDDENR1 0NUMBERSK6"
proof-
  have "0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 0NUMBERSK6) =HIDDENR1 -XCMPLX-0K4 0NUMBERSK6"
    using arithm_th_1 sorry
  thus "-XCMPLX-0K4 0NUMBERSK6 =HIDDENR1 0NUMBERSK6"
    using xcmplx_0_def_6 sorry
qed

mtheorem arithm_th_2:
" for x be ComplexXCMPLX-0M1 holds x *XCMPLX-0K3 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be ComplexXCMPLX-0M1 holds x *XCMPLX-0K3 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
       sorry
    then obtain Z where 
      [ty]:"Z be ElementSUBSET-1M1-of REALNUMBERSK2" and ZDef:"Z = 0NUMBERSK6"
      using numbers_th_19 sorry
    have "x inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain x1 x2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
      using arytm_0_th_9 sorry
    have "+ARYTM-0K1(Z,Z) =HIDDENR1 0NUMBERSK6"
      using arytm_0_th_11 sorry
    then have Lm2: "oppARYTM-0K3 Z =HIDDENR1 0NUMBERSK6"
      using arytm_0_def_3 sorry
    have "0NUMBERSK6 =HIDDENR1 [*ARYTM-0K5 Z,Z *]"
      using arytm_0_def_5 sorry
    then have "x *XCMPLX-0K3 (0NUMBERSK6) =HIDDENR1 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,Z),oppARYTM-0K3 ( *ARYTM-0K2(x2,Z))),+ARYTM-0K1( *ARYTM-0K2(x1,Z), *ARYTM-0K2(x2,Z)) *]"
      using A1 xcmplx_0_def_5 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,Z),oppARYTM-0K3 Z),+ARYTM-0K1( *ARYTM-0K2(x1,Z), *ARYTM-0K2(x2,Z)) *]"
      using arytm_0_th_12 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,Z),oppARYTM-0K3 Z),+ARYTM-0K1( *ARYTM-0K2(x1,Z),Z) *]"
      using arytm_0_th_12 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1(Z,oppARYTM-0K3 Z),+ARYTM-0K1( *ARYTM-0K2(x1,Z),Z) *]"
      using arytm_0_th_12 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1(Z,oppARYTM-0K3 Z),+ARYTM-0K1(Z,Z) *]"
      using arytm_0_th_12 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1(Z,oppARYTM-0K3 Z),Z *]"
      using arytm_0_th_11 sorry
    also have "... = [*ARYTM-0K5 oppARYTM-0K3 Z,Z *]"
      using arytm_0_th_11 sorry
    also have "... = 0NUMBERSK6"
      using Lm2 arytm_0_def_5 sorry
    finally have "x *XCMPLX-0K3 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
    thus "x *XCMPLX-0K3 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arithm_th_3:
" for x be ComplexXCMPLX-0M1 holds \<one>\<^sub>M *XCMPLX-0K3 x =HIDDENR1 x"
proof-
  have " for x be ComplexXCMPLX-0M1 holds \<one>\<^sub>M *XCMPLX-0K3 x =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1 & \<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
       sorry
    then obtain Z J where 
      [ty]:"Z be ElementSUBSET-1M1-of REALNUMBERSK2" and ZDef:"Z = 0NUMBERSK6" and
      [ty]:"J be ElementSUBSET-1M1-of REALNUMBERSK2" and JDef:"J = \<one>\<^sub>M"
      using numbers_th_19 sorry
    have "+ARYTM-0K1(Z,Z) =HIDDENR1 0NUMBERSK6"
      using arytm_0_th_11 sorry
    then have Lm2: "oppARYTM-0K3 Z =HIDDENR1 0NUMBERSK6"
      using arytm_0_def_3 sorry
    have "x inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain x1 x2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
      using arytm_0_th_9 sorry
    have "\<one>\<^sub>M =HIDDENR1 [*ARYTM-0K5 J,Z *]"
      using arytm_0_def_5 sorry
    then have "x *XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,J),oppARYTM-0K3 ( *ARYTM-0K2(x2,Z))),+ARYTM-0K1( *ARYTM-0K2(x1,Z), *ARYTM-0K2(x2,J)) *]"
      using A1 xcmplx_0_def_5 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,J),oppARYTM-0K3 Z),+ARYTM-0K1( *ARYTM-0K2(x1,Z), *ARYTM-0K2(x2,J)) *]"
      using arytm_0_th_12 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1(x1,oppARYTM-0K3 Z),+ARYTM-0K1( *ARYTM-0K2(x1,Z), *ARYTM-0K2(x2,J)) *]"
      using arytm_0_th_19 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1(x1,oppARYTM-0K3 Z),+ARYTM-0K1( *ARYTM-0K2(x1,Z),x2) *]"
      using arytm_0_th_19 sorry
    also have "... = [*ARYTM-0K5 +ARYTM-0K1(x1,Z),+ARYTM-0K1(Z,x2) *]"
      using Lm2 arytm_0_th_12 sorry
    also have "... = [*ARYTM-0K5 x1,+ARYTM-0K1(Z,x2) *]"
      using arytm_0_th_11 sorry
    also have "... = x"
      using A1 arytm_0_th_11 sorry
    finally have "x *XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 x"
       sorry
    thus "\<one>\<^sub>M *XCMPLX-0K3 x =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arithm_th_4:
" for x be ComplexXCMPLX-0M1 holds x -XCMPLX-0K6 0NUMBERSK6 =HIDDENR1 x"
proof-
  have " for x be ComplexXCMPLX-0M1 holds x -XCMPLX-0K6 0NUMBERSK6 =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    have "x -XCMPLX-0K6 0NUMBERSK6 =HIDDENR1 x +XCMPLX-0K2 0NUMBERSK6"
      using arithm_lm_1 xcmplx_0_def_8 sorry
    thus "x -XCMPLX-0K6 0NUMBERSK6 =HIDDENR1 x"
      using arithm_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arithm_th_5:
" for x be ComplexXCMPLX-0M1 holds (0NUMBERSK6)/XCMPLX-0K7 x =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be ComplexXCMPLX-0M1 holds (0NUMBERSK6)/XCMPLX-0K7 x =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    have "(0NUMBERSK6)/XCMPLX-0K7 x =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 x \<inverse>XCMPLX-0K5"
      using xcmplx_0_def_9 sorry
    thus "(0NUMBERSK6)/XCMPLX-0K7 x =HIDDENR1 0NUMBERSK6"
      using arithm_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arithm_lm_2:
"\<one>\<^sub>M \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M"
proof-
  have "\<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M \<inverse>XCMPLX-0K5"
    using arithm_th_3 sorry
  thus "\<one>\<^sub>M \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M"
    using xcmplx_0_def_7 sorry
qed

mtheorem arithm_th_6:
" for x be ComplexXCMPLX-0M1 holds x /XCMPLX-0K7 \<one>\<^sub>M =HIDDENR1 x"
proof-
  have " for x be ComplexXCMPLX-0M1 holds x /XCMPLX-0K7 \<one>\<^sub>M =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    have "x /XCMPLX-0K7 \<one>\<^sub>M =HIDDENR1 x *XCMPLX-0K3 \<one>\<^sub>M"
      using arithm_lm_2 xcmplx_0_def_9 sorry
    thus "x /XCMPLX-0K7 \<one>\<^sub>M =HIDDENR1 x"
      using arithm_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
