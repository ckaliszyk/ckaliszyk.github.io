theory binari_2
  imports binarith
   "../mizar_extension/E_number"
begin
(*begin*)
reserve i, n for "NatNAT-1M1"
reserve m for " non zeroORDINAL1V8\<bar>NatNAT-1M1"
reserve p, q for "TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
reserve d, d1, d2 for "ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
mlemma binari_2_lm_1:
" for n be NatNAT-1M1 holds  for p be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for q be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds (lenFINSEQ-1K4 p =XBOOLE-0R4 n & lenFINSEQ-1K4 q =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies p /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 q /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies p =FINSEQ-1R1 q"
proof-
  have " for n be NatNAT-1M1 holds  for p be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for q be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds lenFINSEQ-1K4 p =XBOOLE-0R4 n & (lenFINSEQ-1K4 q =XBOOLE-0R4 n & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies p /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 q /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)) implies p =FINSEQ-1R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix q assume [ty]: "q be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    assume A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 n"
      and A2: "lenFINSEQ-1K4 q =XBOOLE-0R4 n"
      and A3: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies p /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 q /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
    have A4: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 n"
      using A1 finseq_1_def_3 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A5: "i inTARSKIR2 domFINSEQ-1K5 p"
      then have A6: "i inTARSKIR2 domFINSEQ-1K5 q"
        using A2 A4 finseq_1_def_3 sorry
      have A7: "p /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 p .FUNCT-1K1 i"
        using A5 partfun1_def_6 sorry
      have "q /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 q .FUNCT-1K1 i"
        using A6 partfun1_def_6 sorry
      thus "p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
        using A3 A4 A5 A7 sorry
    qed "sorry"
    thus "p =FINSEQ-1R1 q"
      using A1 A2 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef binari_2_def_1 ("Bin1BINARI-2K1  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func Bin1BINARI-2K1 n \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
    proof-
      have " ex tVar1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies tVar1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
      proof-
        let ?F = "\<lambda>Lamb1. IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(Lamb1,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
        obtain z where
          [ty]:"z be FinSequenceFINSEQ-1M3-of BOOLEANMARGREL1K5" and 
          A1: "lenFINSEQ-1K4 z =XBOOLE-0R4 n"and A2: " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 z implies z .FUNCT-1K1 j =XBOOLE-0R4 ?F(j)"
          using finseq_2_sch_1 sorry
        have A3: "domFINSEQ-1K5 z =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A1 finseq_1_def_3 sorry
        have "z be ElementFINSEQ-2M2\<^bsub>(BOOLEANMARGREL1K5)\<^esub>-of n -tuples-onFINSEQ-2K4 (BOOLEANMARGREL1K5)"
          using A1 finseq_2_th_92 sorry
        then have 
          [ty]:"z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
           sorry
        show " ex tVar1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies tVar1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
        proof(rule bexI[of _ "z"],rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A4: "i inTARSKIR2 SegFINSEQ-1K2 n"
          then have "i inTARSKIR2 domFINSEQ-1K5 z"
            using A1 finseq_1_def_3 sorry
          then have "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 z .FUNCT-1K1 i"
            using partfun1_def_6 sorry
          also have "... = IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
            using A2 A3 A4 sorry
          finally show "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)) implies it1 =HIDDENR1 it2"
    proof-
      have " for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)) implies z1 =HIDDENR1 z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        assume A5: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
          and A6: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
        have A7: "lenFINSEQ-1K4 z1 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        have A8: "lenFINSEQ-1K4 z2 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        have A9: "domFINSEQ-1K5 z1 =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A7 finseq_1_def_3 sorry
        have " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 z1 implies z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
        proof(rule ballI,rule impI)
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A10: "j inTARSKIR2 domFINSEQ-1K5 z1"
          then have A11: "j inTARSKIR2 domFINSEQ-1K5 z2"
            using A8 A9 finseq_1_def_3 sorry
          have "z1 .FUNCT-1K1 j =HIDDENR1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A10 partfun1_def_6 sorry
          also have "... = IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(j,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
            using A5 A9 A10 sorry
          also have "... = z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A6 A9 A10 sorry
          also have "... = z2 .FUNCT-1K1 j"
            using A11 partfun1_def_6 sorry
          finally show "z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
             sorry
        qed "sorry"
        thus "z1 =HIDDENR1 z2"
          using A7 A8 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef binari_2_def_2 ("Neg2BINARI-2K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func Neg2BINARI-2K2\<^bsub>(n)\<^esub> x \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) equals
  'not'BINARITHK3\<^bsub>(n)\<^esub> x +BINARITHK7\<^bsub>(n)\<^esub> Bin1BINARI-2K1 n"
proof-
  (*coherence*)
    show "'not'BINARITHK3\<^bsub>(n)\<^esub> x +BINARITHK7\<^bsub>(n)\<^esub> Bin1BINARI-2K1 n be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
       sorry
qed "sorry"

mdef binari_2_def_3 ("IntvalBINARI-2K3\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func IntvalBINARI-2K3\<^bsub>(n)\<^esub> x \<rightarrow> IntegerINT-1M1 equals
  AbsvalBINARITHK6\<^bsub>(n)\<^esub> x if x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 FALSEMARGREL1K6 otherwise AbsvalBINARITHK6\<^bsub>(n)\<^esub> x -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 n"
proof-
  (*coherence*)
    show "(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 FALSEMARGREL1K6 implies AbsvalBINARITHK6\<^bsub>(n)\<^esub> x be IntegerINT-1M1) & ( not x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 FALSEMARGREL1K6 implies AbsvalBINARITHK6\<^bsub>(n)\<^esub> x -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 n be IntegerINT-1M1)"
       sorry
  (*consistency*)
    show " for it be IntegerINT-1M1 holds  True "
       sorry
qed "sorry"

mdef binari_2_def_4 ("Int-add-ovflBINARI-2K4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func Int-add-ovflBINARI-2K4\<^bsub>(n)\<^esub>(z1,z2) \<rightarrow> ElementSUBSET-1M1-of BOOLEANMARGREL1K5 equals
  ('not'MARGREL1K10 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 'not'MARGREL1K10 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
proof-
  (*coherence*)
    show "('not'MARGREL1K10 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 'not'MARGREL1K10 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
qed "sorry"

mdef binari_2_def_5 ("Int-add-udflBINARI-2K5\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func Int-add-udflBINARI-2K5\<^bsub>(n)\<^esub>(z1,z2) \<rightarrow> ElementSUBSET-1M1-of BOOLEANMARGREL1K5 equals
  (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 'not'MARGREL1K10 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
proof-
  (*coherence*)
    show "(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'&'MARGREL1K11 'not'MARGREL1K10 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
qed "sorry"

mtheorem binari_2_th_1:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5)"
  assume A1: "z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
  obtain k1 k2 where
    [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1" "k2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
    A2: "BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> k1,k2 *>"
    using finseq_2_th_100 sorry
  have A3: "z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6,FALSEMARGREL1K6 *>"
    using A1 finseq_1_def_9 sorry
  then have A4: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
    using finseq_4_th_17 sorry
  have A5: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
    using A3 finseq_4_th_17 sorry
  have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M & SegFINSEQ-1K2 \<one>\<^sub>M c=TARSKIR1 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 finseq_1_th_5 sorry
  then have A6: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = 0NUMBERSK6"
    using A4 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
     sorry
  have "\<two>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 sorry
  then have A7: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = 0NUMBERSK6"
    using A5 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 0NUMBERSK6"
     sorry
  have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k1 & (BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 k2"
    using A2 finseq_4_th_17 sorry
  then have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6,0NUMBERSK6 *>)"
    using A2 A6 A7 binarith_def_4 sorry
  also have "... = (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> ((<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>))"
    using finseq_1_def_9 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>),(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>))"
    using finsop_1_th_5 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>))"
    using finsop_1_th_11 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,0NUMBERSK6)"
    using finsop_1_th_11 sorry
  also have "... = 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
    using binop_2_def_23 sorry
  also have "... = 0NUMBERSK6"
     sorry
  finally have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 0NUMBERSK6"
     sorry
  thus "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 0NUMBERSK6"
    using A5 binari_2_def_3 sorry
qed "sorry"

mtheorem binari_2_th_2:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule impI)
  fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5)"
  assume A1: "z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
  obtain k1 k2 where
    [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1" "k2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
    A2: "BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> k1,k2 *>"
    using finseq_2_th_100 sorry
  have A3: "z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7,FALSEMARGREL1K6 *>"
    using A1 finseq_1_def_9 sorry
  then have A4: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 TRUEMARGREL1K7"
    using finseq_4_th_17 sorry
  have A5: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
    using A3 finseq_4_th_17 sorry
  have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M & SegFINSEQ-1K2 \<one>\<^sub>M c=TARSKIR1 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 finseq_1_th_5 sorry
  then have A6: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
    using A4 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
     sorry
  have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
     sorry
  then have "\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
    using xreal_0_def_2 sorry
  then have A7: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
    using A6 power_th_24 sorry
  have "\<two>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 sorry
  then have A8: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = 0NUMBERSK6"
    using A5 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 0NUMBERSK6"
     sorry
  have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k1 & (BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 k2"
    using A2 finseq_4_th_17 sorry
  then have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M,0NUMBERSK6 *>)"
    using A2 A7 A8 binarith_def_4 sorry
  also have "... = (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> ((<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>))"
    using finseq_1_def_9 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>),(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>))"
    using finsop_1_th_5 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>))"
    using finsop_1_th_11 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,0NUMBERSK6)"
    using finsop_1_th_11 sorry
  also have "... = \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
    using binop_2_def_23 sorry
  also have "... = \<one>\<^sub>M"
     sorry
  finally have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 \<one>\<^sub>M"
     sorry
  thus "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 \<one>\<^sub>M"
    using A5 binari_2_def_3 sorry
qed "sorry"

mtheorem binari_2_th_3:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M"
proof(rule ballI,rule impI)
  fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5)"
  assume A1: "z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)"
  obtain k1 k2 where
    [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1" "k2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
    A2: "BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> k1,k2 *>"
    using finseq_2_th_100 sorry
  have A3: "z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6,TRUEMARGREL1K7 *>"
    using A1 finseq_1_def_9 sorry
  then have A4: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
    using finseq_4_th_17 sorry
  have A5: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 TRUEMARGREL1K7"
    using A3 finseq_4_th_17 sorry
  then have A6: "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
    using binari_2_def_3 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
    using power_th_27 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
    using power_th_25 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
    using power_th_25 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<four>\<^sub>M"
     sorry
  finally have "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<four>\<^sub>M"
     sorry
  have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M & SegFINSEQ-1K2 \<one>\<^sub>M c=TARSKIR1 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 finseq_1_th_5 sorry
  then have A7: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = 0NUMBERSK6"
    using A4 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
     sorry
  have "\<two>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 sorry
  then have A8: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = \<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
    using A5 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
     sorry
  have "\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
     sorry
  then have "\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  then have A9: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
    using A8 power_th_25 sorry
  have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k1 & (BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 k2"
    using A2 finseq_4_th_17 sorry
  then have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6,\<two>\<^sub>M *>)"
    using A2 A7 A9 binarith_def_4 sorry
  also have "... = (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> ((<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M*>))"
    using finseq_1_def_9 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6 *>),(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M*>))"
    using finsop_1_th_5 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M*>))"
    using finsop_1_th_11 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(0NUMBERSK6,\<two>\<^sub>M)"
    using finsop_1_th_11 sorry
  also have "... = 0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M"
    using binop_2_def_23 sorry
  also have "... = \<two>\<^sub>M"
     sorry
  finally have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 \<two>\<^sub>M"
     sorry
  thus "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 -XCMPLX-0K4 \<two>\<^sub>M"
    using A6 sorry
qed "sorry"

mtheorem binari_2_th_4:
" for z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>) implies IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof(rule ballI,rule impI)
  fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<two>\<^sub>M,BOOLEANMARGREL1K5)"
  assume A1: "z1 =FINSEQ-1R1 (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>)"
  obtain k1 k2 where
    [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1" "k2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
    A2: "BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> k1,k2 *>"
    using finseq_2_th_100 sorry
  have A3: "z1 =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7,TRUEMARGREL1K7 *>"
    using A1 finseq_1_def_9 sorry
  then have A4: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M <>HIDDENR2 FALSEMARGREL1K6"
    using finseq_4_th_17 sorry
  have A5: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M <>HIDDENR2 FALSEMARGREL1K6"
    using A3 finseq_4_th_17 sorry
  then have A6: "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
    using binari_2_def_3 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
    using power_th_27 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
    using power_th_25 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
    using power_th_25 sorry
  also have "... = AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<four>\<^sub>M"
     sorry
  finally have "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 -XCMPLX-0K6 \<four>\<^sub>M"
     sorry
  have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M & SegFINSEQ-1K2 \<one>\<^sub>M c=TARSKIR1 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 finseq_1_th_5 sorry
  then have A7: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
    using A4 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
     sorry
  have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
     sorry
  then have "\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
    using xreal_0_def_2 sorry
  then have A8: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
    using A7 power_th_24 sorry
  have "\<two>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<two>\<^sub>M"
    using finseq_1_th_3 sorry
  then have A9: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
    using binarith_def_3 sorry
  also have "... = \<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
    using A5 funcop_1_def_8 sorry
  finally have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
     sorry
  have "\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
     sorry
  then have "\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  then have A10: "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
    using A9 power_th_25 sorry
  have "(BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k1 & (BinaryBINARITHK5\<^bsub>(\<two>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 k2"
    using A2 finseq_4_th_17 sorry
  then have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M,\<two>\<^sub>M *>)"
    using A2 A8 A10 binarith_def_4 sorry
  also have "... = (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> ((<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M*>))"
    using finseq_1_def_9 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M*>),(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M*>))"
    using finsop_1_th_5 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> \<two>\<^sub>M*>))"
    using finsop_1_th_11 sorry
  also have "... = (addnatBINOP-2K23).BINOP-1K4\<^bsub>(NATNUMBERSK1)\<^esub>(\<one>\<^sub>M,\<two>\<^sub>M)"
    using finsop_1_th_11 sorry
  also have "... = \<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M"
    using binop_2_def_23 sorry
  also have "... = \<three>\<^sub>M"
     sorry
  finally have "AbsvalBINARITHK6\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 \<three>\<^sub>M"
     sorry
  thus "IntvalBINARI-2K3\<^bsub>(\<two>\<^sub>M)\<^esub> z1 =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    using A6 sorry
qed "sorry"

mtheorem binari_2_th_5:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n & i =XBOOLE-0R4 \<one>\<^sub>M implies (Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 TRUEMARGREL1K7"
proof-
  have " for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n & i =XBOOLE-0R4 \<one>\<^sub>M implies (Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 TRUEMARGREL1K7"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i inTARSKIR2 SegFINSEQ-1K2 n"
      and A2: "i =XBOOLE-0R4 \<one>\<^sub>M"
    have "(Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
      using A1 binari_2_def_1 sorry
    also have "... = TRUEMARGREL1K7"
      using A2 funcop_1_def_8 sorry
    finally show "(Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 TRUEMARGREL1K7"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_6:
" for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n & i <>HIDDENR2 \<one>\<^sub>M implies (Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 FALSEMARGREL1K6"
proof-
  have " for n be NatNAT-1M1 holds  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n & i <>HIDDENR2 \<one>\<^sub>M implies (Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 FALSEMARGREL1K6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i inTARSKIR2 SegFINSEQ-1K2 n"
      and A2: "i <>HIDDENR2 \<one>\<^sub>M"
    have "(Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(BOOLEANMARGREL1K5)\<^esub>(i,\<one>\<^sub>M,TRUEMARGREL1K7,FALSEMARGREL1K6)"
      using A1 binari_2_def_1 sorry
    also have "... = FALSEMARGREL1K6"
      using A2 funcop_1_def_8 sorry
    finally show "(Bin1BINARI-2K1 n)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 FALSEMARGREL1K6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_7:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
  proof(rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    have A1: "lenFINSEQ-1K4 (Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
      using card_1_def_7 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M) implies (Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A2: "i inTARSKIR2 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
      show "(Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      proof-
        have cases: "i inTARSKIR2 SegFINSEQ-1K2 m or i =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
          using A2 finseq_2_th_7 sorry
        have case1: "i inTARSKIR2 SegFINSEQ-1K2 m implies (Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof(rule impI)
          assume A3: "i inTARSKIR2 SegFINSEQ-1K2 m"
          show "(Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          proof-
            show "(Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            proof-
              have cases: "i =XBOOLE-0R4 \<one>\<^sub>M or i <>HIDDENR2 \<one>\<^sub>M"
                 sorry
              have case1: "i =XBOOLE-0R4 \<one>\<^sub>M implies (Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              proof(rule impI)
                assume A4: "i =XBOOLE-0R4 \<one>\<^sub>M"
                have "((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (Bin1BINARI-2K1 m)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                  using A3 binarith_th_1 sorry
                also have "... = TRUEMARGREL1K7"
                  using A3 A4 binari_2_th_5 sorry
                finally have "((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 TRUEMARGREL1K7"
                   sorry
                thus "(Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                  using A2 A4 binari_2_th_5 sorry
              qed
              have case2: "i <>HIDDENR2 \<one>\<^sub>M implies (Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              proof(rule impI)
                assume A5: "i <>HIDDENR2 \<one>\<^sub>M"
                have "((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (Bin1BINARI-2K1 m)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                  using A3 binarith_th_1 sorry
                also have "... = FALSEMARGREL1K6"
                  using A3 A5 binari_2_th_6 sorry
                finally have "((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 FALSEMARGREL1K6"
                   sorry
                thus "(Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                  using A2 A5 binari_2_th_6 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
        qed
        have case2: "i =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M implies (Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof(rule impI)
          assume A6: "i =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
          have "\<one>\<^sub>M <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_14 sorry
          then have "(Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 FALSEMARGREL1K6"
            using A2 A6 binari_2_th_6 sorry
          thus "(Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A6 binarith_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
      using A1 binari_2_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_8:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
proof-
  let ?P = "\<lambda>Lamb1. IntvalBINARI-2K3\<^bsub>(Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 Lamb1)^BINARITHK9\<^bsub>(Lamb1,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
  have A1: "?P(\<one>\<^sub>M)"
  proof-
    have "IntvalBINARI-2K3\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 \<one>\<^sub>M)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
    proof-
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
        A2: "Bin1BINARI-2K1 \<one>\<^sub>M =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>"
        using finseq_2_th_97 sorry
      have A3: "(Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k"
        using A2 finseq_4_th_16 sorry
      have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
        using finseq_1_th_3 sorry
      then have "Bin1BINARI-2K1 \<one>\<^sub>M =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>"
        using A2 A3 binari_2_th_5 sorry
      thus "IntvalBINARI-2K3\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 \<one>\<^sub>M)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
        using binari_2_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  have A4: " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M implies IntvalBINARI-2K3\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    assume A5: "?P(m)"
    have "((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FALSEMARGREL1K6"
      using binarith_th_2 sorry
    then have A6: "AbsvalBINARITHK6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =XBOOLE-0R4 \<one>\<^sub>M"
      using A5 binari_2_def_3 sorry
    have "((Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FALSEMARGREL1K6"
      using binarith_th_2 sorry
    then have "IntvalBINARI-2K3\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))"
      using binari_2_def_3 sorry
    also have "... = AbsvalBINARITHK6\<^bsub>((m +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))^BINARITHK9\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))"
      using binari_2_th_7 sorry
    also have "... = AbsvalBINARITHK6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(FALSEMARGREL1K6,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binarith_th_20 sorry
    also have "... = \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
      using A6 funcop_1_def_8 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "IntvalBINARI-2K3\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "IntvalBINARI-2K3\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  show " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 \<one>\<^sub>M"
    using nat_1_sch_10 A1 A4 sorry
qed

mtheorem binari_2_th_9:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds 'not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =FINSEQ-1R1 'not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds 'not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =FINSEQ-1R1 'not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z assume [ty]: "z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    have A1: "lenFINSEQ-1K4 ('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)) =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
      using card_1_def_7 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M) implies ('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A2: "i inTARSKIR2 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
      show "('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      proof-
        have cases: "i inTARSKIR2 SegFINSEQ-1K2 m or i =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
          using A2 finseq_2_th_7 sorry
        have case1: "i inTARSKIR2 SegFINSEQ-1K2 m implies ('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof(rule impI)
          assume A3: "i inTARSKIR2 SegFINSEQ-1K2 m"
          have A4: "('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A2 binarith_def_1 sorry
          also have "... = 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A3 binarith_th_1 sorry
          finally have "('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
             sorry
          have "('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ('not'BINARITHK3\<^bsub>(m)\<^esub> z)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A3 binarith_th_1 sorry
          also have "... = 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A3 binarith_def_1 sorry
          finally have "('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
             sorry
          thus "('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A4 sorry
        qed
        have case2: "i =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M implies ('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof(rule impI)
          assume A5: "i =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
          have "('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A2 binarith_def_1 sorry
          also have "... = 'not'MARGREL1K10 d"
            using A5 binarith_th_2 sorry
          finally have "('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 d"
             sorry
          thus "('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A5 binarith_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "'not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =FINSEQ-1R1 'not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)"
      using A1 binari_2_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_10:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z assume [ty]: "z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    show "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
    proof-
      have cases: "d =XBOOLE-0R4 FALSEMARGREL1K6 or d =XBOOLE-0R4 TRUEMARGREL1K7"
        using xboolean_def_3 sorry
      have case1: "d =XBOOLE-0R4 FALSEMARGREL1K6 implies IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
      proof(rule impI)
        assume A1: "d =XBOOLE-0R4 FALSEMARGREL1K6"
        then have "(z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FALSEMARGREL1K6"
          using binarith_th_2 sorry
        then have A2: "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
          using binari_2_def_3 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
          using binarith_th_20 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z +NAT-1K1 0NUMBERSK6"
          using A1 funcop_1_def_8 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z"
           sorry
        finally have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z"
           sorry
        have "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 0NUMBERSK6"
          using A1 funcop_1_def_8 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z"
           sorry
        finally have "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z"
           sorry
        thus "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
          using A2 sorry
      qed
      have case2: "d =XBOOLE-0R4 TRUEMARGREL1K7 implies IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
      proof(rule impI)
        assume A3: "d =XBOOLE-0R4 TRUEMARGREL1K7"
        then have "(z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 FALSEMARGREL1K6"
          using binarith_th_2 sorry
        then have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
          using binari_2_def_3 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m))-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
          using binarith_th_20 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z +NAT-1K1 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
          using A3 funcop_1_def_8 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z +NAT-1K1 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 m *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
          using power_th_27 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z +NAT-1K1 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
          using power_th_25 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 m"
           sorry
        finally have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 m"
           sorry
        thus "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
          using A3 funcop_1_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_11:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    let ?f = "FALSEMARGREL1K6"
    let ?t = "TRUEMARGREL1K7"
    have A1: "AbsvalBINARITHK6\<^bsub>(m)\<^esub> (z1 +BINARITHK7\<^bsub>(m)\<^esub> z2) =XBOOLE-0R4 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
    proof-
      let ?siki1 = "AbsvalBINARITHK6\<^bsub>(m)\<^esub> (z1 +BINARITHK7\<^bsub>(m)\<^esub> z2)"
      let ?siki2 = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
      have "(?siki1 +NAT-1K1 ?siki2)-XCMPLX-0K6 ?siki2 =XBOOLE-0R4 ?siki1"
         sorry
      thus "AbsvalBINARITHK6\<^bsub>(m)\<^esub> (z1 +BINARITHK7\<^bsub>(m)\<^esub> z2) =XBOOLE-0R4 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
        using binarith_th_21 sorry
    qed
    have A2: "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((z1 +BINARITHK7\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2)) *>))"
      using binarith_th_19 sorry
    also have "... = ((AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
      using A1 binari_2_th_10 sorry
    finally have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 ((AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
       sorry
    have A3: "Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 ('not'MARGREL1K10 d1 '&'MARGREL1K11 'not'MARGREL1K10 (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
      using binarith_th_2 sorry
    also have "... = ('not'MARGREL1K10 d1 '&'MARGREL1K11 'not'MARGREL1K10 d2)'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
      using binarith_th_2 sorry
    also have "... = ('not'MARGREL1K10 d1 '&'MARGREL1K11 'not'MARGREL1K10 d2)'&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2))"
      using binarith_th_18 sorry
    finally have "Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 ('not'MARGREL1K10 d1 '&'MARGREL1K11 'not'MARGREL1K10 d2)'&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2))"
       sorry
    have A4: "Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 (d1 '&'MARGREL1K11 (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'&'MARGREL1K11 'not'MARGREL1K10 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
      using binarith_th_2 sorry
    also have "... = (d1 '&'MARGREL1K11 d2)'&'MARGREL1K11 'not'MARGREL1K10 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
      using binarith_th_2 sorry
    also have "... = (d1 '&'MARGREL1K11 d2)'&'MARGREL1K11 'not'MARGREL1K10 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2))"
      using binarith_th_18 sorry
    finally have "Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 (d1 '&'MARGREL1K11 d2)'&'MARGREL1K11 'not'MARGREL1K10 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2))"
       sorry
    have A5: "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
      using binari_2_th_10 sorry
    have A6: "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d2,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
      using binari_2_th_10 sorry
    show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
    proof-
      have cases: "((d1 =XBOOLE-0R4 ?f & d2 =XBOOLE-0R4 ?f or d1 =XBOOLE-0R4 ?t & d2 =XBOOLE-0R4 ?f) or d1 =XBOOLE-0R4 ?f & d2 =XBOOLE-0R4 ?t) or d1 =XBOOLE-0R4 ?t & d2 =XBOOLE-0R4 ?t"
        using xboolean_def_3 sorry
      have case1: "d1 =XBOOLE-0R4 FALSEMARGREL1K6 & d2 =XBOOLE-0R4 FALSEMARGREL1K6 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
      proof(rule impI)
        assume A7: "d1 =XBOOLE-0R4 ?f & d2 =XBOOLE-0R4 ?f"
        then have A8: "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 0NUMBERSK6"
          using funcop_1_def_8 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1"
           sorry
        finally have "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1"
           sorry
        have A9: "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d2,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 0NUMBERSK6"
          using A7 funcop_1_def_8 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2"
           sorry
        finally have "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d2,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2"
           sorry
        have A10: "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((d1 '&'MARGREL1K11 d2)'&'MARGREL1K11 'not'MARGREL1K10 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2)),?f,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 0NUMBERSK6"
          using A7 funcop_1_def_8 sorry
        show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
        proof-
          show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
          proof-
            have cases: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f or add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              using xboolean_def_3 sorry
            have case1: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 FALSEMARGREL1K6 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f"
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A2 A3 A4 A6 A7 A8 binari_2_th_10 sorry
            qed
            have case2: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 TRUEMARGREL1K7 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume A11: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =XBOOLE-0R4 \<two>\<^sub>M to-powerSERIES-1K5 m"
                using funcop_1_def_8 sorry
              then have "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
                using A2 A3 A4 A7 A10 A11 funcop_1_def_8 sorry
              also have "... = ((AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
                using power_th_25 sorry
              also have "... = ((AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
                using power_th_27 sorry
              also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2"
                 sorry
              finally have "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2"
                 sorry
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A6 A8 A9 binari_2_th_10 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      have case2: "d1 =XBOOLE-0R4 TRUEMARGREL1K7 & d2 =XBOOLE-0R4 FALSEMARGREL1K6 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
      proof(rule impI)
        assume A12: "d1 =XBOOLE-0R4 ?t & d2 =XBOOLE-0R4 ?f"
        then have A13: "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d2,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 0NUMBERSK6"
          using funcop_1_def_8 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2"
           sorry
        finally have "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d2,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2"
           sorry
        show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
        proof-
          show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
          proof-
            have cases: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f or add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              using xboolean_def_3 sorry
            have case1: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 FALSEMARGREL1K6 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume A14: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f"
              then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =XBOOLE-0R4 0NUMBERSK6"
                using funcop_1_def_8 sorry
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A2 A3 A4 A5 A6 A12 A13 A14 sorry
            qed
            have case2: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 TRUEMARGREL1K7 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A2 A3 A4 A5 A6 A12 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      have case3: "d1 =XBOOLE-0R4 FALSEMARGREL1K6 & d2 =XBOOLE-0R4 TRUEMARGREL1K7 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
      proof(rule impI)
        assume A15: "d1 =XBOOLE-0R4 ?f & d2 =XBOOLE-0R4 ?t"
        then have A16: "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 0NUMBERSK6"
          using funcop_1_def_8 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1"
           sorry
        finally have "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1"
           sorry
        show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
        proof-
          show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
          proof-
            have cases: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f or add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              using xboolean_def_3 sorry
            have case1: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 FALSEMARGREL1K6 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume A17: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f"
              then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =XBOOLE-0R4 0NUMBERSK6"
                using funcop_1_def_8 sorry
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A2 A3 A4 A5 A6 A15 A16 A17 sorry
            qed
            have case2: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 TRUEMARGREL1K7 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A2 A3 A4 A5 A6 A15 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      have case4: "d1 =XBOOLE-0R4 TRUEMARGREL1K7 & d2 =XBOOLE-0R4 TRUEMARGREL1K7 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
      proof(rule impI)
        assume A18: "d1 =XBOOLE-0R4 ?t & d2 =XBOOLE-0R4 ?t"
        then have A19: "AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d2,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2 -XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 m"
          using funcop_1_def_8 sorry
        have A20: "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m))+XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
          using A5 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
          using A6 A18 A19 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
          using power_th_25 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
          using power_th_27 sorry
        finally have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
        have A21: "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(('not'MARGREL1K10 d1 '&'MARGREL1K11 'not'MARGREL1K10 d2)'&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2)),?f,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 0NUMBERSK6"
          using A18 funcop_1_def_8 sorry
        show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
        proof-
          show "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
          proof-
            have cases: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f or add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              using xboolean_def_3 sorry
            have case1: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 FALSEMARGREL1K6 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume A22: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?f"
              then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =XBOOLE-0R4 0NUMBERSK6"
                using funcop_1_def_8 sorry
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A2 A3 A4 A18 A20 A21 A22 funcop_1_def_8 sorry
            qed
            have case2: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 TRUEMARGREL1K7 implies (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
            proof(rule impI)
              assume A23: "add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m) =XBOOLE-0R4 \<two>\<^sub>M to-powerSERIES-1K5 m"
                using funcop_1_def_8 sorry
              then have "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
                using A2 A3 A4 A18 A23 sorry
              also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
                using power_th_25 sorry
              also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
                using power_th_27 sorry
              finally have "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z2)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              thus "(IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
                using A20 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_12:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    let ?A = "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
    let ?B = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
    let ?C = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
    let ?D = "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
    have "(?A +XCMPLX-0K2 ?B)-XCMPLX-0K6 ?C =XBOOLE-0R4 ?D"
      using binari_2_th_11 sorry
    thus "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) =HIDDENR1 ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_13:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(m)\<^esub> 'not'BINARITHK3\<^bsub>(m)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
proof-
  let ?P = "\<lambda>Lamb1.  for x be TupleFINSEQ-2M3-of(Lamb1,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(Lamb1)\<^esub> 'not'BINARITHK3\<^bsub>(Lamb1)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(Lamb1)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 Lamb1)-XCMPLX-0K6 \<one>\<^sub>M"
  have A1: "?P(\<one>\<^sub>M)"
  proof-
    have " for x be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
    proof(rule ballI)
      fix x assume [ty]: "x be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)"
      show "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      proof-
        have cases: "x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *> or x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>"
          using binarith_th_14 sorry
        have case1: "x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
        proof(rule impI)
          assume A2: "x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>"
          then have A3: "x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
            using finseq_4_th_16 sorry
          obtain k where
            [ty]:"k be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
            A4: "'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>"
            using finseq_2_th_97 sorry
          have A5: "('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k"
            using A4 finseq_4_th_16 sorry
          have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
            using finseq_1_th_3 sorry
          then have A6: "('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 'not'MARGREL1K10 (FALSEMARGREL1K6)"
            using A3 binarith_def_1 sorry
          also have "... = TRUEMARGREL1K7"
             sorry
          finally have "('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 TRUEMARGREL1K7"
             sorry
          have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((-XCMPLX-0K4 0NUMBERSK6)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using A2 binarith_th_15 sorry
          also have "... = (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using power_th_25 sorry
          also have "... = \<one>\<^sub>M"
             sorry
          finally have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
             sorry
          thus "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using A4 A5 A6 binarith_th_16 sorry
        qed
        have case2: "x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
        proof(rule impI)
          assume A7: "x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *>"
          then have A8: "x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 TRUEMARGREL1K7"
            using finseq_4_th_16 sorry
          obtain k where
            [ty]:"k be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
            A9: "'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>"
            using finseq_2_th_97 sorry
          have A10: "('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k"
            using A9 finseq_4_th_16 sorry
          have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
            using finseq_1_th_3 sorry
          then have A11: "('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 'not'MARGREL1K10 (TRUEMARGREL1K7)"
            using A8 binarith_def_1 sorry
          also have "... = FALSEMARGREL1K6"
             sorry
          finally have "('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 FALSEMARGREL1K6"
             sorry
          have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using A7 binarith_th_16 sorry
          also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using power_th_25 sorry
          also have "... = 0NUMBERSK6"
             sorry
          finally have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
             sorry
          thus "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using A9 A10 A11 binarith_th_15 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A12: " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ( for x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(m)\<^esub> 'not'BINARITHK3\<^bsub>(m)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M) implies ( for x be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    assume A13: "?P(m)"
    have " for x be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
    proof(rule ballI)
      fix x assume [ty]: "x be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5)"
      obtain t d where
        [ty]:"t be ElementFINSEQ-2M2\<^bsub>(BOOLEANMARGREL1K5)\<^esub>-of m -tuples-onFINSEQ-2K4 (BOOLEANMARGREL1K5)" "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
        A14: "x =FINSEQ-1R1 t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
        using finseq_2_th_117 sorry
      have A15: "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =HIDDENR1 AbsvalBINARITHK6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))"
        using A14 binari_2_th_9 sorry
      also have "... = AbsvalBINARITHK6\<^bsub>(m)\<^esub> 'not'BINARITHK3\<^bsub>(m)\<^esub> t +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>('not'MARGREL1K10 d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
        using binarith_th_20 sorry
      also have "... = (((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>('not'MARGREL1K10 d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
        using A13 sorry
      finally have "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =HIDDENR1 (((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>('not'MARGREL1K10 d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
         sorry
      have A16: "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 ((-XCMPLX-0K4 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> t +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)))+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
        using A14 binarith_th_20 sorry
      show "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
      proof-
        show "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
        proof-
          have cases: "d =XBOOLE-0R4 FALSEMARGREL1K6 or d =XBOOLE-0R4 TRUEMARGREL1K7"
            using xboolean_def_3 sorry
          have case1: "d =XBOOLE-0R4 FALSEMARGREL1K6 implies AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
          proof(rule impI)
            assume A17: "d =XBOOLE-0R4 FALSEMARGREL1K6"
            then have A18: "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =HIDDENR1 (((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
              using A15 funcop_1_def_8 sorry
            also have "... = ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            also have "... = ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
              using power_th_25 sorry
            also have "... = ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
              using power_th_27 sorry
            finally have "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =HIDDENR1 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((-XCMPLX-0K4 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> t +NAT-1K1 0NUMBERSK6))+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
              using A16 A17 funcop_1_def_8 sorry
            also have "... = ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            finally have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            thus "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
              using A18 sorry
          qed
          have case2: "d =XBOOLE-0R4 TRUEMARGREL1K7 implies AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
          proof(rule impI)
            assume A19: "d =XBOOLE-0R4 TRUEMARGREL1K7"
            then have A20: "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =HIDDENR1 (((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6"
              using A15 funcop_1_def_8 sorry
            also have "... = ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            finally have "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =HIDDENR1 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((-XCMPLX-0K4 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> t +NAT-1K1 \<two>\<^sub>M to-powerSERIES-1K5 m))+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
              using A16 A19 funcop_1_def_8 sorry
            also have "... = (((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 m)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
              using power_th_27 sorry
            also have "... = (((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 m)+XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
              using power_th_25 sorry
            also have "... = ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            finally have "((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> t)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
               sorry
            thus "AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
              using A20 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
    qed "sorry"
    thus " for x be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> 'not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 \<one>\<^sub>M"
       sorry
  qed "sorry"
  show " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(m)\<^esub> 'not'BINARITHK3\<^bsub>(m)\<^esub> x =XBOOLE-0R4 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> x)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M"
    using nat_1_sch_10 A1 A12 sorry
qed

mtheorem binari_2_th_14:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =FINSEQ-1R1 (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z,Bin1BINARI-2K1 m)) *>)"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z,Bin1BINARI-2K1 m)) *>)"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z assume [ty]: "z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    have "Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 'not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)"
      using binari_2_th_9 sorry
    also have "... = 'not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
      using binari_2_th_7 sorry
    also have "... = ('not'BINARITHK3\<^bsub>(m)\<^esub> z +BINARITHK7\<^bsub>(m)\<^esub> Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ('not'MARGREL1K10 d 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z,Bin1BINARI-2K1 m)) *>)"
      using binarith_th_19 sorry
    also have "... = (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z,Bin1BINARI-2K1 m)) *>)"
       sorry
    finally show "Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z,Bin1BINARI-2K1 m)) *>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_15:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z assume [ty]: "z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    let ?OV = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
    let ?UD = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
    have A1: "Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 (('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (FALSEMARGREL1K6))'&'MARGREL1K11 'not'MARGREL1K10 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
      using binarith_th_2 sorry
    also have "... = FALSEMARGREL1K6"
       sorry
    finally have "Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) =HIDDENR1 FALSEMARGREL1K6"
       sorry
    have A2: "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 IntvalBINARI-2K3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_9 sorry
    also have "... = IntvalBINARI-2K3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_9 sorry
    also have "... = IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_7 sorry
    also have "... = IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) +XCMPLX-0K2 ?OV"
      using binari_2_th_7 sorry
    also have "... = (((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))-XCMPLX-0K6 ?OV)+XCMPLX-0K2 ?UD)+XCMPLX-0K2 ?OV"
      using binari_2_th_12 sorry
    also have "... = (((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)) +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ?OV)+XCMPLX-0K2 ?UD)+XCMPLX-0K2 ?OV"
      using binari_2_th_8 sorry
    also have "... = ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 ?UD)-XCMPLX-0K6 (?OV -XCMPLX-0K6 ?OV)"
       sorry
    also have "... = (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>)) +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6"
      using A1 funcop_1_def_8 sorry
    also have "... = (AbsvalBINARITHK6\<^bsub>(m)\<^esub> 'not'BINARITHK3\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>('not'MARGREL1K10 d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m))+XCMPLX-0K2 \<one>\<^sub>M"
      using binari_2_th_10 sorry
    also have "... = ((((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>('not'MARGREL1K10 d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m))+XCMPLX-0K2 \<one>\<^sub>M"
      using binari_2_th_13 sorry
    also have "... = ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>('not'MARGREL1K10 d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
       sorry
    finally have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>('not'MARGREL1K10 d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
       sorry
    have A3: "-XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 -XCMPLX-0K4 (AbsvalBINARITHK6\<^bsub>(m)\<^esub> z -XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m))"
      using binari_2_th_10 sorry
    also have "... = (-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
       sorry
    finally have "-XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 (-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 m)"
       sorry
    show "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
    proof-
      have cases: "d =XBOOLE-0R4 FALSEMARGREL1K6 or d =XBOOLE-0R4 TRUEMARGREL1K7"
        using xboolean_def_3 sorry
      have case1: "d =XBOOLE-0R4 FALSEMARGREL1K6 implies IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
      proof(rule impI)
        assume A4: "d =XBOOLE-0R4 FALSEMARGREL1K6"
        then have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 \<two>\<^sub>M to-powerSERIES-1K5 m"
          using A2 funcop_1_def_8 sorry
        also have "... = (-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 0NUMBERSK6"
           sorry
        finally have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 0NUMBERSK6"
           sorry
        thus "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
          using A3 A4 funcop_1_def_8 sorry
      qed
      have case2: "d =XBOOLE-0R4 TRUEMARGREL1K7 implies IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
      proof(rule impI)
        assume A5: "d =XBOOLE-0R4 TRUEMARGREL1K7"
        then have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m)-XCMPLX-0K6 0NUMBERSK6"
          using A2 funcop_1_def_8 sorry
        also have "... = (-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
           sorry
        finally have "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (-XCMPLX-0K4 AbsvalBINARITHK6\<^bsub>(m)\<^esub> z)+XCMPLX-0K2 \<two>\<^sub>M to-powerSERIES-1K5 m"
           sorry
        thus "IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 -XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
          using A3 A5 funcop_1_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_16:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
proof-
  let ?P = "\<lambda>Lamb1.  for z be TupleFINSEQ-2M3-of(Lamb1,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(Lamb1 +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(Lamb1,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(Lamb1,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
  have A1: "?P(\<one>\<^sub>M)"
  proof-
    have " for z be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
    proof(rule ballI,rule ballI)
      fix z assume [ty]: "z be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)"
      fix d assume [ty]: "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
      let ?NZD = "'not'MARGREL1K10 d 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
      let ?DPI = "d '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
      let ?NZ1 = "('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
      let ?B1 = "(Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
      have A2: "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
        using finseq_1_th_3 sorry
      have A3: "('not'MARGREL1K10 d 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M)) =HIDDENR1 'not'MARGREL1K10 d 'xor'BINARITHK2 (?NZ1 '&'MARGREL1K11 ?B1 'or'BINARITHK1 ?NZ1 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'or'BINARITHK1 ?B1 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using binarith_def_6 sorry
      also have "... = 'not'MARGREL1K10 d 'xor'BINARITHK2 (?NZ1 '&'MARGREL1K11 ?B1 'or'BINARITHK1 ?NZ1 '&'MARGREL1K11 (FALSEMARGREL1K6))'or'BINARITHK1 ?B1 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using binarith_def_2 sorry
      also have "... = 'not'MARGREL1K10 d 'xor'BINARITHK2 (?NZ1 '&'MARGREL1K11 ?B1 'or'BINARITHK1 (FALSEMARGREL1K6))'or'BINARITHK1 ?B1 '&'MARGREL1K11 (FALSEMARGREL1K6)"
        using binarith_def_2 sorry
      also have "... = 'not'MARGREL1K10 d 'xor'BINARITHK2 (TRUEMARGREL1K7)'&'MARGREL1K11 ?NZ1"
        using A2 binari_2_th_5 sorry
      also have "... = 'not'MARGREL1K10 d 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A2 binarith_def_1 sorry
      finally have "('not'MARGREL1K10 d 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M)) =HIDDENR1 'not'MARGREL1K10 d 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
         sorry
      have A4: "('not'MARGREL1K10 ?NZD 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M),Bin1BINARI-2K1 \<one>\<^sub>M)) =HIDDENR1 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 (('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 ?B1 'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M),Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'or'BINARITHK1 ?B1 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M),Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using binarith_def_6 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 (('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (FALSEMARGREL1K6))'or'BINARITHK1 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M),Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using binarith_def_2 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 (('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 (FALSEMARGREL1K6))'or'BINARITHK1 ?B1 '&'MARGREL1K11 (FALSEMARGREL1K6)"
        using binarith_def_2 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 (TRUEMARGREL1K7)'&'MARGREL1K11 ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A2 binari_2_th_5 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A2 binarith_def_1 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 ((('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using A2 binarith_def_5 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 ((('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (FALSEMARGREL1K6))"
        using binarith_def_2 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 (?NZ1 'xor'BINARITHK2 (TRUEMARGREL1K7))"
        using A2 binari_2_th_5 sorry
      also have "... = 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A2 binarith_def_1 sorry
      finally have "('not'MARGREL1K10 ?NZD 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M),Bin1BINARI-2K1 \<one>\<^sub>M)) =HIDDENR1 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
         sorry
      have A5: "Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =HIDDENR1 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) +BINARITHK7\<^bsub>(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
        using binari_2_th_9 sorry
      also have "... = 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d*>) +BINARITHK7\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 \<one>\<^sub>M)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)) +BINARITHK7\<^bsub>(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
        using binari_2_th_7 sorry
      also have "... = 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ('not'MARGREL1K10 d 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M)) *>)) +BINARITHK7\<^bsub>(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_19 sorry
      also have "... = 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M) ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 ?NZD*>) +BINARITHK7\<^bsub>(\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
        using A3 binari_2_th_9 sorry
      also have "... = 'not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M) ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 ?NZD*>) +BINARITHK7\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 \<one>\<^sub>M)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)"
        using binari_2_th_7 sorry
      also have "... = ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M) +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M *>)"
        using A4 binarith_th_19 sorry
      finally have "Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =HIDDENR1 ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M) +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M)^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 ?NZD 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M *>)"
         sorry
      then have A6: "(Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M) +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A2 binarith_th_1 sorry
      also have "... = (('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M),Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A2 binarith_def_5 sorry
      also have "... = (('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (FALSEMARGREL1K6)"
        using binarith_def_2 sorry
      also have "... = ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (TRUEMARGREL1K7)"
        using A2 binari_2_th_5 sorry
      also have "... = 'not'MARGREL1K10 ('not'MARGREL1K10 ('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using A2 binarith_def_1 sorry
      also have "... = (('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(\<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 \<one>\<^sub>M))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A2 binarith_def_5 sorry
      also have "... = (?NZ1 'xor'BINARITHK2 (Bin1BINARI-2K1 \<one>\<^sub>M)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (FALSEMARGREL1K6)"
        using binarith_def_2 sorry
      also have "... = ?NZ1 'xor'BINARITHK2 (TRUEMARGREL1K7)"
        using A2 binari_2_th_5 sorry
      also have "... = 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using A2 binarith_def_1 sorry
      also have "... = z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
         sorry
      finally have "(Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
         sorry
      obtain p q where 
        [ty]:"p be booleanMARGREL1V2\<bar>objectHIDDENM1" and pDef:"p = d" and
        [ty]:"q be booleanMARGREL1V2\<bar>objectHIDDENM1" and qDef:"q = z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
         sorry
      have A7: "(Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M =HIDDENR1 ('not'MARGREL1K10 d 'or'BINARITHK1 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M))'&'MARGREL1K11 ('not'MARGREL1K10 ('not'MARGREL1K10 d) 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M) 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using A5 binarith_th_2 sorry
      also have "... = ('not'MARGREL1K8 p 'or'XBOOLEANK5 q)'&'MARGREL1K9 p 'or'XBOOLEANK5 ('not'MARGREL1K8 p 'or'XBOOLEANK5 q)'&'MARGREL1K9 'not'MARGREL1K8 q 'xor'XBOOLEANK10 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using xboolean_th_8 sorry
      also have "... = (p '&'MARGREL1K9 'not'MARGREL1K8 p 'or'XBOOLEANK5 p '&'MARGREL1K9 q)'or'XBOOLEANK5 'not'MARGREL1K8 q '&'MARGREL1K9 ('not'MARGREL1K8 p 'or'XBOOLEANK5 q) 'xor'XBOOLEANK10 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using xboolean_th_8 sorry
      also have "... = (d '&'MARGREL1K11 'not'MARGREL1K10 d 'or'BINARITHK1 d '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'or'BINARITHK1 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M) 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using xboolean_th_8 sorry
      also have "... = ((FALSEMARGREL1K6)'or'BINARITHK1 d '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'or'BINARITHK1 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M) 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using xboolean_th_138 sorry
      also have "... = ?DPI 'or'BINARITHK1 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d 'or'BINARITHK1 (FALSEMARGREL1K6)) 'xor'BINARITHK2 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
        using xboolean_th_138 sorry
      also have "... = ('not'MARGREL1K10 d 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'&'MARGREL1K11 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 d)) 'or'BINARITHK1 (?DPI 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d)'&'MARGREL1K11 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
         sorry
      also have "... = ('not'MARGREL1K10 d 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'&'MARGREL1K11 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d) 'or'BINARITHK1 (?DPI 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d)'&'MARGREL1K11 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using xboolean_th_8 sorry
      also have "... = ('not'MARGREL1K10 d 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'&'MARGREL1K11 ((FALSEMARGREL1K6)'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d) 'or'BINARITHK1 (d '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d)'&'MARGREL1K11 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using xboolean_th_138 sorry
      also have "... = (('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d)'&'MARGREL1K11 'not'MARGREL1K10 d 'or'BINARITHK1 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d)'&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'or'BINARITHK1 (?DPI 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d)'&'MARGREL1K11 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using xboolean_th_8 sorry
      also have "... = ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (d '&'MARGREL1K11 'not'MARGREL1K10 d) 'or'BINARITHK1 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d)'&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'or'BINARITHK1 (?DPI 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d)'&'MARGREL1K11 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
         sorry
      also have "... = ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (FALSEMARGREL1K6) 'or'BINARITHK1 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d)'&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'or'BINARITHK1 (?DPI 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d)'&'MARGREL1K11 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using xboolean_th_138 sorry
      also have "... = d '&'MARGREL1K11 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M) 'or'BINARITHK1 (?DPI 'or'BINARITHK1 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d)'&'MARGREL1K11 'not'MARGREL1K10 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
         sorry
      also have "... = d '&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 (z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 (z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d) 'or'BINARITHK1 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d))"
        using xboolean_th_8 sorry
      also have "... = d '&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 ((z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'&'MARGREL1K11 d 'or'BINARITHK1 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 d))"
         sorry
      also have "... = d '&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 (z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d 'or'BINARITHK1 (z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'&'MARGREL1K11 'not'MARGREL1K10 d)"
         sorry
      also have "... = d '&'MARGREL1K11 'not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 (z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M '&'MARGREL1K11 d 'or'BINARITHK1 (FALSEMARGREL1K6)'&'MARGREL1K11 'not'MARGREL1K10 d)"
        using xboolean_th_138 sorry
      also have "... = d '&'MARGREL1K11 ('not'MARGREL1K10 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'or'BINARITHK1 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)"
        using xboolean_th_8 sorry
      also have "... = (TRUEMARGREL1K7)'&'MARGREL1K11 d"
        using xboolean_th_102 sorry
      also have "... = d"
         sorry
      finally have "(Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M =HIDDENR1 d"
         sorry
      obtain k1 k2 where
        [ty]:"k1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" "k2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
        A8: "Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k1,k2 *>"
        using finseq_2_th_100 sorry
      have A9: "(Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 k1 & (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 k2"
        using A8 finseq_4_th_17 sorry
      obtain k where
        [ty]:"k be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
        A10: "z =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>"
        using finseq_2_th_97 sorry
      have "Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 <*FINSEQ-4K2\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k,d *>"
        using A6 A7 A8 A9 A10 finseq_4_th_16 sorry
      thus "Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(\<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
        using A10 finseq_1_def_9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A11: " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ( for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) implies ( for z be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))"
  proof(rule ballI,rule impI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    assume A12: "?P(m)"
    have " for z be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =HIDDENR1 z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
    proof(rule ballI,rule ballI)
      fix z assume [ty]: "z be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5)"
      fix d assume [ty]: "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
      obtain t k where
        [ty]:"t be ElementFINSEQ-2M2\<^bsub>(BOOLEANMARGREL1K5)\<^esub>-of m -tuples-onFINSEQ-2K4 (BOOLEANMARGREL1K5)" "k be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
        A13: "z =FINSEQ-1R1 t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>)"
        using finseq_2_th_117 sorry
      let ?A = "add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m)"
      let ?B = "add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> t),Bin1BINARI-2K1 m)"
      have "Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>))) =HIDDENR1 Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Neg2BINARI-2K2\<^bsub>(m)\<^esub> t)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m)) *>))"
        using binari_2_th_14 sorry
      also have "... = (Neg2BINARI-2K2\<^bsub>(m)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> t))^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 ('not'MARGREL1K10 k 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m))) 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> t),Bin1BINARI-2K1 m)) *>)"
        using binari_2_th_14 sorry
      finally have "Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>))) =HIDDENR1 (Neg2BINARI-2K2\<^bsub>(m)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> t))^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 ('not'MARGREL1K10 k 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m))) 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> t),Bin1BINARI-2K1 m)) *>)"
         sorry
      then have A14: "(Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>))))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 'not'MARGREL1K10 ('not'MARGREL1K10 k 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m))) 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> t),Bin1BINARI-2K1 m))"
        using binarith_th_2 sorry
      have A15: "(t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 k"
        using binarith_th_2 sorry
      obtain p q where 
        [ty]:"p be booleanMARGREL1V2\<bar>objectHIDDENM1" and pDef:"p = k" and
        [ty]:"q be booleanMARGREL1V2\<bar>objectHIDDENM1" and qDef:"q = ?A"
         sorry
      have "'not'MARGREL1K10 ('not'MARGREL1K10 k 'xor'BINARITHK2 ?A) 'xor'BINARITHK2 ?B =HIDDENR1 p '&'MARGREL1K9 ('not'MARGREL1K8 p 'or'XBOOLEANK5 'not'MARGREL1K8 q) 'or'XBOOLEANK5 ('not'MARGREL1K8 p 'or'XBOOLEANK5 'not'MARGREL1K8 q)'&'MARGREL1K9 q 'xor'XBOOLEANK10 ?B"
        using xboolean_th_8 sorry
      also have "... = k '&'MARGREL1K11 'not'MARGREL1K10 ?A 'or'BINARITHK1 ?A '&'MARGREL1K11 ('not'MARGREL1K10 k 'or'BINARITHK1 'not'MARGREL1K10 ?A) 'xor'BINARITHK2 ?B"
        using xboolean_th_11 sorry
      also have "... = (?A 'xor'BINARITHK2 k)'xor'BINARITHK2 ?B"
        using xboolean_th_11 sorry
      also have "... = k 'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B)"
        using xboolean_th_73 sorry
      finally have "'not'MARGREL1K10 ('not'MARGREL1K10 k 'xor'BINARITHK2 ?A) 'xor'BINARITHK2 ?B =HIDDENR1 k 'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B)"
         sorry
      then have A16: "k 'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B) =XBOOLE-0R4 k 'xor'BINARITHK2 (FALSEMARGREL1K6)"
        using A12 A14 A15 sorry
      have A17: "k 'xor'BINARITHK2 (k 'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B)) =HIDDENR1 (k 'xor'BINARITHK2 k)'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B)"
        using xboolean_th_73 sorry
      also have "... = (FALSEMARGREL1K6)'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B)"
        using xboolean_th_138 sorry
      also have "... = ?A 'xor'BINARITHK2 ?B"
         sorry
      finally have "k 'xor'BINARITHK2 (k 'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B)) =HIDDENR1 ?A 'xor'BINARITHK2 ?B"
         sorry
      have A18: "k 'xor'BINARITHK2 (k 'xor'BINARITHK2 (FALSEMARGREL1K6)) =XBOOLE-0R4 FALSEMARGREL1K6"
        using xboolean_th_138 sorry
      have A19: "?A 'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B) =HIDDENR1 (?A 'xor'BINARITHK2 ?A)'xor'BINARITHK2 ?B"
        using xboolean_th_73 sorry
      also have "... = (FALSEMARGREL1K6)'xor'BINARITHK2 ?B"
        using xboolean_th_138 sorry
      also have "... = ?B"
         sorry
      finally have "?A 'xor'BINARITHK2 (?A 'xor'BINARITHK2 ?B) =HIDDENR1 ?B"
         sorry
      have A20: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
        using finseq_1_th_3 sorry
      have A21: "add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))"
        using A13 binari_2_th_9 sorry
      also have "... = add-ovflBINARITHK8\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))"
        using binari_2_th_7 sorry
      also have "... = (('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) 'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_def_6 sorry
      also have "... = (('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (FALSEMARGREL1K6) 'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_2 sorry
      also have "... = ((FALSEMARGREL1K6)'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 (FALSEMARGREL1K6)'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_2 sorry
      also have "... = 'not'MARGREL1K10 k '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_2 sorry
      also have "... = 'not'MARGREL1K10 k '&'MARGREL1K11 ?A"
        using binarith_th_18 sorry
      finally have "add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 'not'MARGREL1K10 k '&'MARGREL1K11 ?A"
         sorry
      have A22: "add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 add-ovflBINARITHK8\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))"
        using binari_2_th_7 sorry
      also have "... = (('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) 'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_def_6 sorry
      also have "... = (('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (FALSEMARGREL1K6) 'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_2 sorry
      also have "... = ((FALSEMARGREL1K6)'or'BINARITHK1 ('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 (FALSEMARGREL1K6)'&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_2 sorry
      also have "... = ('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k*>)) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using A13 binari_2_th_9 sorry
      also have "... = ('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binari_2_th_9 sorry
      also have "... = ('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binari_2_th_7 sorry
      also have "... = ('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binari_2_th_7 sorry
      also have "... = 'not'MARGREL1K10 ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using A20 binarith_def_1 sorry
      also have "... = 'not'MARGREL1K10 ((('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) 'xor'BINARITHK2 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using A20 binarith_def_5 sorry
      also have "... = 'not'MARGREL1K10 (('not'MARGREL1K10 k 'xor'BINARITHK2 ((Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M))'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_2 sorry
      also have "... = 'not'MARGREL1K10 (('not'MARGREL1K10 k 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_2 sorry
      also have "... = 'not'MARGREL1K10 (('not'MARGREL1K10 k 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m))) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 k*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_18 sorry
      also have "... = 'not'MARGREL1K10 ('not'MARGREL1K10 k 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m))) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (('not'BINARITHK3\<^bsub>(m)\<^esub> t +BINARITHK7\<^bsub>(m)\<^esub> Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ('not'MARGREL1K10 k 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m)) *>)),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binarith_th_19 sorry
      also have "... = 'not'MARGREL1K10 ('not'MARGREL1K10 k 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m))) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> ('not'BINARITHK3\<^bsub>(m)\<^esub> t +BINARITHK7\<^bsub>(m)\<^esub> Bin1BINARI-2K1 m) ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 (('not'MARGREL1K10 k 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> t,Bin1BINARI-2K1 m)))*>),(Bin1BINARI-2K1 m)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)"
        using binari_2_th_9 sorry
      also have "... = (('not'MARGREL1K10 k 'or'BINARITHK1 'not'MARGREL1K10 ?A)'&'MARGREL1K11 (k 'or'BINARITHK1 'not'MARGREL1K10 ('not'MARGREL1K10 ?A)))'&'MARGREL1K11 ?A"
        using A16 A17 A18 A19 binarith_th_18 sorry
      also have "... = ('not'MARGREL1K10 k 'or'BINARITHK1 'not'MARGREL1K10 ?A)'&'MARGREL1K11 (?A '&'MARGREL1K11 (k 'or'BINARITHK1 ?A))"
         sorry
      also have "... = ?A '&'MARGREL1K11 ('not'MARGREL1K10 ?A 'or'BINARITHK1 'not'MARGREL1K10 k)"
        using xboolean_th_6 sorry
      also have "... = ?A '&'MARGREL1K11 'not'MARGREL1K10 k"
        using xboolean_th_11 sorry
      finally have "add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ?A '&'MARGREL1K11 'not'MARGREL1K10 k"
         sorry
      let ?C = "'not'MARGREL1K10 k '&'MARGREL1K11 ?A"
      obtain p q where 
        [ty]:"p be booleanMARGREL1V2\<bar>objectHIDDENM1" and pDef:"p = d" and
        [ty]:"q be booleanMARGREL1V2\<bar>objectHIDDENM1" and qDef:"q = ?C"
         sorry
      have A23: "'not'MARGREL1K10 ('not'MARGREL1K10 d 'xor'BINARITHK2 ?C) 'xor'BINARITHK2 ?C =HIDDENR1 p '&'MARGREL1K9 ('not'MARGREL1K8 p 'or'XBOOLEANK5 'not'MARGREL1K8 q) 'or'XBOOLEANK5 ('not'MARGREL1K8 p 'or'XBOOLEANK5 'not'MARGREL1K8 q)'&'MARGREL1K9 q 'xor'XBOOLEANK10 ?C"
        using xboolean_th_8 sorry
      also have "... = d '&'MARGREL1K11 'not'MARGREL1K10 ?C 'or'BINARITHK1 ?C '&'MARGREL1K11 ('not'MARGREL1K10 d 'or'BINARITHK1 'not'MARGREL1K10 ?C) 'xor'BINARITHK2 ?C"
        using xboolean_th_11 sorry
      also have "... = (?C 'xor'BINARITHK2 d)'xor'BINARITHK2 ?C"
        using xboolean_th_11 sorry
      also have "... = d 'xor'BINARITHK2 (?C 'xor'BINARITHK2 ?C)"
        using xboolean_th_73 sorry
      also have "... = d 'xor'BINARITHK2 (FALSEMARGREL1K6)"
        using xboolean_th_138 sorry
      also have "... = d"
         sorry
      finally have "'not'MARGREL1K10 ('not'MARGREL1K10 d 'xor'BINARITHK2 ?C) 'xor'BINARITHK2 ?C =HIDDENR1 d"
         sorry
      have "Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =HIDDENR1 Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z)^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))) *>))"
        using binari_2_th_14 sorry
      also have "... = (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z))^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 ('not'MARGREL1K10 d 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z,Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)))) 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub> z),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M))) *>)"
        using binari_2_th_14 sorry
      also have "... = z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
        using A12 A13 A21 A22 A23 sorry
      finally show "Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =HIDDENR1 z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
         sorry
    qed "sorry"
    thus " for z be TupleFINSEQ-2M3-of(m +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(m +NAT-1K1 \<one>\<^sub>M,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
       sorry
  qed "sorry"
  show " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))) =FINSEQ-1R1 z ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)"
    using nat_1_sch_10 A1 A11 sorry
qed

mdef binari_2_def_6 (" _ -BINARI-2K6\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func x -BINARI-2K6\<^bsub>(n)\<^esub> y \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
    proof-
      have " ex tVar2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      proof-
        let ?F = "\<lambda>Lamb1. (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1"
        obtain z where
          [ty]:"z be FinSequenceFINSEQ-1M3-of BOOLEANMARGREL1K5" and 
          A1: "lenFINSEQ-1K4 z =XBOOLE-0R4 n"and A2: " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 z implies z .FUNCT-1K1 j =XBOOLE-0R4 ?F(j)"
          using finseq_2_sch_1 sorry
        have A3: "domFINSEQ-1K5 z =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A1 finseq_1_def_3 sorry
        have "z be ElementFINSEQ-2M2\<^bsub>(BOOLEANMARGREL1K5)\<^esub>-of n -tuples-onFINSEQ-2K4 (BOOLEANMARGREL1K5)"
          using A1 finseq_2_th_92 sorry
        then have 
          [ty]:"z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
           sorry
        show " ex tVar2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof(rule bexI[of _ "z"],rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A4: "i inTARSKIR2 SegFINSEQ-1K2 n"
          then have "i inTARSKIR2 domFINSEQ-1K5 z"
            using A1 finseq_1_def_3 sorry
          then have "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 z .FUNCT-1K1 i"
            using partfun1_def_6 sorry
          also have "... = (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A2 A3 A4 sorry
          finally show "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies it1 =HIDDENR1 it2"
    proof-
      have " for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies z1 =HIDDENR1 z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        assume A5: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          and A6: " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        have A7: "lenFINSEQ-1K4 z1 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        have A8: "lenFINSEQ-1K4 z2 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        have A9: "domFINSEQ-1K5 z1 =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A7 finseq_1_def_3 sorry
        have " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 z1 implies z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
        proof(rule ballI,rule impI)
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A10: "j inTARSKIR2 domFINSEQ-1K5 z1"
          have "SegFINSEQ-1K2 n =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 z2)"
            using card_1_def_7 sorry
          then have A11: "j inTARSKIR2 domFINSEQ-1K5 z2"
            using A9 A10 finseq_1_def_3 sorry
          have "z1 .FUNCT-1K1 j =HIDDENR1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A10 partfun1_def_6 sorry
          also have "... = (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(n)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(n)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A5 A9 A10 sorry
          also have "... = z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A6 A9 A10 sorry
          also have "... = z2 .FUNCT-1K1 j"
            using A11 partfun1_def_6 sorry
          finally show "z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
             sorry
        qed "sorry"
        thus "z1 =HIDDENR1 z2"
          using A7 A8 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem binari_2_th_17:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for y be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds x -BINARI-2K6\<^bsub>(m)\<^esub> y =FINSEQ-1R1 x +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> y"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for y be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds x -BINARI-2K6\<^bsub>(m)\<^esub> y =FINSEQ-1R1 x +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> y"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix x assume [ty]: "x be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix y assume [ty]: "y be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    have " for i be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 m implies (x -BINARI-2K6\<^bsub>(m)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (Neg2BINARI-2K2\<^bsub>(m)\<^esub> y)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(m)\<^esub>(x,Neg2BINARI-2K2\<^bsub>(m)\<^esub> y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      using binari_2_def_6 sorry
    thus "x -BINARI-2K6\<^bsub>(m)\<^esub> y =FINSEQ-1R1 x +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> y"
      using binarith_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_18:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =FINSEQ-1R1 (z1 +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ((d1 'xor'BINARITHK2 'not'MARGREL1K10 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)) *>)"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =HIDDENR1 (z1 +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ((d1 'xor'BINARITHK2 'not'MARGREL1K10 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)) *>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    have "z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =HIDDENR1 z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
      using binari_2_th_17 sorry
    also have "... = z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)"
      using binari_2_th_14 sorry
    also have "... = (z1 +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 ('not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m))))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)) *>)"
      using binarith_th_19 sorry
    also have "... = (z1 +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ((d1 'xor'BINARITHK2 'not'MARGREL1K10 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)) *>)"
      using xboolean_th_73 sorry
    finally show "z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =HIDDENR1 (z1 +BINARITHK7\<^bsub>(m)\<^esub> Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ((d1 'xor'BINARITHK2 'not'MARGREL1K10 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)))'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>(z1,Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)) *>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binari_2_th_19:
" for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) -XCMPLX-0K6 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
proof-
  have " for m be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) -XCMPLX-0K6 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(m,BOOLEANMARGREL1K5)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    let ?OV1 = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
    let ?UD1 = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
    let ?OV2 = "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
    let ?NEG = "(Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)"
    have "((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_17 sorry
    also have "... = ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_14 sorry
    also have "... = ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),(Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_14 sorry
    also have "... = ((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),(Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),(Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_14 sorry
    also have "... = (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M))"
      using binari_2_th_11 sorry
    also have "... = IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((Neg2BINARI-2K2\<^bsub>(m)\<^esub> z2)^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> 'not'MARGREL1K10 d2 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(m)\<^esub>('not'BINARITHK3\<^bsub>(m)\<^esub> z2,Bin1BINARI-2K1 m)) *>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))"
       sorry
    also have "... = IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 (IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))"
      using binari_2_th_14 sorry
    also have "... = IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) +XCMPLX-0K2 (-XCMPLX-0K4 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))"
      using binari_2_th_15 sorry
    also have "... = IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) -XCMPLX-0K6 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
       sorry
    finally show "((IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) -BINARI-2K6\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)) +XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))-XCMPLX-0K6 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-udflBINARI-2K5\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),Neg2BINARI-2K2\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(Int-add-ovflBINARI-2K4\<^bsub>(m +NAT-1K1 \<one>\<^sub>M)\<^esub>('not'BINARITHK3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)),Bin1BINARI-2K1 (m +NAT-1K1 \<one>\<^sub>M)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z1 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)) -XCMPLX-0K6 IntvalBINARI-2K3\<^bsub>(m +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z2 ^BINARITHK9\<^bsub>(m,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
