theory card_2
  imports ordinal3 nat_1 funct_6 fraenkel
   "../mizar_extension/E_number"
begin
(*begin*)
reserve A, B for "OrdinalORDINAL1M3"
reserve K, M, N for "CardinalCARD-1M1"
reserve x, x1, x2, y, y1, y2, z, u for "objectHIDDENM1"
reserve X, Y, Z, X1, X2, Y1, Y2 for "setHIDDENM2"
reserve f, g for "FunctionFUNCT-1M1"
mtheorem card_2_th_1:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x inHIDDENR3 X & (X,Y)are-equipotentWELLORD2R2 implies Y <>HIDDENR2 {}XBOOLE-0K1 & ( ex x be objectHIDDENM1 st x inHIDDENR3 Y)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x inHIDDENR3 X implies  not ((X,Y)are-equipotentWELLORD2R2 &  not ( not Y <>HIDDENR2 {}XBOOLE-0K1 &  not ( for x be objectHIDDENM1 holds  not x inHIDDENR3 Y)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "x inHIDDENR3 X"
    have "( ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 Y)) implies Y <>HIDDENR2 {}XBOOLE-0K1 & ( ex tVar1 be objectHIDDENM1 st tVar1 inHIDDENR3 Y)"
    proof(rule impI,rule conjMI)
      assume Given: " ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 Y)"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
         sorry
      have "f .FUNCT-1K1 x inTARSKIR2 Y"
        using A1 A2 funct_1_def_3 sorry
      thus "Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      show " ex tVar1 be objectHIDDENM1 st tVar1 inHIDDENR3 Y"
      proof(rule bexI[of _ "f .FUNCT-1K1 x"])
        show "f .FUNCT-1K1 x inHIDDENR3 Y"
          using A1 A2 funct_1_def_3 sorry
      qed "sorry"
    qed
    thus " not ((X,Y)are-equipotentWELLORD2R2 &  not ( not Y <>HIDDENR2 {}XBOOLE-0K1 &  not ( for x be objectHIDDENM1 holds  not x inHIDDENR3 Y)))"
      using wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_2:
" for X be setHIDDENM2 holds (boolZFMISC-1K1 X,boolZFMISC-1K1 (cardCARD-1K1 X))are-equipotentWELLORD2R2 & cardCARD-1K1 (boolZFMISC-1K1 X) =XBOOLE-0R4 cardCARD-1K1 (boolZFMISC-1K1 (cardCARD-1K1 X))"
proof-
  have " for X be setHIDDENM2 holds (boolZFMISC-1K1 X,boolZFMISC-1K1 (cardCARD-1K1 X))are-equipotentWELLORD2R2 & cardCARD-1K1 (boolZFMISC-1K1 X) =XBOOLE-0R4 cardCARD-1K1 (boolZFMISC-1K1 (cardCARD-1K1 X))"
  proof(rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: "rngFUNCT-1K2 f =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_def_2 wellord2_def_4 sorry
    let ?g = "\<lambda>Lamb1. f .:FUNCT-1K5 Lamb1"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A4: "domRELAT-1K1 g =XBOOLE-0R4 boolZFMISC-1K1 X & ( for x be setHIDDENM2 holds x inTARSKIR2 boolZFMISC-1K1 X implies g .FUNCT-1K1 x =XBOOLE-0R4 ?g(x))"
      using funct_1_sch_5 sorry
    show "(boolZFMISC-1K1 X,boolZFMISC-1K1 (cardCARD-1K1 X))are-equipotentWELLORD2R2"
    proof-
      have "g be one-to-oneFUNCT-1V2 & (domRELAT-1K1 g =XBOOLE-0R4 boolZFMISC-1K1 X & proj2XTUPLE-0K13 g =HIDDENR1 boolZFMISC-1K1 (cardCARD-1K1 X))"
      proof(rule conjMI,rule conjMI)
        show "g be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g & (y inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y) implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 g"
              and A6: "y inHIDDENR3 domRELAT-1K1 g"
              and A7: "g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
            obtain xx yy where 
              [ty]:"xx be setHIDDENM2" and xxDef:"xx = x" and
              [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
              using tarski_th_1 sorry
            have A8: "g .FUNCT-1K1 x =XBOOLE-0R4 f .:FUNCT-1K5 xx & g .FUNCT-1K1 y =XBOOLE-0R4 f .:FUNCT-1K5 yy"
              using A4 A5 A6 sorry
            have A9: "yy c=TARSKIR1 xx"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 yy implies z inHIDDENR3 xx"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume A10: "z inHIDDENR3 yy"
                then have "f .FUNCT-1K1 z inTARSKIR2 f .:FUNCT-1K5 yy"
                  using A2 A4 A6 funct_1_def_6 sorry
                then have " ex u be objectHIDDENM1 st (u inHIDDENR3 domRELAT-1K1 f & u inHIDDENR3 xx) & f .FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 u"
                  using A7 A8 funct_1_def_6 sorry
                thus "z inHIDDENR3 xx"
                  using A1 A2 A4 A6 A10 sorry
              qed "sorry"
              thus "yy c=TARSKIR1 xx"
                using tarski_def_3 sorry
            qed
            have "xx c=TARSKIR1 yy"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 xx implies z inHIDDENR3 yy"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume A11: "z inHIDDENR3 xx"
                then have "f .FUNCT-1K1 z inTARSKIR2 f .:FUNCT-1K5 xx"
                  using A2 A4 A5 funct_1_def_6 sorry
                then have " ex u be objectHIDDENM1 st (u inHIDDENR3 domRELAT-1K1 f & u inHIDDENR3 yy) & f .FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 u"
                  using A7 A8 funct_1_def_6 sorry
                thus "z inHIDDENR3 yy"
                  using A1 A2 A4 A5 A11 sorry
              qed "sorry"
              thus "xx c=TARSKIR1 yy"
                using tarski_def_3 sorry
            qed
            thus "x =HIDDENR1 y"
              using A9 xboole_0_def_10 sorry
          qed "sorry"
          thus "g be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 g =XBOOLE-0R4 boolZFMISC-1K1 X"
          using A4 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 boolZFMISC-1K1 (cardCARD-1K1 X) & boolZFMISC-1K1 (cardCARD-1K1 X) c=TARSKIR1 proj2XTUPLE-0K13 g"
        proof(rule conjMI)
          show "rngFUNCT-1K2 g c=TARSKIR1 boolZFMISC-1K1 (cardCARD-1K1 X)"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 boolZFMISC-1K1 (cardCARD-1K1 X)"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 g"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A12: "y inHIDDENR3 domRELAT-1K1 g"and A13: "x =HIDDENR1 g .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have 
                [ty]:"y be setHIDDENM2"
                using tarski_th_1 sorry
              have A14: "f .:FUNCT-1K5 y c=TARSKIR1 rngFUNCT-1K2 f"
                using relat_1_th_111 sorry
              have "g .FUNCT-1K1 y =XBOOLE-0R4 f .:FUNCT-1K5 y"
                using A4 A12 sorry
              thus "x inHIDDENR3 boolZFMISC-1K1 (cardCARD-1K1 X)"
                using A3 A13 A14 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 g c=TARSKIR1 boolZFMISC-1K1 (cardCARD-1K1 X)"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 boolZFMISC-1K1 (cardCARD-1K1 X) implies x inHIDDENR3 proj2XTUPLE-0K13 g"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            obtain xx where 
              [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
              using tarski_th_1 sorry
            have A15: "f \<inverse>FUNCT-1K6 xx c=TARSKIR1 domRELAT-1K1 f"
              using relat_1_th_132 sorry
            assume "x inHIDDENR3 boolZFMISC-1K1 (cardCARD-1K1 X)"
            then have "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 xx =HIDDENR1 x"
              using A3 funct_1_th_77 sorry
            then have "g .FUNCT-1K1 f \<inverse>FUNCT-1K6 xx =HIDDENR1 x"
              using A2 A4 A15 sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 g"
              using A2 A4 A15 funct_1_def_3 sorry
          qed "sorry"
          thus "boolZFMISC-1K1 (cardCARD-1K1 X) c=TARSKIR1 proj2XTUPLE-0K13 g"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 g =HIDDENR1 boolZFMISC-1K1 (cardCARD-1K1 X)"
          using xboole_0_def_10 sorry
      qed
      thus "(boolZFMISC-1K1 X,boolZFMISC-1K1 (cardCARD-1K1 X))are-equipotentWELLORD2R2"
        using bexI[of _ "g"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 (boolZFMISC-1K1 X) =XBOOLE-0R4 cardCARD-1K1 (boolZFMISC-1K1 (cardCARD-1K1 X))"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z inTARSKIR2 FuncsFUNCT-2K1(X,Y) implies (Z,X)are-equipotentWELLORD2R2 & cardCARD-1K1 Z =XBOOLE-0R4 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z inTARSKIR2 FuncsFUNCT-2K1(X,Y) implies (Z,X)are-equipotentWELLORD2R2 & cardCARD-1K1 Z =XBOOLE-0R4 cardCARD-1K1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume "Z inTARSKIR2 FuncsFUNCT-2K1(X,Y)"
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "Z =XBOOLE-0R4 f"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and "rngFUNCT-1K2 f c=TARSKIR1 Y"
      using funct_2_def_2 sorry
    show "(Z,X)are-equipotentWELLORD2R2"
    proof-
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 g =XBOOLE-0R4 Z & ( for x be objectHIDDENM1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =HIDDENR1 x `1XTUPLE-0K1)"
        using funct_1_sch_3 sorry
      have "g be one-to-oneFUNCT-1V2 & (domRELAT-1K1 g =XBOOLE-0R4 Z & proj2XTUPLE-0K13 g =HIDDENR1 X)"
      proof(rule conjMI,rule conjMI)
        show "g be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g & y inHIDDENR3 domRELAT-1K1 g implies  not (g .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 y &  not x =HIDDENR1 y)"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A4: "x inHIDDENR3 domRELAT-1K1 g"
              and A5: "y inHIDDENR3 domRELAT-1K1 g"
            have A6: "g .FUNCT-1K1 x =HIDDENR1 x `1XTUPLE-0K1 & g .FUNCT-1K1 y =HIDDENR1 y `1XTUPLE-0K1"
              using A3 A4 A5 sorry
            have " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st [TARSKIK4 x1,x2 ] =HIDDENR1 y"
              using A1 A3 A5 relat_1_def_1 sorry
            then have A7: "y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
               sorry
            have " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st [TARSKIK4 x1,x2 ] =HIDDENR1 x"
              using A1 A3 A4 relat_1_def_1 sorry
            then have A8: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
               sorry
            then have "x `2XTUPLE-0K2 =HIDDENR1 f .FUNCT-1K1 x `1XTUPLE-0K1"
              using A1 A3 A4 funct_1_th_1 sorry
            thus " not (g .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 y &  not x =HIDDENR1 y)"
              using A1 A3 A5 A8 A7 A6 funct_1_th_1 sorry
          qed "sorry"
          thus "g be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 g =XBOOLE-0R4 Z"
          using A3 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 X & X c=TARSKIR1 proj2XTUPLE-0K13 g"
        proof(rule conjMI)
          show "rngFUNCT-1K2 g c=TARSKIR1 X"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 X"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 g"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A9: "y inHIDDENR3 domRELAT-1K1 g"and A10: "x =HIDDENR1 g .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st [TARSKIK4 x1,x2 ] =HIDDENR1 y"
                using A1 A3 A9 relat_1_def_1 sorry
              then have A11: "y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
                 sorry
              have "x =HIDDENR1 y `1XTUPLE-0K1"
                using A3 A9 A10 sorry
              thus "x inHIDDENR3 X"
                using A1 A2 A3 A9 A11 funct_1_th_1 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 g c=TARSKIR1 X"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 proj2XTUPLE-0K13 g"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            then have A12: "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 Z"
              using A1 A2 funct_1_def_2 sorry
            then have "g .FUNCT-1K1 [TARSKIK4 x,f .FUNCT-1K1 x ] =HIDDENR1 [TARSKIK4 x,f .FUNCT-1K1 x ] `1XTUPLE-0K1"
              using A3 sorry
            also have "... = x"
               sorry
            finally have "g .FUNCT-1K1 [TARSKIK4 x,f .FUNCT-1K1 x ] =HIDDENR1 x"
               sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 g"
              using A3 A12 funct_1_def_3 sorry
          qed "sorry"
          thus "X c=TARSKIR1 proj2XTUPLE-0K13 g"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 g =HIDDENR1 X"
          using xboole_0_def_10 sorry
      qed
      thus "(Z,X)are-equipotentWELLORD2R2"
        using bexI[of _ "g"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 Z =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_2_lm_1:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 <>HIDDENR2 x2 implies (A +^ORDINAL2K10 B,[:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])are-equipotentWELLORD2R2 & cardCARD-1K1 (A +^ORDINAL2K10 B) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 <>HIDDENR2 x2 implies (A +^ORDINAL2K10 B,[:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])are-equipotentWELLORD2R2 & cardCARD-1K1 (A +^ORDINAL2K10 B) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    let ?C = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
    let ?F = "\<lambda>Lamb1. [TARSKIK4 Lamb1,x1 ]"
    let ?G = "\<lambda>Lamb1. [TARSKIK4 Lamb1 -^ORDINAL3K5 A,x2 ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 A +^ORDINAL2K10 B"and A2: " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 A +^ORDINAL2K10 B implies (?C(x) implies f .FUNCT-1K1 x =HIDDENR1 ?F(x)) & ( not ?C(x) implies f .FUNCT-1K1 x =HIDDENR1 ?G(x))"
      using finset_1_sch_1 sorry
    assume A3: "x1 <>HIDDENR2 x2"
    show "(A +^ORDINAL2K10 B,[:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 A +^ORDINAL2K10 B & proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A4: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
              and A5: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            obtain C1 C2 where 
              [ty]:"C1 be OrdinalORDINAL1M3" and C1Def:"C1 = x" and
              [ty]:"C2 be OrdinalORDINAL1M3" and C2Def:"C2 = y"
              using A1 A4 sorry
            show "x =HIDDENR1 y"
            proof-
              have cases: "((x inHIDDENR3 A & y inHIDDENR3 A or  not x inHIDDENR3 A &  not y inHIDDENR3 A) or x inHIDDENR3 A &  not y inHIDDENR3 A) or  not x inHIDDENR3 A & y inHIDDENR3 A"
                 sorry
              have case1: "x inHIDDENR3 A & y inHIDDENR3 A implies x =HIDDENR1 y"
              proof(rule impI)
                assume A6: "x inHIDDENR3 A & y inHIDDENR3 A"
                have A7: "[TARSKIK4 x,x1 ] `1XTUPLE-0K1 =HIDDENR1 C1 & [TARSKIK4 y,x1 ] `1XTUPLE-0K1 =HIDDENR1 C2"
                   sorry
                have "f .FUNCT-1K1 C1 =HIDDENR1 [TARSKIK4 x,x1 ] & f .FUNCT-1K1 C2 =HIDDENR1 [TARSKIK4 y,x1 ]"
                  using A1 A2 A4 A6 sorry
                thus "x =HIDDENR1 y"
                  using A5 A7 sorry
              qed
              have case2: " not x inHIDDENR3 A &  not y inHIDDENR3 A implies x =HIDDENR1 y"
              proof(rule impI)
                assume A8: " not x inHIDDENR3 A &  not y inHIDDENR3 A"
                have A9: "[TARSKIK4 C1 -^ORDINAL3K5 A,x2 ] `1XTUPLE-0K1 =HIDDENR1 C1 -^ORDINAL3K5 A & [TARSKIK4 C2 -^ORDINAL3K5 A,x2 ] `1XTUPLE-0K1 =HIDDENR1 C2 -^ORDINAL3K5 A"
                   sorry
                have "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 C1 -^ORDINAL3K5 A,x2 ] & f .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 C2 -^ORDINAL3K5 A,x2 ]"
                  using A1 A2 A4 A8 sorry
                then have A10: "C1 -^ORDINAL3K5 A =XBOOLE-0R4 C2 -^ORDINAL3K5 A"
                  using A5 A9 sorry
                have "A c=ORDINAL1R1 C1"
                  using A8 ordinal1_th_16 sorry
                then have A11: "C1 =XBOOLE-0R4 A +^ORDINAL2K10 (C1 -^ORDINAL3K5 A)"
                  using ordinal3_def_5 sorry
                have "A c=ORDINAL1R1 C2"
                  using A8 ordinal1_th_16 sorry
                thus "x =HIDDENR1 y"
                  using A10 A11 ordinal3_def_5 sorry
              qed
              have case3: "x inHIDDENR3 A &  not y inHIDDENR3 A implies x =HIDDENR1 y"
              proof(rule impI)
                assume A12: "x inHIDDENR3 A &  not y inHIDDENR3 A"
                have A13: "[TARSKIK4 x,x1 ] `2XTUPLE-0K2 =HIDDENR1 x1 & [TARSKIK4 C2 -^ORDINAL3K5 A,x2 ] `2XTUPLE-0K2 =HIDDENR1 x2"
                   sorry
                have "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,x1 ] & f .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 C2 -^ORDINAL3K5 A,x2 ]"
                  using A1 A2 A4 A12 sorry
                thus "x =HIDDENR1 y"
                  using A3 A5 A13 sorry
              qed
              have case4: " not x inHIDDENR3 A & y inHIDDENR3 A implies x =HIDDENR1 y"
              proof(rule impI)
                assume A14: " not x inHIDDENR3 A & y inHIDDENR3 A"
                have A15: "[TARSKIK4 y,x1 ] `2XTUPLE-0K2 =HIDDENR1 x1 & [TARSKIK4 C1 -^ORDINAL3K5 A,x2 ] `2XTUPLE-0K2 =HIDDENR1 x2"
                   sorry
                have "f .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 y,x1 ] & f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 C1 -^ORDINAL3K5 A,x2 ]"
                  using A1 A2 A4 A14 sorry
                thus "x =HIDDENR1 y"
                  using A3 A5 A15 sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 case4 sorry
            qed
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 A +^ORDINAL2K10 B"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :] & [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :] c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              have A16: "x1 inHIDDENR3 {TARSKIK1 x1}"
                using tarski_def_1 sorry
              have A17: "x2 inHIDDENR3 {TARSKIK1 x2}"
                using tarski_def_1 sorry
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A18: "y inHIDDENR3 domRELAT-1K1 f"and A19: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              obtain C where 
                [ty]:"C be OrdinalORDINAL1M3" and CDef:"C = y"
                using A1 A18 sorry
              show "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
              proof-
                have cases: "y inHIDDENR3 A or  not y inHIDDENR3 A"
                   sorry
                have case1: "y inHIDDENR3 A implies x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
                proof(rule impI)
                  assume "y inHIDDENR3 A"
                  then have "x =HIDDENR1 [TARSKIK4 C,x1 ] & [TARSKIK4 C,x1 ] inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :]"
                    using A1 A2 A18 A19 A16 zfmisc_1_th_87 sorry
                  thus "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
                    using xboole_0_def_3 sorry
                qed
                have case2: " not y inHIDDENR3 A implies x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
                proof(rule impI)
                  assume A20: " not y inHIDDENR3 A"
                  then have "A c=ORDINAL1R1 C"
                    using ordinal1_th_16 sorry
                  then have "A +^ORDINAL2K10 (C -^ORDINAL3K5 A) =XBOOLE-0R4 C"
                    using ordinal3_def_5 sorry
                  then have "C -^ORDINAL3K5 A inTARSKIR2 B"
                    using A1 A18 ordinal3_th_22 sorry
                  then have A21: "[TARSKIK4 C -^ORDINAL3K5 A,x2 ] inHIDDENR3 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
                    using A17 zfmisc_1_th_87 sorry
                  have "x =HIDDENR1 [TARSKIK4 C -^ORDINAL3K5 A,x2 ]"
                    using A1 A2 A18 A19 A20 sorry
                  thus "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
                    using A21 xboole_0_def_3 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A22: "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
            have A23: "x inHIDDENR3 [:ZFMISC-1K2 B,{TARSKIK1 x2} :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
            proof(rule impI)
              assume "x inHIDDENR3 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
              then obtain y z where
                [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
                A24: "y inHIDDENR3 B"and A25: "z inHIDDENR3 {TARSKIK1 x2}"and A26: "x =HIDDENR1 [TARSKIK4 y,z ]"
                using zfmisc_1_th_84 sorry
              have 
                [ty]:"y be OrdinalORDINAL1M3"
                using A24 sorry
              have A27: "A +^ORDINAL2K10 y inTARSKIR2 A +^ORDINAL2K10 B"
                using A24 ordinal2_th_32 sorry
              have A28: " not A +^ORDINAL2K10 y inTARSKIR2 A"
                using ordinal1_th_5 ordinal3_th_24 sorry
              have "(A +^ORDINAL2K10 y)-^ORDINAL3K5 A =XBOOLE-0R4 y & z =HIDDENR1 x2"
                using A25 ordinal3_th_52 tarski_def_1 sorry
              then have "x =HIDDENR1 f .FUNCT-1K1 (A +^ORDINAL2K10 y)"
                using A2 A26 A27 A28 sorry
              thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
                using A1 A27 funct_1_def_3 sorry
            qed
            have "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
            proof(rule impI)
              assume "x inHIDDENR3 [:ZFMISC-1K2 A,{TARSKIK1 x1} :]"
              then obtain y z where
                [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
                A29: "y inHIDDENR3 A"and A30: "z inHIDDENR3 {TARSKIK1 x1}"and A31: "x =HIDDENR1 [TARSKIK4 y,z ]"
                using zfmisc_1_th_84 sorry
              have A32: "A c=ORDINAL1R1 A +^ORDINAL2K10 B"
                using ordinal3_th_24 sorry
              have "z =HIDDENR1 x1"
                using A30 tarski_def_1 sorry
              then have "x =HIDDENR1 f .FUNCT-1K1 y"
                using A2 A29 A31 A32 sorry
              thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
                using A1 A29 A32 funct_1_def_3 sorry
            qed
            thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
              using A22 A23 xboole_0_def_3 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :] c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :]"
          using xboole_0_def_10 sorry
      qed
      thus "(A +^ORDINAL2K10 B,[:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 (A +^ORDINAL2K10 B) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_2_lm_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 Y,X :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y,X :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 Y,X :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y,X :])"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?f = "\<lambda>Lamb1. [TARSKIK4 Lamb1 `2XTUPLE-0K2,Lamb1 `1XTUPLE-0K1 ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies f .FUNCT-1K1 x =HIDDENR1 ?f(x))"
      using funct_1_sch_3 sorry
    show "([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 Y,X :])are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 Y,X :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y)"
          proof(rule ballI,rule ballI,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A2: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
            then have A3: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] & y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
              using A1 mcart_1_th_21 sorry
            assume A4: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            have A5: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] & f .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 y `2XTUPLE-0K2,y `1XTUPLE-0K1 ]"
              using A1 A2 sorry
            then have "x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1"
              using A4 xtuple_0_th_1 sorry
            thus "x =HIDDENR1 y"
              using A3 A5 A4 xtuple_0_th_1 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 Y,X :] & [:ZFMISC-1K2 Y,X :] c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A6: "y inHIDDENR3 domRELAT-1K1 f"and A7: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have A8: "y `2XTUPLE-0K2 inHIDDENR3 Y"
                using A1 A6 mcart_1_th_10 sorry
              have "x =HIDDENR1 [TARSKIK4 y `2XTUPLE-0K2,y `1XTUPLE-0K1 ] & y `1XTUPLE-0K1 inHIDDENR3 X"
                using A1 A6 A7 mcart_1_th_10 sorry
              thus "x inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
                using A8 zfmisc_1_th_87 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 Y,X :]"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Y,X :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            have A9: "[TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] `1XTUPLE-0K1 =HIDDENR1 x `2XTUPLE-0K2 & [TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] `2XTUPLE-0K2 =HIDDENR1 x `1XTUPLE-0K1"
               sorry
            assume A10: "x inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
            then have A11: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have A12: "x `1XTUPLE-0K1 inHIDDENR3 Y & x `2XTUPLE-0K2 inHIDDENR3 X"
              using A10 mcart_1_th_10 sorry
            then have "[TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
              using zfmisc_1_th_87 sorry
            then have "f .FUNCT-1K1 [TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] inTARSKIR2 rngFUNCT-1K2 f"
              using A1 funct_1_def_3 sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
              using A1 A11 A12 A9 zfmisc_1_th_87 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 Y,X :] c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 Y,X :]"
          using xboole_0_def_10 sorry
      qed
      thus "([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 Y,X :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y,X :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_2_def_1 (" _ +`CARD-2K1  _ " [132,132]132 ) where
  mlet "M be CardinalCARD-1M1", "N be CardinalCARD-1M1"
"func M +`CARD-2K1 N \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (M +^ORDINAL2K10 N)"
proof-
  (*coherence*)
    show "cardCARD-1K1 (M +^ORDINAL2K10 N) be CardinalCARD-1M1"
       sorry
qed "sorry"

mtheorem CARD_2K1_commutativity:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M +`CARD-2K1 N =HIDDENR1 N +`CARD-2K1 M"
proof-
  have " for it be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds it =HIDDENR1 M +`CARD-2K1 N implies it =HIDDENR1 N +`CARD-2K1 M"
  proof-
    have " for it be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds it =HIDDENR1 cardCARD-1K1 (M +^ORDINAL2K10 N) implies it =HIDDENR1 cardCARD-1K1 (N +^ORDINAL2K10 M)"
    proof-
      have " for C be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds C =XBOOLE-0R4 cardCARD-1K1 (M +^ORDINAL2K10 N) implies C =HIDDENR1 cardCARD-1K1 (N +^ORDINAL2K10 M)"
      proof(rule ballI,rule ballI,rule ballI,rule impI)
        fix C assume [ty]: "C be CardinalCARD-1M1"
        fix M assume [ty]: "M be CardinalCARD-1M1"
        fix N assume [ty]: "N be CardinalCARD-1M1"
        assume "C =XBOOLE-0R4 cardCARD-1K1 (M +^ORDINAL2K10 N)"
        then have "C =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 N,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])"
          using card_2_lm_1 sorry
        also have "... = cardCARD-1K1 (N +^ORDINAL2K10 M)"
          using card_2_lm_1 sorry
        finally show "C =HIDDENR1 cardCARD-1K1 (N +^ORDINAL2K10 M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using card_2_def_1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef card_2_def_2 (" _ *`CARD-2K2  _ " [164,164]164 ) where
  mlet "M be CardinalCARD-1M1", "N be CardinalCARD-1M1"
"func M *`CARD-2K2 N \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 ([:ZFMISC-1K2 M,N :])"
proof-
  (*coherence*)
    show "cardCARD-1K1 ([:ZFMISC-1K2 M,N :]) be CardinalCARD-1M1"
       sorry
qed "sorry"

mtheorem CARD_2K2_commutativity:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M *`CARD-2K2 N =HIDDENR1 N *`CARD-2K2 M"
proof-
  have " for it be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds it =HIDDENR1 M *`CARD-2K2 N implies it =HIDDENR1 N *`CARD-2K2 M"
  proof-
    have " for it be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds it =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 M,N :]) implies it =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 N,M :])"
      using card_2_lm_2 sorry
    thus " ?thesis "
      using card_2_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef card_2_def_3 ("expCARD-2K3'( _ , _ ')" [0,0]164 ) where
  mlet "M be CardinalCARD-1M1", "N be CardinalCARD-1M1"
"func expCARD-2K3(M,N) \<rightarrow> CardinalCARD-1M1 equals
  cardCARD-1K1 (FuncsFUNCT-2K1(N,M))"
proof-
  (*coherence*)
    show "cardCARD-1K1 (FuncsFUNCT-2K1(N,M)) be CardinalCARD-1M1"
       sorry
qed "sorry"

mtheorem card_2_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 Y,X :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y,X :])"
  using card_2_lm_2 sorry

mtheorem card_2_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ([:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :],[:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ([:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :],[:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    let ?f = "\<lambda>Lamb1. [TARSKIK4 (Lamb1 `1XTUPLE-0K1)`1XTUPLE-0K1,[TARSKIK4 (Lamb1 `1XTUPLE-0K1)`2XTUPLE-0K2,Lamb1 `2XTUPLE-0K2 ] ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :] & ( for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :] implies f .FUNCT-1K1 x =HIDDENR1 ?f(x))"
      using funct_1_sch_3 sorry
    show "([:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :],[:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :] & proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y)"
          proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A2: "x inHIDDENR3 domRELAT-1K1 f"
              and A3: "y inHIDDENR3 domRELAT-1K1 f"
            assume A4: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            have A5: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] & y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
              using A1 A2 A3 mcart_1_th_21 sorry
            have "x `1XTUPLE-0K1 inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
              using A1 A2 mcart_1_th_10 sorry
            then have A6: "x `1XTUPLE-0K1 =HIDDENR1 [TARSKIK4 (x `1XTUPLE-0K1)`1XTUPLE-0K1,(x `1XTUPLE-0K1)`2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have A7: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (x `1XTUPLE-0K1)`1XTUPLE-0K1,[TARSKIK4 (x `1XTUPLE-0K1)`2XTUPLE-0K2,x `2XTUPLE-0K2 ] ] & f .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 (y `1XTUPLE-0K1)`1XTUPLE-0K1,[TARSKIK4 (y `1XTUPLE-0K1)`2XTUPLE-0K2,y `2XTUPLE-0K2 ] ]"
              using A1 A2 A3 sorry
            then have A8: "(x `1XTUPLE-0K1)`1XTUPLE-0K1 =HIDDENR1 (y `1XTUPLE-0K1)`1XTUPLE-0K1"
              using A4 xtuple_0_th_1 sorry
            have "y `1XTUPLE-0K1 inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
              using A1 A3 mcart_1_th_10 sorry
            then have A9: "y `1XTUPLE-0K1 =HIDDENR1 [TARSKIK4 (y `1XTUPLE-0K1)`1XTUPLE-0K1,(y `1XTUPLE-0K1)`2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have A10: "[TARSKIK4 (x `1XTUPLE-0K1)`2XTUPLE-0K2,x `2XTUPLE-0K2 ] =HIDDENR1 [TARSKIK4 (y `1XTUPLE-0K1)`2XTUPLE-0K2,y `2XTUPLE-0K2 ]"
              using A7 A4 xtuple_0_th_1 sorry
            then have "(x `1XTUPLE-0K1)`2XTUPLE-0K2 =HIDDENR1 (y `1XTUPLE-0K1)`2XTUPLE-0K2"
              using xtuple_0_th_1 sorry
            thus "x =HIDDENR1 y"
              using A5 A8 A10 A6 A9 xtuple_0_th_1 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :]"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :] & [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :] c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :]"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :]"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A11: "y inHIDDENR3 domRELAT-1K1 f"and A12: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have A13: "y `1XTUPLE-0K1 inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
                using A1 A11 mcart_1_th_10 sorry
              then have A14: "(y `1XTUPLE-0K1)`2XTUPLE-0K2 inHIDDENR3 Y"
                using mcart_1_th_10 sorry
              have "y `2XTUPLE-0K2 inHIDDENR3 Z"
                using A1 A11 mcart_1_th_10 sorry
              then have A15: "[TARSKIK4 (y `1XTUPLE-0K1)`2XTUPLE-0K2,y `2XTUPLE-0K2 ] inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
                using A14 zfmisc_1_th_87 sorry
              have A16: "(y `1XTUPLE-0K1)`1XTUPLE-0K1 inHIDDENR3 X"
                using A13 mcart_1_th_10 sorry
              have "x =HIDDENR1 [TARSKIK4 (y `1XTUPLE-0K1)`1XTUPLE-0K1,[TARSKIK4 (y `1XTUPLE-0K1)`2XTUPLE-0K2,y `2XTUPLE-0K2 ] ]"
                using A1 A11 A12 sorry
              thus "x inHIDDENR3 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :]"
                using A16 A15 zfmisc_1_th_87 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :]"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            have A17: "[TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ] `1XTUPLE-0K1 =HIDDENR1 x `1XTUPLE-0K1 & [TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ] `2XTUPLE-0K2 =HIDDENR1 (x `2XTUPLE-0K2)`1XTUPLE-0K1"
               sorry
            have A18: "[TARSKIK4 [TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ],(x `2XTUPLE-0K2)`2XTUPLE-0K2 ] `1XTUPLE-0K1 =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ] & [TARSKIK4 [TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ],(x `2XTUPLE-0K2)`2XTUPLE-0K2 ] `2XTUPLE-0K2 =HIDDENR1 (x `2XTUPLE-0K2)`2XTUPLE-0K2"
               sorry
            assume A19: "x inHIDDENR3 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :]"
            then have A20: "x `2XTUPLE-0K2 inHIDDENR3 [:ZFMISC-1K2 Y,Z :]"
              using mcart_1_th_10 sorry
            then have A21: "(x `2XTUPLE-0K2)`1XTUPLE-0K1 inHIDDENR3 Y"
              using mcart_1_th_10 sorry
            have A22: "(x `2XTUPLE-0K2)`2XTUPLE-0K2 inHIDDENR3 Z"
              using A20 mcart_1_th_10 sorry
            have "x `1XTUPLE-0K1 inHIDDENR3 X"
              using A19 mcart_1_th_10 sorry
            then have A23: "[TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
              using A21 zfmisc_1_th_87 sorry
            then have A24: "[TARSKIK4 [TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ],(x `2XTUPLE-0K2)`2XTUPLE-0K2 ] inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :]"
              using A22 zfmisc_1_th_87 sorry
            have A25: "x `2XTUPLE-0K2 =HIDDENR1 [TARSKIK4 (x `2XTUPLE-0K2)`1XTUPLE-0K1,(x `2XTUPLE-0K2)`2XTUPLE-0K2 ]"
              using A20 mcart_1_th_21 sorry
            have "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
              using A19 mcart_1_th_21 sorry
            then have "x =HIDDENR1 f .FUNCT-1K1 [TARSKIK4 [TARSKIK4 x `1XTUPLE-0K1,(x `2XTUPLE-0K2)`1XTUPLE-0K1 ],(x `2XTUPLE-0K2)`2XTUPLE-0K2 ]"
              using A1 A25 A17 A23 A18 A22 zfmisc_1_th_87 sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
              using A1 A24 funct_1_def_3 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :] c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :]"
          using xboole_0_def_10 sorry
      qed
      thus "([:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :],[:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 X,Y :],Z :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,[:ZFMISC-1K2 Y,Z :] :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_2_lm_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,Y :])are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,Y :])are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: "rngFUNCT-1K2 f =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_def_2 wellord2_def_4 sorry
    let ?g = "\<lambda>Lamb1. [TARSKIK4 f .FUNCT-1K1 Lamb1 `1XTUPLE-0K1,Lamb1 `2XTUPLE-0K2 ]"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A4: "domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & ( for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies g .FUNCT-1K1 x =HIDDENR1 ?g(x))"
      using funct_1_sch_3 sorry
    have "g be one-to-oneFUNCT-1V2 & (domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] & proj2XTUPLE-0K13 g =HIDDENR1 [:ZFMISC-1K2 cardCARD-1K1 X,Y :])"
    proof(rule conjMI,rule conjMI)
      show "g be one-to-oneFUNCT-1V2"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g & y inHIDDENR3 domRELAT-1K1 g implies (g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y implies x =HIDDENR1 y)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 g & y inHIDDENR3 domRELAT-1K1 g"
          then have A6: "x `1XTUPLE-0K1 inHIDDENR3 X & y `1XTUPLE-0K1 inHIDDENR3 X"
            using A4 mcart_1_th_10 sorry
          assume A7: "g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
          have "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] & g .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
            using A4 A5 sorry
          then have A8: "f .FUNCT-1K1 x `1XTUPLE-0K1 =XBOOLE-0R4 f .FUNCT-1K1 y `1XTUPLE-0K1 & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2"
            using A7 xtuple_0_th_1 sorry
          have "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] & y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
            using A4 A5 mcart_1_th_21 sorry
          thus "x =HIDDENR1 y"
            using A1 A2 A6 A8 sorry
        qed "sorry"
        thus "g be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      show "domRELAT-1K1 g =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
        using A4 sorry
      have "rngFUNCT-1K2 g c=TARSKIR1 [:ZFMISC-1K2 cardCARD-1K1 X,Y :] & [:ZFMISC-1K2 cardCARD-1K1 X,Y :] c=TARSKIR1 proj2XTUPLE-0K13 g"
      proof(rule conjMI)
        show "rngFUNCT-1K2 g c=TARSKIR1 [:ZFMISC-1K2 cardCARD-1K1 X,Y :]"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 [:ZFMISC-1K2 cardCARD-1K1 X,Y :]"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 g"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A9: "x inHIDDENR3 domRELAT-1K1 g"and A10: "y =HIDDENR1 g .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have "x `1XTUPLE-0K1 inHIDDENR3 X"
              using A4 A9 mcart_1_th_10 sorry
            then have A11: "f .FUNCT-1K1 x `1XTUPLE-0K1 inTARSKIR2 cardCARD-1K1 X"
              using A2 A3 funct_1_def_3 sorry
            have "y =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] & x `2XTUPLE-0K2 inHIDDENR3 Y"
              using A4 A9 A10 mcart_1_th_10 sorry
            thus "y inHIDDENR3 [:ZFMISC-1K2 cardCARD-1K1 X,Y :]"
              using A11 zfmisc_1_th_87 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 g c=TARSKIR1 [:ZFMISC-1K2 cardCARD-1K1 X,Y :]"
            using tarski_def_3 sorry
        qed
        have " for y be objectHIDDENM1 holds y inHIDDENR3 [:ZFMISC-1K2 cardCARD-1K1 X,Y :] implies y inHIDDENR3 proj2XTUPLE-0K13 g"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A12: "y inHIDDENR3 [:ZFMISC-1K2 cardCARD-1K1 X,Y :]"
          then have "y `1XTUPLE-0K1 inHIDDENR3 cardCARD-1K1 X"
            using mcart_1_th_10 sorry
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A13: "x inHIDDENR3 X"and A14: "y `1XTUPLE-0K1 =HIDDENR1 f .FUNCT-1K1 x"
            using A2 A3 funct_1_def_3 sorry
          have A15: "y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
            using A12 mcart_1_th_21 sorry
          have A16: "y `2XTUPLE-0K2 inHIDDENR3 Y"
            using A12 mcart_1_th_10 sorry
          then have A17: "[TARSKIK4 x,y `2XTUPLE-0K2 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
            using A13 zfmisc_1_th_87 sorry
          have "[TARSKIK4 x,y `2XTUPLE-0K2 ] `1XTUPLE-0K1 =HIDDENR1 x & [TARSKIK4 x,y `2XTUPLE-0K2 ] `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2"
             sorry
          then have "g .FUNCT-1K1 [TARSKIK4 x,y `2XTUPLE-0K2 ] =HIDDENR1 y"
            using A4 A15 A14 A16 A13 zfmisc_1_th_87 sorry
          thus "y inHIDDENR3 proj2XTUPLE-0K13 g"
            using A4 A17 funct_1_def_3 sorry
        qed "sorry"
        thus "[:ZFMISC-1K2 cardCARD-1K1 X,Y :] c=TARSKIR1 proj2XTUPLE-0K13 g"
          using tarski_def_3 sorry
      qed
      thus "proj2XTUPLE-0K13 g =HIDDENR1 [:ZFMISC-1K2 cardCARD-1K1 X,Y :]"
        using xboole_0_def_10 sorry
    qed
    thus "([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,Y :])are-equipotentWELLORD2R2"
      using bexI[of _ "g"] wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem card_2_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ((((([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,Y :])are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2) & ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2) & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,Y :])) & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,cardCARD-1K1 Y :])) & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,Y :])are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2) & (([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2 & ((cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,Y :]) & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,cardCARD-1K1 Y :])) & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :])))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "([:ZFMISC-1K2 Y,X :],[:ZFMISC-1K2 cardCARD-1K1 Y,X :])are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 Y,X :])are-equipotentWELLORD2R2"
      using card_2_lm_2 card_2_lm_3 sorry
    then have A1: "([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 Y,X :])are-equipotentWELLORD2R2"
      using wellord2_th_15 sorry
    have A2: "([:ZFMISC-1K2 cardCARD-1K1 Y,X :],[:ZFMISC-1K2 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2"
      using card_2_lm_2 sorry
    thus A3: "([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,Y :])are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2"
      using A1 card_2_lm_3 wellord2_th_15 sorry
    have "([:ZFMISC-1K2 X,cardCARD-1K1 Y :],[:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2"
      using card_2_lm_3 sorry
    thus "([:ZFMISC-1K2 X,Y :],[:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :])are-equipotentWELLORD2R2"
      using A3 wellord2_th_15 sorry
    thus "(cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,Y :]) & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,cardCARD-1K1 Y :])) & cardCARD-1K1 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,cardCARD-1K1 Y :])"
      using A2 A1 card_2_lm_3 card_1_th_5 wellord2_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_8:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (X1,Y1)are-equipotentWELLORD2R2 & (X2,Y2)are-equipotentWELLORD2R2 implies ([:ZFMISC-1K2 X1,X2 :],[:ZFMISC-1K2 Y1,Y2 :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X1,X2 :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y1,Y2 :])"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (X1,Y1)are-equipotentWELLORD2R2 & (X2,Y2)are-equipotentWELLORD2R2 implies ([:ZFMISC-1K2 X1,X2 :],[:ZFMISC-1K2 Y1,Y2 :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X1,X2 :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y1,Y2 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume "(X1,Y1)are-equipotentWELLORD2R2 & (X2,Y2)are-equipotentWELLORD2R2"
    then have A1: "cardCARD-1K1 X1 =XBOOLE-0R4 cardCARD-1K1 Y1 & cardCARD-1K1 X2 =XBOOLE-0R4 cardCARD-1K1 Y2"
      using card_1_th_5 sorry
    have "([:ZFMISC-1K2 X1,X2 :],[:ZFMISC-1K2 cardCARD-1K1 X1,cardCARD-1K1 X2 :])are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 Y1,Y2 :],[:ZFMISC-1K2 cardCARD-1K1 Y1,cardCARD-1K1 Y2 :])are-equipotentWELLORD2R2"
      using card_2_th_7 sorry
    thus "([:ZFMISC-1K2 X1,X2 :],[:ZFMISC-1K2 Y1,Y2 :])are-equipotentWELLORD2R2"
      using A1 wellord2_th_15 sorry
    thus "cardCARD-1K1 ([:ZFMISC-1K2 X1,X2 :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y1,Y2 :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_9:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 <>HIDDENR2 x2 implies (A +^ORDINAL2K10 B,[:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])are-equipotentWELLORD2R2 & cardCARD-1K1 (A +^ORDINAL2K10 B) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 A,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 x2} :])"
  using card_2_lm_1 sorry

mtheorem card_2_th_10:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 <>HIDDENR2 x2 implies (K +`CARD-2K1 M,[:ZFMISC-1K2 K,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 x2} :])are-equipotentWELLORD2R2 & K +`CARD-2K1 M =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 K,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 x2} :])"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 <>HIDDENR2 x2 implies (K +`CARD-2K1 M,[:ZFMISC-1K2 K,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 x2} :])are-equipotentWELLORD2R2 & K +`CARD-2K1 M =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 K,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 x2} :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    assume "x1 <>HIDDENR2 x2"
    then have "cardCARD-1K1 ([:ZFMISC-1K2 K,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 x2} :]) =XBOOLE-0R4 K +`CARD-2K1 M"
      using card_2_lm_1 sorry
    thus "(K +`CARD-2K1 M,[:ZFMISC-1K2 K,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 x2} :])are-equipotentWELLORD2R2 & K +`CARD-2K1 M =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 K,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 x2} :])"
      using card_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_11:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A *^ORDINAL2K11 B,[:ZFMISC-1K2 A,B :])are-equipotentWELLORD2R2 & cardCARD-1K1 (A *^ORDINAL2K11 B) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 A,B :])"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A *^ORDINAL2K11 B,[:ZFMISC-1K2 A,B :])are-equipotentWELLORD2R2 & cardCARD-1K1 (A *^ORDINAL2K11 B) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 A,B :])"
  proof(rule ballI,rule ballI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex O1 be OrdinalORDINAL1M3 st  ex O2 be OrdinalORDINAL1M3 st (O1 =HIDDENR1 Lamb1 `1XTUPLE-0K1 & O2 =HIDDENR1 Lamb1 `2XTUPLE-0K2) & Lamb2 =HIDDENR1 O1 *^ORDINAL2K11 B +^ORDINAL2K10 O2"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 A,B :] implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 A,B :] implies ( ex tVar8 be objectHIDDENM1 st  ex tVar9 be OrdinalORDINAL1M3 st  ex tVar10 be OrdinalORDINAL1M3 st (tVar9 =HIDDENR1 x `1XTUPLE-0K1 & tVar10 =HIDDENR1 x `2XTUPLE-0K2) & tVar9 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10 =HIDDENR1 tVar9 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 [:ZFMISC-1K2 A,B :]"
        then have "x `1XTUPLE-0K1 inHIDDENR3 A & x `2XTUPLE-0K2 inHIDDENR3 B"
          using mcart_1_th_10 sorry
        then obtain x1 x2 where 
          [ty]:"x1 be OrdinalORDINAL1M3" and x1Def:"x1 = x `1XTUPLE-0K1" and
          [ty]:"x2 be OrdinalORDINAL1M3" and x2Def:"x2 = x `2XTUPLE-0K2"
           sorry
        show " ex tVar8 be objectHIDDENM1 st  ex tVar9 be OrdinalORDINAL1M3 st  ex tVar10 be OrdinalORDINAL1M3 st (tVar9 =HIDDENR1 x `1XTUPLE-0K1 & tVar10 =HIDDENR1 x `2XTUPLE-0K2) & tVar9 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10 =HIDDENR1 tVar9 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10"
        proof(rule bexI[of _ "x1 *^ORDINAL2K11 B +^ORDINAL2K10 x2"])
          show " ex tVar9 be OrdinalORDINAL1M3 st  ex tVar10 be OrdinalORDINAL1M3 st (tVar9 =HIDDENR1 x `1XTUPLE-0K1 & tVar10 =HIDDENR1 x `2XTUPLE-0K2) & tVar9 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10 =HIDDENR1 tVar9 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10"
          proof(rule bexI[of _ "x1"])
            show " ex tVar10 be OrdinalORDINAL1M3 st (x1 =HIDDENR1 x `1XTUPLE-0K1 & tVar10 =HIDDENR1 x `2XTUPLE-0K2) & x1 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10 =HIDDENR1 x1 *^ORDINAL2K11 B +^ORDINAL2K10 tVar10"
            proof(rule bexI[of _ "x2"])
              show "(x1 =HIDDENR1 x `1XTUPLE-0K1 & x2 =HIDDENR1 x `2XTUPLE-0K2) & x1 *^ORDINAL2K11 B +^ORDINAL2K10 x2 =HIDDENR1 x1 *^ORDINAL2K11 B +^ORDINAL2K10 x2"
                 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A2: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 A,B :] & ( for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 A,B :] implies ?P(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A1 sorry
    have A3: "([:ZFMISC-1K2 A,B :],A *^ORDINAL2K11 B)are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 A,B :] & proj2XTUPLE-0K13 f =HIDDENR1 A *^ORDINAL2K11 B)"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y)"
          proof(rule ballI,rule ballI,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A4: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
            then have A5: "x `2XTUPLE-0K2 inHIDDENR3 B & y `2XTUPLE-0K2 inHIDDENR3 B"
              using A2 mcart_1_th_10 sorry
            have "x `1XTUPLE-0K1 inHIDDENR3 A & y `1XTUPLE-0K1 inHIDDENR3 A"
              using A2 A4 mcart_1_th_10 sorry
            then obtain x1 y1 where 
              [ty]:"x1 be OrdinalORDINAL1M3" and x1Def:"x1 = x `1XTUPLE-0K1" and
              [ty]:"y1 be OrdinalORDINAL1M3" and y1Def:"y1 = y `1XTUPLE-0K1"
               sorry
            assume A6: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
            have A7: "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] & y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
              using A2 A4 mcart_1_th_21 sorry
            have A8: "( ex O1 be OrdinalORDINAL1M3 st  ex O2 be OrdinalORDINAL1M3 st (O1 =HIDDENR1 x `1XTUPLE-0K1 & O2 =HIDDENR1 x `2XTUPLE-0K2) & f .FUNCT-1K1 x =XBOOLE-0R4 O1 *^ORDINAL2K11 B +^ORDINAL2K10 O2) & ( ex O3 be OrdinalORDINAL1M3 st  ex O4 be OrdinalORDINAL1M3 st (O3 =HIDDENR1 y `1XTUPLE-0K1 & O4 =HIDDENR1 y `2XTUPLE-0K2) & f .FUNCT-1K1 y =XBOOLE-0R4 O3 *^ORDINAL2K11 B +^ORDINAL2K10 O4)"
              using A2 A4 sorry
            then have "x1 =XBOOLE-0R4 y1"
              using A5 A6 ordinal3_th_48 sorry
            thus "x =HIDDENR1 y"
              using A7 A5 A8 A6 ordinal3_th_48 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"
          using A2 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 A *^ORDINAL2K11 B & A *^ORDINAL2K11 B c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 A *^ORDINAL2K11 B"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 A *^ORDINAL2K11 B"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              have A9: "\<one>\<^sub>M *^ORDINAL2K11 B =XBOOLE-0R4 B"
                using ordinal2_th_39 sorry
              assume "y inHIDDENR3 rngFUNCT-1K2 f"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A10: "x inHIDDENR3 domRELAT-1K1 f"and A11: "y =HIDDENR1 f .FUNCT-1K1 x"
                using funct_1_def_3 sorry
              obtain x1 x2 where
                [ty]:"x1 be OrdinalORDINAL1M3" "x2 be OrdinalORDINAL1M3" and 
                A12: "x1 =HIDDENR1 x `1XTUPLE-0K1"and A13: "x2 =HIDDENR1 x `2XTUPLE-0K2 & f .FUNCT-1K1 x =XBOOLE-0R4 x1 *^ORDINAL2K11 B +^ORDINAL2K10 x2"
                using A2 A10 sorry
              have "x1 +^ORDINAL2K10 \<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 x1"
                using ordinal2_th_31 sorry
              then have A14: "x1 *^ORDINAL2K11 B +^ORDINAL2K10 \<one>\<^sub>M *^ORDINAL2K11 B =XBOOLE-0R4 succORDINAL1K1 x1 *^ORDINAL2K11 B"
                using ordinal3_th_46 sorry
              have "succORDINAL1K1 x1 c=ORDINAL1R1 A"
                using A12 A2 A10 mcart_1_th_10 ordinal1_th_21 sorry
              then have A15: "x1 *^ORDINAL2K11 B +^ORDINAL2K10 \<one>\<^sub>M *^ORDINAL2K11 B c=ORDINAL1R1 A *^ORDINAL2K11 B"
                using A14 ordinal2_th_41 sorry
              have "y inHIDDENR3 x1 *^ORDINAL2K11 B +^ORDINAL2K10 \<one>\<^sub>M *^ORDINAL2K11 B"
                using A11 A13 A9 A2 A10 mcart_1_th_10 ordinal2_th_32 sorry
              thus "y inHIDDENR3 A *^ORDINAL2K11 B"
                using A15 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 A *^ORDINAL2K11 B"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 A *^ORDINAL2K11 B implies y inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A16: "y inHIDDENR3 A *^ORDINAL2K11 B"
            then obtain C where 
              [ty]:"C be OrdinalORDINAL1M3" and CDef:"C = y"
               sorry
            have A17: "C =XBOOLE-0R4 (C div^ORDINAL3K6 B)*^ORDINAL2K11 B +^ORDINAL2K10 (C mod^ORDINAL3K7 B) & [TARSKIK4 C div^ORDINAL3K6 B,C mod^ORDINAL3K7 B ] `1XTUPLE-0K1 =HIDDENR1 C div^ORDINAL3K6 B"
              using ordinal3_th_65 sorry
            have "C div^ORDINAL3K6 B inTARSKIR2 A & C mod^ORDINAL3K7 B inTARSKIR2 B"
              using A16 ordinal3_th_67 sorry
            then have A18: "[TARSKIK4 C div^ORDINAL3K6 B,C mod^ORDINAL3K7 B ] inHIDDENR3 [:ZFMISC-1K2 A,B :]"
              using zfmisc_1_th_87 sorry
            then have "[TARSKIK4 C div^ORDINAL3K6 B,C mod^ORDINAL3K7 B ] `2XTUPLE-0K2 =HIDDENR1 C mod^ORDINAL3K7 B & ( ex O1 be OrdinalORDINAL1M3 st  ex O2 be OrdinalORDINAL1M3 st (O1 =HIDDENR1 [TARSKIK4 C div^ORDINAL3K6 B,C mod^ORDINAL3K7 B ] `1XTUPLE-0K1 & O2 =HIDDENR1 [TARSKIK4 C div^ORDINAL3K6 B,C mod^ORDINAL3K7 B ] `2XTUPLE-0K2) & f .FUNCT-1K1 [TARSKIK4 C div^ORDINAL3K6 B,C mod^ORDINAL3K7 B ] =XBOOLE-0R4 O1 *^ORDINAL2K11 B +^ORDINAL2K10 O2)"
              using A2 sorry
            thus "y inHIDDENR3 proj2XTUPLE-0K13 f"
              using A2 A18 A17 funct_1_def_3 sorry
          qed "sorry"
          thus "A *^ORDINAL2K11 B c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 A *^ORDINAL2K11 B"
          using xboole_0_def_10 sorry
      qed
      thus "([:ZFMISC-1K2 A,B :],A *^ORDINAL2K11 B)are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "(A *^ORDINAL2K11 B,[:ZFMISC-1K2 A,B :])are-equipotentWELLORD2R2"
       sorry
    show "cardCARD-1K1 (A *^ORDINAL2K11 B) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 A,B :])"
      using A3 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_12:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (((X1,Y1)are-equipotentWELLORD2R2 & (X2,Y2)are-equipotentWELLORD2R2) & x1 <>HIDDENR2 x2) & y1 <>HIDDENR2 y2 implies ([:ZFMISC-1K2 X1,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :],[:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X1,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :])"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds (X1,Y1)are-equipotentWELLORD2R2 & ((X2,Y2)are-equipotentWELLORD2R2 & (x1 <>HIDDENR2 x2 & y1 <>HIDDENR2 y2)) implies ([:ZFMISC-1K2 X1,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :],[:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X1,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "(X1,Y1)are-equipotentWELLORD2R2"
      and A2: "(X2,Y2)are-equipotentWELLORD2R2"
      and A3: "x1 <>HIDDENR2 x2"
      and A4: "y1 <>HIDDENR2 y2"
    have "({TARSKIK1 x2},{TARSKIK1 y2})are-equipotentWELLORD2R2"
      using card_1_th_28 sorry
    then have A5: "([:ZFMISC-1K2 X2,{TARSKIK1 x2} :],[:ZFMISC-1K2 Y2,{TARSKIK1 y2} :])are-equipotentWELLORD2R2"
      using A2 card_2_th_8 sorry
    have A6: "[:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] meetsXBOOLE-0R5 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :] implies  False "
    proof(rule impI)
      assume "[:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] meetsXBOOLE-0R5 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :]"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A7: "y inHIDDENR3 [:ZFMISC-1K2 Y1,{TARSKIK1 y1} :]"and A8: "y inHIDDENR3 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :]"
        using xboole_0_th_3 sorry
      have "y `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y1}"
        using A7 mcart_1_th_10 sorry
      then have A9: "y `2XTUPLE-0K2 =HIDDENR1 y1"
        using tarski_def_1 sorry
      have "y `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y2}"
        using A8 mcart_1_th_10 sorry
      thus " False "
        using A4 A9 tarski_def_1 sorry
    qed
    have A10: "[:ZFMISC-1K2 X1,{TARSKIK1 x1} :] meetsXBOOLE-0R5 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :] implies  False "
    proof(rule impI)
      assume "[:ZFMISC-1K2 X1,{TARSKIK1 x1} :] meetsXBOOLE-0R5 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :]"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A11: "x inHIDDENR3 [:ZFMISC-1K2 X1,{TARSKIK1 x1} :]"and A12: "x inHIDDENR3 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :]"
        using xboole_0_th_3 sorry
      have "x `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 x1}"
        using A11 mcart_1_th_10 sorry
      then have A13: "x `2XTUPLE-0K2 =HIDDENR1 x1"
        using tarski_def_1 sorry
      have "x `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 x2}"
        using A12 mcart_1_th_10 sorry
      thus " False "
        using A3 A13 tarski_def_1 sorry
    qed
    have "({TARSKIK1 x1},{TARSKIK1 y1})are-equipotentWELLORD2R2"
      using card_1_th_28 sorry
    then have "([:ZFMISC-1K2 X1,{TARSKIK1 x1} :],[:ZFMISC-1K2 Y1,{TARSKIK1 y1} :])are-equipotentWELLORD2R2"
      using A1 card_2_th_8 sorry
    thus "([:ZFMISC-1K2 X1,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :],[:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :])are-equipotentWELLORD2R2"
      using A5 A10 A6 card_1_th_31 sorry
    thus "cardCARD-1K1 ([:ZFMISC-1K2 X1,{TARSKIK1 x1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X2,{TARSKIK1 x2} :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y1,{TARSKIK1 y1} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,{TARSKIK1 y2} :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_13:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds cardCARD-1K1 (A +^ORDINAL2K10 B) =XBOOLE-0R4 cardCARD-1K1 A +`CARD-2K1 cardCARD-1K1 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds cardCARD-1K1 (A +^ORDINAL2K10 B) =XBOOLE-0R4 cardCARD-1K1 A +`CARD-2K1 cardCARD-1K1 B"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have A1: "(A +^ORDINAL2K10 B,[:ZFMISC-1K2 A,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_2_lm_1 sorry
    have "(A,cardCARD-1K1 A)are-equipotentWELLORD2R2 & (B,cardCARD-1K1 B)are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    then have A2: "([:ZFMISC-1K2 A,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 cardCARD-1K1 A,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 cardCARD-1K1 B,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_2_th_12 sorry
    have "([:ZFMISC-1K2 cardCARD-1K1 A,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 cardCARD-1K1 B,{TARSKIK1 \<one>\<^sub>M} :],cardCARD-1K1 A +^ORDINAL2K10 cardCARD-1K1 B)are-equipotentWELLORD2R2"
      using card_2_lm_1 sorry
    then have "([:ZFMISC-1K2 A,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 B,{TARSKIK1 \<one>\<^sub>M} :],cardCARD-1K1 A +^ORDINAL2K10 cardCARD-1K1 B)are-equipotentWELLORD2R2"
      using A2 wellord2_th_15 sorry
    then have "(A +^ORDINAL2K10 B,cardCARD-1K1 A +^ORDINAL2K10 cardCARD-1K1 B)are-equipotentWELLORD2R2"
      using A1 wellord2_th_15 sorry
    thus "cardCARD-1K1 (A +^ORDINAL2K10 B) =XBOOLE-0R4 cardCARD-1K1 A +`CARD-2K1 cardCARD-1K1 B"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_14:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds cardCARD-1K1 (A *^ORDINAL2K11 B) =XBOOLE-0R4 cardCARD-1K1 A *`CARD-2K2 cardCARD-1K1 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds cardCARD-1K1 (A *^ORDINAL2K11 B) =HIDDENR1 cardCARD-1K1 A *`CARD-2K2 cardCARD-1K1 B"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "cardCARD-1K1 (A *^ORDINAL2K11 B) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 A,B :])"
      using card_2_th_11 sorry
    also have "... = cardCARD-1K1 A *`CARD-2K2 cardCARD-1K1 B"
      using card_2_th_7 sorry
    finally show "cardCARD-1K1 (A *^ORDINAL2K11 B) =HIDDENR1 cardCARD-1K1 A *`CARD-2K2 cardCARD-1K1 B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_15:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ([:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 Y,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 Y,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 X,{TARSKIK1 \<one>\<^sub>M} :])"
  using card_2_th_12 sorry

mtheorem card_2_th_16:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds ([:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :],[:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds ([:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :],[:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])are-equipotentWELLORD2R2 & cardCARD-1K1 ([:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    let ?f = "\<lambda>Lamb1. [TARSKIK4 Lamb1 `2XTUPLE-0K2,Lamb1 `1XTUPLE-0K1 ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :] & ( for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :] implies f .FUNCT-1K1 x =HIDDENR1 ?f(x))"
      using funct_1_sch_3 sorry
    show "([:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :],[:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :] & proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            assume A2: "x1 inHIDDENR3 domRELAT-1K1 f"
              and A3: "x2 inHIDDENR3 domRELAT-1K1 f"
              and A4: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
            have "x1 inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] or x1 inHIDDENR3 [:ZFMISC-1K2 Y1,Y2 :]"
              using A1 A2 xboole_0_def_3 sorry
            then have A5: "x1 =HIDDENR1 [TARSKIK4 x1 `1XTUPLE-0K1,x1 `2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have "x2 inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] or x2 inHIDDENR3 [:ZFMISC-1K2 Y1,Y2 :]"
              using A1 A3 xboole_0_def_3 sorry
            then have A6: "x2 =HIDDENR1 [TARSKIK4 x2 `1XTUPLE-0K1,x2 `2XTUPLE-0K2 ]"
              using mcart_1_th_21 sorry
            have A7: "f .FUNCT-1K1 x1 =HIDDENR1 [TARSKIK4 x1 `2XTUPLE-0K2,x1 `1XTUPLE-0K1 ] & f .FUNCT-1K1 x2 =HIDDENR1 [TARSKIK4 x2 `2XTUPLE-0K2,x2 `1XTUPLE-0K1 ]"
              using A1 A2 A3 sorry
            then have "x1 `1XTUPLE-0K1 =HIDDENR1 x2 `1XTUPLE-0K1"
              using A4 xtuple_0_th_1 sorry
            thus "x1 =HIDDENR1 x2"
              using A4 A7 A5 A6 xtuple_0_th_1 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :]"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :] & [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :] c=TARSKIR1 proj2XTUPLE-0K13 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :]"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :]"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 f"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A8: "y inHIDDENR3 domRELAT-1K1 f"and A9: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have "y inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] or y inHIDDENR3 [:ZFMISC-1K2 Y1,Y2 :]"
                using A1 A8 xboole_0_def_3 sorry
              then have A10: "y `1XTUPLE-0K1 inHIDDENR3 X1 & y `2XTUPLE-0K2 inHIDDENR3 X2 or y `1XTUPLE-0K1 inHIDDENR3 Y1 & y `2XTUPLE-0K2 inHIDDENR3 Y2"
                using mcart_1_th_10 sorry
              have "x =HIDDENR1 [TARSKIK4 y `2XTUPLE-0K2,y `1XTUPLE-0K1 ]"
                using A1 A8 A9 sorry
              then have "x inHIDDENR3 [:ZFMISC-1K2 X2,X1 :] or x inHIDDENR3 [:ZFMISC-1K2 Y2,Y1 :]"
                using A10 zfmisc_1_th_87 sorry
              thus "x inHIDDENR3 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :]"
                using xboole_0_def_3 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :]"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :] implies x inHIDDENR3 proj2XTUPLE-0K13 f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            have A11: "[TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] `1XTUPLE-0K1 =HIDDENR1 x `2XTUPLE-0K2 & [TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] `2XTUPLE-0K2 =HIDDENR1 x `1XTUPLE-0K1"
               sorry
            assume "x inHIDDENR3 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :]"
            then have A12: "x inHIDDENR3 [:ZFMISC-1K2 X2,X1 :] or x inHIDDENR3 [:ZFMISC-1K2 Y2,Y1 :]"
              using xboole_0_def_3 sorry
            then have "x `1XTUPLE-0K1 inHIDDENR3 X2 & x `2XTUPLE-0K2 inHIDDENR3 X1 or x `1XTUPLE-0K1 inHIDDENR3 Y2 & x `2XTUPLE-0K2 inHIDDENR3 Y1"
              using mcart_1_th_10 sorry
            then have "[TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] or [TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] inHIDDENR3 [:ZFMISC-1K2 Y1,Y2 :]"
              using zfmisc_1_th_87 sorry
            then have A13: "[TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :]"
              using xboole_0_def_3 sorry
            have "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
              using A12 mcart_1_th_21 sorry
            then have "f .FUNCT-1K1 [TARSKIK4 x `2XTUPLE-0K2,x `1XTUPLE-0K1 ] =HIDDENR1 x"
              using A1 A13 A11 sorry
            thus "x inHIDDENR3 proj2XTUPLE-0K13 f"
              using A1 A13 funct_1_def_3 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :] c=TARSKIR1 proj2XTUPLE-0K13 f"
            using tarski_def_3 sorry
        qed
        thus "proj2XTUPLE-0K13 f =HIDDENR1 [:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :]"
          using xboole_0_def_10 sorry
      qed
      thus "([:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :],[:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 ([:ZFMISC-1K2 X1,X2 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y1,Y2 :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X2,X1 :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y2,Y1 :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_17:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x <>HIDDENR2 y implies cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 y} :])"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x <>HIDDENR2 y implies cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 y} :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "x <>HIDDENR2 y"
    have "(X,cardCARD-1K1 X)are-equipotentWELLORD2R2 & (Y,cardCARD-1K1 Y)are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    then have "cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 y} :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 cardCARD-1K1 Y,{TARSKIK1 y} :])"
      using A1 card_2_th_12 sorry
    thus "cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 y} :])"
      using A1 card_2_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_18:
" for M be CardinalCARD-1M1 holds M +`CARD-2K1 0NUMBERSK6 =XBOOLE-0R4 M"
proof-
  have " for M be CardinalCARD-1M1 holds M +`CARD-2K1 0NUMBERSK6 =HIDDENR1 M"
  proof(rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    have "M +`CARD-2K1 0NUMBERSK6 =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {}XBOOLE-0K1,{TARSKIK1 \<one>\<^sub>M} :])"
      using card_2_lm_1 sorry
    also have "... = cardCARD-1K1 M"
      using card_1_th_69 sorry
    also have "... = M"
       sorry
    finally show "M +`CARD-2K1 0NUMBERSK6 =HIDDENR1 M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_2_lm_4:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x <>HIDDENR2 y implies [:ZFMISC-1K2 X,{TARSKIK1 x} :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y,{TARSKIK1 y} :]"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x <>HIDDENR2 y implies ( not [:ZFMISC-1K2 X,{TARSKIK1 x} :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y,{TARSKIK1 y} :] implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "x <>HIDDENR2 y"
    assume " not [:ZFMISC-1K2 X,{TARSKIK1 x} :] missesXBOOLE-0R1 [:ZFMISC-1K2 Y,{TARSKIK1 y} :]"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A2: "z inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"and A3: "z inHIDDENR3 [:ZFMISC-1K2 Y,{TARSKIK1 y} :]"
      using xboole_0_th_3 sorry
    have "z `2XTUPLE-0K2 =HIDDENR1 x"
      using A2 mcart_1_th_13 sorry
    thus " False "
      using A1 A3 mcart_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_19:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (K +`CARD-2K1 M)+`CARD-2K1 N =XBOOLE-0R4 K +`CARD-2K1 (M +`CARD-2K1 N)"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (K +`CARD-2K1 M)+`CARD-2K1 N =XBOOLE-0R4 K +`CARD-2K1 (M +`CARD-2K1 N)"
  proof(rule ballI,rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "cardCARD-1K1 ((K +`CARD-2K1 M)+`CARD-2K1 N) =XBOOLE-0R4 (K +`CARD-2K1 M)+`CARD-2K1 N"
       sorry
    have A2: "((K +`CARD-2K1 M)+`CARD-2K1 N,[:ZFMISC-1K2 K +`CARD-2K1 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_2_th_10 sorry
    have "[:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] missesXBOOLE-0R1 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have A3: "([:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =RELAT-1R1 {}XBOOLE-0K1"
       sorry
    have "[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =RELAT-1R1 {}XBOOLE-0K1"
       sorry
    then have "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =HIDDENR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 {}XBOOLE-0K1"
      using A3 xboole_1_th_23 sorry
    also have "... = {}XBOOLE-0K1"
       sorry
    finally have "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =HIDDENR1 {}XBOOLE-0K1"
       sorry
    then have A4: "[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] missesXBOOLE-0R1 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]"
       sorry
    have "(K +`CARD-2K1 M,[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2 & (K +`CARD-2K1 M,[:ZFMISC-1K2 K +`CARD-2K1 M,{TARSKIK1 0NUMBERSK6 } :])are-equipotentWELLORD2R2"
      using card_1_th_69 card_2_th_10 sorry
    then have A5: "([:ZFMISC-1K2 K +`CARD-2K1 M,{TARSKIK1 0NUMBERSK6 } :],[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using wellord2_th_15 sorry
    have "[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have A6: "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =RELAT-1R1 {}XBOOLE-0K1"
       sorry
    have "[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :]) =RELAT-1R1 {}XBOOLE-0K1"
       sorry
    then have "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =HIDDENR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 {}XBOOLE-0K1"
      using A6 xboole_1_th_23 sorry
    also have "... = {}XBOOLE-0K1"
       sorry
    finally have "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =HIDDENR1 {}XBOOLE-0K1"
       sorry
    then have A7: "[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]"
       sorry
    have "(M +`CARD-2K1 N,[:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2 & (M +`CARD-2K1 N,[:ZFMISC-1K2 M +`CARD-2K1 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_1_th_69 card_2_th_10 sorry
    then have A8: "([:ZFMISC-1K2 M +`CARD-2K1 N,{TARSKIK1 \<two>\<^sub>M} :],[:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2"
      using wellord2_th_15 sorry
    have "[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 M +`CARD-2K1 N,{TARSKIK1 \<two>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have A9: "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 ([:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]),[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M +`CARD-2K1 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2"
      using A7 A8 card_1_th_31 sorry
    have "[:ZFMISC-1K2 K +`CARD-2K1 M,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have A10: "([:ZFMISC-1K2 K +`CARD-2K1 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :],([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])\\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2"
      using A4 A5 card_1_th_31 sorry
    have "[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 ([:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]) =RELAT-1R1 ([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M,{TARSKIK1 \<one>\<^sub>M} :])\\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :]"
      using xboole_1_th_4 sorry
    then have "([:ZFMISC-1K2 K +`CARD-2K1 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<two>\<^sub>M} :],[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M +`CARD-2K1 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2"
      using A10 A9 wellord2_th_15 sorry
    then have A11: "((K +`CARD-2K1 M)+`CARD-2K1 N,[:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M +`CARD-2K1 N,{TARSKIK1 \<two>\<^sub>M} :])are-equipotentWELLORD2R2"
      using A2 wellord2_th_15 sorry
    have "([:ZFMISC-1K2 K,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 M +`CARD-2K1 N,{TARSKIK1 \<two>\<^sub>M} :],K +`CARD-2K1 (M +`CARD-2K1 N))are-equipotentWELLORD2R2"
      using card_2_th_10 sorry
    then have "((K +`CARD-2K1 M)+`CARD-2K1 N,K +`CARD-2K1 (M +`CARD-2K1 N))are-equipotentWELLORD2R2"
      using A11 wellord2_th_15 sorry
    thus "(K +`CARD-2K1 M)+`CARD-2K1 N =XBOOLE-0R4 K +`CARD-2K1 (M +`CARD-2K1 N)"
      using A1 card_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_20:
" for K be CardinalCARD-1M1 holds K *`CARD-2K2 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
   sorry

mtheorem card_2_th_21:
" for K be CardinalCARD-1M1 holds K *`CARD-2K2 \<one>\<^sub>M =XBOOLE-0R4 K"
proof-
  have " for K be CardinalCARD-1M1 holds K *`CARD-2K2 \<one>\<^sub>M =XBOOLE-0R4 K"
  proof(rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    have "K =XBOOLE-0R4 cardCARD-1K1 K"
       sorry
    thus "K *`CARD-2K2 \<one>\<^sub>M =XBOOLE-0R4 K"
      using card_1_th_69 ordinal3_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_22:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (K *`CARD-2K2 M)*`CARD-2K2 N =XBOOLE-0R4 K *`CARD-2K2 (M *`CARD-2K2 N)"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (K *`CARD-2K2 M)*`CARD-2K2 N =HIDDENR1 K *`CARD-2K2 (M *`CARD-2K2 N)"
  proof(rule ballI,rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have "(K *`CARD-2K2 M)*`CARD-2K2 N =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 K,M :],N :])"
      using card_2_th_7 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 K,[:ZFMISC-1K2 M,N :] :])"
      using card_2_th_5 sorry
    also have "... = K *`CARD-2K2 (M *`CARD-2K2 N)"
      using card_2_th_7 sorry
    finally show "(K *`CARD-2K2 M)*`CARD-2K2 N =HIDDENR1 K *`CARD-2K2 (M *`CARD-2K2 N)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_23:
" for K be CardinalCARD-1M1 holds \<two>\<^sub>M *`CARD-2K2 K =XBOOLE-0R4 K +`CARD-2K1 K"
proof-
  have " for K be CardinalCARD-1M1 holds \<two>\<^sub>M *`CARD-2K2 K =HIDDENR1 K +`CARD-2K1 K"
  proof(rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    have "\<two>\<^sub>M *`CARD-2K2 K =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 {TARSKIK1 {}XBOOLE-0K1 },K :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 \<one>\<^sub>M},K :])"
      using card_1_th_50 zfmisc_1_th_109 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 K,{TARSKIK1 {}XBOOLE-0K1 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 K,{TARSKIK1 \<one>\<^sub>M} :])"
      using card_2_th_16 sorry
    also have "... = cardCARD-1K1 K +`CARD-2K1 cardCARD-1K1 K"
      using card_2_th_17 sorry
    also have "... = K +`CARD-2K1 cardCARD-1K1 K"
       sorry
    also have "... = K +`CARD-2K1 K"
       sorry
    finally show "\<two>\<^sub>M *`CARD-2K2 K =HIDDENR1 K +`CARD-2K1 K"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_24:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K *`CARD-2K2 (M +`CARD-2K1 N) =XBOOLE-0R4 K *`CARD-2K2 M +`CARD-2K1 K *`CARD-2K2 N"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K *`CARD-2K2 (M +`CARD-2K1 N) =HIDDENR1 K *`CARD-2K2 M +`CARD-2K1 K *`CARD-2K2 N"
  proof(rule ballI,rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "([:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,M :]),{TARSKIK1 0NUMBERSK6 } :],[:ZFMISC-1K2 [:ZFMISC-1K2 K,M :],{TARSKIK1 0NUMBERSK6 } :])are-equipotentWELLORD2R2"
      using card_2_th_7 sorry
    have "(M,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :])are-equipotentWELLORD2R2"
      using card_1_th_69 sorry
    then have A2: "([:ZFMISC-1K2 K,M :],[:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] :])are-equipotentWELLORD2R2"
      using card_2_th_8 sorry
    have "([:ZFMISC-1K2 [:ZFMISC-1K2 K,M :],{TARSKIK1 0NUMBERSK6 } :],[:ZFMISC-1K2 K,M :])are-equipotentWELLORD2R2"
      using card_1_th_69 sorry
    then have "([:ZFMISC-1K2 [:ZFMISC-1K2 K,M :],{TARSKIK1 0NUMBERSK6 } :],[:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] :])are-equipotentWELLORD2R2"
      using A2 wellord2_th_15 sorry
    then have A3: "([:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,M :]),{TARSKIK1 0NUMBERSK6 } :],[:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] :])are-equipotentWELLORD2R2"
      using A1 wellord2_th_15 sorry
    have A4: "([:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,N :]),{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 [:ZFMISC-1K2 K,N :],{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_2_th_7 sorry
    have "[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have A5: "[:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] :] missesXBOOLE-0R1 [:ZFMISC-1K2 K,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :]"
      using zfmisc_1_th_104 sorry
    have "(N,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_1_th_69 sorry
    then have A6: "([:ZFMISC-1K2 K,N :],[:ZFMISC-1K2 K,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :])are-equipotentWELLORD2R2"
      using card_2_th_8 sorry
    have A7: "K *`CARD-2K2 (M +`CARD-2K1 N) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 K,cardCARD-1K1 ([:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :]) :])"
      using card_2_th_10 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :])"
      using card_2_th_7 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] :] \\/XBOOLE-0K2 [:ZFMISC-1K2 K,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :])"
      using zfmisc_1_th_97 sorry
    finally have "K *`CARD-2K2 (M +`CARD-2K1 N) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] :] \\/XBOOLE-0K2 [:ZFMISC-1K2 K,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :])"
       sorry
    have "([:ZFMISC-1K2 [:ZFMISC-1K2 K,N :],{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 K,N :])are-equipotentWELLORD2R2"
      using card_1_th_69 sorry
    then have "([:ZFMISC-1K2 [:ZFMISC-1K2 K,N :],{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 K,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :])are-equipotentWELLORD2R2"
      using A6 wellord2_th_15 sorry
    then have A8: "([:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,N :]),{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 K,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :])are-equipotentWELLORD2R2"
      using A4 wellord2_th_15 sorry
    have "[:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,M :]),{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,N :]),{TARSKIK1 \<one>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have "([:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,M :]),{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,N :]),{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 K,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] :] \\/XBOOLE-0K2 [:ZFMISC-1K2 K,[:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :] :])are-equipotentWELLORD2R2"
      using A3 A8 A5 card_1_th_31 sorry
    then have "K *`CARD-2K2 (M +`CARD-2K1 N) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,M :]),{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 cardCARD-1K1 ([:ZFMISC-1K2 K,N :]),{TARSKIK1 \<one>\<^sub>M} :])"
      using A7 card_1_th_5 sorry
    also have "... = K *`CARD-2K2 M +`CARD-2K1 K *`CARD-2K2 N"
      using card_2_th_10 sorry
    finally show "K *`CARD-2K2 (M +`CARD-2K1 N) =HIDDENR1 K *`CARD-2K2 M +`CARD-2K1 K *`CARD-2K2 N"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_25:
" for K be CardinalCARD-1M1 holds expCARD-2K3(K,0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for K be CardinalCARD-1M1 holds expCARD-2K3(K,0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    have "expCARD-2K3(K,0NUMBERSK6) =HIDDENR1 cardCARD-1K4 {TARSKIK1 {}XBOOLE-0K1 }"
      using funct_5_th_57 sorry
    also have "... = \<one>\<^sub>M"
      using card_1_th_30 sorry
    finally show "expCARD-2K3(K,0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_26:
" for K be CardinalCARD-1M1 holds K <>HIDDENR2 0NUMBERSK6 implies expCARD-2K3(0NUMBERSK6,K) =XBOOLE-0R4 0NUMBERSK6"
   sorry

mtheorem card_2_th_27:
" for K be CardinalCARD-1M1 holds expCARD-2K3(K,\<one>\<^sub>M) =XBOOLE-0R4 K & expCARD-2K3(\<one>\<^sub>M,K) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for K be CardinalCARD-1M1 holds expCARD-2K3(K,\<one>\<^sub>M) =HIDDENR1 K & expCARD-2K3(\<one>\<^sub>M,K) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule conjMI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    have "expCARD-2K3(K,\<one>\<^sub>M) =HIDDENR1 cardCARD-1K1 K"
      using funct_5_th_58 ordinal3_th_15 sorry
    also have "... = K"
       sorry
    finally show "expCARD-2K3(K,\<one>\<^sub>M) =HIDDENR1 K"
       sorry
    have "expCARD-2K3(\<one>\<^sub>M,K) =HIDDENR1 cardCARD-1K4 {TARSKIK1 K -->FUNCOP-1K7 {}XBOOLE-0K1 }"
      using funct_5_th_59 ordinal3_th_15 sorry
    also have "... = \<one>\<^sub>M"
      using card_1_th_30 sorry
    finally show "expCARD-2K3(\<one>\<^sub>M,K) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_28:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds expCARD-2K3(K,M +`CARD-2K1 N) =XBOOLE-0R4 (expCARD-2K3(K,M))*`CARD-2K2 (expCARD-2K3(K,N))"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds expCARD-2K3(K,M +`CARD-2K1 N) =HIDDENR1 (expCARD-2K3(K,M))*`CARD-2K2 (expCARD-2K3(K,N))"
  proof(rule ballI,rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :]"
      using zfmisc_1_th_108 sorry
    have "([:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :],M)are-equipotentWELLORD2R2"
      using card_1_th_69 sorry
    then have A2: "(FuncsFUNCT-2K1([:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :],K),FuncsFUNCT-2K1(M,K))are-equipotentWELLORD2R2"
      using funct_5_th_60 sorry
    have "([:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :],N)are-equipotentWELLORD2R2"
      using card_1_th_69 sorry
    then have A3: "(FuncsFUNCT-2K1([:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :],K),FuncsFUNCT-2K1(N,K))are-equipotentWELLORD2R2"
      using funct_5_th_60 sorry
    have "(M +`CARD-2K1 N,[:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_2_th_10 sorry
    then have "expCARD-2K3(K,M +`CARD-2K1 N) =HIDDENR1 cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :],K))"
      using funct_5_th_60 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1([:ZFMISC-1K2 M,{TARSKIK1 0NUMBERSK6 } :],K),FuncsFUNCT-2K1([:ZFMISC-1K2 N,{TARSKIK1 \<one>\<^sub>M} :],K) :])"
      using A1 funct_5_th_62 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(M,K),FuncsFUNCT-2K1(N,K) :])"
      using A2 A3 card_2_th_8 sorry
    also have "... = (expCARD-2K3(K,M))*`CARD-2K2 (expCARD-2K3(K,N))"
      using card_2_th_7 sorry
    finally show "expCARD-2K3(K,M +`CARD-2K1 N) =HIDDENR1 (expCARD-2K3(K,M))*`CARD-2K2 (expCARD-2K3(K,N))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_29:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds expCARD-2K3(K *`CARD-2K2 M,N) =XBOOLE-0R4 (expCARD-2K3(K,N))*`CARD-2K2 (expCARD-2K3(M,N))"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds expCARD-2K3(K *`CARD-2K2 M,N) =HIDDENR1 (expCARD-2K3(K,N))*`CARD-2K2 (expCARD-2K3(M,N))"
  proof(rule ballI,rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have "cardCARD-1K1 (K *`CARD-2K2 M) =XBOOLE-0R4 K *`CARD-2K2 M & cardCARD-1K1 N =XBOOLE-0R4 cardCARD-1K1 N"
       sorry
    then have "expCARD-2K3(K *`CARD-2K2 M,N) =HIDDENR1 cardCARD-1K1 (FuncsFUNCT-2K1(N,[:ZFMISC-1K2 K,M :]))"
      using funct_5_th_61 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(N,K),FuncsFUNCT-2K1(N,M) :])"
      using funct_5_th_64 sorry
    also have "... = (expCARD-2K3(K,N))*`CARD-2K2 (expCARD-2K3(M,N))"
      using card_2_th_7 sorry
    finally show "expCARD-2K3(K *`CARD-2K2 M,N) =HIDDENR1 (expCARD-2K3(K,N))*`CARD-2K2 (expCARD-2K3(M,N))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_30:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds expCARD-2K3(K,M *`CARD-2K2 N) =XBOOLE-0R4 expCARD-2K3(expCARD-2K3(K,M),N)"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds expCARD-2K3(K,M *`CARD-2K2 N) =HIDDENR1 expCARD-2K3(expCARD-2K3(K,M),N)"
  proof(rule ballI,rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "(FuncsFUNCT-2K1(M,K),cardCARD-1K1 (FuncsFUNCT-2K1(M,K)))are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    have "([:ZFMISC-1K2 M,N :],M *`CARD-2K2 N)are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 N,M :],[:ZFMISC-1K2 M,N :])are-equipotentWELLORD2R2"
      using card_2_lm_2 card_1_def_2 sorry
    then have "([:ZFMISC-1K2 N,M :],M *`CARD-2K2 N)are-equipotentWELLORD2R2"
      using wellord2_th_15 sorry
    then have "expCARD-2K3(K,M *`CARD-2K2 N) =HIDDENR1 cardCARD-1K1 (FuncsFUNCT-2K1([:ZFMISC-1K2 N,M :],K))"
      using funct_5_th_60 sorry
    also have "... = cardCARD-1K1 (FuncsFUNCT-2K1(N,FuncsFUNCT-2K1(M,K)))"
      using funct_5_th_63 sorry
    also have "... = expCARD-2K3(expCARD-2K3(K,M),N)"
      using A1 funct_5_th_60 sorry
    finally show "expCARD-2K3(K,M *`CARD-2K2 N) =HIDDENR1 expCARD-2K3(expCARD-2K3(K,M),N)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N The Number of Subsets of a Set*)
mtheorem card_2_th_31:
" for X be setHIDDENM2 holds expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 X) =XBOOLE-0R4 cardCARD-1K1 (boolZFMISC-1K1 X)"
proof-
  have " for X be setHIDDENM2 holds expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 X) =HIDDENR1 cardCARD-1K1 (boolZFMISC-1K1 X)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "cardCARD-1K1 (cardCARD-1K1 X) =XBOOLE-0R4 cardCARD-1K1 X & cardCARD-1K4 \<two>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }"
      using card_1_th_50 sorry
    then have "expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 X) =HIDDENR1 cardCARD-1K1 (FuncsFUNCT-2K9(X,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }))"
      using funct_5_th_61 sorry
    also have "... = cardCARD-1K1 (boolZFMISC-1K1 X)"
      using funct_5_th_65 sorry
    finally show "expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 X) =HIDDENR1 cardCARD-1K1 (boolZFMISC-1K1 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_32:
" for K be CardinalCARD-1M1 holds expCARD-2K3(K,\<two>\<^sub>M) =XBOOLE-0R4 K *`CARD-2K2 K"
  using card_1_th_50 funct_5_th_66 sorry

mtheorem card_2_th_33:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds expCARD-2K3(K +`CARD-2K1 M,\<two>\<^sub>M) =XBOOLE-0R4 (K *`CARD-2K2 K +`CARD-2K1 (\<two>\<^sub>M *`CARD-2K2 K)*`CARD-2K2 M)+`CARD-2K1 M *`CARD-2K2 M"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds expCARD-2K3(K +`CARD-2K1 M,\<two>\<^sub>M) =HIDDENR1 (K *`CARD-2K2 K +`CARD-2K1 (\<two>\<^sub>M *`CARD-2K2 K)*`CARD-2K2 M)+`CARD-2K1 M *`CARD-2K2 M"
  proof(rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    have "expCARD-2K3(K +`CARD-2K1 M,\<two>\<^sub>M) =HIDDENR1 (K +`CARD-2K1 M)*`CARD-2K2 (K +`CARD-2K1 M)"
      using card_1_th_50 funct_5_th_66 sorry
    also have "... = K *`CARD-2K2 (K +`CARD-2K1 M) +`CARD-2K1 M *`CARD-2K2 (K +`CARD-2K1 M)"
      using card_2_th_24 sorry
    also have "... = (K *`CARD-2K2 K +`CARD-2K1 K *`CARD-2K2 M)+`CARD-2K1 M *`CARD-2K2 (K +`CARD-2K1 M)"
      using card_2_th_24 sorry
    also have "... = (K *`CARD-2K2 K +`CARD-2K1 K *`CARD-2K2 M)+`CARD-2K1 (M *`CARD-2K2 K +`CARD-2K1 M *`CARD-2K2 M)"
      using card_2_th_24 sorry
    also have "... = ((K *`CARD-2K2 K +`CARD-2K1 K *`CARD-2K2 M)+`CARD-2K1 K *`CARD-2K2 M)+`CARD-2K1 M *`CARD-2K2 M"
      using card_2_th_19 sorry
    also have "... = (K *`CARD-2K2 K +`CARD-2K1 (K *`CARD-2K2 M +`CARD-2K1 K *`CARD-2K2 M))+`CARD-2K1 M *`CARD-2K2 M"
      using card_2_th_19 sorry
    also have "... = (K *`CARD-2K2 K +`CARD-2K1 \<two>\<^sub>M *`CARD-2K2 (K *`CARD-2K2 M))+`CARD-2K1 M *`CARD-2K2 M"
      using card_2_th_23 sorry
    also have "... = (K *`CARD-2K2 K +`CARD-2K1 (\<two>\<^sub>M *`CARD-2K2 K)*`CARD-2K2 M)+`CARD-2K1 M *`CARD-2K2 M"
      using card_2_th_22 sorry
    finally show "expCARD-2K3(K +`CARD-2K1 M,\<two>\<^sub>M) =HIDDENR1 (K *`CARD-2K2 K +`CARD-2K1 (\<two>\<^sub>M *`CARD-2K2 K)*`CARD-2K2 M)+`CARD-2K1 M *`CARD-2K2 M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_34:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :] & ( for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :] implies f .FUNCT-1K1 x =HIDDENR1 x `1XTUPLE-0K1)"
      using funct_1_sch_3 sorry
    have "X \\/XBOOLE-0K2 Y c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
        then have A2: "x inHIDDENR3 X or x inHIDDENR3 Y"
          using xboole_0_def_3 sorry
        show "x inHIDDENR3 rngFUNCT-1K2 f"
        proof-
          have cases: "x inHIDDENR3 X or  not x inHIDDENR3 X"
             sorry
          have case1: "x inHIDDENR3 X implies x inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule impI)
            assume "x inHIDDENR3 X"
            then have "[TARSKIK4 x,0NUMBERSK6 ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :]"
              using zfmisc_1_th_106 sorry
            then have A3: "[TARSKIK4 x,0NUMBERSK6 ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :]"
              using xboole_0_def_3 sorry
            have "[TARSKIK4 x,0NUMBERSK6 ] `1XTUPLE-0K1 =HIDDENR1 x"
               sorry
            then have "x =HIDDENR1 f .FUNCT-1K1 [TARSKIK4 x,0NUMBERSK6 ]"
              using A1 A3 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 f"
              using A1 A3 funct_1_def_3 sorry
          qed
          have case2: " not x inHIDDENR3 X implies x inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule impI)
            assume " not x inHIDDENR3 X"
            then have "[TARSKIK4 x,\<one>\<^sub>M ] inHIDDENR3 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :]"
              using A2 zfmisc_1_th_106 sorry
            then have A4: "[TARSKIK4 x,\<one>\<^sub>M ] inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :]"
              using xboole_0_def_3 sorry
            have "[TARSKIK4 x,\<one>\<^sub>M ] `1XTUPLE-0K1 =HIDDENR1 x"
               sorry
            then have "x =HIDDENR1 f .FUNCT-1K1 [TARSKIK4 x,\<one>\<^sub>M ]"
              using A1 A4 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 f"
              using A1 A4 funct_1_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "X \\/XBOOLE-0K2 Y c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    then have "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :])"
      using A1 card_1_th_12 sorry
    thus "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
      using card_2_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_35:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =HIDDENR1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X missesXBOOLE-0R1 Y"
    have "(X,[:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :])are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 X,{TARSKIK1 0NUMBERSK6 } :],[:ZFMISC-1K2 cardCARD-1K1 X,{TARSKIK1 0NUMBERSK6 } :])are-equipotentWELLORD2R2"
      using card_1_th_69 card_2_th_7 sorry
    then have A2: "(X,[:ZFMISC-1K2 cardCARD-1K1 X,{TARSKIK1 0NUMBERSK6 } :])are-equipotentWELLORD2R2"
      using wellord2_th_15 sorry
    have "(Y,[:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2 & ([:ZFMISC-1K2 Y,{TARSKIK1 \<one>\<^sub>M} :],[:ZFMISC-1K2 cardCARD-1K1 Y,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using card_1_th_69 card_2_th_7 sorry
    then have A3: "(Y,[:ZFMISC-1K2 cardCARD-1K1 Y,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using wellord2_th_15 sorry
    have "[:ZFMISC-1K2 cardCARD-1K1 X,{TARSKIK1 0NUMBERSK6 } :] missesXBOOLE-0R1 [:ZFMISC-1K2 cardCARD-1K1 Y,{TARSKIK1 \<one>\<^sub>M} :]"
      using card_2_lm_4 sorry
    then have "(X \\/XBOOLE-0K2 Y,[:ZFMISC-1K2 cardCARD-1K1 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 cardCARD-1K1 Y,{TARSKIK1 \<one>\<^sub>M} :])are-equipotentWELLORD2R2"
      using A1 A2 A3 card_1_th_31 sorry
    then have "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 X,{TARSKIK1 0NUMBERSK6 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 cardCARD-1K1 Y,{TARSKIK1 \<one>\<^sub>M} :])"
      using card_1_th_5 sorry
    also have "... = cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
      using card_2_th_10 sorry
    finally show "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =HIDDENR1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve m, n for "NatORDINAL1M6"
mtheorem card_2_th_36:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds n +XCMPLX-0K2 m =XBOOLE-0R4 n +^ORDINAL3K8 m"
proof-
  have " for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds n +XCMPLX-0K2 m =XBOOLE-0R4 n +^ORDINAL3K8 m"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatORDINAL1M6"
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1. n +XCMPLX-0K2 Lamb1 =XBOOLE-0R4 n +^ORDINAL3K8 Lamb1"
    have A1: " for m be NatORDINAL1M6 holds ?P(m) implies ?P(m +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for m be NatORDINAL1M6 holds n +XCMPLX-0K2 m =XBOOLE-0R4 n +^ORDINAL3K8 m implies n +XCMPLX-0K2 (m +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 n +^ORDINAL3K8 (m +XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatORDINAL1M6"
        assume A2: "?P(m)"
        have "n +XCMPLX-0K2 (m +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 SegmCARD-1K5 ((n +XCMPLX-0K2 m)+XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
        also have "... = succORDINAL1K1 (SegmCARD-1K5 (n +XCMPLX-0K2 m))"
          using nat_1_th_38 sorry
        also have "... = succORDINAL1K1 (n +^ORDINAL3K8 m)"
          using A2 sorry
        also have "... = n +^ORDINAL3K8 succORDINAL1K1 (SegmCARD-1K5 m)"
          using ordinal2_th_28 sorry
        also have "... = n +^ORDINAL3K8 SegmCARD-1K5 (m +XCMPLX-0K2 \<one>\<^sub>M)"
          using nat_1_th_38 sorry
        also have "... = n +^ORDINAL3K8 (m +XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
        finally show "n +XCMPLX-0K2 (m +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 n +^ORDINAL3K8 (m +XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?P(0NUMBERSK6)"
      using ordinal2_th_27 sorry
    have " for m be NatORDINAL1M6 holds ?P(m)"
      using nat_1_sch_2 A3 A1 sorry
    thus "n +XCMPLX-0K2 m =XBOOLE-0R4 n +^ORDINAL3K8 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_37:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds n *XCMPLX-0K3 m =XBOOLE-0R4 n *^ORDINAL3K9 m"
proof-
  have " for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds n *XCMPLX-0K3 m =XBOOLE-0R4 n *^ORDINAL3K9 m"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatORDINAL1M6"
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1. Lamb1 *XCMPLX-0K3 m =XBOOLE-0R4 Lamb1 *^ORDINAL3K9 m"
    have A1: " for n be NatORDINAL1M6 holds ?P(n) implies ?P(n +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for n be NatORDINAL1M6 holds n *XCMPLX-0K3 m =XBOOLE-0R4 n *^ORDINAL3K9 m implies (n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 m =HIDDENR1 (n +XCMPLX-0K2 \<one>\<^sub>M)*^ORDINAL3K9 m"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatORDINAL1M6"
        assume A2: "?P(n)"
        have "(n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 m =HIDDENR1 n *XCMPLX-0K3 m +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 m"
           sorry
        also have "... = n *^ORDINAL3K9 m +^ORDINAL2K10 m"
          using A2 card_2_th_36 sorry
        also have "... = n *^ORDINAL3K9 m +^ORDINAL2K10 \<one>\<^sub>M *^ORDINAL3K9 m"
          using ordinal2_th_39 sorry
        also have "... = (n +^ORDINAL3K8 \<one>\<^sub>M)*^ORDINAL2K11 m"
          using ordinal3_th_46 sorry
        also have "... = succORDINAL1K1 (SegmCARD-1K5 n) *^ORDINAL3K9 m"
          using ordinal2_th_31 sorry
        also have "... = (SegmCARD-1K5 (n +XCMPLX-0K2 \<one>\<^sub>M))*^ORDINAL3K9 m"
          using nat_1_th_38 sorry
        also have "... = (n +XCMPLX-0K2 \<one>\<^sub>M)*^ORDINAL3K9 m"
           sorry
        finally show "(n +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 m =HIDDENR1 (n +XCMPLX-0K2 \<one>\<^sub>M)*^ORDINAL3K9 m"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?P(0NUMBERSK6)"
      using ordinal2_th_35 sorry
    have " for n be NatORDINAL1M6 holds ?P(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus "n *XCMPLX-0K3 m =XBOOLE-0R4 n *^ORDINAL3K9 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_38:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds cardCARD-1K4 (n +XCMPLX-0K2 m) =XBOOLE-0R4 cardCARD-1K4 n +`CARD-2K1 cardCARD-1K4 m"
  using card_2_th_36 sorry

mtheorem card_2_th_39:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds cardCARD-1K4 (n *XCMPLX-0K3 m) =XBOOLE-0R4 cardCARD-1K4 n *`CARD-2K2 cardCARD-1K4 m"
proof-
  have " for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds cardCARD-1K4 (n *XCMPLX-0K3 m) =HIDDENR1 cardCARD-1K4 n *`CARD-2K2 cardCARD-1K4 m"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatORDINAL1M6"
    fix n assume [ty]: "n be NatORDINAL1M6"
    have "cardCARD-1K4 (n *XCMPLX-0K3 m) =HIDDENR1 cardCARD-1K1 (n *^ORDINAL3K9 m)"
      using card_2_th_37 sorry
    also have "... = cardCARD-1K4 n *`CARD-2K2 cardCARD-1K4 m"
      using card_2_th_14 sorry
    finally show "cardCARD-1K4 (n *XCMPLX-0K3 m) =HIDDENR1 cardCARD-1K4 n *`CARD-2K2 cardCARD-1K4 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_40:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds X missesXBOOLE-0R1 Y implies cardCARD-1K4 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  assume "X missesXBOOLE-0R1 Y"
  then have "cardCARD-1K4 (cardCARD-1K4 (X \\/XBOOLE-0K2 Y)) =HIDDENR1 cardCARD-1K4 (cardCARD-1K4 X) +`CARD-2K1 cardCARD-1K4 (cardCARD-1K4 Y)"
    using card_2_th_35 sorry
  also have "... = cardCARD-1K4 (cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y)"
    using card_2_th_38 sorry
  finally have "cardCARD-1K4 (cardCARD-1K4 (X \\/XBOOLE-0K2 Y)) =HIDDENR1 cardCARD-1K4 (cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y)"
     sorry
  thus "cardCARD-1K4 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y"
     sorry
qed "sorry"

mtheorem card_2_th_41:
" for x be objectHIDDENM1 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not x inHIDDENR3 X implies cardCARD-1K4 (X \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for x be objectHIDDENM1 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not x inHIDDENR3 X implies cardCARD-1K4 (X \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
    have A1: "cardCARD-1K4 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    assume " not x inHIDDENR3 X"
    thus "cardCARD-1K4 (X \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 card_2_th_40 zfmisc_1_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_42:
" for X be setHIDDENM2 holds cardCARD-1K1 X =XBOOLE-0R4 \<one>\<^sub>M iff ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})"
proof-
  have " for X be setHIDDENM2 holds (cardCARD-1K1 X =XBOOLE-0R4 \<one>\<^sub>M implies ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})) & (( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x}) implies cardCARD-1K1 X =XBOOLE-0R4 \<one>\<^sub>M)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "cardCARD-1K4 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    thus "cardCARD-1K1 X =XBOOLE-0R4 \<one>\<^sub>M implies ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})"
      using card_1_th_29 sorry
    assume Given: " ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x}"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "X =XBOOLE-0R4 {TARSKIK1 x}"
       sorry
    show "cardCARD-1K1 X =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 card_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_43:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 (X \\/XBOOLE-0K2 Y) <=XXREAL-0R1 cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  have "cardCARD-1K4 X =XBOOLE-0R4 cardCARD-1K4 (cardCARD-1K4 X) & cardCARD-1K4 Y =XBOOLE-0R4 cardCARD-1K4 (cardCARD-1K4 Y)"
     sorry
  then have "cardCARD-1K4 X +`CARD-2K1 cardCARD-1K4 Y =XBOOLE-0R4 cardCARD-1K4 (cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y)"
    using card_2_th_38 sorry
  then have "cardCARD-1K4 (SegmCARD-1K5 cardCARD-1K4 (X \\/XBOOLE-0K2 Y)) =XBOOLE-0R4 cardCARD-1K4 (X \\/XBOOLE-0K2 Y) & cardCARD-1K4 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K4 (SegmCARD-1K5 (cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y))"
    using card_2_th_34 sorry
  thus "cardCARD-1K4 (X \\/XBOOLE-0K2 Y) <=XXREAL-0R1 cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y"
    using nat_1_th_40 sorry
qed "sorry"

mtheorem card_2_th_44:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y c=TARSKIR1 X implies cardCARD-1K4 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 Y"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  let ?P = "\<lambda>Lamb1.  ex S be finiteFINSET-1V1\<bar>setHIDDENM2 st S =XBOOLE-0R4 Lamb1 & cardCARD-1K4 (X \\SUBSET-1K6 S) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 S"
  have "cardCARD-1K4 X -XCMPLX-0K6 0NUMBERSK6 =XBOOLE-0R4 cardCARD-1K4 X & X \\SUBSET-1K6 {}XBOOLE-0K1 =XBOOLE-0R4 X"
     sorry
  then have A1: "?P({}XBOOLE-0K1)"
    using card_1_th_27 sorry
  assume A2: "Y c=TARSKIR1 X"
  have A3: " for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X1 inTARSKIR2 Y & Z c=TARSKIR1 Y) & ?P(Z) implies ?P(Z \\/XBOOLE-0K2 {TARSKIK1 X1})"
  proof-
    have " for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds X1 inTARSKIR2 Y & (Z c=TARSKIR1 Y & (( ex S be finiteFINSET-1V1\<bar>setHIDDENM2 st S =XBOOLE-0R4 Z & cardCARD-1K4 (X \\SUBSET-1K6 S) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 S) &  not ( ex S be finiteFINSET-1V1\<bar>setHIDDENM2 st S =XBOOLE-0R4 Z \\/XBOOLE-0K2 {TARSKIK1 X1} & cardCARD-1K4 (X \\SUBSET-1K6 S) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 S))) implies  False "
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
      fix X1 assume [ty]: "X1 be setHIDDENM2"
      fix Z assume [ty]: "Z be setHIDDENM2"
      assume A4: "X1 inTARSKIR2 Y"
        and A5: "Z c=TARSKIR1 Y"
        and A6: "?P(Z)"
        and A7: " not ?P(Z \\/XBOOLE-0K2 {TARSKIK1 X1})"
      have A8: "cardCARD-1K4 {TARSKIK1 X1} =XBOOLE-0R4 \<one>\<^sub>M"
        using card_1_th_30 sorry
      have A9: "X1 inTARSKIR2 Z implies ( ex S be finiteFINSET-1V1\<bar>setHIDDENM2 st S =XBOOLE-0R4 Z \\/XBOOLE-0K2 {TARSKIK1 X1} & cardCARD-1K4 (X \\SUBSET-1K6 S) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 S)"
      proof(rule impI)
        assume "X1 inTARSKIR2 Z"
        then have "{TARSKIK1 X1} c=TARSKIR1 Z"
          using zfmisc_1_th_31 sorry
        then have "Z =XBOOLE-0R4 Z \\/XBOOLE-0K2 {TARSKIK1 X1}"
          using xboole_1_th_12 sorry
        thus " ex S be finiteFINSET-1V1\<bar>setHIDDENM2 st S =XBOOLE-0R4 Z \\/XBOOLE-0K2 {TARSKIK1 X1} & cardCARD-1K4 (X \\SUBSET-1K6 S) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 S"
          using A6 sorry
      qed
      then have A10: "X1 inTARSKIR2 X \\SUBSET-1K6 Z"
        using A2 A4 A7 xboole_0_def_5 sorry
      then obtain m where
        [ty]:"m be NatORDINAL1M6" and 
        A11: "cardCARD-1K4 (X \\SUBSET-1K6 Z) =XBOOLE-0R4 m +XCMPLX-0K2 \<one>\<^sub>M"
        using nat_1_th_6 sorry
      obtain Z1 where 
        [ty]:"Z1 be finiteFINSET-1V1\<bar>setHIDDENM2" and Z1Def:"Z1 = Z"
        using A5 sorry
      have A12: "(X \\SUBSET-1K6 Z,cardCARD-1K4 (X \\SUBSET-1K6 Z))are-equipotentWELLORD2R2 & X \\SUBSET-1K6 (Z \\/XBOOLE-0K2 {TARSKIK1 X1}) =XBOOLE-0R4 (X \\SUBSET-1K6 Z)\\SUBSET-1K7\<^bsub>(X)\<^esub> {TARSKIK1 X1}"
        using card_1_def_2 xboole_1_th_41 sorry
      have "cardCARD-1K4 {TARSKIK1 X1} =XBOOLE-0R4 \<one>\<^sub>M"
        using card_1_th_30 sorry
      then have A13: "cardCARD-1K4 Z1 +XCMPLX-0K2 cardCARD-1K4 {TARSKIK1 X1} =XBOOLE-0R4 cardCARD-1K4 (Z1 \\/XBOOLE-0K2 {TARSKIK1 X1})"
        using A7 A9 card_2_th_41 sorry
      have "SegmCARD-1K5 (m +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 m)"
        using nat_1_th_38 sorry
      then have "m inTARSKIR2 m +XCMPLX-0K2 \<one>\<^sub>M & m =XBOOLE-0R4 (m +XCMPLX-0K2 \<one>\<^sub>M)\\SUBSET-1K6 {TARSKIK1 m}"
        using ordinal1_th_6 ordinal1_th_37 sorry
      then have "(X \\SUBSET-1K6 (Z \\/XBOOLE-0K2 {TARSKIK1 X1}),m)are-equipotentWELLORD2R2"
        using A10 A11 A12 card_1_th_34 sorry
      then have "cardCARD-1K4 (X \\SUBSET-1K6 (Z \\/XBOOLE-0K2 {TARSKIK1 X1})) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 (Z1 \\/XBOOLE-0K2 {TARSKIK1 X1})"
        using A6 A13 A11 A8 card_1_def_2 sorry
      thus " False "
        using A7 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A14: "Y be finiteFINSET-1V1"
     sorry
  have "?P(Y)"
    using finset_1_sch_2 A14 A1 A3 sorry
  thus "cardCARD-1K4 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K4 X -XCMPLX-0K6 cardCARD-1K4 Y"
     sorry
qed "sorry"

mtheorem card_2_th_45:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 (cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y)-XCMPLX-0K6 cardCARD-1K4 (X /\\XBOOLE-0K3 Y)"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  have "Y \\SUBSET-1K6 X =XBOOLE-0R4 Y \\SUBSET-1K6 X /\\XBOOLE-0K3 Y"
    using xboole_1_th_47 sorry
  then have A1: "cardCARD-1K4 (Y \\SUBSET-1K6 X) =XBOOLE-0R4 cardCARD-1K4 Y -XCMPLX-0K6 cardCARD-1K4 (X /\\XBOOLE-0K3 Y)"
    using card_2_th_44 xboole_1_th_17 sorry
  have "cardCARD-1K4 (X \\/XBOOLE-0K2 (Y \\SUBSET-1K6 X)) =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 (Y \\SUBSET-1K6 X)"
    using card_2_th_40 xboole_1_th_79 sorry
  thus "cardCARD-1K4 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 (cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y)-XCMPLX-0K6 cardCARD-1K4 (X /\\XBOOLE-0K3 Y)"
    using A1 xboole_1_th_39 sorry
qed "sorry"

mtheorem card_2_th_46:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K4 X *XCMPLX-0K3 cardCARD-1K4 Y"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  have "cardCARD-1K4 (cardCARD-1K4 ([:ZFMISC-1K2 X,Y :])) =HIDDENR1 cardCARD-1K4 (cardCARD-1K4 X) *`CARD-2K2 cardCARD-1K4 (cardCARD-1K4 Y)"
    using card_2_th_7 sorry
  also have "... = cardCARD-1K4 (cardCARD-1K4 X *XCMPLX-0K3 cardCARD-1K4 Y)"
    using card_2_th_39 sorry
  finally have "cardCARD-1K4 (cardCARD-1K4 ([:ZFMISC-1K2 X,Y :])) =HIDDENR1 cardCARD-1K4 (cardCARD-1K4 X *XCMPLX-0K3 cardCARD-1K4 Y)"
     sorry
  thus "cardCARD-1K4 ([:ZFMISC-1K2 X,Y :]) =XBOOLE-0R4 cardCARD-1K4 X *XCMPLX-0K3 cardCARD-1K4 Y"
     sorry
qed "sorry"

mtheorem card_2_th_47:
" for f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds cardCARD-1K4 (rngFUNCT-1K2 f) <=XXREAL-0R1 cardCARD-1K4 (domRELAT-1K1 f)"
proof(rule ballI)
  fix f assume [ty]: "f be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
  have "SegmCARD-1K5 cardCARD-1K4 (rngFUNCT-1K2 f) c=ORDINAL1R1 SegmCARD-1K5 cardCARD-1K4 (domRELAT-1K1 f)"
    using card_1_th_12 sorry
  thus "cardCARD-1K4 (rngFUNCT-1K2 f) <=XXREAL-0R1 cardCARD-1K4 (domRELAT-1K1 f)"
    using nat_1_th_39 sorry
qed "sorry"

mtheorem card_2_th_48:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c<XBOOLE-0R2 Y implies cardCARD-1K4 X <XXREAL-0R3 cardCARD-1K4 Y & cardCARD-1K4 X inTARSKIR2 SegmCARD-1K5 cardCARD-1K4 Y"
proof(rule ballI,rule ballI,rule impI,rule conjMI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  assume A1: "X c<XBOOLE-0R2 Y"
  then have "X c=TARSKIR1 Y"
     sorry
  then have A2: "Y =XBOOLE-0R4 X \\/XBOOLE-0K2 (Y \\SUBSET-1K6 X)"
    using xboole_1_th_45 sorry
  then have A3: "cardCARD-1K4 Y =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 (Y \\SUBSET-1K6 X)"
    using card_2_th_40 xboole_1_th_79 sorry
  then have A4: "cardCARD-1K4 X <=XXREAL-0R1 cardCARD-1K4 Y"
    using nat_1_th_11 sorry
  have "cardCARD-1K4 (Y \\SUBSET-1K6 X) =XBOOLE-0R4 0NUMBERSK6 implies  False "
  proof(rule impI)
    assume "cardCARD-1K4 (Y \\SUBSET-1K6 X) =XBOOLE-0R4 0NUMBERSK6"
    then have "Y \\SUBSET-1K6 X =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    thus " False "
      using A1 A2 sorry
  qed
  then have "cardCARD-1K4 X <>HIDDENR2 cardCARD-1K4 Y"
    using A3 sorry
  thus "cardCARD-1K4 X <XXREAL-0R3 cardCARD-1K4 Y"
    using A4 xxreal_0_th_1 sorry
  thus "cardCARD-1K4 X inTARSKIR2 SegmCARD-1K5 cardCARD-1K4 Y"
    using nat_1_th_44 sorry
qed "sorry"

mtheorem card_2_th_49:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y) & Y be finiteFINSET-1V1 implies X be finiteFINSET-1V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y) & Y be finiteFINSET-1V1 implies X be finiteFINSET-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y or cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y"
      and A2: "Y be finiteFINSET-1V1"
    have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
      using A1 ordinal1_def_2 sorry
    thus "X be finiteFINSET-1V1"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x1, x2, x3, x4, x5, x6, x7, x8 for "objectHIDDENM1"
mtheorem card_2_th_50:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds cardCARD-1K4 {TARSKIK2 x1,x2 } <=XXREAL-0R1 \<two>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds cardCARD-1K4 {TARSKIK2 x1,x2 } <=XXREAL-0R1 \<two>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have A1: "{TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2} & \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
      using enumset1_th_1 sorry
    have "cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M & cardCARD-1K4 {TARSKIK1 x2} =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    thus "cardCARD-1K4 {TARSKIK2 x1,x2 } <=XXREAL-0R1 \<two>\<^sub>M"
      using A1 card_2_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_51:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } <=XXREAL-0R1 \<three>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } <=XXREAL-0R1 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "cardCARD-1K4 {TARSKIK2 x2,x3 } <=XXREAL-0R1 \<two>\<^sub>M"
      using card_2_th_50 sorry
    then have A1: "\<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {TARSKIK2 x2,x3 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M"
      using xreal_1_th_7 sorry
    have "cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M & {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
      using card_1_th_30 enumset1_th_2 sorry
    then have "cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {TARSKIK2 x2,x3 }"
      using card_2_th_43 sorry
    thus "cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } <=XXREAL-0R1 \<three>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_52:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } <=XXREAL-0R1 \<four>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } <=XXREAL-0R1 \<four>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "cardCARD-1K4 {ENUMSET1K1 x2,x3,x4 } <=XXREAL-0R1 \<three>\<^sub>M"
      using card_2_th_51 sorry
    then have A1: "\<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K1 x2,x3,x4 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M"
      using xreal_1_th_7 sorry
    have "cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M & {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using card_1_th_30 enumset1_th_4 sorry
    then have "cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K1 x2,x3,x4 }"
      using card_2_th_43 sorry
    thus "cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } <=XXREAL-0R1 \<four>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_53:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } <=XXREAL-0R1 \<five>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } <=XXREAL-0R1 \<five>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have "cardCARD-1K4 {ENUMSET1K2 x2,x3,x4,x5 } <=XXREAL-0R1 \<four>\<^sub>M"
      using card_2_th_52 sorry
    then have A1: "\<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K2 x2,x3,x4,x5 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<four>\<^sub>M"
      using xreal_1_th_7 sorry
    have "cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M & {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
      using card_1_th_30 enumset1_th_7 sorry
    then have "cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K2 x2,x3,x4,x5 }"
      using card_2_th_43 sorry
    thus "cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } <=XXREAL-0R1 \<five>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_54:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } <=XXREAL-0R1 \<six>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } <=XXREAL-0R1 \<six>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have "cardCARD-1K4 {ENUMSET1K3 x2,x3,x4,x5,x6 } <=XXREAL-0R1 \<five>\<^sub>M"
      using card_2_th_53 sorry
    then have A1: "\<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K3 x2,x3,x4,x5,x6 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<five>\<^sub>M"
      using xreal_1_th_7 sorry
    have "cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M & {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
      using card_1_th_30 enumset1_th_11 sorry
    then have "cardCARD-1K4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
      using card_2_th_43 sorry
    thus "cardCARD-1K4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } <=XXREAL-0R1 \<six>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_55:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } <=XXREAL-0R1 \<seven>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } <=XXREAL-0R1 \<seven>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have "cardCARD-1K4 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 } <=XXREAL-0R1 \<six>\<^sub>M"
      using card_2_th_54 sorry
    then have A1: "\<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<six>\<^sub>M"
      using xreal_1_th_7 sorry
    have "cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M & {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
      using card_1_th_30 enumset1_th_16 sorry
    then have "cardCARD-1K4 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
      using card_2_th_43 sorry
    thus "cardCARD-1K4 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } <=XXREAL-0R1 \<seven>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_56:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } <=XXREAL-0R1 \<eight>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds cardCARD-1K4 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } <=XXREAL-0R1 \<eight>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have "cardCARD-1K4 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 } <=XXREAL-0R1 \<seven>\<^sub>M"
      using card_2_th_55 sorry
    then have A1: "\<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<seven>\<^sub>M"
      using xreal_1_th_7 sorry
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 } & cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 enumset1_th_22 sorry
    then have "cardCARD-1K4 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 cardCARD-1K4 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 }"
      using card_2_th_43 sorry
    thus "cardCARD-1K4 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } <=XXREAL-0R1 \<eight>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_57:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 <>HIDDENR2 x2 implies cardCARD-1K4 {TARSKIK2 x1,x2 } =XBOOLE-0R4 \<two>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 <>HIDDENR2 x2 implies cardCARD-1K4 {TARSKIK2 x1,x2 } =XBOOLE-0R4 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have A1: "cardCARD-1K4 {TARSKIK1 x1} =XBOOLE-0R4 \<one>\<^sub>M & cardCARD-1K4 {TARSKIK1 x2} =XBOOLE-0R4 \<one>\<^sub>M"
      using card_1_th_30 sorry
    have A2: "{TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2} & \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
      using enumset1_th_1 sorry
    assume "x1 <>HIDDENR2 x2"
    thus "cardCARD-1K4 {TARSKIK2 x1,x2 } =XBOOLE-0R4 \<two>\<^sub>M"
      using A1 A2 card_2_th_40 zfmisc_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_58:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds (x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x2 <>HIDDENR2 x3 implies cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 \<three>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds (x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x2 <>HIDDENR2 x3 implies cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    assume "(x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x2 <>HIDDENR2 x3"
    then have A1: "cardCARD-1K4 {TARSKIK2 x1,x2 } =XBOOLE-0R4 \<two>\<^sub>M &  not x3 inHIDDENR3 {TARSKIK2 x1,x2 }"
      using card_2_th_57 tarski_def_2 sorry
    have "{ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3}"
      using enumset1_th_3 sorry
    then have "cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 \<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 card_2_th_41 sorry
    also have "... = \<three>\<^sub>M"
       sorry
    finally show "cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_59:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds ((((x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x1 <>HIDDENR2 x4) & x2 <>HIDDENR2 x3) & x2 <>HIDDENR2 x4) & x3 <>HIDDENR2 x4 implies cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 \<four>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds ((((x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x1 <>HIDDENR2 x4) & x2 <>HIDDENR2 x3) & x2 <>HIDDENR2 x4) & x3 <>HIDDENR2 x4 implies cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 \<four>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    assume "((((x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3) & x1 <>HIDDENR2 x4) & x2 <>HIDDENR2 x3) & x2 <>HIDDENR2 x4) & x3 <>HIDDENR2 x4"
    then have A1: "cardCARD-1K4 {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 \<three>\<^sub>M &  not x4 inHIDDENR3 {ENUMSET1K1 x1,x2,x3 }"
      using card_2_th_58 enumset1_def_1 sorry
    have "{ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_6 sorry
    then have "cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 card_2_th_41 sorry
    also have "... = \<four>\<^sub>M"
       sorry
    finally show "cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 \<four>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem card_2_th_60:
" for X be setHIDDENM2 holds cardCARD-1K1 X =XBOOLE-0R4 \<two>\<^sub>M implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st x <>HIDDENR2 y & X =XBOOLE-0R4 {TARSKIK2 x,y })"
proof-
  have " for X be setHIDDENM2 holds cardCARD-1K1 X =XBOOLE-0R4 \<two>\<^sub>M implies ( ex tVar13 be objectHIDDENM1 st  ex tVar14 be objectHIDDENM1 st tVar13 <>HIDDENR2 tVar14 & X =XBOOLE-0R4 {TARSKIK2 tVar13,tVar14 })"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "cardCARD-1K1 X =XBOOLE-0R4 \<two>\<^sub>M"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 X"
      using card_1_th_27 xboole_0_def_1 sorry
    have "X be finiteFINSET-1V1"
      using A1 sorry
    then obtain Y where 
      [ty]:"Y be finiteFINSET-1V1\<bar>setHIDDENM2" and YDef:"Y = X"
       sorry
    have "{TARSKIK1 x} c=TARSKIR1 X"
      using A2 zfmisc_1_th_31 sorry
    then have "cardCARD-1K1 (X \\SUBSET-1K6 {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 Y -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 x}"
      using card_2_th_44 sorry
    also have "... = \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 card_1_th_30 sorry
    finally have "cardCARD-1K1 (X \\SUBSET-1K6 {TARSKIK1 x}) =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A3: "X \\SUBSET-1K6 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK1 y}"
      using card_2_th_42 sorry
    show " ex tVar13 be objectHIDDENM1 st  ex tVar14 be objectHIDDENM1 st tVar13 <>HIDDENR2 tVar14 & X =XBOOLE-0R4 {TARSKIK2 tVar13,tVar14 }"
    proof(rule bexI[of _ "x"])
      show " ex tVar14 be objectHIDDENM1 st x <>HIDDENR2 tVar14 & X =XBOOLE-0R4 {TARSKIK2 x,tVar14 }"
      proof(rule bexI[of _ "y"],rule conjMI)
        have "x inHIDDENR3 {TARSKIK1 x}"
          using tarski_def_1 sorry
        thus "x <>HIDDENR2 y"
          using A3 xboole_0_def_5 sorry
        have "X c=TARSKIR1 {TARSKIK2 x,y } & {TARSKIK2 x,y } c=TARSKIR1 X"
        proof(rule conjMI)
          show "X c=TARSKIR1 {TARSKIK2 x,y }"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 X implies z inHIDDENR3 {TARSKIK2 x,y }"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume A4: "z inHIDDENR3 X"
              show "z inHIDDENR3 {TARSKIK2 x,y }"
              proof-
                have cases: "z =HIDDENR1 x or z <>HIDDENR2 x"
                   sorry
                have case1: "z =HIDDENR1 x implies z inHIDDENR3 {TARSKIK2 x,y }"
                proof(rule impI)
                  assume "z =HIDDENR1 x"
                  thus "z inHIDDENR3 {TARSKIK2 x,y }"
                    using tarski_def_2 sorry
                qed
                have case2: "z <>HIDDENR2 x implies z inHIDDENR3 {TARSKIK2 x,y }"
                proof(rule impI)
                  assume "z <>HIDDENR2 x"
                  then have " not z inHIDDENR3 {TARSKIK1 x}"
                    using tarski_def_1 sorry
                  then have "z inHIDDENR3 {TARSKIK1 y}"
                    using A3 A4 xboole_0_def_5 sorry
                  then have "z =HIDDENR1 y"
                    using tarski_def_1 sorry
                  thus "z inHIDDENR3 {TARSKIK2 x,y }"
                    using tarski_def_2 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "X c=TARSKIR1 {TARSKIK2 x,y }"
              using tarski_def_3 sorry
          qed
          have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z inHIDDENR3 X"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 {TARSKIK2 x,y }"
            then have A5: "z =HIDDENR1 x or z =HIDDENR1 y"
              using tarski_def_2 sorry
            have "y inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x}"
              using A3 tarski_def_1 sorry
            thus "z inHIDDENR3 X"
              using A2 A5 sorry
          qed "sorry"
          thus "{TARSKIK2 x,y } c=TARSKIR1 X"
            using tarski_def_3 sorry
        qed
        thus "X =XBOOLE-0R4 {TARSKIK2 x,y }"
          using xboole_0_def_10 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_61:
" for f be FunctionFUNCT-1M1 holds cardCARD-1K1 (rngFUNCT-1K2 f) c=ORDINAL1R1 cardCARD-1K1 (domRELAT-1K1 f)"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "rngFUNCT-1K2 f =XBOOLE-0R4 f .:FUNCT-1K5 domRELAT-1K1 f"
    using relat_1_th_113 sorry
  thus "cardCARD-1K1 (rngFUNCT-1K2 f) c=ORDINAL1R1 cardCARD-1K1 (domRELAT-1K1 f)"
    using card_1_th_66 sorry
qed "sorry"

mlemma card_2_lm_5:
" for n be NatORDINAL1M6 holds ( for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (cardCARD-1K4 Z =XBOOLE-0R4 n & Z <>HIDDENR2 {}XBOOLE-0K1) & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Z & Y inTARSKIR2 Z implies X c=TARSKIR1 Y or Y c=TARSKIR1 X) implies unionTARSKIK3 Z inTARSKIR2 Z) implies ( for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 Z =XBOOLE-0R4 n +XCMPLX-0K2 \<one>\<^sub>M & (Z <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Z & Y inTARSKIR2 Z implies X c=TARSKIR1 Y or Y c=TARSKIR1 X)) implies unionTARSKIK3 Z inTARSKIR2 Z)"
proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impMI ,rule impI)
  fix n assume [ty]: "n be NatORDINAL1M6"
  assume A1: " for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (cardCARD-1K4 Z =XBOOLE-0R4 n & Z <>HIDDENR2 {}XBOOLE-0K1) & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Z & Y inTARSKIR2 Z implies X c=TARSKIR1 Y or Y c=TARSKIR1 X) implies unionTARSKIK3 Z inTARSKIR2 Z"
  fix Z assume [ty]: "Z be finiteFINSET-1V1\<bar>setHIDDENM2"
  assume A2: "cardCARD-1K4 Z =XBOOLE-0R4 n +XCMPLX-0K2 \<one>\<^sub>M"
    and A3: "Z <>HIDDENR2 {}XBOOLE-0K1"
    and A4: " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Z & Y inTARSKIR2 Z implies X c=TARSKIR1 Y or Y c=TARSKIR1 X"
  let ?y = "the ElementSUBSET-1M1-of Z"
  show "unionTARSKIK3 Z inTARSKIR2 Z"
  proof-
    have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies unionTARSKIK3 Z inTARSKIR2 Z"
    proof(rule impI)
      assume "n =XBOOLE-0R4 0NUMBERSK6"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "Z =XBOOLE-0R4 {TARSKIK1 x}"
        using A2 card_2_th_42 sorry
      show "unionTARSKIK3 Z inTARSKIR2 Z"
        using A5 tarski_def_1 sorry
    qed
    have case2: "n <>HIDDENR2 0NUMBERSK6 implies unionTARSKIK3 Z inTARSKIR2 Z"
    proof(rule impI)
      assume A6: "n <>HIDDENR2 0NUMBERSK6"
      let ?Y = "Z \\SUBSET-1K6 {TARSKIK1 ?y}"
      obtain Y where 
        [ty]:"Y be finiteFINSET-1V1\<bar>setHIDDENM2" and YDef:"Y = ?Y"
         sorry
      have "{TARSKIK1 ?y} c=TARSKIR1 Z"
        using A3 zfmisc_1_th_31 sorry
      then have A7: "cardCARD-1K4 Y =HIDDENR1 (n +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 ?y}"
        using A2 card_2_th_44 sorry
      also have "... = (n +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
        using card_1_th_30 sorry
      also have "... = n"
         sorry
      finally have "cardCARD-1K4 Y =HIDDENR1 n"
         sorry
      have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds a inTARSKIR2 Y & b inTARSKIR2 Y implies a c=TARSKIR1 b or b c=TARSKIR1 a"
        using A4 sorry
      then have A8: "unionTARSKIK3 Y inTARSKIR2 Y"
        using A1 A6 A7 card_1_th_27 sorry
      then have A9: "unionTARSKIK3 Y inTARSKIR2 Z"
         sorry
      have "Z =XBOOLE-0R4 (Z \\SUBSET-1K6 {TARSKIK1 ?y})\\/XBOOLE-0K2 {TARSKIK1 ?y}"
      proof-
        have "Z =XBOOLE-0R4 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z }"
        proof-
          have "Z c=TARSKIR1 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z } & (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z } c=TARSKIR1 Z"
          proof(rule conjMI)
            show "Z c=TARSKIR1 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 Z implies x inHIDDENR3 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 Z"
                then have "x inHIDDENR3 Z \\SUBSET-1K6 {TARSKIK1 ?y} or x inHIDDENR3 {TARSKIK1 ?y}"
                  using xboole_0_def_5 sorry
                thus "x inHIDDENR3 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z }"
                  using xboole_0_def_3 sorry
              qed "sorry"
              thus "Z c=TARSKIR1 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z }"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z } implies x inHIDDENR3 Z"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 (Z \\SUBSET-1K6 {TARSKIK1 ?y})\\/XBOOLE-0K2 {TARSKIK1 ?y}"
              then have A10: "x inHIDDENR3 Z \\SUBSET-1K6 {TARSKIK1 ?y} or x inHIDDENR3 {TARSKIK1 ?y}"
                using xboole_0_def_3 sorry
              have "{TARSKIK1 ?y} c=TARSKIR1 Z"
                using A3 zfmisc_1_th_31 sorry
              thus "x inHIDDENR3 Z"
                using A10 sorry
            qed "sorry"
            thus "(Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z } c=TARSKIR1 Z"
              using tarski_def_3 sorry
          qed
          thus "Z =XBOOLE-0R4 (Z \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of Z })\\/XBOOLE-0K2 {TARSKIK1 the ElementSUBSET-1M1-of Z }"
            using xboole_0_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then have A11: "unionTARSKIK3 Z =HIDDENR1 unionTARSKIK3 Y \\/XBOOLE-0K2 unionTARSKIK3 {TARSKIK1 ?y}"
        using zfmisc_1_th_78 sorry
      also have "... = unionTARSKIK3 Y \\/XBOOLE-0K2 ?y"
         sorry
      finally have "unionTARSKIK3 Z =HIDDENR1 unionTARSKIK3 Y \\/XBOOLE-0K2 ?y"
         sorry
      have A12: "?y inTARSKIR2 Z"
        using A3 sorry
      have "?y c=TARSKIR1 unionTARSKIK3 Y or unionTARSKIK3 Y c=TARSKIR1 ?y"
        using A4 A8 sorry
      thus "unionTARSKIK3 Z inTARSKIR2 Z"
        using A9 A12 A11 xboole_1_th_12 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mlemma card_2_lm_6:
" for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Z & Y inTARSKIR2 Z implies X c=TARSKIR1 Y or Y c=TARSKIR1 X) implies unionTARSKIK3 Z inTARSKIR2 Z"
proof-
  have " for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds  not (( not Z <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (((X inTARSKIR2 Z & Y inTARSKIR2 Z) &  not X c=TARSKIR1 Y) &  not Y c=TARSKIR1 X))) &  not unionTARSKIK3 Z inTARSKIR2 Z)"
  proof(rule ballI)
    let ?P = "\<lambda>Lamb1.  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (cardCARD-1K4 Z =XBOOLE-0R4 Lamb1 & Z <>HIDDENR2 {}XBOOLE-0K1) & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Z & Y inTARSKIR2 Z implies X c=TARSKIR1 Y or Y c=TARSKIR1 X) implies unionTARSKIK3 Z inTARSKIR2 Z"
    fix Z assume [ty]: "Z be finiteFINSET-1V1\<bar>setHIDDENM2"
    have A1: "cardCARD-1K4 Z =XBOOLE-0R4 cardCARD-1K4 Z"
       sorry
    have A2: "?P(0NUMBERSK6)"
       sorry
    have A3: " for k be NatORDINAL1M6 holds ?P(k) implies ?P(k +XCMPLX-0K2 \<one>\<^sub>M)"
      using card_2_lm_5 sorry
    have " for n be NatORDINAL1M6 holds ?P(n)"
      using nat_1_sch_2 A2 A3 sorry
    thus " not (( not Z <>HIDDENR2 {}XBOOLE-0K1 & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (((X inTARSKIR2 Z & Y inTARSKIR2 Z) &  not X c=TARSKIR1 Y) &  not Y c=TARSKIR1 X))) &  not unionTARSKIK3 Z inTARSKIR2 Z)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_62:
" for Z be setHIDDENM2 holds (Z <>HIDDENR2 {}XBOOLE-0K1 & Z be finiteFINSET-1V1) & ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 Z & Y inTARSKIR2 Z implies X c=TARSKIR1 Y or Y c=TARSKIR1 X) implies unionTARSKIK3 Z inTARSKIR2 Z"
  using card_2_lm_6 sorry

mtheorem card_2_th_63:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds (x1,x2,x3,x4,x5)are-mutually-distinctZFMISC-1R3 implies cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 \<five>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds (x1,x2,x3,x4,x5)are-mutually-distinctZFMISC-1R3 implies cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 \<five>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have A1: "{ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5}"
      using enumset1_th_10 sorry
    assume A2: "(x1,x2,x3,x4,x5)are-mutually-distinctZFMISC-1R3"
    then have A3: "x3 <>HIDDENR2 x5 & x4 <>HIDDENR2 x5"
      using zfmisc_1_def_7 sorry
    have A4: "x2 <>HIDDENR2 x4 & x3 <>HIDDENR2 x4"
      using A2 zfmisc_1_def_7 sorry
    have A5: "x1 <>HIDDENR2 x4 & x2 <>HIDDENR2 x3"
      using A2 zfmisc_1_def_7 sorry
    have "x1 <>HIDDENR2 x5 & x2 <>HIDDENR2 x5"
      using A2 zfmisc_1_def_7 sorry
    then have A6: " not x5 inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 }"
      using A3 enumset1_def_2 sorry
    have "x1 <>HIDDENR2 x2 & x1 <>HIDDENR2 x3"
      using A2 zfmisc_1_def_7 sorry
    then have "cardCARD-1K4 {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 \<four>\<^sub>M"
      using A5 A4 card_2_th_59 sorry
    then have "cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 \<four>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
      using A6 A1 card_2_th_41 sorry
    also have "... = \<five>\<^sub>M"
       sorry
    finally show "cardCARD-1K4 {ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 \<five>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_64:
" for M1 be setHIDDENM2 holds  for M2 be setHIDDENM2 holds cardCARD-1K1 M1 =XBOOLE-0R4 0NUMBERSK6 & cardCARD-1K1 M2 =XBOOLE-0R4 0NUMBERSK6 implies M1 =XBOOLE-0R4 M2"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix M1 assume [ty]: "M1 be setHIDDENM2"
  fix M2 assume [ty]: "M2 be setHIDDENM2"
  assume A1: "cardCARD-1K1 M1 =XBOOLE-0R4 0NUMBERSK6"
    and A2: "cardCARD-1K1 M2 =XBOOLE-0R4 0NUMBERSK6"
  have "M1 =XBOOLE-0R4 {}XBOOLE-0K1"
    using A1 sorry
  thus "M1 =XBOOLE-0R4 M2"
    using A2 sorry
qed "sorry"

mtheorem card_2_cl_1:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster [TARSKIK4 x,y ] as-term-is  non naturalORDINAL1V7"
proof
(*coherence*)
  show "[TARSKIK4 x,y ] be  non naturalORDINAL1V7"
  proof-
    have "[TARSKIK4 x,y ] be naturalORDINAL1V7 implies  False "
    proof(rule impI)
      assume "[TARSKIK4 x,y ] be naturalORDINAL1V7"
      then obtain n where 
        [ty]:"n be NatORDINAL1M6" and nDef:"n = [TARSKIK4 x,y ]"
         sorry
      have "cardCARD-1K4 n <=XXREAL-0R1 \<two>\<^sub>M"
        using card_2_th_50 sorry
      then have "n <=XXREAL-0R1 \<two>\<^sub>M"
         sorry
      then have Cut1546: " ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & n =XBOOLE-0R4 VarFor1"
         sorry
      show " False "
      proof-
        have cases: "(n =XBOOLE-0R4 0NUMBERSK6 or n =XBOOLE-0R4 \<one>\<^sub>M) or n =XBOOLE-0R4 \<two>\<^sub>M"
          using Cut1546 sorry
        have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "n =XBOOLE-0R4 0NUMBERSK6"
          thus " False "
             sorry
        qed
        have case2: "n =XBOOLE-0R4 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "n =XBOOLE-0R4 \<one>\<^sub>M"
          thus " False "
            using card_1_th_49 zfmisc_1_th_4 sorry
        qed
        have case3: "n =XBOOLE-0R4 \<two>\<^sub>M implies  False "
        proof(rule impI)
          assume "n =XBOOLE-0R4 \<two>\<^sub>M"
          thus " False "
            using card_1_th_50 zfmisc_1_th_6 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
reserve A, B, C for "OrdinalORDINAL1M3"
reserve K, L, M, N for "CardinalCARD-1M1"
reserve x, y, y1, y2, z, u for "objectHIDDENM1"
reserve X, Y, Z, Z1, Z2 for "setHIDDENM2"
reserve n for "NatORDINAL1M6"
reserve f, f1, g, h for "FunctionFUNCT-1M1"
mtheorem card_2_th_65:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds SumCARD-3K6 (M -->FUNCOP-1K7 N) =XBOOLE-0R4 M *`CARD-2K2 N"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds SumCARD-3K6 (M -->FUNCOP-1K7 N) =HIDDENR1 M *`CARD-2K2 N"
  proof(rule ballI,rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have "SumCARD-3K6 (M -->FUNCOP-1K7 N) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 N,M :])"
      using card_3_th_25 sorry
    also have "... = M *`CARD-2K2 N"
      using card_2_lm_2 sorry
    finally show "SumCARD-3K6 (M -->FUNCOP-1K7 N) =HIDDENR1 M *`CARD-2K2 N"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_66:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ProductCARD-3K7 (N -->FUNCOP-1K7 M) =XBOOLE-0R4 expCARD-2K3(M,N)"
  using card_3_th_11 sorry

theorem card_2_sch_1:
  fixes Xf0 Pp2 
  assumes
[ty]: "Xf0 be finiteFINSET-1V1\<bar>setHIDDENM2" and
   A1: "Xf0 <>HIDDENR2 {}XBOOLE-0K1" and
   A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds Pp2(x,y) & Pp2(y,x) implies x =HIDDENR1 y" and
   A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds Pp2(x,y) & Pp2(y,z) implies Pp2(x,z)"
  shows " ex x be objectHIDDENM1 st x inHIDDENR3 Xf0 & ( for y be objectHIDDENM1 holds y inHIDDENR3 Xf0 & y <>HIDDENR2 x implies  not Pp2(y,x))"
  proof-
    have " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 Xf0 &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
    proof-
      let ?Q = "\<lambda>Lamb1.  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 Lamb1 & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X & y <>HIDDENR2 x implies  not Pp2(y,x)))"
      have A4: "?Q(0NUMBERSK6)"
         sorry
      have A5: " for n be NatORDINAL1M6 holds ?Q(n) implies ?Q(n +XCMPLX-0K2 \<one>\<^sub>M)"
      proof-
        have " for n be NatORDINAL1M6 holds ( for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 n & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X & y <>HIDDENR2 x implies  not Pp2(y,x)))) implies ( for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 n +XCMPLX-0K2 \<one>\<^sub>M & X <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x))))))"
        proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatORDINAL1M6"
          assume A6: " for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 n & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X & y <>HIDDENR2 x implies  not Pp2(y,x)))"
          fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
          assume A7: "cardCARD-1K4 X =XBOOLE-0R4 n +XCMPLX-0K2 \<one>\<^sub>M"
            and A8: "X <>HIDDENR2 {}XBOOLE-0K1"
          let ?x = "the ElementSUBSET-1M1-of X"
          have A9: "X \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of X } =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
          proof(rule impI)
            assume "X \\SUBSET-1K6 {TARSKIK1 ?x} =XBOOLE-0R4 {}XBOOLE-0K1"
            then have A10: "X c=TARSKIR1 {TARSKIK1 ?x}"
              using xboole_1_th_37 sorry
            show " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
            proof-
              have " ex tVar15 be objectHIDDENM1 st tVar15 inTARSKIR2 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 tVar15) & Pp2(y,tVar15)))"
              proof-
                show " ex tVar15 be objectHIDDENM1 st tVar15 inTARSKIR2 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 tVar15) & Pp2(y,tVar15)))"
                proof(rule bexI[of _ "?x"],rule conjMI)
                  show "the ElementSUBSET-1M1-of X inTARSKIR2 X"
                    using A8 sorry
                  show " for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 the ElementSUBSET-1M1-of X) & Pp2(y,the ElementSUBSET-1M1-of X))"
                    using A10 tarski_def_1 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
          qed
          have "X \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of X } <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
          proof(rule impI)
            assume A11: "X \\SUBSET-1K6 {TARSKIK1 ?x} <>HIDDENR2 {}XBOOLE-0K1"
            have "{TARSKIK1 ?x} c=TARSKIR1 X"
              using A8 zfmisc_1_th_31 sorry
            then have A12: "cardCARD-1K4 (X \\SUBSET-1K6 {TARSKIK1 ?x}) =XBOOLE-0R4 (n +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 ?x}"
              using A7 card_2_th_44 sorry
            have "cardCARD-1K4 {TARSKIK1 ?x} =XBOOLE-0R4 \<one>\<^sub>M"
              using card_1_th_30 sorry
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A13: "y inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 ?x}"and A14: " for z be objectHIDDENM1 holds z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 ?x} & z <>HIDDENR2 y implies  not Pp2(z,y)"
              using A6 A11 A12 sorry
            have A15: "Pp2(the ElementSUBSET-1M1-of X,y) implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
            proof(rule impI)
              assume A16: "Pp2(?x,y)"
              show " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
              proof-
                have " ex tVar16 be objectHIDDENM1 st tVar16 inTARSKIR2 X & ( for z be objectHIDDENM1 holds z inHIDDENR3 X & (z <>HIDDENR2 tVar16 & Pp2(z,tVar16)) implies  False )"
                proof-
                  show " ex tVar16 be objectHIDDENM1 st tVar16 inTARSKIR2 X & ( for z be objectHIDDENM1 holds z inHIDDENR3 X & (z <>HIDDENR2 tVar16 & Pp2(z,tVar16)) implies  False )"
                  proof(rule bexI[of _ "?x"],rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
                    show "the ElementSUBSET-1M1-of X inTARSKIR2 X"
                      using A8 sorry
                    fix z assume [ty]: "z be objectHIDDENM1"
                    assume A17: "z inHIDDENR3 X"
                      and A18: "z <>HIDDENR2 ?x"
                      and A19: "Pp2(z,?x)"
                    have " not z inHIDDENR3 {TARSKIK1 ?x}"
                      using A18 tarski_def_1 sorry
                    then have A20: "z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 ?x}"
                      using A17 xboole_0_def_5 sorry
                    have A21: " not y inHIDDENR3 {TARSKIK1 ?x}"
                      using A13 xboole_0_def_5 sorry
                    have A22: "z =HIDDENR1 y"
                      using A3 A14 A16 A19 A20 sorry
                    have "y <>HIDDENR2 ?x"
                      using A21 tarski_def_1 sorry
                    thus " False "
                      using A2 A16 A19 A22 sorry
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
            qed
            have " not Pp2(the ElementSUBSET-1M1-of X,y) implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
            proof(rule impI)
              assume A23: " not Pp2(?x,y)"
              show " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
              proof-
                have " ex tVar17 be objectHIDDENM1 st tVar17 inHIDDENR3 X & ( for z be objectHIDDENM1 holds z inHIDDENR3 X & z <>HIDDENR2 tVar17 implies  not Pp2(z,tVar17))"
                proof-
                  show " ex tVar17 be objectHIDDENM1 st tVar17 inHIDDENR3 X & ( for z be objectHIDDENM1 holds z inHIDDENR3 X & z <>HIDDENR2 tVar17 implies  not Pp2(z,tVar17))"
                  proof(rule bexI[of _ "y"],rule conjMI,rule ballI,rule impMI ,rule impI)
                    show "y inHIDDENR3 X"
                      using A13 sorry
                    fix z assume [ty]: "z be objectHIDDENM1"
                    assume A24: "z inHIDDENR3 X"
                      and A25: "z <>HIDDENR2 y"
                    have "z inHIDDENR3 {TARSKIK1 ?x} or  not z inHIDDENR3 {TARSKIK1 ?x}"
                       sorry
                    then have "z =HIDDENR1 ?x or z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 ?x}"
                      using A24 tarski_def_1 xboole_0_def_5 sorry
                    thus " not Pp2(z,y)"
                      using A14 A23 A25 sorry
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
            qed
            thus " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
              using A15 sorry
          qed
          thus " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 X &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
            using A9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A26: " for n be NatORDINAL1M6 holds ?Q(n)"
        using nat_1_sch_2 A4 A5 sorry
      have "cardCARD-1K4 Xf0 =XBOOLE-0R4 cardCARD-1K4 Xf0"
         sorry
      thus " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 & ( for y be objectHIDDENM1 holds  not ((y inHIDDENR3 Xf0 &  not y <>HIDDENR2 x) & Pp2(y,x)))))"
        using A1 A26 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem card_2_sch_2:
  fixes Xf0 Pp2 
  assumes
[ty]: "Xf0 be finiteFINSET-1V1\<bar>setHIDDENM2" and
   A1: "Xf0 <>HIDDENR2 {}XBOOLE-0K1" and
   A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds Pp2(x,y) or Pp2(y,x)" and
   A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds Pp2(x,y) & Pp2(y,z) implies Pp2(x,z)"
  shows " ex x be objectHIDDENM1 st x inHIDDENR3 Xf0 & ( for y be objectHIDDENM1 holds y inHIDDENR3 Xf0 implies Pp2(x,y))"
  proof-
    have " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Xf0 &  not Pp2(x,y)))))"
    proof-
      let ?Q = "\<lambda>Lamb1.  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 Lamb1 & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies Pp2(x,y)))"
      have A4: "?Q(0NUMBERSK6)"
         sorry
      have A5: " for n be NatORDINAL1M6 holds ?Q(n) implies ?Q(n +XCMPLX-0K2 \<one>\<^sub>M)"
      proof-
        have " for n be NatORDINAL1M6 holds ( for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 n & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies Pp2(x,y)))) implies ( for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 n +XCMPLX-0K2 \<one>\<^sub>M & X <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not Pp2(x,y))))))"
        proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatORDINAL1M6"
          assume A6: " for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 X =XBOOLE-0R4 n & X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies Pp2(x,y)))"
          fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
          assume A7: "cardCARD-1K4 X =XBOOLE-0R4 n +XCMPLX-0K2 \<one>\<^sub>M"
            and A8: "X <>HIDDENR2 {}XBOOLE-0K1"
          let ?x = "the ElementSUBSET-1M1-of X"
          have A9: "X \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of X } =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not Pp2(x,y)))))"
          proof(rule impI)
            assume "X \\SUBSET-1K6 {TARSKIK1 ?x} =XBOOLE-0R4 {}XBOOLE-0K1"
            then have A10: "X c=TARSKIR1 {TARSKIK1 ?x}"
              using xboole_1_th_37 sorry
            show " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not Pp2(x,y)))))"
            proof-
              have " ex tVar18 be objectHIDDENM1 st tVar18 inTARSKIR2 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies Pp2(tVar18,y))"
              proof-
                show " ex tVar18 be objectHIDDENM1 st tVar18 inTARSKIR2 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies Pp2(tVar18,y))"
                proof(rule bexI[of _ "?x"],rule conjMI,rule ballI,rule impI)
                  show "the ElementSUBSET-1M1-of X inTARSKIR2 X"
                    using A8 sorry
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume "y inHIDDENR3 X"
                  then have "y =HIDDENR1 ?x"
                    using A10 tarski_def_1 sorry
                  thus "Pp2(the ElementSUBSET-1M1-of X,y)"
                    using A2 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
          qed
          have "X \\SUBSET-1K6 {TARSKIK1 the ElementSUBSET-1M1-of X } <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not Pp2(x,y)))))"
          proof(rule impI)
            assume A11: "X \\SUBSET-1K6 {TARSKIK1 ?x} <>HIDDENR2 {}XBOOLE-0K1"
            have "{TARSKIK1 ?x} c=TARSKIR1 X"
              using A8 zfmisc_1_th_31 sorry
            then have A12: "cardCARD-1K4 (X \\SUBSET-1K6 {TARSKIK1 ?x}) =XBOOLE-0R4 (n +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 ?x}"
              using A7 card_2_th_44 sorry
            have "cardCARD-1K4 {TARSKIK1 ?x} =XBOOLE-0R4 \<one>\<^sub>M"
              using card_1_th_30 sorry
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A13: "y inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 ?x}"and A14: " for z be objectHIDDENM1 holds z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 ?x} implies Pp2(y,z)"
              using A6 A11 A12 sorry
            have A15: "Pp2(?x,y) or Pp2(y,?x)"
              using A2 sorry
            have A16: "Pp2(?x,?x)"
              using A2 sorry
            have "Pp2(y,y)"
              using A2 sorry
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A17: "z =HIDDENR1 ?x or z =HIDDENR1 y"and A18: "Pp2(z,?x)"and A19: "Pp2(z,y)"
              using A15 A16 sorry
            show " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not Pp2(x,y)))))"
            proof-
              have " ex tVar19 be objectHIDDENM1 st tVar19 inHIDDENR3 X & ( for u be objectHIDDENM1 holds u inHIDDENR3 X implies Pp2(tVar19,u))"
              proof-
                show " ex tVar19 be objectHIDDENM1 st tVar19 inHIDDENR3 X & ( for u be objectHIDDENM1 holds u inHIDDENR3 X implies Pp2(tVar19,u))"
                proof(rule bexI[of _ "z"],rule conjMI,rule ballI,rule impI)
                  show "z inHIDDENR3 X"
                    using A13 A17 sorry
                  fix u assume [ty]: "u be objectHIDDENM1"
                  have A20: "u inHIDDENR3 {TARSKIK1 ?x} or  not u inHIDDENR3 {TARSKIK1 ?x}"
                     sorry
                  assume "u inHIDDENR3 X"
                  then have "u =HIDDENR1 ?x or u inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 ?x}"
                    using A20 tarski_def_1 xboole_0_def_5 sorry
                  then have "Pp2(z,u) or Pp2(y,u)"
                    using A14 A18 sorry
                  thus "Pp2(z,u)"
                    using A3 A19 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
          qed
          thus " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not Pp2(x,y)))))"
            using A9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A21: " for n be NatORDINAL1M6 holds ?Q(n)"
        using nat_1_sch_2 A4 A5 sorry
      have "cardCARD-1K4 Xf0 =XBOOLE-0R4 cardCARD-1K4 Xf0"
         sorry
      thus " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Xf0 &  not Pp2(x,y)))))"
        using A1 A21 sorry
    qed
    thus " ?thesis "
       sorry
  qed

mlemma card_2_lm_7:
" for n be NatORDINAL1M6 holds RankCLASSES1K4 n be finiteFINSET-1V1 implies RankCLASSES1K4 (n +XCMPLX-0K2 \<one>\<^sub>M) be finiteFINSET-1V1"
proof-
  have " for n be NatORDINAL1M6 holds  not (RankCLASSES1K4 n be finiteFINSET-1V1 &  not RankCLASSES1K4 (n +XCMPLX-0K2 \<one>\<^sub>M) be finiteFINSET-1V1)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatORDINAL1M6"
    have "SegmCARD-1K5 (n +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 n)"
      using nat_1_th_38 sorry
    then have "RankCLASSES1K4 (n +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 boolZFMISC-1K1 RankCLASSES1K4 n"
      using classes1_th_30 sorry
    thus " not (RankCLASSES1K4 n be finiteFINSET-1V1 &  not RankCLASSES1K4 (n +XCMPLX-0K2 \<one>\<^sub>M) be finiteFINSET-1V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_2_lm_8:
"\<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 \<one>\<^sub>M"
   sorry

mtheorem card_2_th_67:
" for n be NatORDINAL1M6 holds RankCLASSES1K4 n be finiteFINSET-1V1"
proof-
  have " for n be NatORDINAL1M6 holds RankCLASSES1K4 n be finiteFINSET-1V1"
  proof(rule ballI)
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1. RankCLASSES1K4 Lamb1 be finiteFINSET-1V1"
    have A1: "?P(0NUMBERSK6)"
      using classes1_th_29 sorry
    have A2: " for n be NatORDINAL1M6 holds ?P(n) implies ?P(n +XCMPLX-0K2 \<one>\<^sub>M)"
      using card_2_lm_7 sorry
    have " for n be NatORDINAL1M6 holds ?P(n)"
      using nat_1_sch_2 A1 A2 sorry
    thus "RankCLASSES1K4 n be finiteFINSET-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_68:
" for M be CardinalCARD-1M1 holds 0NUMBERSK6 inTARSKIR2 M iff \<one>\<^sub>M c=ORDINAL1R1 M"
proof-
  have " for M be CardinalCARD-1M1 holds  not (0NUMBERSK6 inTARSKIR2 M &  not \<one>\<^sub>M c=ORDINAL1R1 M) &  not (\<one>\<^sub>M c=ORDINAL1R1 M &  not 0NUMBERSK6 inTARSKIR2 M)"
  proof(rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    then have "nextcardCARD-1K2 (cardCARD-1K4 (SegmCARD-1K5 (0NUMBERSK6))) =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 \<one>\<^sub>M)"
      using nat_1_th_42 sorry
    thus " not (0NUMBERSK6 inTARSKIR2 M &  not \<one>\<^sub>M c=ORDINAL1R1 M) &  not (\<one>\<^sub>M c=ORDINAL1R1 M &  not 0NUMBERSK6 inTARSKIR2 M)"
      using card_3_th_90 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_69:
" for M be CardinalCARD-1M1 holds \<one>\<^sub>M inTARSKIR2 M iff \<two>\<^sub>M c=ORDINAL1R1 M"
proof-
  have " for M be CardinalCARD-1M1 holds  not (\<one>\<^sub>M inTARSKIR2 M &  not \<two>\<^sub>M c=ORDINAL1R1 M) &  not (\<two>\<^sub>M c=ORDINAL1R1 M &  not \<one>\<^sub>M inTARSKIR2 M)"
  proof(rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    have "\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
       sorry
    then have "nextcardCARD-1K2 (cardCARD-1K4 (SegmCARD-1K5 \<one>\<^sub>M)) =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 \<two>\<^sub>M)"
      using nat_1_th_42 sorry
    thus " not (\<one>\<^sub>M inTARSKIR2 M &  not \<two>\<^sub>M c=ORDINAL1R1 M) &  not (\<two>\<^sub>M c=ORDINAL1R1 M &  not \<one>\<^sub>M inTARSKIR2 M)"
      using card_3_th_90 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve n, k for "NatORDINAL1M6"
mtheorem card_2_th_70:
" for A be OrdinalORDINAL1M3 holds A be limit-ordinalORDINAL1V4 iff ( for B be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds B inTARSKIR2 A implies B +^ORDINAL2K10 n inTARSKIR2 A)"
proof-
  have " for A be OrdinalORDINAL1M3 holds (A be limit-ordinalORDINAL1V4 implies ( for B be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds B inTARSKIR2 A implies B +^ORDINAL2K10 n inTARSKIR2 A)) & (( for B be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds B inTARSKIR2 A implies B +^ORDINAL2K10 n inTARSKIR2 A) implies A be limit-ordinalORDINAL1V4)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "A be limit-ordinalORDINAL1V4 implies ( for B be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds B inTARSKIR2 A implies B +^ORDINAL2K10 n inTARSKIR2 A)"
    proof(rule impI,rule ballI,rule ballI,rule impI)
      assume A1: "A be limit-ordinalORDINAL1V4"
      fix B assume [ty]: "B be OrdinalORDINAL1M3"
      fix n assume [ty]: "n be NatORDINAL1M6"
      let ?P = "\<lambda>Lamb1. B +^ORDINAL2K10 Lamb1 inTARSKIR2 A"
      assume "B inTARSKIR2 A"
      then have A2: "?P(0NUMBERSK6)"
        using ordinal2_th_27 sorry
      have A3: " for k be NatORDINAL1M6 holds ?P(k) implies ?P(k +XCMPLX-0K2 \<one>\<^sub>M)"
      proof-
        have " for k be NatORDINAL1M6 holds  not (B +^ORDINAL2K10 k inTARSKIR2 A &  not B +^ORDINAL2K10 (k +XCMPLX-0K2 \<one>\<^sub>M) inTARSKIR2 A)"
        proof(rule ballI)
          fix k assume [ty]: "k be NatORDINAL1M6"
          have "SegmCARD-1K5 (k +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 k)"
            using nat_1_th_38 sorry
          then have "B +^ORDINAL2K10 (k +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (B +^ORDINAL2K10 k)"
            using ordinal2_th_28 sorry
          thus " not (B +^ORDINAL2K10 k inTARSKIR2 A &  not B +^ORDINAL2K10 (k +XCMPLX-0K2 \<one>\<^sub>M) inTARSKIR2 A)"
            using A1 ordinal1_th_28 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for k be NatORDINAL1M6 holds ?P(k)"
        using nat_1_sch_2 A2 A3 sorry
      thus "B +^ORDINAL2K10 n inTARSKIR2 A"
         sorry
    qed "sorry"
    assume A4: " for B be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds B inTARSKIR2 A implies B +^ORDINAL2K10 n inTARSKIR2 A"
    have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies succORDINAL1K1 B inTARSKIR2 A"
    proof(rule ballI,rule impI)
      fix B assume [ty]: "B be OrdinalORDINAL1M3"
      assume "B inTARSKIR2 A"
      then have "B +^ORDINAL2K10 \<one>\<^sub>M inTARSKIR2 A"
        using A4 sorry
      thus "succORDINAL1K1 B inTARSKIR2 A"
        using ordinal2_th_31 sorry
    qed "sorry"
    thus "A be limit-ordinalORDINAL1V4"
      using ordinal1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_71:
" for A be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds A +^ORDINAL2K10 succORDINAL1K1 n =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 n & A +^ORDINAL2K10 (n +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 n"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds A +^ORDINAL2K10 succORDINAL1K1 n =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 n & A +^ORDINAL2K10 (n +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 n"
  proof(rule ballI,rule ballI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1. A +^ORDINAL2K10 succORDINAL1K1 Lamb1 =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 Lamb1"
    have "A +^ORDINAL2K10 succORDINAL1K1 (0NUMBERSK6) =HIDDENR1 succORDINAL1K1 A"
      using ordinal2_th_31 sorry
    also have "... = succORDINAL1K1 A +^ORDINAL2K10 0NUMBERSK6"
      using ordinal2_th_27 sorry
    finally have "A +^ORDINAL2K10 succORDINAL1K1 (0NUMBERSK6) =HIDDENR1 succORDINAL1K1 A +^ORDINAL2K10 0NUMBERSK6"
       sorry
    then have A1: "?P(0NUMBERSK6)"
       sorry
    have A2: " for k be NatORDINAL1M6 holds ?P(k) implies ?P(k +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for k be NatORDINAL1M6 holds A +^ORDINAL2K10 succORDINAL1K1 k =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 k implies A +^ORDINAL2K10 succORDINAL1K1 (k +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 succORDINAL1K1 A +^ORDINAL2K10 (k +XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatORDINAL1M6"
        assume A3: "?P(k)"
        have A4: "SegmCARD-1K5 (k +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 k)"
          using nat_1_th_38 sorry
        then have "A +^ORDINAL2K10 succORDINAL1K1 (k +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 succORDINAL1K1 (succORDINAL1K1 A +^ORDINAL2K10 k)"
          using A3 ordinal2_th_28 sorry
        also have "... = (succORDINAL1K1 A +^ORDINAL2K10 k)+^ORDINAL2K10 \<one>\<^sub>M"
          using ordinal2_th_31 sorry
        also have "... = succORDINAL1K1 A +^ORDINAL2K10 (k +^ORDINAL3K8 \<one>\<^sub>M)"
          using ordinal3_th_30 sorry
        also have "... = succORDINAL1K1 A +^ORDINAL2K10 (k +XCMPLX-0K2 \<one>\<^sub>M)"
          using A4 ordinal2_th_31 sorry
        finally show "A +^ORDINAL2K10 succORDINAL1K1 (k +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 succORDINAL1K1 A +^ORDINAL2K10 (k +XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for k be NatORDINAL1M6 holds ?P(k)"
      using nat_1_sch_2 A1 A2 sorry
    show A6: "A +^ORDINAL2K10 succORDINAL1K1 n =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 n"
      using A5 sorry
    have "SegmCARD-1K5 (n +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 n)"
      using nat_1_th_38 sorry
    thus "A +^ORDINAL2K10 (n +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 n"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_72:
" for A be OrdinalORDINAL1M3 holds  ex n be NatORDINAL1M6 st A *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 n"
proof-
  have " for A be OrdinalORDINAL1M3 holds  not ( for n be NatORDINAL1M6 holds  not A *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 n)"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1.  ex n be NatORDINAL1M6 st Lamb1 *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 Lamb1 +^ORDINAL2K10 n"
    have "{}XBOOLE-0K1 +^ORDINAL3K8 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
      using ordinal2_th_27 sorry
    then have A1: "?P(0NUMBERSK6)"
      using ordinal2_th_35 sorry
    have A2: " for A be OrdinalORDINAL1M3 holds ?P(A) implies ?P(succORDINAL1K1 A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds ( ex n be NatORDINAL1M6 st A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 n) implies ( ex tVar20 be NatORDINAL1M6 st succORDINAL1K1 A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 tVar20)"
      proof(rule ballI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume Given: " ex n be NatORDINAL1M6 st A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 n"
        then obtain n where
          [ty]:"n be NatORDINAL1M6" and 
          A3: "A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 n"
           sorry
        show " ex tVar20 be NatORDINAL1M6 st succORDINAL1K1 A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 tVar20"
        proof(rule bexI[of _ "n +XCMPLX-0K2 \<one>\<^sub>M"])
          have "succORDINAL1K1 A *^ORDINAL2K11 \<two>\<^sub>M =HIDDENR1 A *^ORDINAL2K11 \<two>\<^sub>M +^ORDINAL2K10 \<two>\<^sub>M"
            using ordinal2_th_36 sorry
          also have "... = succORDINAL1K1 (A *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M +^ORDINAL2K10 \<one>\<^sub>M)"
            using ordinal2_th_28 sorry
          also have "... = succORDINAL1K1 (succORDINAL1K1 (A +^ORDINAL2K10 n))"
            using A3 ordinal2_th_31 sorry
          also have "... = succORDINAL1K1 (A +^ORDINAL2K10 succORDINAL1K1 (SegmCARD-1K5 n))"
            using ordinal2_th_28 sorry
          also have "... = succORDINAL1K1 (A +^ORDINAL2K10 SegmCARD-1K5 (n +XCMPLX-0K2 \<one>\<^sub>M))"
            using nat_1_th_38 sorry
          also have "... = A +^ORDINAL2K10 succORDINAL1K1 (n +XCMPLX-0K2 \<one>\<^sub>M)"
            using ordinal2_th_28 sorry
          finally have "succORDINAL1K1 A *^ORDINAL2K11 \<two>\<^sub>M =HIDDENR1 A +^ORDINAL2K10 succORDINAL1K1 (n +XCMPLX-0K2 \<one>\<^sub>M)"
             sorry
          thus "succORDINAL1K1 A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 A +^ORDINAL2K10 (n +XCMPLX-0K2 \<one>\<^sub>M)"
            using card_2_th_71 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0NUMBERSK6 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0NUMBERSK6 & (A be limit-ordinalORDINAL1V4 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex n be NatORDINAL1M6 st B *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 B +^ORDINAL2K10 n))) implies ( ex tVar21 be NatORDINAL1M6 st A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 tVar21)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A5: "A <>HIDDENR2 0NUMBERSK6"
          and A6: "A be limit-ordinalORDINAL1V4"
          and A7: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)"
        show " ex tVar21 be NatORDINAL1M6 st A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 tVar21"
        proof(rule bexI[of _ "0NUMBERSK6"])
          let ?f = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 \<two>\<^sub>M"
          obtain phi where
            [ty]:"phi be Ordinal-SequenceORDINAL2M1" and 
            A8: "domRELAT-1K1 phi =XBOOLE-0R4 A"and A9: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies phi .FUNCT-1K1 B =XBOOLE-0R4 ?f(B)"
            using ordinal2_sch_3 sorry
          have A10: "A *^ORDINAL2K11 \<two>\<^sub>M =HIDDENR1 unionTARSKIK3 supORDINAL2K4 phi"
            using A5 A6 A8 A9 ordinal2_th_37 sorry
          also have "... = unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 phi)"
            using ordinal2_th_26 sorry
          finally have "A *^ORDINAL2K11 \<two>\<^sub>M =HIDDENR1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 phi)"
             sorry
          have "A *^ORDINAL2K11 \<two>\<^sub>M c=ORDINAL1R1 A +^ORDINAL2K10 0NUMBERSK6 & A +^ORDINAL2K10 0NUMBERSK6 c=TARSKIR1 A *^ORDINAL2K11 \<two>\<^sub>M"
          proof(rule conjMI)
            show "A *^ORDINAL2K11 \<two>\<^sub>M c=ORDINAL1R1 A +^ORDINAL2K10 0NUMBERSK6"
            proof-
              have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A *^ORDINAL2K11 \<two>\<^sub>M implies B inTARSKIR2 A +^ORDINAL2K10 0NUMBERSK6"
              proof(rule ballI,rule impI)
                fix B assume [ty]: "B be OrdinalORDINAL1M3"
                assume "B inTARSKIR2 A *^ORDINAL2K11 \<two>\<^sub>M"
                then obtain X where
                  [ty]:"X be setHIDDENM2" and 
                  A11: "B inTARSKIR2 X"and A12: "X inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 phi)"
                  using A10 tarski_def_4 sorry
                have 
                  [ty]:"X be OrdinalORDINAL1M3"
                  using A12 sorry
                obtain C where
                  [ty]:"C be OrdinalORDINAL1M3" and 
                  A13: "C inTARSKIR2 rngFUNCT-1K2 phi"and A14: "X c=ORDINAL1R1 C"
                  using A12 ordinal2_th_21 sorry
                obtain x where
                  [ty]:"x be objectHIDDENM1" and 
                  A15: "x inHIDDENR3 domRELAT-1K1 phi"and A16: "C =XBOOLE-0R4 phi .FUNCT-1K1 x"
                  using A13 funct_1_def_3 sorry
                have 
                  [ty]:"x be OrdinalORDINAL1M3"
                  using A15 sorry
                have A17: " ex n be NatORDINAL1M6 st x *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 x +^ORDINAL2K10 n"
                  using A7 A8 A15 sorry
                have "C =XBOOLE-0R4 x *^ORDINAL2K11 \<two>\<^sub>M"
                  using A8 A9 A15 A16 sorry
                then have A18: "C inTARSKIR2 A"
                  using A6 A8 A15 A17 card_2_th_70 sorry
                have "A +^ORDINAL2K10 {}XBOOLE-0K1 =XBOOLE-0R4 A"
                  using ordinal2_th_27 sorry
                thus "B inTARSKIR2 A +^ORDINAL2K10 0NUMBERSK6"
                  using A11 A14 A18 ordinal1_th_10 sorry
              qed "sorry"
              thus "A *^ORDINAL2K11 \<two>\<^sub>M c=ORDINAL1R1 A +^ORDINAL2K10 0NUMBERSK6"
                using ordinal1_def_5 sorry
            qed
            have A19: "\<one>\<^sub>M inTARSKIR2 succORDINAL1K1 \<one>\<^sub>M"
              using ordinal1_th_6 sorry
            have A20: "A +^ORDINAL2K10 0NUMBERSK6 =XBOOLE-0R4 A"
              using ordinal2_th_27 sorry
            have A21: "A =XBOOLE-0R4 A *^ORDINAL2K11 \<one>\<^sub>M"
              using ordinal2_th_39 sorry
            have "\<one>\<^sub>M c=ORDINAL1R1 \<two>\<^sub>M"
              using A19 ordinal1_def_2 sorry
            thus "A +^ORDINAL2K10 0NUMBERSK6 c=TARSKIR1 A *^ORDINAL2K11 \<two>\<^sub>M"
              using A20 A21 ordinal2_th_42 sorry
          qed
          thus "A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 0NUMBERSK6"
            using xboole_0_def_10 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal2_sch_1 A1 A2 A4 sorry
    thus " not ( for n be NatORDINAL1M6 holds  not A *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_73:
" for A be OrdinalORDINAL1M3 holds A be limit-ordinalORDINAL1V4 implies A *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds A be limit-ordinalORDINAL1V4 implies A *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M =XBOOLE-0R4 A"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    obtain n where
      [ty]:"n be NatORDINAL1M6" and 
      A1: "A *^ORDINAL2K11 \<two>\<^sub>M =XBOOLE-0R4 A +^ORDINAL2K10 n"
      using card_2_th_72 sorry
    assume "A be limit-ordinalORDINAL1V4"
    then have A2: "A +^ORDINAL2K10 n be limit-ordinalORDINAL1V4"
      using A1 ordinal3_th_40 sorry
    have "n <>HIDDENR2 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "n <>HIDDENR2 0NUMBERSK6"
      then obtain k where
        [ty]:"k be NatORDINAL1M6" and 
        A3: "n =XBOOLE-0R4 k +XCMPLX-0K2 \<one>\<^sub>M"
        using nat_1_th_6 sorry
      have 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "SegmCARD-1K5 n =XBOOLE-0R4 succORDINAL1K1 (SegmCARD-1K5 k)"
        using A3 nat_1_th_38 sorry
      then have "A +^ORDINAL2K10 n =XBOOLE-0R4 succORDINAL1K1 (A +^ORDINAL2K10 k)"
        using ordinal2_th_28 sorry
      thus " False "
        using A2 ordinal1_th_29 sorry
    qed
    thus "A *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M =XBOOLE-0R4 A"
      using A1 ordinal2_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_2_lm_9:
"omegaORDINAL1K4 be limit-ordinalORDINAL1V4"
  using ordinal1_def_11 sorry

mtheorem card_2_th_74:
" for A be OrdinalORDINAL1M3 holds omegaORDINAL1K4 c=ORDINAL1R1 A implies \<one>\<^sub>M +^ORDINAL2K10 A =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds omegaORDINAL1K4 c=ORDINAL1R1 A implies \<one>\<^sub>M +^ORDINAL2K10 A =XBOOLE-0R4 A"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?f = "\<lambda>Lamb1. \<one>\<^sub>M +^ORDINAL2K10 Lamb1"
    obtain phi where
      [ty]:"phi be Ordinal-SequenceORDINAL2M1" and 
      A1: "domRELAT-1K1 phi =XBOOLE-0R4 omegaORDINAL1K4 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 omegaORDINAL1K4 implies phi .FUNCT-1K1 B =XBOOLE-0R4 ?f(B))"
      using ordinal2_sch_3 sorry
    have A2: "\<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4 =HIDDENR1 supORDINAL2K4 phi"
      using A1 card_2_lm_9 ordinal2_th_29 sorry
    also have "... = supORDINAL2K3 (rngFUNCT-1K2 phi)"
      using ordinal2_th_26 sorry
    finally have "\<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4 =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 phi)"
       sorry
    have A3: "\<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4 c=ORDINAL1R1 omegaORDINAL1K4"
    proof-
      have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 \<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4 implies B inTARSKIR2 omegaORDINAL1K4"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume "B inTARSKIR2 \<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4"
        then obtain C where
          [ty]:"C be OrdinalORDINAL1M3" and 
          A4: "C inTARSKIR2 rngFUNCT-1K2 phi"and A5: "B c=ORDINAL1R1 C"
          using A2 ordinal2_th_21 sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A6: "x inHIDDENR3 domRELAT-1K1 phi"and A7: "C =XBOOLE-0R4 phi .FUNCT-1K1 x"
          using A4 funct_1_def_3 sorry
        have 
          [ty]:"x be OrdinalORDINAL1M3"
          using A6 sorry
        obtain x9 where 
          [ty]:"x9 be CardinalCARD-1M1" and x9Def:"x9 = x"
          using A1 A6 sorry
        have 
          [ty]:"x be finiteFINSET-1V1\<bar>OrdinalORDINAL1M3"
          using A1 A6 sorry
        have A8: "C =XBOOLE-0R4 \<one>\<^sub>M +^ORDINAL3K8 x"
          using A1 A6 A7 sorry
        have "succORDINAL1K1 x inTARSKIR2 omegaORDINAL1K4"
          using A1 A6 card_2_lm_9 ordinal1_th_28 sorry
        then have "C inTARSKIR2 omegaORDINAL1K4"
          using A8 ordinal2_th_31 sorry
        thus "B inTARSKIR2 omegaORDINAL1K4"
          using A5 ordinal1_th_12 sorry
      qed "sorry"
      thus "\<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4 c=ORDINAL1R1 omegaORDINAL1K4"
        using ordinal1_def_5 sorry
    qed
    assume "omegaORDINAL1K4 c=ORDINAL1R1 A"
    then have A9: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 omegaORDINAL1K4 +^ORDINAL2K10 B"
      using ordinal3_th_27 sorry
    have "omegaORDINAL1K4 c=ORDINAL1R1 \<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4"
      using ordinal3_th_24 sorry
    then have "omegaORDINAL1K4 =XBOOLE-0R4 \<one>\<^sub>M +^ORDINAL2K10 omegaORDINAL1K4"
      using A3 sorry
    thus "\<one>\<^sub>M +^ORDINAL2K10 A =XBOOLE-0R4 A"
      using A9 ordinal3_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_cl_2:
"cluster infiniteFINSET-1V2 also-is limit-ordinalORDINAL1V4 for CardinalCARD-1M1"
proof
(*coherence*)
  show " for it be CardinalCARD-1M1 holds it be infiniteFINSET-1V2 implies it be limit-ordinalORDINAL1V4"
  proof-
    have " for M be CardinalCARD-1M1 holds M be infiniteFINSET-1V2 implies ( not M be limit-ordinalORDINAL1V4 implies  False )"
    proof(rule ballI,rule impI,rule impI)
      fix M assume [ty]: "M be CardinalCARD-1M1"
      assume "M be infiniteFINSET-1V2"
      then have A1: " not M inTARSKIR2 omegaORDINAL1K4"
         sorry
      assume " not M be limit-ordinalORDINAL1V4"
      then obtain A where
        [ty]:"A be OrdinalORDINAL1M3" and 
        A2: "M =XBOOLE-0R4 succORDINAL1K1 A"
        using ordinal1_th_29 sorry
      have "omegaORDINAL1K4 =XBOOLE-0R4 succORDINAL1K1 A or omegaORDINAL1K4 inTARSKIR2 succORDINAL1K1 A"
        using A1 A2 card_1_th_4 sorry
      then have A3: "omegaORDINAL1K4 c=ORDINAL1R1 A"
        using card_2_lm_9 ordinal1_th_22 ordinal1_th_29 sorry
      have "cardCARD-1K1 (A +^ORDINAL2K10 \<one>\<^sub>M) =HIDDENR1 cardCARD-1K4 \<one>\<^sub>M +`CARD-2K1 cardCARD-1K1 A"
        using card_2_th_13 sorry
      also have "... = cardCARD-1K1 (\<one>\<^sub>M +^ORDINAL2K10 A)"
        using card_2_th_13 sorry
      also have "... = cardCARD-1K1 A"
        using A3 card_2_th_74 sorry
      finally have "cardCARD-1K1 (A +^ORDINAL2K10 \<one>\<^sub>M) =HIDDENR1 cardCARD-1K1 A"
         sorry
      then have "cardCARD-1K1 (succORDINAL1K1 A) =XBOOLE-0R4 cardCARD-1K1 A"
        using ordinal2_th_31 sorry
      then have A4: "(A,succORDINAL1K1 A)are-equipotentWELLORD2R2"
        using card_1_th_5 sorry
      have A5: " not succORDINAL1K1 A c=ORDINAL1R1 A"
        using ordinal1_th_5 ordinal1_th_6 sorry
      have " ex B be OrdinalORDINAL1M3 st succORDINAL1K1 A =XBOOLE-0R4 B & ( for A be OrdinalORDINAL1M3 holds (A,B)are-equipotentWELLORD2R2 implies B c=ORDINAL1R1 A)"
        using A2 card_1_def_1 sorry
      thus " False "
        using A4 A5 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_2_th_75:
" for M be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies M +`CARD-2K1 M =XBOOLE-0R4 M"
proof-
  have " for M be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies M +`CARD-2K1 M =XBOOLE-0R4 M"
  proof(rule ballI,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    assume " not M be finiteFINSET-1V1"
    then have "M *^ORDINAL2K11 succORDINAL1K1 \<one>\<^sub>M =XBOOLE-0R4 M"
      using card_2_th_73 sorry
    then have "cardCARD-1K1 M =HIDDENR1 cardCARD-1K4 \<two>\<^sub>M *`CARD-2K2 cardCARD-1K1 M"
      using card_2_th_14 sorry
    also have "... = cardCARD-1K1 (succORDINAL1K1 \<one>\<^sub>M *^ORDINAL2K11 M)"
      using card_2_th_14 sorry
    also have "... = cardCARD-1K1 (\<one>\<^sub>M *^ORDINAL2K11 M +^ORDINAL2K10 M)"
      using ordinal2_th_36 sorry
    also have "... = M +`CARD-2K1 M"
      using ordinal2_th_39 sorry
    finally have "cardCARD-1K1 M =HIDDENR1 M +`CARD-2K1 M"
       sorry
    thus "M +`CARD-2K1 M =XBOOLE-0R4 M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_76:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies M +`CARD-2K1 N =XBOOLE-0R4 M & N +`CARD-2K1 M =XBOOLE-0R4 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 & (N c=ORDINAL1R1 M or N inTARSKIR2 M) implies M +`CARD-2K1 N =XBOOLE-0R4 M & N +`CARD-2K1 M =XBOOLE-0R4 M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: " not M be finiteFINSET-1V1"
      and A2: "N c=ORDINAL1R1 M or N inTARSKIR2 M"
    have A3: "M +`CARD-2K1 M =XBOOLE-0R4 M"
      using A1 card_2_th_75 sorry
    have "N c=ORDINAL1R1 M"
      using A2 card_1_th_3 sorry
    then have A4: "M +^ORDINAL2K10 N c=ORDINAL1R1 M +^ORDINAL2K10 M"
      using ordinal2_th_33 sorry
    have A5: "M c=ORDINAL1R1 M +^ORDINAL2K10 N"
      using ordinal3_th_24 sorry
    have A6: "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    have A7: "M +`CARD-2K1 N c=ORDINAL1R1 M"
      using A3 A4 card_1_th_11 sorry
    have "M c=ORDINAL1R1 M +`CARD-2K1 N"
      using A5 A6 card_1_th_11 sorry
    thus "M +`CARD-2K1 N =XBOOLE-0R4 M & N +`CARD-2K1 M =XBOOLE-0R4 M"
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_77:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not X be finiteFINSET-1V1 & ((X,Y)are-equipotentWELLORD2R2 or (Y,X)are-equipotentWELLORD2R2) implies (X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not X be finiteFINSET-1V1 & ((X,Y)are-equipotentWELLORD2R2 or (Y,X)are-equipotentWELLORD2R2) implies (X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: " not X be finiteFINSET-1V1"
      and A2: "(X,Y)are-equipotentWELLORD2R2 or (Y,X)are-equipotentWELLORD2R2"
    have A3: "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
      using A2 card_1_th_5 sorry
    have A4: "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 (X \\/XBOOLE-0K2 Y)"
      using card_1_th_11 xboole_1_th_7 sorry
    have A5: "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
      using card_2_th_34 sorry
    have "cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
      using A1 A3 card_2_th_75 sorry
    then have "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (X \\/XBOOLE-0K2 Y)"
      using A4 A5 sorry
    thus "(X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_78:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not X be finiteFINSET-1V1 & Y be finiteFINSET-1V1 implies (X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not X be finiteFINSET-1V1 & Y be finiteFINSET-1V1 implies (X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: " not X be finiteFINSET-1V1"
      and A2: "Y be finiteFINSET-1V1"
    have "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X"
      using A1 A2 card_3_th_86 sorry
    then have A3: "cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
      using A1 card_2_th_76 sorry
    have A4: "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
      using card_2_th_34 sorry
    have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 (X \\/XBOOLE-0K2 Y)"
      using card_1_th_11 xboole_1_th_7 sorry
    then have "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (X \\/XBOOLE-0K2 Y)"
      using A3 A4 sorry
    thus "(X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_79:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not X be finiteFINSET-1V1 & (cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X or cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X) implies (X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not X be finiteFINSET-1V1 & (cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X or cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X) implies (X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: " not X be finiteFINSET-1V1"
      and A2: "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X or cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X"
    have A3: "cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
      using A1 A2 card_2_th_76 sorry
    have A4: "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
      using card_2_th_34 sorry
    have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 (X \\/XBOOLE-0K2 Y)"
      using card_1_th_11 xboole_1_th_7 sorry
    then have "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (X \\/XBOOLE-0K2 Y)"
      using A3 A4 sorry
    thus "(X \\/XBOOLE-0K2 Y,X)are-equipotentWELLORD2R2 & cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_cl_3:
  mlet "M be finiteFINSET-1V1\<bar>CardinalCARD-1M1", "N be finiteFINSET-1V1\<bar>CardinalCARD-1M1"
"cluster M +`CARD-2K1 N as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "M +`CARD-2K1 N be finiteFINSET-1V1"
  proof-
    have "M +`CARD-2K1 N =XBOOLE-0R4 cardCARD-1K4 (cardCARD-1K4 M +XCMPLX-0K2 cardCARD-1K4 N)"
      using card_2_th_38 sorry
    thus "M +`CARD-2K1 N be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem card_2_th_80:
" for M be finiteFINSET-1V1\<bar>CardinalCARD-1M1 holds  for N be finiteFINSET-1V1\<bar>CardinalCARD-1M1 holds M +`CARD-2K1 N be finiteFINSET-1V1"
   sorry

mtheorem card_2_th_81:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies  not M +`CARD-2K1 N be finiteFINSET-1V1 &  not N +`CARD-2K1 M be finiteFINSET-1V1"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not M be finiteFINSET-1V1 implies  not M +`CARD-2K1 N be finiteFINSET-1V1 &  not N +`CARD-2K1 M be finiteFINSET-1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: " not M be finiteFINSET-1V1"
    have "M c=ORDINAL1R1 N or N c=ORDINAL1R1 M"
       sorry
    then have "M c=ORDINAL1R1 N &  not N be finiteFINSET-1V1 or M +`CARD-2K1 N =XBOOLE-0R4 M & N +`CARD-2K1 M =XBOOLE-0R4 M"
      using A1 card_2_th_76 sorry
    thus " not M +`CARD-2K1 N be finiteFINSET-1V1 &  not N +`CARD-2K1 M be finiteFINSET-1V1"
      using A1 card_2_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_82:
" for M be finiteFINSET-1V1\<bar>CardinalCARD-1M1 holds  for N be finiteFINSET-1V1\<bar>CardinalCARD-1M1 holds M *`CARD-2K2 N be finiteFINSET-1V1"
   sorry

mtheorem card_2_th_83:
" for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N implies K +`CARD-2K1 M c=ORDINAL1R1 L +`CARD-2K1 N & M +`CARD-2K1 K c=ORDINAL1R1 L +`CARD-2K1 N"
proof-
  have " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N implies K +`CARD-2K1 M c=ORDINAL1R1 L +`CARD-2K1 N & M +`CARD-2K1 K c=ORDINAL1R1 L +`CARD-2K1 N"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix L assume [ty]: "L be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N"
    have A2: "K c=ORDINAL1R1 L"
      using A1 card_1_th_3 sorry
    have A3: "M c=ORDINAL1R1 N"
      using A1 card_1_th_3 sorry
    have A4: "K +`CARD-2K1 M =XBOOLE-0R4 cardCARD-1K1 (K +^ORDINAL2K10 M)"
       sorry
    have A5: "K +^ORDINAL2K10 M c=ORDINAL1R1 L +^ORDINAL2K10 N"
      using A2 A3 ordinal3_th_18 sorry
    thus "K +`CARD-2K1 M c=ORDINAL1R1 L +`CARD-2K1 N"
      using card_1_th_11 sorry
    show "M +`CARD-2K1 K c=ORDINAL1R1 L +`CARD-2K1 N"
      using A4 A5 card_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_84:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M inTARSKIR2 N or M c=ORDINAL1R1 N implies ((K +`CARD-2K1 M c=ORDINAL1R1 K +`CARD-2K1 N & K +`CARD-2K1 M c=ORDINAL1R1 N +`CARD-2K1 K) & M +`CARD-2K1 K c=ORDINAL1R1 K +`CARD-2K1 N) & M +`CARD-2K1 K c=ORDINAL1R1 N +`CARD-2K1 K"
  using card_2_th_83 sorry

mtheorem card_2_th_85:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be countableCARD-3V4 & Y be countableCARD-3V4 implies X \\/XBOOLE-0K2 Y be countableCARD-3V4"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X be countableCARD-3V4 & Y be countableCARD-3V4) &  not X \\/XBOOLE-0K2 Y be countableCARD-3V4)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4 & cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4 implies X \\/XBOOLE-0K2 Y be countableCARD-3V4"
    proof(rule impMI ,rule impI)
      assume A1: "cardCARD-1K1 X c=ORDINAL1R1 omegaORDINAL1K4"
        and A2: "cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4"
      have A3: "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y"
        using card_2_th_34 sorry
      have A4: "omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4 =XBOOLE-0R4 omegaORDINAL1K4"
        using card_2_th_75 sorry
      have Cut2108: "cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y c=ORDINAL1R1 omegaORDINAL1K4 +`CARD-2K1 omegaORDINAL1K4"
        using A1 A2 card_2_th_83 sorry
      have "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 omegaORDINAL1K4"
      proof-
        show "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 omegaORDINAL1K4"
          using A3 A4 Cut2108 sorry
      qed
      thus "X \\/XBOOLE-0K2 Y be countableCARD-3V4"
        using card_3_def_14 sorry
    qed
    thus " not ((X be countableCARD-3V4 & Y be countableCARD-3V4) &  not X \\/XBOOLE-0K2 Y be countableCARD-3V4)"
      using card_3_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_86:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  for f be FunctionFUNCT-1M1 holds cardCARD-1K1 (domRELAT-1K1 f) c=ORDINAL1R1 M & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies cardCARD-1K1 (f .FUNCT-1K1 x) c=ORDINAL1R1 N) implies cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 M *`CARD-2K2 N"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  for f be FunctionFUNCT-1M1 holds cardCARD-1K1 (domRELAT-1K1 f) c=ORDINAL1R1 M & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies cardCARD-1K1 (f .FUNCT-1K1 x) c=ORDINAL1R1 N) implies cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 M *`CARD-2K2 N"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "cardCARD-1K1 (domRELAT-1K1 f) c=ORDINAL1R1 M"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies cardCARD-1K1 (f .FUNCT-1K1 x) c=ORDINAL1R1 N"
    have A3: "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 f)"
      using card_3_th_39 sorry
    have A4: "domRELAT-1K1 (CardCARD-3K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using card_3_def_2 sorry
    have A5: "domRELSET-1K1\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f -->FUNCOP-1K7 N) =XBOOLE-0R4 domRELAT-1K1 f"
      using funcop_1_th_13 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 f) implies CardCARD-3K1 f .FUNCT-1K1 x c=TARSKIR1 (domRELAT-1K1 f -->FUNCOP-1K7 N).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domRELAT-1K1 (CardCARD-3K1 f)"
      then have A7: "CardCARD-3K1 f .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (f .FUNCT-1K1 x)"
        using A4 card_3_def_2 sorry
      have "(domRELAT-1K1 f -->FUNCOP-1K7 N).FUNCT-1K1 x =XBOOLE-0R4 N"
        using A4 A6 funcop_1_th_7 sorry
      thus "CardCARD-3K1 f .FUNCT-1K1 x c=TARSKIR1 (domRELAT-1K1 f -->FUNCOP-1K7 N).FUNCT-1K1 x"
        using A2 A4 A6 A7 sorry
    qed "sorry"
    then have "SumCARD-3K6 (CardCARD-3K1 f) c=ORDINAL1R1 SumCARD-3K6 (domRELAT-1K1 f -->FUNCOP-1K7 N)"
      using A4 A5 card_3_th_30 sorry
    then have A8: "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 SumCARD-3K6 (domRELAT-1K1 f -->FUNCOP-1K7 N)"
      using A3 sorry
    have A9: "[:ZFMISC-1K2 cardCARD-1K1 (domRELAT-1K1 f),N :] c=RELAT-1R2 [:ZFMISC-1K2 M,N :]"
      using A1 zfmisc_1_th_95 sorry
    have "SumCARD-3K6 (domRELAT-1K1 f -->FUNCOP-1K7 N) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 N,domRELAT-1K1 f :])"
      using card_3_th_25 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 N,cardCARD-1K1 (domRELAT-1K1 f) :])"
      using card_2_th_7 sorry
    also have "... = cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 (domRELAT-1K1 f),N :])"
      using card_2_th_4 sorry
    finally have "SumCARD-3K6 (domRELAT-1K1 f -->FUNCOP-1K7 N) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 (domRELAT-1K1 f),N :])"
       sorry
    then have A10: "SumCARD-3K6 (domRELAT-1K1 f -->FUNCOP-1K7 N) c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 M,N :])"
      using A9 card_1_th_11 sorry
    show "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 M *`CARD-2K2 N"
      using A8 A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_87:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  for X be setHIDDENM2 holds cardCARD-1K1 X c=ORDINAL1R1 M & ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies cardCARD-1K1 Y c=ORDINAL1R1 N) implies cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 M *`CARD-2K2 N"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  for X be setHIDDENM2 holds cardCARD-1K1 X c=ORDINAL1R1 M & ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies cardCARD-1K1 Y c=ORDINAL1R1 N) implies cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 M *`CARD-2K2 N"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "cardCARD-1K1 X c=ORDINAL1R1 M"
      and A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies cardCARD-1K1 Y c=ORDINAL1R1 N"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (idRELAT-1K7 X) implies cardCARD-1K1 (idRELAT-1K7 X .FUNCT-1K1 x) c=ORDINAL1R1 N"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (idRELAT-1K7 X)"
      then have "idRELAT-1K7 X .FUNCT-1K1 x inTARSKIR2 X"
        using funct_1_th_18 sorry
      thus "cardCARD-1K1 (idRELAT-1K7 X .FUNCT-1K1 x) c=ORDINAL1R1 N"
        using A2 sorry
    qed "sorry"
    then have "cardCARD-1K1 (UnionCARD-3K3 idRELAT-1K7 X) c=ORDINAL1R1 M *`CARD-2K2 N"
      using A1 card_2_th_86 sorry
    thus "cardCARD-1K1 (unionTARSKIK3 X) c=ORDINAL1R1 M *`CARD-2K2 N"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_88:
" for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be finiteFINSET-1V1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1) implies UnionCARD-3K3 f be finiteFINSET-1V1"
proof(rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume A1: "domRELAT-1K1 f be finiteFINSET-1V1"
    and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1"
  obtain df where 
    [ty]:"df be finiteFINSET-1V1\<bar>setHIDDENM2" and dfDef:"df = domRELAT-1K1 f"
    using A1 sorry
  have "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1 implies UnionCARD-3K3 f be finiteFINSET-1V1"
  proof(rule impI)
    assume "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
    then have A3: "df <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. cardCARD-1K1 (f .FUNCT-1K1 Lamb2) c=ORDINAL1R1 cardCARD-1K1 (f .FUNCT-1K1 Lamb1)"
    have A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?P(x,y) or ?P(y,x)"
       sorry
    have A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?P(x,y) & ?P(y,z) implies ?P(x,z)"
      using xboole_1_th_1 sorry
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A6: "x inHIDDENR3 df & ( for y be objectHIDDENM1 holds y inHIDDENR3 df implies ?P(x,y))"
      using card_2_sch_2 A3 A4 A5 sorry
    obtain fx where 
      [ty]:"fx be finiteFINSET-1V1\<bar>setHIDDENM2" and fxDef:"fx = f .FUNCT-1K1 x"
      using A2 A6 sorry
    have A7: "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 cardCARD-1K4 (cardCARD-1K4 df) *`CARD-2K2 cardCARD-1K1 (f .FUNCT-1K1 x)"
      using A6 card_2_th_86 sorry
    have "cardCARD-1K1 (f .FUNCT-1K1 x) =XBOOLE-0R4 cardCARD-1K4 (cardCARD-1K4 fx)"
       sorry
    then have "cardCARD-1K1 (UnionCARD-3K3 f) c=ORDINAL1R1 cardCARD-1K4 (cardCARD-1K4 df *XCMPLX-0K3 cardCARD-1K4 fx)"
      using A7 card_2_th_39 sorry
    thus "UnionCARD-3K3 f be finiteFINSET-1V1"
       sorry
  qed
  thus "UnionCARD-3K3 f be finiteFINSET-1V1"
    using relat_1_th_42 zfmisc_1_th_2 sorry
qed "sorry"

mtheorem card_2_th_89:
" for n be NatORDINAL1M6 holds omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 n c=ORDINAL1R1 omegaORDINAL1K4 & cardCARD-1K4 n *`CARD-2K2 omegaORDINAL1K4 c=ORDINAL1R1 omegaORDINAL1K4"
proof-
  have " for n be NatORDINAL1M6 holds omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 n c=ORDINAL1R1 omegaORDINAL1K4 & cardCARD-1K4 n *`CARD-2K2 omegaORDINAL1K4 c=ORDINAL1R1 omegaORDINAL1K4"
  proof(rule ballI,rule conjMI)
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1. omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 Lamb1 c=ORDINAL1R1 omegaORDINAL1K4"
    have A1: "?P(0NUMBERSK6)"
       sorry
    have A2: " for k be NatORDINAL1M6 holds ?P(k) implies ?P(k +XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have " for k be NatORDINAL1M6 holds omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 k c=ORDINAL1R1 omegaORDINAL1K4 implies omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 (k +XCMPLX-0K2 \<one>\<^sub>M) c=ORDINAL1R1 omegaORDINAL1K4"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatORDINAL1M6"
        assume A3: "?P(k)"
        have "cardCARD-1K4 (k +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 SegmCARD-1K5 (k +XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
        also have "... = succORDINAL1K1 (SegmCARD-1K5 k)"
          using nat_1_th_38 sorry
        finally have "cardCARD-1K4 (k +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 succORDINAL1K1 (SegmCARD-1K5 k)"
           sorry
        then have "cardCARD-1K4 (k +XCMPLX-0K2 \<one>\<^sub>M) =XBOOLE-0R4 cardCARD-1K4 (succORDINAL1K1 k)"
           sorry
        then have "omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 (k +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 cardCARD-1K1 (succORDINAL1K1 k *^ORDINAL2K11 omegaORDINAL1K4)"
          using card_2_th_14 card_1_th_47 sorry
        also have "... = cardCARD-1K1 (k *^ORDINAL2K11 omegaORDINAL1K4 +^ORDINAL2K10 omegaORDINAL1K4)"
          using ordinal2_th_36 sorry
        also have "... = cardCARD-1K1 (k *^ORDINAL2K11 omegaORDINAL1K4) +`CARD-2K1 omegaORDINAL1K4"
          using card_2_th_13 card_1_th_47 sorry
        also have "... = omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 k +`CARD-2K1 omegaORDINAL1K4"
          using card_2_th_14 card_1_th_47 sorry
        also have "... = omegaORDINAL1K4"
          using A3 card_2_th_76 sorry
        finally have "omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 (k +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 omegaORDINAL1K4"
           sorry
        thus "omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 (k +XCMPLX-0K2 \<one>\<^sub>M) c=ORDINAL1R1 omegaORDINAL1K4"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: " for k be NatORDINAL1M6 holds ?P(k)"
      using nat_1_sch_2 A1 A2 sorry
    thus "omegaORDINAL1K4 *`CARD-2K2 cardCARD-1K4 n c=ORDINAL1R1 omegaORDINAL1K4"
       sorry
    show "cardCARD-1K4 n *`CARD-2K2 omegaORDINAL1K4 c=ORDINAL1R1 omegaORDINAL1K4"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_90:
" for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N implies K *`CARD-2K2 M c=ORDINAL1R1 L *`CARD-2K2 N & M *`CARD-2K2 K c=ORDINAL1R1 L *`CARD-2K2 N"
proof-
  have " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N implies K *`CARD-2K2 M c=ORDINAL1R1 L *`CARD-2K2 N & M *`CARD-2K2 K c=ORDINAL1R1 L *`CARD-2K2 N"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix L assume [ty]: "L be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N"
    have A2: "K c=ORDINAL1R1 L"
      using A1 card_1_th_3 sorry
    have A3: "M c=ORDINAL1R1 N"
      using A1 card_1_th_3 sorry
    have A4: "K *`CARD-2K2 M =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 K,M :])"
       sorry
    have A5: "[:ZFMISC-1K2 K,M :] c=RELAT-1R2 [:ZFMISC-1K2 L,N :]"
      using A2 A3 zfmisc_1_th_96 sorry
    thus "K *`CARD-2K2 M c=ORDINAL1R1 L *`CARD-2K2 N"
      using card_1_th_11 sorry
    show "M *`CARD-2K2 K c=ORDINAL1R1 L *`CARD-2K2 N"
      using A4 A5 card_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_91:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M inTARSKIR2 N or M c=ORDINAL1R1 N implies ((K *`CARD-2K2 M c=ORDINAL1R1 K *`CARD-2K2 N & K *`CARD-2K2 M c=ORDINAL1R1 N *`CARD-2K2 K) & M *`CARD-2K2 K c=ORDINAL1R1 K *`CARD-2K2 N) & M *`CARD-2K2 K c=ORDINAL1R1 N *`CARD-2K2 K"
  using card_2_th_90 sorry

mtheorem card_2_th_92:
" for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N implies K =XBOOLE-0R4 0NUMBERSK6 or expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(L,N)"
proof-
  have " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds ((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N implies  not ( not K =XBOOLE-0R4 0NUMBERSK6 &  not expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(L,N))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix L assume [ty]: "L be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "((K inTARSKIR2 L & M inTARSKIR2 N or K c=ORDINAL1R1 L & M inTARSKIR2 N) or K inTARSKIR2 L & M c=ORDINAL1R1 N) or K c=ORDINAL1R1 L & M c=ORDINAL1R1 N"
    have A2: "K c=ORDINAL1R1 L"
      using A1 card_1_th_3 sorry
    have A3: "M c=ORDINAL1R1 N"
      using A1 card_1_th_3 sorry
    have "L <>HIDDENR2 {}XBOOLE-0K1 implies  not ( not K =XBOOLE-0R4 0NUMBERSK6 &  not expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(L,N))"
    proof(rule impI)
      assume "L <>HIDDENR2 {}XBOOLE-0K1"
      then have A4: "FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L) <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have "0NUMBERSK6 c=ORDINAL1R1 cardCARD-1K1 (FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L))"
         sorry
      then have "0NUMBERSK6 inTARSKIR2 cardCARD-1K1 (FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L))"
        using A4 card_1_th_3 sorry
      then have A5: "nextcardCARD-1K2 (SegmCARD-1K5 cardCARD-1K4 (0NUMBERSK6)) c=ORDINAL1R1 cardCARD-1K1 (FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L))"
        using card_1_def_3 sorry
      have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
         sorry
      then have A6: "SegmCARD-1K5 \<one>\<^sub>M c=ORDINAL1R1 cardCARD-1K1 (FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L))"
        using A5 card_2_lm_8 nat_1_th_42 sorry
      have A7: "M missesXBOOLE-0R1 N \\SUBSET-1K6 M"
        using xboole_1_th_79 sorry
      have A8: "N =XBOOLE-0R4 M \\/XBOOLE-0K2 (N \\SUBSET-1K6 M)"
        using A3 xboole_1_th_45 sorry
      have "FuncsFUNCT-2K1(M,K) c=TARSKIR1 FuncsFUNCT-2K1(M,L)"
        using A2 funct_5_th_56 sorry
      then have A9: "expCARD-2K3(K,M) c=ORDINAL1R1 cardCARD-1K1 (FuncsFUNCT-2K1(M,L))"
        using card_1_th_11 sorry
      have A10: "expCARD-2K3(L,N) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(M,L),FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L) :])"
        using A7 A8 funct_5_th_62 sorry
      have A11: "cardCARD-1K1 ([:ZFMISC-1K2 FuncsFUNCT-2K1(M,L),FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L) :]) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 (FuncsFUNCT-2K1(M,L)),cardCARD-1K1 (FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L)) :])"
        using card_2_th_7 sorry
      have "cardCARD-1K1 (FuncsFUNCT-2K1(M,L)) *`CARD-2K2 cardCARD-1K1 (FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L)) =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 cardCARD-1K1 (FuncsFUNCT-2K1(M,L)),cardCARD-1K1 (FuncsFUNCT-2K1(N \\SUBSET-1K6 M,L)) :])"
         sorry
      then have "\<one>\<^sub>M *`CARD-2K2 cardCARD-1K1 (FuncsFUNCT-2K1(M,L)) c=ORDINAL1R1 expCARD-2K3(L,N)"
        using A6 A10 A11 card_2_th_90 sorry
      then have "cardCARD-1K1 (FuncsFUNCT-2K1(M,L)) c=ORDINAL1R1 expCARD-2K3(L,N)"
        using card_2_th_21 sorry
      thus " not ( not K =XBOOLE-0R4 0NUMBERSK6 &  not expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(L,N))"
        using A9 sorry
    qed
    thus " not ( not K =XBOOLE-0R4 0NUMBERSK6 &  not expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(L,N))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_93:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M inTARSKIR2 N or M c=ORDINAL1R1 N implies K =XBOOLE-0R4 0NUMBERSK6 or expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(K,N) & expCARD-2K3(M,K) c=ORDINAL1R1 expCARD-2K3(N,K)"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (M inTARSKIR2 N or M c=ORDINAL1R1 N) & K <>HIDDENR2 0NUMBERSK6 implies expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(K,N) & expCARD-2K3(M,K) c=ORDINAL1R1 expCARD-2K3(N,K)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "M inTARSKIR2 N or M c=ORDINAL1R1 N"
      and A2: "K <>HIDDENR2 0NUMBERSK6"
    show "expCARD-2K3(K,M) c=ORDINAL1R1 expCARD-2K3(K,N)"
      using A1 A2 card_2_th_92 sorry
    have "M =XBOOLE-0R4 0NUMBERSK6 implies expCARD-2K3(M,K) =XBOOLE-0R4 0NUMBERSK6"
      using A2 sorry
    thus "expCARD-2K3(M,K) c=ORDINAL1R1 expCARD-2K3(N,K)"
      using A1 card_2_th_92 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_94:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M c=ORDINAL1R1 M +`CARD-2K1 N & N c=ORDINAL1R1 M +`CARD-2K1 N"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M c=ORDINAL1R1 M +`CARD-2K1 N & N c=ORDINAL1R1 M +`CARD-2K1 N"
  proof(rule ballI,rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: "M c=ORDINAL1R1 M +^ORDINAL2K10 N"
      using ordinal3_th_24 sorry
    have A2: "N c=ORDINAL1R1 M +^ORDINAL2K10 N"
      using ordinal3_th_24 sorry
    have A3: "cardCARD-1K1 N =XBOOLE-0R4 N"
       sorry
    have "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    then have A4: "M c=ORDINAL1R1 cardCARD-1K1 (M +^ORDINAL2K10 N)"
      using A1 card_1_th_11 sorry
    have "N c=ORDINAL1R1 cardCARD-1K1 (M +^ORDINAL2K10 N)"
      using A2 A3 card_1_th_11 sorry
    thus "M c=ORDINAL1R1 M +`CARD-2K1 N & N c=ORDINAL1R1 M +`CARD-2K1 N"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_95:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds N <>HIDDENR2 0NUMBERSK6 implies M c=ORDINAL1R1 M *`CARD-2K2 N & M c=ORDINAL1R1 N *`CARD-2K2 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds N <>HIDDENR2 0NUMBERSK6 implies M c=ORDINAL1R1 M *`CARD-2K2 N & M c=ORDINAL1R1 N *`CARD-2K2 M"
  proof(rule ballI,rule ballI,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "N <>HIDDENR2 0NUMBERSK6"
    have A2: "cardCARD-1K1 M =XBOOLE-0R4 M"
       sorry
    have "cardCARD-1K1 N =XBOOLE-0R4 N"
       sorry
    then have A3: "M *`CARD-2K2 N =XBOOLE-0R4 cardCARD-1K1 (M *^ORDINAL2K11 N)"
      using A2 card_2_th_14 sorry
    have "M c=ORDINAL1R1 M *^ORDINAL2K11 N"
      using A1 ordinal3_th_36 sorry
    thus "M c=ORDINAL1R1 M *`CARD-2K2 N & M c=ORDINAL1R1 N *`CARD-2K2 M"
      using A2 A3 card_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_96:
" for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K inTARSKIR2 L & M inTARSKIR2 N implies K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N & M +`CARD-2K1 K inTARSKIR2 L +`CARD-2K1 N"
proof-
  have " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not ((K inTARSKIR2 L & M inTARSKIR2 N) &  not (K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N & M +`CARD-2K1 K inTARSKIR2 L +`CARD-2K1 N))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix L assume [ty]: "L be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (K inTARSKIR2 L & M inTARSKIR2 N) & L c=ORDINAL1R1 N implies K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
    proof-
      have " for K be CardinalCARD-1M1 holds  for L be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K inTARSKIR2 L & (M inTARSKIR2 N & L c=ORDINAL1R1 N) implies K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix K assume [ty]: "K be CardinalCARD-1M1"
        fix L assume [ty]: "L be CardinalCARD-1M1"
        fix M assume [ty]: "M be CardinalCARD-1M1"
        fix N assume [ty]: "N be CardinalCARD-1M1"
        assume A2: "K inTARSKIR2 L"
          and A3: "M inTARSKIR2 N"
          and A4: "L c=ORDINAL1R1 N"
        show "K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
        proof-
          have cases: "N be finiteFINSET-1V1 or  not N be finiteFINSET-1V1"
             sorry
          have case1: "N be finiteFINSET-1V1 implies K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
          proof(rule impI)
            assume A5: "N be finiteFINSET-1V1"
            then have 
              [ty]:"N be finiteFINSET-1V1\<bar>CardinalCARD-1M1"
               sorry
            have 
              [ty]:"L be finiteFINSET-1V1\<bar>CardinalCARD-1M1" and
              [ty]:"M be finiteFINSET-1V1\<bar>CardinalCARD-1M1" and
              [ty]:"K be finiteFINSET-1V1\<bar>CardinalCARD-1M1"
              using A2 A3 A4 A5 card_3_th_92 sorry
            have A6: "cardCARD-1K4 (SegmCARD-1K5 K) =XBOOLE-0R4 K"
               sorry
            have A7: "cardCARD-1K4 (SegmCARD-1K5 L) =XBOOLE-0R4 L"
               sorry
            have A8: "cardCARD-1K4 (SegmCARD-1K5 M) =XBOOLE-0R4 M"
               sorry
            have A9: "cardCARD-1K4 (SegmCARD-1K5 N) =XBOOLE-0R4 N"
               sorry
            have A10: "K +`CARD-2K1 M =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 (cardCARD-1K4 K +XCMPLX-0K2 cardCARD-1K4 M))"
              using card_2_th_38 sorry
            have A11: "L +`CARD-2K1 N =XBOOLE-0R4 cardCARD-1K4 (SegmCARD-1K5 (cardCARD-1K4 L +XCMPLX-0K2 cardCARD-1K4 N))"
              using card_2_th_38 sorry
            have A12: "cardCARD-1K4 K <XXREAL-0R3 cardCARD-1K4 L"
              using A2 A6 A7 nat_1_th_41 sorry
            have "cardCARD-1K4 M <XXREAL-0R3 cardCARD-1K4 N"
              using A3 A8 A9 nat_1_th_41 sorry
            then have "cardCARD-1K4 K +XCMPLX-0K2 cardCARD-1K4 M <XXREAL-0R3 cardCARD-1K4 L +XCMPLX-0K2 cardCARD-1K4 N"
              using A12 xreal_1_th_8 sorry
            thus "K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
              using A10 A11 nat_1_th_41 sorry
          qed
          have case2: " not N be finiteFINSET-1V1 implies K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
          proof(rule impI)
            assume A13: " not N be finiteFINSET-1V1"
            then have A14: "L +`CARD-2K1 N =XBOOLE-0R4 N"
              using A4 card_2_th_76 sorry
            have A15: "omegaORDINAL1K4 c=ORDINAL1R1 N"
              using A13 card_3_th_85 sorry
            have "K c=ORDINAL1R1 M & (M be finiteFINSET-1V1 or  not M be finiteFINSET-1V1) or M c=ORDINAL1R1 K & (K be finiteFINSET-1V1 or  not K be finiteFINSET-1V1)"
               sorry
            then have A16: "(K be finiteFINSET-1V1 & M be finiteFINSET-1V1 or K +`CARD-2K1 M =XBOOLE-0R4 M) or K +`CARD-2K1 M =XBOOLE-0R4 K & K inTARSKIR2 N"
              using A2 A4 card_2_th_76 sorry
            have "K be finiteFINSET-1V1 & M be finiteFINSET-1V1 implies K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
              using A14 A15 card_1_th_61 sorry
            thus "K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N"
              using A3 A4 A13 A16 card_2_th_76 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "L c=ORDINAL1R1 N or N c=ORDINAL1R1 L"
       sorry
    thus " not ((K inTARSKIR2 L & M inTARSKIR2 N) &  not (K +`CARD-2K1 M inTARSKIR2 L +`CARD-2K1 N & M +`CARD-2K1 K inTARSKIR2 L +`CARD-2K1 N))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_97:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K +`CARD-2K1 M inTARSKIR2 K +`CARD-2K1 N implies M inTARSKIR2 N"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K +`CARD-2K1 M inTARSKIR2 K +`CARD-2K1 N &  not M inTARSKIR2 N implies  not  True "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "K +`CARD-2K1 M inTARSKIR2 K +`CARD-2K1 N"
      and A2: " not M inTARSKIR2 N"
    have "N c=ORDINAL1R1 M"
      using A2 card_1_th_4 sorry
    then have "K +`CARD-2K1 N c=ORDINAL1R1 K +`CARD-2K1 M"
      using card_2_th_83 sorry
    thus " not  True "
      using A1 card_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_98:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X & cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X implies cardCARD-1K1 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X & cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X implies cardCARD-1K1 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K1 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
      and A2: "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X"
    have A3: "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 (X \\/XBOOLE-0K2 Y)"
      using card_1_th_11 xboole_1_th_7 sorry
    have "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) c=ORDINAL1R1 cardCARD-1K1 X"
      using A1 card_2_th_34 sorry
    then have A4: "cardCARD-1K1 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 cardCARD-1K1 X"
      using A3 sorry
    have "(X \\SUBSET-1K6 Y)\\/XBOOLE-0K2 Y =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
      using xboole_1_th_39 sorry
    then have A5: "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (X \\SUBSET-1K6 Y) +`CARD-2K1 cardCARD-1K1 Y"
      using A4 card_2_th_35 xboole_1_th_79 sorry
    then have A6: "cardCARD-1K1 (X \\SUBSET-1K6 Y) c=ORDINAL1R1 cardCARD-1K1 X"
      using card_2_th_94 sorry
    have A7: " not cardCARD-1K1 X be finiteFINSET-1V1 implies ( not cardCARD-1K1 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K1 X implies  False )"
    proof(rule impI,rule impI)
      assume " not cardCARD-1K1 X be finiteFINSET-1V1"
      then have A8: "cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 X"
        using card_2_th_75 sorry
      assume " not cardCARD-1K1 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K1 X"
      then have "cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X"
        using A6 card_1_th_3 sorry
      then have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 X"
        using A2 A5 A8 card_2_th_96 sorry
      thus " False "
         sorry
    qed
    have "cardCARD-1K1 X be finiteFINSET-1V1 implies cardCARD-1K1 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K1 X"
    proof(rule impI)
      assume "cardCARD-1K1 X be finiteFINSET-1V1"
      then have 
        [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and
        [ty]:"Y be finiteFINSET-1V1\<bar>setHIDDENM2"
        using A2 card_3_th_92 sorry
      have "cardCARD-1K4 Y =XBOOLE-0R4 cardCARD-1K4 (cardCARD-1K4 Y)"
         sorry
      then have "cardCARD-1K4 (cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y) =XBOOLE-0R4 cardCARD-1K4 (cardCARD-1K4 X)"
        using A1 card_2_th_38 sorry
      then have "cardCARD-1K4 X +XCMPLX-0K2 cardCARD-1K4 Y =XBOOLE-0R4 cardCARD-1K4 X +XCMPLX-0K2 0NUMBERSK6"
         sorry
      then have "Y =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      thus "cardCARD-1K1 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K1 X"
         sorry
    qed
    thus "cardCARD-1K1 (X \\SUBSET-1K6 Y) =XBOOLE-0R4 cardCARD-1K1 X"
      using A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_99:
" for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K *`CARD-2K2 M inTARSKIR2 K *`CARD-2K2 N implies M inTARSKIR2 N"
proof-
  have " for K be CardinalCARD-1M1 holds  for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds K *`CARD-2K2 M inTARSKIR2 K *`CARD-2K2 N &  not M inTARSKIR2 N implies  not  True "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix K assume [ty]: "K be CardinalCARD-1M1"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume A1: "K *`CARD-2K2 M inTARSKIR2 K *`CARD-2K2 N"
      and A2: " not M inTARSKIR2 N"
    have "N c=ORDINAL1R1 M"
      using A2 card_1_th_4 sorry
    then have "K *`CARD-2K2 N c=ORDINAL1R1 K *`CARD-2K2 M"
      using card_2_th_90 sorry
    thus " not  True "
      using A1 card_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_100:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be countableCARD-3V4 & Y be countableCARD-3V4 implies X \\+\\XBOOLE-0K5 Y be countableCARD-3V4"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be countableCARD-3V4 & Y be countableCARD-3V4 implies X \\+\\XBOOLE-0K5 Y be countableCARD-3V4"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X be countableCARD-3V4"
      and A2: "Y be countableCARD-3V4"
    have A3: "X \\SUBSET-1K6 Y be countableCARD-3V4"
      using A1 sorry
    have "Y \\SUBSET-1K6 X be countableCARD-3V4"
      using A2 sorry
    thus "X \\+\\XBOOLE-0K5 Y be countableCARD-3V4"
      using A3 card_2_th_85 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_cl_4:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be setHIDDENM2", "f be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 B)"
"cluster UnionCARD-3K3 f as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "UnionCARD-3K3 f be finiteFINSET-1V1"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f implies f .FUNCT-1K1 x be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f"
      then have 
        [ty]:"A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
         sorry
      obtain x9 where 
        [ty]:"x9 be ElementSUBSET-1M1-of A" and x9Def:"x9 = x"
        using A1 sorry
      obtain f9 where 
        [ty]:"f9 be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 B)" and f9Def:"f9 = f"
         sorry
      have "f9 .FUNCT-2K3\<^bsub>(A,FinFINSUB-1K5 B)\<^esub> x9 be finiteFINSET-1V1"
         sorry
      thus "f .FUNCT-1K1 x be finiteFINSET-1V1"
         sorry
    qed "sorry"
    thus "UnionCARD-3K3 f be finiteFINSET-1V1"
      using card_2_th_88 sorry
  qed
qed "sorry"

mtheorem card_2_cl_5:
  mlet "f be finiteFINSET-1V1\<bar>finite-yieldingFINSET-1V5\<bar>FunctionFUNCT-1M1"
"cluster productCARD-3K4 f as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "productCARD-3K4 f be finiteFINSET-1V1"
  proof-
    have "FuncsFUNCT-2K1(domRELAT-1K1 f,UnionCARD-3K3 f) be finiteFINSET-1V1"
      using fraenkel_th_6 sorry
    thus "productCARD-3K4 f be finiteFINSET-1V1"
      using finset_1_th_1 funct_6_th_1 sorry
  qed
qed "sorry"

mtheorem card_2_th_101:
" for F be FunctionFUNCT-1M1 holds domRELAT-1K1 F be infiniteFINSET-1V2 & rngFUNCT-1K2 F be finiteFINSET-1V1 implies ( ex x be objectHIDDENM1 st x inHIDDENR3 rngFUNCT-1K2 F & F \<inverse>FUNCT-1K6 {TARSKIK1 x} be infiniteFINSET-1V2)"
proof-
  have " for F be FunctionFUNCT-1M1 holds domRELAT-1K1 F be infiniteFINSET-1V2 & rngFUNCT-1K2 F be finiteFINSET-1V1 implies (( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies F \<inverse>FUNCT-1K6 {TARSKIK1 x} be finiteFINSET-1V1) implies  not  True )"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 F be infiniteFINSET-1V2"
      and A2: "rngFUNCT-1K2 F be finiteFINSET-1V1"
    let ?f = "\<lambda>Lamb1. F \<inverse>FUNCT-1K6 {TARSKIK1 Lamb1}"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 F & ( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies g .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
      using funct_1_sch_3 sorry
    have A4: "domRELAT-1K1 F c=TARSKIR1 UnionCARD-3K3 g"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies x inHIDDENR3 UnionCARD-3K3 g"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 domRELAT-1K1 F"
        have A6: "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
          using A5 funct_1_def_3 sorry
        then have A7: "g .FUNCT-1K1 (F .FUNCT-1K1 x) inTARSKIR2 rngFUNCT-1K2 g"
          using A3 funct_1_def_3 sorry
        have "F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 F .FUNCT-1K1 x }"
          using tarski_def_1 sorry
        then have A8: "x inHIDDENR3 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
          using A5 funct_1_def_7 sorry
        have "g .FUNCT-1K1 (F .FUNCT-1K1 x) =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 F .FUNCT-1K1 x }"
          using A3 A6 sorry
        then have "x inHIDDENR3 unionTARSKIK3 (rngFUNCT-1K2 g)"
          using A8 A7 tarski_def_4 sorry
        thus "x inHIDDENR3 UnionCARD-3K3 g"
           sorry
      qed "sorry"
      thus "domRELAT-1K1 F c=TARSKIR1 UnionCARD-3K3 g"
        using tarski_def_3 sorry
    qed
    assume A9: " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies F \<inverse>FUNCT-1K6 {TARSKIK1 x} be finiteFINSET-1V1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A10: "x inHIDDENR3 domRELAT-1K1 g"
      have "g .FUNCT-1K1 x =XBOOLE-0R4 F \<inverse>FUNCT-1K6 {TARSKIK1 x}"
        using A3 A10 sorry
      thus "g .FUNCT-1K1 x be finiteFINSET-1V1"
        using A9 A3 A10 sorry
    qed "sorry"
    then have "UnionCARD-3K3 g be finiteFINSET-1V1"
      using A2 A3 card_2_th_88 sorry
    thus " not  True "
      using A1 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_2_th_102:
" for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 Y & cardCARD-1K4 X =XBOOLE-0R4 cardCARD-1K4 Y implies X =XBOOLE-0R4 Y"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
  assume A1: "X c=TARSKIR1 Y"
    and A2: "cardCARD-1K4 X =XBOOLE-0R4 cardCARD-1K4 Y"
  have "cardCARD-1K4 (Y \\SUBSET-1K6 X) =XBOOLE-0R4 cardCARD-1K4 Y -XCMPLX-0K6 cardCARD-1K4 X"
    using A1 card_2_th_44 sorry
  then have "Y \\SUBSET-1K6 X =XBOOLE-0R4 {}XBOOLE-0K1"
    using A2 sorry
  then have "Y c=TARSKIR1 X"
    using xboole_1_th_37 sorry
  thus "X =XBOOLE-0R4 Y"
    using A1 sorry
qed "sorry"

theorem card_2_sch_3:
  fixes Xf0 Pp2 
  assumes
[ty]: "Xf0 be finiteFINSET-1V1\<bar>setHIDDENM2" and
   A1: "Xf0 <>HIDDENR2 {}XBOOLE-0K1" and
   A2: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds Pp2(x,y) & Pp2(y,x) implies x =XBOOLE-0R4 y" and
   A3: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds Pp2(x,y) & Pp2(y,z) implies Pp2(x,z)"
  shows " ex x be setHIDDENM2 st x inTARSKIR2 Xf0 & ( for y be setHIDDENM2 holds y inTARSKIR2 Xf0 & y <>HIDDENR2 x implies  not Pp2(y,x))"
  proof-
    have " ex tVar22 be setHIDDENM2 st tVar22 inTARSKIR2 Xf0 & ( for y be setHIDDENM2 holds  not ((y inTARSKIR2 Xf0 &  not y <>HIDDENR2 tVar22) & Pp2(y,tVar22)))"
    proof-
      have A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds Pp2(x,y) & Pp2(y,x) implies x =HIDDENR1 y"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((Pp2(x,y) & Pp2(y,x)) &  not x =HIDDENR1 y)"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          have 
            [ty]:"x be setHIDDENM2" and
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          have "Pp2(x,y) & Pp2(y,x) implies x =XBOOLE-0R4 y"
            using A2 sorry
          thus " not ((Pp2(x,y) & Pp2(y,x)) &  not x =HIDDENR1 y)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds Pp2(x,y) & Pp2(y,z) implies Pp2(x,z)"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not ((Pp2(x,y) & Pp2(y,z)) &  not Pp2(x,z))"
        proof(rule ballI,rule ballI,rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          have 
            [ty]:"x be setHIDDENM2" and
            [ty]:"y be setHIDDENM2" and
            [ty]:"z be setHIDDENM2"
            using tarski_th_1 sorry
          have "Pp2(x,y) & Pp2(y,z) implies Pp2(x,z)"
            using A3 sorry
          thus " not ((Pp2(x,y) & Pp2(y,z)) &  not Pp2(x,z))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "x inHIDDENR3 Xf0"and A7: " for y be objectHIDDENM1 holds y inHIDDENR3 Xf0 & y <>HIDDENR2 x implies  not Pp2(y,x)"
        using card_2_sch_1 A1 A4 A5 sorry
      have 
        [ty]:"x be setHIDDENM2"
        using tarski_th_1 sorry
      show " ex tVar22 be setHIDDENM2 st tVar22 inTARSKIR2 Xf0 & ( for y be setHIDDENM2 holds  not ((y inTARSKIR2 Xf0 &  not y <>HIDDENR2 tVar22) & Pp2(y,tVar22)))"
      proof(rule bexI[of _ "x"])
        show "x inTARSKIR2 Xf0 & ( for y be setHIDDENM2 holds  not ((y inTARSKIR2 Xf0 &  not y <>HIDDENR2 x) & Pp2(y,x)))"
          using A6 A7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

end
