theory cfdiff_1
  imports cfcont_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, k1, n, n1, m for "NatNAT-1M1"
reserve X, y for "setHIDDENM2"
reserve p for "RealXREAL-0M1"
reserve r for "RealXREAL-0M1"
reserve a, a1, a2, b, b1, b2, x, x0, z, z0 for "ComplexXCMPLX-0M1"
reserve s1, s3, seq, seq1 for "Complex-SequenceCOMSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
reserve Nseq for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mdef cfdiff_1_def_1 (" _ -convergentCFDIFF-1V1" [70]70 ) where
  mlet "x be RealXREAL-0M1"
"attr x -convergentCFDIFF-1V1 for Complex-SequenceCOMSEQ-1M1 means
  (\<lambda>IT. IT be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 IT =COMPLEX1R1 x)"..

mtheorem cfdiff_1_th_1:
" for rs be Real-SequenceSEQ-1M1 holds  for cs be Complex-SequenceCOMSEQ-1M1 holds rs =FUNCT-2R1\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> cs & rs be convergentCOMSEQ-2V3 implies cs be convergentCOMSEQ-2V3"
   sorry

mdef cfdiff_1_def_2 ("InvShiftCFDIFF-1K1  _ " [164]164 ) where
  mlet "r be RealXREAL-0M1"
"func InvShiftCFDIFF-1K1 r \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
    proof-
      have " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for n be NatNAT-1M1 holds VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)))"
      proof-
        let ?F = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 r)"
        have " ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ?F(n)"
          using comseq_1_sch_1 sorry
        thus " not ( for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not ( for n be NatNAT-1M1 holds VarFor1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f be Complex-SequenceCOMSEQ-1M1 holds  for g be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) & ( for n be NatNAT-1M1 holds g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies f =HIDDENR1 g"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f assume [ty]: "f be Complex-SequenceCOMSEQ-1M1"
        fix g assume [ty]: "g be Complex-SequenceCOMSEQ-1M1"
        assume A1: " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
          and A2: " for n be NatNAT-1M1 holds g .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 g .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
            using A1 sorry
          also have "... = g .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using A2 sorry
          finally show "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 g .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
             sorry
        qed "sorry"
        thus "f =HIDDENR1 g"
          using funct_2_def_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem cfdiff_1_th_2:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies InvShiftCFDIFF-1K1 r be convergentCOMSEQ-2V3"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies InvShiftCFDIFF-1K1 r be convergentCOMSEQ-2V3"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
    let ?seq = "InvShiftCFDIFF-1K1 r"
    obtain g where 
      [ty]:"g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and gDef:"g = 0cCOMPLEX1K6"
       sorry
    have " ex g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (InvShiftCFDIFF-1K1 r).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain k1 where
        [ty]:"k1 be NatNAT-1M1" and 
        A3: "p \<inverse>XCMPLX-0K5 <XXREAL-0R3 k1"
        using seq_4_th_3 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = k1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (InvShiftCFDIFF-1K1 r).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "n +XCMPLX-0K2 r <=XXREAL-0R1 m +XCMPLX-0K2 r"
          using xreal_1_th_6 sorry
        then have A4: "\<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
          using A1 xreal_1_th_118 sorry
        have A5: "?seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r)"
          using cfdiff_1_def_2 sorry
        have "p \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 k1 +XCMPLX-0K2 r"
          using A1 A3 xreal_1_th_8 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (k1 +XCMPLX-0K2 r) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 p \<inverse>XCMPLX-0K5"
          using A2 xreal_1_th_76 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r) <XXREAL-0R3 p"
          using A4 xxreal_0_th_2 sorry
        thus " |.COMPLEX1K10 (InvShiftCFDIFF-1K1 r).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
          using A1 A5 absvalue_def_1 sorry
      qed "sorry"
    qed "sorry"
    thus "InvShiftCFDIFF-1K1 r be convergentCOMSEQ-2V3"
      using comseq_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_cl_1:
  mlet "r be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster InvShiftCFDIFF-1K1 r as-term-is convergentCOMSEQ-2V3"
proof
(*coherence*)
  show "InvShiftCFDIFF-1K1 r be convergentCOMSEQ-2V3"
    using cfdiff_1_th_2 sorry
qed "sorry"

mtheorem cfdiff_1_th_3:
" for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies limCOMSEQ-2K3 (InvShiftCFDIFF-1K1 r) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies limCOMSEQ-2K3 (InvShiftCFDIFF-1K1 r) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?seq = "InvShiftCFDIFF-1K1 r"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (InvShiftCFDIFF-1K1 r).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain k1 where
        [ty]:"k1 be NatNAT-1M1" and 
        A3: "p \<inverse>XCMPLX-0K5 <XXREAL-0R3 k1"
        using seq_4_th_3 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = k1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (InvShiftCFDIFF-1K1 r).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "n +XCMPLX-0K2 r <=XXREAL-0R1 m +XCMPLX-0K2 r"
          using xreal_1_th_6 sorry
        then have A4: "\<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
          using A1 xreal_1_th_118 sorry
        have A5: "?seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r)"
          using cfdiff_1_def_2 sorry
        have "p \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 k1 +XCMPLX-0K2 r"
          using A1 A3 xreal_1_th_8 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (k1 +XCMPLX-0K2 r) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 p \<inverse>XCMPLX-0K5"
          using A2 xreal_1_th_76 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r) <XXREAL-0R3 p"
          using A4 xxreal_0_th_2 sorry
        thus " |.COMPLEX1K10 (InvShiftCFDIFF-1K1 r).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p"
          using A1 A5 absvalue_def_1 sorry
      qed "sorry"
    qed "sorry"
    thus "limCOMSEQ-2K3 (InvShiftCFDIFF-1K1 r) =COMPLEX1R1 0NUMBERSK6"
      using A1 comseq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_cl_2:
  mlet "r be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster InvShiftCFDIFF-1K1 r as-term-is non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentCFDIFF-1V1"
proof
(*coherence*)
  show "InvShiftCFDIFF-1K1 r be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentCFDIFF-1V1"
  proof-
    have "InvShiftCFDIFF-1K1 r be non-zeroORDINAL1V9 & InvShiftCFDIFF-1K1 r be 0NUMBERSK6 -convergentCFDIFF-1V1"
    proof(rule conjMI)
      let ?s = "InvShiftCFDIFF-1K1 r"
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (InvShiftCFDIFF-1K1 r).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "\<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r) <>HIDDENR2 0NUMBERSK6"
           sorry
        thus "(InvShiftCFDIFF-1K1 r).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
          using cfdiff_1_def_2 sorry
      qed "sorry"
      thus "InvShiftCFDIFF-1K1 r be non-zeroORDINAL1V9"
        using comseq_1_th_4 sorry
      have "limCOMSEQ-2K3 ?s =COMPLEX1R1 0NUMBERSK6"
        using cfdiff_1_th_3 sorry
      thus "InvShiftCFDIFF-1K1 r be 0NUMBERSK6 -convergentCFDIFF-1V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_3:
"cluster 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9"
  proof-
    have " ex tVar4 be Complex-SequenceCOMSEQ-1M1 st tVar4 be 0NUMBERSK6 -convergentCFDIFF-1V1 & tVar4 be non-zeroORDINAL1V9"
    proof-
      show " ex tVar4 be Complex-SequenceCOMSEQ-1M1 st tVar4 be 0NUMBERSK6 -convergentCFDIFF-1V1 & tVar4 be non-zeroORDINAL1V9"
      proof(rule bexI[of _ "InvShiftCFDIFF-1K1 \<one>\<^sub>M"])
        show "InvShiftCFDIFF-1K1 \<one>\<^sub>M be 0NUMBERSK6 -convergentCFDIFF-1V1 & InvShiftCFDIFF-1K1 \<one>\<^sub>M be non-zeroORDINAL1V9"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_4:
"cluster 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9 also-is convergentCOMSEQ-2V3 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9 implies it be convergentCOMSEQ-2V3"
     sorry
qed "sorry"

mtheorem cfdiff_1_cl_5:
"cluster constantVALUED-0V15 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be constantVALUED-0V15"
  proof-
    have " ex tVar5 be Complex-SequenceCOMSEQ-1M1 st tVar5 be constantVALUED-0V15"
    proof-
      obtain cs where 
        [ty]:"cs be Complex-SequenceCOMSEQ-1M1" and csDef:"cs = NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
         sorry
      show " ex tVar5 be Complex-SequenceCOMSEQ-1M1 st tVar5 be constantVALUED-0V15"
      proof(rule bexI[of _ "cs"])
        show "cs be constantVALUED-0V15"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_th_4:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds (seq be constantVALUED-0V15 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) & seq be  non constantVALUED-0V15 implies  not  True )"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    show "seq be constantVALUED-0V15 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m)"
      using valued_0_th_23 sorry
    assume A1: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
      and A2: "seq be  non constantVALUED-0V15"
    have " for n be NatNAT-1M1 holds  False "
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A3: "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n1 <>HIDDENR2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using A2 valued_0_def_18 sorry
      show " False "
        using A1 A3 sorry
    qed "sorry"
    thus " not  True "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_5:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  for n be NatNAT-1M1 holds (seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  for n be NatNAT-1M1 holds (seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix Nseq assume [ty]: "Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "n inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (seq *COMSEQ-3K9 Nseq) =HIDDENR1 NATNUMBERSK1"
      using funct_2_def_1 sorry
    thus "(seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
      using funct_1_th_12 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve h for "0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
reserve c for "constantVALUED-0V15\<bar>Complex-SequenceCOMSEQ-1M1"
mdef cfdiff_1_def_3 ("RestFunc-likeCFDIFF-1V2" 70 ) where
"attr RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  (\<lambda>IT.  for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> IT /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0NUMBERSK6)"..

mtheorem cfdiff_1_cl_6:
"cluster totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
  proof-
    have " ex f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & f be RestFunc-likeCFDIFF-1V2"
    proof-
      obtain cf where 
        [ty]:"cf be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and cfDef:"cf = COMPLEXNUMBERSK3 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
         sorry
      obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and fDef:"f = cf"
         sorry
      show " ex f be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & f be RestFunc-likeCFDIFF-1V2"
      proof(rule bexI[of _ "f"],rule conjMI)
        show "f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
           sorry
        have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
        proof(rule ballI)
          fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
          have " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =HIDDENR1 COMPLEXNUMBERSK3"
              using partfun1_def_2 sorry
            then have A1: "n inTARSKIR2 NATNUMBERSK1 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
              using ordinal1_def_12 sorry
            have "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_5 sorry
            also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 f /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using A1 funct_2_th_108 sorry
            also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6"
              using funcop_1_th_7 sorry
            also have "... = 0cCOMPLEX1K6"
               sorry
            finally show "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
               sorry
          qed "sorry"
          then have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be constantVALUED-0V15 & (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0cCOMPLEX1K6"
            using valued_0_def_18 sorry
          thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
            using cfcont_1_th_26 cfcont_1_th_27 sorry
        qed "sorry"
        thus "f be RestFunc-likeCFDIFF-1V2"
          using cfdiff_1_def_3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CFDIFF_1M1 :: "Ty" ("C-RestFuncCFDIFF-1M1" 70)
translations "C-RestFuncCFDIFF-1M1" \<rightharpoonup> "totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2\<bar>PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"

mdef cfdiff_1_def_4 ("linearCFDIFF-1V3" 70 ) where
"attr linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  (\<lambda>IT.  ex a be ComplexXCMPLX-0M1 st  for z be ComplexXCMPLX-0M1 holds IT /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a *XCMPLX-0K3 z)"..

mtheorem cfdiff_1_cl_7:
"cluster totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
  proof-
    have " ex tVar7 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st tVar7 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & tVar7 be linearCFDIFF-1V3"
    proof-
      let ?F = "\<lambda>Lamb1. InSUBSET-1K10(1rCOMPLEX1K7 *XCMPLX-0K3 Lamb1,COMPLEXNUMBERSK3)"
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 COMPLEXNUMBERSK3"
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
        A1: "( for a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds a inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f iff ?P(a)) & ( for a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds a inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f .FUNCT-1K1 a =COMPLEX1R1 ?F(a))"
        using seq_1_sch_3 sorry
      show " ex tVar7 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st tVar7 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & tVar7 be linearCFDIFF-1V3"
      proof(rule bexI[of _ "f"],rule conjMI)
        have " for y be objectHIDDENM1 holds y inHIDDENR3 COMPLEXNUMBERSK3 implies y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A1 sorry
        then have "COMPLEXNUMBERSK3 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
           sorry
        then have A2: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =HIDDENR1 COMPLEXNUMBERSK3"
           sorry
        thus "f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
          using partfun1_def_2 sorry
        have " for z be ComplexXCMPLX-0M1 holds f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 1rCOMPLEX1K7 *XCMPLX-0K3 z"
        proof(rule ballI)
          fix z assume [ty]: "z be ComplexXCMPLX-0M1"
          have 
            [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 f .FUNCT-1K1 z"
            using A2 partfun1_def_6 sorry
          also have "... = ?F(z)"
            using A1 sorry
          finally have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 ?F(z)"
             sorry
          thus "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 1rCOMPLEX1K7 *XCMPLX-0K3 z"
             sorry
        qed "sorry"
        thus "f be linearCFDIFF-1V3"
          using bexI[of _ "1rCOMPLEX1K7"] cfdiff_1_def_4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CFDIFF_1M2 :: "Ty" ("C-LinearFuncCFDIFF-1M2" 70)
translations "C-LinearFuncCFDIFF-1M2" \<rightharpoonup> "totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3\<bar>PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"

reserve R, R1, R2 for "C-RestFuncCFDIFF-1M1"
reserve L, L1, L2 for "C-LinearFuncCFDIFF-1M2"
mtheorem cfdiff_1_cl_8:
  mlet "L1 be C-LinearFuncCFDIFF-1M2", "L2 be C-LinearFuncCFDIFF-1M2"
"cluster L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be linearCFDIFF-1V3))"
    proof-
      obtain a2 where
        [ty]:"a2 be ComplexXCMPLX-0M1" and 
        A1: " for z be ComplexXCMPLX-0M1 holds L2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a2 *XCMPLX-0K3 z"
        using cfdiff_1_def_4 sorry
      obtain a1 where
        [ty]:"a1 be ComplexXCMPLX-0M1" and 
        A2: " for z be ComplexXCMPLX-0M1 holds L1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a1 *XCMPLX-0K3 z"
        using cfdiff_1_def_4 sorry
      have " for z be ComplexXCMPLX-0M1 holds (L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (a1 +XCMPLX-0K2 a2)*XCMPLX-0K3 z"
      proof(rule ballI)
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        have "z inHIDDENR3 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        then have "(L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 L1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z +XCMPLX-0K2 L2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
          using cfunct_1_th_64 sorry
        also have "... = a1 *XCMPLX-0K3 z +XCMPLX-0K2 L2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
          using A2 sorry
        also have "... = a1 *XCMPLX-0K3 z +XCMPLX-0K2 a2 *XCMPLX-0K3 z"
          using A1 sorry
        also have "... = (a1 +XCMPLX-0K2 a2)*XCMPLX-0K3 z"
           sorry
        finally show "(L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (a1 +XCMPLX-0K2 a2)*XCMPLX-0K3 z"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be linearCFDIFF-1V3))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_9:
  mlet "L1 be C-LinearFuncCFDIFF-1M2", "L2 be C-LinearFuncCFDIFF-1M2"
"cluster L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be linearCFDIFF-1V3))"
    proof-
      obtain a2 where
        [ty]:"a2 be ComplexXCMPLX-0M1" and 
        A3: " for z be ComplexXCMPLX-0M1 holds L2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a2 *XCMPLX-0K3 z"
        using cfdiff_1_def_4 sorry
      obtain a1 where
        [ty]:"a1 be ComplexXCMPLX-0M1" and 
        A4: " for z be ComplexXCMPLX-0M1 holds L1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a1 *XCMPLX-0K3 z"
        using cfdiff_1_def_4 sorry
      have " for z be ComplexXCMPLX-0M1 holds (L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (a1 -XCMPLX-0K6 a2)*XCMPLX-0K3 z"
      proof(rule ballI)
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        have "z inHIDDENR3 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        then have "(L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 L1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 L2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
          using cfunct_1_th_64 sorry
        also have "... = a1 *XCMPLX-0K3 z -XCMPLX-0K6 L2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
          using A4 sorry
        also have "... = a1 *XCMPLX-0K3 z -XCMPLX-0K6 a2 *XCMPLX-0K3 z"
          using A3 sorry
        also have "... = (a1 -XCMPLX-0K6 a2)*XCMPLX-0K3 z"
           sorry
        finally show "(L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (a1 -XCMPLX-0K6 a2)*XCMPLX-0K3 z"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be linearCFDIFF-1V3))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_10:
  mlet "a be ComplexXCMPLX-0M1", "L be C-LinearFuncCFDIFF-1M2"
"cluster a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>linearCFDIFF-1V3"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be linearCFDIFF-1V3))"
    proof-
      obtain b where
        [ty]:"b be ComplexXCMPLX-0M1" and 
        A1: " for z be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 b *XCMPLX-0K3 z"
        using cfdiff_1_def_4 sorry
      have " for z be ComplexXCMPLX-0M1 holds (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (a *XCMPLX-0K3 b)*XCMPLX-0K3 z"
      proof(rule ballI)
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        have "z inHIDDENR3 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        then have "(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 a *XCMPLX-0K3 L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z"
          using cfunct_1_th_65 sorry
        also have "... = a *XCMPLX-0K3 (b *XCMPLX-0K3 z)"
          using A1 sorry
        also have "... = (a *XCMPLX-0K3 b)*XCMPLX-0K3 z"
           sorry
        finally show "(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =HIDDENR1 (a *XCMPLX-0K3 b)*XCMPLX-0K3 z"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be linearCFDIFF-1V3))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_11:
  mlet "R1 be C-RestFuncCFDIFF-1M1", "R2 be C-RestFuncCFDIFF-1M1"
"cluster R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
    proof-
      have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0NUMBERSK6"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
        have A1: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using cfcont_1_th_14 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h"
          using comseq_1_th_10 sorry
        finally have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h"
           sorry
        have A2: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using cfdiff_1_def_3 sorry
        thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using A1 sorry
        have A3: "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
          using cfdiff_1_def_3 sorry
        have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) +XCMPLX-0K2 limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using A2 A1 comseq_2_th_14 sorry
        also have "... = 0NUMBERSK6"
          using A3 cfdiff_1_def_3 sorry
        finally show "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_12:
  mlet "R1 be C-RestFuncCFDIFF-1M1", "R2 be C-RestFuncCFDIFF-1M1"
"cluster R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
    proof-
      have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
        have A4: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using cfcont_1_th_14 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h"
          using comseq_1_th_15 sorry
        finally have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h"
           sorry
        have A5: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using cfdiff_1_def_3 sorry
        thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using A4 sorry
        have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
          using cfdiff_1_def_3 sorry
        then have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6 -XCMPLX-0K6 0cCOMPLEX1K6"
          using A5 A4 comseq_2_th_26 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_13:
  mlet "R1 be C-RestFuncCFDIFF-1M1", "R2 be C-RestFuncCFDIFF-1M1"
"cluster R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
    proof-
      have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
        have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9"
        proof-
          have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 &  not seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9 implies  False "
          proof(rule ballI,rule impMI ,rule impI)
            fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
            assume A6: "seq be non-zeroORDINAL1V9"
              and A7: " not seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9"
            obtain n1 where
              [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A8: "seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n1 =COMPLEX1R1 0cCOMPLEX1K6"
              using A7 comseq_1_th_4 sorry
            have "(seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n1)\<inverse>XCMPLX-0K5 =COMPLEX1R1 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n1"
              using valued_1_th_10 sorry
            thus " False "
              using A6 A8 comseq_1_th_4 xcmplx_1_th_202 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A9: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9"
           sorry
        have A10: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h"
          using cfcont_1_th_14 sorry
        also have "... = ((R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
          using A9 comseq_1_th_37 sorry
        also have "... = ((R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
          using comseq_1_th_30 sorry
        also have "... = (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h))"
          using comseq_1_th_8 sorry
        also have "... = ((h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using comseq_1_th_8 sorry
        also have "... = (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using comseq_1_th_8 sorry
        finally have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
           sorry
        have A11: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using cfdiff_1_def_3 sorry
        then have A12: "h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) be convergentCOMSEQ-2V3"
           sorry
        have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6 & limCOMSEQ-2K3 h =COMPLEX1R1 0cCOMPLEX1K6"
          using cfdiff_1_def_1 cfdiff_1_def_3 sorry
        then have A13: "limCOMSEQ-2K3 (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)) =HIDDENR1 (0NUMBERSK6)*NAT-1K2 (0NUMBERSK6)"
          using A11 comseq_2_th_30 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally have "limCOMSEQ-2K3 (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)) =HIDDENR1 0cCOMPLEX1K6"
           sorry
        have A14: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using cfdiff_1_def_3 sorry
        thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using A12 A10 sorry
        have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
          using cfdiff_1_def_3 sorry
        then have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6 *XCMPLX-0K3 0cCOMPLEX1K6"
          using A14 A12 A13 A10 comseq_2_th_30 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_14:
  mlet "a be ComplexXCMPLX-0M1", "R be C-RestFuncCFDIFF-1M1"
"cluster a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
    proof-
      have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
        have A1: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using cfcont_1_th_15 sorry
        also have "... = a (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using comseq_1_th_13 sorry
        finally have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 a (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
           sorry
        have A2: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using cfdiff_1_def_3 sorry
        thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using A1 sorry
        have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
          using cfdiff_1_def_3 sorry
        then have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 a *XCMPLX-0K3 0cCOMPLEX1K6"
          using A2 A1 comseq_2_th_18 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_15:
  mlet "L1 be C-LinearFuncCFDIFF-1M2", "L2 be C-LinearFuncCFDIFF-1M2"
"cluster L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
    proof-
      obtain LL where 
        [ty]:"LL be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and LLDef:"LL = L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2"
         sorry
      have "LL be RestFunc-likeCFDIFF-1V2"
      proof-
        have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> LL /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> LL /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
        proof(rule ballI,rule conjMI)
          fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
          obtain b1 where
            [ty]:"b1 be ComplexXCMPLX-0M1" and 
            A1: " for z be ComplexXCMPLX-0M1 holds L1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 b1 *XCMPLX-0K3 z"
            using cfdiff_1_def_4 sorry
          obtain b2 where
            [ty]:"b2 be ComplexXCMPLX-0M1" and 
            A2: " for z be ComplexXCMPLX-0M1 holds L2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 b2 *XCMPLX-0K3 z"
            using cfdiff_1_def_4 sorry
          have A3: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((b1 *XCMPLX-0K3 b2)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A4: "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
              using comseq_1_th_4 sorry
            have "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_5 sorry
            also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using funct_2_th_115 sorry
            also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) *XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))"
              using cfunct_1_th_64 sorry
            also have "... = (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))*XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
               sorry
            also have "... = ((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))*XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using valued_1_th_10 sorry
            also have "... = ((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 b1))*XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A1 sorry
            also have "... = (((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 b1)*XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
               sorry
            also have "... = (1rCOMPLEX1K7 *XCMPLX-0K3 b1)*XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A4 xcmplx_0_def_7 sorry
            also have "... = b1 *XCMPLX-0K3 (b2 *XCMPLX-0K3 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A2 sorry
            also have "... = (b1 *XCMPLX-0K3 b2)*XCMPLX-0K3 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
               sorry
            also have "... = ((b1 *XCMPLX-0K3 b2)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_6 sorry
            finally show "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((b1 *XCMPLX-0K3 b2)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
               sorry
          qed "sorry"
          then have A5: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (b1 *XCMPLX-0K3 b2)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h"
             sorry
          show "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> LL /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
            using A3 funct_2_th_63 sorry
          have "limCOMSEQ-2K3 h =COMPLEX1R1 0cCOMPLEX1K6"
            using cfdiff_1_def_1 sorry
          then have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> LL /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 (b1 *XCMPLX-0K3 b2)*XCMPLX-0K3 0cCOMPLEX1K6"
            using A5 comseq_2_th_18 sorry
          also have "... = 0cCOMPLEX1K6"
             sorry
          finally show "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> LL /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
             sorry
        qed "sorry"
        thus "LL be RestFunc-likeCFDIFF-1V2"
          using cfdiff_1_def_3 sorry
      qed
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2 &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_16:
  mlet "R be C-RestFuncCFDIFF-1M1", "L be C-LinearFuncCFDIFF-1M2"
"cluster R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
    proof-
      obtain b1 where
        [ty]:"b1 be ComplexXCMPLX-0M1" and 
        A1: " for z be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 b1 *XCMPLX-0K3 z"
        using cfdiff_1_def_4 sorry
      have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
        have A2: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
          using cfcont_1_th_14 sorry
        also have "... = (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h"
          using comseq_1_th_8 sorry
        finally have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h"
           sorry
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (b1 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
            using funct_2_th_115 sorry
          also have "... = b1 *XCMPLX-0K3 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using A1 sorry
          also have "... = (b1 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using valued_1_th_6 sorry
          finally show "L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (b1 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
             sorry
        qed "sorry"
        then have A3: "L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> b1 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h"
           sorry
        have "limCOMSEQ-2K3 h =COMPLEX1R1 0cCOMPLEX1K6"
          using cfdiff_1_def_1 sorry
        then have A4: "limCOMSEQ-2K3 L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 b1 *XCMPLX-0K3 0cCOMPLEX1K6"
          using A3 comseq_2_th_18 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally have "limCOMSEQ-2K3 L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =HIDDENR1 0cCOMPLEX1K6"
           sorry
        have A5: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using cfdiff_1_def_3 sorry
        thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
          using A2 A3 sorry
        have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
          using cfdiff_1_def_3 sorry
        then have "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6 *XCMPLX-0K3 0cCOMPLEX1K6"
          using A2 A3 A4 A5 comseq_2_th_30 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 R (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L &  not (VarFor1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & VarFor1 be RestFunc-likeCFDIFF-1V2))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_17:
  mlet "R be C-RestFuncCFDIFF-1M1", "L be C-LinearFuncCFDIFF-1M2"
"cluster L (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R as-term-is totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds it =HIDDENR1 L (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R implies it be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>\<bar>RestFunc-likeCFDIFF-1V2"
     sorry
qed "sorry"

mdef cfdiff_1_def_5 ("NeighbourhoodCFDIFF-1M3-of  _ " [70]70 ) where
  mlet "z0 be ComplexXCMPLX-0M1"
"mode NeighbourhoodCFDIFF-1M3-of z0 \<rightarrow> SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 means
  (\<lambda>it.  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 it)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 st  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 it"
    proof-
      have " ex tVar9 be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 st {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M } be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 &  not ( for g be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 g & {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M }))"
      proof-
        let ?N = "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M }"
        show " ex tVar9 be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 st {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M } be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 &  not ( for g be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 g & {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M }))"
        proof(rule bexI[of _ "?N"])
          have "?N c=TARSKIR1 COMPLEXNUMBERSK3"
          proof-
            have "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M } c=TARSKIR1 COMPLEXNUMBERSK3"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M } implies z inHIDDENR3 COMPLEXNUMBERSK3"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume "z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M }"
                then have " ex y be ComplexXCMPLX-0M1 st z =HIDDENR1 y &  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M"
                   sorry
                thus "z inHIDDENR3 COMPLEXNUMBERSK3"
                  using xcmplx_0_def_2 sorry
              qed "sorry"
              thus "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M } c=TARSKIR1 COMPLEXNUMBERSK3"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          thus "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M } be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 &  not ( for g be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 g & {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M }))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem cfdiff_1_th_6:
" for z0 be ComplexXCMPLX-0M1 holds  for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } be NeighbourhoodCFDIFF-1M3-of z0"
proof-
  have " for z0 be ComplexXCMPLX-0M1 holds  for g be RealXREAL-0M1 holds g >XXREAL-0R4 0NUMBERSK6 implies {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } be NeighbourhoodCFDIFF-1M3-of z0"
  proof(rule ballI,rule ballI,rule impI)
    fix z0 assume [ty]: "z0 be ComplexXCMPLX-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "g >XXREAL-0R4 0NUMBERSK6"
    let ?N = "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g }"
    have A2: "?N c=TARSKIR1 COMPLEXNUMBERSK3"
    proof-
      have "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 COMPLEXNUMBERSK3"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } implies z inHIDDENR3 COMPLEXNUMBERSK3"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g }"
          then have " ex y be ComplexXCMPLX-0M1 st z =HIDDENR1 y &  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g"
             sorry
          thus "z inHIDDENR3 COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
        qed "sorry"
        thus "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 COMPLEXNUMBERSK3"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } be NeighbourhoodCFDIFF-1M3-of z0"
      using A1 A2 cfdiff_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_7:
" for z0 be ComplexXCMPLX-0M1 holds  for N be NeighbourhoodCFDIFF-1M3-of z0 holds z0 inHIDDENR3 N"
proof-
  have " for z0 be ComplexXCMPLX-0M1 holds  for N be NeighbourhoodCFDIFF-1M3-of z0 holds z0 inHIDDENR3 N"
  proof(rule ballI,rule ballI)
    fix z0 assume [ty]: "z0 be ComplexXCMPLX-0M1"
    fix N assume [ty]: "N be NeighbourhoodCFDIFF-1M3-of z0"
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A1: "0NUMBERSK6 <XXREAL-0R3 g"and A2: "{z where z be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 z -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 N"
      using cfdiff_1_def_5 sorry
    have " |.COMPLEX1K10 z0 -XCMPLX-0K6 z0 .| =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_44 sorry
    then have "z0 inHIDDENR3 {z where z be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 z -XCMPLX-0K6 z0 .| <XXREAL-0R3 g }"
      using A1 sorry
    thus "z0 inHIDDENR3 N"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma cfdiff_1_lm_1:
" for z0 be ComplexXCMPLX-0M1 holds  for N1 be NeighbourhoodCFDIFF-1M3-of z0 holds  for N2 be NeighbourhoodCFDIFF-1M3-of z0 holds  ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 N1 & N c=TARSKIR1 N2"
proof-
  have " for z0 be ComplexXCMPLX-0M1 holds  for N1 be NeighbourhoodCFDIFF-1M3-of z0 holds  for N2 be NeighbourhoodCFDIFF-1M3-of z0 holds  ex IT be setHIDDENM2 st ((IT be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 & IT be NeighbourhoodCFDIFF-1M3-of z0) & IT c=TARSKIR1 N1) & IT c=TARSKIR1 N2"
  proof(rule ballI,rule ballI,rule ballI)
    fix z0 assume [ty]: "z0 be ComplexXCMPLX-0M1"
    fix N1 assume [ty]: "N1 be NeighbourhoodCFDIFF-1M3-of z0"
    fix N2 assume [ty]: "N2 be NeighbourhoodCFDIFF-1M3-of z0"
    obtain a1 where
      [ty]:"a1 be RealXREAL-0M1" and 
      A1: "0NUMBERSK6 <XXREAL-0R3 a1"and A2: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a1 } c=TARSKIR1 N1"
      using cfdiff_1_def_5 sorry
    obtain a2 where
      [ty]:"a2 be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 a2"and A4: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a2 } c=TARSKIR1 N2"
      using cfdiff_1_def_5 sorry
    let ?g = "minXXREAL-0K4(a1,a2)"
    obtain IT where 
      [ty]:"IT be setHIDDENM2" and ITDef:"IT = {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 ?g }"
       sorry
    show " ex IT be setHIDDENM2 st ((IT be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 & IT be NeighbourhoodCFDIFF-1M3-of z0) & IT c=TARSKIR1 N1) & IT c=TARSKIR1 N2"
    proof(rule bexI[of _ "IT"])
      have A5: "?g <=XXREAL-0R1 a2"
        using xxreal_0_th_17 sorry
      have A6: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 ?g } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a2 }"
      proof-
        have "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 minXXREAL-0K4(a1,a2) } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a2 }"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 minXXREAL-0K4(a1,a2) } implies z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a2 }"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 ?g }"
            then obtain y where
              [ty]:"y be ComplexXCMPLX-0M1" and 
              A7: "z =HIDDENR1 y"and A8: " |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 ?g"
               sorry
            have " |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a2"
              using A5 A8 xxreal_0_th_2 sorry
            thus "z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a2 }"
              using A7 sorry
          qed "sorry"
          thus "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 minXXREAL-0K4(a1,a2) } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a2 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A9: "?g <=XXREAL-0R1 a1"
        using xxreal_0_th_17 sorry
      have A10: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 ?g } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a1 }"
      proof-
        have "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 minXXREAL-0K4(a1,a2) } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a1 }"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 minXXREAL-0K4(a1,a2) } implies z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a1 }"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 ?g }"
            then obtain y where
              [ty]:"y be ComplexXCMPLX-0M1" and 
              A11: "z =HIDDENR1 y"and A12: " |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 ?g"
               sorry
            have " |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a1"
              using A9 A12 xxreal_0_th_2 sorry
            thus "z inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a1 }"
              using A11 sorry
          qed "sorry"
          thus "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 minXXREAL-0K4(a1,a2) } c=TARSKIR1 {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 a1 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "0NUMBERSK6 <XXREAL-0R3 ?g"
        using A1 A3 xxreal_0_th_15 sorry
      thus "((IT be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 & IT be NeighbourhoodCFDIFF-1M3-of z0) & IT c=TARSKIR1 N1) & IT c=TARSKIR1 N2"
        using A2 A4 A10 A6 cfdiff_1_th_6 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef cfdiff_1_def_6 (" _ is-differentiable-inCFDIFF-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "z0 be ComplexXCMPLX-0M1"
"pred f is-differentiable-inCFDIFF-1R1 z0 means
   ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0))"..

mdef cfdiff_1_def_7 ("diffCFDIFF-1K2'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "z0 be ComplexXCMPLX-0M1"
"assume f is-differentiable-inCFDIFF-1R1 z0 func diffCFDIFF-1K2(f,z0) \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 means
  \<lambda>it.  ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))"
proof-
  (*existence*)
    show "f is-differentiable-inCFDIFF-1R1 z0 implies ( ex it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0))))"
    proof(rule impI)
      assume Assume: "f is-differentiable-inCFDIFF-1R1 z0"
      have A1: "f is-differentiable-inCFDIFF-1R1 z0"
        using Assume sorry
      show " ex it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))"
      proof-
        have " ex tVar11 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st (tVar11 be setHIDDENM2 & tVar11 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) &  not ( for N be NeighbourhoodCFDIFF-1M3-of z0 holds  not (N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  not ( for L be C-LinearFuncCFDIFF-1M2 holds  for R be C-RestFuncCFDIFF-1M1 holds  not (tVar11 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds  not (z inHIDDENR3 N &  not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))))))"
        proof-
          obtain N where
            [ty]:"N be NeighbourhoodCFDIFF-1M3-of z0" and 
            A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and A3: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
            using A1 sorry
          obtain L R where
            [ty]:"L be C-LinearFuncCFDIFF-1M2" "R be C-RestFuncCFDIFF-1M1" and 
            A4: " for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
            using A3 sorry
          obtain a where
            [ty]:"a be ComplexXCMPLX-0M1" and 
            A5: " for d be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> d =COMPLEX1R1 a *XCMPLX-0K3 d"
            using cfdiff_1_def_4 sorry
          show " ex tVar11 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st (tVar11 be setHIDDENM2 & tVar11 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) &  not ( for N be NeighbourhoodCFDIFF-1M3-of z0 holds  not (N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  not ( for L be C-LinearFuncCFDIFF-1M2 holds  for R be C-RestFuncCFDIFF-1M1 holds  not (tVar11 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds  not (z inHIDDENR3 N &  not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))))))"
          proof(rule bexI[of _ "a"])
            have "L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 =HIDDENR1 a *XCMPLX-0K3 1rCOMPLEX1K7"
              using A5 sorry
            also have "... = a"
               sorry
            finally have "L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 =HIDDENR1 a"
               sorry
            thus "(a be setHIDDENM2 & a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) &  not ( for N be NeighbourhoodCFDIFF-1M3-of z0 holds  not (N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  not ( for L be C-LinearFuncCFDIFF-1M2 holds  for R be C-RestFuncCFDIFF-1M1 holds  not (a =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds  not (z inHIDDENR3 N &  not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))))))"
              using A2 A4 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "f is-differentiable-inCFDIFF-1R1 z0 implies ( for it1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for it2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it1 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) & ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it2 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f is-differentiable-inCFDIFF-1R1 z0"
      have A1: "f is-differentiable-inCFDIFF-1R1 z0"
        using Assume sorry
      show " for it1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for it2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it1 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) & ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st it2 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) implies it1 =HIDDENR1 it2"
      proof-
        have " for a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for b be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st a =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) & ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st b =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))) implies a =HIDDENR1 b"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          let ?s0 = "InvShiftCFDIFF-1K1 \<two>\<^sub>M"
          fix a assume [ty]: "a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          fix b assume [ty]: "b be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          assume A6: " ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st a =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))"
            and A7: " ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st b =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)))"
          obtain N where
            [ty]:"N be NeighbourhoodCFDIFF-1M3-of z0" and 
            "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and A8: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st a =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0))"
            using A6 sorry
          obtain L R where
            [ty]:"L be C-LinearFuncCFDIFF-1M2" "R be C-RestFuncCFDIFF-1M1" and 
            A9: "a =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"and A10: " for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
            using A8 sorry
          obtain a1 where
            [ty]:"a1 be ComplexXCMPLX-0M1" and 
            A11: " for b be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> b =COMPLEX1R1 a1 *XCMPLX-0K3 b"
            using cfdiff_1_def_4 sorry
          obtain N1 where
            [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of z0" and 
            "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and A12: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st b =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 & ( for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N1 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0))"
            using A7 sorry
          obtain L1 R1 where
            [ty]:"L1 be C-LinearFuncCFDIFF-1M2" "R1 be C-RestFuncCFDIFF-1M1" and 
            A13: "b =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"and A14: " for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N1 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
            using A12 sorry
          obtain b1 where
            [ty]:"b1 be ComplexXCMPLX-0M1" and 
            A15: " for b be ComplexXCMPLX-0M1 holds L1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> b =COMPLEX1R1 b1 *XCMPLX-0K3 b"
            using cfdiff_1_def_4 sorry
          obtain s0 where 
            [ty]:"s0 be Complex-SequenceCOMSEQ-1M1" and s0Def:"s0 = ?s0"
             sorry
          obtain N0 where
            [ty]:"N0 be NeighbourhoodCFDIFF-1M3-of z0" and 
            A16: "N0 c=TARSKIR1 N & N0 c=TARSKIR1 N1"
            using cfdiff_1_lm_1 sorry
          obtain g where
            [ty]:"g be RealXREAL-0M1" and 
            A17: "0NUMBERSK6 <XXREAL-0R3 g"and A18: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 N0"
            using cfdiff_1_def_5 sorry
          let ?s1 = "g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s0"
          have A19: " for n be NatNAT-1M1 holds (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s0).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "(g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s0).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 g *XCMPLX-0K3 s0 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_6 sorry
            also have "... = g *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))"
              using cfdiff_1_def_2 sorry
            also have "... = g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
               sorry
            finally show "(g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s0).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
               sorry
          qed "sorry"
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds 0NUMBERSK6 <>HIDDENR2 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s0).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "?s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
              using A19 sorry
            thus "0NUMBERSK6 <>HIDDENR2 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s0).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
              using A17 sorry
          qed "sorry"
          then have A20: "?s1 be non-zeroORDINAL1V9"
            using comseq_1_th_4 sorry
          have "limCOMSEQ-2K3 s0 =COMPLEX1R1 0NUMBERSK6"
            using cfdiff_1_th_3 sorry
          then have "limCOMSEQ-2K3 ?s1 =COMPLEX1R1 g *XCMPLX-0K3 (0NUMBERSK6)"
            using comseq_2_th_18 sorry
          then obtain h where 
            [ty]:"h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1" and hDef:"h = ?s1"
            using A20 cfdiff_1_def_1 sorry
          have A21: " for n be NatNAT-1M1 holds  ex x be ComplexXCMPLX-0M1 st (x inHIDDENR3 N & x inHIDDENR3 N1) & h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x -XCMPLX-0K6 z0"
          proof-
            have " for n be NatNAT-1M1 holds  ex x be setHIDDENM2 st (x inHIDDENR3 N & x inHIDDENR3 N1) & h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x -XCMPLX-0K6 z0"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              obtain g0 where 
                [ty]:"g0 be ComplexXCMPLX-0M1" and g0Def:"g0 = g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
                 sorry
              obtain x where 
                [ty]:"x be setHIDDENM2" and xDef:"x = z0 +XCMPLX-0K2 g0"
                 sorry
              show " ex x be setHIDDENM2 st (x inHIDDENR3 N & x inHIDDENR3 N1) & h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x -XCMPLX-0K6 z0"
              proof(rule bexI[of _ "x"])
                have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have A22: "g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 g /XCMPLX-0K7 \<one>\<^sub>M"
                  using A17 xreal_1_th_76 sorry
                have " |.COMPLEX1K10 (z0 +XCMPLX-0K2 g0)-XCMPLX-0K6 z0 .| =COMPLEX1R1 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
                  using A17 absvalue_def_1 sorry
                then have "x inTARSKIR2 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g }"
                  using A22 sorry
                then have "x inTARSKIR2 N0"
                  using A18 sorry
                thus "(x inHIDDENR3 N & x inHIDDENR3 N1) & h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x -XCMPLX-0K6 z0"
                  using A16 A19 sorry
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A23: "a =COMPLEX1R1 a1 *XCMPLX-0K3 1rCOMPLEX1K7"
            using A9 A11 sorry
          have A24: " for z be ComplexXCMPLX-0M1 holds z inHIDDENR3 N & z inHIDDENR3 N1 implies a *XCMPLX-0K3 (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) =COMPLEX1R1 b *XCMPLX-0K3 (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
          proof(rule ballI,rule impMI ,rule impI)
            fix z assume [ty]: "z be ComplexXCMPLX-0M1"
            assume A25: "z inHIDDENR3 N"
              and A26: "z inHIDDENR3 N1"
            obtain t0 t where 
              [ty]:"t0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and t0Def:"t0 = z0" and
              [ty]:"t be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and tDef:"t = z"
              using xcmplx_0_def_2 sorry
            have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
              using A10 A25 sorry
            then have "L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
              using A14 A26 sorry
            then have "a1 *XCMPLX-0K3 (t -XCMPLX-0K6 t0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (t -XCMPLX-0K6 t0) =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (t -XCMPLX-0K6 t0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (t -XCMPLX-0K6 t0)"
              using A11 sorry
            then have "(a1 *XCMPLX-0K3 1rCOMPLEX1K7)*XCMPLX-0K3 (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) =COMPLEX1R1 (b1 *XCMPLX-0K3 1rCOMPLEX1K7)*XCMPLX-0K3 (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
              using A15 sorry
            thus "a *XCMPLX-0K3 (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0) =COMPLEX1R1 b *XCMPLX-0K3 (z -XCMPLX-0K6 z0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (z -XCMPLX-0K6 z0)"
              using A13 A15 A23 sorry
          qed "sorry"
          have A27: "a -XCMPLX-0K6 b inTARSKIR2 COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          have " for n be NatNAT-1M1 holds a -XCMPLX-0K6 b =HIDDENR1 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          proof(rule ballI)
            have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> R1 =HIDDENR1 COMPLEXNUMBERSK3"
              using partfun1_def_2 sorry
            then have A28: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> R1"
               sorry
            have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> R =HIDDENR1 COMPLEXNUMBERSK3"
              using partfun1_def_2 sorry
            then have A29: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> R"
               sorry
            fix n assume [ty]: "n be NatNAT-1M1"
            have A30: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            then have A31: "h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
              using comseq_1_th_4 sorry
            have " ex x be ComplexXCMPLX-0M1 st (x inHIDDENR3 N & x inHIDDENR3 N1) & h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x -XCMPLX-0K6 z0"
              using A21 sorry
            then have "a *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using A24 sorry
            then have A32: "(a *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)/XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) /XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (b *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))/XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using xcmplx_1_th_62 sorry
            have A33: "(b *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)/XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 b *XCMPLX-0K3 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n /XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
               sorry
            also have "... = b *XCMPLX-0K3 \<one>\<^sub>M"
              using A31 xcmplx_1_th_60 sorry
            also have "... = b"
               sorry
            finally have "(b *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)/XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 b"
               sorry
            have A34: "R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) /XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *XCMPLX-0K3 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_10 sorry
            also have "... = R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using A30 A28 funct_2_th_108 sorry
            also have "... = (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_5 sorry
            finally have "R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) /XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
               sorry
            have A35: "(a *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)/XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 a *XCMPLX-0K3 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n /XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
               sorry
            also have "... = a *XCMPLX-0K3 \<one>\<^sub>M"
              using A31 xcmplx_1_th_60 sorry
            also have "... = a"
               sorry
            finally have "(a *XCMPLX-0K3 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)/XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 a"
               sorry
            have "R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) /XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *XCMPLX-0K3 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_10 sorry
            also have "... = R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using A30 A29 funct_2_th_109 sorry
            also have "... = (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_5 sorry
            finally have "R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) /XCMPLX-0K7 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
               sorry
            then have "a -XCMPLX-0K6 b =HIDDENR1 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-XCMPLX-0K4 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using A32 A35 A33 A34 sorry
            also have "... = (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using valued_1_th_8 sorry
            also have "... = (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
              using A30 valued_1_th_1 sorry
            finally show "a -XCMPLX-0K6 b =HIDDENR1 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
               sorry
          qed "sorry"
          then have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be constantVALUED-0V15 & (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M =COMPLEX1R1 a -XCMPLX-0K6 b"
            using valued_0_def_18 A27 sorry
          then have A36: "limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 a -XCMPLX-0K6 b"
            using cfcont_1_th_28 sorry
          have A37: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
            using cfdiff_1_def_3 sorry
          have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0NUMBERSK6"
            using cfdiff_1_def_3 sorry
          then have "a -XCMPLX-0K6 b =COMPLEX1R1 0NUMBERSK6 -XCMPLX-0K6 0NUMBERSK6"
            using A36 A37 comseq_2_th_26 sorry
          thus "a =HIDDENR1 b"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef cfdiff_1_def_8 ("differentiableCFDIFF-1V4" 70 ) where
"attr differentiableCFDIFF-1V4 for PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  (\<lambda>f.  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f is-differentiable-inCFDIFF-1R1 x)"..

mdef cfdiff_1_def_9 (" _ is-differentiable-onCFDIFF-1R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "X be setHIDDENM2"
"pred f is-differentiable-onCFDIFF-1R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X be differentiableCFDIFF-1V4"..

mtheorem cfdiff_1_th_8:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 X implies X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
  using xboole_1_th_1 sorry

mdef cfdiff_1_def_10 ("closedCFDIFF-1V5" 70 ) where
"attr closedCFDIFF-1V5 for SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 means
  (\<lambda>X.  for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3 implies limCOMSEQ-2K3 s1 inHIDDENR3 X)"..

mdef cfdiff_1_def_11 ("openCFDIFF-1V6" 70 ) where
"attr openCFDIFF-1V6 for SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 means
  (\<lambda>X. X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> be closedCFDIFF-1V5)"..

mtheorem cfdiff_1_th_9:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 implies ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 X))"
proof-
  have " for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 implies ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X & ( for N be NeighbourhoodCFDIFF-1M3-of z0 holds  not N c=TARSKIR1 X) implies  False )"
  proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume "X be openCFDIFF-1V6"
    then have A1: "X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> be closedCFDIFF-1V5"
       sorry
    fix z0 assume [ty]: "z0 be ComplexXCMPLX-0M1"
    assume A2: "z0 inHIDDENR3 X"
      and A3: " for N be NeighbourhoodCFDIFF-1M3-of z0 holds  not N c=TARSKIR1 X"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M) } & Lamb2 inHIDDENR3 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    have " for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies ( ex s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st s inTARSKIR2 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } & s inTARSKIR2 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
    proof(rule ballI,rule impI)
      fix g assume [ty]: "g be RealXREAL-0M1"
      assume A4: "0NUMBERSK6 <XXREAL-0R3 g"
      let ?N = "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g }"
      have "?N be NeighbourhoodCFDIFF-1M3-of z0"
        using A4 cfdiff_1_th_6 sorry
      then have " not ?N c=TARSKIR1 X"
        using A3 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "x inHIDDENR3 ?N"and A6: " not x inHIDDENR3 X"
         sorry
      obtain s where
        [ty]:"s be ComplexXCMPLX-0M1" and 
        A7: "x =HIDDENR1 s"and A8: " |.COMPLEX1K10 s -XCMPLX-0K6 z0 .| <XXREAL-0R3 g"
        using A5 sorry
      have 
        [ty]:"s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      show " ex s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st s inTARSKIR2 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } & s inTARSKIR2 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
      proof(rule bexI[of _ "s"],rule conjMI)
        show "s inTARSKIR2 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g }"
          using A8 sorry
        show "s inTARSKIR2 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
          using A6 A7 xboole_0_def_5 sorry
      qed "sorry"
    qed "sorry"
    then have A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex s be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st ?P(n,s)"
       sorry
    obtain s1 where
      [ty]:"s1 be sequenceNAT-1M2-of COMPLEXNUMBERSK3" and 
      A10: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
      using funct_2_sch_3 A9 sorry
    have A11: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 implies y inHIDDENR3 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
        then obtain y1 where
          [ty]:"y1 be objectHIDDENM1" and 
          A12: "y1 inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> s1"and A13: "s1 .FUNCT-1K1 y1 =HIDDENR1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A12 sorry
        have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> y1 inTARSKIR2 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
          using A10 sorry
        thus "y inHIDDENR3 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
          using A13 sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
        using tarski_def_3 sorry
    qed
    have A14: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z0 .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A15: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A16: "p \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
        using seq_4_th_3 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z0 .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A17: "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        have "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m inTARSKIR2 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) }"
          using A10 sorry
        then have " ex y be ComplexXCMPLX-0M1 st s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 y &  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
        then have A18: " |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using A17 xxreal_0_th_2 sorry
        have "p \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A16 xreal_1_th_8 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 p \<inverse>XCMPLX-0K5"
          using A15 xreal_1_th_76 sorry
        thus " |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z0 .| <XXREAL-0R3 p"
          using A18 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    then have A19: "s1 be convergentCOMSEQ-2V3"
       sorry
    then have "limCOMSEQ-2K3 s1 =COMPLEX1R1 z0"
      using A14 comseq_2_def_6 sorry
    then have "z0 inHIDDENR3 COMPLEXNUMBERSK3 \\SUBSET-1K6 X"
      using A19 A11 A1 sorry
    thus " False "
      using A2 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_10:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 implies ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex g be RealXREAL-0M1 st {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 X))"
proof-
  have " for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 implies ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex tVar15 be RealXREAL-0M1 st {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 tVar15 } c=TARSKIR1 X))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A1: "X be openCFDIFF-1V6"
    fix z0 assume [ty]: "z0 be ComplexXCMPLX-0M1"
    assume "z0 inHIDDENR3 X"
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of z0" and 
      A2: "N c=TARSKIR1 X"
      using A1 cfdiff_1_th_9 sorry
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      "0NUMBERSK6 <XXREAL-0R3 g"and A3: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 N"
      using cfdiff_1_def_5 sorry
    show " ex tVar15 be RealXREAL-0M1 st {y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 tVar15 } c=TARSKIR1 X"
    proof(rule bexI[of _ "g"])
      show "{y where y be ComplexXCMPLX-0M1 :  not  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 g } c=TARSKIR1 X"
        using A2 A3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_11:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 X)) implies X be openCFDIFF-1V6"
proof-
  have " for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds ( for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 X)) &  not X be openCFDIFF-1V6 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A1: " for z0 be ComplexXCMPLX-0M1 holds z0 inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of z0 st N c=TARSKIR1 X)"
      and A2: " not X be openCFDIFF-1V6"
    have " not X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> be closedCFDIFF-1V5"
      using A2 sorry
    then obtain s1 where
      [ty]:"s1 be sequenceNAT-1M2-of COMPLEXNUMBERSK3" and 
      A3: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"and A4: "s1 be convergentCOMSEQ-2V3"and A5: " not limCOMSEQ-2K3 s1 inHIDDENR3 X `SUBSET-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
       sorry
    have "limCOMSEQ-2K3 s1 inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then have "limCOMSEQ-2K3 s1 inHIDDENR3 X"
      using A5 subset_1_th_29 sorry
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of limCOMSEQ-2K3 s1" and 
      A6: "N c=TARSKIR1 X"
      using A1 sorry
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A7: "0NUMBERSK6 <XXREAL-0R3 g"and A8: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 limCOMSEQ-2K3 s1 .| <XXREAL-0R3 g } c=TARSKIR1 N"
      using cfdiff_1_def_5 sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A9: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 s1 .| <XXREAL-0R3 g"
      using A4 A7 comseq_2_def_6 sorry
    have "n inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have "n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> s1"
      using funct_2_def_1 sorry
    then have A10: "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
      using funct_1_def_3 sorry
    have " |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 limCOMSEQ-2K3 s1 .| <XXREAL-0R3 g"
      using A9 sorry
    then have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 limCOMSEQ-2K3 s1 .| <XXREAL-0R3 g }"
       sorry
    then have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 N"
      using A8 sorry
    thus " False "
      using A3 A6 A10 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_12:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds X be openCFDIFF-1V6 iff ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies ( ex N be NeighbourhoodCFDIFF-1M3-of x st N c=TARSKIR1 X))"
  using cfdiff_1_th_9 cfdiff_1_th_11 sorry

mtheorem cfdiff_1_th_13:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for z0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for r be RealXREAL-0M1 holds X =HIDDENR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 r } implies X be openCFDIFF-1V6"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
  fix z0 assume [ty]: "z0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  fix r assume [ty]: "r be RealXREAL-0M1"
  obtain X0 where 
    [ty]:"X0 be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3" and X0Def:"X0 = X"
     sorry
  assume A1: "X =HIDDENR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 r }"
  have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X0 implies ( ex N be NeighbourhoodCFDIFF-1M3-of x st N c=TARSKIR1 X0)"
  proof-
    have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X0 implies ( ex tVar16 be NeighbourhoodCFDIFF-1M3-of x st tVar16 c=TARSKIR1 X0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      obtain r1 where 
        [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = (r -XCMPLX-0K6  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .|)/XCMPLX-0K7 \<two>\<^sub>M"
         sorry
      let ?N = "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 x .| <XXREAL-0R3 r1 }"
      assume "x inHIDDENR3 X0"
      then have " ex y be ComplexXCMPLX-0M1 st x =COMPLEX1R1 y &  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <XXREAL-0R3 r"
        using A1 sorry
      then have A2: "r -XCMPLX-0K6  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .| >XXREAL-0R4 0NUMBERSK6"
        using xreal_1_th_50 sorry
      then obtain N where 
        [ty]:"N be NeighbourhoodCFDIFF-1M3-of x" and NDef:"N = ?N"
        using cfdiff_1_th_6 sorry
      have "r1 <XXREAL-0R3 r -XCMPLX-0K6  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .|"
        using A2 xreal_1_th_216 sorry
      then have A3: "r1 +XCMPLX-0K2  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .| <XXREAL-0R3 (r -XCMPLX-0K6  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .|)+XCMPLX-0K2  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .|"
        using xreal_1_th_8 sorry
      show " ex tVar16 be NeighbourhoodCFDIFF-1M3-of x st tVar16 c=TARSKIR1 X0"
      proof(rule bexI[of _ "N"])
        have " for z be objectHIDDENM1 holds z inHIDDENR3 N implies z inHIDDENR3 X0"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 N"
          then obtain y1 where
            [ty]:"y1 be ComplexXCMPLX-0M1" and 
            A4: "z =HIDDENR1 y1"and A5: " |.COMPLEX1K10 y1 -XCMPLX-0K6 x .| <XXREAL-0R3 r1"
             sorry
          have " |.COMPLEX1K10 y1 -XCMPLX-0K6 x .| +XCMPLX-0K2  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .| <XXREAL-0R3 r1 +XCMPLX-0K2  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .|"
            using A5 xreal_1_th_8 sorry
          then have " |.COMPLEX1K10 y1 -XCMPLX-0K6 z0 .| <=XXREAL-0R1  |.COMPLEX1K10 y1 -XCMPLX-0K6 x .| +XCMPLX-0K2  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .| &  |.COMPLEX1K10 y1 -XCMPLX-0K6 x .| +XCMPLX-0K2  |.COMPLEX1K10 x -XCMPLX-0K6 z0 .| <XXREAL-0R3 r"
            using A3 complex1_th_63 xxreal_0_th_2 sorry
          then have " |.COMPLEX1K10 y1 -XCMPLX-0K6 z0 .| <XXREAL-0R3 r"
            using xxreal_0_th_2 sorry
          thus "z inHIDDENR3 X0"
            using A1 A4 sorry
        qed "sorry"
        thus "N c=TARSKIR1 X0"
          using tarski_def_3 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "X be openCFDIFF-1V6"
    using cfdiff_1_th_11 sorry
qed "sorry"

mtheorem cfdiff_1_th_14:
" for X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for z0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for r be RealXREAL-0M1 holds X =HIDDENR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <=XXREAL-0R1 r } implies X be closedCFDIFF-1V5"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
  fix z0 assume [ty]: "z0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
  fix r assume [ty]: "r be RealXREAL-0M1"
  obtain X0 where 
    [ty]:"X0 be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3" and X0Def:"X0 = X"
     sorry
  assume A1: "X =HIDDENR1 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <=XXREAL-0R1 r }"
  have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X0 & s1 be convergentCOMSEQ-2V3 implies limCOMSEQ-2K3 s1 inHIDDENR3 X0"
  proof(rule ballI,rule impMI ,rule impI)
    have 
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    let ?s4 = "seq-constSEQ-1K1 r"
    obtain s2 where 
      [ty]:"s2 be Complex-SequenceCOMSEQ-1M1" and s2Def:"s2 = NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z0"
       sorry
    fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
    assume A2: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X0"
      and A3: "s1 be convergentCOMSEQ-2V3"
    let ?s3 = "s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
    have A4: "s2 be convergentCOMSEQ-2V3"
      using cfcont_1_th_26 sorry
    then have A5: "limCOMSEQ-2K3 ?s3 =COMPLEX1R1 limCOMSEQ-2K3 s1 -XCMPLX-0K6 limCOMSEQ-2K3 s2"
      using A3 comseq_2_th_26 sorry
    have A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ?s3.|).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .|).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 z0"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "?s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using valued_1_th_1 sorry
          also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using valued_1_th_8 sorry
          finally have "?s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
             sorry
          thus "(s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 z0"
            using funcop_1_th_7 sorry
        qed "sorry"
        then have A7: "?s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 z0"
           sorry
        have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> s1 =HIDDENR1 NATNUMBERSK1"
          using funct_2_def_1 sorry
        then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
          using funct_1_def_3 sorry
        then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 X0"
          using A2 sorry
        then have " ex y be ComplexXCMPLX-0M1 st y =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n &  |.COMPLEX1K10 y -XCMPLX-0K6 z0 .| <=XXREAL-0R1 r"
          using A1 sorry
        thus "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .|).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r"
          using A7 valued_1_th_18 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "?s3 be convergentCOMSEQ-2V3"
      using A3 A4 sorry
    then have A8: "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ?s3.|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 ?s3 .|"
      using seq_2_th_27 sorry
    obtain s3 where 
      [ty]:"s3 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1" and s3Def:"s3 = s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
      using A3 A4 sorry
    have A9: " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s3.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ?s4 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof-
      have " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s3.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (seq-constSEQ-1K1 r).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A10: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s3.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 r"
          using A6 A10 sorry
        thus "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s3.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (seq-constSEQ-1K1 r).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using seq_1_th_57 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds limCOMSEQ-2K3 s2 =COMPLEX1R1 z0"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "limCOMSEQ-2K3 s2 =HIDDENR1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using cfcont_1_th_28 sorry
      also have "... = z0"
        using funcop_1_th_7 sorry
      finally have "limCOMSEQ-2K3 s2 =HIDDENR1 z0"
         sorry
      thus "limCOMSEQ-2K3 s2 =COMPLEX1R1 z0"
         sorry
    qed "sorry"
    have "limSEQ-2K1 ?s4 =HIDDENR1 ?s4 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = r"
      using seq_1_th_57 sorry
    finally have "limSEQ-2K1 ?s4 =HIDDENR1 r"
       sorry
    then have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s3.|) <=XXREAL-0R1 r"
      using A9 seq_2_th_18 sorry
    then have " |.COMPLEX1K10 limCOMSEQ-2K3 s1 -XCMPLX-0K6 z0 .| <=XXREAL-0R1 r"
      using A11 A5 A8 sorry
    thus "limCOMSEQ-2K3 s1 inHIDDENR3 X0"
      using A1 sorry
  qed "sorry"
  thus "X be closedCFDIFF-1V5"
     sorry
qed "sorry"

mtheorem cfdiff_1_cl_18:
"cluster openCFDIFF-1V6 for SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 st it be openCFDIFF-1V6"
  proof-
    have " not ( for VarFor1 be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  not VarFor1 be openCFDIFF-1V6)"
    proof-
      obtain X where 
        [ty]:"X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3" and XDef:"X = {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 \<one>\<^sub>M }"
        using cfdiff_1_th_6 sorry
      have "X be openCFDIFF-1V6"
        using cfdiff_1_th_13 sorry
      thus " not ( for VarFor1 be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  not VarFor1 be openCFDIFF-1V6)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve Z for "openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
mtheorem cfdiff_1_th_15:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds f is-differentiable-onCFDIFF-1R2 Z iff Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds (f is-differentiable-onCFDIFF-1R2 Z implies Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x)) & (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x) implies f is-differentiable-onCFDIFF-1R2 Z)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    show "f is-differentiable-onCFDIFF-1R2 Z implies Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x)"
    proof-
      have "f is-differentiable-onCFDIFF-1R2 Z implies Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x0)"
      proof(rule impI,rule conjMI,rule ballI,rule impI)
        assume A1: "f is-differentiable-onCFDIFF-1R2 Z"
        thus A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
           sorry
        fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
        have A3: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be differentiableCFDIFF-1V4"
          using A1 sorry
        assume A4: "x0 inHIDDENR3 Z"
        then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)"
          using A2 relat_1_th_57 sorry
        then have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z is-differentiable-inCFDIFF-1R1 x0"
          using A3 sorry
        then obtain N where
          [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
          A5: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)"and A6: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
           sorry
        have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Z"
          using relat_1_th_61 sorry
        then have Cut1057: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using xboole_1_th_17 sorry
        have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex tVar18 be C-LinearFuncCFDIFF-1M2 st  ex tVar19 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 tVar18 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar19 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        proof(rule conjMI)
          show "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
            using A5 Cut1057 sorry
          obtain L R where
            [ty]:"L be C-LinearFuncCFDIFF-1M2" "R be C-RestFuncCFDIFF-1M1" and 
            A7: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            using A6 sorry
          show " ex tVar18 be C-LinearFuncCFDIFF-1M2 st  ex tVar19 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 tVar18 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar19 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
          proof(rule bexI[of _ "L"])
            show " ex tVar19 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar19 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            proof(rule bexI[of _ "R"],rule ballI,rule impI)
              fix x assume [ty]: "x be ComplexXCMPLX-0M1"
              assume A8: "x inHIDDENR3 N"
              then have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A7 sorry
              then have A9: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A5 A8 partfun2_th_15 sorry
              have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Z"
                using A2 A4 xboole_0_def_4 sorry
              thus "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A9 partfun2_th_16 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus "f is-differentiable-inCFDIFF-1R1 x0"
          using bexI[of _ "N"] cfdiff_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A10: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A11: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x"
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be differentiableCFDIFF-1V4"
    proof(rule conjMI)
      show "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A10 sorry
      have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z) implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z is-differentiable-inCFDIFF-1R1 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
        assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)"
        then have A12: "x0 inHIDDENR3 Z"
          using relat_1_th_57 sorry
        then obtain N1 where
          [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
          A13: "N1 c=TARSKIR1 Z"
          using cfdiff_1_th_9 sorry
        have "f is-differentiable-inCFDIFF-1R1 x0"
          using A11 A12 sorry
        then obtain N where
          [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
          A14: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and A15: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
           sorry
        obtain N2 where
          [ty]:"N2 be NeighbourhoodCFDIFF-1M3-of x0" and 
          A16: "N2 c=TARSKIR1 N1"and A17: "N2 c=TARSKIR1 N"
          using cfdiff_1_lm_1 sorry
        have A18: "N2 c=TARSKIR1 Z"
          using A13 A16 sorry
        have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A14 A17 sorry
        then have Cut1091: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Z"
          using A18 xboole_1_th_19 sorry
        have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z) & ( ex tVar21 be C-LinearFuncCFDIFF-1M2 st  ex tVar22 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 tVar21 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar22 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        proof(rule conjMI)
          show A19: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)"
            using relat_1_th_61 Cut1091 sorry
          obtain L R where
            [ty]:"L be C-LinearFuncCFDIFF-1M2" "R be C-RestFuncCFDIFF-1M1" and 
            A20: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            using A15 sorry
          have A21: "x0 inHIDDENR3 N2"
            using cfdiff_1_th_7 sorry
          show " ex tVar21 be C-LinearFuncCFDIFF-1M2 st  ex tVar22 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 tVar21 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar22 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
          proof(rule bexI[of _ "L"])
            show " ex tVar22 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar22 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            proof(rule bexI[of _ "R"],rule ballI,rule impI)
              fix x assume [ty]: "x be ComplexXCMPLX-0M1"
              assume A22: "x inHIDDENR3 N2"
              then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A17 A20 sorry
              then have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A19 A22 partfun2_th_15 sorry
              thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A19 A21 partfun2_th_15 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z is-differentiable-inCFDIFF-1R1 x0"
          using bexI[of _ "N2"] cfdiff_1_def_6 sorry
      qed "sorry"
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be differentiableCFDIFF-1V4"
        using cfdiff_1_def_8 sorry
    qed
    thus "f is-differentiable-onCFDIFF-1R2 Z"
      using cfdiff_1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_16:
" for Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 Y implies Y be openCFDIFF-1V6"
proof-
  have " for Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 Y implies Y be openCFDIFF-1V6"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f is-differentiable-onCFDIFF-1R2 Y"
    then have A2: "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
       sorry
    have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Y implies ( ex N be NeighbourhoodCFDIFF-1M3-of x0 st N c=TARSKIR1 Y)"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume "x0 inHIDDENR3 Y"
      then have A3: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y)"
        using A2 relat_1_th_57 sorry
      have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y be differentiableCFDIFF-1V4"
        using A1 sorry
      then have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y is-differentiable-inCFDIFF-1R1 x0"
        using A3 sorry
      then obtain N where
        [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
        A4: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y)"and " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
         sorry
      show " ex N be NeighbourhoodCFDIFF-1M3-of x0 st N c=TARSKIR1 Y"
      proof(rule bexI[of _ "N"])
        have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Y"
          using relat_1_th_61 sorry
        then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) c=TARSKIR1 Y"
          using xboole_1_th_17 sorry
        thus "N c=TARSKIR1 Y"
          using A4 sorry
      qed "sorry"
    qed "sorry"
    thus "Y be openCFDIFF-1V6"
      using cfdiff_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef cfdiff_1_def_12 (" _ `|CFDIFF-1K3  _ " [164,164]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "X be setHIDDENM2"
"assume f is-differentiable-onCFDIFF-1R2 X func f `|CFDIFF-1K3 X \<rightarrow> PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) means
  \<lambda>it. domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))"
proof-
  (*existence*)
    show "f is-differentiable-onCFDIFF-1R2 X implies ( ex it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)))"
    proof(rule impI)
      assume Assume: "f is-differentiable-onCFDIFF-1R2 X"
      have A1: "f is-differentiable-onCFDIFF-1R2 X"
        using Assume sorry
      show " ex it be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))"
      proof-
        have " ex tVar24 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar24 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 X &  not tVar24 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)))"
        proof-
          let ?F = "\<lambda>Lamb1. diffCFDIFF-1K2(f,Lamb1)"
          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
          obtain F where
            [ty]:"F be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
            A2: "( for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F iff ?P(x)) & ( for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F implies F .FUNCT-1K1 x =COMPLEX1R1 ?F(x))"
            using seq_1_sch_3 sorry
          show " ex tVar24 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) st domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar24 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 X &  not tVar24 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)))"
          proof(rule bexI[of _ "F"],rule conjMI)
            have " for y be objectHIDDENM1 holds y inHIDDENR3 X implies y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
            proof(rule ballI,rule impI)
              have A3: "X be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
                using A1 cfdiff_1_th_8 sorry
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 X"
              thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
                using A2 A3 sorry
            qed "sorry"
            then have A4: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
               sorry
            have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F implies y inHIDDENR3 X"
              using A2 sorry
            then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F c=TARSKIR1 X"
               sorry
            thus "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F =HIDDENR1 X"
              using A4 sorry
            have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be ComplexXCMPLX-0M1"
              assume A5: "x inHIDDENR3 X"
              have "x inHIDDENR3 COMPLEXNUMBERSK3"
                using xcmplx_0_def_2 sorry
              then have A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
                using A2 A5 sorry
              then have "F .FUNCT-1K1 x =COMPLEX1R1 diffCFDIFF-1K2(f,x)"
                using A2 sorry
              thus "F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)"
                using A6 partfun1_def_6 sorry
            qed "sorry"
            thus " for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 X &  not F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))"
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "f is-differentiable-onCFDIFF-1R2 X implies ( for it1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it1 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))) & (domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it2 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f is-differentiable-onCFDIFF-1R2 X"
      have A1: "f is-differentiable-onCFDIFF-1R2 X"
        using Assume sorry
      show " for it1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for it2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it1 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))) & (domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> it2 =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies it2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x))) implies it1 =HIDDENR1 it2"
      proof-
        have " for F be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for G be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F =HIDDENR1 X & (( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)) & (domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> G =HIDDENR1 X & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies G /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)))) implies F =HIDDENR1 G"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
          fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
          assume A7: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F =HIDDENR1 X"
            and A8: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)"
            and A9: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> G =HIDDENR1 X"
            and A10: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies G /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)"
          have " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F implies F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 G /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            assume A11: "x inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> F"
            then have "F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f,x)"
              using A7 A8 sorry
            thus "F /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 G /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x"
              using A7 A10 A11 sorry
          qed "sorry"
          thus "F =HIDDENR1 G"
            using A7 A9 partfun2_th_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem cfdiff_1_th_17:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex a1 be ComplexXCMPLX-0M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =HIDDENR1 {TARSKIK1 a1}) implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 0cCOMPLEX1K6)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies (( ex a1 be ComplexXCMPLX-0M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =HIDDENR1 {TARSKIK1 a1}) implies f is-differentiable-onCFDIFF-1R2 Z & ( for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 0cCOMPLEX1K6))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI,rule ballI,rule impI)
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and cfDef:"cf = COMPLEXNUMBERSK3 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
       sorry
    let ?R = "cf"
    have A1: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R =HIDDENR1 COMPLEXNUMBERSK3"
      using funcop_1_th_13 sorry
    have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
    proof(rule ballI)
      fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
      have " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A2: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R & n inTARSKIR2 NATNUMBERSK1"
          using A1 ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_5 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using A2 funct_2_th_109 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6"
          using funcop_1_th_7 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      then have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be constantVALUED-0V15 & (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0cCOMPLEX1K6"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
        using cfcont_1_th_26 cfcont_1_th_27 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = ?R"
      using cfdiff_1_def_3 sorry
    let ?L = "cf"
    have " for z be ComplexXCMPLX-0M1 holds ?L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 0cCOMPLEX1K6 *XCMPLX-0K3 z"
      using xcmplx_0_def_2 funcop_1_th_7 sorry
    then obtain L where 
      [ty]:"L be C-LinearFuncCFDIFF-1M2" and LDef:"L = ?L"
      using cfdiff_1_def_4 sorry
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    assume Given: " ex a1 be ComplexXCMPLX-0M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =HIDDENR1 {TARSKIK1 a1}"
    then obtain a1 where
      [ty]:"a1 be ComplexXCMPLX-0M1" and 
      A4: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =HIDDENR1 {TARSKIK1 a1}"
       sorry
    have A5: " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 a1"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      then have "f .FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 a1}"
        using A4 funct_1_def_3 sorry
      then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 inTARSKIR2 {TARSKIK1 a1}"
        using A6 partfun1_def_6 sorry
      thus "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 a1"
        using tarski_def_1 sorry
    qed "sorry"
    have A7: " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume A8: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
        A9: "N c=TARSKIR1 Z"
        using cfdiff_1_th_9 sorry
      have A10: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A3 A9 sorry
      have A11: " for x be ComplexXCMPLX-0M1 holds x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be ComplexXCMPLX-0M1"
          assume "x inHIDDENR3 N"
          then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 a1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
            using A5 A10 sorry
          also have "... = a1 -XCMPLX-0K6 a1"
            using A3 A5 A8 sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
            using funcop_1_th_7 A11 sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 A11 sorry
          finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-differentiable-inCFDIFF-1R1 x0"
        using A10 sorry
    qed "sorry"
    thus A12: "f is-differentiable-onCFDIFF-1R2 Z"
      using A3 cfdiff_1_th_15 sorry
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A13: "x0 inHIDDENR3 Z"
    then have A14: "f is-differentiable-inCFDIFF-1R1 x0"
      using A7 sorry
    then have " ex N be NeighbourhoodCFDIFF-1M3-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
       sorry
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A15: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
       sorry
    have A16: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ComplexXCMPLX-0M1"
        have A17: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        assume "x inHIDDENR3 N"
        then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 a1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
          using A5 A15 sorry
        also have "... = a1 -XCMPLX-0K6 a1"
          using A3 A5 A13 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
          using funcop_1_th_7 A17 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 A17 sorry
        finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 diffCFDIFF-1K2(f,x0)"
      using A12 A13 cfdiff_1_def_12 sorry
    also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A14 A15 A16 cfdiff_1_def_7 sorry
    also have "... = 0cCOMPLEX1K6"
      using funcop_1_th_7 sorry
    finally show "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 0cCOMPLEX1K6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_cl_19:
  mlet "seq be non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1", "k be NatNAT-1M1"
"cluster seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k as-term-is non-zeroORDINAL1V9"
proof
(*coherence*)
  show "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9"
  proof-
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 k)"
        using nat_1_def_3 sorry
      thus "(seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
        using comseq_1_th_4 sorry
    qed "sorry"
    thus "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9"
      using comseq_1_th_4 sorry
  qed
qed "sorry"

mtheorem cfdiff_1_cl_20:
  mlet "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1", "n be NatNAT-1M1"
"cluster h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n as-term-is 0NUMBERSK6 -convergentCFDIFF-1V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies it be 0NUMBERSK6 -convergentCFDIFF-1V1"
  proof-
    have " for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not (VarFor1 =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n &  not VarFor1 be 0NUMBERSK6 -convergentCFDIFF-1V1)"
    proof-
      have "limCOMSEQ-2K3 h =COMPLEX1R1 0NUMBERSK6"
        using cfdiff_1_def_1 sorry
      then have A1: "limCOMSEQ-2K3 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 0NUMBERSK6"
        using cfcont_1_th_21 sorry
      have "h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be convergentCOMSEQ-2V3"
        using cfcont_1_th_21 sorry
      thus " for VarFor1 be Complex-SequenceCOMSEQ-1M1 holds  not (VarFor1 =HIDDENR1 h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n &  not VarFor1 be 0NUMBERSK6 -convergentCFDIFF-1V1)"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem cfdiff_1_th_18:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A1: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "((seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) +XCMPLX-0K2 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using valued_1_th_1 A1 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "((seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_19:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A1: "n +XCMPLX-0K2 k inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "((seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using valued_1_th_1 A1 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) +XCMPLX-0K2 (-XCMPLX-0K4 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k))"
        using valued_1_th_8 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-XCMPLX-0K4 (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_8 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "((seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_20:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k))\<inverse>XCMPLX-0K5"
        using valued_1_th_10 sorry
      also have "... = ((seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "(seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_21:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using valued_1_th_5 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using nat_1_def_3 sorry
      also have "... = ((seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "((seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_22:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds  for N be NeighbourhoodCFDIFF-1M3-of x0 holds f is-differentiable-inCFDIFF-1R1 x0 & N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies ( for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds  for c be constantVALUED-0V15\<bar>Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) c=TARSKIR1 N implies h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) be convergentCOMSEQ-2V3 & diffCFDIFF-1K2(f,x0) =COMPLEX1R1 limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds  for N be NeighbourhoodCFDIFF-1M3-of x0 holds f is-differentiable-inCFDIFF-1R1 x0 & N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies ( for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds  for c be constantVALUED-0V15\<bar>Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) c=TARSKIR1 N implies h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) be convergentCOMSEQ-2V3 & diffCFDIFF-1K2(f,x0) =COMPLEX1R1 limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix N assume [ty]: "N be NeighbourhoodCFDIFF-1M3-of x0"
    assume A1: "f is-differentiable-inCFDIFF-1R1 x0"
      and A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
      "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and A3: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A4: "N2 c=TARSKIR1 N"and A5: "N2 c=TARSKIR1 N1"
      using cfdiff_1_lm_1 sorry
    have A6: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A2 A4 sorry
    fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
    fix c assume [ty]: "c be constantVALUED-0V15\<bar>Complex-SequenceCOMSEQ-1M1"
    assume A7: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 {TARSKIK1 x0}"
      and A8: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) c=TARSKIR1 N"
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A9: "0NUMBERSK6 <XXREAL-0R3 g"and A10: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 x0 .| <XXREAL-0R3 g } c=TARSKIR1 N2"
      using cfdiff_1_def_5 sorry
    have " |.COMPLEX1K10 x0 -XCMPLX-0K6 x0 .| =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_44 sorry
    then have "x0 inHIDDENR3 {y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 x0 .| <XXREAL-0R3 g }"
      using A9 sorry
    then have A11: "x0 inHIDDENR3 N2"
      using A10 sorry
    have A12: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c implies y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        then have "y =HIDDENR1 x0"
          using A7 tarski_def_1 sorry
        then have "y inHIDDENR3 N"
          using A4 A11 sorry
        thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A2 sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using tarski_def_3 sorry
    qed
    have " ex n be NatNAT-1M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 N2 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 N2"
    proof-
      have " ex tVar25 be NatNAT-1M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar25) c=TARSKIR1 N2 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar25) c=TARSKIR1 N2"
      proof-
        have "x0 inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          using A7 tarski_def_1 sorry
        then have A13: "limCOMSEQ-2K3 c =COMPLEX1R1 x0"
          using cfcont_1_th_27 sorry
        have A14: "c be convergentCOMSEQ-2V3"
          using cfcont_1_th_26 sorry
        then have A15: "h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c be convergentCOMSEQ-2V3"
           sorry
        have "limCOMSEQ-2K3 h =COMPLEX1R1 0NUMBERSK6"
          using cfdiff_1_def_1 sorry
        then have "limCOMSEQ-2K3 (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 x0"
          using A14 A13 comseq_2_th_14 sorry
        also have "... = x0"
           sorry
        finally have "limCOMSEQ-2K3 (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) =HIDDENR1 x0"
           sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A16: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
          using A9 A15 comseq_2_def_6 sorry
        show " ex tVar25 be NatNAT-1M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar25) c=TARSKIR1 N2 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar25) c=TARSKIR1 N2"
        proof(rule bexI[of _ "n"],rule conjMI)
          have A17: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 {TARSKIK1 x0}"
            using A7 valued_0_th_26 sorry
          show "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 N2"
            using A11 A17 tarski_def_1 sorry
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies y inHIDDENR3 N2"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
            then obtain m where
              [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A18: "y =HIDDENR1 ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
              using funct_2_th_113 sorry
            obtain y1 where 
              [ty]:"y1 be ComplexXCMPLX-0M1" and y1Def:"y1 = y"
              using A18 sorry
            have "n +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 n +NAT-1K1 m"
              using xreal_1_th_7 sorry
            then have " |.COMPLEX1K10 (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 m) -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
              using A16 sorry
            then have " |.COMPLEX1K10 ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
              using nat_1_def_3 sorry
            then have "y1 inHIDDENR3 {z where z be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 z -XCMPLX-0K6 x0 .| <XXREAL-0R3 g }"
              using A18 sorry
            thus "y inHIDDENR3 N2"
              using A10 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 N2"
            using tarski_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 N2"and A19: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 N2"
       sorry
    obtain L R where
      [ty]:"L be C-LinearFuncCFDIFF-1M2" "R be C-RestFuncCFDIFF-1M1" and 
      A20: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A3 sorry
    have A21: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A22: "y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          using valued_0_th_26 sorry
        then have "y =HIDDENR1 x0"
          using A7 A22 tarski_def_1 sorry
        then have "y inHIDDENR3 N"
          using A4 A11 sorry
        thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A2 sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using tarski_def_3 sorry
    qed
    have A23: "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 ((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>) =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
    proof(rule conjMI)
      let ?F = "\<lambda>Lamb1. L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
      obtain s1 where
        [ty]:"s1 be Complex-SequenceCOMSEQ-1M1" and 
        A24: " for k be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 ?F(k)"
        using comseq_1_sch_1 sorry
      have A25: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n1 be NatNAT-1M1 st  for k be NatNAT-1M1 holds n1 <=XXREAL-0R1 k implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 .| <XXREAL-0R3 r)"
      proof(rule ballI,rule impI)
        have A26: "(h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)) =COMPLEX1R1 0NUMBERSK6"
          using cfdiff_1_def_3 sorry
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "0NUMBERSK6 <XXREAL-0R3 r"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A27: " for k be NatNAT-1M1 holds m <=XXREAL-0R1 k implies  |.COMPLEX1K10 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 r"
          using A26 comseq_2_def_6 sorry
        obtain n1 where 
          [ty]:"n1 be NatNAT-1M1" and n1Def:"n1 = m"
           sorry
        show " ex n1 be NatNAT-1M1 st  for k be NatNAT-1M1 holds n1 <=XXREAL-0R1 k implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 .| <XXREAL-0R3 r"
        proof(rule bexI[of _ "n1"],rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A28: "n1 <=XXREAL-0R1 k"
          have " |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 .| =HIDDENR1  |.COMPLEX1K10 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)-XCMPLX-0K6 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 .|"
            using A24 sorry
          also have "... =  |.COMPLEX1K10 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 0cCOMPLEX1K6 .|"
             sorry
          finally have " |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 .| =HIDDENR1  |.COMPLEX1K10 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 0cCOMPLEX1K6 .|"
             sorry
          thus " |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 .| <XXREAL-0R3 r"
            using A27 A28 sorry
        qed "sorry"
      qed "sorry"
      obtain x where
        [ty]:"x be ComplexXCMPLX-0M1" and 
        A29: " for b1 be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> b1 =COMPLEX1R1 x *XCMPLX-0K3 b1"
        using cfdiff_1_def_4 sorry
      have A30: "L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 =HIDDENR1 x *XCMPLX-0K3 1rCOMPLEX1K7"
        using A29 sorry
      also have "... = x"
         sorry
      finally have "L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 =HIDDENR1 x"
         sorry
      have " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
      proof(rule ballI)
        fix m assume [ty]: "m be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A31: "(h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 0cCOMPLEX1K6"
          using comseq_1_th_4 sorry
        have "((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m =HIDDENR1 (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m *XCMPLX-0K3 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using valued_1_th_5 sorry
        also have "... = (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m +XCMPLX-0K2 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m)*XCMPLX-0K3 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using valued_1_th_1 sorry
        also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m *XCMPLX-0K3 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m +XCMPLX-0K2 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m *XCMPLX-0K3 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
           sorry
        also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m *XCMPLX-0K3 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using valued_1_th_5 sorry
        also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m *XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using valued_1_th_10 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m) *XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using funct_2_th_115 sorry
        also have "... = (x *XCMPLX-0K3 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m)*XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using A29 sorry
        also have "... = x *XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m *XCMPLX-0K3 ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
           sorry
        also have "... = x *XCMPLX-0K3 1rCOMPLEX1K7 +XCMPLX-0K2 (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using A31 xcmplx_0_def_7 sorry
        also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
          using A24 A30 sorry
        finally show "((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> m"
           sorry
      qed "sorry"
      then have A32: "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
      thus "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be convergentCOMSEQ-2V3"
        using A25 sorry
      thus "limCOMSEQ-2K3 ((L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>) =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
        using A32 A25 comseq_2_def_6 sorry
    qed
    have A33: " for k be NatNAT-1M1 holds f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have A34: "k +XCMPLX-0K2 n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A35: "k inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using funct_2_th_112 sorry
      then have A36: "((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k inTARSKIR2 N2"
        using A19 sorry
      have "(c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        using funct_2_th_112 valued_0_th_26 A35 sorry
      then have A37: "(c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 x0"
        using A7 tarski_def_1 sorry
      have "((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +XCMPLX-0K2 n) -XCMPLX-0K6 (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using nat_1_def_3 sorry
      also have "... = (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +XCMPLX-0K2 n) +XCMPLX-0K2 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +XCMPLX-0K2 n))-XCMPLX-0K6 (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using valued_1_th_1 A34 sorry
      also have "... = ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +XCMPLX-0K2 n))-XCMPLX-0K6 (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using nat_1_def_3 sorry
      also have "... = ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)-XCMPLX-0K6 (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
        using nat_1_def_3 sorry
      also have "... = (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
         sorry
      finally have "((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
         sorry
      thus "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
        using A20 A5 A36 A37 sorry
    qed "sorry"
    have A38: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A8 A2 sorry
    have A39: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A19 A4 A2 sorry
    have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k"
    proof(rule ballI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k"
        using cfcont_1_th_1 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k"
        using A39 funct_2_th_109 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k)"
        using A21 funct_2_th_109 sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k)"
        using A33 sorry
      also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k)"
        using funct_2_th_115 sorry
      also have "... = L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k"
        using funct_2_th_115 sorry
      also have "... = (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k"
        using valued_1_th_1 sorry
      finally show "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k =HIDDENR1 (L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> k"
         sorry
    qed "sorry"
    then have A40: "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using funct_2_def_7 sorry
    also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using A38 valued_0_th_27 sorry
    also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using A12 valued_0_th_27 sorry
    also have "... = ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using cfdiff_1_th_19 sorry
    also have "... = ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
      using cfdiff_1_th_20 sorry
    also have "... = ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      using cfdiff_1_th_21 sorry
    finally have "(L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =HIDDENR1 ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
       sorry
    then have A41: "L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 =COMPLEX1R1 limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c))"
      using A23 cfcont_1_th_23 sorry
    show "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) be convergentCOMSEQ-2V3"
      using A23 A40 cfcont_1_th_22 sorry
    have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A20 A5 sorry
    thus "diffCFDIFF-1K2(f,x0) =COMPLEX1R1 limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c))"
      using A1 A6 A41 cfdiff_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_23:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =COMPLEX1R1 diffCFDIFF-1K2(f1,x0) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x0)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 diffCFDIFF-1K2(f1,x0) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A1: "f1 is-differentiable-inCFDIFF-1R1 x0"
      and A2: "f2 is-differentiable-inCFDIFF-1R1 x0"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A3: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"and A4: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain L1 R1 where
      [ty]:"L1 be C-LinearFuncCFDIFF-1M2" "R1 be C-RestFuncCFDIFF-1M1" and 
      A5: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A4 sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A6: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"and A7: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A2 sorry
    obtain L2 R2 where
      [ty]:"L2 be C-LinearFuncCFDIFF-1M2" "R2 be C-RestFuncCFDIFF-1M1" and 
      A8: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A7 sorry
    obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = R1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2"
       sorry
    obtain L where 
      [ty]:"L be C-LinearFuncCFDIFF-1M2" and LDef:"L = L1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2"
       sorry
    obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A9: "N c=TARSKIR1 N1"and A10: "N c=TARSKIR1 N2"
      using cfdiff_1_lm_1 sorry
    have A11: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A6 A10 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
      using A3 A9 sorry
    then have "N /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A11 xboole_1_th_27 sorry
    then have A12: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using valued_1_def_1 sorry
    have A13: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      have A14: "x0 inHIDDENR3 N"
        using cfdiff_1_th_7 sorry
      have A15: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      assume A16: "x inHIDDENR3 N"
      then have "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x)-XCMPLX-0K6 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A12 cfunct_1_th_1 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x)-XCMPLX-0K6 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
        using A12 A14 cfunct_1_th_1 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)+XCMPLX-0K2 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
         sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
        using A5 A9 A16 sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using A8 A10 A16 sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        using cfunct_1_th_64 A15 sorry
      finally show "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
      using A12 sorry
    then have "diffCFDIFF-1K2(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A12 A13 cfdiff_1_def_7 sorry
    also have "... = L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 +XCMPLX-0K2 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using cfunct_1_th_64 sorry
    also have "... = diffCFDIFF-1K2(f1,x0) +XCMPLX-0K2 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A1 A3 A5 cfdiff_1_def_7 sorry
    also have "... = diffCFDIFF-1K2(f1,x0) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x0)"
      using A2 A6 A8 cfdiff_1_def_7 sorry
    finally show "diffCFDIFF-1K2(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 diffCFDIFF-1K2(f1,x0) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_24:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =COMPLEX1R1 diffCFDIFF-1K2(f1,x0) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x0)"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 diffCFDIFF-1K2(f1,x0) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A1: "f1 is-differentiable-inCFDIFF-1R1 x0"
      and A2: "f2 is-differentiable-inCFDIFF-1R1 x0"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A3: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"and A4: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain L1 R1 where
      [ty]:"L1 be C-LinearFuncCFDIFF-1M2" "R1 be C-RestFuncCFDIFF-1M1" and 
      A5: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A4 sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A6: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"and A7: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A2 sorry
    obtain L2 R2 where
      [ty]:"L2 be C-LinearFuncCFDIFF-1M2" "R2 be C-RestFuncCFDIFF-1M1" and 
      A8: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A7 sorry
    obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = R1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2"
       sorry
    obtain L where 
      [ty]:"L be C-LinearFuncCFDIFF-1M2" and LDef:"L = L1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2"
       sorry
    obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A9: "N c=TARSKIR1 N1"and A10: "N c=TARSKIR1 N2"
      using cfdiff_1_lm_1 sorry
    have A11: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A6 A10 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
      using A3 A9 sorry
    then have "N /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A11 xboole_1_th_27 sorry
    then have A12: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_2 sorry
    have A13: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      have A14: "x0 inHIDDENR3 N"
        using cfdiff_1_th_7 sorry
      have A15: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      assume A16: "x inHIDDENR3 N"
      then have "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x)-XCMPLX-0K6 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A12 cfunct_1_th_2 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x)-XCMPLX-0K6 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
        using A12 A14 cfunct_1_th_2 sorry
      also have "... = (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)-XCMPLX-0K6 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
         sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))-XCMPLX-0K6 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
        using A5 A9 A16 sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))-XCMPLX-0K6 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using A8 A10 A16 sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) -XCMPLX-0K6 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) -XCMPLX-0K6 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) -XCMPLX-0K6 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        using cfunct_1_th_64 A15 sorry
      finally show "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
      using A12 sorry
    then have "diffCFDIFF-1K2(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A12 A13 cfdiff_1_def_7 sorry
    also have "... = L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 -XCMPLX-0K6 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using cfunct_1_th_64 sorry
    also have "... = diffCFDIFF-1K2(f1,x0) -XCMPLX-0K6 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A1 A3 A5 cfdiff_1_def_7 sorry
    also have "... = diffCFDIFF-1K2(f1,x0) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x0)"
      using A2 A6 A8 cfdiff_1_def_7 sorry
    finally show "diffCFDIFF-1K2(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 diffCFDIFF-1K2(f1,x0) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x0)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_25:
" for a be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f is-differentiable-inCFDIFF-1R1 x0 implies a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f,x0) =COMPLEX1R1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x0))"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f is-differentiable-inCFDIFF-1R1 x0 implies a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f,x0) =HIDDENR1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A1: "f is-differentiable-inCFDIFF-1R1 x0"
    then obtain N1 where
      [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A2: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and A3: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
       sorry
    obtain L1 R1 where
      [ty]:"L1 be C-LinearFuncCFDIFF-1M2" "R1 be C-RestFuncCFDIFF-1M1" and 
      A4: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A3 sorry
    obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1"
       sorry
    obtain L where 
      [ty]:"L be C-LinearFuncCFDIFF-1M2" and LDef:"L = a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L1"
       sorry
    have A5: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
      using A2 valued_1_def_5 sorry
    have A6: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      have A7: "x0 inHIDDENR3 N1"
        using cfdiff_1_th_7 sorry
      have A8: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      assume A9: "x inHIDDENR3 N1"
      then have "(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 a *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A5 cfunct_1_th_4 sorry
      also have "... = a *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 a *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A5 A7 cfunct_1_th_4 sorry
      also have "... = a *XCMPLX-0K3 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
         sorry
      also have "... = a *XCMPLX-0K3 (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using A4 A9 sorry
      also have "... = a *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 a *XCMPLX-0K3 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
         sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 a *XCMPLX-0K3 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        using cfunct_1_th_65 A8 sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        using cfunct_1_th_65 A8 sorry
      finally show "(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-inCFDIFF-1R1 x0"
      using A5 sorry
    then have "diffCFDIFF-1K2(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f,x0) =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A5 A6 cfdiff_1_def_7 sorry
    also have "... = a *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using cfunct_1_th_65 sorry
    also have "... = a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x0))"
      using A1 A2 A4 cfdiff_1_def_7 sorry
    finally show "diffCFDIFF-1K2(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f,x0) =HIDDENR1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_26:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x0)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x0))"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0 implies f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0 & diffCFDIFF-1K2(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x0)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A1: "f1 is-differentiable-inCFDIFF-1R1 x0"
      and A2: "f2 is-differentiable-inCFDIFF-1R1 x0"
    obtain N2 where
      [ty]:"N2 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A3: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"and A4: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A2 sorry
    obtain L2 R2 where
      [ty]:"L2 be C-LinearFuncCFDIFF-1M2" "R2 be C-RestFuncCFDIFF-1M1" and 
      A5: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A4 sorry
    obtain R12 where 
      [ty]:"R12 be C-RestFuncCFDIFF-1M1" and R12Def:"R12 = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2"
       sorry
    obtain L12 where 
      [ty]:"L12 be C-LinearFuncCFDIFF-1M2" and L12Def:"L12 = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2"
       sorry
    obtain N1 where
      [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A6: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"and A7: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A1 sorry
    obtain L1 R1 where
      [ty]:"L1 be C-LinearFuncCFDIFF-1M2" "R1 be C-RestFuncCFDIFF-1M1" and 
      A8: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N1 implies f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A7 sorry
    obtain R11 where 
      [ty]:"R11 be C-RestFuncCFDIFF-1M1" and R11Def:"R11 = f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R1"
       sorry
    obtain L11 where 
      [ty]:"L11 be C-LinearFuncCFDIFF-1M2" and L11Def:"L11 = f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L1"
       sorry
    obtain R18 where 
      [ty]:"R18 be C-RestFuncCFDIFF-1M1" and R18Def:"R18 = R2 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L1"
       sorry
    obtain R17 where 
      [ty]:"R17 be C-RestFuncCFDIFF-1M1" and R17Def:"R17 = R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R2"
       sorry
    obtain R16 where 
      [ty]:"R16 be C-RestFuncCFDIFF-1M1" and R16Def:"R16 = R1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2"
       sorry
    obtain R14 where 
      [ty]:"R14 be C-RestFuncCFDIFF-1M1" and R14Def:"R14 = L1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L2"
       sorry
    obtain R13 where 
      [ty]:"R13 be C-RestFuncCFDIFF-1M1" and R13Def:"R13 = R11 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R12"
       sorry
    obtain L where 
      [ty]:"L be C-LinearFuncCFDIFF-1M2" and LDef:"L = L11 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> L12"
       sorry
    obtain R15 where 
      [ty]:"R15 be C-RestFuncCFDIFF-1M1" and R15Def:"R15 = R13 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R14"
       sorry
    obtain R19 where 
      [ty]:"R19 be C-RestFuncCFDIFF-1M1" and R19Def:"R19 = R16 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R17"
       sorry
    obtain R20 where 
      [ty]:"R20 be C-RestFuncCFDIFF-1M1" and R20Def:"R20 = R19 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R18"
       sorry
    obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = R15 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R20"
       sorry
    obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A9: "N c=TARSKIR1 N1"and A10: "N c=TARSKIR1 N2"
      using cfdiff_1_lm_1 sorry
    have A11: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A3 A10 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
      using A6 A9 sorry
    then have "N /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A11 xboole_1_th_27 sorry
    then have A12: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using valued_1_def_4 sorry
    have A13: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      have A14: "x0 inHIDDENR3 N"
        using cfdiff_1_th_7 sorry
      have A15: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      assume A16: "x inHIDDENR3 N"
      then have A17: "(f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)+XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A8 A9 sorry
      have "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A12 A16 cfunct_1_th_3 sorry
      also have "... = ((f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x +XCMPLX-0K2 (-XCMPLX-0K4 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0))+XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)-XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A12 A14 cfunct_1_th_3 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0) +XCMPLX-0K2 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)*XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
         sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0) +XCMPLX-0K2 (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))*XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A8 A9 A16 sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0) +XCMPLX-0K2 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)"
         sorry
      also have "... = f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0) +XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_65 A15 sorry
      also have "... = ((L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)*XCMPLX-0K3 (f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0) +XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using A17 cfunct_1_th_65 A15 sorry
      also have "... = ((L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)*XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using A5 A10 A16 sorry
      also have "... = ((L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = ((L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_65 A15 sorry
      also have "... = ((L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_65 A15 sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))))"
         sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 (L12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))"
        using cfunct_1_th_64 A15 sorry
      also have "... = (L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))*XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)) +XCMPLX-0K2 ((L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 L12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = ((L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = ((R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 (L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = ((R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = ((R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R16 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) *XCMPLX-0K3 R2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = ((R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R16 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R17 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = ((R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R19 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = (R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R19 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R18 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)))+XCMPLX-0K2 (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = (L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 (R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R20 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 ((R13 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R14 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))+XCMPLX-0K2 R20 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
         sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 (R15 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R20 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        using cfunct_1_th_64 A15 sorry
      also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        using cfunct_1_th_64 A15 sorry
      finally show "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
      using A12 sorry
    then have "diffCFDIFF-1K2(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A12 A13 cfdiff_1_def_7 sorry
    also have "... = L11 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 +XCMPLX-0K2 L12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using cfunct_1_th_64 sorry
    also have "... = f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 +XCMPLX-0K2 L12 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using cfunct_1_th_65 sorry
    also have "... = f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 L1 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7 +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using cfunct_1_th_65 sorry
    also have "... = f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x0)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 L2 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A1 A6 A8 cfdiff_1_def_7 sorry
    also have "... = f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x0)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x0))"
      using A2 A3 A5 cfdiff_1_def_7 sorry
    finally show "diffCFDIFF-1K2(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x0) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x0)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_27:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z =FUNCT-1R1 idPARTFUN1K6 Z implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 1rCOMPLEX1K7)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z =FUNCT-1R1 idPARTFUN1K6 Z implies f is-differentiable-onCFDIFF-1R2 Z & ( for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 1rCOMPLEX1K7)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and cfDef:"cf = COMPLEXNUMBERSK3 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
       sorry
    let ?R = "cf"
    obtain L where 
      [ty]:"L be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and LDef:"L = idPARTFUN1K6 (COMPLEXNUMBERSK3)"
       sorry
    have A1: "COMPLEXNUMBERSK3 c=TARSKIR1 COMPLEXNUMBERSK3"
       sorry
    have " for b be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> b =COMPLEX1R1 1rCOMPLEX1K7 *XCMPLX-0K3 b"
    proof(rule ballI)
      fix b assume [ty]: "b be ComplexXCMPLX-0M1"
      have "b inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      thus "L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> b =COMPLEX1R1 1rCOMPLEX1K7 *XCMPLX-0K3 b"
        using A1 partfun2_th_6 sorry
    qed "sorry"
    then have 
      [ty]:"L be C-LinearFuncCFDIFF-1M2"
      using cfdiff_1_def_4 sorry
    have A2: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R =HIDDENR1 COMPLEXNUMBERSK3"
      using funcop_1_th_13 sorry
    have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
    proof(rule ballI)
      fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
      have " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "n inTARSKIR2 NATNUMBERSK1 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R"
          using A2 ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_5 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using A3 funct_2_th_109 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6"
          using funcop_1_th_7 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      then have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be constantVALUED-0V15 & (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0cCOMPLEX1K6"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
        using cfcont_1_th_26 cfcont_1_th_27 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = ?R"
      using cfdiff_1_def_3 sorry
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A5: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z =FUNCT-1R1 idPARTFUN1K6 Z"
    have A6: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z).FUNCT-1K1 x =COMPLEX1R1 x"
        using A5 funct_1_th_18 sorry
      then have "f .FUNCT-1K1 x =COMPLEX1R1 x"
        using A7 funct_1_th_49 sorry
      thus "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 x"
        using A4 A7 partfun1_def_6 sorry
    qed "sorry"
    have A8: " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume A9: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
        A10: "N c=TARSKIR1 Z"
        using cfdiff_1_th_9 sorry
      have A11: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be ComplexXCMPLX-0M1"
          have A12: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          assume "x inHIDDENR3 N"
          then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
            using A6 A10 sorry
          also have "... = x -XCMPLX-0K6 x0"
            using A6 A9 sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
            using A1 partfun2_th_6 A12 sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 A12 sorry
          finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A4 A10 sorry
      thus "f is-differentiable-inCFDIFF-1R1 x0"
        using A11 sorry
    qed "sorry"
    thus A13: "f is-differentiable-onCFDIFF-1R2 Z"
      using A4 cfdiff_1_th_15 sorry
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A14: "x0 inHIDDENR3 Z"
    then obtain N1 where
      [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A15: "N1 c=TARSKIR1 Z"
      using cfdiff_1_th_9 sorry
    have A16: "f is-differentiable-inCFDIFF-1R1 x0"
      using A8 A14 sorry
    then have " ex N be NeighbourhoodCFDIFF-1M3-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
       sorry
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A17: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
       sorry
    obtain N2 where
      [ty]:"N2 be NeighbourhoodCFDIFF-1M3-of x0" and 
      A18: "N2 c=TARSKIR1 N1"and A19: "N2 c=TARSKIR1 N"
      using cfdiff_1_lm_1 sorry
    have A20: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A17 A19 sorry
    have A21: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ComplexXCMPLX-0M1"
        have A22: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        assume "x inHIDDENR3 N2"
        then have "x inHIDDENR3 N1"
          using A18 sorry
        then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
          using A6 A15 sorry
        also have "... = x -XCMPLX-0K6 x0"
          using A6 A14 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
          using A1 partfun2_th_6 A22 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 A22 sorry
        finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 diffCFDIFF-1K2(f,x0)"
      using A13 A14 cfdiff_1_def_12 sorry
    also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A16 A20 A21 cfdiff_1_def_7 sorry
    also have "... = 1rCOMPLEX1K7"
       sorry
    finally show "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 1rCOMPLEX1K7"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_28:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & f1 is-differentiable-onCFDIFF-1R2 Z) & f2 is-differentiable-onCFDIFF-1R2 Z implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x))"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 is-differentiable-onCFDIFF-1R2 Z & f2 is-differentiable-onCFDIFF-1R2 Z) implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      and A2: "f1 is-differentiable-onCFDIFF-1R2 Z & f2 is-differentiable-onCFDIFF-1R2 Z"
    have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0"
        using A2 cfdiff_1_th_15 sorry
      thus "f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
        using cfdiff_1_th_23 sorry
    qed "sorry"
    thus A3: "f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z"
      using A1 cfdiff_1_th_15 sorry
    have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(f1,x) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f1 is-differentiable-inCFDIFF-1R1 x & f2 is-differentiable-inCFDIFF-1R1 x"
        using A2 cfdiff_1_th_15 sorry
      have "((f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x)"
        using A3 A4 cfdiff_1_def_12 sorry
      also have "... = diffCFDIFF-1K2(f1,x) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x)"
        using A5 cfdiff_1_th_23 sorry
      finally show "((f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(f1,x) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x)"
         sorry
    qed "sorry"
    thus " for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) +XCMPLX-0K2 diffCFDIFF-1K2(f2,x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_29:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & f1 is-differentiable-onCFDIFF-1R2 Z) & f2 is-differentiable-onCFDIFF-1R2 Z implies f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x))"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 is-differentiable-onCFDIFF-1R2 Z & f2 is-differentiable-onCFDIFF-1R2 Z) implies f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      and A2: "f1 is-differentiable-onCFDIFF-1R2 Z & f2 is-differentiable-onCFDIFF-1R2 Z"
    have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0"
        using A2 cfdiff_1_th_15 sorry
      thus "f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
        using cfdiff_1_th_24 sorry
    qed "sorry"
    thus A3: "f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z"
      using A1 cfdiff_1_th_15 sorry
    have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(f1,x) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f1 is-differentiable-inCFDIFF-1R1 x & f2 is-differentiable-inCFDIFF-1R1 x"
        using A2 cfdiff_1_th_15 sorry
      have "((f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x)"
        using A3 A4 cfdiff_1_def_12 sorry
      also have "... = diffCFDIFF-1K2(f1,x) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x)"
        using A5 cfdiff_1_th_24 sorry
      finally show "((f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(f1,x) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x)"
         sorry
    qed "sorry"
    thus " for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 diffCFDIFF-1K2(f1,x) -XCMPLX-0K6 diffCFDIFF-1K2(f2,x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_30:
" for a be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) & f is-differentiable-onCFDIFF-1R2 Z implies a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x)))"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) & f is-differentiable-onCFDIFF-1R2 Z implies a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
      and A2: "f is-differentiable-onCFDIFF-1R2 Z"
    have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f is-differentiable-inCFDIFF-1R1 x0"
        using A2 cfdiff_1_th_15 sorry
      thus "a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-inCFDIFF-1R1 x0"
        using cfdiff_1_th_25 sorry
    qed "sorry"
    thus A3: "a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-differentiable-onCFDIFF-1R2 Z"
      using A1 cfdiff_1_th_15 sorry
    have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f is-differentiable-inCFDIFF-1R1 x"
        using A2 cfdiff_1_th_15 sorry
      have "((a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f,x)"
        using A3 A4 cfdiff_1_def_12 sorry
      also have "... = a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x))"
        using A5 cfdiff_1_th_25 sorry
      finally show "((a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x))"
         sorry
    qed "sorry"
    thus " for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((a (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 (diffCFDIFF-1K2(f,x)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_31:
" for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & f1 is-differentiable-onCFDIFF-1R2 Z) & f2 is-differentiable-onCFDIFF-1R2 Z implies f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x)))"
proof-
  have " for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (f1 is-differentiable-onCFDIFF-1R2 Z & f2 is-differentiable-onCFDIFF-1R2 Z) implies f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      and A2: "f1 is-differentiable-onCFDIFF-1R2 Z & f2 is-differentiable-onCFDIFF-1R2 Z"
    have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume "x0 inHIDDENR3 Z"
      then have "f1 is-differentiable-inCFDIFF-1R1 x0 & f2 is-differentiable-inCFDIFF-1R1 x0"
        using A2 cfdiff_1_th_15 sorry
      thus "f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-inCFDIFF-1R1 x0"
        using cfdiff_1_th_26 sorry
    qed "sorry"
    thus A3: "f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-differentiable-onCFDIFF-1R2 Z"
      using A1 cfdiff_1_th_15 sorry
    have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies ((f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      assume A4: "x inHIDDENR3 Z"
      then have A5: "f1 is-differentiable-inCFDIFF-1R1 x & f2 is-differentiable-inCFDIFF-1R1 x"
        using A2 cfdiff_1_th_15 sorry
      have "((f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 diffCFDIFF-1K2(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2,x)"
        using A3 A4 cfdiff_1_def_12 sorry
      also have "... = f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x))"
        using A5 cfdiff_1_th_26 sorry
      finally show "((f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x))"
         sorry
    qed "sorry"
    thus " for x be ComplexXCMPLX-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)`|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f1,x)) +XCMPLX-0K2 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x *XCMPLX-0K3 (diffCFDIFF-1K2(f2,x)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_32:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be constantFUNCT-1V5 implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 0cCOMPLEX1K6)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be constantFUNCT-1V5 implies f is-differentiable-onCFDIFF-1R2 Z & ( for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 0cCOMPLEX1K6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and cfDef:"cf = COMPLEXNUMBERSK3 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
       sorry
    let ?R = "cf"
    have A1: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R =HIDDENR1 COMPLEXNUMBERSK3"
      using funcop_1_th_13 sorry
    have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
    proof(rule ballI)
      fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
      have " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A2: "n inTARSKIR2 NATNUMBERSK1 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R"
          using A1 ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_5 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using A2 funct_2_th_109 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6"
          using funcop_1_th_7 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      then have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be constantVALUED-0V15 & (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0cCOMPLEX1K6"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
        using cfcont_1_th_26 cfcont_1_th_27 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = ?R"
      using cfdiff_1_def_3 sorry
    let ?L = "cf"
    have " for x be ComplexXCMPLX-0M1 holds ?L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 0cCOMPLEX1K6 *XCMPLX-0K3 x"
      using xcmplx_0_def_2 funcop_1_th_7 sorry
    then obtain L where 
      [ty]:"L be C-LinearFuncCFDIFF-1M2" and LDef:"L = ?L"
      using cfdiff_1_def_4 sorry
    assume A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A4: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be constantFUNCT-1V5"
    obtain a1 where
      [ty]:"a1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
      A5: " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds x inTARSKIR2 Z /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a1"
      using A4 partfun2_th_35 sorry
    have A6: " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume A7: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
        A8: "N c=TARSKIR1 Z"
        using cfdiff_1_th_9 sorry
      have A9: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A3 A8 sorry
      have A10: "x0 inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A3 A7 xboole_0_def_4 sorry
      have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be ComplexXCMPLX-0M1"
          have A11: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          assume "x inHIDDENR3 N"
          then have "x inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
            using A8 A9 xboole_0_def_4 sorry
          then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 a1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
            using A5 sorry
          also have "... = a1 -XCMPLX-0K6 a1"
            using A5 A10 sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
            using funcop_1_th_7 A11 sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 A11 sorry
          finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f is-differentiable-inCFDIFF-1R1 x0"
        using A9 sorry
    qed "sorry"
    thus A12: "f is-differentiable-onCFDIFF-1R2 Z"
      using A3 cfdiff_1_th_15 sorry
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A13: "x0 inHIDDENR3 Z"
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A14: "N c=TARSKIR1 Z"
      using cfdiff_1_th_9 sorry
    have A15: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A3 A14 sorry
    have A16: "x0 inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A3 A13 xboole_0_def_4 sorry
    have A17: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ComplexXCMPLX-0M1"
        have A18: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        assume "x inHIDDENR3 N"
        then have "x inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A14 A15 xboole_0_def_4 sorry
        then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 a1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
          using A5 sorry
        also have "... = a1 -XCMPLX-0K6 a1"
          using A5 A16 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
          using funcop_1_th_7 A18 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 A18 sorry
        finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A19: "f is-differentiable-inCFDIFF-1R1 x0"
      using A6 A13 sorry
    have "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 diffCFDIFF-1K2(f,x0)"
      using A12 A13 cfdiff_1_def_12 sorry
    also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A19 A15 A17 cfdiff_1_def_7 sorry
    also have "... = 0cCOMPLEX1K6"
      using funcop_1_th_7 sorry
    finally show "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 0cCOMPLEX1K6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_33:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f is-differentiable-onCFDIFF-1R2 Z & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f is-differentiable-onCFDIFF-1R2 Z & ( for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies (f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 a)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    obtain cf where 
      [ty]:"cf be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and cfDef:"cf = COMPLEXNUMBERSK3 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
       sorry
    let ?R = "cf"
    have A1: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R =HIDDENR1 COMPLEXNUMBERSK3"
      using funcop_1_th_13 sorry
    have " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
    proof(rule ballI)
      fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
      have " for n be NatNAT-1M1 holds (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A2: "n inTARSKIR2 NATNUMBERSK1 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?R"
          using A1 ordinal1_def_12 sorry
        have "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_5 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 cf /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using A2 funct_2_th_109 sorry
        also have "... = h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6"
          using funcop_1_th_7 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "(h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      then have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be constantVALUED-0V15 & (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ?R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0cCOMPLEX1K6"
        using valued_0_def_18 sorry
      thus "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> cf /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h) =COMPLEX1R1 0cCOMPLEX1K6"
        using cfcont_1_th_26 cfcont_1_th_27 sorry
    qed "sorry"
    then obtain R where 
      [ty]:"R be C-RestFuncCFDIFF-1M1" and RDef:"R = ?R"
      using cfdiff_1_def_3 sorry
    assume A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A4: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 Z implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    let ?G = "\<lambda>Lamb1. InSUBSET-1K10(a *XCMPLX-0K3 Lamb1,COMPLEXNUMBERSK3)"
    obtain L where
      [ty]:"L be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)" and 
      A5: " for x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds L .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> x =COMPLEX1R1 ?G(x)"
      using funct_2_sch_4 sorry
    have " for z be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a *XCMPLX-0K3 z"
    proof(rule ballI)
      fix z assume [ty]: "z be ComplexXCMPLX-0M1"
      have 
        [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      have "L .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 ?G(z)"
        using A5 sorry
      thus "L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a *XCMPLX-0K3 z"
         sorry
    qed "sorry"
    then have 
      [ty]:"L be C-LinearFuncCFDIFF-1M2"
      using cfdiff_1_def_4 sorry
    have A6: " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 Z implies f is-differentiable-inCFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume A7: "x0 inHIDDENR3 Z"
      then obtain N where
        [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
        A8: "N c=TARSKIR1 Z"
        using cfdiff_1_th_9 sorry
      have A9: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof-
        have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be ComplexXCMPLX-0M1"
          have A10: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          assume "x inHIDDENR3 N"
          then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)-XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
            using A4 A8 sorry
          also have "... = (a *XCMPLX-0K3 x +XCMPLX-0K2 b)-XCMPLX-0K6 (a *XCMPLX-0K3 x0 +XCMPLX-0K2 b)"
            using A4 A7 sorry
          also have "... = InSUBSET-1K10(a *XCMPLX-0K3 (x -XCMPLX-0K6 x0),COMPLEXNUMBERSK3) +XCMPLX-0K2 0cCOMPLEX1K6"
             sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
            using A5 A10 sorry
          also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            using funcop_1_th_7 A10 sorry
          finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A3 A8 sorry
      thus "f is-differentiable-inCFDIFF-1R1 x0"
        using A9 sorry
    qed "sorry"
    thus A11: "f is-differentiable-onCFDIFF-1R2 Z"
      using A3 cfdiff_1_th_15 sorry
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A12: "x0 inHIDDENR3 Z"
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A13: "N c=TARSKIR1 Z"
      using cfdiff_1_th_9 sorry
    have A14: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
    proof-
      have " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ComplexXCMPLX-0M1"
        have A15: "x -XCMPLX-0K6 x0 inTARSKIR2 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        assume "x inHIDDENR3 N"
        then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)-XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
          using A4 A13 sorry
        also have "... = (a *XCMPLX-0K3 x +XCMPLX-0K2 b)-XCMPLX-0K6 (a *XCMPLX-0K3 x0 +XCMPLX-0K2 b)"
          using A4 A12 sorry
        also have "... = InSUBSET-1K10(a *XCMPLX-0K3 (x -XCMPLX-0K6 x0),COMPLEXNUMBERSK3) +XCMPLX-0K2 0cCOMPLEX1K6"
           sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 0cCOMPLEX1K6"
          using A5 A15 sorry
        also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
          using funcop_1_th_7 A15 sorry
        finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A16: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A3 A13 sorry
    have A17: "f is-differentiable-inCFDIFF-1R1 x0"
      using A6 A12 sorry
    have "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 diffCFDIFF-1K2(f,x0)"
      using A11 A12 cfdiff_1_def_12 sorry
    also have "... = L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
      using A17 A16 A14 cfdiff_1_def_7 sorry
    also have "... = InSUBSET-1K10(a *XCMPLX-0K3 1rCOMPLEX1K7,COMPLEXNUMBERSK3)"
      using A5 sorry
    also have "... = a"
       sorry
    finally show "(f `|CFDIFF-1K3 Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_34:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f is-differentiable-inCFDIFF-1R1 x0 implies f is-continuous-inCFCONT-1R1 x0"
proof-
  have " for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for x0 be ComplexXCMPLX-0M1 holds f is-differentiable-inCFDIFF-1R1 x0 implies f is-continuous-inCFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    assume A1: "f is-differentiable-inCFDIFF-1R1 x0"
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
       sorry
    have A3: "x0 inHIDDENR3 N"
      using cfdiff_1_th_7 sorry
    have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & (s1 be convergentCOMSEQ-2V3 & (limCOMSEQ-2K3 s1 =COMPLEX1R1 x0 & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0))) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A4: "0NUMBERSK6 <XXREAL-0R3 g"and A5: "{y where y be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 y -XCMPLX-0K6 x0 .| <XXREAL-0R3 g } c=TARSKIR1 N"
        using cfdiff_1_def_5 sorry
      obtain xx0 where 
        [ty]:"xx0 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and xx0Def:"xx0 = x0"
        using xcmplx_0_def_2 sorry
      obtain s2 where 
        [ty]:"s2 be Complex-SequenceCOMSEQ-1M1" and s2Def:"s2 = NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> xx0"
         sorry
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A6: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        and A7: "s1 be convergentCOMSEQ-2V3"
        and A8: "limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
        and A9: " for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0"
      obtain l where
        [ty]:"l be NatNAT-1M1" and 
        A10: " for m be NatNAT-1M1 holds l <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
        using A7 A8 A4 comseq_2_def_6 sorry
      have A11: "limCOMSEQ-2K3 s2 =HIDDENR1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
        using cfcont_1_th_28 sorry
      also have "... = x0"
        using funcop_1_th_7 sorry
      finally have "limCOMSEQ-2K3 s2 =HIDDENR1 x0"
         sorry
      let ?G = "\<lambda>Lamb1. InSUBSET-1K10(s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 -XCMPLX-0K6 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1,COMPLEXNUMBERSK3)"
      obtain s3 where
        [ty]:"s3 be Complex-SequenceCOMSEQ-1M1" and 
        A12: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ?G(n)"
        using funct_2_sch_4 sorry
      have A13: " for n be NatNAT-1M1 holds s3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "s3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ?G(n)"
          using A12 sorry
        thus "s3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
           sorry
      qed "sorry"
      have A14: "s3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
        using A13 cfcont_1_th_1 sorry
      have A15: "s2 be convergentCOMSEQ-2V3"
        using cfcont_1_th_26 sorry
      then have A16: "s3 be convergentCOMSEQ-2V3"
        using A7 A14 sorry
      have "limCOMSEQ-2K3 s3 =HIDDENR1 limCOMSEQ-2K3 (s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)"
        using A13 cfcont_1_th_1 sorry
      also have "... = x0 -XCMPLX-0K6 x0"
        using A7 A8 A15 A11 comseq_2_th_26 sorry
      also have "... = 0cCOMPLEX1K6"
         sorry
      finally have "limCOMSEQ-2K3 s3 =HIDDENR1 0cCOMPLEX1K6"
         sorry
      then have A17: "limCOMSEQ-2K3 (s3 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l) =COMPLEX1R1 0cCOMPLEX1K6"
        using A16 cfcont_1_th_21 sorry
      obtain c where 
        [ty]:"c be constantVALUED-0V15\<bar>Complex-SequenceCOMSEQ-1M1" and cDef:"c = s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
         sorry
      have A18: "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies  False "
      proof(rule impI)
        assume Given: " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A19: "s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
           sorry
        have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
          using A13 A19 sorry
        thus " False "
          using A9 funcop_1_th_7 sorry
      qed
      have A20: "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (s3 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies  False "
      proof(rule impI)
        assume Given: " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st (s3 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A21: "(s3 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
           sorry
        have A22: "n +XCMPLX-0K2 l inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "s3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l) =COMPLEX1R1 0cCOMPLEX1K6"
          using A21 nat_1_def_3 sorry
        thus " False "
          using A18 A22 sorry
      qed
      then have A23: "s3 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l be non-zeroORDINAL1V9"
        using comseq_1_th_4 sorry
      have "s3 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l be convergentCOMSEQ-2V3"
        using A16 cfcont_1_th_21 sorry
      then obtain h where 
        [ty]:"h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1" and hDef:"h = s3 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
        using A17 A23 cfdiff_1_def_1 sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_1 sorry
        also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)+XCMPLX-0K2 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using cfcont_1_th_1 sorry
        also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
           sorry
        finally show "((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
           sorry
      qed "sorry"
      then have A24: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)"
         sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (s1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A25: "n +XCMPLX-0K2 l inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "(h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (((s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using A14 cfdiff_1_th_18 sorry
        also have "... = ((s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l)"
          using nat_1_def_3 sorry
        also have "... = (s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l) +XCMPLX-0K2 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l)"
          using valued_1_th_1 A25 sorry
        also have "... = (s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l) -XCMPLX-0K6 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l))+XCMPLX-0K2 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l)"
          using cfcont_1_th_1 sorry
        also have "... = (s1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using nat_1_def_3 sorry
        finally show "(h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (s1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
           sorry
      qed "sorry"
      then have A26: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l)"
        using A24 funct_2_th_63 sorry
      also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
        using A6 valued_0_th_27 sorry
      finally have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l"
         sorry
      have A27: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 {TARSKIK1 x0}"
      proof-
        have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c c=TARSKIR1 {TARSKIK1 x0} & {TARSKIK1 x0} c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
        proof(rule conjMI)
          show "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c c=TARSKIR1 {TARSKIK1 x0}"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c implies y inHIDDENR3 {TARSKIK1 x0}"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
              then obtain n where
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A28: "y =HIDDENR1 (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
                using funct_2_th_113 sorry
              have A29: "n +XCMPLX-0K2 l inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "y =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l)"
                using A28 nat_1_def_3 sorry
              then have "y =HIDDENR1 x0"
                using funcop_1_th_7 A29 sorry
              thus "y inHIDDENR3 {TARSKIK1 x0}"
                using tarski_def_1 sorry
            qed "sorry"
            thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c c=TARSKIR1 {TARSKIK1 x0}"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x0} implies y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 {TARSKIK1 x0}"
            then have A30: "y =HIDDENR1 x0"
              using tarski_def_1 sorry
            have A31: "0NUMBERSK6 +XCMPLX-0K2 l inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6 +XCMPLX-0K2 l)"
              using nat_1_def_3 sorry
            also have "... = y"
              using A30 funcop_1_th_7 A31 sorry
            finally have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 y"
               sorry
            thus "y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
              using funct_2_th_4 sorry
          qed "sorry"
          thus "{TARSKIK1 x0} c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c"
            using tarski_def_3 sorry
        qed
        thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> c =HIDDENR1 {TARSKIK1 x0}"
          using xboole_0_def_10 sorry
      qed
      have A32: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A33: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"])
          show " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
          proof-
            have " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
            proof(rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume "n <=XXREAL-0R1 m"
              have A34: "m +XCMPLX-0K2 l inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A35: "m inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "{TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
                using A2 A3 zfmisc_1_th_31 sorry
              then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                using A27 funct_2_th_109 A35 sorry
              also have "... =  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (m +XCMPLX-0K2 l)) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                using nat_1_def_3 sorry
              also have "... =  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                using funcop_1_th_7 A34 sorry
              also have "... = 0NUMBERSK6"
                using absvalue_th_2 sorry
              finally have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1 0NUMBERSK6"
                 sorry
              thus " not  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                using A33 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
        qed "sorry"
      qed "sorry"
      then have A36: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c be convergentCOMSEQ-2V3"
         sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A37: "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using A20 sorry
        have "(h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_5 sorry
        also have "... = h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
          using valued_1_th_5 sorry
        also have "... = h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
          using valued_1_th_10 sorry
        also have "... = (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
           sorry
        also have "... = \<one>\<^sub>M *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using A37 xcmplx_0_def_7 sorry
        also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
           sorry
        finally show "(h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
           sorry
      qed "sorry"
      then have A38: "h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c"
         sorry
      have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) c=TARSKIR1 N"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) implies y inHIDDENR3 N"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A39: "y inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)"
          then obtain n where
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A40: "y =HIDDENR1 (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using funct_2_th_113 sorry
          have A41: "n +XCMPLX-0K2 l inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          obtain y1 where 
            [ty]:"y1 be ComplexXCMPLX-0M1" and y1Def:"y1 = y"
            using A39 sorry
          have "(h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (((s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using A14 cfdiff_1_th_18 sorry
          also have "... = ((s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l)"
            using nat_1_def_3 sorry
          also have "... = (s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l) +XCMPLX-0K2 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l)"
            using valued_1_th_1 A41 sorry
          also have "... = (s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l) -XCMPLX-0K6 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l))+XCMPLX-0K2 s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 l)"
            using cfcont_1_th_1 sorry
          also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (l +NAT-1K1 n)"
             sorry
          finally have "(h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (l +NAT-1K1 n)"
             sorry
          then have " |.COMPLEX1K10 (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 x0 .| <XXREAL-0R3 g"
            using A10 nat_1_th_12 sorry
          then have "y1 inHIDDENR3 {z where z be ComplexXCMPLX-0M1 :  |.COMPLEX1K10 z -XCMPLX-0K6 x0 .| <XXREAL-0R3 g }"
            using A40 sorry
          thus "y inHIDDENR3 N"
            using A5 sorry
        qed "sorry"
        thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) c=TARSKIR1 N"
          using tarski_def_3 sorry
      qed
      then have A42: "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) be convergentCOMSEQ-2V3"
        using A1 A2 A27 cfdiff_1_th_22 sorry
      then have A43: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c be convergentCOMSEQ-2V3"
        using A38 sorry
      then have A44: "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c be convergentCOMSEQ-2V3"
        using A36 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A26 cfcont_1_th_22 sorry
      have "limCOMSEQ-2K3 (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c))) =HIDDENR1 0cCOMPLEX1K6 *XCMPLX-0K3 (limCOMSEQ-2K3 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)))"
        using A17 A42 comseq_2_th_30 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "limCOMSEQ-2K3 (h (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c))) =HIDDENR1 0NUMBERSK6"
         sorry
      then have "limCOMSEQ-2K3 ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) =HIDDENR1 0cCOMPLEX1K6 +XCMPLX-0K2 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c"
        using A38 A43 A36 comseq_2_th_14 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A32 A36 comseq_2_def_6 sorry
      finally have "limCOMSEQ-2K3 ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (h +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
         sorry
      thus "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A44 A26 cfcont_1_th_23 sorry
    qed "sorry"
    thus "f is-continuous-inCFCONT-1R1 x0"
      using A2 A3 cfcont_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_35:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 X implies f is-continuous-onCFCONT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-onCFDIFF-1R2 X implies f is-continuous-onCFCONT-1R2 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f is-differentiable-onCFDIFF-1R2 X"
    have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x)"
    proof(rule conjMI,rule ballI,rule impI)
      show A2: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A1 sorry
      fix x assume [ty]: "x be ComplexXCMPLX-0M1"
      assume "x inHIDDENR3 X"
      then have A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
        using A2 relat_1_th_57 sorry
      have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X be differentiableCFDIFF-1V4"
        using A1 sorry
      then have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-differentiable-inCFDIFF-1R1 x"
        using A3 sorry
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x"
        using cfdiff_1_th_34 sorry
    qed "sorry"
    thus "f is-continuous-onCFCONT-1R2 X"
      using cfcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfdiff_1_th_36:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds f is-differentiable-onCFDIFF-1R2 X & Z c=TARSKIR1 X implies f is-differentiable-onCFDIFF-1R2 Z"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds f is-differentiable-onCFDIFF-1R2 X & Z c=TARSKIR1 X implies f is-differentiable-onCFDIFF-1R2 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Z assume [ty]: "Z be openCFDIFF-1V6\<bar>SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    assume A1: "f is-differentiable-onCFDIFF-1R2 X"
      and A2: "Z c=TARSKIR1 X"
    have A3: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X be differentiableCFDIFF-1V4"
      using A1 sorry
    have Cut2347: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A1 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be differentiableCFDIFF-1V4"
    proof(rule conjMI)
      show "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A2 Cut2347 sorry
      have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z) implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z is-differentiable-inCFDIFF-1R1 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
        assume A4: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)"
        then have A5: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using relat_1_th_57 sorry
        have A6: "x0 inHIDDENR3 Z"
          using A4 relat_1_th_57 sorry
        then obtain N1 where
          [ty]:"N1 be NeighbourhoodCFDIFF-1M3-of x0" and 
          A7: "N1 c=TARSKIR1 Z"
          using cfdiff_1_th_9 sorry
        have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
          using A2 A5 A6 relat_1_th_57 sorry
        then have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-differentiable-inCFDIFF-1R1 x0"
          using A3 sorry
        then obtain N where
          [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
          A8: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"and A9: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
           sorry
        obtain N2 where
          [ty]:"N2 be NeighbourhoodCFDIFF-1M3-of x0" and 
          A10: "N2 c=TARSKIR1 N"and A11: "N2 c=TARSKIR1 N1"
          using cfdiff_1_lm_1 sorry
        have A12: "N2 c=TARSKIR1 Z"
          using A7 A11 sorry
        have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
          using relat_1_th_61 sorry
        then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using xboole_1_th_17 sorry
        then have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A8 sorry
        then have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A10 sorry
        then have Cut2372: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Z"
          using A12 xboole_1_th_19 sorry
        have "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z) & ( ex tVar29 be C-LinearFuncCFDIFF-1M2 st  ex tVar30 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 tVar29 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar30 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0))"
        proof(rule conjMI)
          show A13: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)"
            using relat_1_th_61 Cut2372 sorry
          obtain L R where
            [ty]:"L be C-LinearFuncCFDIFF-1M2" "R be C-RestFuncCFDIFF-1M1" and 
            A14: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            using A9 sorry
          show " ex tVar29 be C-LinearFuncCFDIFF-1M2 st  ex tVar30 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 tVar29 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar30 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
          proof(rule bexI[of _ "L"])
            show " ex tVar30 be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N2 implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 tVar30 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
            proof(rule bexI[of _ "R"],rule ballI,rule impI)
              fix x assume [ty]: "x be ComplexXCMPLX-0M1"
              assume A15: "x inHIDDENR3 N2"
              then have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A10 A14 sorry
              then have A16: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A2 A5 A6 partfun2_th_17 sorry
              have "x inHIDDENR3 N"
                using A10 A15 sorry
              then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A8 A16 partfun2_th_15 sorry
              then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A5 A6 partfun2_th_17 sorry
              thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
                using A13 A15 partfun2_th_15 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z is-differentiable-inCFDIFF-1R1 x0"
          using bexI[of _ "N2"] cfdiff_1_def_6 sorry
      qed "sorry"
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Z be differentiableCFDIFF-1V4"
        using cfdiff_1_def_8 sorry
    qed
    thus "f is-differentiable-onCFDIFF-1R2 Z"
      using cfdiff_1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem cfdiff_1_th_38:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-inCFDIFF-1R1 x0 implies ( ex R be C-RestFuncCFDIFF-1M1 st R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0cCOMPLEX1K6 & R is-continuous-inCFCONT-1R1 0cCOMPLEX1K6)"
proof-
  have " for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-differentiable-inCFDIFF-1R1 x0 implies ( ex tVar31 be C-RestFuncCFDIFF-1M1 st tVar31 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0cCOMPLEX1K6 & tVar31 is-continuous-inCFCONT-1R1 0cCOMPLEX1K6)"
  proof(rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume "f is-differentiable-inCFDIFF-1R1 x0"
    then obtain N where
      [ty]:"N be NeighbourhoodCFDIFF-1M3-of x0" and 
      "N c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"and A1: " ex L be C-LinearFuncCFDIFF-1M2 st  ex R be C-RestFuncCFDIFF-1M1 st  for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
       sorry
    obtain L R where
      [ty]:"L be C-LinearFuncCFDIFF-1M2" "R be C-RestFuncCFDIFF-1M1" and 
      A2: " for x be ComplexXCMPLX-0M1 holds x inHIDDENR3 N implies f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x -XCMPLX-0K6 x0)"
      using A1 sorry
    show " ex tVar31 be C-RestFuncCFDIFF-1M1 st tVar31 /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0cCOMPLEX1K6 & tVar31 is-continuous-inCFCONT-1R1 0cCOMPLEX1K6"
    proof(rule bexI[of _ "R"],rule conjMI)
      obtain a where
        [ty]:"a be ComplexXCMPLX-0M1" and 
        A3: " for z be ComplexXCMPLX-0M1 holds L /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z =COMPLEX1R1 a *XCMPLX-0K3 z"
        using cfdiff_1_def_4 sorry
      have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 L /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x0 -XCMPLX-0K6 x0) +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (x0 -XCMPLX-0K6 x0)"
        using A2 cfdiff_1_th_7 sorry
      then have A4: "0cCOMPLEX1K6 =COMPLEX1R1 a *XCMPLX-0K3 0cCOMPLEX1K6 +XCMPLX-0K2 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
        using A3 sorry
      thus "R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 =COMPLEX1R1 0cCOMPLEX1K6"
         sorry
      have A5: " for h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =COMPLEX1R1 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
      proof(rule ballI,rule conjMI)
        fix h assume [ty]: "h be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
        have "h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be boundedCOMSEQ-2V2"
          using cfdiff_1_def_3 sorry
        then obtain M where
          [ty]:"M be RealXREAL-0M1" and 
          "M >XXREAL-0R4 0NUMBERSK6"and A6: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <XXREAL-0R3 M"
          using comseq_2_th_8 sorry
        have "limCOMSEQ-2K3 h =COMPLEX1R1 0NUMBERSK6"
          using cfdiff_1_def_1 sorry
        then have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|) =COMPLEX1R1  |.COMPLEX1K10 0NUMBERSK6 .|"
          using seq_2_th_27 sorry
        then have A7: "limSEQ-2K1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|)) =HIDDENR1 M *XCMPLX-0K3 ( |.COMPLEX1K10 0NUMBERSK6 .|)"
          using seq_2_th_8 sorry
        also have "... = M *XCMPLX-0K3 (0NUMBERSK6)"
          using absvalue_th_2 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally have "limSEQ-2K1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|)) =HIDDENR1 0NUMBERSK6"
           sorry
        have A8: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p)"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume "0NUMBERSK6 <XXREAL-0R3 p"
          then obtain m where
            [ty]:"m be NatNAT-1M1" and 
            A9: " for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
            using A7 seq_2_def_7 sorry
          show " ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p"
          proof(rule bexI[of _ "m"])
            have " for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p"
            proof(rule ballI,rule impI)
              fix n assume [ty]: "n be NatNAT-1M1"
              assume "m <=XXREAL-0R1 n"
              then have A10: " |.COMPLEX1K10 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
                using A9 sorry
              have " |.COMPLEX1K10 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =HIDDENR1  |.COMPLEX1K10 h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
                using valued_1_th_5 sorry
              also have "... =  |.COMPLEX1K10 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
                using valued_1_th_10 sorry
              finally have " |.COMPLEX1K10 (h \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =HIDDENR1  |.COMPLEX1K10 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
                 sorry
              then have A11: " |.COMPLEX1K10 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1 M"
                using A6 sorry
              have A12: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have " |.COMPLEX1K10 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| >=XXREAL-0R2 0NUMBERSK6"
                using complex1_th_46 sorry
              then have "( |.COMPLEX1K10 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|) <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
                using A11 xreal_1_th_64 sorry
              then have " |.COMPLEX1K10 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .| <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
                using complex1_th_65 sorry
              then have "h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 &  |.COMPLEX1K10 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
                using comseq_1_th_4 A12 sorry
              then have " |.COMPLEX1K10 1rCOMPLEX1K7 *XCMPLX-0K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1 M *XCMPLX-0K3 ( |.COMPLEX1K10 h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
                using xcmplx_0_def_7 sorry
              then have " |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 M *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
                using valued_1_th_18 sorry
              then have A13: " |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
                using seq_1_th_9 sorry
              have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
                using complex1_th_46 sorry
              then have "0NUMBERSK6 <=XXREAL-0R1 (M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
                using A13 sorry
              then have "(M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 p"
                using A10 absvalue_def_1 sorry
              thus " |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p"
                using A13 xxreal_0_th_2 sorry
            qed "sorry"
            thus " for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 0cCOMPLEX1K6 .| <XXREAL-0R3 p"
               sorry
          qed "sorry"
        qed "sorry"
        thus "R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h be convergentCOMSEQ-2V3"
           sorry
        thus "limCOMSEQ-2K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h =COMPLEX1R1 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
          using A4 A8 comseq_2_def_6 sorry
      qed "sorry"
      have A14: " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> R & ((s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0NUMBERSK6)) implies R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =COMPLEX1R1 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
        assume "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> R"
          and A15: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 0NUMBERSK6"
          and A16: " for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using A16 sorry
        then have "s1 be non-zeroORDINAL1V9"
          using comseq_1_th_4 sorry
        then have "s1 be 0NUMBERSK6 -convergentCFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1"
          using A15 cfdiff_1_def_1 sorry
        thus "R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =COMPLEX1R1 R /.FUNCT-2K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
          using A5 sorry
      qed "sorry"
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> R =HIDDENR1 COMPLEXNUMBERSK3"
        using partfun1_def_2 sorry
      thus "R is-continuous-inCFCONT-1R1 0cCOMPLEX1K6"
        using A14 cfcont_1_th_31 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
