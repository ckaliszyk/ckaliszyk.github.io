theory recdef_1
  imports ordinal2 finseq_1 binop_1 domain_1 real_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "NatNAT-1M1"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Z, x, y, z, y1, y2 for "setHIDDENM2"
reserve p, q for "FinSequenceFINSEQ-1M1"
mlemma recdef_1_lm_1:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 n be ElementSUBSET-1M1-of D"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 n be ElementSUBSET-1M1-of D"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume "\<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p"
    then have "n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_th_1 sorry
    then have "n inTARSKIR2 domFINSEQ-1K5 p"
      using finseq_1_def_3 sorry
    then have A1: "p .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 p"
      using funct_1_def_3 sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 D"
      using finseq_1_def_4 sorry
    thus "p .FUNCT-1K1 n be ElementSUBSET-1M1-of D"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RECDEF_1K1(" _ .RECDEF-1K1  _ " [200,200]200) where
  "p .RECDEF-1K1 n \<equiv> p .FUNCT-1K1 n"

mtheorem recdef_1_add_1:
  mlet "p be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1", "n be setHIDDENM2"
"cluster p .FUNCT-1K1 n as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "p .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

theorem recdef_1_sch_1:
  fixes Af0 Pp3 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
   A1: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex y be setHIDDENM2 st Pp3(n,x,y)"
  shows " ex f be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " ex tVar19 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar19 =XBOOLE-0R4 NATNUMBERSK1 & (tVar19 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & ( for n be NatNAT-1M1 holds Pp3(n,tVar19 .FUNCT-1K1 n,tVar19 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 Lamb3 & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 Lamb2) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 Lamb2) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
      have A2: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex y be setHIDDENM2 st ?Q(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex tVar7 be setHIDDENM2 st  ex O2c be OrdinalORDINAL1M3 st (O2c =XBOOLE-0R4 tVar7 & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2c & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2c c=ORDINAL1R1 O)"
        proof(rule ballI,rule ballI)
          let ?Y = "\<lambda>Lamb1. \<lambda>Lamb2.  for m be NatNAT-1M1 holds  ex y be setHIDDENM2 st (Lamb2 be OrdinalORDINAL1M3 & y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K6 Lamb2)) & Pp3(m,Lamb1,y)"
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be setHIDDENM2"
          let ?X = "\<lambda>Lamb1.  for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 Lamb1 & Pp3(n,X,Y))"
          have A3: " for x9 be objectHIDDENM1 holds x9 inHIDDENR3 boolZFMISC-1K1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex o be objectHIDDENM1 st ?Y(x9,o))"
          proof-
            have " for x9 be objectHIDDENM1 holds x9 inHIDDENR3 boolZFMISC-1K1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex o be setHIDDENM2 st  for m be NatNAT-1M1 holds  ex y be setHIDDENM2 st (o be OrdinalORDINAL1M3 & y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o)) & Pp3(m,x9,y))"
            proof(rule ballI,rule impI)
              fix x9 assume [ty]: "x9 be objectHIDDENM1"
              assume "x9 inHIDDENR3 boolZFMISC-1K1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x)"
              let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex y be setHIDDENM2 st (Lamb2 be OrdinalORDINAL1M3 & y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K6 Lamb2)) & Pp3(Lamb1,x9,y)"
              have A4: " for e be objectHIDDENM1 holds e inHIDDENR3 NATNUMBERSK1 implies ( ex u be objectHIDDENM1 st ?X(e,u))"
              proof-
                have " for i be objectHIDDENM1 holds i inHIDDENR3 NATNUMBERSK1 implies ( ex o be objectHIDDENM1 st  ex y be setHIDDENM2 st (o be OrdinalORDINAL1M3 & y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K6 o)) & Pp3(i,x9,y))"
                proof(rule ballI,rule impI)
                  fix i assume [ty]: "i be objectHIDDENM1"
                  assume "i inHIDDENR3 NATNUMBERSK1"
                  then obtain i9 where 
                    [ty]:"i9 be NatNAT-1M1" and i9Def:"i9 = i"
                     sorry
                  show " ex o be objectHIDDENM1 st  ex y be setHIDDENM2 st (o be OrdinalORDINAL1M3 & y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K6 o)) & Pp3(i,x9,y)"
                  proof-
                    have " ex o be setHIDDENM2 st  ex tVar2 be setHIDDENM2 st o be OrdinalORDINAL1M3 & (tVar2 c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o) & Pp3(i,x9,tVar2))"
                    proof-
                      have "x9 be setHIDDENM2"
                        using tarski_th_1 sorry
                      then obtain y where
                        [ty]:"y be setHIDDENM2" and 
                        A5: "Pp3(i9,x9,y)"
                        using A1 sorry
                      obtain o where 
                        [ty]:"o be setHIDDENM2" and oDef:"o = the-rank-ofCLASSES1K7 y"
                         sorry
                      show " ex o be setHIDDENM2 st  ex tVar2 be setHIDDENM2 st o be OrdinalORDINAL1M3 & (tVar2 c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o) & Pp3(i,x9,tVar2))"
                      proof(rule bexI[of _ "o"])
                        show " ex tVar2 be setHIDDENM2 st o be OrdinalORDINAL1M3 & (tVar2 c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o) & Pp3(i,x9,tVar2))"
                        proof(rule bexI[of _ "y"],rule conjMI,rule conjMI)
                          show "o be OrdinalORDINAL1M3"
                             sorry
                          have "the-rank-ofCLASSES1K7 (the-rank-ofCLASSES1K7 y) =XBOOLE-0R4 the-rank-ofCLASSES1K7 y"
                            using classes1_th_73 sorry
                          thus "y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o)"
                            using classes1_th_65 sorry
                          show "Pp3(i,x9,y)"
                            using A5 sorry
                        qed "sorry"
                      qed "sorry"
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              obtain h where
                [ty]:"h be FunctionFUNCT-1M1" and 
                A6: "domRELAT-1K1 h =XBOOLE-0R4 NATNUMBERSK1"and A7: " for i be objectHIDDENM1 holds i inHIDDENR3 NATNUMBERSK1 implies ?X(i,h .FUNCT-1K1 i)"
                using classes1_sch_1 A4 sorry
              obtain o where 
                [ty]:"o be setHIDDENM2" and oDef:"o = supORDINAL2K3 (rngFUNCT-1K2 h)"
                 sorry
              show " ex o be setHIDDENM2 st  for m be NatNAT-1M1 holds  ex y be setHIDDENM2 st (o be OrdinalORDINAL1M3 & y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o)) & Pp3(m,x9,y)"
              proof(rule bexI[of _ "o"])
                show " for m be NatNAT-1M1 holds  ex y be setHIDDENM2 st (o be OrdinalORDINAL1M3 & y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o)) & Pp3(m,x9,y)"
                proof-
                  have " for m be NatNAT-1M1 holds  ex tVar4 be setHIDDENM2 st o be OrdinalORDINAL1M3 & (tVar4 c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o) & Pp3(m,x9,tVar4))"
                  proof(rule ballI)
                    fix m assume [ty]: "m be NatNAT-1M1"
                    have A8: "m inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    then obtain y where
                      [ty]:"y be setHIDDENM2" and 
                      A9: "h .FUNCT-1K1 m be OrdinalORDINAL1M3"and A10: "y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (h .FUNCT-1K1 m))"and A11: "Pp3(m,x9,y)"
                      using A7 sorry
                    obtain O where 
                      [ty]:"O be OrdinalORDINAL1M3" and ODef:"O = h .FUNCT-1K1 m"
                      using A9 sorry
                    have "h .FUNCT-1K1 m inTARSKIR2 rngFUNCT-1K2 h"
                      using A6 A8 funct_1_def_3 sorry
                    then have "h .FUNCT-1K1 m inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 h)"
                      using A9 ordinal2_th_19 sorry
                    then have "h .FUNCT-1K1 m c=TARSKIR1 o"
                      using ordinal1_def_2 sorry
                    then have A12: "RankCLASSES1K4 O c=TARSKIR1 RankCLASSES1K4 o"
                      using classes1_th_37 sorry
                    show " ex tVar4 be setHIDDENM2 st o be OrdinalORDINAL1M3 & (tVar4 c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o) & Pp3(m,x9,tVar4))"
                    proof(rule bexI[of _ "y"],rule conjMI,rule conjMI)
                      show "o be OrdinalORDINAL1M3"
                         sorry
                      have "y c=TARSKIR1 RankCLASSES1K4 O"
                        using A10 classes1_th_73 sorry
                      then have "y c=TARSKIR1 RankCLASSES1K4 o"
                        using A12 sorry
                      thus "y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 o)"
                        using classes1_th_73 sorry
                      show "Pp3(m,x9,y)"
                        using A11 sorry
                    qed "sorry"
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A13: "domRELAT-1K1 f =XBOOLE-0R4 boolZFMISC-1K1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x)"and A14: " for x9 be objectHIDDENM1 holds x9 inHIDDENR3 boolZFMISC-1K1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ?Y(x9,f .FUNCT-1K1 x9)"
            using classes1_sch_1 A3 sorry
          have A15: " ex O be OrdinalORDINAL1M3 st ?X(O)"
          proof-
            have " ex O2 be setHIDDENM2 st  for X be setHIDDENM2 holds  for m be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(m,X,Y))"
            proof-
              obtain O2 where 
                [ty]:"O2 be setHIDDENM2" and O2Def:"O2 = supORDINAL2K3 (rngFUNCT-1K2 f)"
                 sorry
              show " ex O2 be setHIDDENM2 st  for X be setHIDDENM2 holds  for m be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(m,X,Y))"
              proof(rule bexI[of _ "O2"])
                show " for X be setHIDDENM2 holds  for m be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(m,X,Y))"
                proof-
                  have " for X be setHIDDENM2 holds  for m be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex tVar6 be setHIDDENM2 st tVar6 c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(m,X,tVar6))"
                  proof(rule ballI,rule ballI,rule impI)
                    fix X assume [ty]: "X be setHIDDENM2"
                    fix m assume [ty]: "m be NatNAT-1M1"
                    assume A16: "X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x)"
                    then obtain Y where
                      [ty]:"Y be setHIDDENM2" and 
                      A17: "f .FUNCT-1K1 X be OrdinalORDINAL1M3"and A18: "Y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (f .FUNCT-1K1 X))"and A19: "Pp3(m,X,Y)"
                      using A14 sorry
                    obtain O where 
                      [ty]:"O be OrdinalORDINAL1M3" and ODef:"O = f .FUNCT-1K1 X"
                      using A17 sorry
                    have "f .FUNCT-1K1 X inTARSKIR2 rngFUNCT-1K2 f"
                      using A13 A16 funct_1_def_3 sorry
                    then have "f .FUNCT-1K1 X inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 f)"
                      using A17 ordinal2_th_19 sorry
                    then have "f .FUNCT-1K1 X c=TARSKIR1 O2"
                      using ordinal1_def_2 sorry
                    then have A20: "RankCLASSES1K4 O c=TARSKIR1 RankCLASSES1K4 O2"
                      using classes1_th_37 sorry
                    show " ex tVar6 be setHIDDENM2 st tVar6 c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(m,X,tVar6)"
                    proof(rule bexI[of _ "Y"],rule conjMI)
                      have "the-rank-ofCLASSES1K7 O =XBOOLE-0R4 O"
                        using classes1_th_73 sorry
                      thus "Y c=TARSKIR1 RankCLASSES1K4 O2"
                        using A18 A20 sorry
                      show "Pp3(m,X,Y)"
                        using A19 sorry
                    qed "sorry"
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          obtain O2 where
            [ty]:"O2 be OrdinalORDINAL1M3" and 
            A21: "?X(O2) & ( for O be OrdinalORDINAL1M3 holds ?X(O) implies O2 c=ORDINAL1R1 O)"
            using ordinal1_sch_1 A15 sorry
          show " ex tVar7 be setHIDDENM2 st  ex O2c be OrdinalORDINAL1M3 st (O2c =XBOOLE-0R4 tVar7 & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2c & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2c c=ORDINAL1R1 O)"
          proof(rule bexI[of _ "O2"])
            show " ex O2c be OrdinalORDINAL1M3 st (O2c =XBOOLE-0R4 O2 & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2c & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2c c=ORDINAL1R1 O)"
              using A21 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A22: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ?Q(n,x,y1) & ?Q(n,x,y2) implies y1 =XBOOLE-0R4 y2"
      proof-
        have " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 y1 & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2 c=ORDINAL1R1 O)) & ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 y2 & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2 c=ORDINAL1R1 O)) implies y1 =XBOOLE-0R4 y2"
        proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be setHIDDENM2"
          fix y1 assume [ty]: "y1 be setHIDDENM2"
          fix y2 assume [ty]: "y2 be setHIDDENM2"
          assume A23: "?Q(n,x,y1)"
            and A24: "?Q(n,x,y2)"
          obtain O2 where
            [ty]:"O2 be OrdinalORDINAL1M3" and 
            A25: "O2 =XBOOLE-0R4 y2"and A26: "( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
            using A24 sorry
          obtain O1 where
            [ty]:"O1 be OrdinalORDINAL1M3" and 
            A27: "O1 =XBOOLE-0R4 y1"and A28: "( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O1 & Pp3(n,X,Y))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 x) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O1 c=ORDINAL1R1 O)"
            using A23 sorry
          have "O1 c=ORDINAL1R1 O2 & O2 c=ORDINAL1R1 O1"
            using A28 A26 sorry
          thus "y1 =XBOOLE-0R4 y2"
            using A27 A25 xboole_0_def_10 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " ex f be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
      proof-
        have " ex tVar16 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar16 =XBOOLE-0R4 NATNUMBERSK1 & (tVar16 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0 & ( for d be NatNAT-1M1 holds  ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar16 .FUNCT-1K1 (d +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar16 .FUNCT-1K1 d)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar16 .FUNCT-1K1 d)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))"
        proof-
          let ?S = "\<lambda>Lamb1. {k where k be NatNAT-1M1 : k <=XXREAL-0R1 Lamb1 }"
          have A29: " for p be FunctionFUNCT-1M1 holds  for q be FunctionFUNCT-1M1 holds  for k be NatNAT-1M1 holds ((domRELAT-1K1 p =XBOOLE-0R4 ?S(k) & domRELAT-1K1 q =XBOOLE-0R4 ?S(k +NAT-1K1 \<one>\<^sub>M)) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 q .FUNCT-1K1 (0NUMBERSK6)) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies ?Q(n,p .FUNCT-1K1 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & ?Q(n,q .FUNCT-1K1 n,q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))) implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
          proof-
            have " for p be FunctionFUNCT-1M1 holds  for q be FunctionFUNCT-1M1 holds  for k be NatNAT-1M1 holds domRELAT-1K1 p =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 k } & (domRELAT-1K1 q =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M } & (p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 q .FUNCT-1K1 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 n)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 n)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2 c=ORDINAL1R1 O)) & ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 n)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 n)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2 c=ORDINAL1R1 O))))) implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
            proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
              fix p assume [ty]: "p be FunctionFUNCT-1M1"
              fix q assume [ty]: "q be FunctionFUNCT-1M1"
              fix k assume [ty]: "k be NatNAT-1M1"
              let ?Z = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 k implies p .FUNCT-1K1 Lamb1 =XBOOLE-0R4 q .FUNCT-1K1 Lamb1"
              assume "domRELAT-1K1 p =XBOOLE-0R4 ?S(k)"
                and "domRELAT-1K1 q =XBOOLE-0R4 ?S(k +NAT-1K1 \<one>\<^sub>M)"
                and A30: "p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 q .FUNCT-1K1 (0NUMBERSK6)"
                and A31: " for n be NatNAT-1M1 holds n <XXREAL-0R3 k implies ?Q(n,p .FUNCT-1K1 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & ?Q(n,q .FUNCT-1K1 n,q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
              have A32: " for n be NatNAT-1M1 holds ?Z(n) implies ?Z(n +NAT-1K1 \<one>\<^sub>M)"
              proof-
                have " for n be NatNAT-1M1 holds (n <=XXREAL-0R1 k implies p .FUNCT-1K1 n =XBOOLE-0R4 q .FUNCT-1K1 n) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
                proof(rule ballI,rule impI,rule impI)
                  fix n assume [ty]: "n be NatNAT-1M1"
                  assume A33: "n <=XXREAL-0R1 k implies p .FUNCT-1K1 n =XBOOLE-0R4 q .FUNCT-1K1 n"
                  assume "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                  then have A34: "n <XXREAL-0R3 k"
                    using nat_1_th_13 sorry
                  then have A35: "?Q(n,p .FUNCT-1K1 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
                    using A31 sorry
                  have "?Q(n,p .FUNCT-1K1 n,q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
                    using A31 A33 A34 sorry
                  thus "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                    using A22 A35 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A36: "?Z(0NUMBERSK6)"
                using A30 sorry
              have " for n be NatNAT-1M1 holds ?Z(n)"
                using nat_1_sch_2 A36 A32 sorry
              thus "p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A37: " for n be NatNAT-1M1 holds  ex p be FunctionFUNCT-1M1 st (domRELAT-1K1 p =XBOOLE-0R4 ?S(n) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
          proof-
            have " for n be NatNAT-1M1 holds  ex p be FunctionFUNCT-1M1 st (domRELAT-1K1 p =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n } & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2 c=ORDINAL1R1 O)))"
            proof-
              let ?Z = "\<lambda>Lamb1.  ex p be FunctionFUNCT-1M1 st (domRELAT-1K1 p =XBOOLE-0R4 ?S(Lamb1) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 Lamb1 implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
              have A38: " for n be NatNAT-1M1 holds ?Z(n) implies ?Z(n +NAT-1K1 \<one>\<^sub>M)"
              proof-
                have " for n be NatNAT-1M1 holds ( ex p be FunctionFUNCT-1M1 st (domRELAT-1K1 p =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n } & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))) implies ( ex tVar10 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar10 =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M } & (tVar10 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0 & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar10 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar10 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar10 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))))"
                proof(rule ballI,rule impI)
                  fix n assume [ty]: "n be NatNAT-1M1"
                  assume Given: " ex p be FunctionFUNCT-1M1 st (domRELAT-1K1 p =XBOOLE-0R4 ?S(n) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
                  then obtain p where
                    [ty]:"p be FunctionFUNCT-1M1" and 
                    "domRELAT-1K1 p =XBOOLE-0R4 ?S(n)"and A39: "p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"and A40: " for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                     sorry
                  obtain z where
                    [ty]:"z be setHIDDENM2" and 
                    A41: "?Q(n,p .FUNCT-1K1 n,z)"
                    using A2 sorry
                  let ?ST = "\<lambda>Lamb1. \<lambda>Lamb2.  for k be NatNAT-1M1 holds k =HIDDENR1 Lamb1 implies (k <=XXREAL-0R1 n implies Lamb2 =HIDDENR1 p .FUNCT-1K1 k) & (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies Lamb2 =HIDDENR1 z)"
                  have A42: " for x be objectHIDDENM1 holds x inHIDDENR3 ?S(n +NAT-1K1 \<one>\<^sub>M) implies ( ex y be objectHIDDENM1 st ?ST(x,y))"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M } implies  not ( for y be objectHIDDENM1 holds  not ( for k be NatNAT-1M1 holds k =HIDDENR1 x implies (k <=XXREAL-0R1 n implies y =HIDDENR1 p .FUNCT-1K1 k) & (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies y =HIDDENR1 z)))"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume "x inHIDDENR3 ?S(n +NAT-1K1 \<one>\<^sub>M)"
                      then have A43: " ex m be NatNAT-1M1 st m =HIDDENR1 x & m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                         sorry
                      then obtain t where 
                        [ty]:"t be NatNAT-1M1" and tDef:"t = x"
                         sorry
                      have A44: "t <=XXREAL-0R1 n implies  not ( for y be objectHIDDENM1 holds  not ?ST(x,y))"
                      proof-
                        have "t <=XXREAL-0R1 n implies ( ex tVar8 be objectHIDDENM1 st  for k be NatNAT-1M1 holds k =HIDDENR1 x implies (k <=XXREAL-0R1 n implies tVar8 =XBOOLE-0R4 p .FUNCT-1K1 k) & (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies tVar8 =HIDDENR1 z))"
                        proof(rule impI)
                          assume A45: "t <=XXREAL-0R1 n"
                          show " ex tVar8 be objectHIDDENM1 st  for k be NatNAT-1M1 holds k =HIDDENR1 x implies (k <=XXREAL-0R1 n implies tVar8 =XBOOLE-0R4 p .FUNCT-1K1 k) & (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies tVar8 =HIDDENR1 z)"
                          proof(rule bexI[of _ "p .FUNCT-1K1 x"],rule ballI,rule impI,rule conjMI,rule impI)
                            fix k assume [ty]: "k be NatNAT-1M1"
                            assume A46: "k =HIDDENR1 x"
                            thus "k <=XXREAL-0R1 n implies p .FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 k"
                               sorry
                            assume "k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
                            then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 0NUMBERSK6"
                              using A45 A46 sorry
                            thus "p .FUNCT-1K1 x =HIDDENR1 z"
                              using xreal_1_th_6 sorry
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      have "t =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies  not ( for y be objectHIDDENM1 holds  not ?ST(x,y))"
                      proof-
                        have "t =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies ( ex tVar9 be objectHIDDENM1 st  for k be NatNAT-1M1 holds k =HIDDENR1 x implies (k <=XXREAL-0R1 n implies tVar9 =XBOOLE-0R4 p .FUNCT-1K1 k) &  not (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M &  not tVar9 =HIDDENR1 tVar9))"
                        proof(rule impI)
                          assume A47: "t =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
                          show " ex tVar9 be objectHIDDENM1 st  for k be NatNAT-1M1 holds k =HIDDENR1 x implies (k <=XXREAL-0R1 n implies tVar9 =XBOOLE-0R4 p .FUNCT-1K1 k) &  not (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M &  not tVar9 =HIDDENR1 tVar9)"
                          proof(rule bexI[of _ "z"],rule ballI,rule impI,rule conjMI)
                            fix k assume [ty]: "k be NatNAT-1M1"
                            assume A48: "k =HIDDENR1 x"
                            show "k <=XXREAL-0R1 n implies z =XBOOLE-0R4 p .FUNCT-1K1 k"
                            proof(rule impI)
                              assume "k <=XXREAL-0R1 n"
                              then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 0NUMBERSK6"
                                using A47 A48 sorry
                              thus "z =XBOOLE-0R4 p .FUNCT-1K1 k"
                                using xreal_1_th_6 sorry
                            qed
                            show " not (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M &  not z =HIDDENR1 z)"
                               sorry
                          qed "sorry"
                        qed
                        thus " ?thesis "
                           sorry
                      qed
                      thus " not ( for y be objectHIDDENM1 holds  not ( for k be NatNAT-1M1 holds k =HIDDENR1 x implies (k <=XXREAL-0R1 n implies y =HIDDENR1 p .FUNCT-1K1 k) & (k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies y =HIDDENR1 z)))"
                        using A43 A44 nat_1_th_8 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  obtain q where
                    [ty]:"q be FunctionFUNCT-1M1" and 
                    A49: "domRELAT-1K1 q =XBOOLE-0R4 ?S(n +NAT-1K1 \<one>\<^sub>M) & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?S(n +NAT-1K1 \<one>\<^sub>M) implies ?ST(x,q .FUNCT-1K1 x))"
                    using classes1_sch_1 A42 sorry
                  show " ex tVar10 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar10 =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M } & (tVar10 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0 & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar10 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar10 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar10 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))))"
                  proof(rule bexI[of _ "q"],rule conjMI,rule conjMI,rule ballI,rule impI)
                    show "domRELAT-1K1 q =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M }"
                      using A49 sorry
                    have "0NUMBERSK6 inTARSKIR2 ?S(n +NAT-1K1 \<one>\<^sub>M)"
                       sorry
                    thus "q .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"
                      using A39 A49 sorry
                    fix k assume [ty]: "k be NatNAT-1M1"
                    assume A50: "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                    have A51: "k <>HIDDENR2 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))"
                    proof(rule impI)
                      have A52: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                        using A50 nat_1_th_13 sorry
                      assume "k <>HIDDENR2 n"
                      then have "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
                         sorry
                      then have A53: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                        using A52 nat_1_th_8 sorry
                      then have A54: "k <XXREAL-0R3 n"
                        using nat_1_th_13 sorry
                      have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 ?S(n +NAT-1K1 \<one>\<^sub>M)"
                        using A52 sorry
                      then have A55: "q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                        using A49 A53 sorry
                      have "k inTARSKIR2 ?S(n +NAT-1K1 \<one>\<^sub>M)"
                        using A50 sorry
                      then have "p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
                        using A49 A54 sorry
                      thus " ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
                        using A40 A55 A54 sorry
                    qed
                    have "k =XBOOLE-0R4 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))"
                    proof(rule impI)
                      assume A56: "k =XBOOLE-0R4 n"
                      then have "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                        using nat_1_th_11 sorry
                      then have "k inTARSKIR2 ?S(n +NAT-1K1 \<one>\<^sub>M)"
                         sorry
                      then have A57: "q .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
                        using A49 A56 sorry
                      have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 ?S(n +NAT-1K1 \<one>\<^sub>M)"
                        using A56 sorry
                      then have "q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z"
                        using A49 A56 sorry
                      thus " ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
                        using A41 A56 A57 sorry
                    qed
                    thus " ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
                      using A51 sorry
                  qed "sorry"
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A58: "?Z(0NUMBERSK6)"
              proof-
                have " ex tVar11 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar11 =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 } & (tVar11 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0 & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 0NUMBERSK6 &  not ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar11 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar11 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar11 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))))"
                proof-
                  let ?s = "?S(0NUMBERSK6) -->FUNCOP-1K7 the-rank-ofCLASSES1K6 Af0"
                  show " ex tVar11 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar11 =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 } & (tVar11 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0 & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 0NUMBERSK6 &  not ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar11 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar11 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar11 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))))"
                  proof(rule bexI[of _ "?s"],rule conjMI,rule conjMI)
                    show "domRELAT-1K1 (({kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 })-->FUNCOP-1K7 the-rank-ofCLASSES1K6 Af0) =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 }"
                      using funcop_1_th_13 sorry
                    have "0NUMBERSK6 inTARSKIR2 ?S(0NUMBERSK6)"
                       sorry
                    thus "(({kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 })-->FUNCOP-1K7 the-rank-ofCLASSES1K6 Af0).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"
                      using funcop_1_th_7 sorry
                    show " for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 0NUMBERSK6 &  not ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 (({kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 })-->FUNCOP-1K7 the-rank-ofCLASSES1K6 Af0).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 ((({kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 })-->FUNCOP-1K7 the-rank-ofCLASSES1K6 Af0).FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 ((({kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 0NUMBERSK6 })-->FUNCOP-1K7 the-rank-ofCLASSES1K6 Af0).FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))"
                       sorry
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
              show " for n be NatNAT-1M1 holds  ex p be FunctionFUNCT-1M1 st (domRELAT-1K1 p =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n } & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(nc,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for nc be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(nc,X,Y))) implies O2 c=ORDINAL1R1 O)))"
                using nat_1_sch_2 A58 A38 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds  ex p be FunctionFUNCT-1M1 st ((domRELAT-1K1 p =XBOOLE-0R4 ?S(n) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) & f .FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n)"
          proof-
            have " ex tVar14 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar14 =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds  ex tVar15 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar15 =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n } & tVar15 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & (( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar15 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar15 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar15 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))) & tVar14 .FUNCT-1K1 n =XBOOLE-0R4 tVar15 .FUNCT-1K1 n))"
            proof-
              let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be NatNAT-1M1 holds n =HIDDENR1 Lamb1 implies ( ex p be FunctionFUNCT-1M1 st ((domRELAT-1K1 p =XBOOLE-0R4 ?S(n) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) & Lamb2 =HIDDENR1 p .FUNCT-1K1 n)"
              have A59: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st ?Z(x,y))"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex pn be setHIDDENM2 st  for k be NatNAT-1M1 holds k =HIDDENR1 x implies ( ex P be FunctionFUNCT-1M1 st ((domRELAT-1K1 P =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 k } & P .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 k &  not ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 P .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))))) & pn =HIDDENR1 P .FUNCT-1K1 k))"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 NATNUMBERSK1"
                  then obtain n where 
                    [ty]:"n be NatNAT-1M1" and nDef:"n = x"
                     sorry
                  obtain p where
                    [ty]:"p be FunctionFUNCT-1M1" and 
                    A60: "(domRELAT-1K1 p =XBOOLE-0R4 ?S(n) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
                    using A37 sorry
                  obtain pn where 
                    [ty]:"pn be setHIDDENM2" and pnDef:"pn = p .FUNCT-1K1 n"
                     sorry
                  show " ex pn be setHIDDENM2 st  for k be NatNAT-1M1 holds k =HIDDENR1 x implies ( ex P be FunctionFUNCT-1M1 st ((domRELAT-1K1 P =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 k } & P .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 k &  not ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 P .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))))) & pn =HIDDENR1 P .FUNCT-1K1 k)"
                  proof(rule bexI[of _ "pn"],rule ballI,rule impI)
                    fix k assume [ty]: "k be NatNAT-1M1"
                    assume A61: "k =HIDDENR1 x"
                    obtain P where 
                      [ty]:"P be FunctionFUNCT-1M1" and PDef:"P = p"
                       sorry
                    show " ex P be FunctionFUNCT-1M1 st ((domRELAT-1K1 P =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 k } & P .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 k &  not ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 P .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))))) & pn =HIDDENR1 P .FUNCT-1K1 k"
                    proof(rule bexI[of _ "P"])
                      show "((domRELAT-1K1 P =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 k } & P .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds  not ( not k <XXREAL-0R3 k &  not ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 P .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (P .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))))) & pn =HIDDENR1 P .FUNCT-1K1 k"
                        using A60 A61 sorry
                    qed "sorry"
                  qed "sorry"
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              obtain f where
                [ty]:"f be FunctionFUNCT-1M1" and 
                A62: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?Z(x,f .FUNCT-1K1 x))"
                using classes1_sch_1 A59 sorry
              show " ex tVar14 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar14 =XBOOLE-0R4 NATNUMBERSK1 & ( for n be NatNAT-1M1 holds  ex tVar15 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar15 =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n } & tVar15 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & (( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar15 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar15 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar15 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))) & tVar14 .FUNCT-1K1 n =XBOOLE-0R4 tVar15 .FUNCT-1K1 n))"
              proof(rule bexI[of _ "f"],rule conjMI,rule ballI)
                show "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
                  using A62 sorry
                fix n assume [ty]: "n be NatNAT-1M1"
                have "n inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                then obtain p where
                  [ty]:"p be FunctionFUNCT-1M1" and 
                  A63: "domRELAT-1K1 p =XBOOLE-0R4 ?S(n) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"and A64: " for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"and A65: "f .FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
                  using A62 sorry
                show " ex tVar15 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar15 =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n } & tVar15 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & (( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar15 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar15 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar15 .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))) & f .FUNCT-1K1 n =XBOOLE-0R4 tVar15 .FUNCT-1K1 n)"
                proof(rule bexI[of _ "p"],rule conjMI,rule conjMI)
                  show "domRELAT-1K1 p =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 n } & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"
                    using A63 sorry
                  show " for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O))"
                    using A64 sorry
                  show "f .FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
                    using A65 sorry
                qed "sorry"
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A66: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A67: " for n be NatNAT-1M1 holds  ex p be FunctionFUNCT-1M1 st ((domRELAT-1K1 p =XBOOLE-0R4 ?S(n) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) & f .FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
             sorry
          show " ex tVar16 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar16 =XBOOLE-0R4 NATNUMBERSK1 & (tVar16 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0 & ( for d be NatNAT-1M1 holds  ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 tVar16 .FUNCT-1K1 (d +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar16 .FUNCT-1K1 d)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (tVar16 .FUNCT-1K1 d)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))"
          proof(rule bexI[of _ "f"],rule conjMI,rule conjMI,rule ballI)
            show "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
              using A66 sorry
            have " ex p be FunctionFUNCT-1M1 st ((domRELAT-1K1 p =XBOOLE-0R4 ?S(0NUMBERSK6) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 0NUMBERSK6 implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6)"
              using A67 sorry
            thus "f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"
               sorry
            fix d assume [ty]: "d be NatNAT-1M1"
            obtain p where
              [ty]:"p be FunctionFUNCT-1M1" and 
              A68: "domRELAT-1K1 p =XBOOLE-0R4 ?S(d +NAT-1K1 \<one>\<^sub>M)"and A69: "p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"and A70: " for k be NatNAT-1M1 holds k <XXREAL-0R3 d +NAT-1K1 \<one>\<^sub>M implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"and A71: "f .FUNCT-1K1 (d +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (d +NAT-1K1 \<one>\<^sub>M)"
              using A67 sorry
            obtain q where
              [ty]:"q be FunctionFUNCT-1M1" and 
              A72: "domRELAT-1K1 q =XBOOLE-0R4 ?S(d)"and A73: "q .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"and A74: " for k be NatNAT-1M1 holds k <XXREAL-0R3 d implies ?Q(k,q .FUNCT-1K1 k,q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"and A75: "f .FUNCT-1K1 d =XBOOLE-0R4 q .FUNCT-1K1 d"
              using A67 sorry
            have "((domRELAT-1K1 p =XBOOLE-0R4 ?S(d +NAT-1K1 \<one>\<^sub>M) & domRELAT-1K1 q =XBOOLE-0R4 ?S(d)) & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 q .FUNCT-1K1 (0NUMBERSK6)) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 d implies ?Q(k,q .FUNCT-1K1 k,q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
            proof-
              have "domRELAT-1K1 p =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 d +NAT-1K1 \<one>\<^sub>M } & (domRELAT-1K1 q =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 d } & (p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 q .FUNCT-1K1 (0NUMBERSK6) & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 d implies ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)) & ( ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)))))"
              proof(rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impI,rule conjMI)
                show "domRELAT-1K1 p =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 d +NAT-1K1 \<one>\<^sub>M }"
                  using A68 sorry
                show "domRELAT-1K1 q =XBOOLE-0R4 {kc where kc be NatNAT-1M1 : kc <=XXREAL-0R1 d }"
                  using A72 sorry
                show "p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 q .FUNCT-1K1 (0NUMBERSK6)"
                  using A69 A73 sorry
                fix k assume [ty]: "k be NatNAT-1M1"
                assume A76: "k <XXREAL-0R3 d"
                thus " ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (q .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
                  using A74 sorry
                have "d <=XXREAL-0R1 d +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                then have "k <XXREAL-0R3 d +NAT-1K1 \<one>\<^sub>M"
                  using A76 xxreal_0_th_2 sorry
                thus " ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (p .FUNCT-1K1 k)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
                  using A70 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            then have "p .FUNCT-1K1 d =XBOOLE-0R4 q .FUNCT-1K1 d"
              using A29 sorry
            thus " ex O2 be OrdinalORDINAL1M3 st (O2 =XBOOLE-0R4 f .FUNCT-1K1 (d +NAT-1K1 \<one>\<^sub>M) & ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (f .FUNCT-1K1 d)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(n,X,Y)))) & ( for O be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (f .FUNCT-1K1 d)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 O & Pp3(n,X,Y))) implies O2 c=ORDINAL1R1 O)"
              using A70 A71 A75 xreal_1_th_29 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A77: "domRELAT-1K1 g =XBOOLE-0R4 NATNUMBERSK1"and A78: "g .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 the-rank-ofCLASSES1K6 Af0"and A79: " for n be NatNAT-1M1 holds ?Q(n,g .FUNCT-1K1 n,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
         sorry
      let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex i be NatNAT-1M1 st ((i =HIDDENR1 Lamb1 `2XTUPLE-0K2 & Pp3(Lamb1 `2XTUPLE-0K2,Lamb1 `1XTUPLE-0K1,Lamb2 `1XTUPLE-0K1)) & Lamb2 `2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M) &  not ( ex y be setHIDDENM2 st Pp3(Lamb1 `2XTUPLE-0K2,Lamb1 `1XTUPLE-0K1,y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 Lamb2 `1XTUPLE-0K1)"
      have A80: "[TARSKIK4 Af0,0NUMBERSK6 ] `1XTUPLE-0K1 =HIDDENR1 Af0 & [TARSKIK4 Af0,0NUMBERSK6 ] `2XTUPLE-0K2 =HIDDENR1 0NUMBERSK6"
         sorry
      let ?beta = "supORDINAL2K3 (rngFUNCT-1K2 g)"
      have A81: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 RankCLASSES1K4 ?beta,NATNUMBERSK1 :] implies ( ex u be objectHIDDENM1 st ?X(x,u))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 g)),NATNUMBERSK1 :] implies ( ex u be objectHIDDENM1 st  ex i be NatNAT-1M1 st i =HIDDENR1 x `2XTUPLE-0K2 & (Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,u `1XTUPLE-0K1) & (u `2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M & (( ex y be setHIDDENM2 st Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 u `1XTUPLE-0K1) implies  False ))))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          let ?X = "\<lambda>Lamb1.  ex y be setHIDDENM2 st y c=TARSKIR1 RankCLASSES1K4 Lamb1 & Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,y)"
          assume "x inHIDDENR3 [:ZFMISC-1K2 RankCLASSES1K4 ?beta,NATNUMBERSK1 :]"
          then obtain a b where
            [ty]:"a be objectHIDDENM1" "b be objectHIDDENM1" and 
            A82: "a inHIDDENR3 RankCLASSES1K4 ?beta"and A83: "b inHIDDENR3 NATNUMBERSK1"and A84: "x =HIDDENR1 [TARSKIK4 a,b ]"
            using zfmisc_1_def_2 sorry
          have 
            [ty]:"b be NatNAT-1M1"
            using A83 sorry
          have A85: "x `2XTUPLE-0K2 =HIDDENR1 b & x `1XTUPLE-0K1 =HIDDENR1 a"
            using A84 sorry
          have "the-rank-ofCLASSES1K6 a inTARSKIR2 ?beta"
            using A82 classes1_th_66 sorry
          then obtain alfa where
            [ty]:"alfa be OrdinalORDINAL1M3" and 
            A86: "alfa inTARSKIR2 rngFUNCT-1K2 g"and A87: "the-rank-ofCLASSES1K6 a c=ORDINAL1R1 alfa"
            using ordinal2_th_21 sorry
          obtain k where
            [ty]:"k be objectHIDDENM1" and 
            A88: "k inHIDDENR3 domRELAT-1K1 g"and A89: "alfa =XBOOLE-0R4 g .FUNCT-1K1 k"
            using A86 funct_1_def_3 sorry
          have 
            [ty]:"k be NatNAT-1M1"
            using A77 A88 sorry
          have A90: "?Q(k,alfa,g .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
            using A79 A89 sorry
          then obtain O2 where 
            [ty]:"O2 be OrdinalORDINAL1M3" and O2Def:"O2 = g .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
          have 
            [ty]:"a be setHIDDENM2"
            using tarski_th_1 sorry
          have "a c=TARSKIR1 RankCLASSES1K4 alfa"
            using A87 classes1_th_65 sorry
          then have "a c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 alfa)"
            using classes1_th_73 sorry
          then have " ex y be setHIDDENM2 st y c=TARSKIR1 RankCLASSES1K4 O2 & Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,y)"
            using A90 A85 sorry
          then have A91: " ex O be OrdinalORDINAL1M3 st ?X(O)"
             sorry
          obtain O where
            [ty]:"O be OrdinalORDINAL1M3" and 
            A92: "?X(O)"and A93: " for O9 be OrdinalORDINAL1M3 holds ?X(O9) implies O c=ORDINAL1R1 O9"
            using ordinal1_sch_1 A91 sorry
          obtain Y where
            [ty]:"Y be setHIDDENM2" and 
            A94: "Y c=TARSKIR1 RankCLASSES1K4 O"and A95: "Pp3(b,a,Y)"
            using A85 A92 sorry
          have A96: "the-rank-ofCLASSES1K7 Y c=ORDINAL1R1 O"
            using A94 classes1_th_65 sorry
          obtain u where 
            [ty]:"u be objectHIDDENM1" and uDef:"u = [TARSKIK4 Y,b +NAT-1K1 \<one>\<^sub>M ]"
             sorry
          show " ex u be objectHIDDENM1 st  ex i be NatNAT-1M1 st i =HIDDENR1 x `2XTUPLE-0K2 & (Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,u `1XTUPLE-0K1) & (u `2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M & (( ex y be setHIDDENM2 st Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 u `1XTUPLE-0K1) implies  False )))"
          proof(rule bexI[of _ "u"])
            obtain i where 
              [ty]:"i be NatNAT-1M1" and iDef:"i = b"
               sorry
            show " ex i be NatNAT-1M1 st i =HIDDENR1 x `2XTUPLE-0K2 & (Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,u `1XTUPLE-0K1) & (u `2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M & (( ex y be setHIDDENM2 st Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 u `1XTUPLE-0K1) implies  False )))"
            proof(rule bexI[of _ "i"],rule conjMI,rule conjMI,rule conjMI,rule impI)
              show "i =HIDDENR1 x `2XTUPLE-0K2"
                using A84 sorry
              show "Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,u `1XTUPLE-0K1)"
                using A85 A95 sorry
              show "u `2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M"
                 sorry
              assume Given: " ex y be setHIDDENM2 st Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 u `1XTUPLE-0K1"
              then obtain y where
                [ty]:"y be setHIDDENM2" and 
                A97: "Pp3(x `2XTUPLE-0K2,x `1XTUPLE-0K1,y)"and A98: "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 u `1XTUPLE-0K1"
                 sorry
              have A99: "y c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 y)"
                using classes1_def_9 sorry
              have "the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K7 Y"
                using A98 sorry
              thus " False "
                using A93 A97 A96 A99 ordinal1_th_5 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain F where
        [ty]:"F be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 F =XBOOLE-0R4 [:ZFMISC-1K2 RankCLASSES1K4 ?beta,NATNUMBERSK1 :]"and A100: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 RankCLASSES1K4 ?beta,NATNUMBERSK1 :] implies ?X(x,F .FUNCT-1K1 x)"
        using classes1_sch_1 A81 sorry
      let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. (F .FUNCT-1K1 [TARSKIK4 Lamb2,Lamb1 ])`1XTUPLE-0K1"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A101: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A102: "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"and A103: " for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?U(n,f .FUNCT-1K1 n)"
        using nat_1_sch_11 sorry
      let ?X = "\<lambda>Lamb1. the-rank-ofCLASSES1K7 (f .FUNCT-1K1 Lamb1) inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 g)"
      have "g .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 rngFUNCT-1K2 g"
        using A77 funct_1_def_3 sorry
      then have A104: "?X(0NUMBERSK6)"
        using A78 A102 ordinal2_th_19 sorry
      have A105: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds the-rank-ofCLASSES1K7 (f .FUNCT-1K1 n) inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 g) implies the-rank-ofCLASSES1K7 (f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 g)"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A106: "the-rank-ofCLASSES1K7 (f .FUNCT-1K1 n) inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 g)"
          then obtain o1 where
            [ty]:"o1 be OrdinalORDINAL1M3" and 
            A107: "o1 inTARSKIR2 rngFUNCT-1K2 g"and A108: "the-rank-ofCLASSES1K7 (f .FUNCT-1K1 n) c=ORDINAL1R1 o1"
            using ordinal2_th_21 sorry
          have A109: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "f .FUNCT-1K1 n inTARSKIR2 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 g))"
            using A106 classes1_th_66 sorry
          then have A110: "[TARSKIK4 f .FUNCT-1K1 n,n ] inHIDDENR3 [:ZFMISC-1K2 RankCLASSES1K4 ?beta,NATNUMBERSK1 :]"
            using A109 zfmisc_1_th_87 sorry
          obtain m where
            [ty]:"m be objectHIDDENM1" and 
            A111: "m inHIDDENR3 domRELAT-1K1 g"and A112: "g .FUNCT-1K1 m =XBOOLE-0R4 o1"
            using A107 funct_1_def_3 sorry
          have 
            [ty]:"m be NatNAT-1M1"
            using A77 A111 sorry
          obtain o2 where
            [ty]:"o2 be OrdinalORDINAL1M3" and 
            A113: "o2 =XBOOLE-0R4 g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"and A114: " for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (g .FUNCT-1K1 m)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 o2 & Pp3(n,X,Y))"and " for o be OrdinalORDINAL1M3 holds ( for X be setHIDDENM2 holds  for n be NatNAT-1M1 holds X c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (g .FUNCT-1K1 m)) implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 RankCLASSES1K4 o & Pp3(n,X,Y))) implies o2 c=ORDINAL1R1 o"
            using A79 sorry
          have "the-rank-ofCLASSES1K7 (f .FUNCT-1K1 n) c=ORDINAL1R1 the-rank-ofCLASSES1K7 (g .FUNCT-1K1 m)"
            using A108 A112 classes1_th_73 sorry
          then have "f .FUNCT-1K1 n c=TARSKIR1 RankCLASSES1K4 (the-rank-ofCLASSES1K7 (g .FUNCT-1K1 m))"
            using classes1_th_65 sorry
          then obtain YY where
            [ty]:"YY be setHIDDENM2" and 
            A115: "YY c=TARSKIR1 RankCLASSES1K4 o2"and A116: "Pp3(n,f .FUNCT-1K1 n,YY)"
            using A114 sorry
          have A117: "the-rank-ofCLASSES1K7 YY c=ORDINAL1R1 o2"
            using A115 classes1_th_65 sorry
          have "[TARSKIK4 f .FUNCT-1K1 n,n ] `1XTUPLE-0K1 =HIDDENR1 f .FUNCT-1K1 n & [TARSKIK4 f .FUNCT-1K1 n,n ] `2XTUPLE-0K2 =HIDDENR1 n"
             sorry
          then have " ex i be NatNAT-1M1 st ((i =XBOOLE-0R4 n & Pp3(n,f .FUNCT-1K1 n,(F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 n,n ])`1XTUPLE-0K1)) & (F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 n,n ])`2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M) &  not ( ex y be setHIDDENM2 st Pp3(n,f .FUNCT-1K1 n,y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 (F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 n,n ])`1XTUPLE-0K1)"
            using A100 A110 sorry
          then have A118: "the-rank-ofCLASSES1K6 (F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 n,n ])`1XTUPLE-0K1 c=ORDINAL1R1 the-rank-ofCLASSES1K7 YY"
            using A116 ordinal1_th_16 sorry
          have "g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 g"
            using A77 funct_1_def_3 sorry
          then have A119: "o2 inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 g)"
            using A113 ordinal2_th_19 sorry
          have "f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 n,n ])`1XTUPLE-0K1"
            using A103 sorry
          thus "the-rank-ofCLASSES1K7 (f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 g)"
            using A118 A117 A119 ordinal1_th_12 xboole_1_th_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A120: " for n be NatNAT-1M1 holds ?X(n)"
        using nat_1_sch_2 A104 A105 sorry
      let ?X = "\<lambda>Lamb1. Pp3(Lamb1,f .FUNCT-1K1 Lamb1,f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M))"
      have A121: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) implies Pp3(n +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          have "the-rank-ofCLASSES1K7 (f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) inTARSKIR2 supORDINAL2K3 (rngFUNCT-1K2 g)"
            using A120 sorry
          then have "f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 g))"
            using classes1_th_66 sorry
          then have A122: "[TARSKIK4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M ] inHIDDENR3 [:ZFMISC-1K2 RankCLASSES1K4 ?beta,NATNUMBERSK1 :]"
            using zfmisc_1_th_87 sorry
          have "[TARSKIK4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M ] `1XTUPLE-0K1 =HIDDENR1 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & [TARSKIK4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M ] `2XTUPLE-0K2 =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
             sorry
          then have " ex i be NatNAT-1M1 st ((i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & Pp3(n +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),(F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M ])`1XTUPLE-0K1)) & (F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M ])`2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M) &  not ( ex y be setHIDDENM2 st Pp3(n +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 (F .FUNCT-1K1 [TARSKIK4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),n +NAT-1K1 \<one>\<^sub>M ])`1XTUPLE-0K1)"
            using A100 A122 sorry
          thus "Pp3(n +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
            using A103 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " ex tVar19 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar19 =XBOOLE-0R4 NATNUMBERSK1 & (tVar19 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & ( for n be NatNAT-1M1 holds Pp3(n,tVar19 .FUNCT-1K1 n,tVar19 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
      proof(rule bexI[of _ "f"],rule conjMI,rule conjMI)
        show "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
          using A101 sorry
        show "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"
          using A102 sorry
        have "Af0 inHIDDENR3 RankCLASSES1K4 (supORDINAL2K3 (rngFUNCT-1K2 g))"
          using A102 A104 classes1_th_66 sorry
        then have "[TARSKIK4 Af0,0NUMBERSK6 ] inHIDDENR3 [:ZFMISC-1K2 RankCLASSES1K4 ?beta,NATNUMBERSK1 :]"
          using zfmisc_1_th_87 sorry
        then have " ex i be NatNAT-1M1 st ((i =HIDDENR1 [TARSKIK4 Af0,0NUMBERSK6 ] `2XTUPLE-0K2 & Pp3(0NUMBERSK6,Af0,(F .FUNCT-1K1 [TARSKIK4 Af0,0NUMBERSK6 ])`1XTUPLE-0K1)) & (F .FUNCT-1K1 [TARSKIK4 Af0,0NUMBERSK6 ])`2XTUPLE-0K2 =HIDDENR1 i +NAT-1K1 \<one>\<^sub>M) &  not ( ex y be setHIDDENM2 st Pp3(0NUMBERSK6,Af0,y) & the-rank-ofCLASSES1K7 y inTARSKIR2 the-rank-ofCLASSES1K6 (F .FUNCT-1K1 [TARSKIK4 Af0,0NUMBERSK6 ])`1XTUPLE-0K1)"
          using A100 A80 sorry
        then have A123: "?X(0NUMBERSK6)"
          using A102 A103 sorry
        show " for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          using nat_1_sch_2 A123 A121 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_2:
  fixes Df0 Af0 Pp3 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
   A1: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st Pp3(n,x,y)"
  shows " ex f be sequenceNAT-1M2-of Df0 st f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " ex tVar22 be sequenceNAT-1M2-of Df0 st tVar22 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds Pp3(n,tVar22 .FUNCT-1K1 n,tVar22 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Pp3(Lamb1,Lamb2,Lamb3)"
      have A2: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for y be ElementSUBSET-1M1-of Df0 holds  ex z be ElementSUBSET-1M1-of Df0 st ?Q(x,y,z)"
        using A1 sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 NATNUMBERSK1,Df0 :],Df0)" and 
        A3: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for y be ElementSUBSET-1M1-of Df0 holds ?Q(x,y,f .BINOP-1K2\<^bsub>(NATNUMBERSK1,Df0,Df0)\<^esub>(x,y))"
        using binop_1_sch_3 A2 sorry
      let ?P = "\<lambda>Lamb1. Lamb1 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Lamb1 implies Lamb1 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,Lamb1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ])"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & ?P(p)) & x =HIDDENR1 p)"
        using finseq_1_sch_4 sorry
      let ?Y = "unionTARSKIK3 X"
      have A5: " for x be setHIDDENM2 holds x inTARSKIR2 X implies x inTARSKIR2 Df0 * FINSEQ-1K14"
      proof-
        have " for x be setHIDDENM2 holds x inTARSKIR2 X implies x inTARSKIR2 Df0 * FINSEQ-1K14"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          assume "x inTARSKIR2 X"
          then have " ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & (p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]))) & x =XBOOLE-0R4 p"
            using A4 sorry
          thus "x inTARSKIR2 Df0 * FINSEQ-1K14"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A6: " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p inTARSKIR2 X & q inTARSKIR2 X) & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q implies p c=RELAT-1R2 q"
      proof-
        have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 X & (q inTARSKIR2 X & lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q) implies p c=RELAT-1R2 q"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
          fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
          assume A7: "p inTARSKIR2 X"
            and A8: "q inTARSKIR2 X"
            and A9: "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
          have A10: " ex q9 be FinSequenceFINSEQ-1M1 st (q9 inTARSKIR2 Df0 * FINSEQ-1K14 & (q9 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q9 implies q9 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,q9 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]))) & q =FINSEQ-1R1 q9"
            using A4 A8 sorry
          have A11: " ex p9 be FinSequenceFINSEQ-1M1 st (p9 inTARSKIR2 Df0 * FINSEQ-1K14 & (p9 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p9 implies p9 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,p9 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]))) & p =FINSEQ-1R1 p9"
            using A4 A7 sorry
          have A12: " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 n =XBOOLE-0R4 q .FUNCT-1K1 n"
          proof-
            have "( ex n be NatNAT-1M1 st (\<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p) & p .FUNCT-1K1 n <>HIDDENR2 q .FUNCT-1K1 n) implies  False "
            proof(rule impI)
              let ?P = "\<lambda>Lamb1. (\<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 p) & p .FUNCT-1K1 Lamb1 <>HIDDENR2 q .FUNCT-1K1 Lamb1"
              assume " ex n be NatNAT-1M1 st ?P(n)"
              then have A13: " ex n be NatNAT-1M1 st ?P(n)"
                 sorry
              obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A14: "?P(k) & ( for n be NatNAT-1M1 holds ?P(n) implies k <=XXREAL-0R1 n)"
                using nat_1_sch_5 A13 sorry
              have "k =XBOOLE-0R4 \<one>\<^sub>M"
              proof-
                have "k <>HIDDENR2 \<one>\<^sub>M implies  not  True "
                proof(rule impI)
                  have "0NUMBERSK6 <>HIDDENR2 k"
                    using A14 sorry
                  then obtain n where
                    [ty]:"n be NatNAT-1M1" and 
                    A15: "k =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
                    using nat_1_th_6 sorry
                  have "n +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                    using xreal_1_th_7 sorry
                  then have A16: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
                    using A14 A15 xxreal_0_th_2 sorry
                  have A17: "n +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                    using xreal_1_th_6 sorry
                  assume A18: "k <>HIDDENR2 \<one>\<^sub>M"
                  then have "\<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                    using A14 A15 xxreal_0_th_1 sorry
                  then have A19: "\<one>\<^sub>M <=XXREAL-0R1 n"
                    using nat_1_th_13 sorry
                  have "n <>HIDDENR2 0NUMBERSK6"
                    using A18 A15 sorry
                  then obtain m where
                    [ty]:"m be NatNAT-1M1" and 
                    A20: "n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
                    using nat_1_th_6 sorry
                  have 
                    [ty]:"m be NatNAT-1M1"
                     sorry
                  have A21: "m +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
                    using A9 A14 A15 A20 xxreal_0_th_2 sorry
                  have "p .FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 (m +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
                    using A15 A20 sorry
                  also have "... = f .FUNCT-1K1 [TARSKIK4 m,p .FUNCT-1K1 n ]"
                    using A11 A14 A15 A20 sorry
                  also have "... = f .FUNCT-1K1 [TARSKIK4 m,q .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) ]"
                    using A14 A15 A19 A16 A17 A20 sorry
                  also have "... = q .FUNCT-1K1 k"
                    using A10 A15 A20 A21 sorry
                  finally have "p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
                     sorry
                  thus " not  True "
                    using A14 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus " False "
                using A11 A10 A14 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 p implies x inHIDDENR3 q"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 p"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A22: "n inTARSKIR2 domFINSEQ-1K5 p"and A23: "x =HIDDENR1 [TARSKIK4 n,p .FUNCT-1K1 n ]"
              using finseq_1_th_12 sorry
            have A24: "n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using A22 finseq_1_def_3 sorry
            then have A25: "\<one>\<^sub>M <=XXREAL-0R1 n"
              using finseq_1_th_1 sorry
            have A26: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
              using A24 finseq_1_th_1 sorry
            then have "n <=XXREAL-0R1 lenFINSEQ-1K4 q"
              using A9 xxreal_0_th_2 sorry
            then have "n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
              using A25 finseq_1_th_1 sorry
            then have A27: "n inTARSKIR2 domFINSEQ-1K5 q"
              using finseq_1_def_3 sorry
            have "x =HIDDENR1 [TARSKIK4 n,q .FUNCT-1K1 n ]"
              using A12 A23 A25 A26 sorry
            thus "x inHIDDENR3 q"
              using A27 funct_1_th_1 sorry
          qed "sorry"
          thus "p c=RELAT-1R2 q"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A28: "?Y be Function-likeFUNCT-1V1"
      proof-
        have "unionTARSKIK3 X be Function-likeFUNCT-1V1"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 ?Y & [TARSKIK4 x,z ] inHIDDENR3 ?Y implies y =HIDDENR1 z"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A29: "[TARSKIK4 x,y ] inHIDDENR3 ?Y"
              and A30: "[TARSKIK4 x,z ] inHIDDENR3 ?Y"
            obtain Z2 where
              [ty]:"Z2 be setHIDDENM2" and 
              A31: "[TARSKIK4 x,z ] inHIDDENR3 Z2"and A32: "Z2 inTARSKIR2 X"
              using A30 tarski_def_4 sorry
            have "Z2 inTARSKIR2 Df0 * FINSEQ-1K14"
              using A5 A32 sorry
            then obtain q where 
              [ty]:"q be FinSequenceFINSEQ-1M3-of Df0" and qDef:"q = Z2"
              using finseq_1_def_11 sorry
            obtain Z1 where
              [ty]:"Z1 be setHIDDENM2" and 
              A33: "[TARSKIK4 x,y ] inHIDDENR3 Z1"and A34: "Z1 inTARSKIR2 X"
              using A29 tarski_def_4 sorry
            have "Z1 inTARSKIR2 Df0 * FINSEQ-1K14"
              using A5 A34 sorry
            then obtain p where 
              [ty]:"p be FinSequenceFINSEQ-1M3-of Df0" and pDef:"p = Z1"
              using finseq_1_def_11 sorry
            show "y =HIDDENR1 z"
            proof-
              have cases: "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p or lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
                 sorry
              have case1: "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p implies y =HIDDENR1 z"
              proof(rule impI)
                assume "lenFINSEQ-1K4 q <=XXREAL-0R1 lenFINSEQ-1K4 p"
                then have A35: "q c=RELAT-1R2 Z1"
                  using A6 A34 A32 sorry
                have "[TARSKIK4 x,y ] inHIDDENR3 p"
                  using A33 sorry
                thus "y =HIDDENR1 z"
                  using A31 A35 funct_1_def_1 sorry
              qed
              have case2: "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q implies y =HIDDENR1 z"
              proof(rule impI)
                assume "lenFINSEQ-1K4 p <=XXREAL-0R1 lenFINSEQ-1K4 q"
                then have "p c=RELAT-1R2 Z2"
                  using A6 A34 A32 sorry
                then have "[TARSKIK4 x,y ] inHIDDENR3 q"
                  using A33 sorry
                thus "y =HIDDENR1 z"
                  using A31 funct_1_def_1 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus "unionTARSKIK3 X be Function-likeFUNCT-1V1"
            using funct_1_def_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "?Y be Relation-likeRELAT-1V1"
      proof-
        have "unionTARSKIK3 X be Relation-likeRELAT-1V1"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 X implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ])"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?Y"
            then obtain Z2 where
              [ty]:"Z2 be setHIDDENM2" and 
              A36: "x inHIDDENR3 Z2"and A37: "Z2 inTARSKIR2 X"
              using tarski_def_4 sorry
            have " ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & ?P(p)) & Z2 =XBOOLE-0R4 p"
              using A4 A37 sorry
            then have "Z2 be Relation-likeRELAT-1V1"
               sorry
            thus " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]"
              using A36 sorry
          qed "sorry"
          thus "unionTARSKIK3 X be Relation-likeRELAT-1V1"
            using relat_1_def_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A38: "g =XBOOLE-0R4 ?Y"
        using A28 sorry
      have A39: " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 Df0"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 g"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A40: "y inHIDDENR3 domRELAT-1K1 g & x =HIDDENR1 g .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 ?Y"
          using A38 A40 funct_1_th_1 sorry
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A41: "[TARSKIK4 y,x ] inHIDDENR3 Z"and A42: "Z inTARSKIR2 X"
          using tarski_def_4 sorry
        have "Z inTARSKIR2 Df0 * FINSEQ-1K14"
          using A5 A42 sorry
        then obtain p where 
          [ty]:"p be FinSequenceFINSEQ-1M3-of Df0" and pDef:"p = Z"
          using finseq_1_def_11 sorry
        have "y inHIDDENR3 domFINSEQ-1K5 p & x =HIDDENR1 p .FUNCT-1K1 y"
          using A41 funct_1_th_1 sorry
        then have A43: "x inHIDDENR3 rngFUNCT-1K2 p"
          using funct_1_def_3 sorry
        have "rngFUNCT-1K2 p c=TARSKIR1 Df0"
          using finseq_1_def_4 sorry
        thus "x inHIDDENR3 Df0"
          using A43 sorry
      qed "sorry"
      then have "rngFUNCT-1K2 g c=TARSKIR1 Df0"
         sorry
      then obtain h where 
        [ty]:"h be FunctionFUNCT-2M1-of(domRELAT-1K1 g,Df0)" and hDef:"h = g"
        using funct_2_th_2 sorry
      have A44: " for n be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
      proof-
        have " for k be NatNAT-1M1 holds k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
        proof-
          let ?P = "\<lambda>Lamb1. Lamb1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
          have A45: " for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>) implies (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>)"
            then have "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M"
              using finseq_1_th_39 sorry
            then have "n +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_12 sorry
            thus "(<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
              using xreal_1_th_6 sorry
          qed "sorry"
          have "(<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 & <*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*> inTARSKIR2 Df0 * FINSEQ-1K14"
            using finseq_1_def_8 finseq_1_def_11 sorry
          then have "<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*> inTARSKIR2 X"
            using A4 A45 sorry
          then have A46: "{DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 omegaORDINAL1K4,Df0 :])\<^esub> [DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] } inTARSKIR2 X"
            using finseq_1_th_37 sorry
          have A47: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for k be NatNAT-1M1 holds k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h implies (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
            proof(rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
              then have "[TARSKIK4 k +NAT-1K1 \<one>\<^sub>M,h .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 ?Y"
                using A38 funct_1_th_1 sorry
              then obtain Z where
                [ty]:"Z be setHIDDENM2" and 
                A48: "[TARSKIK4 k +NAT-1K1 \<one>\<^sub>M,h .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Z"and A49: "Z inTARSKIR2 X"
                using tarski_def_4 sorry
              have "Z inTARSKIR2 Df0 * FINSEQ-1K14"
                using A5 A49 sorry
              then have 
                [ty]:"Z be FinSequenceFINSEQ-1M3-of Df0"
                using finseq_1_def_11 sorry
              have A50: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 Z implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
              proof-
                have "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 Z implies (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
                proof(rule impI)
                  let ?p = "Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)"
                  have A51: "\<one>\<^sub>M <=XXREAL-0R1 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                    using nat_1_th_12 sorry
                  assume A52: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 Z"
                  then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
                    using nat_1_th_12 sorry
                  then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
                    using finseq_1_th_1 sorry
                  then have A53: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
                    using finseq_1_def_3 sorry
                  have A54: " for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?p implies ?p .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                  proof-
                    have " for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)) implies (Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                    proof(rule ballI,rule impI)
                      fix n assume [ty]: "n be NatNAT-1M1"
                      assume "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?p"
                      then have A55: "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)"
                        using finseq_1_th_22 sorry
                      then have A56: "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z +NAT-1K1 \<one>\<^sub>M"
                        using finseq_1_th_40 sorry
                      have A57: "n +NAT-1K1 \<two>\<^sub>M <>HIDDENR2 lenFINSEQ-1K4 Z +NAT-1K1 \<one>\<^sub>M implies (Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                      proof(rule impI)
                        have "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z +NAT-1K1 \<one>\<^sub>M"
                          using A55 finseq_1_th_40 sorry
                        then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
                          using nat_1_th_12 xreal_1_th_6 sorry
                        then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
                          using finseq_1_th_1 sorry
                        then have A58: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
                          using finseq_1_def_3 sorry
                        have A59: "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
                          using nat_1_th_12 sorry
                        assume A60: "n +NAT-1K1 \<two>\<^sub>M <>HIDDENR2 lenFINSEQ-1K4 Z +NAT-1K1 \<one>\<^sub>M"
                        then have "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
                          using A56 nat_1_th_8 sorry
                        then have "n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
                          using A59 finseq_1_th_1 sorry
                        then have A61: "n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
                          using finseq_1_def_3 sorry
                        have " ex q be FinSequenceFINSEQ-1M1 st ((q inTARSKIR2 Df0 * FINSEQ-1K14 & q .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,q .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ])) & Z =FINSEQ-1R1 q"
                          using A4 A49 sorry
                        then have "Z .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,Z .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                          using A56 A60 nat_1_th_8 sorry
                        then have "?p .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,Z .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                          using A61 finseq_1_def_7 sorry
                        thus "(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                          using A58 finseq_1_def_7 sorry
                      qed
                      have "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 Z +NAT-1K1 \<one>\<^sub>M implies (Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                      proof(rule impI)
                        have "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z +NAT-1K1 \<one>\<^sub>M"
                          using A55 finseq_1_th_40 sorry
                        then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
                          using nat_1_th_12 xreal_1_th_6 sorry
                        then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
                          using finseq_1_th_1 sorry
                        then have A62: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
                          using finseq_1_def_3 sorry
                        assume A63: "n +NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 Z +NAT-1K1 \<one>\<^sub>M"
                        then have "?p .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>).FUNCT-1K1 ((n +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 ((n +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))"
                          using A55 finseq_1_th_23 sorry
                        also have "... = f .FUNCT-1K1 [TARSKIK4 n,Z .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                          using A52 A63 finseq_1_th_40 sorry
                        finally have "?p .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 [TARSKIK4 n,Z .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                           sorry
                        thus "(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                          using A62 finseq_1_def_7 sorry
                      qed
                      thus "(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
                        using A57 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  have A64: "?p inTARSKIR2 Df0 * FINSEQ-1K14"
                  proof-
                    have "Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>) inTARSKIR2 Df0 * FINSEQ-1K14"
                    proof-
                      have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                        using nat_1_th_12 sorry
                      then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
                        using A52 finseq_1_th_1 sorry
                      then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
                        using finseq_1_def_3 sorry
                      then have A65: "Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 Z"
                        using funct_1_def_3 sorry
                      have "rngFUNCT-1K2 Z c=TARSKIR1 Df0"
                        using finseq_1_def_4 sorry
                      then obtain z where 
                        [ty]:"z be ElementSUBSET-1M1-of Df0" and zDef:"z = Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
                        using A65 sorry
                      obtain n where 
                        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = k"
                        using ordinal1_def_12 sorry
                      have "?p =FINSEQ-1R1 Z ^FINSEQ-1K9\<^bsub>(Df0)\<^esub> (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> f .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 NATNUMBERSK1,Df0 :],Df0)\<^esub> [DOMAIN-1K1\<^bsub>(NATNUMBERSK1,Df0)\<^esub> n,z ]*>)"
                         sorry
                      thus "Z ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>) inTARSKIR2 Df0 * FINSEQ-1K14"
                        using finseq_1_def_11 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  have "lenFINSEQ-1K4 ?p =HIDDENR1 lenFINSEQ-1K4 Z +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 f .FUNCT-1K1 [TARSKIK4 k,Z .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) ]*>)"
                    using finseq_1_th_22 sorry
                  also have "... = (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                    using A52 finseq_1_th_39 sorry
                  finally have "lenFINSEQ-1K4 ?p =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                     sorry
                  then have "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?p)"
                    using A51 finseq_1_th_1 sorry
                  then have "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?p"
                    using finseq_1_def_3 sorry
                  then have A66: "[TARSKIK4 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,?p .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 ?p"
                    using funct_1_th_1 sorry
                  have " ex p be FinSequenceFINSEQ-1M1 st ((p inTARSKIR2 Df0 * FINSEQ-1K14 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ])) & Z =FINSEQ-1R1 p"
                    using A4 A49 sorry
                  then have "?p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0"
                    using A53 finseq_1_def_7 sorry
                  then have "?p inTARSKIR2 X"
                    using A4 A64 A54 sorry
                  then have "[TARSKIK4 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,?p .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 h"
                    using A38 A66 tarski_def_4 sorry
                  thus "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
                    using funct_1_th_1 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 lenFINSEQ-1K4 Z implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
              proof-
                have "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 lenFINSEQ-1K4 Z implies (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
                proof(rule impI)
                  have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
                    using A48 funct_1_th_1 sorry
                  then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
                    using finseq_1_def_3 sorry
                  then have A67: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
                    using finseq_1_th_1 sorry
                  assume "k +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 lenFINSEQ-1K4 Z"
                  then have "k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 Z"
                    using A67 xxreal_0_th_1 sorry
                  then have A68: "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
                    using nat_1_th_13 sorry
                  have "\<one>\<^sub>M <=XXREAL-0R1 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
                    using nat_1_th_12 sorry
                  then have "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
                    using A68 finseq_1_th_1 sorry
                  then have "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
                    using finseq_1_def_3 sorry
                  then have "[TARSKIK4 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,Z .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Z"
                    using funct_1_th_1 sorry
                  then have "[TARSKIK4 (k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,Z .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 h"
                    using A38 A49 tarski_def_4 sorry
                  thus "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
                    using funct_1_th_1 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "(k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
                using A50 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "[DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] inTARSKIR2 {DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 omegaORDINAL1K4,Df0 :])\<^esub> [DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] }"
            using tarski_def_1 sorry
          then have "[DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] inTARSKIR2 h"
            using A38 A46 tarski_def_4 sorry
          then have A69: "?P(0NUMBERSK6)"
            using funct_1_th_1 sorry
          show " for k be NatNAT-1M1 holds k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
            using nat_1_sch_2 A69 A47 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A70: " for n be NatNAT-1M1 holds h .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
      proof-
        have " for n be NatNAT-1M1 holds h .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 [TARSKIK4 n,h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
            using A44 sorry
          then have "[TARSKIK4 n +NAT-1K1 \<two>\<^sub>M,h .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) ] inHIDDENR3 h"
            using funct_1_def_2 sorry
          then obtain Z where
            [ty]:"Z be setHIDDENM2" and 
            A71: "[TARSKIK4 n +NAT-1K1 \<two>\<^sub>M,h .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) ] inHIDDENR3 Z"and A72: "Z inTARSKIR2 X"
            using A38 tarski_def_4 sorry
          have A73: " ex p be FinSequenceFINSEQ-1M1 st (p inTARSKIR2 Df0 * FINSEQ-1K14 & (p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]))) & Z =XBOOLE-0R4 p"
            using A4 A72 sorry
          have "Z inTARSKIR2 Df0 * FINSEQ-1K14"
            using A5 A72 sorry
          then have 
            [ty]:"Z be FinSequenceFINSEQ-1M3-of Df0"
            using finseq_1_def_11 sorry
          have "n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
            using A71 funct_1_th_1 sorry
          then have "n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
            using finseq_1_def_3 sorry
          then have A74: "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
            using finseq_1_th_1 sorry
          have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<two>\<^sub>M"
            using xreal_1_th_7 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 Z"
            using A74 nat_1_th_12 xxreal_0_th_2 sorry
          then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 Z)"
            using finseq_1_th_1 sorry
          then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 Z"
            using finseq_1_def_3 sorry
          then have "[TARSKIK4 n +NAT-1K1 \<one>\<^sub>M,Z .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 Z"
            using funct_1_th_1 sorry
          then have A75: "[TARSKIK4 n +NAT-1K1 \<one>\<^sub>M,Z .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ] inHIDDENR3 h"
            using A38 A72 tarski_def_4 sorry
          have "h .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Z .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M)"
            using A71 funct_1_th_1 sorry
          also have "... = f .FUNCT-1K1 [TARSKIK4 n,Z .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
            using A73 A74 sorry
          also have "... = f .FUNCT-1K1 [TARSKIK4 n,h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
            using A75 funct_1_th_1 sorry
          finally show "h .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 [TARSKIK4 n,h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be NatNAT-1M1 st n =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      have A76: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex tVar20 be objectHIDDENM1 st  ex tVar21 be NatNAT-1M1 st tVar21 =HIDDENR1 x & h .FUNCT-1K1 (tVar21 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 (tVar21 +NAT-1K1 \<one>\<^sub>M))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 NATNUMBERSK1"
          then obtain n where 
            [ty]:"n be NatNAT-1M1" and nDef:"n = x"
             sorry
          show " ex tVar20 be objectHIDDENM1 st  ex tVar21 be NatNAT-1M1 st tVar21 =HIDDENR1 x & h .FUNCT-1K1 (tVar21 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 (tVar21 +NAT-1K1 \<one>\<^sub>M)"
          proof(rule bexI[of _ "h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"])
            show " ex tVar21 be NatNAT-1M1 st tVar21 =HIDDENR1 x & h .FUNCT-1K1 (tVar21 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 (tVar21 +NAT-1K1 \<one>\<^sub>M)"
            proof(rule bexI[of _ "n"])
              show "n =HIDDENR1 x & h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A77: "domRELAT-1K1 g =XBOOLE-0R4 NATNUMBERSK1 & ( for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,g .FUNCT-1K1 x))"
        using classes1_sch_1 A76 sorry
      have A78: "domRELAT-1K1 g =XBOOLE-0R4 NATNUMBERSK1"
        using A77 sorry
      have A79: " for n be NatNAT-1M1 holds g .FUNCT-1K1 n =XBOOLE-0R4 h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have " ex m be NatNAT-1M1 st m =XBOOLE-0R4 n & g .FUNCT-1K1 n =XBOOLE-0R4 h .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
          using A77 sorry
        thus "g .FUNCT-1K1 n =XBOOLE-0R4 h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      have "rngFUNCT-1K2 g c=TARSKIR1 Df0"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 Df0"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 g"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A80: "y inHIDDENR3 domRELAT-1K1 g"and A81: "x =HIDDENR1 g .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          obtain k where 
            [ty]:"k be NatNAT-1M1" and kDef:"k = y"
            using A78 A80 sorry
          have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELAT-1K1 h"
            using A44 sorry
          then have A82: "h .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 h"
            using funct_1_def_3 sorry
          have "x =HIDDENR1 h .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
            using A79 A81 sorry
          thus "x inHIDDENR3 Df0"
            using A39 A82 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 g c=TARSKIR1 Df0"
          using tarski_def_3 sorry
      qed
      then have 
        [ty]:"g be sequenceNAT-1M2-of Df0"
        using A78 funct_2_th_2 sorry
      have A83: " for n be NatNAT-1M1 holds g .FUNCT-1K1 n =XBOOLE-0R4 h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        using A79 sorry
      have A84: " for n be NatNAT-1M1 holds n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>) implies (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>)"
        then have "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_39 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
          using xreal_1_th_6 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 n"
           sorry
        thus "(<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 [TARSKIK4 n,(<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) ]"
          using xreal_1_th_6 sorry
      qed "sorry"
      have "<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*> inTARSKIR2 Df0 * FINSEQ-1K14 & (<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0"
        using finseq_1_def_8 finseq_1_def_11 sorry
      then have "<*FINSEQ-1K13\<^bsub>(Df0)\<^esub> Af0*> inTARSKIR2 X"
        using A4 A84 sorry
      then have A85: "{DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 omegaORDINAL1K4,Df0 :])\<^esub> [DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] } inTARSKIR2 X"
        using finseq_1_th_37 sorry
      show " ex tVar22 be sequenceNAT-1M2-of Df0 st tVar22 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds Pp3(n,tVar22 .FUNCT-1K1 n,tVar22 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      proof(rule bexI[of _ "g"],rule conjMI,rule ballI)
        have "[DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] inTARSKIR2 {DOMAIN-1K6\<^bsub>([:ZFMISC-1K2 omegaORDINAL1K4,Df0 :])\<^esub> [DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] }"
          using tarski_def_1 sorry
        then have "[DOMAIN-1K1\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> \<one>\<^sub>M,Af0 ] inTARSKIR2 h"
          using A38 A85 tarski_def_4 sorry
        then have "Af0 =HIDDENR1 h .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
          using funct_1_th_1 sorry
        also have "... = g .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6)"
          using A83 sorry
        finally have "Af0 =HIDDENR1 g .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6)"
           sorry
        thus "g .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"
           sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        have A86: "h .FUNCT-1K1 (n +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 f .BINOP-1K1(n,h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          using A70 sorry
        have A87: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "g .FUNCT-1K1 n inTARSKIR2 Df0"
          using funct_2_th_5 sorry
        then have "Pp3(n,g .FUNCT-1K1 n,f .BINOP-1K1(n,g .FUNCT-1K1 n))"
          using A3 A87 sorry
        then have "Pp3(n,g .FUNCT-1K1 n,h .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using A83 A86 sorry
        thus "Pp3(n,g .FUNCT-1K1 n,g .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using A83 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mlemma recdef_1_lm_2:
"\<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
  using numbers_th_19 sorry

theorem recdef_1_sch_3:
  fixes Af0 Nf0 Pp3 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Nf0 be NatNAT-1M1" and
   A1: " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies ( for x be setHIDDENM2 holds  ex y be setHIDDENM2 st Pp3(n,x,y))"
  shows " ex p be FinSequenceFINSEQ-1M1 st (lenFINSEQ-1K4 p =XBOOLE-0R4 Nf0 & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,p .FUNCT-1K1 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " ex tVar25 be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 tVar25 =XBOOLE-0R4 Nf0 & ((tVar25 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,tVar25 .FUNCT-1K1 n,tVar25 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. (Lamb1 <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(Lamb1 +NAT-1K1 \<one>\<^sub>M,Lamb2,Lamb3)) & ( not Lamb1 <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Lamb3 =XBOOLE-0R4 0NUMBERSK6)"
      have A2: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex y be setHIDDENM2 st ?Q(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  not ( for y be setHIDDENM2 holds  not ((n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)) & ( not n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies y =XBOOLE-0R4 0NUMBERSK6)))"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be setHIDDENM2"
          have "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies  not ( for y be setHIDDENM2 holds  not ?Q(n,x,y))"
          proof-
            have "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies ( ex tVar23 be setHIDDENM2 st (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,tVar23)) &  not (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M &  not tVar23 =XBOOLE-0R4 0NUMBERSK6))"
            proof(rule impI)
              assume A3: "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M"
              then have "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 Nf0"
                using xreal_1_th_20 sorry
              then obtain y where
                [ty]:"y be setHIDDENM2" and 
                A4: "Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)"
                using A1 nat_1_th_11 sorry
              show " ex tVar23 be setHIDDENM2 st (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,tVar23)) &  not (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M &  not tVar23 =XBOOLE-0R4 0NUMBERSK6)"
              proof(rule bexI[of _ "y"],rule conjMI)
                show "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)"
                  using A4 sorry
                show " not (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M &  not y =XBOOLE-0R4 0NUMBERSK6)"
                  using A3 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          thus " not ( for y be setHIDDENM2 holds  not ((n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)) & ( not n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies y =XBOOLE-0R4 0NUMBERSK6)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A5: "(domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_1 A2 sorry
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  for r be RealXREAL-0M1 holds r =HIDDENR1 Lamb1 implies Lamb2 =HIDDENR1 f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M)"
      have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ( ex tVar24 be objectHIDDENM1 st  for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies tVar24 =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 REALNUMBERSK2"
          then obtain r where 
            [ty]:"r be RealXREAL-0M1" and rDef:"r = x"
             sorry
          show " ex tVar24 be objectHIDDENM1 st  for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies tVar24 =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M)"
          proof(rule bexI[of _ "f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M)"])
            show " for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A7: "domRELAT-1K1 g =XBOOLE-0R4 REALNUMBERSK2 & ( for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ?Q(x,g .FUNCT-1K1 x))"
        using classes1_sch_1 A6 sorry
      have "SegFINSEQ-1K2 Nf0 c=TARSKIR1 REALNUMBERSK2"
        using numbers_th_19 sorry
      then have A8: "domRELAT-1K1 (g  |RELAT-1K8 SegFINSEQ-1K2 Nf0) =XBOOLE-0R4 SegFINSEQ-1K2 Nf0"
        using A7 relat_1_th_62 sorry
      then obtain p where 
        [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = g  |RELAT-1K8 SegFINSEQ-1K2 Nf0"
        using finseq_1_def_2 sorry
      show " ex tVar25 be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 tVar25 =XBOOLE-0R4 Nf0 & ((tVar25 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,tVar25 .FUNCT-1K1 n,tVar25 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
      proof(rule bexI[of _ "p"],rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
        have "Nf0 inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus "lenFINSEQ-1K4 p =XBOOLE-0R4 Nf0"
          using A8 finseq_1_def_3 sorry
        have "Nf0 <>HIDDENR2 0NUMBERSK6 implies p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6"
        proof-
          have "Nf0 <>HIDDENR2 0NUMBERSK6 implies  not ( not p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 &  not Nf0 =XBOOLE-0R4 0NUMBERSK6)"
          proof(rule impI)
            assume "Nf0 <>HIDDENR2 0NUMBERSK6"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A9: "Nf0 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_6 sorry
            have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_7 sorry
            then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 Nf0"
              using A9 finseq_1_th_1 sorry
            then have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 g .FUNCT-1K1 \<one>\<^sub>M"
              using funct_1_th_49 sorry
            also have "... = f .FUNCT-1K1 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
              using A7 recdef_1_lm_2 sorry
            also have "... = Af0"
              using A5 sorry
            finally have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0"
               sorry
            thus " not ( not p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 &  not Nf0 =XBOOLE-0R4 0NUMBERSK6)"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A10: "\<one>\<^sub>M <=XXREAL-0R1 n"
          and A11: "n <XXREAL-0R3 Nf0"
        have "0NUMBERSK6 <>HIDDENR2 n"
          using A10 sorry
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A12: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        have A13: " for n be NatNAT-1M1 holds n <XXREAL-0R3 Nf0 implies p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n <XXREAL-0R3 Nf0"
          then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 Nf0"
            using nat_1_th_11 nat_1_th_13 sorry
          then have A14: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 Nf0"
            using finseq_1_th_1 sorry
          have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
            using A7 sorry
          also have "... = f .FUNCT-1K1 n"
             sorry
          finally have "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 n"
             sorry
          thus "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 n"
            using A14 funct_1_th_49 sorry
        qed "sorry"
        have 
          [ty]:"k be NatNAT-1M1"
           sorry
        have "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have A15: "k <XXREAL-0R3 Nf0"
          using A11 A12 xxreal_0_th_2 sorry
        have "k <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M"
          using A11 A12 xreal_1_th_20 sorry
        then have "Pp3(k +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 k,f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
          using A5 sorry
        then have "Pp3(k +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 k,p .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using A13 A11 A12 sorry
        thus "Pp3(n,p .FUNCT-1K1 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          using A13 A12 A15 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_4:
  fixes Df0 Af0 Nf0 Pp3 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Nf0 be NatNAT-1M1" and
   A1: " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies ( for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st Pp3(n,x,y))"
  shows " ex p be FinSequenceFINSEQ-1M3-of Df0 st (lenFINSEQ-1K4 p =XBOOLE-0R4 Nf0 & (p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,p .FUNCT-1K1 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " ex tVar28 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar28 =XBOOLE-0R4 Nf0 & ((tVar28 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,tVar28 .FUNCT-1K1 n,tVar28 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
    proof-
      let ?ZZ = "the ElementSUBSET-1M1-of Df0"
      let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. (Lamb1 <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(Lamb1 +NAT-1K1 \<one>\<^sub>M,Lamb2,Lamb3)) & ( not Lamb1 <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Lamb3 =XBOOLE-0R4 ?ZZ)"
      have A2: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st ?Z(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  not ( for y be ElementSUBSET-1M1-of Df0 holds  not ((n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)) & ( not n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies y =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)))"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of Df0"
          have "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies  not ( for y be ElementSUBSET-1M1-of Df0 holds  not ?Z(n,x,y))"
          proof-
            have "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies ( ex tVar26 be ElementSUBSET-1M1-of Df0 st (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,tVar26)) &  not (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M &  not tVar26 =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0))"
            proof(rule impI)
              assume A3: "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M"
              then have "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 Nf0"
                using xreal_1_th_20 sorry
              then obtain y where
                [ty]:"y be ElementSUBSET-1M1-of Df0" and 
                A4: "Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)"
                using A1 nat_1_th_11 sorry
              show " ex tVar26 be ElementSUBSET-1M1-of Df0 st (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,tVar26)) &  not (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M &  not tVar26 =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)"
              proof(rule bexI[of _ "y"],rule conjMI)
                show "n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)"
                  using A4 sorry
                show " not (n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M &  not y =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)"
                  using A3 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          thus " not ( for y be ElementSUBSET-1M1-of Df0 holds  not ((n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)) & ( not n <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies y =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of Df0" and 
        A5: "f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds ?Z(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_2 A2 sorry
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for r be RealXREAL-0M1 holds r =HIDDENR1 Lamb1 implies Lamb2 =HIDDENR1 f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M)"
      have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ( ex tVar27 be objectHIDDENM1 st  for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies tVar27 =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 REALNUMBERSK2"
          then obtain r where 
            [ty]:"r be RealXREAL-0M1" and rDef:"r = x"
             sorry
          show " ex tVar27 be objectHIDDENM1 st  for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies tVar27 =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M)"
          proof(rule bexI[of _ "f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M)"])
            show " for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A7: "domRELAT-1K1 g =XBOOLE-0R4 REALNUMBERSK2 & ( for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ?P(x,g .FUNCT-1K1 x))"
        using classes1_sch_1 A6 sorry
      have "SegFINSEQ-1K2 Nf0 c=TARSKIR1 REALNUMBERSK2"
        using numbers_th_19 sorry
      then have A8: "domRELAT-1K1 (g  |RELAT-1K8 SegFINSEQ-1K2 Nf0) =XBOOLE-0R4 SegFINSEQ-1K2 Nf0"
        using A7 relat_1_th_62 sorry
      then obtain p where 
        [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = g  |RELAT-1K8 SegFINSEQ-1K2 Nf0"
        using finseq_1_def_2 sorry
      have "rngFUNCT-1K2 p c=TARSKIR1 Df0"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x inHIDDENR3 Df0"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 p"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A9: "y inHIDDENR3 domFINSEQ-1K5 p"and A10: "x =HIDDENR1 p .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have 
            [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A9 sorry
          have A11: "f .FUNCT-1K1 (y -XCMPLX-0K6 \<one>\<^sub>M) inTARSKIR2 Df0"
          proof-
            have "y <>HIDDENR2 0NUMBERSK6"
              using A8 A9 finseq_1_th_1 sorry
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A12: "y =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_6 sorry
            have 
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> k inTARSKIR2 Df0"
               sorry
            thus "f .FUNCT-1K1 (y -XCMPLX-0K6 \<one>\<^sub>M) inTARSKIR2 Df0"
              using A12 sorry
          qed
          have A13: "y inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          have "p .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
            using A9 funct_1_th_47 sorry
          thus "x inHIDDENR3 Df0"
            using A7 A10 A11 A13 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 p c=TARSKIR1 Df0"
          using tarski_def_3 sorry
      qed
      then have 
        [ty]:"p be FinSequenceFINSEQ-1M3-of Df0"
        using finseq_1_def_4 sorry
      show " ex tVar28 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar28 =XBOOLE-0R4 Nf0 & ((tVar28 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,tVar28 .FUNCT-1K1 n,tVar28 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
      proof(rule bexI[of _ "p"],rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
        have "Nf0 inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus "lenFINSEQ-1K4 p =XBOOLE-0R4 Nf0"
          using A8 finseq_1_def_3 sorry
        have "Nf0 <>HIDDENR2 0NUMBERSK6 implies p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6"
        proof-
          have "Nf0 <>HIDDENR2 0NUMBERSK6 implies  not ( not p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 &  not Nf0 =XBOOLE-0R4 0NUMBERSK6)"
          proof(rule impI)
            assume "Nf0 <>HIDDENR2 0NUMBERSK6"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A14: "Nf0 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_6 sorry
            have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_7 sorry
            then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 Nf0"
              using A14 finseq_1_th_1 sorry
            then have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 g .FUNCT-1K1 \<one>\<^sub>M"
              using funct_1_th_49 sorry
            also have "... = f .FUNCT-1K1 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
              using A7 recdef_1_lm_2 sorry
            also have "... = Af0"
              using A5 sorry
            finally have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0"
               sorry
            thus " not ( not p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 &  not Nf0 =XBOOLE-0R4 0NUMBERSK6)"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A15: "\<one>\<^sub>M <=XXREAL-0R1 n"
          and A16: "n <XXREAL-0R3 Nf0"
        have "0NUMBERSK6 <>HIDDENR2 n"
          using A15 sorry
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A17: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_6 sorry
        have A18: " for n be NatNAT-1M1 holds n <XXREAL-0R3 Nf0 implies p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n <XXREAL-0R3 Nf0"
          then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 Nf0"
            using nat_1_th_11 nat_1_th_13 sorry
          then have A19: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 Nf0"
            using finseq_1_th_1 sorry
          have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
            using A7 sorry
          also have "... = f .FUNCT-1K1 n"
             sorry
          finally have "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 n"
             sorry
          thus "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 n"
            using A19 funct_1_th_49 sorry
        qed "sorry"
        have 
          [ty]:"k be NatNAT-1M1"
           sorry
        have "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have A20: "k <XXREAL-0R3 Nf0"
          using A16 A17 xxreal_0_th_2 sorry
        have "k <XXREAL-0R3 Nf0 -XCMPLX-0K6 \<one>\<^sub>M"
          using A16 A17 xreal_1_th_20 sorry
        then have "Pp3(k +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 k,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using A5 sorry
        then have "Pp3(k +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 k,p .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using A18 A16 A17 sorry
        thus "Pp3(n,p .FUNCT-1K1 n,p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
          using A18 A17 A20 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_5:
  fixes Sf0 Pp3 
  assumes
[ty]: "Sf0 be FinSequenceFINSEQ-1M1" and
   A1: " for k be NatNAT-1M1 holds  for x be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ( ex y be setHIDDENM2 st Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),x,y))"
  shows " ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " not ( for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds  not (((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) &  not Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Pp3(Sf0 .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M),Lamb2,Lamb3)"
      have A2: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ( for x be setHIDDENM2 holds  ex y be setHIDDENM2 st ?Q(k,x,y))"
        using A1 sorry
      obtain p where
        [ty]:"p be FinSequenceFINSEQ-1M1" and 
        A3: "(lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0 & (p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M or lenFINSEQ-1K4 Sf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_3 A2 sorry
      have A4: "lenFINSEQ-1K4 Sf0 <>HIDDENR2 0NUMBERSK6 implies  not ( for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds  not (((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) &  not Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))))"
      proof-
        have "lenFINSEQ-1K4 Sf0 <>HIDDENR2 0NUMBERSK6 implies ( ex tVar29 be setHIDDENM2 st  ex tVar30 be FinSequenceFINSEQ-1M1 st ((tVar30 .FUNCT-1K1 lenFINSEQ-1K4 tVar30 =XBOOLE-0R4 tVar30 .FUNCT-1K1 lenFINSEQ-1K4 tVar30 & lenFINSEQ-1K4 tVar30 =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & tVar30 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar30 .FUNCT-1K1 k,tVar30 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))"
        proof(rule impI)
          assume A5: "lenFINSEQ-1K4 Sf0 <>HIDDENR2 0NUMBERSK6"
          show " ex tVar29 be setHIDDENM2 st  ex tVar30 be FinSequenceFINSEQ-1M1 st ((tVar30 .FUNCT-1K1 lenFINSEQ-1K4 tVar30 =XBOOLE-0R4 tVar30 .FUNCT-1K1 lenFINSEQ-1K4 tVar30 & lenFINSEQ-1K4 tVar30 =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & tVar30 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar30 .FUNCT-1K1 k,tVar30 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
          proof(rule bexI[of _ "p .FUNCT-1K1 lenFINSEQ-1K4 p"])
            show " ex tVar30 be FinSequenceFINSEQ-1M1 st ((tVar30 .FUNCT-1K1 lenFINSEQ-1K4 tVar30 =XBOOLE-0R4 tVar30 .FUNCT-1K1 lenFINSEQ-1K4 tVar30 & lenFINSEQ-1K4 tVar30 =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & tVar30 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar30 .FUNCT-1K1 k,tVar30 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
            proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule impI)
              show "(p .FUNCT-1K1 lenFINSEQ-1K4 p =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M"
                using A3 A5 sorry
              fix k assume [ty]: "k be NatNAT-1M1"
              assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0"
              thus "Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                using A3 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      have "lenFINSEQ-1K4 Sf0 =XBOOLE-0R4 0NUMBERSK6 implies  not ( for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds  not (((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) &  not Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))))"
      proof-
        have "lenFINSEQ-1K4 Sf0 =XBOOLE-0R4 0NUMBERSK6 implies ( ex tVar31 be setHIDDENM2 st  ex tVar32 be FinSequenceFINSEQ-1M1 st ((tVar32 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 tVar32 .FUNCT-1K1 lenFINSEQ-1K4 tVar32 & lenFINSEQ-1K4 tVar32 =XBOOLE-0R4 lenFINSEQ-1K4 tVar32) & tVar32 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 tVar32 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 tVar32) &  not Pp3(tVar32 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar32 .FUNCT-1K1 k,tVar32 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))))"
        proof(rule impI)
          assume A6: "lenFINSEQ-1K4 Sf0 =XBOOLE-0R4 0NUMBERSK6"
          show " ex tVar31 be setHIDDENM2 st  ex tVar32 be FinSequenceFINSEQ-1M1 st ((tVar32 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 tVar32 .FUNCT-1K1 lenFINSEQ-1K4 tVar32 & lenFINSEQ-1K4 tVar32 =XBOOLE-0R4 lenFINSEQ-1K4 tVar32) & tVar32 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 tVar32 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 tVar32) &  not Pp3(tVar32 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar32 .FUNCT-1K1 k,tVar32 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))"
          proof(rule bexI[of _ "Sf0 .FUNCT-1K1 (0NUMBERSK6)"])
            show " ex tVar32 be FinSequenceFINSEQ-1M1 st ((tVar32 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 tVar32 .FUNCT-1K1 lenFINSEQ-1K4 tVar32 & lenFINSEQ-1K4 tVar32 =XBOOLE-0R4 lenFINSEQ-1K4 tVar32) & tVar32 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 tVar32 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 tVar32) &  not Pp3(tVar32 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar32 .FUNCT-1K1 k,tVar32 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))"
            proof(rule bexI[of _ "Sf0"],rule conjMI)
              show "(Sf0 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Sf0 .FUNCT-1K1 lenFINSEQ-1K4 Sf0 & lenFINSEQ-1K4 Sf0 =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & Sf0 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M"
                using A6 sorry
              show " for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) &  not Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),Sf0 .FUNCT-1K1 k,Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
                using A6 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not ( for x be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M1 holds  not (((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 k &  not k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) &  not Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))))))"
        using A4 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_6:
  fixes Sf0 Ff2 
  assumes
[ty]: "Sf0 be FinSequenceFINSEQ-1M1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be setHIDDENM2"
  shows " ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))"
  proof-
    have " ex tVar33 be setHIDDENM2 st  ex tVar34 be FinSequenceFINSEQ-1M1 st ((tVar33 =XBOOLE-0R4 tVar34 .FUNCT-1K1 lenFINSEQ-1K4 tVar34 & lenFINSEQ-1K4 tVar34 =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & tVar34 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies tVar34 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar34 .FUNCT-1K1 k))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
      have A1: " for k be NatNAT-1M1 holds  for x be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ( ex y be setHIDDENM2 st ?P(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),x,y))"
         sorry
      obtain x where
        [ty]:"x be setHIDDENM2" and 
        A2: " ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?P(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_5 A1 sorry
      show " ex tVar33 be setHIDDENM2 st  ex tVar34 be FinSequenceFINSEQ-1M1 st ((tVar33 =XBOOLE-0R4 tVar34 .FUNCT-1K1 lenFINSEQ-1K4 tVar34 & lenFINSEQ-1K4 tVar34 =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & tVar34 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies tVar34 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar34 .FUNCT-1K1 k))"
      proof(rule bexI[of _ "x"])
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M1" and 
          A3: "(x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M"and A4: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k)"
          using A2 sorry
        show " ex tVar34 be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 tVar34 .FUNCT-1K1 lenFINSEQ-1K4 tVar34 & lenFINSEQ-1K4 tVar34 =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & tVar34 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies tVar34 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),tVar34 .FUNCT-1K1 k))"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule impI)
          show "(x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M"
            using A3 sorry
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0"
          thus "p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k)"
            using A4 sorry
        qed "sorry"
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_7:
  fixes Af0 Nf0 Ff0 Gf0 Pp3 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Nf0 be NatNAT-1M1" and
  [ty]: "Ff0 be FinSequenceFINSEQ-1M1" and
  [ty]: "Gf0 be FinSequenceFINSEQ-1M1" and
   A1: " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies ( for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2)" and
   A2: "(lenFINSEQ-1K4 Ff0 =XBOOLE-0R4 Nf0 & (Ff0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))" and
   A3: "(lenFINSEQ-1K4 Gf0 =XBOOLE-0R4 Nf0 & (Gf0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
  shows "Ff0 =FINSEQ-1R1 Gf0"
  proof-
    have "Ff0 <>HIDDENR2 Gf0 implies  False "
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. (\<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 Nf0) & Ff0 .FUNCT-1K1 Lamb1 <>HIDDENR2 Gf0 .FUNCT-1K1 Lamb1"
      assume A4: "Ff0 <>HIDDENR2 Gf0"
      have "domFINSEQ-1K5 Ff0 =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 Gf0)"
        using A2 A3 finseq_1_def_3 sorry
      also have "... = domFINSEQ-1K5 Gf0"
        using finseq_1_def_3 sorry
      finally have "domFINSEQ-1K5 Ff0 =HIDDENR1 domFINSEQ-1K5 Gf0"
         sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "x inHIDDENR3 domFINSEQ-1K5 Ff0"and A6: "Ff0 .FUNCT-1K1 x <>HIDDENR2 Gf0 .FUNCT-1K1 x"
        using A4 sorry
      have A7: "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 Ff0)"
        using A5 finseq_1_def_3 sorry
      have 
        [ty]:"x be NatNAT-1M1"
        using A5 sorry
      have A8: "\<one>\<^sub>M <=XXREAL-0R1 x"
        using A7 finseq_1_th_1 sorry
      have "x <=XXREAL-0R1 Nf0"
        using A2 A7 finseq_1_th_1 sorry
      then have A9: " ex n be NatNAT-1M1 st ?P(n)"
        using A6 A8 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A10: "?P(n) & ( for k be NatNAT-1M1 holds ?P(k) implies n <=XXREAL-0R1 k)"
        using nat_1_sch_5 A9 sorry
      have "0NUMBERSK6 <>HIDDENR2 n"
        using A10 sorry
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A11: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_6 sorry
      have 
        [ty]:"k be NatNAT-1M1"
         sorry
      have "n <>HIDDENR2 \<one>\<^sub>M"
        using A2 A3 A10 sorry
      then have "\<one>\<^sub>M <XXREAL-0R3 n"
        using A10 xxreal_0_th_1 sorry
      then have A12: "\<one>\<^sub>M <=XXREAL-0R1 k"
        using A11 nat_1_th_13 sorry
      have "k <XXREAL-0R3 n"
        using A11 xreal_1_th_29 sorry
      then have A13: "k <XXREAL-0R3 Nf0"
        using A10 xxreal_0_th_2 sorry
      have "n >XXREAL-0R4 k"
        using A11 nat_1_th_13 sorry
      then have "Ff0 .FUNCT-1K1 k =XBOOLE-0R4 Gf0 .FUNCT-1K1 k"
        using A10 A12 A13 sorry
      then have A14: "Pp3(k,Ff0 .FUNCT-1K1 k,Gf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
        using A3 A12 A13 sorry
      have "Pp3(k,Ff0 .FUNCT-1K1 k,Ff0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
        using A2 A12 A13 sorry
      thus " False "
        using A1 A10 A11 A12 A13 A14 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_8:
  fixes Df0 Af0 Nf0 Ff0 Gf0 Pp3 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Nf0 be NatNAT-1M1" and
  [ty]: "Ff0 be FinSequenceFINSEQ-1M3-of Df0" and
  [ty]: "Gf0 be FinSequenceFINSEQ-1M3-of Df0" and
   A1: " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies ( for x be ElementSUBSET-1M1-of Df0 holds  for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2)" and
   A2: "(lenFINSEQ-1K4 Ff0 =XBOOLE-0R4 Nf0 & (Ff0 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))" and
   A3: "(lenFINSEQ-1K4 Gf0 =XBOOLE-0R4 Nf0 & (Gf0 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 Nf0 implies Pp3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
  shows "Ff0 =FINSEQ-1R1 Gf0"
  proof-
    have "Ff0 <>HIDDENR2 Gf0 implies  False "
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. (\<one>\<^sub>M <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 Nf0) & Ff0 .FUNCT-1K1 Lamb1 <>HIDDENR2 Gf0 .FUNCT-1K1 Lamb1"
      assume A4: "Ff0 <>HIDDENR2 Gf0"
      have "domFINSEQ-1K5 Ff0 =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 Gf0)"
        using A2 A3 finseq_1_def_3 sorry
      also have "... = domFINSEQ-1K5 Gf0"
        using finseq_1_def_3 sorry
      finally have "domFINSEQ-1K5 Ff0 =HIDDENR1 domFINSEQ-1K5 Gf0"
         sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "x inHIDDENR3 domFINSEQ-1K5 Ff0"and A6: "Ff0 .FUNCT-1K1 x <>HIDDENR2 Gf0 .FUNCT-1K1 x"
        using A4 sorry
      have A7: "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 Ff0)"
        using A5 finseq_1_def_3 sorry
      have 
        [ty]:"x be NatNAT-1M1"
        using A5 sorry
      have A8: "\<one>\<^sub>M <=XXREAL-0R1 x"
        using A7 finseq_1_th_1 sorry
      have "x <=XXREAL-0R1 Nf0"
        using A2 A7 finseq_1_th_1 sorry
      then have A9: " ex n be NatNAT-1M1 st ?P(n)"
        using A6 A8 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A10: "?P(n) & ( for k be NatNAT-1M1 holds ?P(k) implies n <=XXREAL-0R1 k)"
        using nat_1_sch_5 A9 sorry
      have "0NUMBERSK6 <>HIDDENR2 n"
        using A10 sorry
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A11: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_6 sorry
      have 
        [ty]:"k be NatNAT-1M1"
         sorry
      obtain Gk1 where 
        [ty]:"Gk1 be ElementSUBSET-1M1-of Df0" and Gk1Def:"Gk1 = Gf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        using A3 A10 A11 recdef_1_lm_1 sorry
      have "n <>HIDDENR2 \<one>\<^sub>M"
        using A2 A3 A10 sorry
      then have "\<one>\<^sub>M <XXREAL-0R3 n"
        using A10 xxreal_0_th_1 sorry
      then have A12: "\<one>\<^sub>M <=XXREAL-0R1 k"
        using A11 nat_1_th_13 sorry
      have "k <XXREAL-0R3 n"
        using A11 xreal_1_th_29 sorry
      then have A13: "k <XXREAL-0R3 Nf0"
        using A10 xxreal_0_th_2 sorry
      then obtain Fk where 
        [ty]:"Fk be ElementSUBSET-1M1-of Df0" and FkDef:"Fk = Ff0 .FUNCT-1K1 k"
        using A2 A12 recdef_1_lm_1 sorry
      have "n >XXREAL-0R4 k"
        using A11 nat_1_th_13 sorry
      then have "Ff0 .FUNCT-1K1 k =XBOOLE-0R4 Gf0 .FUNCT-1K1 k"
        using A10 A12 A13 sorry
      then have A14: "Pp3(k,Fk,Gk1)"
        using A3 A12 A13 sorry
      obtain Fk1 where 
        [ty]:"Fk1 be ElementSUBSET-1M1-of Df0" and Fk1Def:"Fk1 = Ff0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        using A2 A10 A11 recdef_1_lm_1 sorry
      have "Pp3(k,Fk,Fk1)"
        using A2 A12 A13 sorry
      thus " False "
        using A1 A10 A11 A12 A13 A14 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_9:
  fixes Sf0 xf0 yf0 Pp3 
  assumes
[ty]: "Sf0 be FinSequenceFINSEQ-1M1" and
  [ty]: "xf0 be objectHIDDENM1" and
  [ty]: "yf0 be objectHIDDENM1" and
   A1: " for k be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds  for z be setHIDDENM2 holds (((\<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) & z =XBOOLE-0R4 Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Pp3(z,x,y1)) & Pp3(z,x,y2) implies y1 =XBOOLE-0R4 y2" and
   A2: " ex p be FinSequenceFINSEQ-1M1 st ((xf0 =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))" and
   A3: " ex p be FinSequenceFINSEQ-1M1 st ((yf0 =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
  shows "xf0 =HIDDENR1 yf0"
  proof-
    let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Pp3(Sf0 .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M),Lamb2,Lamb3)"
    have A4: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ( for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ?Q(k,x,y1) & ?Q(k,x,y2) implies y1 =XBOOLE-0R4 y2)"
      using A1 sorry
    obtain q where
      [ty]:"q be FinSequenceFINSEQ-1M1" and 
      A5: "yf0 =HIDDENR1 q .FUNCT-1K1 lenFINSEQ-1K4 q"and A6: "(lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 Sf0 & q .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?Q(k,q .FUNCT-1K1 k,q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      using A3 sorry
    have A7: "(lenFINSEQ-1K4 q =XBOOLE-0R4 lenFINSEQ-1K4 Sf0 & (q .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M or lenFINSEQ-1K4 Sf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?Q(k,q .FUNCT-1K1 k,q .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      using A6 sorry
    obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M1" and 
      A8: "xf0 =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p"and A9: "(lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      using A2 sorry
    have A10: "(lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0 & (p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M or lenFINSEQ-1K4 Sf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?Q(k,p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      using A9 sorry
    have "p =FINSEQ-1R1 q"
      using recdef_1_sch_7 A4 A10 A7 sorry
    thus "xf0 =HIDDENR1 yf0"
      using A8 A5 sorry
  qed

theorem recdef_1_sch_10:
  fixes Sf0 Ff2 xf0 yf0 
  assumes
[ty]: "Sf0 be FinSequenceFINSEQ-1M1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
  [ty]: "xf0 be objectHIDDENM1" and
  [ty]: "yf0 be objectHIDDENM1" and
   A1: " ex p be FinSequenceFINSEQ-1M1 st ((xf0 =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))" and
   A2: " ex p be FinSequenceFINSEQ-1M1 st ((yf0 =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))"
  shows "xf0 =HIDDENR1 yf0"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
    have A3: " ex p be FinSequenceFINSEQ-1M1 st ((yf0 =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?P(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      using A2 sorry
    have A4: " for k be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds  for z be setHIDDENM2 holds (((\<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) & z =XBOOLE-0R4 Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & ?P(z,x,y1)) & ?P(z,x,y2) implies y1 =XBOOLE-0R4 y2"
       sorry
    have A5: " ex p be FinSequenceFINSEQ-1M1 st ((xf0 =HIDDENR1 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ?P(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      using A1 sorry
    show "xf0 =HIDDENR1 yf0"
      using recdef_1_sch_9 A4 A5 A3 sorry
  qed

theorem recdef_1_sch_11:
  fixes Af0 nf0 Pp3 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "nf0 be NatNAT-1M1" and
   A1: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex y be setHIDDENM2 st Pp3(n,x,y)" and
   A2: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2"
  shows "( ex y be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & ( for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ( ex f be FunctionFUNCT-1M1 st ((y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & ( ex f be FunctionFUNCT-1M1 st ((y2 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) implies y1 =XBOOLE-0R4 y2)"
  proof-
    have "( ex y be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & ( for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ( ex f1 be FunctionFUNCT-1M1 st ((y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0 & domRELAT-1K1 f1 =XBOOLE-0R4 NATNUMBERSK1) & f1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) implies (( ex f2 be FunctionFUNCT-1M1 st ((y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & domRELAT-1K1 f2 =XBOOLE-0R4 NATNUMBERSK1) & f2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) implies y1 =XBOOLE-0R4 y2))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      have A3: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex y be setHIDDENM2 st Pp3(n,x,y)"
        using A1 sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A4: "(domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_1 A3 sorry
      have A5: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2"
        using A2 sorry
      show " ex y be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
      proof-
        have " ex FN be setHIDDENM2 st  ex F be FunctionFUNCT-1M1 st ((FN =XBOOLE-0R4 F .FUNCT-1K1 nf0 & domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1) & F .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
        proof-
          obtain FN where 
            [ty]:"FN be setHIDDENM2" and FNDef:"FN = f .FUNCT-1K1 nf0"
             sorry
          show " ex FN be setHIDDENM2 st  ex F be FunctionFUNCT-1M1 st ((FN =XBOOLE-0R4 F .FUNCT-1K1 nf0 & domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1) & F .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
          proof(rule bexI[of _ "FN"])
            obtain F where 
              [ty]:"F be FunctionFUNCT-1M1" and FDef:"F = f"
               sorry
            show " ex F be FunctionFUNCT-1M1 st ((FN =XBOOLE-0R4 F .FUNCT-1K1 nf0 & domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1) & F .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
            proof(rule bexI[of _ "F"])
              show "((FN =XBOOLE-0R4 F .FUNCT-1K1 nf0 & domRELAT-1K1 F =XBOOLE-0R4 NATNUMBERSK1) & F .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
                using A4 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      fix y1 assume [ty]: "y1 be setHIDDENM2"
      fix y2 assume [ty]: "y2 be setHIDDENM2"
      assume Given: " ex f1 be FunctionFUNCT-1M1 st ((y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0 & domRELAT-1K1 f1 =XBOOLE-0R4 NATNUMBERSK1) & f1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
      then obtain f1 where
        [ty]:"f1 be FunctionFUNCT-1M1" and 
        A6: "y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0"and A7: "domRELAT-1K1 f1 =XBOOLE-0R4 NATNUMBERSK1"and A8: "f1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"and A9: " for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
         sorry
      have A10: " for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using A9 sorry
      assume Given: " ex f2 be FunctionFUNCT-1M1 st ((y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & domRELAT-1K1 f2 =XBOOLE-0R4 NATNUMBERSK1) & f2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
      then obtain f2 where
        [ty]:"f2 be FunctionFUNCT-1M1" and 
        A11: "y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0"and A12: "domRELAT-1K1 f2 =XBOOLE-0R4 NATNUMBERSK1"and A13: "f2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"and A14: " for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
         sorry
      have A15: " for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using A14 sorry
      have "f1 =FUNCT-1R1 f2"
        using nat_1_sch_13 A7 A8 A10 A12 A13 A15 A5 sorry
      thus "y1 =XBOOLE-0R4 y2"
        using A6 A11 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_12:
  fixes Af0 nf0 RecFunf2 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "nf0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> RecFunf2(x1,x2) be setHIDDENM2"
  shows "( ex y be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) & ( for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ( ex f be FunctionFUNCT-1M1 st ((y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) & ( ex f be FunctionFUNCT-1M1 st ((y2 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) implies y1 =XBOOLE-0R4 y2)"
  proof-
    have "( ex y be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) & ( for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ( ex f1 be FunctionFUNCT-1M1 st ((y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0 & domRELAT-1K1 f1 =XBOOLE-0R4 NATNUMBERSK1) & f1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f1 .FUNCT-1K1 n))) implies (( ex f2 be FunctionFUNCT-1M1 st ((y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & domRELAT-1K1 f2 =XBOOLE-0R4 NATNUMBERSK1) & f2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f2 .FUNCT-1K1 n))) implies y1 =XBOOLE-0R4 y2))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for z be setHIDDENM2 holds z =XBOOLE-0R4 Lamb2 implies Lamb3 =XBOOLE-0R4 RecFunf2(Lamb1,z)"
      have A1: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex y be setHIDDENM2 st ?P(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex tVar37 be setHIDDENM2 st  for z be setHIDDENM2 holds z =XBOOLE-0R4 x implies tVar37 =XBOOLE-0R4 RecFunf2(n,z)"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be setHIDDENM2"
          show " ex tVar37 be setHIDDENM2 st  for z be setHIDDENM2 holds z =XBOOLE-0R4 x implies tVar37 =XBOOLE-0R4 RecFunf2(n,z)"
          proof(rule bexI[of _ "RecFunf2(n,x)"])
            show " for z be setHIDDENM2 holds z =XBOOLE-0R4 x implies RecFunf2(n,x) =XBOOLE-0R4 RecFunf2(n,z)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A2: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ?P(n,x,y1) & ?P(n,x,y2) implies y1 =XBOOLE-0R4 y2"
      proof-
        have " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ( for z be setHIDDENM2 holds z =XBOOLE-0R4 x implies y1 =XBOOLE-0R4 RecFunf2(n,z)) & ( for z be setHIDDENM2 holds z =XBOOLE-0R4 x implies y2 =XBOOLE-0R4 RecFunf2(n,z)) implies y1 =HIDDENR1 y2"
        proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be setHIDDENM2"
          fix y1 assume [ty]: "y1 be setHIDDENM2"
          fix y2 assume [ty]: "y2 be setHIDDENM2"
          assume A3: " for z be setHIDDENM2 holds z =XBOOLE-0R4 x implies y1 =XBOOLE-0R4 RecFunf2(n,z)"
            and A4: " for z be setHIDDENM2 holds z =XBOOLE-0R4 x implies y2 =XBOOLE-0R4 RecFunf2(n,z)"
          have "y1 =HIDDENR1 RecFunf2(n,x)"
            using A3 sorry
          also have "... = y2"
            using A4 sorry
          finally show "y1 =HIDDENR1 y2"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A5: "( ex y be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds ?P(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & ( for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ( ex f be FunctionFUNCT-1M1 st ((y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds ?P(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) & ( ex f be FunctionFUNCT-1M1 st ((y2 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds ?P(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))) implies y1 =XBOOLE-0R4 y2)"
        using recdef_1_sch_11 A1 A2 sorry
      then obtain y f where
        [ty]:"y be setHIDDENM2" "f be FunctionFUNCT-1M1" and 
        A6: "(y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & (f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & ( for n be NatNAT-1M1 holds ?P(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))))"
         sorry
      show " ex y be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))"
      proof-
        have " ex tVar38 be setHIDDENM2 st  ex tVar39 be FunctionFUNCT-1M1 st ((tVar38 =XBOOLE-0R4 tVar39 .FUNCT-1K1 nf0 & domRELAT-1K1 tVar39 =XBOOLE-0R4 NATNUMBERSK1) & tVar39 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds tVar39 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,tVar39 .FUNCT-1K1 n))"
        proof-
          show " ex tVar38 be setHIDDENM2 st  ex tVar39 be FunctionFUNCT-1M1 st ((tVar38 =XBOOLE-0R4 tVar39 .FUNCT-1K1 nf0 & domRELAT-1K1 tVar39 =XBOOLE-0R4 NATNUMBERSK1) & tVar39 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds tVar39 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,tVar39 .FUNCT-1K1 n))"
          proof(rule bexI[of _ "y"])
            show " ex tVar39 be FunctionFUNCT-1M1 st ((y =XBOOLE-0R4 tVar39 .FUNCT-1K1 nf0 & domRELAT-1K1 tVar39 =XBOOLE-0R4 NATNUMBERSK1) & tVar39 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds tVar39 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,tVar39 .FUNCT-1K1 n))"
            proof(rule bexI[of _ "f"])
              show "((y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1) & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))"
                using A6 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      fix y1 assume [ty]: "y1 be setHIDDENM2"
      fix y2 assume [ty]: "y2 be setHIDDENM2"
      assume Given: " ex f1 be FunctionFUNCT-1M1 st ((y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0 & domRELAT-1K1 f1 =XBOOLE-0R4 NATNUMBERSK1) & f1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f1 .FUNCT-1K1 n))"
      then obtain f1 where
        [ty]:"f1 be FunctionFUNCT-1M1" and 
        A7: "(y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0 & domRELAT-1K1 f1 =XBOOLE-0R4 NATNUMBERSK1) & f1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"and A8: " for n be NatNAT-1M1 holds f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f1 .FUNCT-1K1 n)"
         sorry
      have A9: " for n be NatNAT-1M1 holds ?P(n,f1 .FUNCT-1K1 n,f1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using A8 sorry
      assume Given: " ex f2 be FunctionFUNCT-1M1 st ((y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & domRELAT-1K1 f2 =XBOOLE-0R4 NATNUMBERSK1) & f2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0) & ( for n be NatNAT-1M1 holds f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f2 .FUNCT-1K1 n))"
      then obtain f2 where
        [ty]:"f2 be FunctionFUNCT-1M1" and 
        A10: "(y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & domRELAT-1K1 f2 =XBOOLE-0R4 NATNUMBERSK1) & f2 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"and A11: " for n be NatNAT-1M1 holds f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f2 .FUNCT-1K1 n)"
         sorry
      have " for n be NatNAT-1M1 holds ?P(n,f2 .FUNCT-1K1 n,f2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using A11 sorry
      thus "y1 =XBOOLE-0R4 y2"
        using A5 A7 A10 A9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_13:
  fixes Df0 Af0 nf0 Pp3 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "nf0 be NatNAT-1M1" and
   A1: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st Pp3(n,x,y)" and
   A2: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2"
  shows "( ex y be ElementSUBSET-1M1-of Df0 st  ex f be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) & ( for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ( ex f be sequenceNAT-1M2-of Df0 st (y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) & ( ex f be sequenceNAT-1M2-of Df0 st (y2 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) implies y1 =XBOOLE-0R4 y2)"
  proof-
    have "( ex y be ElementSUBSET-1M1-of Df0 st  ex f be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) & ( for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ( ex f1 be sequenceNAT-1M2-of Df0 st (y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0 & f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) implies (( ex f2 be sequenceNAT-1M2-of Df0 st (y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) implies y1 =XBOOLE-0R4 y2))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      have A3: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st Pp3(n,x,y)"
        using A1 sorry
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of Df0" and 
        A4: "f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_2 A3 sorry
      have A5: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2"
        using A2 sorry
      show " ex y be ElementSUBSET-1M1-of Df0 st  ex f be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      proof-
        have " ex Fn be ElementSUBSET-1M1-of Df0 st  ex F be sequenceNAT-1M2-of Df0 st (Fn =XBOOLE-0R4 F .FUNCT-1K1 nf0 & F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
        proof-
          obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = nf0"
            using ordinal1_def_12 sorry
          obtain Fn where 
            [ty]:"Fn be ElementSUBSET-1M1-of Df0" and FnDef:"Fn = f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> n"
             sorry
          show " ex Fn be ElementSUBSET-1M1-of Df0 st  ex F be sequenceNAT-1M2-of Df0 st (Fn =XBOOLE-0R4 F .FUNCT-1K1 nf0 & F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
          proof(rule bexI[of _ "Fn"])
            obtain F where 
              [ty]:"F be sequenceNAT-1M2-of Df0" and FDef:"F = f"
               sorry
            show " ex F be sequenceNAT-1M2-of Df0 st (Fn =XBOOLE-0R4 F .FUNCT-1K1 nf0 & F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
            proof(rule bexI[of _ "F"])
              show "(Fn =XBOOLE-0R4 F .FUNCT-1K1 nf0 & F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,F .FUNCT-1K1 n,F .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
                using A4 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      fix y1 assume [ty]: "y1 be ElementSUBSET-1M1-of Df0"
      fix y2 assume [ty]: "y2 be ElementSUBSET-1M1-of Df0"
      assume Given: " ex f1 be sequenceNAT-1M2-of Df0 st (y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0 & f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      then obtain f1 where
        [ty]:"f1 be sequenceNAT-1M2-of Df0" and 
        A6: "y1 =XBOOLE-0R4 f1 .FUNCT-1K1 nf0"and A7: "f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"and A8: " for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
         sorry
      have A9: "f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"
        using A7 sorry
      have A10: " for n be NatNAT-1M1 holds Pp3(n,f1 .FUNCT-1K1 n,f1 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using A8 sorry
      assume Given: " ex f2 be sequenceNAT-1M2-of Df0 st (y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      then obtain f2 where
        [ty]:"f2 be sequenceNAT-1M2-of Df0" and 
        A11: "y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0"and A12: "f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"and A13: " for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
         sorry
      have A14: " for n be NatNAT-1M1 holds Pp3(n,f2 .FUNCT-1K1 n,f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using A13 sorry
      have A15: "f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"
        using A12 sorry
      have "f1 =FUNCT-2R2\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> f2"
        using nat_1_sch_14 A9 A10 A15 A14 A5 sorry
      thus "y1 =XBOOLE-0R4 y2"
        using A6 A11 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_14:
  fixes Df0 Af0 nf0 RecFunf2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "nf0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> RecFunf2(x1,x2) be ElementSUBSET-1M1-of Df0"
  shows "( ex y be ElementSUBSET-1M1-of Df0 st  ex f be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) & ( for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ( ex f be sequenceNAT-1M2-of Df0 st (y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) & ( ex f be sequenceNAT-1M2-of Df0 st (y2 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) implies y1 =XBOOLE-0R4 y2)"
  proof-
    have "( ex y be ElementSUBSET-1M1-of Df0 st  ex f be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) & ( for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ( ex f be sequenceNAT-1M2-of Df0 st (y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))) implies (( ex f2 be sequenceNAT-1M2-of Df0 st (y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f2 .FUNCT-1K1 n))) implies y1 =XBOOLE-0R4 y2))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for z be ElementSUBSET-1M1-of Df0 holds z =XBOOLE-0R4 Lamb2 implies Lamb3 =XBOOLE-0R4 RecFunf2(Lamb1,z)"
      have A1: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st ?Q(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  ex tVar42 be ElementSUBSET-1M1-of Df0 st  for z be ElementSUBSET-1M1-of Df0 holds z =XBOOLE-0R4 x implies tVar42 =XBOOLE-0R4 RecFunf2(n,z)"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of Df0"
          show " ex tVar42 be ElementSUBSET-1M1-of Df0 st  for z be ElementSUBSET-1M1-of Df0 holds z =XBOOLE-0R4 x implies tVar42 =XBOOLE-0R4 RecFunf2(n,z)"
          proof(rule bexI[of _ "RecFunf2(n,x)"],rule ballI,rule impI)
            fix z assume [ty]: "z be ElementSUBSET-1M1-of Df0"
            assume "z =XBOOLE-0R4 x"
            thus "RecFunf2(n,x) =XBOOLE-0R4 RecFunf2(n,z)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A2: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ?Q(n,x,y1) & ?Q(n,x,y2) implies y1 =XBOOLE-0R4 y2"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ( for z be ElementSUBSET-1M1-of Df0 holds z =XBOOLE-0R4 x implies y1 =XBOOLE-0R4 RecFunf2(n,z)) & ( for z be ElementSUBSET-1M1-of Df0 holds z =XBOOLE-0R4 x implies y2 =XBOOLE-0R4 RecFunf2(n,z)) implies y1 =HIDDENR1 y2"
        proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of Df0"
          fix y1 assume [ty]: "y1 be ElementSUBSET-1M1-of Df0"
          fix y2 assume [ty]: "y2 be ElementSUBSET-1M1-of Df0"
          assume A3: " for z be ElementSUBSET-1M1-of Df0 holds z =XBOOLE-0R4 x implies y1 =XBOOLE-0R4 RecFunf2(n,z)"
            and A4: " for z be ElementSUBSET-1M1-of Df0 holds z =XBOOLE-0R4 x implies y2 =XBOOLE-0R4 RecFunf2(n,z)"
          have "y1 =HIDDENR1 RecFunf2(n,x)"
            using A3 sorry
          also have "... = y2"
            using A4 sorry
          finally show "y1 =HIDDENR1 y2"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A5: "( ex y be ElementSUBSET-1M1-of Df0 st  ex f be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) & ( for y1 be ElementSUBSET-1M1-of Df0 holds  for y2 be ElementSUBSET-1M1-of Df0 holds ( ex f be sequenceNAT-1M2-of Df0 st (y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) & ( ex f be sequenceNAT-1M2-of Df0 st (y2 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))) implies y1 =XBOOLE-0R4 y2)"
        using recdef_1_sch_13 A1 A2 sorry
      then obtain y f where
        [ty]:"y be ElementSUBSET-1M1-of Df0" "f be sequenceNAT-1M2-of Df0" and 
        A6: "y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"and A7: " for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
         sorry
      show " ex y be ElementSUBSET-1M1-of Df0 st  ex f be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))"
      proof-
        have " ex tVar43 be ElementSUBSET-1M1-of Df0 st  ex tVar44 be sequenceNAT-1M2-of Df0 st (tVar43 =XBOOLE-0R4 tVar44 .FUNCT-1K1 nf0 & tVar44 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds tVar44 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,tVar44 .FUNCT-1K1 n))"
        proof-
          show " ex tVar43 be ElementSUBSET-1M1-of Df0 st  ex tVar44 be sequenceNAT-1M2-of Df0 st (tVar43 =XBOOLE-0R4 tVar44 .FUNCT-1K1 nf0 & tVar44 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds tVar44 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,tVar44 .FUNCT-1K1 n))"
          proof(rule bexI[of _ "y"])
            show " ex tVar44 be sequenceNAT-1M2-of Df0 st (y =XBOOLE-0R4 tVar44 .FUNCT-1K1 nf0 & tVar44 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds tVar44 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,tVar44 .FUNCT-1K1 n))"
            proof(rule bexI[of _ "f"],rule conjMI,rule ballI)
              show "y =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"
                using A6 sorry
              fix n assume [ty]: "n be NatNAT-1M1"
              have 
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "?Q(n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
                using A7 sorry
              thus "f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n)"
                 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      fix y1 assume [ty]: "y1 be ElementSUBSET-1M1-of Df0"
      fix y2 assume [ty]: "y2 be ElementSUBSET-1M1-of Df0"
      assume Given: " ex f be sequenceNAT-1M2-of Df0 st (y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n))"
      then obtain f where
        [ty]:"f be sequenceNAT-1M2-of Df0" and 
        A8: "y1 =XBOOLE-0R4 f .FUNCT-1K1 nf0 & f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"and A9: " for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f .FUNCT-1K1 n)"
         sorry
      have A10: " for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using A9 sorry
      assume Given: " ex f2 be sequenceNAT-1M2-of Df0 st (y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0) & ( for n be NatNAT-1M1 holds f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f2 .FUNCT-1K1 n))"
      then obtain f2 where
        [ty]:"f2 be sequenceNAT-1M2-of Df0" and 
        A11: "y2 =XBOOLE-0R4 f2 .FUNCT-1K1 nf0 & f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0"and A12: " for n be NatNAT-1M1 holds f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 RecFunf2(n,f2 .FUNCT-1K1 n)"
         sorry
      have " for n be NatNAT-1M1 holds ?Q(n,f2 .FUNCT-1K1 n,f2 .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        using A12 sorry
      thus "y1 =XBOOLE-0R4 y2"
        using A5 A8 A11 A10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_15:
  fixes Sf0 Pp3 
  assumes
[ty]: "Sf0 be FinSequenceFINSEQ-1M1" and
   A1: " for k be NatNAT-1M1 holds  for y be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ( ex z be setHIDDENM2 st Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),y,z))" and
   A2: " for k be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds  for z be setHIDDENM2 holds (((\<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) & z =XBOOLE-0R4 Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Pp3(z,x,y1)) & Pp3(z,x,y2) implies y1 =XBOOLE-0R4 y2"
  shows "( ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) & ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds ( ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) & ( ex p be FinSequenceFINSEQ-1M1 st ((y =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) implies x =XBOOLE-0R4 y)"
  proof-
    have "( ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) & ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds ( ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) implies (( ex p be FinSequenceFINSEQ-1M1 st ((y =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))) implies x =XBOOLE-0R4 y))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      have A3: " for k be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds  for z be setHIDDENM2 holds (((\<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0) & z =XBOOLE-0R4 Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & Pp3(z,x,y1)) & Pp3(z,x,y2) implies y1 =XBOOLE-0R4 y2"
        using A2 sorry
      have A4: " for k be NatNAT-1M1 holds  for y be setHIDDENM2 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies ( ex z be setHIDDENM2 st Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),y,z))"
        using A1 sorry
      show " ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_5 A4 sorry
      fix x assume [ty]: "x be setHIDDENM2"
      fix y assume [ty]: "y be setHIDDENM2"
      assume A5: " ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      assume A6: " ex p be FinSequenceFINSEQ-1M1 st ((y =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies Pp3(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k,p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
      show "x =XBOOLE-0R4 y"
        using recdef_1_sch_9 A3 A5 A6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_16:
  fixes Sf0 Ff2 
  assumes
[ty]: "Sf0 be FinSequenceFINSEQ-1M1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be setHIDDENM2"
  shows "( ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))) & ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds ( ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))) & ( ex p be FinSequenceFINSEQ-1M1 st ((y =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))) implies x =XBOOLE-0R4 y)"
  proof-
    have "( ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))) & ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds ( ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))) implies (( ex p be FinSequenceFINSEQ-1M1 st ((y =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))) implies x =XBOOLE-0R4 y))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      show " ex x be setHIDDENM2 st  ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))"
        using recdef_1_sch_6 sorry
      fix x assume [ty]: "x be setHIDDENM2"
      fix y assume [ty]: "y be setHIDDENM2"
      assume A1: " ex p be FinSequenceFINSEQ-1M1 st ((x =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))"
      assume A2: " ex p be FinSequenceFINSEQ-1M1 st ((y =XBOOLE-0R4 p .FUNCT-1K1 lenFINSEQ-1K4 p & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 Sf0) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Sf0 .FUNCT-1K1 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 Sf0 implies p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Ff2(Sf0 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M),p .FUNCT-1K1 k))"
      show "x =XBOOLE-0R4 y"
        using recdef_1_sch_10 A1 A2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_17:
  fixes Df0 Nf0 Pp2 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Nf0 be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 Nf0 implies ( ex x be ElementSUBSET-1M1-of Df0 st Pp2(k,x))"
  shows " ex p be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 Nf0 implies Pp2(k,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k))"
  proof-
    have " ex tVar45 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar45 =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,tVar45 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)))"
    proof-
      show " ex tVar45 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar45 =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,tVar45 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)))"
      proof-
        have cases: "Nf0 =XBOOLE-0R4 0NUMBERSK6 or Nf0 <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "Nf0 =XBOOLE-0R4 0NUMBERSK6 implies ( ex tVar45 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar45 =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,tVar45 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k))))"
        proof(rule impI)
          assume A2: "Nf0 =XBOOLE-0R4 0NUMBERSK6"
          show " ex tVar45 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar45 =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,tVar45 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)))"
          proof(rule bexI[of _ "<*>FINSEQ-1K7 Df0"])
            show "domFINSEQ-1K5 <*>FINSEQ-1K7 Df0 =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,<*>FINSEQ-1K7 Df0 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)))"
              using A2 sorry
          qed "sorry"
        qed
        have case2: "Nf0 <>HIDDENR2 0NUMBERSK6 implies ( ex tVar46 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar46 =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,tVar46 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k))))"
        proof(rule impI)
          assume A3: "Nf0 <>HIDDENR2 0NUMBERSK6"
          have "SegFINSEQ-1K2 Nf0 =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
          proof(rule impI)
            assume A4: "SegFINSEQ-1K2 Nf0 =XBOOLE-0R4 {}XBOOLE-0K1"
            have "Nf0 =XBOOLE-0R4 0NUMBERSK6 &  False  or Nf0 <>HIDDENR2 0NUMBERSK6 & (Nf0 <>HIDDENR2 0NUMBERSK6 implies  False )"
            proof-
              show "Nf0 =XBOOLE-0R4 0NUMBERSK6 &  False  or Nf0 <>HIDDENR2 0NUMBERSK6 & (Nf0 <>HIDDENR2 0NUMBERSK6 implies  False )"
              proof-
                have cases: "Nf0 =XBOOLE-0R4 0NUMBERSK6 or Nf0 <>HIDDENR2 0NUMBERSK6"
                   sorry
                have case1: "Nf0 =XBOOLE-0R4 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume "Nf0 =XBOOLE-0R4 0NUMBERSK6"
                  thus " False "
                    using A3 sorry
                qed
                have case2: "Nf0 <>HIDDENR2 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume "Nf0 <>HIDDENR2 0NUMBERSK6"
                  thus " False "
                    using A4 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " False "
               sorry
          qed
          then obtain M where 
            [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = SegFINSEQ-1K2 Nf0"
             sorry
          have A5: " for x be ElementSUBSET-1M1-of M holds  ex y be ElementSUBSET-1M1-of Df0 st Pp2(x,y)"
          proof-
            have " for x be ElementSUBSET-1M1-of M holds  not ( for y be ElementSUBSET-1M1-of Df0 holds  not Pp2(x,y))"
            proof(rule ballI)
              fix x assume [ty]: "x be ElementSUBSET-1M1-of M"
              have "x inTARSKIR2 SegFINSEQ-1K2 Nf0"
                 sorry
              thus " not ( for y be ElementSUBSET-1M1-of Df0 holds  not Pp2(x,y))"
                using A1 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain f where
            [ty]:"f be FunctionFUNCT-2M1-of(M,Df0)" and 
            A6: " for x be ElementSUBSET-1M1-of M holds Pp2(x,f .FUNCT-2K3\<^bsub>(M,Df0)\<^esub> x)"
            using funct_2_sch_3 A5 sorry
          have "domRELAT-1K1 f =XBOOLE-0R4 SegFINSEQ-1K2 Nf0"
            using funct_2_def_1 sorry
          then obtain q where 
            [ty]:"q be FinSequenceFINSEQ-1M1" and qDef:"q = f"
            using finseq_1_def_2 sorry
          have " for u be objectHIDDENM1 holds u inHIDDENR3 rngFUNCT-1K2 q implies u inHIDDENR3 Df0"
          proof(rule ballI,rule impI)
            fix u assume [ty]: "u be objectHIDDENM1"
            have A7: "rngFUNCT-1K2 q c=TARSKIR1 Df0"
              using relat_1_def_19 sorry
            assume "u inHIDDENR3 rngFUNCT-1K2 q"
            thus "u inHIDDENR3 Df0"
              using A7 sorry
          qed "sorry"
          then have "rngFUNCT-1K2 q c=TARSKIR1 Df0"
             sorry
          then have 
            [ty]:"q be FinSequenceFINSEQ-1M3-of Df0"
            using finseq_1_def_4 sorry
          show " ex tVar46 be FinSequenceFINSEQ-1M3-of Df0 st domFINSEQ-1K5 tVar46 =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,tVar46 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)))"
          proof(rule bexI[of _ "q"])
            have " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 Nf0 implies Pp2(k,q /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)"
            proof(rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A8: "k inTARSKIR2 SegFINSEQ-1K2 Nf0"
              then have "k inTARSKIR2 domFINSEQ-1K5 q"
                using funct_2_def_1 sorry
              then have "q .FUNCT-1K1 k =XBOOLE-0R4 q /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k"
                using partfun1_def_6 sorry
              thus "Pp2(k,q /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)"
                using A6 A8 sorry
            qed "sorry"
            thus "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 Nf0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 SegFINSEQ-1K2 Nf0 &  not Pp2(k,q /.PARTFUN1K7\<^bsub>(Df0)\<^esub> k)))"
              using funct_2_def_1 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_1_sch_18:
  fixes Df0 Af0 Nf0 Pp3 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Df0" and
  [ty]: "Nf0 be ElementSUBSET-1M1-of NATNUMBERSK1" and
   A1: " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies ( for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st Pp3(n,x,y))"
  shows " ex p be FinSequenceFINSEQ-1M3-of Df0 st (lenFINSEQ-1K4 p =XBOOLE-0R4 Nf0 & (p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " ex tVar49 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar49 =XBOOLE-0R4 Nf0 & ((tVar49 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n,tVar49 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n,tVar49 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))))"
    proof-
      let ?ZZ = "the ElementSUBSET-1M1-of Df0"
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. (0NUMBERSK6 <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies Pp3(Lamb1 +NAT-1K1 \<one>\<^sub>M,Lamb2,Lamb3)) & ( not (0NUMBERSK6 <=XXREAL-0R1 Lamb1 & Lamb1 <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M) implies Lamb3 =XBOOLE-0R4 ?ZZ)"
      have A2: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  ex y be ElementSUBSET-1M1-of Df0 st ?Q(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Df0 holds  not ( for y be ElementSUBSET-1M1-of Df0 holds  not ((0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)) & ( not (0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M) implies y =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)))"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of Df0"
          have "0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies  not ( for y be ElementSUBSET-1M1-of Df0 holds  not ?Q(n,x,y))"
          proof-
            have "0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies ( ex tVar47 be ElementSUBSET-1M1-of Df0 st (0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,tVar47)) &  not ( not (0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M) &  not tVar47 =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0))"
            proof(rule impMI ,rule impI)
              have A3: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                using xreal_1_th_6 sorry
              assume "0NUMBERSK6 <=XXREAL-0R1 n"
                and A4: "n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M"
              have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (Nf0 -XCMPLX-0K6 \<two>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                using A4 xreal_1_th_6 sorry
              then obtain y where
                [ty]:"y be ElementSUBSET-1M1-of Df0" and 
                A5: "Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)"
                using A1 A3 sorry
              show " ex tVar47 be ElementSUBSET-1M1-of Df0 st (0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,tVar47)) &  not ( not (0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M) &  not tVar47 =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)"
              proof(rule bexI[of _ "y"],rule conjMI)
                show "0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)"
                  using A5 sorry
                show " not ( not (0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M) &  not y =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)"
                  using A4 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          thus " not ( for y be ElementSUBSET-1M1-of Df0 holds  not ((0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M implies Pp3(n +NAT-1K1 \<one>\<^sub>M,x,y)) & ( not (0NUMBERSK6 <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<two>\<^sub>M) implies y =XBOOLE-0R4 the ElementSUBSET-1M1-of Df0)))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of Df0" and 
        A6: "f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & ( for n be NatNAT-1M1 holds ?Q(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_2 A2 sorry
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  for r be RealXREAL-0M1 holds r =HIDDENR1 Lamb1 implies Lamb2 =HIDDENR1 f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M)"
      have A7: " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ( ex tVar48 be objectHIDDENM1 st  for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies tVar48 =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 REALNUMBERSK2"
          then obtain r where 
            [ty]:"r be RealXREAL-0M1" and rDef:"r = x"
             sorry
          show " ex tVar48 be objectHIDDENM1 st  for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies tVar48 =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M)"
          proof(rule bexI[of _ "f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M)"])
            show " for rc be RealXREAL-0M1 holds rc =HIDDENR1 x implies f .FUNCT-1K1 (r -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 (rc -XCMPLX-0K6 \<one>\<^sub>M)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A8: "domRELAT-1K1 g =XBOOLE-0R4 REALNUMBERSK2 & ( for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies ?Q(x,g .FUNCT-1K1 x))"
        using classes1_sch_1 A7 sorry
      have "SegFINSEQ-1K2 Nf0 c=TARSKIR1 REALNUMBERSK2"
        using numbers_th_19 sorry
      then have A9: "domRELAT-1K1 (g  |RELAT-1K8 SegFINSEQ-1K2 Nf0) =XBOOLE-0R4 SegFINSEQ-1K2 Nf0"
        using A8 relat_1_th_62 sorry
      then obtain p where 
        [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = g  |RELAT-1K8 SegFINSEQ-1K2 Nf0"
        using finseq_1_def_2 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x inHIDDENR3 Df0"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 p"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A10: "y inHIDDENR3 domFINSEQ-1K5 p"and A11: "x =HIDDENR1 p .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A10 sorry
        have A12: "f .FUNCT-1K1 (y -XCMPLX-0K6 \<one>\<^sub>M) inTARSKIR2 Df0"
        proof-
          have "y <>HIDDENR2 0NUMBERSK6"
            using A9 A10 finseq_1_th_1 sorry
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A13: "y =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_6 sorry
          have 
            [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Df0)\<^esub> k inTARSKIR2 Df0"
             sorry
          thus "f .FUNCT-1K1 (y -XCMPLX-0K6 \<one>\<^sub>M) inTARSKIR2 Df0"
            using A13 sorry
        qed
        have A14: "y inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "p .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
          using A10 funct_1_th_47 sorry
        thus "x inHIDDENR3 Df0"
          using A8 A11 A12 A14 sorry
      qed "sorry"
      then have "rngFUNCT-1K2 p c=TARSKIR1 Df0"
         sorry
      then have 
        [ty]:"p be FinSequenceFINSEQ-1M3-of Df0"
        using finseq_1_def_4 sorry
      show " ex tVar49 be FinSequenceFINSEQ-1M3-of Df0 st lenFINSEQ-1K4 tVar49 =XBOOLE-0R4 Nf0 & ((tVar49 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies Pp3(n,tVar49 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n,tVar49 /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))))"
      proof(rule bexI[of _ "p"],rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
        show "lenFINSEQ-1K4 p =XBOOLE-0R4 Nf0"
          using A9 finseq_1_def_3 sorry
        have "Nf0 <>HIDDENR2 0NUMBERSK6 implies p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Af0"
        proof(rule impI)
          assume "Nf0 <>HIDDENR2 0NUMBERSK6"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A15: "Nf0 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_6 sorry
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
            using xreal_1_th_7 sorry
          then have A16: "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 Nf0"
            using A15 finseq_1_th_1 sorry
          then have "p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =HIDDENR1 p .FUNCT-1K1 \<one>\<^sub>M"
            using A9 partfun1_def_6 sorry
          also have "... = g .FUNCT-1K1 \<one>\<^sub>M"
            using A16 funct_1_th_49 sorry
          also have "... = f .FUNCT-1K1 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
            using A8 recdef_1_lm_2 sorry
          also have "... = Af0"
            using A6 sorry
          finally have "p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =HIDDENR1 Af0"
             sorry
          thus "p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Af0"
             sorry
        qed
        thus "p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Af0 or Nf0 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A17: "\<one>\<^sub>M <=XXREAL-0R1 n"
          and A18: "n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<one>\<^sub>M"
        obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A19: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A17 nat_1_th_6 sorry
        have A20: " for n be NatNAT-1M1 holds n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<one>\<^sub>M implies p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n <=XXREAL-0R1 Nf0 -XCMPLX-0K6 \<one>\<^sub>M"
          then have A21: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (Nf0 -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
            using xreal_1_th_6 sorry
          have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have A22: "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
            using A8 sorry
          also have "... = f .FUNCT-1K1 n"
             sorry
          finally have "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 n"
             sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have A23: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 Nf0"
            using A21 finseq_1_th_1 sorry
          then have "p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A9 partfun1_def_6 sorry
          thus "p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 n"
            using A23 A22 funct_1_th_49 sorry
        qed "sorry"
        have A24: "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        have "k <=XXREAL-0R1 (Nf0 -XCMPLX-0K6 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A18 A19 xreal_1_th_19 sorry
        then have "Pp3(k +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 k,f .FUNCT-2K3\<^bsub>(omegaORDINAL1K4,Df0)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using A6 sorry
        then have "Pp3(k +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 k,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using A20 A18 A19 sorry
        thus "Pp3(n,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> n,p /.PARTFUN1K7\<^bsub>(Df0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using A20 A18 A19 A24 xxreal_0_th_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

end
