theory quaterni
  imports arytm_0 series_3 funct_7
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, x, y, w, z, x1, x2, x3, x4, X for "setHIDDENM2"
reserve A for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mdef quaterni_def_1 ("QUATERNIONQUATERNIK1" 164 ) where
"func QUATERNIONQUATERNIK1 \<rightarrow> setHIDDENM2 equals
  (FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }))\\/XBOOLE-0K2 COMPLEXNUMBERSK3"
proof-
  (*coherence*)
    show "(FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }))\\/XBOOLE-0K2 COMPLEXNUMBERSK3 be setHIDDENM2"
       sorry
qed "sorry"

mdef quaterni_def_2 ("quaternionQUATERNIV1" 70 ) where
"attr quaternionQUATERNIV1 for NumberORDINAL1M1 means
  (\<lambda>x. x inHIDDENR3 QUATERNIONQUATERNIK1)"..

mtheorem quaterni_cl_1:
"cluster QUATERNIONQUATERNIK1 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "QUATERNIONQUATERNIK1 be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem quaterni_cl_2:
"cluster quaternionQUATERNIV1 for NumberORDINAL1M1"
proof
(*existence*)
  show " ex it be NumberORDINAL1M1 st it be quaternionQUATERNIV1"
  proof-
    have " ex tVar1 be NumberORDINAL1M1 st tVar1 be quaternionQUATERNIV1"
    proof-
      show " ex tVar1 be NumberORDINAL1M1 st tVar1 be quaternionQUATERNIV1"
      proof(rule bexI[of _ "the ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"])
        show "the ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 be quaternionQUATERNIV1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax QUATERNIM1 :: "Ty" ("QuaternionQUATERNIM1" 70)
translations "QuaternionQUATERNIM1" \<rightharpoonup> "quaternionQUATERNIV1\<bar>NumberORDINAL1M1"

(*\$CD*)
(*\$CT 4*)
mlemma quaterni_lm_1:
"(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)are-mutually-distinctZFMISC-1R2"
   sorry

mtheorem quaterni_th_5:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for X be setHIDDENM2 holds {ENUMSET1K2 x1,x2,x3,x4 } c=TARSKIR1 X iff ((x1 inTARSKIR2 X & x2 inTARSKIR2 X) & x3 inTARSKIR2 X) & x4 inTARSKIR2 X"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for X be setHIDDENM2 holds ({ENUMSET1K2 x1,x2,x3,x4 } c=TARSKIR1 X implies ((x1 inTARSKIR2 X & x2 inTARSKIR2 X) & x3 inTARSKIR2 X) & x4 inTARSKIR2 X) & (x1 inTARSKIR2 X & (x2 inTARSKIR2 X & (x3 inTARSKIR2 X & x4 inTARSKIR2 X)) implies {ENUMSET1K2 x1,x2,x3,x4 } c=TARSKIR1 X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "x1 inTARSKIR2 {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_def_2 sorry
    have A2: "x2 inTARSKIR2 {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_def_2 sorry
    have A3: "x3 inTARSKIR2 {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_def_2 sorry
    have "x4 inTARSKIR2 {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_def_2 sorry
    thus "{ENUMSET1K2 x1,x2,x3,x4 } c=TARSKIR1 X implies ((x1 inTARSKIR2 X & x2 inTARSKIR2 X) & x3 inTARSKIR2 X) & x4 inTARSKIR2 X"
      using A1 A2 A3 sorry
    assume A4: "x1 inTARSKIR2 X"
      and A5: "x2 inTARSKIR2 X"
      and A6: "x3 inTARSKIR2 X"
      and A7: "x4 inTARSKIR2 X"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } implies z inHIDDENR3 X"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 }"
      thus "z inHIDDENR3 X"
        using A4 A5 A6 A7 enumset1_def_2 sorry
    qed "sorry"
    thus "{ENUMSET1K2 x1,x2,x3,x4 } c=TARSKIR1 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax QUATERNIK2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("'( _ , _ , _ , _ ')-->QUATERNIK2\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]116)
translations "(x,y,w,z)-->QUATERNIK2\<^bsub>(A)\<^esub>(a,b,c,d)" \<rightharpoonup> "(x,y,w,z)-->FUNCT-4K12(a,b,c,d)"

mtheorem quaterni_add_1:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be setHIDDENM2", "y be setHIDDENM2", "w be setHIDDENM2", "z be setHIDDENM2", "a be ElementSUBSET-1M1-of A", "b be ElementSUBSET-1M1-of A", "c be ElementSUBSET-1M1-of A", "d be ElementSUBSET-1M1-of A"
"cluster (x,y,w,z)-->FUNCT-4K12(a,b,c,d) as-term-is FunctionFUNCT-2M1-of({ENUMSET1K2 x,y,w,z },A)"
proof
(*coherence*)
  show "(x,y,w,z)-->FUNCT-4K12(a,b,c,d) be FunctionFUNCT-2M1-of({ENUMSET1K2 x,y,w,z },A)"
  proof-
    let ?f = "(x,y)-->FUNCT-4K7\<^bsub>(A)\<^esub>(a,b)"
    let ?g = "(w,z)-->FUNCT-4K7\<^bsub>(A)\<^esub>(c,d)"
    let ?h = "(x,y,w,z)-->FUNCT-4K12(a,b,c,d)"
    have A1: "rngFUNCT-1K2 ?h c=TARSKIR1 rngRELSET-1K2\<^bsub>(A)\<^esub> ?f \\/SUBSET-1K4\<^bsub>(A)\<^esub> rngRELSET-1K2\<^bsub>(A)\<^esub> ?g"
      using funct_4_th_17 sorry
    have A2: "domRELAT-1K1 ?h =XBOOLE-0R4 {ENUMSET1K2 x,y,w,z }"
      using funct_4_th_137 sorry
    have "rngFUNCT-1K2 ?h c=TARSKIR1 A"
      using A1 xboole_1_th_1 sorry
    thus "(x,y,w,z)-->FUNCT-4K12(a,b,c,d) be FunctionFUNCT-2M1-of({ENUMSET1K2 x,y,w,z },A)"
      using A2 funct_2_def_1 relset_1_th_4 sorry
  qed
qed "sorry"

mdef quaterni_def_4 ("<j>QUATERNIK3" 164 ) where
"func <j>QUATERNIK3 \<rightarrow> NumberORDINAL1M1 equals
  (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6)"
proof-
  (*coherence*)
    show "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6) be NumberORDINAL1M1"
       sorry
qed "sorry"

mdef quaterni_def_5 ("<k>QUATERNIK4" 164 ) where
"func <k>QUATERNIK4 \<rightarrow> NumberORDINAL1M1 equals
  (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M)"
proof-
  (*coherence*)
    show "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M) be NumberORDINAL1M1"
       sorry
qed "sorry"

mtheorem quaterni_cl_3:
"cluster <i>XCMPLX-0K1 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "<i>XCMPLX-0K1 be quaternionQUATERNIV1"
  proof-
    obtain jj zz where 
      [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
      [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
      using xreal_0_def_1 sorry
    have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
      using arytm_0_def_5 sorry
    thus "<i>XCMPLX-0K1 be quaternionQUATERNIV1"
      using xboole_0_def_3 sorry
  qed
qed "sorry"

mtheorem quaterni_cl_4:
"cluster <j>QUATERNIK3 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "<j>QUATERNIK3 be quaternionQUATERNIV1"
  proof-
    let ?X = "{x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }"
    have A1: "<j>QUATERNIK3 inHIDDENR3 {x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 } implies  False "
    proof(rule impI)
      assume "<j>QUATERNIK3 inHIDDENR3 ?X"
      then have " ex x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) st (<j>QUATERNIK3 =HIDDENR1 x & x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6) & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
         sorry
      thus " False "
        using funct_4_th_140 sorry
    qed
    obtain z j w m where 
      [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2" and zDef:"z = 0NUMBERSK6" and
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = 0NUMBERSK6" and
      [ty]:"w be ElementSUBSET-1M1-of REALNUMBERSK2" and wDef:"w = \<one>\<^sub>M" and
      [ty]:"m be ElementSUBSET-1M1-of REALNUMBERSK2" and mDef:"m = 0NUMBERSK6"
      using xreal_0_def_1 sorry
    have "<j>QUATERNIK3 =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(z,j,w,m)"
       sorry
    then have "<j>QUATERNIK3 inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2)"
      using card_1_th_52 funct_2_th_8 sorry
    then have Cut141: "<j>QUATERNIK3 inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ?X"
      using A1 xboole_0_def_5 sorry
    have "<j>QUATERNIK3 inHIDDENR3 QUATERNIONQUATERNIK1"
    proof-
      show "<j>QUATERNIK3 inHIDDENR3 QUATERNIONQUATERNIK1"
        using xboole_0_def_3 Cut141 sorry
    qed
    thus "<j>QUATERNIK3 be quaternionQUATERNIV1"
      using quaterni_def_2 sorry
  qed
qed "sorry"

mtheorem quaterni_cl_5:
"cluster <k>QUATERNIK4 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "<k>QUATERNIK4 be quaternionQUATERNIV1"
  proof-
    let ?X = "{x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }"
    have A2: "<k>QUATERNIK4 inHIDDENR3 {x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 } implies  False "
    proof(rule impI)
      assume "<k>QUATERNIK4 inHIDDENR3 ?X"
      then have " ex x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) st (<k>QUATERNIK4 =HIDDENR1 x & x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6) & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
         sorry
      thus " False "
        using funct_4_th_139 sorry
    qed
    obtain z j w m where 
      [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2" and zDef:"z = 0NUMBERSK6" and
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = 0NUMBERSK6" and
      [ty]:"w be ElementSUBSET-1M1-of REALNUMBERSK2" and wDef:"w = 0NUMBERSK6" and
      [ty]:"m be ElementSUBSET-1M1-of REALNUMBERSK2" and mDef:"m = \<one>\<^sub>M"
      using xreal_0_def_1 sorry
    have "<k>QUATERNIK4 =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(z,j,w,m)"
       sorry
    then have "<k>QUATERNIK4 inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2)"
      using card_1_th_52 funct_2_th_8 sorry
    then have Cut156: "<k>QUATERNIK4 inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ?X"
      using A2 xboole_0_def_5 sorry
    have "<k>QUATERNIK4 inHIDDENR3 QUATERNIONQUATERNIK1"
    proof-
      show "<k>QUATERNIK4 inHIDDENR3 QUATERNIONQUATERNIK1"
        using xboole_0_def_3 Cut156 sorry
    qed
    thus "<k>QUATERNIK4 be quaternionQUATERNIV1"
      using quaterni_def_2 sorry
  qed
qed "sorry"

mtheorem quaterni_cl_6:
"cluster note-that quaternionQUATERNIV1 for ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds it be quaternionQUATERNIV1"
     sorry
qed "sorry"

mdef quaterni_def_6 ("[*QUATERNIK5 _ , _ , _ , _ *]" [0,0,0,0]164 ) where
  mlet "x be RealXREAL-0M1", "y be RealXREAL-0M1", "w be RealXREAL-0M1", "z be RealXREAL-0M1"
"func [*QUATERNIK5 x,y,w,z *] \<rightarrow> ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 means
  \<lambda>it.  ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *] if w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 otherwise \<lambda>it. it =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z)"
proof-
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds  True "
       sorry
  (*existence*)
    show "(w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 implies ( ex it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *])) & ( not (w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6) implies ( ex it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st it =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z)))"
    proof-
      have "(w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 implies ( ex t be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & t =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *])) & (w <>HIDDENR2 0NUMBERSK6 or z <>HIDDENR2 0NUMBERSK6 implies ( ex t be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st t =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z)))"
      proof(rule conjMI)
        obtain x9 y9 w9 z9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of REALNUMBERSK2" and x9Def:"x9 = x" and
          [ty]:"y9 be ElementSUBSET-1M1-of REALNUMBERSK2" and y9Def:"y9 = y" and
          [ty]:"w9 be ElementSUBSET-1M1-of REALNUMBERSK2" and w9Def:"w9 = w" and
          [ty]:"z9 be ElementSUBSET-1M1-of REALNUMBERSK2" and z9Def:"z9 = z"
          using xreal_0_def_1 sorry
        show "w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 implies ( ex t be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & t =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *])"
        proof-
          have "w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 implies ( ex tVar2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  ex tVar3 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar3 =COMPLEX1R1 x & tVar4 =COMPLEX1R1 y) & tVar2 =XBOOLE-0R4 [*ARYTM-0K5 tVar3,tVar4 *])"
          proof(rule impMI ,rule impI)
            assume "w =COMPLEX1R1 0NUMBERSK6"
              and "z =COMPLEX1R1 0NUMBERSK6"
            let ?t = "[*ARYTM-0K5 x9,y9 *]"
            obtain t where 
              [ty]:"t be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1" and tDef:"t = ?t"
              using xboole_0_def_3 sorry
            show " ex tVar2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  ex tVar3 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar3 =COMPLEX1R1 x & tVar4 =COMPLEX1R1 y) & tVar2 =XBOOLE-0R4 [*ARYTM-0K5 tVar3,tVar4 *]"
            proof(rule bexI[of _ "t"])
              show " ex tVar3 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar3 =COMPLEX1R1 x & tVar4 =COMPLEX1R1 y) & t =XBOOLE-0R4 [*ARYTM-0K5 tVar3,tVar4 *]"
              proof(rule bexI[of _ "x9"])
                show " ex tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & tVar4 =COMPLEX1R1 y) & t =XBOOLE-0R4 [*ARYTM-0K5 x9,tVar4 *]"
                proof(rule bexI[of _ "y9"])
                  show "(x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & t =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *]"
                     sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        let ?e = "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(x9,y9,w9,z9)"
        show "w <>HIDDENR2 0NUMBERSK6 or z <>HIDDENR2 0NUMBERSK6 implies ( ex t be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st t =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z))"
        proof-
          have "w <>HIDDENR2 0NUMBERSK6 or z <>HIDDENR2 0NUMBERSK6 implies ( ex tVar5 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st tVar5 =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z))"
          proof(rule impI)
            assume A1: "w <>HIDDENR2 0NUMBERSK6 or z <>HIDDENR2 0NUMBERSK6"
            have A2: "?e inTARSKIR2 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2)"
              using card_1_th_52 funct_2_th_8 sorry
            have "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(x9,y9,w9,z9) inTARSKIR2 {r where r be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : r .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & r .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 } implies  False "
            proof(rule impI)
              assume "?e inTARSKIR2 {r where r be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : r .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & r .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }"
              then have " ex r be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) st (?e =FUNCT-2R1\<^bsub>({ENUMSET1K2 0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M },REALNUMBERSK2,\<four>\<^sub>M,REALNUMBERSK2)\<^esub> r & r .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6) & r .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
                 sorry
              thus " False "
                using A1 funct_4_th_139 funct_4_th_140 sorry
            qed
            then have "?e inTARSKIR2 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({r where r be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : r .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & r .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
              using A2 xboole_0_def_5 sorry
            then obtain e where 
              [ty]:"e be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1" and eDef:"e = ?e"
              using xboole_0_def_3 sorry
            show " ex tVar5 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st tVar5 =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z)"
            proof(rule bexI[of _ "e"])
              show "e =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z)"
                 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds  for it2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds (w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6 implies (( ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it1 =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *]) & ( ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & it2 =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *]) implies it1 =HIDDENR1 it2)) & ( not (w =COMPLEX1R1 0NUMBERSK6 & z =COMPLEX1R1 0NUMBERSK6) implies (it1 =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z) & it2 =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x,y,w,z) implies it1 =HIDDENR1 it2))"
       sorry
qed "sorry"

mlemma quaterni_lm_2:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 x,y *]"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  have " ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 x & y9 =COMPLEX1R1 y) & [*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *]"
    using quaterni_def_6 sorry
  thus "[*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 x,y *]"
     sorry
qed "sorry"

(*\$CT*)
mtheorem quaterni_th_7:
" for g be QuaternionQUATERNIM1 holds  ex r be RealXREAL-0M1 st  ex s be RealXREAL-0M1 st  ex t be RealXREAL-0M1 st  ex u be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,s,t,u *]"
proof-
  have " for g be QuaternionQUATERNIM1 holds  ex tVar6 be RealXREAL-0M1 st  ex tVar7 be RealXREAL-0M1 st  ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 tVar6,tVar7,tVar9,tVar9 *]"
  proof(rule ballI)
    fix g assume [ty]: "g be QuaternionQUATERNIM1"
    have A1: "g inHIDDENR3 QUATERNIONQUATERNIK1"
      using quaterni_def_2 sorry
    show " ex tVar6 be RealXREAL-0M1 st  ex tVar7 be RealXREAL-0M1 st  ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 tVar6,tVar7,tVar9,tVar9 *]"
    proof-
      have cases: "g inHIDDENR3 COMPLEXNUMBERSK3 or  not g inHIDDENR3 COMPLEXNUMBERSK3"
         sorry
      have case1: "g inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar6 be RealXREAL-0M1 st  ex tVar7 be RealXREAL-0M1 st  ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 tVar6,tVar7,tVar9,tVar9 *])"
      proof(rule impI)
        assume "g inHIDDENR3 COMPLEXNUMBERSK3"
        then obtain r s where
          [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" "s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A2: "g =HIDDENR1 [*ARYTM-0K5 r,s *]"
          using arytm_0_th_9 sorry
        show " ex tVar6 be RealXREAL-0M1 st  ex tVar7 be RealXREAL-0M1 st  ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 tVar6,tVar7,tVar9,tVar9 *]"
        proof(rule bexI[of _ "r"])
          show " ex tVar7 be RealXREAL-0M1 st  ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,tVar7,tVar9,tVar9 *]"
          proof(rule bexI[of _ "s"])
            show " ex tVar8 be RealXREAL-0M1 st  ex tVar9 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,s,tVar9,tVar9 *]"
            proof(rule bexI[of _ "0NUMBERSK6"])
              show " ex tVar9 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,s,tVar9,tVar9 *]"
              proof(rule bexI[of _ "0NUMBERSK6"])
                show "g =HIDDENR1 [*QUATERNIK5 r,s,0NUMBERSK6,0NUMBERSK6 *]"
                  using A2 quaterni_def_6 A1 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed
      have case2: " not g inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar10 be RealXREAL-0M1 st  ex tVar11 be RealXREAL-0M1 st  ex tVar12 be RealXREAL-0M1 st  ex tVar13 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 tVar10,tVar11,tVar12,tVar13 *])"
      proof(rule impI)
        assume " not g inHIDDENR3 COMPLEXNUMBERSK3"
        then have A3: "g inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
          using A1 xboole_0_def_3 sorry
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A4: "g =HIDDENR1 f"and A5: "domRELAT-1K1 f =XBOOLE-0R4 \<four>\<^sub>M"and A6: "rngFUNCT-1K2 f c=TARSKIR1 REALNUMBERSK2"
          using funct_2_def_2 sorry
        have A7: "0NUMBERSK6 inTARSKIR2 \<four>\<^sub>M"
          using card_1_th_52 enumset1_def_2 sorry
        have A8: "\<one>\<^sub>M inTARSKIR2 \<four>\<^sub>M"
          using card_1_th_52 enumset1_def_2 sorry
        have A9: "\<two>\<^sub>M inTARSKIR2 \<four>\<^sub>M"
          using card_1_th_52 enumset1_def_2 sorry
        have A10: "\<three>\<^sub>M inTARSKIR2 \<four>\<^sub>M"
          using card_1_th_52 enumset1_def_2 sorry
        have A11: "f .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 rngFUNCT-1K2 f"
          using A5 A7 funct_1_th_3 sorry
        have A12: "f .FUNCT-1K1 \<one>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
          using A5 A8 funct_1_th_3 sorry
        have A13: "f .FUNCT-1K1 \<two>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
          using A5 A9 funct_1_th_3 sorry
        have "f .FUNCT-1K1 \<three>\<^sub>M inTARSKIR2 rngFUNCT-1K2 f"
          using A5 A10 funct_1_th_3 sorry
        then obtain r s t u where 
          [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = f .FUNCT-1K1 (0NUMBERSK6)" and
          [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = f .FUNCT-1K1 \<one>\<^sub>M" and
          [ty]:"t be ElementSUBSET-1M1-of REALNUMBERSK2" and tDef:"t = f .FUNCT-1K1 \<two>\<^sub>M" and
          [ty]:"u be ElementSUBSET-1M1-of REALNUMBERSK2" and uDef:"u = f .FUNCT-1K1 \<three>\<^sub>M"
          using A6 A11 A12 A13 sorry
        have A14: "g =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(r,s,t,u)"
          using A4 A5 funct_4_th_144 card_1_th_52 sorry
        show " ex tVar10 be RealXREAL-0M1 st  ex tVar11 be RealXREAL-0M1 st  ex tVar12 be RealXREAL-0M1 st  ex tVar13 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 tVar10,tVar11,tVar12,tVar13 *]"
        proof(rule bexI[of _ "r"])
          show " ex tVar11 be RealXREAL-0M1 st  ex tVar12 be RealXREAL-0M1 st  ex tVar13 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,tVar11,tVar12,tVar13 *]"
          proof(rule bexI[of _ "s"])
            show " ex tVar12 be RealXREAL-0M1 st  ex tVar13 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,s,tVar12,tVar13 *]"
            proof(rule bexI[of _ "t"])
              show " ex tVar13 be RealXREAL-0M1 st g =HIDDENR1 [*QUATERNIK5 r,s,t,tVar13 *]"
              proof(rule bexI[of _ "u"])
                have "t =COMPLEX1R1 0NUMBERSK6 & u =COMPLEX1R1 0NUMBERSK6 implies  False "
                proof(rule impMI ,rule impI)
                  assume A15: "t =COMPLEX1R1 0NUMBERSK6"
                    and A16: "u =COMPLEX1R1 0NUMBERSK6"
                  have A17: "((0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(r,s,t,u)).FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
                    using A15 funct_4_th_140 sorry
                  have "((0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(r,s,t,u)).FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6"
                    using A16 funct_4_th_139 sorry
                  then have "g inHIDDENR3 {x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }"
                    using A3 A14 A17 sorry
                  thus " False "
                    using A3 xboole_0_def_5 sorry
                qed
                thus "g =HIDDENR1 [*QUATERNIK5 r,s,t,u *]"
                  using A14 quaterni_def_6 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve i, j, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve a, b, c, d for "RealXREAL-0M1"
reserve y, r, s, x, t, w for "ElementSUBSET-1M1-of RAT+ARYTM-3K5"
(*\$CT*)
mlemma quaterni_lm_3:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] =HIDDENR1 {TARSKIK1 z} implies z =HIDDENR1 {TARSKIK1 x} & x =HIDDENR1 y"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
  fix x assume [ty]: "x be objectHIDDENM1"
  fix y assume [ty]: "y be objectHIDDENM1"
  fix z assume [ty]: "z be objectHIDDENM1"
  assume A1: "[TARSKIK4 x,y ] =HIDDENR1 {TARSKIK1 z}"
  then have A2: "{TARSKIK2 x,y } inTARSKIR2 {TARSKIK1 z}"
    using tarski_def_2 sorry
  have "{TARSKIK1 x} inTARSKIR2 {TARSKIK1 z}"
    using A1 tarski_def_2 sorry
  thus A3: "z =HIDDENR1 {TARSKIK1 x}"
    using tarski_def_1 sorry
  have "{TARSKIK2 x,y } =HIDDENR1 z"
    using A2 tarski_def_1 sorry
  thus "x =HIDDENR1 y"
    using A3 zfmisc_1_th_5 sorry
qed "sorry"

mtheorem quaterni_th_9:
" for A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 holds ( ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t inTARSKIR2 A & t <>HIDDENR2 {}ARYTM-3K12) & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A) implies ( ex r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex r5 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (((((((((((((r1 inTARSKIR2 A & r2 inTARSKIR2 A) & r3 inTARSKIR2 A) & r4 inTARSKIR2 A) & r5 inTARSKIR2 A) & r1 <>HIDDENR2 r2) & r1 <>HIDDENR2 r3) & r1 <>HIDDENR2 r4) & r1 <>HIDDENR2 r5) & r2 <>HIDDENR2 r3) & r2 <>HIDDENR2 r4) & r2 <>HIDDENR2 r5) & r3 <>HIDDENR2 r4) & r3 <>HIDDENR2 r5) & r4 <>HIDDENR2 r5)"
proof-
  have " for A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 holds ( ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t inTARSKIR2 A & t <>HIDDENR2 {}ARYTM-3K12) implies (( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A) implies ( ex tVar14 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar15 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar16 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar17 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ((((tVar14 inTARSKIR2 A & tVar15 inTARSKIR2 A) & tVar16 inTARSKIR2 A) & tVar17 inTARSKIR2 A) & tVar18 inTARSKIR2 A) & ((((((((( not tVar14 <>HIDDENR2 tVar15 &  not tVar14 <>HIDDENR2 tVar16) &  not tVar14 <>HIDDENR2 tVar17) &  not tVar14 <>HIDDENR2 tVar18) &  not tVar15 <>HIDDENR2 tVar16) &  not tVar15 <>HIDDENR2 tVar17) &  not tVar15 <>HIDDENR2 tVar18) &  not tVar16 <>HIDDENR2 tVar17) &  not tVar16 <>HIDDENR2 tVar18) &  not tVar17 <>HIDDENR2 tVar18)))"
  proof(rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5"
    assume Given: " ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t inTARSKIR2 A & t <>HIDDENR2 {}ARYTM-3K12"
    then obtain t where
      [ty]:"t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A1: "t inTARSKIR2 A"and A2: "t <>HIDDENR2 {}ARYTM-3K12"
       sorry
    assume A3: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A"
    obtain x where
      [ty]:"x be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A4: "t =XBOOLE-0R4 x +ARYTM-3K10 x"
      using arytm_3_th_60 sorry
    obtain y where
      [ty]:"y be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A5: "x =XBOOLE-0R4 y +ARYTM-3K10 y"
      using arytm_3_th_60 sorry
    obtain w where
      [ty]:"w be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A6: "y =XBOOLE-0R4 w +ARYTM-3K10 w"
      using arytm_3_th_60 sorry
    show " ex tVar14 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar15 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar16 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar17 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ((((tVar14 inTARSKIR2 A & tVar15 inTARSKIR2 A) & tVar16 inTARSKIR2 A) & tVar17 inTARSKIR2 A) & tVar18 inTARSKIR2 A) & ((((((((( not tVar14 <>HIDDENR2 tVar15 &  not tVar14 <>HIDDENR2 tVar16) &  not tVar14 <>HIDDENR2 tVar17) &  not tVar14 <>HIDDENR2 tVar18) &  not tVar15 <>HIDDENR2 tVar16) &  not tVar15 <>HIDDENR2 tVar17) &  not tVar15 <>HIDDENR2 tVar18) &  not tVar16 <>HIDDENR2 tVar17) &  not tVar16 <>HIDDENR2 tVar18) &  not tVar17 <>HIDDENR2 tVar18)"
    proof(rule bexI[of _ "{}ARYTM-3K12"])
      show " ex tVar15 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar16 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar17 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (((({}ARYTM-3K12 inTARSKIR2 A & tVar15 inTARSKIR2 A) & tVar16 inTARSKIR2 A) & tVar17 inTARSKIR2 A) & tVar18 inTARSKIR2 A) & ((((((((( not {}ARYTM-3K12 <>HIDDENR2 tVar15 &  not {}ARYTM-3K12 <>HIDDENR2 tVar16) &  not {}ARYTM-3K12 <>HIDDENR2 tVar17) &  not {}ARYTM-3K12 <>HIDDENR2 tVar18) &  not tVar15 <>HIDDENR2 tVar16) &  not tVar15 <>HIDDENR2 tVar17) &  not tVar15 <>HIDDENR2 tVar18) &  not tVar16 <>HIDDENR2 tVar17) &  not tVar16 <>HIDDENR2 tVar18) &  not tVar17 <>HIDDENR2 tVar18)"
      proof(rule bexI[of _ "w"])
        show " ex tVar16 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar17 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (((({}ARYTM-3K12 inTARSKIR2 A & w inTARSKIR2 A) & tVar16 inTARSKIR2 A) & tVar17 inTARSKIR2 A) & tVar18 inTARSKIR2 A) & ((((((((( not {}ARYTM-3K12 <>HIDDENR2 w &  not {}ARYTM-3K12 <>HIDDENR2 tVar16) &  not {}ARYTM-3K12 <>HIDDENR2 tVar17) &  not {}ARYTM-3K12 <>HIDDENR2 tVar18) &  not w <>HIDDENR2 tVar16) &  not w <>HIDDENR2 tVar17) &  not w <>HIDDENR2 tVar18) &  not tVar16 <>HIDDENR2 tVar17) &  not tVar16 <>HIDDENR2 tVar18) &  not tVar17 <>HIDDENR2 tVar18)"
        proof(rule bexI[of _ "y"])
          show " ex tVar17 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (((({}ARYTM-3K12 inTARSKIR2 A & w inTARSKIR2 A) & y inTARSKIR2 A) & tVar17 inTARSKIR2 A) & tVar18 inTARSKIR2 A) & ((((((((( not {}ARYTM-3K12 <>HIDDENR2 w &  not {}ARYTM-3K12 <>HIDDENR2 y) &  not {}ARYTM-3K12 <>HIDDENR2 tVar17) &  not {}ARYTM-3K12 <>HIDDENR2 tVar18) &  not w <>HIDDENR2 y) &  not w <>HIDDENR2 tVar17) &  not w <>HIDDENR2 tVar18) &  not y <>HIDDENR2 tVar17) &  not y <>HIDDENR2 tVar18) &  not tVar17 <>HIDDENR2 tVar18)"
          proof(rule bexI[of _ "x"])
            show " ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (((({}ARYTM-3K12 inTARSKIR2 A & w inTARSKIR2 A) & y inTARSKIR2 A) & x inTARSKIR2 A) & tVar18 inTARSKIR2 A) & ((((((((( not {}ARYTM-3K12 <>HIDDENR2 w &  not {}ARYTM-3K12 <>HIDDENR2 y) &  not {}ARYTM-3K12 <>HIDDENR2 x) &  not {}ARYTM-3K12 <>HIDDENR2 tVar18) &  not w <>HIDDENR2 y) &  not w <>HIDDENR2 x) &  not w <>HIDDENR2 tVar18) &  not y <>HIDDENR2 x) &  not y <>HIDDENR2 tVar18) &  not x <>HIDDENR2 tVar18)"
            proof(rule bexI[of _ "t"],rule conjMI)
              have A7: "{}ARYTM-3K12 <='ARYTM-3R3 t"
                using arytm_3_th_64 sorry
              have A8: "x <='ARYTM-3R3 t"
                using A4 sorry
              have A9: "y <='ARYTM-3R3 x"
                using A5 sorry
              have A10: "w <='ARYTM-3R3 y"
                using A6 sorry
              have A11: "y <='ARYTM-3R3 t"
                using A8 A9 arytm_3_th_67 sorry
              have "w <='ARYTM-3R3 x"
                using A9 A10 arytm_3_th_67 sorry
              thus "((({}ARYTM-3K12 inTARSKIR2 A & w inTARSKIR2 A) & y inTARSKIR2 A) & x inTARSKIR2 A) & t inTARSKIR2 A"
                using A1 A3 A7 A8 A9 arytm_3_th_67 sorry
              have A12: "{}ARYTM-3K12 <>HIDDENR2 x"
                using A2 A4 arytm_3_th_50 sorry
              then have A13: "{}ARYTM-3K12 <>HIDDENR2 y"
                using A5 arytm_3_th_50 sorry
              have A14: "x <>HIDDENR2 t"
              proof-
                have "x =XBOOLE-0R4 t implies  False "
                proof(rule impI)
                  assume "x =XBOOLE-0R4 t"
                  then have "t +ARYTM-3K10 {}ARYTM-3K12 =XBOOLE-0R4 t +ARYTM-3K10 t"
                    using A4 arytm_3_th_50 sorry
                  thus " False "
                    using A2 arytm_3_th_62 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have A15: "y <>HIDDENR2 x"
              proof-
                have "y =XBOOLE-0R4 x implies  False "
                proof(rule impI)
                  assume "y =XBOOLE-0R4 x"
                  then have "x +ARYTM-3K10 {}ARYTM-3K12 =XBOOLE-0R4 x +ARYTM-3K10 x"
                    using A5 arytm_3_th_50 sorry
                  thus " False "
                    using A12 arytm_3_th_62 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have "w <>HIDDENR2 y"
              proof-
                have "w =XBOOLE-0R4 y implies  False "
                proof(rule impI)
                  assume "w =XBOOLE-0R4 y"
                  then have "y +ARYTM-3K10 {}ARYTM-3K12 =XBOOLE-0R4 y +ARYTM-3K10 y"
                    using A6 arytm_3_th_50 sorry
                  thus " False "
                    using A13 arytm_3_th_62 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "(((((((( not {}ARYTM-3K12 <>HIDDENR2 w &  not {}ARYTM-3K12 <>HIDDENR2 y) &  not {}ARYTM-3K12 <>HIDDENR2 x) &  not {}ARYTM-3K12 <>HIDDENR2 t) &  not w <>HIDDENR2 y) &  not w <>HIDDENR2 x) &  not w <>HIDDENR2 t) &  not y <>HIDDENR2 x) &  not y <>HIDDENR2 t) &  not x <>HIDDENR2 t"
                using A2 A4 A5 A6 A8 A9 A10 A11 A14 A15 arytm_3_th_50 arytm_3_th_66 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 REALNUMBERSK2"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 REALNUMBERSK2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    let ?f = "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d)"
    have A1: "?f =XBOOLE-0R4 {ENUMSET1K2 [TARSKIK4 0NUMBERSK6,a ],[TARSKIK4 \<one>\<^sub>M,b ],[TARSKIK4 \<two>\<^sub>M,c ],[TARSKIK4 \<three>\<^sub>M,d ] }"
      using quaterni_lm_1 funct_4_th_145 sorry
    have "?f inTARSKIR2 {[TARSKIK4 i,j ] where i be ElementSUBSET-1M1-of NATNUMBERSK1, j be ElementSUBSET-1M1-of NATNUMBERSK1 : (i,j)are-coprimeARYTM-3R1 & j <>HIDDENR2 {}ARYTM-3K12 } implies  False "
    proof(rule impI)
      assume "?f inTARSKIR2 {[TARSKIK4 i,j ] where i be ElementSUBSET-1M1-of NATNUMBERSK1, j be ElementSUBSET-1M1-of NATNUMBERSK1 : (i,j)are-coprimeARYTM-3R1 & j <>HIDDENR2 {}ARYTM-3K12 }"
      then obtain i j where
        [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" "j be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A2: "?f =HIDDENR1 [TARSKIK4 i,j ]"and "(i,j)are-coprimeARYTM-3R1"and "j <>HIDDENR2 {}ARYTM-3K12"
         sorry
      have A3: "{TARSKIK1 i} inTARSKIR2 ?f"
        using A2 tarski_def_2 sorry
      have A4: "{TARSKIK2 i,j } inTARSKIR2 ?f"
        using A2 tarski_def_2 sorry
      have A5: "i =COMPLEX1R1 j implies  False "
      proof(rule impI)
        assume "i =COMPLEX1R1 j"
        then have "{TARSKIK1 i} =XBOOLE-0R4 {TARSKIK2 i,j }"
          using enumset1_th_29 sorry
        then have A6: "[TARSKIK4 i,j ] =HIDDENR1 {TARSKIK1 {TARSKIK1 i} }"
          using enumset1_th_29 sorry
        then have A7: "[TARSKIK4 0NUMBERSK6,a ] inHIDDENR3 {TARSKIK1 {TARSKIK1 i} }"
          using A1 A2 enumset1_def_2 sorry
        have A8: "[TARSKIK4 \<one>\<^sub>M,b ] inHIDDENR3 {TARSKIK1 {TARSKIK1 i} }"
          using A1 A2 A6 enumset1_def_2 sorry
        have A9: "[TARSKIK4 0NUMBERSK6,a ] =HIDDENR1 {TARSKIK1 i}"
          using A7 tarski_def_1 sorry
        have "[TARSKIK4 \<one>\<^sub>M,b ] =HIDDENR1 {TARSKIK1 i}"
          using A8 tarski_def_1 sorry
        thus " False "
          using A9 xtuple_0_th_1 sorry
      qed
      show " False "
      proof-
        have cases: "(((((((((((((({TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]) or {TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
          using A1 A3 A4 enumset1_def_2 sorry
        have case1: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] implies  False "
        proof(rule impI)
          assume "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
          thus " False "
            using A5 zfmisc_1_th_5 sorry
        qed
        have case2: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] implies  False "
        proof(rule impMI ,rule impI)
          assume A10: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
            and A11: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
          have A12: "i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using A10 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<one>\<^sub>M},{TARSKIK2 \<one>\<^sub>M,b } }"
            using A11 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,b } or i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<one>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A12 tarski_def_1 sorry
        qed
        have case3: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] implies  False "
        proof(rule impMI ,rule impI)
          assume A13: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
            and A14: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]"
          have A15: "i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using A13 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<two>\<^sub>M},{TARSKIK2 \<two>\<^sub>M,c } }"
            using A14 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<two>\<^sub>M,c } or i =XBOOLE-0R4 {TARSKIK1 \<two>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<two>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A15 tarski_def_1 sorry
        qed
        have case4: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] implies  False "
        proof(rule impMI ,rule impI)
          assume A16: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
            and A17: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
          have A18: "i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using A16 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<three>\<^sub>M},{TARSKIK2 \<three>\<^sub>M,d } }"
            using A17 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<three>\<^sub>M,d } or i =XBOOLE-0R4 {TARSKIK1 \<three>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<three>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A18 tarski_def_1 sorry
        qed
        have case5: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] implies  False "
        proof(rule impMI ,rule impI)
          assume A19: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
            and A20: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
          have A21: "i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using A19 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 0NUMBERSK6 },{TARSKIK2 0NUMBERSK6,a } }"
            using A20 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,a } or i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_2 sorry
          then have "0NUMBERSK6 inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A21 tarski_def_1 sorry
        qed
        have case6: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] implies  False "
        proof(rule impI)
          assume "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
          thus " False "
            using A5 zfmisc_1_th_5 sorry
        qed
        have case7: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] implies  False "
        proof(rule impMI ,rule impI)
          assume A22: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
            and A23: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]"
          have A24: "i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using A22 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<two>\<^sub>M},{TARSKIK2 \<two>\<^sub>M,c } }"
            using A23 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<two>\<^sub>M,c } or i =XBOOLE-0R4 {TARSKIK1 \<two>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<two>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A24 tarski_def_1 sorry
        qed
        have case8: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] implies  False "
        proof(rule impMI ,rule impI)
          assume A25: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
            and A26: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
          have A27: "i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using A25 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<three>\<^sub>M},{TARSKIK2 \<three>\<^sub>M,d } }"
            using A26 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<three>\<^sub>M,d } or i =XBOOLE-0R4 {TARSKIK1 \<three>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<three>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A27 tarski_def_1 sorry
        qed
        have case9: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] implies  False "
        proof(rule impMI ,rule impI)
          assume A28: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]"
            and A29: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
          have A30: "i =XBOOLE-0R4 {TARSKIK1 \<two>\<^sub>M}"
            using A28 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 0NUMBERSK6 },{TARSKIK2 0NUMBERSK6,a } }"
            using A29 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,a } or i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_2 sorry
          then have "0NUMBERSK6 inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A30 tarski_def_1 sorry
        qed
        have case10: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] implies  False "
        proof(rule impMI ,rule impI)
          assume A31: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]"
            and A32: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
          have A33: "i =XBOOLE-0R4 {TARSKIK1 \<two>\<^sub>M}"
            using A31 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<one>\<^sub>M},{TARSKIK2 \<one>\<^sub>M,b } }"
            using A32 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,b } or i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<one>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A33 tarski_def_1 sorry
        qed
        have case11: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] implies  False "
        proof(rule impI)
          assume "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]"
          thus " False "
            using A5 zfmisc_1_th_5 sorry
        qed
        have case12: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] implies  False "
        proof(rule impMI ,rule impI)
          assume A34: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]"
            and A35: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
          have A36: "i =XBOOLE-0R4 {TARSKIK1 \<two>\<^sub>M}"
            using A34 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<three>\<^sub>M},{TARSKIK2 \<three>\<^sub>M,d } }"
            using A35 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<three>\<^sub>M,d } or i =XBOOLE-0R4 {TARSKIK1 \<three>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<three>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A36 tarski_def_1 sorry
        qed
        have case13: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ] implies  False "
        proof(rule impMI ,rule impI)
          assume A37: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
            and A38: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 0NUMBERSK6,a ]"
          have A39: "i =XBOOLE-0R4 {TARSKIK1 \<three>\<^sub>M}"
            using A37 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 0NUMBERSK6 },{TARSKIK2 0NUMBERSK6,a } }"
            using A38 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,a } or i =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_2 sorry
          then have "0NUMBERSK6 inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A39 tarski_def_1 sorry
        qed
        have case14: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ] implies  False "
        proof(rule impMI ,rule impI)
          assume A40: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
            and A41: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,b ]"
          have A42: "i =XBOOLE-0R4 {TARSKIK1 \<three>\<^sub>M}"
            using A40 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<one>\<^sub>M},{TARSKIK2 \<one>\<^sub>M,b } }"
            using A41 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<one>\<^sub>M,b } or i =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<one>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A42 tarski_def_1 sorry
        qed
        have case15: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ] implies  False "
        proof(rule impMI ,rule impI)
          assume A43: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
            and A44: "{TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,c ]"
          have A45: "i =XBOOLE-0R4 {TARSKIK1 \<three>\<^sub>M}"
            using A43 quaterni_lm_3 sorry
          have "i inTARSKIR2 {TARSKIK2 {TARSKIK1 \<two>\<^sub>M},{TARSKIK2 \<two>\<^sub>M,c } }"
            using A44 tarski_def_2 sorry
          then have "i =XBOOLE-0R4 {TARSKIK2 \<two>\<^sub>M,c } or i =XBOOLE-0R4 {TARSKIK1 \<two>\<^sub>M}"
            using tarski_def_2 sorry
          then have "\<two>\<^sub>M inTARSKIR2 i"
            using tarski_def_1 tarski_def_2 sorry
          thus " False "
            using A45 tarski_def_1 sorry
        qed
        have case16: "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] implies  False "
        proof(rule impI)
          assume "{TARSKIK1 i} =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ] & {TARSKIK2 i,j } =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,d ]"
          thus " False "
            using A5 zfmisc_1_th_5 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 case4 case5 case6 case7 case8 case9 case10 case11 case12 case13 case14 case15 case16 sorry
      qed
    qed
    then have A46: " not ?f inTARSKIR2 ({[TARSKIK4 i,j ] where i be ElementSUBSET-1M1-of NATNUMBERSK1, j be ElementSUBSET-1M1-of NATNUMBERSK1 : (i,j)are-coprimeARYTM-3R1 & j <>HIDDENR2 {}ARYTM-3K12 })\\SUBSET-1K6 ({[TARSKIK4 k,\<one>\<^sub>M ] where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  True  })"
       sorry
    have "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 omegaORDINAL1K4 implies  False "
    proof(rule impI)
      assume "?f inTARSKIR2 omegaORDINAL1K4"
      then have "?f be  non emptyXBOOLE-0V1\<bar>ordinalORDINAL1V3"
         sorry
      then have "{}ARYTM-3K12 inTARSKIR2 ?f"
        using ordinal3_th_8 sorry
      thus " False "
        using A1 enumset1_def_2 sorry
    qed
    then have A47: " not ?f inTARSKIR2 RAT+ARYTM-3K5"
      using A46 xboole_0_def_3 sorry
    let ?IR = "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
    have " not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st  ex w be objectHIDDENM1 st {ENUMSET1K2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ],[TARSKIK4 \<two>\<^sub>M,z ],[TARSKIK4 \<three>\<^sub>M,w ] } inTARSKIR2 ?IR)"
    proof-
      have "( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st  ex w be objectHIDDENM1 st {ENUMSET1K2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ],[TARSKIK4 \<two>\<^sub>M,z ],[TARSKIK4 \<three>\<^sub>M,w ] } inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st  ex w be objectHIDDENM1 st {ENUMSET1K2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ],[TARSKIK4 \<two>\<^sub>M,z ],[TARSKIK4 \<three>\<^sub>M,w ] } inTARSKIR2 ?IR"
        then obtain x y z w where
          [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" "z be objectHIDDENM1" "w be objectHIDDENM1" and 
          A48: "{ENUMSET1K2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ],[TARSKIK4 \<two>\<^sub>M,z ],[TARSKIK4 \<three>\<^sub>M,w ] } inTARSKIR2 ?IR"
           sorry
        obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A49: "{ENUMSET1K2 [TARSKIK4 0NUMBERSK6,x ],[TARSKIK4 \<one>\<^sub>M,y ],[TARSKIK4 \<two>\<^sub>M,z ],[TARSKIK4 \<three>\<^sub>M,w ] } =XBOOLE-0R4 A"and A50: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
          using A48 sorry
        have A51: "[TARSKIK4 0NUMBERSK6,x ] inHIDDENR3 A"
          using A49 enumset1_def_2 sorry
        have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A"
          using A50 sorry
        then obtain r1 r2 r3 r4 r5 where
          [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r5 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A52: "r1 inTARSKIR2 A"and A53: "r2 inTARSKIR2 A"and A54: "r3 inTARSKIR2 A"and A55: "r4 inTARSKIR2 A"and A56: "r5 inTARSKIR2 A"and A57: "r1 <>HIDDENR2 r2"and A58: "r1 <>HIDDENR2 r3"and A59: "r1 <>HIDDENR2 r4"and A60: "r1 <>HIDDENR2 r5"and A61: "r2 <>HIDDENR2 r3"and A62: "r2 <>HIDDENR2 r4"and A63: "r2 <>HIDDENR2 r5"and A64: "r3 <>HIDDENR2 r4"and A65: "r3 <>HIDDENR2 r5"and A66: "r4 <>HIDDENR2 r5"
          using A51 quaterni_th_9 sorry
        have A67: "((r1 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x ] or r1 =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,y ]) or r1 =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,z ]) or r1 =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,w ]"
          using A49 A52 enumset1_def_2 sorry
        have A68: "((r2 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x ] or r2 =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,y ]) or r2 =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,z ]) or r2 =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,w ]"
          using A49 A53 enumset1_def_2 sorry
        have A69: "((r3 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x ] or r3 =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,y ]) or r3 =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,z ]) or r3 =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,w ]"
          using A49 A54 enumset1_def_2 sorry
        have "((r4 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x ] or r4 =HIDDENR1 [TARSKIK4 \<one>\<^sub>M,y ]) or r4 =HIDDENR1 [TARSKIK4 \<two>\<^sub>M,z ]) or r4 =HIDDENR1 [TARSKIK4 \<three>\<^sub>M,w ]"
          using A49 A55 enumset1_def_2 sorry
        thus " False "
          using A49 A56 A57 A58 A59 A60 A61 A62 A63 A64 A65 A66 A67 A68 A69 enumset1_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have " not ?f inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
      using A1 arytm_2_def_1 sorry
    then have A70: " not ?f inTARSKIR2 REAL+ARYTM-2K2"
      using A47 arytm_2_def_2 xboole_0_def_3 sorry
    have "?f inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :] implies  False "
    proof(rule impI)
      assume "?f inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 {}ARYTM-3K12 },REAL+ARYTM-2K2 :]"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A71: "x inHIDDENR3 {TARSKIK1 {}ARYTM-3K12 }"and "y inHIDDENR3 REAL+ARYTM-2K2"and A72: "?f =HIDDENR1 [TARSKIK4 x,y ]"
        using zfmisc_1_th_84 sorry
      have A73: "x =HIDDENR1 0NUMBERSK6"
        using A71 tarski_def_1 sorry
      have "?f =XBOOLE-0R4 {ENUMSET1K2 [TARSKIK4 0NUMBERSK6,a ],[TARSKIK4 \<one>\<^sub>M,b ],[TARSKIK4 \<two>\<^sub>M,c ],[TARSKIK4 \<three>\<^sub>M,d ] }"
        using quaterni_lm_1 funct_4_th_145 sorry
      then have A74: "[TARSKIK4 \<one>\<^sub>M,b ] inHIDDENR3 ?f"
        using enumset1_def_2 sorry
      show " False "
      proof-
        have cases: "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } or {TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,y }"
          using A72 A73 A74 tarski_def_2 sorry
        have case1: "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } implies  False "
        proof(rule impI)
          assume "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
          then have "0NUMBERSK6 inTARSKIR2 {TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} }"
            using tarski_def_1 sorry
          thus " False "
            using tarski_def_2 sorry
        qed
        have case2: "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,y } implies  False "
        proof(rule impI)
          assume "{TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} } =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,y }"
          then have "0NUMBERSK6 inTARSKIR2 {TARSKIK2 {TARSKIK2 \<one>\<^sub>M,b },{TARSKIK1 \<one>\<^sub>M} }"
            using tarski_def_2 sorry
          thus " False "
            using tarski_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 REALNUMBERSK2"
      using A70 numbers_def_1 xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 COMPLEXNUMBERSK3"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds  not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 COMPLEXNUMBERSK3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    let ?f = "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d)"
    have A1: " not ?f inTARSKIR2 REALNUMBERSK2"
      using quaterni_lm_4 sorry
    have " not ?f inTARSKIR2 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)"
    proof-
      have "(0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) implies  False "
      proof(rule impI)
        assume "?f inTARSKIR2 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)"
        then have "domRELAT-1K1 ?f =XBOOLE-0R4 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
          using funct_2_th_92 sorry
        then have "{ENUMSET1K2 0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M } c=TARSKIR1 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
          using funct_4_th_137 sorry
        then have "{TARSKIK2 0NUMBERSK6,\<one>\<^sub>M } \\/XBOOLE-0K2 {TARSKIK2 \<two>\<^sub>M,\<three>\<^sub>M } c=TARSKIR1 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
          using enumset1_th_5 sorry
        thus " False "
          using xboole_1_th_11 zfmisc_1_th_22 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have " not ?f inTARSKIR2 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
       sorry
    thus " not (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d) inTARSKIR2 COMPLEXNUMBERSK3"
      using A1 numbers_def_2 xboole_0_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem quaterni_th_12:
" for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds [*QUATERNIK5 x1,x2,x3,x4 *] =XBOOLE-0R4 [*QUATERNIK5 y1,y2,y3,y4 *] implies ((x1 =COMPLEX1R1 y1 & x2 =COMPLEX1R1 y2) & x3 =COMPLEX1R1 y3) & x4 =COMPLEX1R1 y4"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix x1 assume [ty]: "x1 be RealXREAL-0M1"
  fix x2 assume [ty]: "x2 be RealXREAL-0M1"
  fix x3 assume [ty]: "x3 be RealXREAL-0M1"
  fix x4 assume [ty]: "x4 be RealXREAL-0M1"
  fix y1 assume [ty]: "y1 be RealXREAL-0M1"
  fix y2 assume [ty]: "y2 be RealXREAL-0M1"
  fix y3 assume [ty]: "y3 be RealXREAL-0M1"
  fix y4 assume [ty]: "y4 be RealXREAL-0M1"
  assume A1: "[*QUATERNIK5 x1,x2,x3,x4 *] =XBOOLE-0R4 [*QUATERNIK5 y1,y2,y3,y4 *]"
  obtain xx1 xx2 yy1 yy2 where 
    [ty]:"xx1 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx1Def:"xx1 = x1" and
    [ty]:"xx2 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx2Def:"xx2 = x2" and
    [ty]:"yy1 be ElementSUBSET-1M1-of REALNUMBERSK2" and yy1Def:"yy1 = y1" and
    [ty]:"yy2 be ElementSUBSET-1M1-of REALNUMBERSK2" and yy2Def:"yy2 = y2"
    using xreal_0_def_1 sorry
  show "((x1 =COMPLEX1R1 y1 & x2 =COMPLEX1R1 y2) & x3 =COMPLEX1R1 y3) & x4 =COMPLEX1R1 y4"
  proof-
    have cases: "x3 =COMPLEX1R1 0NUMBERSK6 & x4 =COMPLEX1R1 0NUMBERSK6 or (x3 <>HIDDENR2 0NUMBERSK6 or x4 <>HIDDENR2 0NUMBERSK6)"
       sorry
    have case1: "x3 =COMPLEX1R1 0NUMBERSK6 & x4 =COMPLEX1R1 0NUMBERSK6 implies ((x1 =COMPLEX1R1 y1 & x2 =COMPLEX1R1 y2) & x3 =COMPLEX1R1 y3) & x4 =COMPLEX1R1 y4"
    proof(rule impI)
      assume A2: "x3 =COMPLEX1R1 0NUMBERSK6 & x4 =COMPLEX1R1 0NUMBERSK6"
      then have A3: "[*QUATERNIK5 x1,x2,x3,x4 *] =XBOOLE-0R4 [*ARYTM-0K5 xx1,xx2 *]"
        using quaterni_lm_2 sorry
      have A4: "y3 <>HIDDENR2 0NUMBERSK6 or y4 <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "y3 <>HIDDENR2 0NUMBERSK6 or y4 <>HIDDENR2 0NUMBERSK6"
        then have "[*ARYTM-0K5 xx1,xx2 *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(y1,y2,y3,y4)"
          using A1 A3 quaterni_def_6 sorry
        thus " False "
          using quaterni_th_10 sorry
      qed
      then have "[*QUATERNIK5 y1,y2,y3,y4 *] =XBOOLE-0R4 [*ARYTM-0K5 yy1,yy2 *]"
        using quaterni_lm_2 sorry
      thus "((x1 =COMPLEX1R1 y1 & x2 =COMPLEX1R1 y2) & x3 =COMPLEX1R1 y3) & x4 =COMPLEX1R1 y4"
        using A1 A2 A3 A4 arytm_0_th_10 sorry
    qed
    have case2: "x3 <>HIDDENR2 0NUMBERSK6 or x4 <>HIDDENR2 0NUMBERSK6 implies ((x1 =COMPLEX1R1 y1 & x2 =COMPLEX1R1 y2) & x3 =COMPLEX1R1 y3) & x4 =COMPLEX1R1 y4"
    proof(rule impI)
      assume "x3 <>HIDDENR2 0NUMBERSK6 or x4 <>HIDDENR2 0NUMBERSK6"
      then have A5: "[*QUATERNIK5 y1,y2,y3,y4 *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(x1,x2,x3,x4)"
        using A1 quaterni_def_6 sorry
      have "y3 =COMPLEX1R1 0NUMBERSK6 & y4 =COMPLEX1R1 0NUMBERSK6 implies  False "
      proof(rule impMI ,rule impI)
        assume A6: "y3 =COMPLEX1R1 0NUMBERSK6"
          and A7: "y4 =COMPLEX1R1 0NUMBERSK6"
        have "[*QUATERNIK5 y1,y2,y3,y4 *] =XBOOLE-0R4 [*ARYTM-0K5 yy1,yy2 *]"
          using A6 A7 quaterni_lm_2 sorry
        thus " False "
          using A5 quaterni_th_10 sorry
      qed
      then have "[*QUATERNIK5 y1,y2,y3,y4 *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(y1,y2,y3,y4)"
        using quaterni_def_6 sorry
      thus "((x1 =COMPLEX1R1 y1 & x2 =COMPLEX1R1 y2) & x3 =COMPLEX1R1 y3) & x4 =COMPLEX1R1 y4"
        using A5 quaterni_lm_1 funct_4_th_146 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mdef quaterni_def_7 (" _ +QUATERNIK6  _ " [132,132]132 ) where
  mlet "x be QuaternionQUATERNIM1", "y be QuaternionQUATERNIM1"
"func x +QUATERNIK6 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
    proof-
      obtain x1 x2 x3 x4 where
        [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" and 
        A1: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"
        using quaterni_th_7 sorry
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A2: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " ex it be NumberORDINAL1M1 st  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
      proof-
        have " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not ((x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & IT =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]))"
        proof-
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1" and ITDef:"IT = [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
             sorry
          show " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not ((x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & IT =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]))"
          proof(rule bexI[of _ "IT"])
            show " not ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not ((x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & IT =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]))"
              using A1 A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it1 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) & ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it2 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) implies it1 =HIDDENR1 it2"
    proof-
      obtain x1 x2 x3 x4 where
        [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" and 
        A1: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"
        using quaterni_th_7 sorry
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A2: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it1 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) & ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it2 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be NumberORDINAL1M1 holds  for c2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & c1 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) implies (( ex x19 be RealXREAL-0M1 st  ex x29 be RealXREAL-0M1 st  ex x39 be RealXREAL-0M1 st  ex x49 be RealXREAL-0M1 st  ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x19,x29,x39,x49 *] & y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]) & c2 =HIDDENR1 [*QUATERNIK5 x19 +XCMPLX-0K2 y19,x29 +XCMPLX-0K2 y29,x39 +XCMPLX-0K2 y39,x49 +XCMPLX-0K2 y49 *]) implies c1 =HIDDENR1 c2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix c1 assume [ty]: "c1 be NumberORDINAL1M1"
          fix c2 assume [ty]: "c2 be NumberORDINAL1M1"
          assume Given: " ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & c1 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
          then obtain x1 x2 x3 x4 y1 y2 y3 y4 where
            [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" "y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
            A3: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"and A4: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and A5: "c1 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
             sorry
          assume Given: " ex x19 be RealXREAL-0M1 st  ex x29 be RealXREAL-0M1 st  ex x39 be RealXREAL-0M1 st  ex x49 be RealXREAL-0M1 st  ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x19,x29,x39,x49 *] & y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]) & c2 =HIDDENR1 [*QUATERNIK5 x19 +XCMPLX-0K2 y19,x29 +XCMPLX-0K2 y29,x39 +XCMPLX-0K2 y39,x49 +XCMPLX-0K2 y49 *]"
          then obtain x19 x29 x39 x49 y19 y29 y39 y49 where
            [ty]:"x19 be RealXREAL-0M1" "x29 be RealXREAL-0M1" "x39 be RealXREAL-0M1" "x49 be RealXREAL-0M1" "y19 be RealXREAL-0M1" "y29 be RealXREAL-0M1" "y39 be RealXREAL-0M1" "y49 be RealXREAL-0M1" and 
            A6: "x =HIDDENR1 [*QUATERNIK5 x19,x29,x39,x49 *]"and A7: "y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]"and A8: "c2 =HIDDENR1 [*QUATERNIK5 x19 +XCMPLX-0K2 y19,x29 +XCMPLX-0K2 y29,x39 +XCMPLX-0K2 y39,x49 +XCMPLX-0K2 y49 *]"
             sorry
          have A9: "x1 =COMPLEX1R1 x19"
            using A3 A6 quaterni_th_12 sorry
          have A10: "x2 =COMPLEX1R1 x29"
            using A3 A6 quaterni_th_12 sorry
          have A11: "x3 =COMPLEX1R1 x39"
            using A3 A6 quaterni_th_12 sorry
          have A12: "x4 =COMPLEX1R1 x49"
            using A3 A6 quaterni_th_12 sorry
          have A13: "y1 =COMPLEX1R1 y19"
            using A4 A7 quaterni_th_12 sorry
          have A14: "y2 =COMPLEX1R1 y29"
            using A4 A7 quaterni_th_12 sorry
          have "y3 =COMPLEX1R1 y39"
            using A4 A7 quaterni_th_12 sorry
          thus "c1 =HIDDENR1 c2"
            using A4 A5 A7 A8 A9 A10 A11 A12 A13 A14 quaterni_th_12 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem QUATERNIK6_commutativity:
" for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds x +QUATERNIK6 y =HIDDENR1 y +QUATERNIK6 x"
proof-
  have " for it be NumberORDINAL1M1 holds  for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds it =HIDDENR1 x +QUATERNIK6 y implies it =HIDDENR1 y +QUATERNIK6 x"
  proof-
    obtain x1 x2 x3 x4 where
      [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" and 
      A1: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"
      using quaterni_th_7 sorry
    obtain y1 y2 y3 y4 where
      [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
      A2: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
      using quaterni_th_7 sorry
    have " for it be NumberORDINAL1M1 holds  for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]) implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (y =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & x =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *])"
       sorry
    thus " ?thesis "
      using quaterni_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_5:
"0NUMBERSK6 =XBOOLE-0R4 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
proof-
  have " ex x9 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y9 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x9 =COMPLEX1R1 0NUMBERSK6 & y9 =COMPLEX1R1 0NUMBERSK6) & [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 x9,y9 *]"
    using quaterni_def_6 sorry
  thus "0NUMBERSK6 =XBOOLE-0R4 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
    using arytm_0_def_5 sorry
qed

mdef quaterni_def_8 ("-QUATERNIK7  _ " [132]132 ) where
  mlet "z be QuaternionQUATERNIM1"
"func -QUATERNIK7 z \<rightarrow> QuaternionQUATERNIM1 means
  \<lambda>it. z +QUATERNIK6 it =HIDDENR1 0NUMBERSK6"
proof-
  (*existence*)
    show " ex it be QuaternionQUATERNIM1 st z +QUATERNIK6 it =HIDDENR1 0NUMBERSK6"
    proof-
      obtain v w x y where
        [ty]:"v be RealXREAL-0M1" "w be RealXREAL-0M1" "x be RealXREAL-0M1" "y be RealXREAL-0M1" and 
        A1: "z =HIDDENR1 [*QUATERNIK5 v,w,x,y *]"
        using quaterni_th_7 sorry
      show " ex it be QuaternionQUATERNIM1 st z +QUATERNIK6 it =HIDDENR1 0NUMBERSK6"
      proof-
        have " ex tVar20 be QuaternionQUATERNIM1 st z +QUATERNIK6 tVar20 =HIDDENR1 0NUMBERSK6"
        proof-
          obtain z9 where 
            [ty]:"z9 be QuaternionQUATERNIM1" and z9Def:"z9 = [*QUATERNIK5 -XCMPLX-0K4 v,-XCMPLX-0K4 w,-XCMPLX-0K4 x,-XCMPLX-0K4 y *]"
             sorry
          show " ex tVar20 be QuaternionQUATERNIM1 st z +QUATERNIK6 tVar20 =HIDDENR1 0NUMBERSK6"
          proof(rule bexI[of _ "z9"])
            have A2: "0NUMBERSK6 =COMPLEX1R1 v +XCMPLX-0K2 (-XCMPLX-0K4 v)"
               sorry
            have A3: "0NUMBERSK6 =COMPLEX1R1 w +XCMPLX-0K2 (-XCMPLX-0K4 w)"
               sorry
            have A4: "0NUMBERSK6 =COMPLEX1R1 x +XCMPLX-0K2 (-XCMPLX-0K4 x)"
               sorry
            have "0NUMBERSK6 =COMPLEX1R1 y +XCMPLX-0K2 (-XCMPLX-0K4 y)"
               sorry
            thus "z +QUATERNIK6 z9 =HIDDENR1 0NUMBERSK6"
              using A1 A2 A3 A4 quaterni_def_7 quaterni_lm_5 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be QuaternionQUATERNIM1 holds  for it2 be QuaternionQUATERNIM1 holds z +QUATERNIK6 it1 =HIDDENR1 0NUMBERSK6 & z +QUATERNIK6 it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2"
    proof-
      obtain v w x y where
        [ty]:"v be RealXREAL-0M1" "w be RealXREAL-0M1" "x be RealXREAL-0M1" "y be RealXREAL-0M1" and 
        A1: "z =HIDDENR1 [*QUATERNIK5 v,w,x,y *]"
        using quaterni_th_7 sorry
      show " for it1 be QuaternionQUATERNIM1 holds  for it2 be QuaternionQUATERNIM1 holds z +QUATERNIK6 it1 =HIDDENR1 0NUMBERSK6 & z +QUATERNIK6 it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be QuaternionQUATERNIM1 holds  for c2 be QuaternionQUATERNIM1 holds z +QUATERNIK6 c1 =HIDDENR1 0NUMBERSK6 & z +QUATERNIK6 c2 =HIDDENR1 0NUMBERSK6 implies c1 =HIDDENR1 c2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix c1 assume [ty]: "c1 be QuaternionQUATERNIM1"
          fix c2 assume [ty]: "c2 be QuaternionQUATERNIM1"
          assume A5: "z +QUATERNIK6 c1 =HIDDENR1 0NUMBERSK6"
            and A6: "z +QUATERNIK6 c2 =HIDDENR1 0NUMBERSK6"
          obtain x1 x2 x3 x4 y1 y2 y3 y4 where
            [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" "y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
            A7: "z =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"and A8: "c1 =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and A9: "0NUMBERSK6 =XBOOLE-0R4 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
            using A5 quaterni_def_7 sorry
          obtain x19 x29 x39 x49 y19 y29 y39 y49 where
            [ty]:"x19 be RealXREAL-0M1" "x29 be RealXREAL-0M1" "x39 be RealXREAL-0M1" "x49 be RealXREAL-0M1" "y19 be RealXREAL-0M1" "y29 be RealXREAL-0M1" "y39 be RealXREAL-0M1" "y49 be RealXREAL-0M1" and 
            A10: "z =HIDDENR1 [*QUATERNIK5 x19,x29,x39,x49 *]"and A11: "c2 =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]"and A12: "0NUMBERSK6 =XBOOLE-0R4 [*QUATERNIK5 x19 +XCMPLX-0K2 y19,x29 +XCMPLX-0K2 y29,x39 +XCMPLX-0K2 y39,x49 +XCMPLX-0K2 y49 *]"
            using A6 quaterni_def_7 sorry
          have A13: "x1 =COMPLEX1R1 x19"
            using A7 A10 quaterni_th_12 sorry
          have A14: "x2 =COMPLEX1R1 x29"
            using A7 A10 quaterni_th_12 sorry
          have A15: "x3 =COMPLEX1R1 x39"
            using A7 A10 quaterni_th_12 sorry
          have A16: "x4 =COMPLEX1R1 x49"
            using A7 A10 quaterni_th_12 sorry
          have A17: "x1 +XCMPLX-0K2 y1 =COMPLEX1R1 0NUMBERSK6"
            using A9 quaterni_lm_5 quaterni_th_12 sorry
          have A18: "x1 +XCMPLX-0K2 y19 =COMPLEX1R1 0NUMBERSK6"
            using A12 A13 quaterni_lm_5 quaterni_th_12 sorry
          have A19: "x2 +XCMPLX-0K2 y2 =COMPLEX1R1 0NUMBERSK6"
            using A9 quaterni_lm_5 quaterni_th_12 sorry
          have A20: "x2 +XCMPLX-0K2 y29 =COMPLEX1R1 0NUMBERSK6"
            using A12 A14 quaterni_lm_5 quaterni_th_12 sorry
          have A21: "x3 +XCMPLX-0K2 y3 =COMPLEX1R1 0NUMBERSK6"
            using A9 quaterni_lm_5 quaterni_th_12 sorry
          have A22: "x3 +XCMPLX-0K2 y39 =COMPLEX1R1 0NUMBERSK6"
            using A12 A15 quaterni_lm_5 quaterni_th_12 sorry
          have A23: "x4 +XCMPLX-0K2 y4 =COMPLEX1R1 0NUMBERSK6"
            using A9 quaterni_lm_5 quaterni_th_12 sorry
          have "x4 +XCMPLX-0K2 y49 =COMPLEX1R1 0NUMBERSK6"
            using A12 A16 quaterni_lm_5 quaterni_th_12 sorry
          thus "c1 =HIDDENR1 c2"
            using A8 A11 A17 A18 A19 A20 A21 A22 A23 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem QUATERNIK7_involutiveness:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK7 (-QUATERNIK7 z) =HIDDENR1 z"
proof-
  have " for it be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds it =HIDDENR1 -QUATERNIK7 z implies z =HIDDENR1 -QUATERNIK7 it"
  proof-
    obtain v w x y where
      [ty]:"v be RealXREAL-0M1" "w be RealXREAL-0M1" "x be RealXREAL-0M1" "y be RealXREAL-0M1" and 
      A1: "z =HIDDENR1 [*QUATERNIK5 v,w,x,y *]"
      using quaterni_th_7 sorry
    have " for it be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds z +QUATERNIK6 it =HIDDENR1 0NUMBERSK6 implies it +QUATERNIK6 z =HIDDENR1 0NUMBERSK6"
       sorry
    thus " ?thesis "
      using quaterni_def_8 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef quaterni_def_9 (" _ -QUATERNIK8  _ " [132,132]132 ) where
  mlet "x be QuaternionQUATERNIM1", "y be QuaternionQUATERNIM1"
"func x -QUATERNIK8 y \<rightarrow> NumberORDINAL1M1 equals
  x +QUATERNIK6 (-QUATERNIK7 y)"
proof-
  (*coherence*)
    show "x +QUATERNIK6 (-QUATERNIK7 y) be NumberORDINAL1M1"
       sorry
qed "sorry"

mdef quaterni_def_10 (" _ *QUATERNIK9  _ " [164,164]164 ) where
  mlet "x be QuaternionQUATERNIM1", "y be QuaternionQUATERNIM1"
"func x *QUATERNIK9 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
    proof-
      obtain x1 x2 x3 x4 where
        [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" and 
        A1: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"
        using quaterni_th_7 sorry
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A2: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " ex it be NumberORDINAL1M1 st  ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
      proof-
        have " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not ((x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & IT =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]))"
        proof-
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1" and ITDef:"IT = [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
             sorry
          show " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not ((x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & IT =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]))"
          proof(rule bexI[of _ "IT"])
            show " not ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds  for x4 be RealXREAL-0M1 holds  for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not ((x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & IT =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]))"
              using A1 A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it1 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]) & ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it2 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]) implies it1 =HIDDENR1 it2"
    proof-
      obtain x1 x2 x3 x4 where
        [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" and 
        A1: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"
        using quaterni_th_7 sorry
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A2: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it1 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]) & ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & it2 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]) implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be NumberORDINAL1M1 holds  for c2 be NumberORDINAL1M1 holds ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & c1 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]) implies (( ex x19 be RealXREAL-0M1 st  ex x29 be RealXREAL-0M1 st  ex x39 be RealXREAL-0M1 st  ex x49 be RealXREAL-0M1 st  ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x19,x29,x39,x49 *] & y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]) & c2 =HIDDENR1 [*QUATERNIK5 ((x19 *XCMPLX-0K3 y19 -XCMPLX-0K6 x29 *XCMPLX-0K3 y29)-XCMPLX-0K6 x39 *XCMPLX-0K3 y39)-XCMPLX-0K6 x49 *XCMPLX-0K3 y49,((x19 *XCMPLX-0K3 y29 +XCMPLX-0K2 x29 *XCMPLX-0K3 y19)+XCMPLX-0K2 x39 *XCMPLX-0K3 y49)-XCMPLX-0K6 x49 *XCMPLX-0K3 y39,((x19 *XCMPLX-0K3 y39 +XCMPLX-0K2 y19 *XCMPLX-0K3 x39)+XCMPLX-0K2 y29 *XCMPLX-0K3 x49)-XCMPLX-0K6 y49 *XCMPLX-0K3 x29,((x19 *XCMPLX-0K3 y49 +XCMPLX-0K2 x49 *XCMPLX-0K3 y19)+XCMPLX-0K2 x29 *XCMPLX-0K3 y39)-XCMPLX-0K6 x39 *XCMPLX-0K3 y29 *]) implies c1 =HIDDENR1 c2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix c1 assume [ty]: "c1 be NumberORDINAL1M1"
          fix c2 assume [ty]: "c2 be NumberORDINAL1M1"
          assume Given: " ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & c1 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
          then obtain x1 x2 x3 x4 y1 y2 y3 y4 where
            [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" "y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
            A3: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"and A4: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and A5: "c1 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
             sorry
          assume Given: " ex x19 be RealXREAL-0M1 st  ex x29 be RealXREAL-0M1 st  ex x39 be RealXREAL-0M1 st  ex x49 be RealXREAL-0M1 st  ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st (x =HIDDENR1 [*QUATERNIK5 x19,x29,x39,x49 *] & y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]) & c2 =HIDDENR1 [*QUATERNIK5 ((x19 *XCMPLX-0K3 y19 -XCMPLX-0K6 x29 *XCMPLX-0K3 y29)-XCMPLX-0K6 x39 *XCMPLX-0K3 y39)-XCMPLX-0K6 x49 *XCMPLX-0K3 y49,((x19 *XCMPLX-0K3 y29 +XCMPLX-0K2 x29 *XCMPLX-0K3 y19)+XCMPLX-0K2 x39 *XCMPLX-0K3 y49)-XCMPLX-0K6 x49 *XCMPLX-0K3 y39,((x19 *XCMPLX-0K3 y39 +XCMPLX-0K2 y19 *XCMPLX-0K3 x39)+XCMPLX-0K2 y29 *XCMPLX-0K3 x49)-XCMPLX-0K6 y49 *XCMPLX-0K3 x29,((x19 *XCMPLX-0K3 y49 +XCMPLX-0K2 x49 *XCMPLX-0K3 y19)+XCMPLX-0K2 x29 *XCMPLX-0K3 y39)-XCMPLX-0K6 x39 *XCMPLX-0K3 y29 *]"
          then obtain x19 x29 x39 x49 y19 y29 y39 y49 where
            [ty]:"x19 be RealXREAL-0M1" "x29 be RealXREAL-0M1" "x39 be RealXREAL-0M1" "x49 be RealXREAL-0M1" "y19 be RealXREAL-0M1" "y29 be RealXREAL-0M1" "y39 be RealXREAL-0M1" "y49 be RealXREAL-0M1" and 
            A6: "x =HIDDENR1 [*QUATERNIK5 x19,x29,x39,x49 *]"and A7: "y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]"and A8: "c2 =HIDDENR1 [*QUATERNIK5 ((x19 *XCMPLX-0K3 y19 -XCMPLX-0K6 x29 *XCMPLX-0K3 y29)-XCMPLX-0K6 x39 *XCMPLX-0K3 y39)-XCMPLX-0K6 x49 *XCMPLX-0K3 y49,((x19 *XCMPLX-0K3 y29 +XCMPLX-0K2 x29 *XCMPLX-0K3 y19)+XCMPLX-0K2 x39 *XCMPLX-0K3 y49)-XCMPLX-0K6 x49 *XCMPLX-0K3 y39,((x19 *XCMPLX-0K3 y39 +XCMPLX-0K2 y19 *XCMPLX-0K3 x39)+XCMPLX-0K2 y29 *XCMPLX-0K3 x49)-XCMPLX-0K6 y49 *XCMPLX-0K3 x29,((x19 *XCMPLX-0K3 y49 +XCMPLX-0K2 x49 *XCMPLX-0K3 y19)+XCMPLX-0K2 x29 *XCMPLX-0K3 y39)-XCMPLX-0K6 x39 *XCMPLX-0K3 y29 *]"
             sorry
          have A9: "x1 =COMPLEX1R1 x19"
            using A3 A6 quaterni_th_12 sorry
          have A10: "x2 =COMPLEX1R1 x29"
            using A3 A6 quaterni_th_12 sorry
          have A11: "x3 =COMPLEX1R1 x39"
            using A3 A6 quaterni_th_12 sorry
          have A12: "x4 =COMPLEX1R1 x49"
            using A3 A6 quaterni_th_12 sorry
          have A13: "y1 =COMPLEX1R1 y19"
            using A4 A7 quaterni_th_12 sorry
          have A14: "y2 =COMPLEX1R1 y29"
            using A4 A7 quaterni_th_12 sorry
          have A15: "y3 =COMPLEX1R1 y39"
            using A4 A7 quaterni_th_12 sorry
          have "y4 =COMPLEX1R1 y49"
            using A4 A7 quaterni_th_12 sorry
          thus "c1 =HIDDENR1 c2"
            using A5 A8 A9 A10 A11 A12 A13 A14 A15 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem quaterni_cl_7:
  mlet "z be QuaternionQUATERNIM1", "z9 be QuaternionQUATERNIM1"
"cluster z +QUATERNIK6 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "z +QUATERNIK6 z9 be quaternionQUATERNIV1"
  proof-
    have " ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (z =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & z9 =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & z +QUATERNIK6 z9 =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
      using quaterni_def_7 sorry
    thus "z +QUATERNIK6 z9 be quaternionQUATERNIV1"
       sorry
  qed
qed "sorry"

mtheorem quaterni_cl_8:
  mlet "z be QuaternionQUATERNIM1", "z9 be QuaternionQUATERNIM1"
"cluster z *QUATERNIK9 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "z *QUATERNIK9 z9 be quaternionQUATERNIV1"
  proof-
    have Cut778: " ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st  ex x3 be RealXREAL-0M1 st  ex x4 be RealXREAL-0M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st (z =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *] & z9 =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]) & z *QUATERNIK9 z9 =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
      using quaterni_def_10 sorry
    have "z *QUATERNIK9 z9 inHIDDENR3 QUATERNIONQUATERNIK1"
    proof-
      show "z *QUATERNIK9 z9 inHIDDENR3 QUATERNIONQUATERNIK1"
        using Cut778 sorry
    qed
    thus "z *QUATERNIK9 z9 be quaternionQUATERNIV1"
      using quaterni_def_2 sorry
  qed
qed "sorry"

abbreviation(input) QUATERNIK10("<j>QUATERNIK10" 164) where
  "<j>QUATERNIK10 \<equiv> <j>QUATERNIK3"

mtheorem quaterni_def_11:
"redefine func <j>QUATERNIK10 \<rightarrow> ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 equals
  [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6 *]"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds it =HIDDENR1 <j>QUATERNIK10 iff it =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6 *]"
    using quaterni_def_6 sorry
qed "sorry"

mtheorem quaterni_add_2:
"cluster <j>QUATERNIK3 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "<j>QUATERNIK3 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

abbreviation(input) QUATERNIK11("<k>QUATERNIK11" 164) where
  "<k>QUATERNIK11 \<equiv> <k>QUATERNIK4"

mtheorem quaterni_def_12:
"redefine func <k>QUATERNIK11 \<rightarrow> ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 equals
  [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M *]"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 holds it =HIDDENR1 <k>QUATERNIK11 iff it =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M *]"
    using quaterni_def_6 sorry
qed "sorry"

mtheorem quaterni_add_3:
"cluster <k>QUATERNIK4 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "<k>QUATERNIK4 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mtheorem quaterni_th_13:
"(<i>XCMPLX-0K1)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 zz,jj,zz,zz *]"
    using Lm2 quaterni_lm_2 sorry
  then have A1: "(<i>XCMPLX-0K1)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 -XCMPLX-0K4 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  finally have "(<i>XCMPLX-0K1)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 -XCMPLX-0K4 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  have "-XCMPLX-0K4 \<one>\<^sub>M =COMPLEX1R1 [*ARYTM-0K5 -REAL-1K1 jj,zz *]"
    using arytm_0_def_5 sorry
  thus "(<i>XCMPLX-0K1)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    using A1 quaterni_lm_2 sorry
qed

mtheorem quaterni_th_14:
"(<j>QUATERNIK10)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have A1: "(<j>QUATERNIK10)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 -XCMPLX-0K4 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  finally have "(<j>QUATERNIK10)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 -XCMPLX-0K4 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  have "[*QUATERNIK5 -XCMPLX-0K4 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 -REAL-1K1 jj,zz *]"
    using quaterni_lm_2 sorry
  thus "(<j>QUATERNIK10)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    using A1 arytm_0_def_5 sorry
qed

mtheorem quaterni_th_15:
"(<k>QUATERNIK11)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have A1: "(<k>QUATERNIK11)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 -XCMPLX-0K4 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  finally have "(<k>QUATERNIK11)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 -XCMPLX-0K4 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  have "-XCMPLX-0K4 \<one>\<^sub>M =COMPLEX1R1 [*ARYTM-0K5 -REAL-1K1 jj,zz *]"
    using arytm_0_def_5 sorry
  thus "(<k>QUATERNIK11)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    using A1 quaterni_lm_2 sorry
qed

mtheorem quaterni_th_16:
"(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 <k>QUATERNIK11"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6 *]"
    using Lm2 quaterni_lm_2 sorry
  then have "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M *]"
     sorry
  finally have "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M *]"
     sorry
  thus "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 <k>QUATERNIK11"
     sorry
qed

mtheorem quaterni_th_17:
"(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 <i>XCMPLX-0K1"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  finally have "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  thus "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 <i>XCMPLX-0K1"
    using Lm2 quaterni_lm_2 sorry
qed

mtheorem quaterni_th_18:
"(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 <j>QUATERNIK10"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6 *]"
    using Lm2 quaterni_lm_2 sorry
  then have "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6 *]"
     sorry
  finally have "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6 *]"
     sorry
  thus "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 <j>QUATERNIK10"
     sorry
qed

mtheorem quaterni_th_19:
"(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 -QUATERNIK7 (<j>QUATERNIK10)*QUATERNIK9 (<i>XCMPLX-0K1)"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have A1: "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 zz,jj,zz,zz *]"
    using Lm2 quaterni_lm_2 sorry
  then have A2: "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 zz,zz,zz,jj *]"
     sorry
  finally have "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 zz,zz,zz,jj *]"
     sorry
  have "(<j>QUATERNIK10)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M *]"
    using A1 quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 zz,zz,zz,-REAL-1K1 jj *]"
     sorry
  finally have "(<j>QUATERNIK10)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 zz,zz,zz,-REAL-1K1 jj *]"
     sorry
  then have "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) +QUATERNIK6 (<j>QUATERNIK10)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) *]"
    using A2 quaterni_def_7 sorry
  also have "... = 0NUMBERSK6"
    using quaterni_lm_5 sorry
  finally have "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) +QUATERNIK6 (<j>QUATERNIK10)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 0NUMBERSK6"
     sorry
  thus "(<i>XCMPLX-0K1)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 -QUATERNIK7 (<j>QUATERNIK10)*QUATERNIK9 (<i>XCMPLX-0K1)"
    using quaterni_def_8 sorry
qed

mtheorem quaterni_th_20:
"(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 -QUATERNIK7 (<k>QUATERNIK11)*QUATERNIK9 (<j>QUATERNIK10)"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have A1: "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 zz,jj,zz,zz *]"
     sorry
  finally have "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 zz,jj,zz,zz *]"
     sorry
  have "(<k>QUATERNIK11)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 zz,-REAL-1K1 jj,zz,zz *]"
     sorry
  finally have "(<k>QUATERNIK11)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 zz,-REAL-1K1 jj,zz,zz *]"
     sorry
  then have "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) +QUATERNIK6 (<k>QUATERNIK11)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) *]"
    using A1 quaterni_def_7 sorry
  also have "... = 0NUMBERSK6"
    using quaterni_lm_5 sorry
  finally have "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) +QUATERNIK6 (<k>QUATERNIK11)*QUATERNIK9 (<j>QUATERNIK10) =HIDDENR1 0NUMBERSK6"
     sorry
  thus "(<j>QUATERNIK10)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 -QUATERNIK7 (<k>QUATERNIK11)*QUATERNIK9 (<j>QUATERNIK10)"
    using quaterni_def_8 sorry
qed

mtheorem quaterni_th_21:
"(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 -QUATERNIK7 (<i>XCMPLX-0K1)*QUATERNIK9 (<k>QUATERNIK11)"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have A1: "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 zz,jj,zz,zz *]"
    using Lm2 quaterni_lm_2 sorry
  then have A2: "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M *]"
    using quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 zz,zz,jj,zz *]"
     sorry
  finally have "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 zz,zz,jj,zz *]"
     sorry
  have "(<i>XCMPLX-0K1)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 (((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6),(((0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M,(((0NUMBERSK6)*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6))-XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) *]"
    using A1 quaterni_def_10 sorry
  also have "... = [*QUATERNIK5 zz,zz,-REAL-1K1 jj,zz *]"
     sorry
  finally have "(<i>XCMPLX-0K1)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 zz,zz,-REAL-1K1 jj,zz *]"
     sorry
  then have "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) +QUATERNIK6 (<i>XCMPLX-0K1)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6,\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M),0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 *]"
    using A2 quaterni_def_7 sorry
  also have "... = 0NUMBERSK6"
    using quaterni_lm_5 sorry
  finally have "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) +QUATERNIK6 (<i>XCMPLX-0K1)*QUATERNIK9 (<k>QUATERNIK11) =HIDDENR1 0NUMBERSK6"
     sorry
  thus "(<k>QUATERNIK11)*QUATERNIK9 (<i>XCMPLX-0K1) =HIDDENR1 -QUATERNIK7 (<i>XCMPLX-0K1)*QUATERNIK9 (<k>QUATERNIK11)"
    using quaterni_def_8 sorry
qed

mdef quaterni_def_13 ("ReaQUATERNIK12  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func ReaQUATERNIK12 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ReCOMPLEX1K3 z9 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ReCOMPLEX1K3 z9)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)))"
    proof-
      have "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & IT =HIDDENR1 ReCOMPLEX1K3 z9)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar24 be NumberORDINAL1M1 st  ex tVar25 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar25 & tVar25 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 tVar25 .FUNCT-1K1 (0NUMBERSK6)))"
      proof(rule conjMI,rule impI)
        show "z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & IT =HIDDENR1 ReCOMPLEX1K3 z9)"
        proof-
          have "z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar22 be NumberORDINAL1M1 st  ex tVar23 be ComplexXCMPLX-0M1 st z =HIDDENR1 tVar23 & ReCOMPLEX1K3 tVar23 =HIDDENR1 ReCOMPLEX1K3 tVar23)"
          proof(rule impI)
            assume "z inHIDDENR3 COMPLEXNUMBERSK3"
            then obtain r s where
              [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" "s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A1: "z =HIDDENR1 [*ARYTM-0K5 r,s *]"
              using arytm_0_th_9 sorry
            let ?z9 = "[*ARYTM-0K5 r,s *]"
            show " ex tVar22 be NumberORDINAL1M1 st  ex tVar23 be ComplexXCMPLX-0M1 st z =HIDDENR1 tVar23 & ReCOMPLEX1K3 tVar23 =HIDDENR1 ReCOMPLEX1K3 tVar23"
            proof(rule bexI[of _ "ReCOMPLEX1K3 ?z9"])
              show " ex tVar23 be ComplexXCMPLX-0M1 st z =HIDDENR1 tVar23 & ReCOMPLEX1K3 tVar23 =HIDDENR1 ReCOMPLEX1K3 tVar23"
              proof(rule bexI[of _ "?z9"])
                show "z =HIDDENR1 [*ARYTM-0K5 r,s *] & ReCOMPLEX1K3 ([*ARYTM-0K5 r,s *]) =HIDDENR1 ReCOMPLEX1K3 ([*ARYTM-0K5 r,s *])"
                  using A1 sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        assume A2: " not z inHIDDENR3 COMPLEXNUMBERSK3"
        have "z inHIDDENR3 QUATERNIONQUATERNIK1"
          using quaterni_def_2 sorry
        then have "z inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
          using A2 xboole_0_def_3 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using funct_2_th_66 sorry
        show " ex tVar24 be NumberORDINAL1M1 st  ex tVar25 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar25 & tVar25 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 tVar25 .FUNCT-1K1 (0NUMBERSK6)"
        proof(rule bexI[of _ "f .FUNCT-1K1 (0NUMBERSK6)"])
          show " ex tVar25 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar25 & tVar25 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 tVar25 .FUNCT-1K1 (0NUMBERSK6)"
          proof(rule bexI[of _ "f"])
            show "z =HIDDENR1 f & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it1 =HIDDENR1 ReCOMPLEX1K3 z9) & ( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it2 =HIDDENR1 ReCOMPLEX1K3 z9) implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mdef quaterni_def_14 ("Im1QUATERNIK13  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func Im1QUATERNIK13 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ImCOMPLEX1K4 z9 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it =HIDDENR1 ImCOMPLEX1K4 z9)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M))"
    proof-
      have "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & IT =HIDDENR1 ImCOMPLEX1K4 z9)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar28 be NumberORDINAL1M1 st  ex tVar29 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar29 & tVar29 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 tVar29 .FUNCT-1K1 \<one>\<^sub>M))"
      proof(rule conjMI,rule impI)
        show "z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st  ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & IT =HIDDENR1 ImCOMPLEX1K4 z9)"
        proof-
          have "z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar26 be NumberORDINAL1M1 st  ex tVar27 be ComplexXCMPLX-0M1 st z =HIDDENR1 tVar27 & ImCOMPLEX1K4 tVar27 =HIDDENR1 ImCOMPLEX1K4 tVar27)"
          proof(rule impI)
            assume "z inHIDDENR3 COMPLEXNUMBERSK3"
            then obtain r s where
              [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" "s be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A3: "z =HIDDENR1 [*ARYTM-0K5 r,s *]"
              using arytm_0_th_9 sorry
            let ?z9 = "[*ARYTM-0K5 r,s *]"
            show " ex tVar26 be NumberORDINAL1M1 st  ex tVar27 be ComplexXCMPLX-0M1 st z =HIDDENR1 tVar27 & ImCOMPLEX1K4 tVar27 =HIDDENR1 ImCOMPLEX1K4 tVar27"
            proof(rule bexI[of _ "ImCOMPLEX1K4 ?z9"])
              show " ex tVar27 be ComplexXCMPLX-0M1 st z =HIDDENR1 tVar27 & ImCOMPLEX1K4 tVar27 =HIDDENR1 ImCOMPLEX1K4 tVar27"
              proof(rule bexI[of _ "?z9"])
                show "z =HIDDENR1 [*ARYTM-0K5 r,s *] & ImCOMPLEX1K4 ([*ARYTM-0K5 r,s *]) =HIDDENR1 ImCOMPLEX1K4 ([*ARYTM-0K5 r,s *])"
                  using A3 sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        assume A4: " not z inHIDDENR3 COMPLEXNUMBERSK3"
        have "z inHIDDENR3 QUATERNIONQUATERNIK1"
          using quaterni_def_2 sorry
        then have "z inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
          using A4 xboole_0_def_3 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using funct_2_th_66 sorry
        show " ex tVar28 be NumberORDINAL1M1 st  ex tVar29 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar29 & tVar29 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 tVar29 .FUNCT-1K1 \<one>\<^sub>M"
        proof(rule bexI[of _ "f .FUNCT-1K1 \<one>\<^sub>M"])
          show " ex tVar29 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar29 & tVar29 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 tVar29 .FUNCT-1K1 \<one>\<^sub>M"
          proof(rule bexI[of _ "f"])
            show "z =HIDDENR1 f & f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it1 =HIDDENR1 ImCOMPLEX1K4 z9) & ( ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & it2 =HIDDENR1 ImCOMPLEX1K4 z9) implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mdef quaterni_def_15 ("Im2QUATERNIK14  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func Im2QUATERNIK14 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it. it =HIDDENR1 0NUMBERSK6 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st it =HIDDENR1 0NUMBERSK6)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M))"
    proof-
      have "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st IT =HIDDENR1 0NUMBERSK6)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar30 be NumberORDINAL1M1 st  ex tVar31 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar31 & tVar31 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 tVar31 .FUNCT-1K1 \<two>\<^sub>M))"
      proof(rule conjMI,rule impI)
        show "z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st IT =HIDDENR1 0NUMBERSK6)"
           sorry
        assume A5: " not z inHIDDENR3 COMPLEXNUMBERSK3"
        have "z inHIDDENR3 QUATERNIONQUATERNIK1"
          using quaterni_def_2 sorry
        then have "z inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
          using A5 xboole_0_def_3 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using funct_2_th_66 sorry
        show " ex tVar30 be NumberORDINAL1M1 st  ex tVar31 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar31 & tVar31 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 tVar31 .FUNCT-1K1 \<two>\<^sub>M"
        proof(rule bexI[of _ "f .FUNCT-1K1 \<two>\<^sub>M"])
          show " ex tVar31 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar31 & tVar31 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 tVar31 .FUNCT-1K1 \<two>\<^sub>M"
          proof(rule bexI[of _ "f"])
            show "z =HIDDENR1 f & f .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mdef quaterni_def_16 ("Im3QUATERNIK15  _ " [164]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func Im3QUATERNIK15 z \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it. it =HIDDENR1 0NUMBERSK6 if z inHIDDENR3 COMPLEXNUMBERSK3 otherwise \<lambda>it.  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M"
proof-
  (*existence*)
    show "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st it =HIDDENR1 0NUMBERSK6)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex it be NumberORDINAL1M1 st  ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M))"
    proof-
      have "(z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st IT =HIDDENR1 0NUMBERSK6)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex tVar32 be NumberORDINAL1M1 st  ex tVar33 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar33 & tVar33 .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 tVar33 .FUNCT-1K1 \<three>\<^sub>M))"
      proof(rule conjMI,rule impI)
        show "z inHIDDENR3 COMPLEXNUMBERSK3 implies ( ex IT be NumberORDINAL1M1 st IT =HIDDENR1 0NUMBERSK6)"
           sorry
        assume A6: " not z inHIDDENR3 COMPLEXNUMBERSK3"
        have "z inHIDDENR3 QUATERNIONQUATERNIK1"
          using quaterni_def_2 sorry
        then have "z inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
          using A6 xboole_0_def_3 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using funct_2_th_66 sorry
        show " ex tVar32 be NumberORDINAL1M1 st  ex tVar33 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar33 & tVar33 .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 tVar33 .FUNCT-1K1 \<three>\<^sub>M"
        proof(rule bexI[of _ "f .FUNCT-1K1 \<three>\<^sub>M"])
          show " ex tVar33 be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 tVar33 & tVar33 .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 tVar33 .FUNCT-1K1 \<three>\<^sub>M"
          proof(rule bexI[of _ "f"])
            show "z =HIDDENR1 f & f .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds (z inHIDDENR3 COMPLEXNUMBERSK3 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & ( not z inHIDDENR3 COMPLEXNUMBERSK3 implies (( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it1 =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M) & ( ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & it2 =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M) implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be NumberORDINAL1M1 holds  True "
       sorry
qed "sorry"

mtheorem quaterni_cl_9:
  mlet "z be QuaternionQUATERNIM1"
"cluster ReaQUATERNIK12 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "ReaQUATERNIK12 z be realXREAL-0V1"
  proof-
    show "ReaQUATERNIK12 z be realXREAL-0V1"
    proof-
      have cases: "z inHIDDENR3 COMPLEXNUMBERSK3 or  not z inHIDDENR3 COMPLEXNUMBERSK3"
         sorry
      have case1: "z inHIDDENR3 COMPLEXNUMBERSK3 implies ReaQUATERNIK12 z be realXREAL-0V1"
      proof(rule impI)
        assume "z inHIDDENR3 COMPLEXNUMBERSK3"
        then have " ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & ReaQUATERNIK12 z =HIDDENR1 ReCOMPLEX1K3 z9"
          using quaterni_def_13 sorry
        thus "ReaQUATERNIK12 z be realXREAL-0V1"
           sorry
      qed
      have case2: " not z inHIDDENR3 COMPLEXNUMBERSK3 implies ReaQUATERNIK12 z be realXREAL-0V1"
      proof(rule impI)
        assume " not z inHIDDENR3 COMPLEXNUMBERSK3"
        then have " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & ReaQUATERNIK12 z =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
          using quaterni_def_13 sorry
        thus "ReaQUATERNIK12 z be realXREAL-0V1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem quaterni_cl_10:
  mlet "z be QuaternionQUATERNIM1"
"cluster Im1QUATERNIK13 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "Im1QUATERNIK13 z be realXREAL-0V1"
  proof-
    show "Im1QUATERNIK13 z be realXREAL-0V1"
    proof-
      have cases: "z inHIDDENR3 COMPLEXNUMBERSK3 or  not z inHIDDENR3 COMPLEXNUMBERSK3"
         sorry
      have case1: "z inHIDDENR3 COMPLEXNUMBERSK3 implies Im1QUATERNIK13 z be realXREAL-0V1"
      proof(rule impI)
        assume "z inHIDDENR3 COMPLEXNUMBERSK3"
        then have " ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & Im1QUATERNIK13 z =HIDDENR1 ImCOMPLEX1K4 z9"
          using quaterni_def_14 sorry
        thus "Im1QUATERNIK13 z be realXREAL-0V1"
           sorry
      qed
      have case2: " not z inHIDDENR3 COMPLEXNUMBERSK3 implies Im1QUATERNIK13 z be realXREAL-0V1"
      proof(rule impI)
        assume " not z inHIDDENR3 COMPLEXNUMBERSK3"
        then have " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & Im1QUATERNIK13 z =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
          using quaterni_def_14 sorry
        thus "Im1QUATERNIK13 z be realXREAL-0V1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem quaterni_cl_11:
  mlet "z be QuaternionQUATERNIM1"
"cluster Im2QUATERNIK14 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "Im2QUATERNIK14 z be realXREAL-0V1"
  proof-
    show "Im2QUATERNIK14 z be realXREAL-0V1"
    proof-
      have cases: "z inHIDDENR3 COMPLEXNUMBERSK3 or  not z inHIDDENR3 COMPLEXNUMBERSK3"
         sorry
      have case1: "z inHIDDENR3 COMPLEXNUMBERSK3 implies Im2QUATERNIK14 z be realXREAL-0V1"
      proof(rule impI)
        assume "z inHIDDENR3 COMPLEXNUMBERSK3"
        thus "Im2QUATERNIK14 z be realXREAL-0V1"
          using quaterni_def_15 sorry
      qed
      have case2: " not z inHIDDENR3 COMPLEXNUMBERSK3 implies Im2QUATERNIK14 z be realXREAL-0V1"
      proof(rule impI)
        assume " not z inHIDDENR3 COMPLEXNUMBERSK3"
        then have " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & Im2QUATERNIK14 z =HIDDENR1 f .FUNCT-1K1 \<two>\<^sub>M"
          using quaterni_def_15 sorry
        thus "Im2QUATERNIK14 z be realXREAL-0V1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem quaterni_cl_12:
  mlet "z be QuaternionQUATERNIM1"
"cluster Im3QUATERNIK15 z as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "Im3QUATERNIK15 z be realXREAL-0V1"
  proof-
    show "Im3QUATERNIK15 z be realXREAL-0V1"
    proof-
      have cases: "z inHIDDENR3 COMPLEXNUMBERSK3 or  not z inHIDDENR3 COMPLEXNUMBERSK3"
         sorry
      have case1: "z inHIDDENR3 COMPLEXNUMBERSK3 implies Im3QUATERNIK15 z be realXREAL-0V1"
      proof(rule impI)
        assume "z inHIDDENR3 COMPLEXNUMBERSK3"
        thus "Im3QUATERNIK15 z be realXREAL-0V1"
          using quaterni_def_16 sorry
      qed
      have case2: " not z inHIDDENR3 COMPLEXNUMBERSK3 implies Im3QUATERNIK15 z be realXREAL-0V1"
      proof(rule impI)
        assume " not z inHIDDENR3 COMPLEXNUMBERSK3"
        then have " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & Im3QUATERNIK15 z =HIDDENR1 f .FUNCT-1K1 \<three>\<^sub>M"
          using quaterni_def_16 sorry
        thus "Im3QUATERNIK15 z be realXREAL-0V1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem quaterni_th_22:
" for f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) holds  ex a be RealXREAL-0M1 st  ex b be RealXREAL-0M1 st  ex c be RealXREAL-0M1 st  ex d be RealXREAL-0M1 st f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d)"
proof-
  have " for f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) holds  ex tVar34 be RealXREAL-0M1 st  ex tVar35 be RealXREAL-0M1 st  ex tVar36 be RealXREAL-0M1 st  ex tVar37 be RealXREAL-0M1 st f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(tVar34,tVar35,tVar36,tVar37)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)"
    obtain a b c d where 
      [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = f .FUNCT-1K1 (0NUMBERSK6)" and
      [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = f .FUNCT-1K1 \<one>\<^sub>M" and
      [ty]:"c be ElementSUBSET-1M1-of REALNUMBERSK2" and cDef:"c = f .FUNCT-1K1 \<two>\<^sub>M" and
      [ty]:"d be ElementSUBSET-1M1-of REALNUMBERSK2" and dDef:"d = f .FUNCT-1K1 \<three>\<^sub>M"
      using xreal_0_def_1 sorry
    show " ex tVar34 be RealXREAL-0M1 st  ex tVar35 be RealXREAL-0M1 st  ex tVar36 be RealXREAL-0M1 st  ex tVar37 be RealXREAL-0M1 st f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(tVar34,tVar35,tVar36,tVar37)"
    proof(rule bexI[of _ "a"])
      show " ex tVar35 be RealXREAL-0M1 st  ex tVar36 be RealXREAL-0M1 st  ex tVar37 be RealXREAL-0M1 st f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,tVar35,tVar36,tVar37)"
      proof(rule bexI[of _ "b"])
        show " ex tVar36 be RealXREAL-0M1 st  ex tVar37 be RealXREAL-0M1 st f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,tVar36,tVar37)"
        proof(rule bexI[of _ "c"])
          show " ex tVar37 be RealXREAL-0M1 st f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,tVar37)"
          proof(rule bexI[of _ "d"])
            have "domRELSET-1K1\<^bsub>(\<four>\<^sub>M)\<^esub> f =XBOOLE-0R4 {ENUMSET1K2 0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
              using card_1_th_52 funct_2_def_1 sorry
            thus "f =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d)"
              using funct_4_th_144 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_6:
" for a be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b be ElementSUBSET-1M1-of REALNUMBERSK2 holds ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a & ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 b"
proof(rule ballI,rule ballI,rule conjMI)
  fix a assume [ty]: "a be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix b assume [ty]: "b be ElementSUBSET-1M1-of REALNUMBERSK2"
  obtain a9 b9 where 
    [ty]:"a9 be ElementSUBSET-1M1-of REALNUMBERSK2" and a9Def:"a9 = a" and
    [ty]:"b9 be ElementSUBSET-1M1-of REALNUMBERSK2" and b9Def:"b9 = b"
     sorry
  show "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a"
  proof-
    show "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a"
    proof-
      have cases: "b =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "b =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a"
      proof(rule impI)
        assume "b =COMPLEX1R1 0NUMBERSK6"
        then have "[*ARYTM-0K5 a,b *] =COMPLEX1R1 a"
          using arytm_0_def_5 sorry
        thus "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a"
          using complex1_def_1 sorry
      qed
      have case2: "b <>HIDDENR2 0NUMBERSK6 implies ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a"
      proof(rule impI)
        assume "b <>HIDDENR2 0NUMBERSK6"
        then have A1: "[*ARYTM-0K5 a,b *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a9,b9)"
          using arytm_0_def_5 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*ARYTM-0K5 a,b *]"
          using card_1_th_50 sorry
        have " not [*ARYTM-0K5 a,b *] inTARSKIR2 REALNUMBERSK2"
          using A1 arytm_0_th_8 sorry
        then have a2: " not [*ARYTM-0K5 a,b *] be realXREAL-0V1"
          using xreal_0_def_1 sorry
        have "f .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 a"
          using A1 funct_4_th_63 sorry
        thus "ReCOMPLEX1K3 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 a"
          using a2 complex1_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  show "ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 b"
  proof-
    have cases: "b =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "b =COMPLEX1R1 0NUMBERSK6 implies ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 b"
    proof(rule impI)
      assume A3: "b =COMPLEX1R1 0NUMBERSK6"
      then have "[*ARYTM-0K5 a,b *] =COMPLEX1R1 a"
        using arytm_0_def_5 sorry
      thus "ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 b"
        using A3 complex1_def_2 sorry
    qed
    have case2: "b <>HIDDENR2 0NUMBERSK6 implies ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 b"
    proof(rule impI)
      assume "b <>HIDDENR2 0NUMBERSK6"
      then have A4: "[*ARYTM-0K5 a,b *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a9,b9)"
        using arytm_0_def_5 sorry
      then obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*ARYTM-0K5 a,b *]"
        using card_1_th_50 sorry
      have " not [*ARYTM-0K5 a,b *] inTARSKIR2 REALNUMBERSK2"
        using A4 arytm_0_th_8 sorry
      then have a5: " not [*ARYTM-0K5 a,b *] be realXREAL-0V1"
        using xreal_0_def_1 sorry
      have "f .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 b"
        using A4 funct_4_th_63 sorry
      thus "ImCOMPLEX1K4 ([*ARYTM-0K5 a,b *]) =COMPLEX1R1 b"
        using a5 complex1_def_2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mlemma quaterni_lm_7:
" for z be ComplexXCMPLX-0M1 holds [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =COMPLEX1R1 z"
proof-
  have " for z be ComplexXCMPLX-0M1 holds [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "z inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    show "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
    proof-
      have cases: "z inHIDDENR3 REALNUMBERSK2 or  not z inHIDDENR3 REALNUMBERSK2"
         sorry
      have case1: "z inHIDDENR3 REALNUMBERSK2 implies [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
      proof(rule impI)
        assume A2: "z inHIDDENR3 REALNUMBERSK2"
        then have "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
          using complex1_def_2 sorry
        then have "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 ReCOMPLEX1K3 z"
          using arytm_0_def_5 sorry
        also have "... = z"
          using A2 complex1_def_1 sorry
        finally show "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =HIDDENR1 z"
           sorry
      qed
      have case2: " not z inHIDDENR3 REALNUMBERSK2 implies [*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =COMPLEX1R1 z"
      proof(rule impI)
        assume A3: " not z inHIDDENR3 REALNUMBERSK2"
        then have a3: " not z be realXREAL-0V1"
          using xreal_0_def_1 sorry
        then have A4: " ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & ImCOMPLEX1K4 z =COMPLEX1R1 f .FUNCT-1K1 \<one>\<^sub>M"
          using complex1_def_2 sorry
        have A5: " ex f be FunctionFUNCT-2M1-of(\<two>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & ReCOMPLEX1K3 z =COMPLEX1R1 f .FUNCT-1K1 (0NUMBERSK6)"
          using a3 complex1_def_1 sorry
        obtain a b where
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" "b be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A6: "z =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(REALNUMBERSK2)\<^esub>(a,b)"
          using A4 complex1_th_2 sorry
        have A7: "ReCOMPLEX1K3 z =COMPLEX1R1 a"
          using A5 A6 funct_4_th_63 sorry
        have A8: "ImCOMPLEX1K4 z =COMPLEX1R1 b"
          using A4 A6 funct_4_th_63 sorry
        have "z inHIDDENR3 FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
          using A1 A3 card_1_th_50 numbers_def_2 xboole_0_def_3 sorry
        then have A9: " not z inHIDDENR3 {x where x be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }"
          using xboole_0_def_5 sorry
        obtain f where 
          [ty]:"f be ElementFUNCT-2M4\<^bsub>(\<two>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<two>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using A6 card_1_th_50 funct_2_th_8 sorry
        have "f .FUNCT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6"
          using A9 sorry
        then have "b <>HIDDENR2 0NUMBERSK6"
          using A6 funct_4_th_63 sorry
        thus "[*ARYTM-0K5 ReCOMPLEX1K3 z,ImCOMPLEX1K4 z *] =COMPLEX1R1 z"
          using A6 A7 A8 arytm_0_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_23:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a & Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b) & Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c) & Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a & (Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b & (Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c & Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    obtain aa bb c9 d9 where 
      [ty]:"aa be ElementSUBSET-1M1-of REALNUMBERSK2" and aaDef:"aa = a" and
      [ty]:"bb be ElementSUBSET-1M1-of REALNUMBERSK2" and bbDef:"bb = b" and
      [ty]:"c9 be ElementSUBSET-1M1-of REALNUMBERSK2" and c9Def:"c9 = c" and
      [ty]:"d9 be ElementSUBSET-1M1-of REALNUMBERSK2" and d9Def:"d9 = d"
      using xreal_0_def_1 sorry
    show "ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a"
    proof-
      show "ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a"
      proof-
        have cases: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 or (c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6)"
           sorry
        have case1: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 implies ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a"
        proof(rule impI)
          assume "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6"
          then have A1: "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 [*ARYTM-0K5 aa,bb *]"
            using quaterni_lm_2 sorry
          have "ReCOMPLEX1K3 ([*ARYTM-0K5 aa,bb *]) =COMPLEX1R1 a"
            using quaterni_lm_6 sorry
          thus "ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a"
            using A1 quaterni_def_13 sorry
        qed
        have case2: "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6 implies ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a"
        proof(rule impI)
          assume "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6"
          then have A2: "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(aa,bb,c9,d9)"
            using quaterni_def_6 sorry
          then obtain f where 
            [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*QUATERNIK5 a,b,c,d *]"
            using card_1_th_52 sorry
          have A3: " not [*QUATERNIK5 a,b,c,d *] inTARSKIR2 COMPLEXNUMBERSK3"
            using A2 quaterni_th_10 sorry
          have "f .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 a"
            using A2 funct_4_th_142 sorry
          thus "ReaQUATERNIK12 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 a"
            using A3 quaterni_def_13 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    show "Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b"
    proof-
      show "Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b"
      proof-
        have cases: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 or (c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6)"
           sorry
        have case1: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 implies Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b"
        proof(rule impI)
          assume "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6"
          then have A4: "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 [*ARYTM-0K5 aa,bb *]"
            using quaterni_lm_2 sorry
          have "ImCOMPLEX1K4 ([*ARYTM-0K5 aa,bb *]) =COMPLEX1R1 b"
            using quaterni_lm_6 sorry
          thus "Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b"
            using A4 quaterni_def_14 sorry
        qed
        have case2: "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6 implies Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b"
        proof(rule impI)
          assume "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6"
          then have A5: "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(aa,bb,c9,d9)"
            using quaterni_def_6 sorry
          then obtain f where 
            [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*QUATERNIK5 a,b,c,d *]"
            using card_1_th_52 sorry
          have A6: " not [*QUATERNIK5 a,b,c,d *] inTARSKIR2 COMPLEXNUMBERSK3"
            using A5 quaterni_th_10 sorry
          have "f .FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 b"
            using A5 funct_4_th_141 sorry
          thus "Im1QUATERNIK13 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 b"
            using A6 quaterni_def_14 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    show "Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c"
    proof-
      show "Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c"
      proof-
        have cases: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 or (c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6)"
           sorry
        have case1: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 implies Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c"
        proof(rule impI)
          assume A7: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6"
          then have "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 [*ARYTM-0K5 aa,bb *]"
            using quaterni_lm_2 sorry
          thus "Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c"
            using A7 quaterni_def_15 sorry
        qed
        have case2: "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6 implies Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c"
        proof(rule impI)
          assume "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6"
          then have A8: "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(aa,bb,c9,d9)"
            using quaterni_def_6 sorry
          then obtain f where 
            [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*QUATERNIK5 a,b,c,d *]"
            using card_1_th_52 sorry
          have A9: " not [*QUATERNIK5 a,b,c,d *] inTARSKIR2 COMPLEXNUMBERSK3"
            using A8 quaterni_th_10 sorry
          have "f .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 c"
            using A8 funct_4_th_140 sorry
          thus "Im2QUATERNIK14 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 c"
            using A9 quaterni_def_15 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    show "Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d"
    proof-
      have cases: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 or (c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6)"
         sorry
      have case1: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6 implies Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d"
      proof(rule impI)
        assume A10: "c =COMPLEX1R1 0NUMBERSK6 & d =COMPLEX1R1 0NUMBERSK6"
        then have "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 [*ARYTM-0K5 aa,bb *]"
          using quaterni_lm_2 sorry
        thus "Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d"
          using A10 quaterni_def_16 sorry
      qed
      have case2: "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6 implies Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d"
      proof(rule impI)
        assume "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6"
        then have A11: "[*QUATERNIK5 a,b,c,d *] =XBOOLE-0R4 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(aa,bb,c9,d9)"
          using quaterni_def_6 sorry
        then obtain f where 
          [ty]:"f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = [*QUATERNIK5 a,b,c,d *]"
          using card_1_th_52 sorry
        have A12: " not [*QUATERNIK5 a,b,c,d *] inTARSKIR2 COMPLEXNUMBERSK3"
          using A11 quaterni_th_10 sorry
        have "f .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 d"
          using A11 funct_4_th_139 sorry
        thus "Im3QUATERNIK15 ([*QUATERNIK5 a,b,c,d *]) =COMPLEX1R1 d"
          using A12 quaterni_def_16 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve z, z1, z2, z3, z4 for "QuaternionQUATERNIM1"
mtheorem quaterni_th_24:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
proof-
  have " for z be QuaternionQUATERNIM1 holds z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "z inHIDDENR3 QUATERNIONQUATERNIK1"
      using quaterni_def_2 sorry
    show "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
    proof-
      have cases: "z inHIDDENR3 COMPLEXNUMBERSK3 or  not z inHIDDENR3 COMPLEXNUMBERSK3"
         sorry
      have case1: "z inHIDDENR3 COMPLEXNUMBERSK3 implies z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
      proof(rule impI)
        assume A2: "z inHIDDENR3 COMPLEXNUMBERSK3"
        then have A3: "Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6"
          using quaterni_def_15 sorry
        have A4: "Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
          using A2 quaterni_def_16 sorry
        have A5: " ex z9 be ComplexXCMPLX-0M1 st z =HIDDENR1 z9 & ReaQUATERNIK12 z =COMPLEX1R1 ReCOMPLEX1K3 z9"
          using A2 quaterni_def_13 sorry
        obtain z9 where
          [ty]:"z9 be ComplexXCMPLX-0M1" and 
          A6: "z =HIDDENR1 z9"and A7: "Im1QUATERNIK13 z =COMPLEX1R1 ImCOMPLEX1K4 z9"
          using A2 quaterni_def_14 sorry
        obtain Rz Imz where 
          [ty]:"Rz be ElementSUBSET-1M1-of REALNUMBERSK2" and RzDef:"Rz = ReaQUATERNIK12 z" and
          [ty]:"Imz be ElementSUBSET-1M1-of REALNUMBERSK2" and ImzDef:"Imz = Im1QUATERNIK13 z"
          using xreal_0_def_1 sorry
        have "[*ARYTM-0K5 Rz,Imz *] =COMPLEX1R1 z9"
          using A5 A6 A7 quaterni_lm_7 sorry
        thus "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
          using A3 A4 A6 quaterni_lm_2 sorry
      qed
      have case2: " not z inHIDDENR3 COMPLEXNUMBERSK3 implies z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
      proof(rule impI)
        assume A8: " not z inHIDDENR3 COMPLEXNUMBERSK3"
        then have A9: " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & Im1QUATERNIK13 z =COMPLEX1R1 f .FUNCT-1K1 \<one>\<^sub>M"
          using quaterni_def_14 sorry
        have A10: " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & ReaQUATERNIK12 z =COMPLEX1R1 f .FUNCT-1K1 (0NUMBERSK6)"
          using A8 quaterni_def_13 sorry
        have A11: " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & Im2QUATERNIK14 z =COMPLEX1R1 f .FUNCT-1K1 \<two>\<^sub>M"
          using A8 quaterni_def_15 sorry
        have A12: " ex f be FunctionFUNCT-2M1-of(\<four>\<^sub>M,REALNUMBERSK2) st z =HIDDENR1 f & Im3QUATERNIK15 z =COMPLEX1R1 f .FUNCT-1K1 \<three>\<^sub>M"
          using A8 quaterni_def_16 sorry
        obtain a b c d where
          [ty]:"a be RealXREAL-0M1" "b be RealXREAL-0M1" "c be RealXREAL-0M1" "d be RealXREAL-0M1" and 
          A13: "z =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->FUNCT-4K12(a,b,c,d)"
          using A9 quaterni_th_22 sorry
        have 
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and
          [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and
          [ty]:"c be ElementSUBSET-1M1-of REALNUMBERSK2" and
          [ty]:"d be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A14: "z =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M)-->QUATERNIK2\<^bsub>(REALNUMBERSK2)\<^esub>(a,b,c,d)"
          using A13 sorry
        have A15: "ReaQUATERNIK12 z =COMPLEX1R1 a"
          using A10 A14 funct_4_th_142 sorry
        have A16: "Im1QUATERNIK13 z =COMPLEX1R1 b"
          using A9 A14 funct_4_th_141 sorry
        have A17: "Im2QUATERNIK14 z =COMPLEX1R1 c"
          using A11 A14 funct_4_th_140 sorry
        have A18: "Im3QUATERNIK15 z =COMPLEX1R1 d"
          using A12 A14 funct_4_th_139 sorry
        have "z inHIDDENR3 FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) \\SUBSET-1K6 ({x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 })"
          using A1 A8 xboole_0_def_3 sorry
        then have A19: " not z inHIDDENR3 {x where x be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2) : x .FUNCT-1K1 \<two>\<^sub>M =COMPLEX1R1 0NUMBERSK6 & x .FUNCT-1K1 \<three>\<^sub>M =COMPLEX1R1 0NUMBERSK6 }"
          using xboole_0_def_5 sorry
        obtain f where 
          [ty]:"f be ElementFUNCT-2M4\<^bsub>(\<four>\<^sub>M,REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9(\<four>\<^sub>M,REALNUMBERSK2)" and fDef:"f = z"
          using A14 card_1_th_52 funct_2_th_8 sorry
        have "f .FUNCT-1K1 \<two>\<^sub>M <>HIDDENR2 0NUMBERSK6 or f .FUNCT-1K1 \<three>\<^sub>M <>HIDDENR2 0NUMBERSK6"
          using A19 sorry
        then have "c <>HIDDENR2 0NUMBERSK6 or d <>HIDDENR2 0NUMBERSK6"
          using A14 funct_4_th_139 funct_4_th_140 sorry
        thus "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
          using A14 A15 A16 A17 A18 quaterni_def_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_25:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 z1 =COMPLEX1R1 ReaQUATERNIK12 z2 & Im1QUATERNIK13 z1 =COMPLEX1R1 Im1QUATERNIK13 z2) & Im2QUATERNIK14 z1 =COMPLEX1R1 Im2QUATERNIK14 z2) & Im3QUATERNIK15 z1 =COMPLEX1R1 Im3QUATERNIK15 z2 implies z1 =HIDDENR1 z2"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z1 =COMPLEX1R1 ReaQUATERNIK12 z2 & (Im1QUATERNIK13 z1 =COMPLEX1R1 Im1QUATERNIK13 z2 & (Im2QUATERNIK14 z1 =COMPLEX1R1 Im2QUATERNIK14 z2 & Im3QUATERNIK15 z1 =COMPLEX1R1 Im3QUATERNIK15 z2)) implies z1 =HIDDENR1 z2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    assume A1: "ReaQUATERNIK12 z1 =COMPLEX1R1 ReaQUATERNIK12 z2"
      and A2: "Im1QUATERNIK13 z1 =COMPLEX1R1 Im1QUATERNIK13 z2"
      and A3: "Im2QUATERNIK14 z1 =COMPLEX1R1 Im2QUATERNIK14 z2"
      and A4: "Im3QUATERNIK15 z1 =COMPLEX1R1 Im3QUATERNIK15 z2"
    have "z1 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z2,Im1QUATERNIK13 z2,Im2QUATERNIK14 z2,Im3QUATERNIK15 z2 *]"
      using A1 A2 A3 A4 quaterni_th_24 sorry
    also have "... = z2"
      using quaterni_th_24 sorry
    finally show "z1 =HIDDENR1 z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef quaterni_def_17 ("0qQUATERNIK16" 164 ) where
"func 0qQUATERNIK16 \<rightarrow> QuaternionQUATERNIM1 equals
  0NUMBERSK6"
proof-
  (*coherence*)
    show "0NUMBERSK6 be QuaternionQUATERNIM1"
      using quaterni_lm_5 sorry
qed "sorry"

mdef quaterni_def_18 ("1qQUATERNIK17" 164 ) where
"func 1qQUATERNIK17 \<rightarrow> QuaternionQUATERNIM1 equals
  \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<one>\<^sub>M be QuaternionQUATERNIM1"
    proof-
      obtain jj zz where 
        [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
        [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
        using xreal_0_def_1 sorry
      have "[*QUATERNIK5 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 jj,zz *]"
        using quaterni_lm_2 sorry
      thus "\<one>\<^sub>M be QuaternionQUATERNIM1"
        using arytm_0_def_5 sorry
    qed
qed "sorry"

mlemma quaterni_lm_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies ((a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6) & c =COMPLEX1R1 0NUMBERSK6) & d =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies (((a <>HIDDENR2 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6) or c <>HIDDENR2 0NUMBERSK6) or d <>HIDDENR2 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
    have A2: "0NUMBERSK6 <=XXREAL-0R1 a ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A3: "0NUMBERSK6 <=XXREAL-0R1 b ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A4: "0NUMBERSK6 <=XXREAL-0R1 c ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A5: "0NUMBERSK6 <=XXREAL-0R1 d ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    assume A6: "((a <>HIDDENR2 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6) or c <>HIDDENR2 0NUMBERSK6) or d <>HIDDENR2 0NUMBERSK6"
    show " False "
    proof-
      have cases: "((a <>HIDDENR2 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6) or c <>HIDDENR2 0NUMBERSK6) or d <>HIDDENR2 0NUMBERSK6"
        using A6 sorry
      have case1: "a <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "a <>HIDDENR2 0NUMBERSK6"
        then have "0NUMBERSK6 <XXREAL-0R3 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
          using A3 square_1_th_12 xreal_1_th_34 sorry
        thus " False "
          using A1 A4 A5 sorry
      qed
      have case2: "b <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "b <>HIDDENR2 0NUMBERSK6"
        then have "0NUMBERSK6 <XXREAL-0R3 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
          using A2 square_1_th_12 xreal_1_th_34 sorry
        thus " False "
          using A1 A4 A5 sorry
      qed
      have case3: "c <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "c <>HIDDENR2 0NUMBERSK6"
        then have "0NUMBERSK6 <XXREAL-0R3 c ^2SQUARE-1K1 +XCMPLX-0K2 d ^2SQUARE-1K1"
          using A5 square_1_th_12 xreal_1_th_34 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 (c ^2SQUARE-1K1 +XCMPLX-0K2 d ^2SQUARE-1K1)"
          using A2 A3 sorry
        thus " False "
          using A1 sorry
      qed
      have case4: "d <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "d <>HIDDENR2 0NUMBERSK6"
        then have "0NUMBERSK6 <XXREAL-0R3 c ^2SQUARE-1K1 +XCMPLX-0K2 d ^2SQUARE-1K1"
          using A4 square_1_th_12 xreal_1_th_34 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 (c ^2SQUARE-1K1 +XCMPLX-0K2 d ^2SQUARE-1K1)"
          using A2 A3 sorry
        thus " False "
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_26:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0qQUATERNIK16"
proof-
  have " for z be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6 & (Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6 & (Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6 & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6)) implies z =HIDDENR1 0qQUATERNIK16"
  proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: "ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6"
      and A2: "Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6"
      and A3: "Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6"
      and A4: "Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
    have A5: "ReaQUATERNIK12 z =COMPLEX1R1 ReaQUATERNIK12 ([*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *])"
      using A1 quaterni_th_23 sorry
    have A6: "Im1QUATERNIK13 z =COMPLEX1R1 Im1QUATERNIK13 ([*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *])"
      using A2 quaterni_th_23 sorry
    have A7: "Im2QUATERNIK14 z =COMPLEX1R1 Im2QUATERNIK14 ([*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *])"
      using A3 quaterni_th_23 sorry
    have "Im3QUATERNIK15 z =COMPLEX1R1 Im3QUATERNIK15 ([*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *])"
      using A4 quaterni_th_23 sorry
    thus "z =HIDDENR1 0qQUATERNIK16"
      using A5 A6 A7 quaterni_lm_5 quaterni_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_27:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 0NUMBERSK6 implies (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be QuaternionQUATERNIM1 holds z =HIDDENR1 0NUMBERSK6 implies (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: "z =HIDDENR1 0NUMBERSK6"
    then have A2: "ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6"
      using quaterni_lm_5 quaterni_th_23 sorry
    have A3: "Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have "Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    thus "(((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 quaterni_lm_5 quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_28:
" for z be QuaternionQUATERNIM1 holds (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0qQUATERNIK16"
proof-
  have " for z be QuaternionQUATERNIM1 holds (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0qQUATERNIK16"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: "(((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
    then have A2: "ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6"
      using quaterni_lm_8 sorry
    have A3: "Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_8 sorry
    have A4: "Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_8 sorry
    have "Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_8 sorry
    thus "z =HIDDENR1 0qQUATERNIK16"
      using A2 A3 A4 quaterni_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_29:
"((ReaQUATERNIK12 (1qQUATERNIK17) =COMPLEX1R1 \<one>\<^sub>M & Im1QUATERNIK13 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have "[*QUATERNIK5 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 jj,zz *]"
    using quaterni_lm_2 sorry
  then have Lm10: "[*QUATERNIK5 jj,zz,zz,zz *] =XBOOLE-0R4 \<one>\<^sub>M"
    using arytm_0_def_5 sorry
  thus "((ReaQUATERNIK12 (1qQUATERNIK17) =COMPLEX1R1 \<one>\<^sub>M & Im1QUATERNIK13 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (1qQUATERNIK17) =COMPLEX1R1 0NUMBERSK6"
    using quaterni_th_23 sorry
qed

mtheorem quaterni_th_30:
"((ReaQUATERNIK12 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<i>XCMPLX-0K1) =COMPLEX1R1 \<one>\<^sub>M) & Im2QUATERNIK14 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have "[*ARYTM-0K5 zz,jj *] =XBOOLE-0R4 [*QUATERNIK5 0NUMBERSK6,\<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6 *]"
    using quaterni_lm_2 sorry
  thus "((ReaQUATERNIK12 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<i>XCMPLX-0K1) =COMPLEX1R1 \<one>\<^sub>M) & Im2QUATERNIK14 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<i>XCMPLX-0K1) =COMPLEX1R1 0NUMBERSK6"
    using Lm2 quaterni_th_23 sorry
qed

mtheorem quaterni_th_31:
"((((((ReaQUATERNIK12 (<j>QUATERNIK10) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<j>QUATERNIK10) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<j>QUATERNIK10) =COMPLEX1R1 \<one>\<^sub>M) & Im3QUATERNIK15 (<j>QUATERNIK10) =COMPLEX1R1 0NUMBERSK6) & ReaQUATERNIK12 (<k>QUATERNIK11) =COMPLEX1R1 0NUMBERSK6) & Im1QUATERNIK13 (<k>QUATERNIK11) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<k>QUATERNIK11) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<k>QUATERNIK11) =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_23 sorry

mlemma quaterni_lm_9:
" for m be QuaternionQUATERNIM1 holds  for n be QuaternionQUATERNIM1 holds  for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds z =HIDDENR1 ((m +QUATERNIK6 n)+QUATERNIK6 x)+QUATERNIK6 y implies ((ReaQUATERNIK12 z =COMPLEX1R1 ((ReaQUATERNIK12 m +XCMPLX-0K2 ReaQUATERNIK12 n)+XCMPLX-0K2 ReaQUATERNIK12 x)+XCMPLX-0K2 ReaQUATERNIK12 y & Im1QUATERNIK13 z =COMPLEX1R1 ((Im1QUATERNIK13 m +XCMPLX-0K2 Im1QUATERNIK13 n)+XCMPLX-0K2 Im1QUATERNIK13 x)+XCMPLX-0K2 Im1QUATERNIK13 y) & Im2QUATERNIK14 z =COMPLEX1R1 ((Im2QUATERNIK14 m +XCMPLX-0K2 Im2QUATERNIK14 n)+XCMPLX-0K2 Im2QUATERNIK14 x)+XCMPLX-0K2 Im2QUATERNIK14 y) & Im3QUATERNIK15 z =COMPLEX1R1 ((Im3QUATERNIK15 m +XCMPLX-0K2 Im3QUATERNIK15 n)+XCMPLX-0K2 Im3QUATERNIK15 x)+XCMPLX-0K2 Im3QUATERNIK15 y"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix m assume [ty]: "m be QuaternionQUATERNIM1"
  fix n assume [ty]: "n be QuaternionQUATERNIM1"
  fix x assume [ty]: "x be QuaternionQUATERNIM1"
  fix y assume [ty]: "y be QuaternionQUATERNIM1"
  fix z assume [ty]: "z be QuaternionQUATERNIM1"
  assume A1: "z =HIDDENR1 ((m +QUATERNIK6 n)+QUATERNIK6 x)+QUATERNIK6 y"
  obtain m1 m2 m3 m4 n1 n2 n3 n4 where
    [ty]:"m1 be RealXREAL-0M1" "m2 be RealXREAL-0M1" "m3 be RealXREAL-0M1" "m4 be RealXREAL-0M1" "n1 be RealXREAL-0M1" "n2 be RealXREAL-0M1" "n3 be RealXREAL-0M1" "n4 be RealXREAL-0M1" and 
    A2: "m =HIDDENR1 [*QUATERNIK5 m1,m2,m3,m4 *]"and A3: "n =HIDDENR1 [*QUATERNIK5 n1,n2,n3,n4 *]"and A4: "m +QUATERNIK6 n =HIDDENR1 [*QUATERNIK5 m1 +XCMPLX-0K2 n1,m2 +XCMPLX-0K2 n2,m3 +XCMPLX-0K2 n3,m4 +XCMPLX-0K2 n4 *]"
    using quaterni_def_7 sorry
  obtain x1 x2 x3 x4 y1 y2 y3 y4 where
    [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" "y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
    A5: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"and A6: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and "x +QUATERNIK6 y =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
    using quaterni_def_7 sorry
  have A7: "ReaQUATERNIK12 m =COMPLEX1R1 m1"
    using A2 quaterni_th_23 sorry
  have A8: "ReaQUATERNIK12 n =COMPLEX1R1 n1"
    using A3 quaterni_th_23 sorry
  have A9: "ReaQUATERNIK12 x =COMPLEX1R1 x1"
    using A5 quaterni_th_23 sorry
  have A10: "ReaQUATERNIK12 y =COMPLEX1R1 y1"
    using A6 quaterni_th_23 sorry
  have A11: "Im1QUATERNIK13 m =COMPLEX1R1 m2"
    using A2 quaterni_th_23 sorry
  have A12: "Im1QUATERNIK13 n =COMPLEX1R1 n2"
    using A3 quaterni_th_23 sorry
  have A13: "Im1QUATERNIK13 x =COMPLEX1R1 x2"
    using A5 quaterni_th_23 sorry
  have A14: "Im1QUATERNIK13 y =COMPLEX1R1 y2"
    using A6 quaterni_th_23 sorry
  have A15: "Im2QUATERNIK14 m =COMPLEX1R1 m3"
    using A2 quaterni_th_23 sorry
  have A16: "Im2QUATERNIK14 n =COMPLEX1R1 n3"
    using A3 quaterni_th_23 sorry
  have A17: "Im2QUATERNIK14 x =COMPLEX1R1 x3"
    using A5 quaterni_th_23 sorry
  have A18: "Im2QUATERNIK14 y =COMPLEX1R1 y3"
    using A6 quaterni_th_23 sorry
  have A19: "Im3QUATERNIK15 m =COMPLEX1R1 m4"
    using A2 quaterni_th_23 sorry
  have A20: "Im3QUATERNIK15 n =COMPLEX1R1 n4"
    using A3 quaterni_th_23 sorry
  have A21: "Im3QUATERNIK15 x =COMPLEX1R1 x4"
    using A5 quaterni_th_23 sorry
  have A22: "Im3QUATERNIK15 y =COMPLEX1R1 y4"
    using A6 quaterni_th_23 sorry
  have "(m +QUATERNIK6 n)+QUATERNIK6 x =HIDDENR1 [*QUATERNIK5 (m1 +XCMPLX-0K2 n1)+XCMPLX-0K2 x1,(m2 +XCMPLX-0K2 n2)+XCMPLX-0K2 x2,(m3 +XCMPLX-0K2 n3)+XCMPLX-0K2 x3,(m4 +XCMPLX-0K2 n4)+XCMPLX-0K2 x4 *]"
    using A4 A5 quaterni_def_7 sorry
  then have "z =HIDDENR1 [*QUATERNIK5 ((m1 +XCMPLX-0K2 n1)+XCMPLX-0K2 x1)+XCMPLX-0K2 y1,((m2 +XCMPLX-0K2 n2)+XCMPLX-0K2 x2)+XCMPLX-0K2 y2,((m3 +XCMPLX-0K2 n3)+XCMPLX-0K2 x3)+XCMPLX-0K2 y3,((m4 +XCMPLX-0K2 n4)+XCMPLX-0K2 x4)+XCMPLX-0K2 y4 *]"
    using A1 A6 quaterni_def_7 sorry
  thus "((ReaQUATERNIK12 z =COMPLEX1R1 ((ReaQUATERNIK12 m +XCMPLX-0K2 ReaQUATERNIK12 n)+XCMPLX-0K2 ReaQUATERNIK12 x)+XCMPLX-0K2 ReaQUATERNIK12 y & Im1QUATERNIK13 z =COMPLEX1R1 ((Im1QUATERNIK13 m +XCMPLX-0K2 Im1QUATERNIK13 n)+XCMPLX-0K2 Im1QUATERNIK13 x)+XCMPLX-0K2 Im1QUATERNIK13 y) & Im2QUATERNIK14 z =COMPLEX1R1 ((Im2QUATERNIK14 m +XCMPLX-0K2 Im2QUATERNIK14 n)+XCMPLX-0K2 Im2QUATERNIK14 x)+XCMPLX-0K2 Im2QUATERNIK14 y) & Im3QUATERNIK15 z =COMPLEX1R1 ((Im3QUATERNIK15 m +XCMPLX-0K2 Im3QUATERNIK15 n)+XCMPLX-0K2 Im3QUATERNIK15 x)+XCMPLX-0K2 Im3QUATERNIK15 y"
    using A7 A8 A9 A10 A11 A12 A13 A14 A15 A16 A17 A18 A19 A20 A21 A22 quaterni_th_23 sorry
qed "sorry"

mlemma quaterni_lm_10:
" for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds z =HIDDENR1 x +QUATERNIK6 y implies ((ReaQUATERNIK12 z =COMPLEX1R1 ReaQUATERNIK12 x +XCMPLX-0K2 ReaQUATERNIK12 y & Im1QUATERNIK13 z =COMPLEX1R1 Im1QUATERNIK13 x +XCMPLX-0K2 Im1QUATERNIK13 y) & Im2QUATERNIK14 z =COMPLEX1R1 Im2QUATERNIK14 x +XCMPLX-0K2 Im2QUATERNIK14 y) & Im3QUATERNIK15 z =COMPLEX1R1 Im3QUATERNIK15 x +XCMPLX-0K2 Im3QUATERNIK15 y"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be QuaternionQUATERNIM1"
  fix y assume [ty]: "y be QuaternionQUATERNIM1"
  fix z assume [ty]: "z be QuaternionQUATERNIM1"
  assume A1: "z =HIDDENR1 x +QUATERNIK6 y"
  obtain x1 x2 x3 x4 y1 y2 y3 y4 where
    [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" "y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
    A2: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"and A3: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and A4: "x +QUATERNIK6 y =HIDDENR1 [*QUATERNIK5 x1 +XCMPLX-0K2 y1,x2 +XCMPLX-0K2 y2,x3 +XCMPLX-0K2 y3,x4 +XCMPLX-0K2 y4 *]"
    using quaterni_def_7 sorry
  have A5: "ReaQUATERNIK12 x =COMPLEX1R1 x1"
    using A2 quaterni_th_23 sorry
  have A6: "ReaQUATERNIK12 y =COMPLEX1R1 y1"
    using A3 quaterni_th_23 sorry
  have A7: "Im1QUATERNIK13 x =COMPLEX1R1 x2"
    using A2 quaterni_th_23 sorry
  have A8: "Im1QUATERNIK13 y =COMPLEX1R1 y2"
    using A3 quaterni_th_23 sorry
  have A9: "Im2QUATERNIK14 x =COMPLEX1R1 x3"
    using A2 quaterni_th_23 sorry
  have A10: "Im2QUATERNIK14 y =COMPLEX1R1 y3"
    using A3 quaterni_th_23 sorry
  have A11: "Im3QUATERNIK15 x =COMPLEX1R1 x4"
    using A2 quaterni_th_23 sorry
  have "Im3QUATERNIK15 y =COMPLEX1R1 y4"
    using A3 quaterni_th_23 sorry
  thus "((ReaQUATERNIK12 z =COMPLEX1R1 ReaQUATERNIK12 x +XCMPLX-0K2 ReaQUATERNIK12 y & Im1QUATERNIK13 z =COMPLEX1R1 Im1QUATERNIK13 x +XCMPLX-0K2 Im1QUATERNIK13 y) & Im2QUATERNIK14 z =COMPLEX1R1 Im2QUATERNIK14 x +XCMPLX-0K2 Im2QUATERNIK14 y) & Im3QUATERNIK15 z =COMPLEX1R1 Im3QUATERNIK15 x +XCMPLX-0K2 Im3QUATERNIK15 y"
    using A1 A4 A5 A6 A7 A8 A9 A10 A11 quaterni_th_23 sorry
qed "sorry"

mlemma quaterni_lm_11:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK6 z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK6 z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    let ?z = "[*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
    obtain z9 where 
      [ty]:"z9 be QuaternionQUATERNIM1" and z9Def:"z9 = z1 +QUATERNIK6 z2"
       sorry
    have A1: "ReaQUATERNIK12 ?z =HIDDENR1 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2"
      using quaterni_th_23 sorry
    also have "... = ReaQUATERNIK12 z9"
      using quaterni_lm_10 sorry
    finally have "ReaQUATERNIK12 ?z =HIDDENR1 ReaQUATERNIK12 z9"
       sorry
    have A2: "Im1QUATERNIK13 ?z =HIDDENR1 Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2"
      using quaterni_th_23 sorry
    also have "... = Im1QUATERNIK13 z9"
      using quaterni_lm_10 sorry
    finally have "Im1QUATERNIK13 ?z =HIDDENR1 Im1QUATERNIK13 z9"
       sorry
    have A3: "Im2QUATERNIK14 ?z =HIDDENR1 Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2"
      using quaterni_th_23 sorry
    also have "... = Im2QUATERNIK14 z9"
      using quaterni_lm_10 sorry
    finally have "Im2QUATERNIK14 ?z =HIDDENR1 Im2QUATERNIK14 z9"
       sorry
    have "Im3QUATERNIK15 ?z =HIDDENR1 Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2"
      using quaterni_th_23 sorry
    also have "... = Im3QUATERNIK15 z9"
      using quaterni_lm_10 sorry
    finally have "Im3QUATERNIK15 ?z =HIDDENR1 Im3QUATERNIK15 z9"
       sorry
    thus "z1 +QUATERNIK6 z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
      using A1 A2 A3 quaterni_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_12:
" for x be QuaternionQUATERNIM1 holds  for y be QuaternionQUATERNIM1 holds  for z be QuaternionQUATERNIM1 holds z =HIDDENR1 x *QUATERNIK9 y implies ((ReaQUATERNIK12 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (ReaQUATERNIK12 y) -XCMPLX-0K6 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im1QUATERNIK13 y))-XCMPLX-0K6 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im2QUATERNIK14 y))-XCMPLX-0K6 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im3QUATERNIK15 y) & Im1QUATERNIK13 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im1QUATERNIK13 y) +XCMPLX-0K2 (Im1QUATERNIK13 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im3QUATERNIK15 y))-XCMPLX-0K6 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im2QUATERNIK14 y)) & Im2QUATERNIK14 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im2QUATERNIK14 y) +XCMPLX-0K2 (Im2QUATERNIK14 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im1QUATERNIK13 y))-XCMPLX-0K6 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im3QUATERNIK15 y)) & Im3QUATERNIK15 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im3QUATERNIK15 y) +XCMPLX-0K2 (Im3QUATERNIK15 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im2QUATERNIK14 y))-XCMPLX-0K6 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im1QUATERNIK13 y)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be QuaternionQUATERNIM1"
  fix y assume [ty]: "y be QuaternionQUATERNIM1"
  fix z assume [ty]: "z be QuaternionQUATERNIM1"
  assume A1: "z =HIDDENR1 x *QUATERNIK9 y"
  obtain x1 x2 x3 x4 y1 y2 y3 y4 where
    [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" "x3 be RealXREAL-0M1" "x4 be RealXREAL-0M1" "y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
    A2: "x =HIDDENR1 [*QUATERNIK5 x1,x2,x3,x4 *]"and A3: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and A4: "x *QUATERNIK9 y =HIDDENR1 [*QUATERNIK5 ((x1 *XCMPLX-0K3 y1 -XCMPLX-0K6 x2 *XCMPLX-0K3 y2)-XCMPLX-0K6 x3 *XCMPLX-0K3 y3)-XCMPLX-0K6 x4 *XCMPLX-0K3 y4,((x1 *XCMPLX-0K3 y2 +XCMPLX-0K2 x2 *XCMPLX-0K3 y1)+XCMPLX-0K2 x3 *XCMPLX-0K3 y4)-XCMPLX-0K6 x4 *XCMPLX-0K3 y3,((x1 *XCMPLX-0K3 y3 +XCMPLX-0K2 y1 *XCMPLX-0K3 x3)+XCMPLX-0K2 y2 *XCMPLX-0K3 x4)-XCMPLX-0K6 y4 *XCMPLX-0K3 x2,((x1 *XCMPLX-0K3 y4 +XCMPLX-0K2 x4 *XCMPLX-0K3 y1)+XCMPLX-0K2 x2 *XCMPLX-0K3 y3)-XCMPLX-0K6 x3 *XCMPLX-0K3 y2 *]"
    using quaterni_def_10 sorry
  have A5: "ReaQUATERNIK12 x =COMPLEX1R1 x1"
    using A2 quaterni_th_23 sorry
  have A6: "ReaQUATERNIK12 y =COMPLEX1R1 y1"
    using A3 quaterni_th_23 sorry
  have A7: "Im1QUATERNIK13 x =COMPLEX1R1 x2"
    using A2 quaterni_th_23 sorry
  have A8: "Im1QUATERNIK13 y =COMPLEX1R1 y2"
    using A3 quaterni_th_23 sorry
  have A9: "Im2QUATERNIK14 x =COMPLEX1R1 x3"
    using A2 quaterni_th_23 sorry
  have A10: "Im2QUATERNIK14 y =COMPLEX1R1 y3"
    using A3 quaterni_th_23 sorry
  have A11: "Im3QUATERNIK15 x =COMPLEX1R1 x4"
    using A2 quaterni_th_23 sorry
  have "Im3QUATERNIK15 y =COMPLEX1R1 y4"
    using A3 quaterni_th_23 sorry
  thus "((ReaQUATERNIK12 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (ReaQUATERNIK12 y) -XCMPLX-0K6 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im1QUATERNIK13 y))-XCMPLX-0K6 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im2QUATERNIK14 y))-XCMPLX-0K6 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im3QUATERNIK15 y) & Im1QUATERNIK13 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im1QUATERNIK13 y) +XCMPLX-0K2 (Im1QUATERNIK13 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im3QUATERNIK15 y))-XCMPLX-0K6 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im2QUATERNIK14 y)) & Im2QUATERNIK14 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im2QUATERNIK14 y) +XCMPLX-0K2 (Im2QUATERNIK14 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im3QUATERNIK15 x)*XCMPLX-0K3 (Im1QUATERNIK13 y))-XCMPLX-0K6 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im3QUATERNIK15 y)) & Im3QUATERNIK15 z =COMPLEX1R1 (((ReaQUATERNIK12 x)*XCMPLX-0K3 (Im3QUATERNIK15 y) +XCMPLX-0K2 (Im3QUATERNIK15 x)*XCMPLX-0K3 (ReaQUATERNIK12 y))+XCMPLX-0K2 (Im1QUATERNIK13 x)*XCMPLX-0K3 (Im2QUATERNIK14 y))-XCMPLX-0K6 (Im2QUATERNIK14 x)*XCMPLX-0K3 (Im1QUATERNIK13 y)"
    using A1 A4 A5 A6 A7 A8 A9 A10 A11 quaterni_th_23 sorry
qed "sorry"

mlemma quaterni_lm_13:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  for z3 be QuaternionQUATERNIM1 holds  for z4 be QuaternionQUATERNIM1 holds ((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4 =HIDDENR1 [*QUATERNIK5 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4,((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4,((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4,((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4 *]"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  for z3 be QuaternionQUATERNIM1 holds  for z4 be QuaternionQUATERNIM1 holds ((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4 =HIDDENR1 [*QUATERNIK5 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4,((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4,((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4,((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4 *]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    fix z3 assume [ty]: "z3 be QuaternionQUATERNIM1"
    fix z4 assume [ty]: "z4 be QuaternionQUATERNIM1"
    let ?z = "[*QUATERNIK5 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4,((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4,((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4,((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4 *]"
    obtain z9 where 
      [ty]:"z9 be QuaternionQUATERNIM1" and z9Def:"z9 = ((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4"
       sorry
    have A1: "ReaQUATERNIK12 ?z =HIDDENR1 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4"
      using quaterni_th_23 sorry
    also have "... = ReaQUATERNIK12 z9"
      using quaterni_lm_9 sorry
    finally have "ReaQUATERNIK12 ?z =HIDDENR1 ReaQUATERNIK12 z9"
       sorry
    have A2: "Im1QUATERNIK13 ?z =HIDDENR1 ((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4"
      using quaterni_th_23 sorry
    also have "... = Im1QUATERNIK13 z9"
      using quaterni_lm_9 sorry
    finally have "Im1QUATERNIK13 ?z =HIDDENR1 Im1QUATERNIK13 z9"
       sorry
    have A3: "Im2QUATERNIK14 ?z =HIDDENR1 ((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4"
      using quaterni_th_23 sorry
    also have "... = Im2QUATERNIK14 z9"
      using quaterni_lm_9 sorry
    finally have "Im2QUATERNIK14 ?z =HIDDENR1 Im2QUATERNIK14 z9"
       sorry
    have "Im3QUATERNIK15 ?z =HIDDENR1 ((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4"
      using quaterni_th_23 sorry
    also have "... = Im3QUATERNIK15 z9"
      using quaterni_lm_9 sorry
    finally have "Im3QUATERNIK15 ?z =HIDDENR1 Im3QUATERNIK15 z9"
       sorry
    thus "((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4 =HIDDENR1 [*QUATERNIK5 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4,((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4,((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4,((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4 *]"
      using A1 A2 A3 quaterni_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_14:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK9 z2 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK9 z2 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    let ?z = "[*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
    obtain z9 where 
      [ty]:"z9 be QuaternionQUATERNIM1" and z9Def:"z9 = z1 *QUATERNIK9 z2"
       sorry
    have A1: "ReaQUATERNIK12 ?z =HIDDENR1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)"
      using quaterni_th_23 sorry
    also have "... = ReaQUATERNIK12 z9"
      using quaterni_lm_12 sorry
    finally have "ReaQUATERNIK12 ?z =HIDDENR1 ReaQUATERNIK12 z9"
       sorry
    have A2: "Im1QUATERNIK13 ?z =HIDDENR1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)"
      using quaterni_th_23 sorry
    also have "... = Im1QUATERNIK13 z9"
      using quaterni_lm_12 sorry
    finally have "Im1QUATERNIK13 ?z =HIDDENR1 Im1QUATERNIK13 z9"
       sorry
    have A3: "Im2QUATERNIK14 ?z =HIDDENR1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)"
      using quaterni_th_23 sorry
    also have "... = Im2QUATERNIK14 z9"
      using quaterni_lm_12 sorry
    finally have "Im2QUATERNIK14 ?z =HIDDENR1 Im2QUATERNIK14 z9"
       sorry
    have "Im3QUATERNIK15 ?z =HIDDENR1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
      using quaterni_th_23 sorry
    also have "... = Im3QUATERNIK15 z9"
      using quaterni_lm_12 sorry
    finally have "Im3QUATERNIK15 ?z =HIDDENR1 Im3QUATERNIK15 z9"
       sorry
    thus "z1 *QUATERNIK9 z2 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
      using A1 A2 A3 quaterni_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_15:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 *QUATERNIK9 z2 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
      using quaterni_lm_14 sorry
    thus "((ReaQUATERNIK12 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK9 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_32:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  for z3 be QuaternionQUATERNIM1 holds  for z4 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4 & Im1QUATERNIK13 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4) & Im2QUATERNIK14 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4) & Im3QUATERNIK15 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  for z3 be QuaternionQUATERNIM1 holds  for z4 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4 & Im1QUATERNIK13 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4) & Im2QUATERNIK14 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4) & Im3QUATERNIK15 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    fix z3 assume [ty]: "z3 be QuaternionQUATERNIM1"
    fix z4 assume [ty]: "z4 be QuaternionQUATERNIM1"
    have "((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4 =HIDDENR1 [*QUATERNIK5 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4,((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4,((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4,((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4 *]"
      using quaterni_lm_13 sorry
    thus "((ReaQUATERNIK12 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+XCMPLX-0K2 ReaQUATERNIK12 z3)+XCMPLX-0K2 ReaQUATERNIK12 z4 & Im1QUATERNIK13 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)+XCMPLX-0K2 Im1QUATERNIK13 z3)+XCMPLX-0K2 Im1QUATERNIK13 z4) & Im2QUATERNIK14 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)+XCMPLX-0K2 Im2QUATERNIK14 z3)+XCMPLX-0K2 Im2QUATERNIK14 z4) & Im3QUATERNIK15 (((z1 +QUATERNIK6 z2)+QUATERNIK6 z3)+QUATERNIK6 z4) =COMPLEX1R1 ((Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)+XCMPLX-0K2 Im3QUATERNIK15 z3)+XCMPLX-0K2 Im3QUATERNIK15 z4"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x for "RealXREAL-0M1"
mlemma quaterni_lm_16:
" for z be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z =HIDDENR1 x implies ((ReaQUATERNIK12 z =COMPLEX1R1 x & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z =HIDDENR1 x implies ((ReaQUATERNIK12 z =COMPLEX1R1 x & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "z =HIDDENR1 x"
    obtain xx zz where 
      [ty]:"xx be ElementSUBSET-1M1-of REALNUMBERSK2" and xxDef:"xx = x" and
      [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
      using xreal_0_def_1 sorry
    have A2: "x =COMPLEX1R1 [*ARYTM-0K5 xx,zz *]"
      using arytm_0_def_5 sorry
    have "[*ARYTM-0K5 xx,zz *] =XBOOLE-0R4 [*QUATERNIK5 x,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
      using quaterni_lm_2 sorry
    thus "((ReaQUATERNIK12 z =COMPLEX1R1 x & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_33:
" for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 x) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 x) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "z1 =HIDDENR1 x"
    have A2: "ReaQUATERNIK12 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<i>XCMPLX-0K1)) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<i>XCMPLX-0K1)))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<i>XCMPLX-0K1)))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<i>XCMPLX-0K1))"
      using quaterni_lm_15 sorry
    have A3: "Im1QUATERNIK13 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<i>XCMPLX-0K1)) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<i>XCMPLX-0K1)))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<i>XCMPLX-0K1)))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<i>XCMPLX-0K1))"
      using quaterni_lm_15 sorry
    have A4: "Im2QUATERNIK14 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<i>XCMPLX-0K1)) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<i>XCMPLX-0K1)))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<i>XCMPLX-0K1)))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<i>XCMPLX-0K1))"
      using quaterni_lm_15 sorry
    have "Im3QUATERNIK15 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<i>XCMPLX-0K1)) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<i>XCMPLX-0K1)))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<i>XCMPLX-0K1)))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<i>XCMPLX-0K1))"
      using quaterni_lm_15 sorry
    thus "((ReaQUATERNIK12 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 x) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<i>XCMPLX-0K1)) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 A4 quaterni_lm_16 quaterni_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_34:
" for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 x) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 x) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "z1 =HIDDENR1 x"
    have A2: "ReaQUATERNIK12 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<j>QUATERNIK10)) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<j>QUATERNIK10)))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<j>QUATERNIK10)))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<j>QUATERNIK10))"
      using quaterni_lm_15 sorry
    have A3: "Im1QUATERNIK13 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<j>QUATERNIK10)) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<j>QUATERNIK10)))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<j>QUATERNIK10)))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<j>QUATERNIK10))"
      using quaterni_lm_15 sorry
    have A4: "Im2QUATERNIK14 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<j>QUATERNIK10)) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<j>QUATERNIK10)))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<j>QUATERNIK10)))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<j>QUATERNIK10))"
      using quaterni_lm_15 sorry
    have "Im3QUATERNIK15 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<j>QUATERNIK10)) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<j>QUATERNIK10)))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<j>QUATERNIK10)))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<j>QUATERNIK10))"
      using quaterni_lm_15 sorry
    thus "((ReaQUATERNIK12 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 x) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<j>QUATERNIK10)) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 A4 quaterni_lm_16 quaterni_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_35:
" for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 x"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for x be RealXREAL-0M1 holds z1 =HIDDENR1 x implies ((ReaQUATERNIK12 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "z1 =HIDDENR1 x"
    have A2: "ReaQUATERNIK12 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<k>QUATERNIK11)) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<k>QUATERNIK11)))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<k>QUATERNIK11)))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<k>QUATERNIK11))"
      using quaterni_lm_15 sorry
    have A3: "Im1QUATERNIK13 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<k>QUATERNIK11)) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<k>QUATERNIK11)))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<k>QUATERNIK11)))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<k>QUATERNIK11))"
      using quaterni_lm_15 sorry
    have A4: "Im2QUATERNIK14 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<k>QUATERNIK11)) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<k>QUATERNIK11)))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<k>QUATERNIK11)))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<k>QUATERNIK11))"
      using quaterni_lm_15 sorry
    have "Im3QUATERNIK15 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 (<k>QUATERNIK11)) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 (<k>QUATERNIK11)))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 (<k>QUATERNIK11)))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 (<k>QUATERNIK11))"
      using quaterni_lm_15 sorry
    thus "((ReaQUATERNIK12 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z1 *QUATERNIK9 (<k>QUATERNIK11)) =COMPLEX1R1 x"
      using A1 A2 A3 A4 quaterni_lm_16 quaterni_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef quaterni_def_19 (" _ +QUATERNIK18  _ " [132,132]132 ) where
  mlet "x be RealXREAL-0M1", "y be QuaternionQUATERNIM1"
"func x +QUATERNIK18 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
    proof-
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A1: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " ex it be NumberORDINAL1M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
      proof-
        have " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not (y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & IT =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]))"
        proof-
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1" and ITDef:"IT = [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
             sorry
          show " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not (y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & IT =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]))"
          proof(rule bexI[of _ "IT"])
            show " not ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not (y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & IT =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]))"
              using A1 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it1 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]) & ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it2 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]) implies it1 =HIDDENR1 it2"
    proof-
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A1: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it1 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]) & ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it2 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]) implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be NumberORDINAL1M1 holds  for c2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & c1 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]) implies (( ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *] & c2 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y19,y29,y39,y49 *]) implies c1 =HIDDENR1 c2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix c1 assume [ty]: "c1 be NumberORDINAL1M1"
          fix c2 assume [ty]: "c2 be NumberORDINAL1M1"
          assume Given: " ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & c1 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
          then obtain y1 y2 y3 y4 where
            [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
            A2: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and A3: "c1 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
             sorry
          assume Given: " ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *] & c2 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y19,y29,y39,y49 *]"
          then obtain y19 y29 y39 y49 where
            [ty]:"y19 be RealXREAL-0M1" "y29 be RealXREAL-0M1" "y39 be RealXREAL-0M1" "y49 be RealXREAL-0M1" and 
            A4: "y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]"and A5: "c2 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y19,y29,y39,y49 *]"
             sorry
          have A6: "y1 =COMPLEX1R1 y19"
            using A2 A4 quaterni_th_12 sorry
          have A7: "y2 =COMPLEX1R1 y29"
            using A2 A4 quaterni_th_12 sorry
          have "y3 =COMPLEX1R1 y39"
            using A2 A4 quaterni_th_12 sorry
          thus "c1 =HIDDENR1 c2"
            using A2 A3 A4 A5 A6 A7 quaterni_th_12 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef quaterni_def_20 (" _ -QUATERNIK19  _ " [132,132]132 ) where
  mlet "x be RealXREAL-0M1", "y be QuaternionQUATERNIM1"
"func x -QUATERNIK19 y \<rightarrow> NumberORDINAL1M1 equals
  x +QUATERNIK18 (-QUATERNIK7 y)"
proof-
  (*coherence*)
    show "x +QUATERNIK18 (-QUATERNIK7 y) be NumberORDINAL1M1"
       sorry
qed "sorry"

mdef quaterni_def_21 (" _ *QUATERNIK20  _ " [164,164]164 ) where
  mlet "x be RealXREAL-0M1", "y be QuaternionQUATERNIM1"
"func x *QUATERNIK20 y \<rightarrow> NumberORDINAL1M1 means
  \<lambda>it.  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
proof-
  (*existence*)
    show " ex it be NumberORDINAL1M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
    proof-
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A1: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " ex it be NumberORDINAL1M1 st  ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
      proof-
        have " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not (y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & IT =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]))"
        proof-
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1" and ITDef:"IT = [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
             sorry
          show " ex IT be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1 st  not ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not (y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & IT =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]))"
          proof(rule bexI[of _ "IT"])
            show " not ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds  for y3 be RealXREAL-0M1 holds  for y4 be RealXREAL-0M1 holds  not (y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & IT =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]))"
              using A1 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it1 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]) & ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it2 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]) implies it1 =HIDDENR1 it2"
    proof-
      obtain y1 y2 y3 y4 where
        [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
        A1: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"
        using quaterni_th_7 sorry
      show " for it1 be NumberORDINAL1M1 holds  for it2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it1 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]) & ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & it2 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]) implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be NumberORDINAL1M1 holds  for c2 be NumberORDINAL1M1 holds ( ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & c1 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]) implies (( ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *] & c2 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y19,x *XCMPLX-0K3 y29,x *XCMPLX-0K3 y39,x *XCMPLX-0K3 y49 *]) implies c1 =HIDDENR1 c2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix c1 assume [ty]: "c1 be NumberORDINAL1M1"
          fix c2 assume [ty]: "c2 be NumberORDINAL1M1"
          assume Given: " ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & c1 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
          then obtain y1 y2 y3 y4 where
            [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
            A2: "y =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *]"and A3: "c1 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
             sorry
          assume Given: " ex y19 be RealXREAL-0M1 st  ex y29 be RealXREAL-0M1 st  ex y39 be RealXREAL-0M1 st  ex y49 be RealXREAL-0M1 st y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *] & c2 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y19,x *XCMPLX-0K3 y29,x *XCMPLX-0K3 y39,x *XCMPLX-0K3 y49 *]"
          then obtain y19 y29 y39 y49 where
            [ty]:"y19 be RealXREAL-0M1" "y29 be RealXREAL-0M1" "y39 be RealXREAL-0M1" "y49 be RealXREAL-0M1" and 
            A4: "y =HIDDENR1 [*QUATERNIK5 y19,y29,y39,y49 *]"and A5: "c2 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y19,x *XCMPLX-0K3 y29,x *XCMPLX-0K3 y39,x *XCMPLX-0K3 y49 *]"
             sorry
          have A6: "y1 =COMPLEX1R1 y19"
            using A2 A4 quaterni_th_12 sorry
          have A7: "y2 =COMPLEX1R1 y29"
            using A2 A4 quaterni_th_12 sorry
          have "y3 =COMPLEX1R1 y39"
            using A2 A4 quaterni_th_12 sorry
          thus "c1 =HIDDENR1 c2"
            using A2 A3 A4 A5 A6 A7 quaterni_th_12 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem quaterni_cl_13:
  mlet "x be RealXREAL-0M1", "z9 be QuaternionQUATERNIM1"
"cluster x +QUATERNIK18 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "x +QUATERNIK18 z9 be quaternionQUATERNIV1"
  proof-
    have " ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st z9 =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & x +QUATERNIK18 z9 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 y1,y2,y3,y4 *]"
      using quaterni_def_19 sorry
    thus "x +QUATERNIK18 z9 be quaternionQUATERNIV1"
       sorry
  qed
qed "sorry"

mtheorem quaterni_cl_14:
  mlet "x be RealXREAL-0M1", "z9 be QuaternionQUATERNIM1"
"cluster x *QUATERNIK20 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "x *QUATERNIK20 z9 be quaternionQUATERNIV1"
  proof-
    have Cut1706: " ex y1 be RealXREAL-0M1 st  ex y2 be RealXREAL-0M1 st  ex y3 be RealXREAL-0M1 st  ex y4 be RealXREAL-0M1 st z9 =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & x *QUATERNIK20 z9 =HIDDENR1 [*QUATERNIK5 x *XCMPLX-0K3 y1,x *XCMPLX-0K3 y2,x *XCMPLX-0K3 y3,x *XCMPLX-0K3 y4 *]"
      using quaterni_def_21 sorry
    have "x *QUATERNIK20 z9 inHIDDENR3 QUATERNIONQUATERNIK1"
    proof-
      show "x *QUATERNIK20 z9 inHIDDENR3 QUATERNIONQUATERNIK1"
        using Cut1706 sorry
    qed
    thus "x *QUATERNIK20 z9 be quaternionQUATERNIV1"
      using quaterni_def_2 sorry
  qed
qed "sorry"

mtheorem quaterni_cl_15:
  mlet "x be RealXREAL-0M1", "z9 be QuaternionQUATERNIM1"
"cluster x -QUATERNIK19 z9 as-term-is quaternionQUATERNIV1"
proof
(*coherence*)
  show "x -QUATERNIK19 z9 be quaternionQUATERNIV1"
     sorry
qed "sorry"

mlemma quaterni_lm_17:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds [*QUATERNIK5 x,y,z,w *] =HIDDENR1 ((x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK6 z *QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK6 w *QUATERNIK20 (<k>QUATERNIK11)"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  fix z assume [ty]: "z be RealXREAL-0M1"
  fix w assume [ty]: "w be RealXREAL-0M1"
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 zz,jj,zz,zz *]"
    using Lm2 quaterni_lm_2 sorry
  then have A1: "y *QUATERNIK20 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 y *XCMPLX-0K3 (0NUMBERSK6),y *XCMPLX-0K3 \<one>\<^sub>M,y *XCMPLX-0K3 (0NUMBERSK6),y *XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_21 sorry
  also have "... = [*QUATERNIK5 0NUMBERSK6,y,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  finally have "y *QUATERNIK20 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,y,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  have A2: "z *QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 z *XCMPLX-0K3 (0NUMBERSK6),z *XCMPLX-0K3 (0NUMBERSK6),z *XCMPLX-0K3 \<one>\<^sub>M,y *XCMPLX-0K3 (0NUMBERSK6) *]"
    using quaterni_def_21 sorry
  also have "... = [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,z,0NUMBERSK6 *]"
     sorry
  finally have "z *QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,z,0NUMBERSK6 *]"
     sorry
  have A3: "w *QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 w *XCMPLX-0K3 (0NUMBERSK6),w *XCMPLX-0K3 (0NUMBERSK6),w *XCMPLX-0K3 (0NUMBERSK6),w *XCMPLX-0K3 \<one>\<^sub>M *]"
    using quaterni_def_21 sorry
  also have "... = [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,w *]"
     sorry
  finally have "w *QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,w *]"
     sorry
  have "x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 0NUMBERSK6,y,0NUMBERSK6,0NUMBERSK6 *]"
    using A1 quaterni_def_19 sorry
  also have "... = [*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  finally have "x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1) =HIDDENR1 [*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  then have "(x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK6 z *QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 0NUMBERSK6,y +XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 z,0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 *]"
    using A2 quaterni_def_7 sorry
  also have "... = [*QUATERNIK5 x,y,z,0NUMBERSK6 *]"
     sorry
  finally have "(x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK6 z *QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 x,y,z,0NUMBERSK6 *]"
     sorry
  then have "((x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK6 z *QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK6 w *QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 0NUMBERSK6,y +XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 z,0NUMBERSK6 +XCMPLX-0K2 w *]"
    using A3 quaterni_def_7 sorry
  thus "[*QUATERNIK5 x,y,z,w *] =HIDDENR1 ((x +QUATERNIK18 y *QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK6 z *QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK6 w *QUATERNIK20 (<k>QUATERNIK11)"
     sorry
qed "sorry"

abbreviation(input) QUATERNIK21(" _ +QUATERNIK21  _ " [132,132]132) where
  "z1 +QUATERNIK21 z2 \<equiv> z1 +QUATERNIK6 z2"

mtheorem quaterni_add_4:
  mlet "z1 be QuaternionQUATERNIM1", "z2 be QuaternionQUATERNIM1"
"cluster z1 +QUATERNIK6 z2 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z1 +QUATERNIK6 z2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_18:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK21 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK21 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 +QUATERNIK21 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
      using quaterni_lm_11 sorry
    thus "z1 +QUATERNIK21 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_36:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 +QUATERNIK21 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 +QUATERNIK21 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 +QUATERNIK21 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
      using quaterni_lm_11 sorry
    thus "((ReaQUATERNIK12 (z1 +QUATERNIK21 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) QUATERNIK22(" _ *QUATERNIK22  _ " [164,164]164) where
  "z1 *QUATERNIK22 z2 \<equiv> z1 *QUATERNIK9 z2"

mtheorem quaterni_add_5:
  mlet "z1 be QuaternionQUATERNIM1", "z2 be QuaternionQUATERNIM1"
"cluster z1 *QUATERNIK9 z2 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z1 *QUATERNIK9 z2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_19:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK22 z2 =XBOOLE-0R4 ((((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+QUATERNIK18 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))*QUATERNIK20 (<k>QUATERNIK11)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK22 z2 =XBOOLE-0R4 ((((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+QUATERNIK18 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))*QUATERNIK20 (<k>QUATERNIK11)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 *QUATERNIK22 z2 =XBOOLE-0R4 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
      using quaterni_lm_14 sorry
    thus "z1 *QUATERNIK22 z2 =XBOOLE-0R4 ((((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+QUATERNIK18 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_37:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 ((ReaQUATERNIK12 z +QUATERNIK18 (Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
proof-
  have " for z be QuaternionQUATERNIM1 holds z =HIDDENR1 ((ReaQUATERNIK12 z +QUATERNIK18 (Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "[*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *] =HIDDENR1 z"
      using quaterni_th_24 sorry
    thus "z =HIDDENR1 ((ReaQUATERNIK12 z +QUATERNIK18 (Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_20:
" for c be QuaternionQUATERNIM1 holds c +QUATERNIK21 0qQUATERNIK16 =HIDDENR1 c"
proof(rule ballI)
  fix c assume [ty]: "c be QuaternionQUATERNIM1"
  have A1: "0qQUATERNIK16 =HIDDENR1 [*ARYTM-0K5 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) *]"
    using arytm_0_def_5 sorry
  also have "... = [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
    using quaterni_lm_2 sorry
  finally have "0qQUATERNIK16 =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
     sorry
  obtain x y w z where
    [ty]:"x be RealXREAL-0M1" "y be RealXREAL-0M1" "w be RealXREAL-0M1" "z be RealXREAL-0M1" and 
    A2: "c =HIDDENR1 [*QUATERNIK5 x,y,w,z *]"
    using quaterni_th_7 sorry
  have "c +QUATERNIK21 0qQUATERNIK16 =HIDDENR1 [*QUATERNIK5 x +XCMPLX-0K2 0NUMBERSK6,y +XCMPLX-0K2 0NUMBERSK6,w +XCMPLX-0K2 0NUMBERSK6,z +XCMPLX-0K2 0NUMBERSK6 *]"
    using A1 A2 quaterni_def_7 sorry
  also have "... = [*QUATERNIK5 x,y,w,z *]"
     sorry
  finally have "c +QUATERNIK21 0qQUATERNIK16 =HIDDENR1 [*QUATERNIK5 x,y,w,z *]"
     sorry
  thus "c +QUATERNIK21 0qQUATERNIK16 =HIDDENR1 c"
    using A2 sorry
qed "sorry"

mlemma quaterni_lm_21:
"((0NUMBERSK6)*QUATERNIK20 (<i>XCMPLX-0K1) =HIDDENR1 0NUMBERSK6 & (0NUMBERSK6)*QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 0NUMBERSK6) & (0NUMBERSK6)*QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 0NUMBERSK6"
proof-
  let ?z1 = "0NUMBERSK6"
  let ?z2 = "<i>XCMPLX-0K1"
  obtain y1 y2 y3 y4 where
    [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
    A1: "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & ?z1 *QUATERNIK20 ?z2 =HIDDENR1 [*QUATERNIK5 ?z1 *XCMPLX-0K3 y1,?z1 *XCMPLX-0K3 y2,?z1 *XCMPLX-0K3 y3,?z1 *XCMPLX-0K3 y4 *]"
    using quaterni_def_21 sorry
  have A2: "?z1 *QUATERNIK20 ?z2 =HIDDENR1 [*ARYTM-0K5 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) *]"
    using A1 quaterni_lm_2 sorry
  also have "... = 0NUMBERSK6"
    using arytm_0_def_5 sorry
  finally have "?z1 *QUATERNIK20 ?z2 =HIDDENR1 0NUMBERSK6"
     sorry
  obtain y1 y2 y3 y4 where
    [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
    A3: "<j>QUATERNIK10 =XBOOLE-0R4 [*QUATERNIK5 y1,y2,y3,y4 *] & ?z1 *QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 [*QUATERNIK5 ?z1 *XCMPLX-0K3 y1,?z1 *XCMPLX-0K3 y2,?z1 *XCMPLX-0K3 y3,?z1 *XCMPLX-0K3 y4 *]"
    using quaterni_def_21 sorry
  have A4: "?z1 *QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 [*ARYTM-0K5 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) *]"
    using A3 quaterni_lm_2 sorry
  also have "... = 0NUMBERSK6"
    using arytm_0_def_5 sorry
  finally have "?z1 *QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 0NUMBERSK6"
     sorry
  obtain y1 y2 y3 y4 where
    [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
    A5: "<k>QUATERNIK11 =XBOOLE-0R4 [*QUATERNIK5 y1,y2,y3,y4 *] & ?z1 *QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 [*QUATERNIK5 ?z1 *XCMPLX-0K3 y1,?z1 *XCMPLX-0K3 y2,?z1 *XCMPLX-0K3 y3,?z1 *XCMPLX-0K3 y4 *]"
    using quaterni_def_21 sorry
  have "?z1 *QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 [*ARYTM-0K5 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) *]"
    using A5 quaterni_lm_2 sorry
  also have "... = 0NUMBERSK6"
    using arytm_0_def_5 sorry
  finally have "?z1 *QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 0NUMBERSK6"
     sorry
  thus "((0NUMBERSK6)*QUATERNIK20 (<i>XCMPLX-0K1) =HIDDENR1 0NUMBERSK6 & (0NUMBERSK6)*QUATERNIK20 (<j>QUATERNIK10) =HIDDENR1 0NUMBERSK6) & (0NUMBERSK6)*QUATERNIK20 (<k>QUATERNIK11) =HIDDENR1 0NUMBERSK6"
    using A2 A4 sorry
qed

mtheorem quaterni_th_38:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((((Im1QUATERNIK13 z1 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 z2 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z1 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z2 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z1 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z2 =COMPLEX1R1 0NUMBERSK6 implies ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((((Im1QUATERNIK13 z1 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 z2 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z1 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z2 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z1 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z2 =COMPLEX1R1 0NUMBERSK6 implies ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    assume A1: "((((Im1QUATERNIK13 z1 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 z2 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z1 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z2 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z1 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z2 =COMPLEX1R1 0NUMBERSK6"
    have A2: "z1 *QUATERNIK22 z2 =HIDDENR1 ((((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+QUATERNIK18 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_19 sorry
    also have "... = ((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) +QUATERNIK18 0qQUATERNIK16)+QUATERNIK21 0qQUATERNIK16"
      using quaterni_lm_20 quaterni_lm_21 A1 sorry
    also have "... = (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) +QUATERNIK18 0qQUATERNIK16"
      using quaterni_lm_20 sorry
    finally have "z1 *QUATERNIK22 z2 =HIDDENR1 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) +QUATERNIK18 0qQUATERNIK16"
       sorry
    obtain y1 y2 y3 y4 where
      [ty]:"y1 be RealXREAL-0M1" "y2 be RealXREAL-0M1" "y3 be RealXREAL-0M1" "y4 be RealXREAL-0M1" and 
      A3: "0qQUATERNIK16 =HIDDENR1 [*QUATERNIK5 y1,y2,y3,y4 *] & (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) +QUATERNIK18 0qQUATERNIK16 =HIDDENR1 [*QUATERNIK5 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) +XCMPLX-0K2 y1,y2,y3,y4 *]"
      using quaterni_def_19 sorry
    obtain RR zz where 
      [ty]:"RR be ElementSUBSET-1M1-of REALNUMBERSK2" and RRDef:"RR = (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2)" and
      [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
      using xreal_0_def_1 sorry
    have "((y1 =COMPLEX1R1 0NUMBERSK6 & y2 =COMPLEX1R1 0NUMBERSK6) & y3 =COMPLEX1R1 0NUMBERSK6) & y4 =COMPLEX1R1 0NUMBERSK6"
      using quaterni_th_12 A3 quaterni_lm_5 sorry
    then have "(ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) +QUATERNIK18 0qQUATERNIK16 =HIDDENR1 [*ARYTM-0K5 RR,zz *]"
      using A3 quaterni_lm_2 sorry
    then have "(ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) +QUATERNIK18 0qQUATERNIK16 =HIDDENR1 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2)"
      using arytm_0_def_5 sorry
    thus "((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
      using quaterni_lm_16 A2 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_39:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z1 =COMPLEX1R1 0NUMBERSK6 & ReaQUATERNIK12 z2 =COMPLEX1R1 0NUMBERSK6 implies ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((-XCMPLX-0K4 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z1 =COMPLEX1R1 0NUMBERSK6 & ReaQUATERNIK12 z2 =COMPLEX1R1 0NUMBERSK6 implies ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((-XCMPLX-0K4 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    assume A1: "ReaQUATERNIK12 z1 =COMPLEX1R1 0NUMBERSK6 & ReaQUATERNIK12 z2 =COMPLEX1R1 0NUMBERSK6"
    have "((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
      using quaterni_lm_15 sorry
    thus "((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((-XCMPLX-0K4 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) -XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) -XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_40:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 -XCMPLX-0K6 (Im1QUATERNIK13 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im2QUATERNIK14 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im1QUATERNIK13 z))) & Im2QUATERNIK14 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im2QUATERNIK14 z))) & Im3QUATERNIK15 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im3QUATERNIK15 z))"
proof-
  have " for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 -XCMPLX-0K6 (Im1QUATERNIK13 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im2QUATERNIK14 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im1QUATERNIK13 z))) & Im2QUATERNIK14 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im2QUATERNIK14 z))) & Im3QUATERNIK15 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im3QUATERNIK15 z))"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "((ReaQUATERNIK12 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)*XCMPLX-0K3 (ReaQUATERNIK12 z) -XCMPLX-0K6 (Im1QUATERNIK13 z)*XCMPLX-0K3 (Im1QUATERNIK13 z))-XCMPLX-0K6 (Im2QUATERNIK14 z)*XCMPLX-0K3 (Im2QUATERNIK14 z))-XCMPLX-0K6 (Im3QUATERNIK15 z)*XCMPLX-0K3 (Im3QUATERNIK15 z) & Im1QUATERNIK13 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im1QUATERNIK13 z) +XCMPLX-0K2 (Im1QUATERNIK13 z)*XCMPLX-0K3 (ReaQUATERNIK12 z))+XCMPLX-0K2 (Im2QUATERNIK14 z)*XCMPLX-0K3 (Im3QUATERNIK15 z))-XCMPLX-0K6 (Im3QUATERNIK15 z)*XCMPLX-0K3 (Im2QUATERNIK14 z)) & Im2QUATERNIK14 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im2QUATERNIK14 z) +XCMPLX-0K2 (Im2QUATERNIK14 z)*XCMPLX-0K3 (ReaQUATERNIK12 z))+XCMPLX-0K2 (Im3QUATERNIK15 z)*XCMPLX-0K3 (Im1QUATERNIK13 z))-XCMPLX-0K6 (Im1QUATERNIK13 z)*XCMPLX-0K3 (Im3QUATERNIK15 z)) & Im3QUATERNIK15 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im3QUATERNIK15 z) +XCMPLX-0K2 (Im3QUATERNIK15 z)*XCMPLX-0K3 (ReaQUATERNIK12 z))+XCMPLX-0K2 (Im1QUATERNIK13 z)*XCMPLX-0K3 (Im2QUATERNIK14 z))-XCMPLX-0K6 (Im2QUATERNIK14 z)*XCMPLX-0K3 (Im1QUATERNIK13 z)"
      using quaterni_lm_15 sorry
    thus "((ReaQUATERNIK12 (z *QUATERNIK22 z) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 -XCMPLX-0K6 (Im1QUATERNIK13 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im2QUATERNIK14 z)^2SQUARE-1K1)-XCMPLX-0K6 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im1QUATERNIK13 z))) & Im2QUATERNIK14 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im2QUATERNIK14 z))) & Im3QUATERNIK15 (z *QUATERNIK22 z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((ReaQUATERNIK12 z)*XCMPLX-0K3 (Im3QUATERNIK15 z))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) QUATERNIK23("-QUATERNIK23  _ " [132]132) where
  "-QUATERNIK23 z \<equiv> -QUATERNIK7 z"

mtheorem quaterni_add_6:
  mlet "z be QuaternionQUATERNIM1"
"cluster -QUATERNIK7 z as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "-QUATERNIK7 z be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_22:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
proof-
  have " for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    let ?z9 = "[*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
    have A1: "?z9 =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_17 sorry
    have "?z9 +QUATERNIK21 z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 ?z9 +XCMPLX-0K2 ReaQUATERNIK12 z,Im1QUATERNIK13 ?z9 +XCMPLX-0K2 Im1QUATERNIK13 z,Im2QUATERNIK14 ?z9 +XCMPLX-0K2 Im2QUATERNIK14 z,Im3QUATERNIK15 ?z9 +XCMPLX-0K2 Im3QUATERNIK15 z *]"
      using quaterni_lm_11 sorry
    also have "... = [*QUATERNIK5 (-XCMPLX-0K4 ReaQUATERNIK12 z)+XCMPLX-0K2 ReaQUATERNIK12 z,Im1QUATERNIK13 ?z9 +XCMPLX-0K2 Im1QUATERNIK13 z,Im2QUATERNIK14 ?z9 +XCMPLX-0K2 Im2QUATERNIK14 z,Im3QUATERNIK15 ?z9 +XCMPLX-0K2 Im3QUATERNIK15 z *]"
      using quaterni_th_23 sorry
    also have "... = [*QUATERNIK5 0NUMBERSK6,(-XCMPLX-0K4 Im1QUATERNIK13 z)+XCMPLX-0K2 Im1QUATERNIK13 z,Im2QUATERNIK14 ?z9 +XCMPLX-0K2 Im2QUATERNIK14 z,Im3QUATERNIK15 ?z9 +XCMPLX-0K2 Im3QUATERNIK15 z *]"
      using quaterni_th_23 sorry
    also have "... = [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,(-XCMPLX-0K4 Im2QUATERNIK14 z)+XCMPLX-0K2 Im2QUATERNIK14 z,Im3QUATERNIK15 ?z9 +XCMPLX-0K2 Im3QUATERNIK15 z *]"
      using quaterni_th_23 sorry
    also have "... = [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,(-XCMPLX-0K4 Im3QUATERNIK15 z)+XCMPLX-0K2 Im3QUATERNIK15 z *]"
      using quaterni_th_23 sorry
    also have "... = 0NUMBERSK6"
      using quaterni_lm_5 sorry
    finally have "?z9 +QUATERNIK21 z =HIDDENR1 0NUMBERSK6"
       sorry
    thus "-QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
      using A1 quaterni_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_41:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 ReaQUATERNIK12 z & Im1QUATERNIK13 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
proof-
  have " for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 ReaQUATERNIK12 z & Im1QUATERNIK13 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "-QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_22 sorry
    then have "-QUATERNIK23 z =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_lm_17 sorry
    thus "((ReaQUATERNIK12 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 ReaQUATERNIK12 z & Im1QUATERNIK13 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) QUATERNIK24(" _ -QUATERNIK24  _ " [132,132]132) where
  "z1 -QUATERNIK24 z2 \<equiv> z1 -QUATERNIK8 z2"

mtheorem quaterni_add_7:
  mlet "z1 be QuaternionQUATERNIM1", "z2 be QuaternionQUATERNIM1"
"cluster z1 -QUATERNIK8 z2 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z1 -QUATERNIK8 z2 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
    using quaterni_def_2 sorry
qed "sorry"

mlemma quaterni_lm_23:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 -QUATERNIK24 z2 =HIDDENR1 (((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 (-QUATERNIK23 z2))+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 (-QUATERNIK23 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 (-QUATERNIK23 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 (-QUATERNIK23 z2))*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_18 sorry
    also have "... = (((ReaQUATERNIK12 z1 +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z2))+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 (-QUATERNIK23 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 (-QUATERNIK23 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 (-QUATERNIK23 z2))*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_th_41 sorry
    also have "... = (((ReaQUATERNIK12 z1 +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z2))+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 (-QUATERNIK23 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 (-QUATERNIK23 z2))*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_th_41 sorry
    also have "... = (((ReaQUATERNIK12 z1 +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z2))+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 (-QUATERNIK23 z2))*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_th_41 sorry
    also have "... = (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_th_41 sorry
    finally have "z1 -QUATERNIK24 z2 =HIDDENR1 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
       sorry
    thus "z1 -QUATERNIK24 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_42:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 -QUATERNIK24 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 -QUATERNIK24 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 -QUATERNIK24 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_23 sorry
    then have "z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
      using quaterni_lm_17 sorry
    thus "((ReaQUATERNIK12 (z1 -QUATERNIK24 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2 & Im1QUATERNIK13 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2) & Im2QUATERNIK14 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2) & Im3QUATERNIK15 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef quaterni_def_22 (" _ *''QUATERNIK25" [228]228 ) where
  mlet "z be QuaternionQUATERNIM1"
"func z *'QUATERNIK25 \<rightarrow> QuaternionQUATERNIM1 equals
  ((ReaQUATERNIK12 z +QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
proof-
  (*coherence*)
    show "((ReaQUATERNIK12 z +QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11) be QuaternionQUATERNIM1"
       sorry
qed "sorry"

abbreviation(input) QUATERNIK26(" _ *''QUATERNIK26" [228]228) where
  "z *'QUATERNIK26 \<equiv> z *'QUATERNIK25"

mtheorem quaterni_add_8:
  mlet "z be QuaternionQUATERNIM1"
"cluster z *'QUATERNIK25 as-term-is ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
proof
(*coherence*)
  show "z *'QUATERNIK25 be ElementSUBSET-1M1-of QUATERNIONQUATERNIK1"
     sorry
qed "sorry"

mtheorem quaterni_th_43:
" for z be QuaternionQUATERNIM1 holds z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
proof-
  have " for z be QuaternionQUATERNIM1 holds z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    obtain jj zz where 
      [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
      [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
      using xreal_0_def_1 sorry
    have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
      using arytm_0_def_5 sorry
    have "<i>XCMPLX-0K1 =HIDDENR1 [*QUATERNIK5 zz,jj,zz,zz *]"
      using Lm2 quaterni_lm_2 sorry
    then have "z *'QUATERNIK26 =HIDDENR1 ((ReaQUATERNIK12 z +QUATERNIK18 [*QUATERNIK5 (-XCMPLX-0K4 Im1QUATERNIK13 z)*XCMPLX-0K3 (0NUMBERSK6),(-XCMPLX-0K4 Im1QUATERNIK13 z)*XCMPLX-0K3 \<one>\<^sub>M,(-XCMPLX-0K4 Im1QUATERNIK13 z)*XCMPLX-0K3 (0NUMBERSK6),(-XCMPLX-0K4 Im1QUATERNIK13 z)*XCMPLX-0K3 (0NUMBERSK6) *])+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_def_21 sorry
    also have "... = ((ReaQUATERNIK12 z +QUATERNIK18 [*QUATERNIK5 0NUMBERSK6,-XCMPLX-0K4 Im1QUATERNIK13 z,0NUMBERSK6,0NUMBERSK6 *])+QUATERNIK21 [*QUATERNIK5 (-XCMPLX-0K4 Im2QUATERNIK14 z)*XCMPLX-0K3 (0NUMBERSK6),(-XCMPLX-0K4 Im2QUATERNIK14 z)*XCMPLX-0K3 (0NUMBERSK6),(-XCMPLX-0K4 Im2QUATERNIK14 z)*XCMPLX-0K3 \<one>\<^sub>M,(-XCMPLX-0K4 Im2QUATERNIK14 z)*XCMPLX-0K3 (0NUMBERSK6) *])+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_def_21 sorry
    also have "... = ((ReaQUATERNIK12 z +QUATERNIK18 [*QUATERNIK5 0NUMBERSK6,-XCMPLX-0K4 Im1QUATERNIK13 z,0NUMBERSK6,0NUMBERSK6 *])+QUATERNIK21 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,-XCMPLX-0K4 Im2QUATERNIK14 z,0NUMBERSK6 *])+QUATERNIK21 [*QUATERNIK5 (-XCMPLX-0K4 Im3QUATERNIK15 z)*XCMPLX-0K3 (0NUMBERSK6),(-XCMPLX-0K4 Im3QUATERNIK15 z)*XCMPLX-0K3 (0NUMBERSK6),(-XCMPLX-0K4 Im3QUATERNIK15 z)*XCMPLX-0K3 (0NUMBERSK6),(-XCMPLX-0K4 Im3QUATERNIK15 z)*XCMPLX-0K3 \<one>\<^sub>M *]"
      using quaterni_def_21 sorry
    also have "... = ([*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 0NUMBERSK6,-XCMPLX-0K4 Im1QUATERNIK13 z,0NUMBERSK6,0NUMBERSK6 *] +QUATERNIK21 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,-XCMPLX-0K4 Im2QUATERNIK14 z,0NUMBERSK6 *])+QUATERNIK21 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_def_19 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 0NUMBERSK6,(-XCMPLX-0K4 Im1QUATERNIK13 z)+XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z),0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 *] +QUATERNIK21 [*QUATERNIK5 0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_def_7 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 0NUMBERSK6,(-XCMPLX-0K4 Im1QUATERNIK13 z)+XCMPLX-0K2 0NUMBERSK6,(-XCMPLX-0K4 Im2QUATERNIK14 z)+XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z) *]"
      using quaterni_def_7 sorry
    finally have "z *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 0NUMBERSK6,(-XCMPLX-0K4 Im1QUATERNIK13 z)+XCMPLX-0K2 0NUMBERSK6,(-XCMPLX-0K4 Im2QUATERNIK14 z)+XCMPLX-0K2 0NUMBERSK6,0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z) *]"
       sorry
    thus "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_44:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 z *'QUATERNIK26 =COMPLEX1R1 ReaQUATERNIK12 z & Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
proof-
  have " for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 z *'QUATERNIK26 =COMPLEX1R1 ReaQUATERNIK12 z & Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_lm_17 sorry
    thus "((ReaQUATERNIK12 z *'QUATERNIK26 =COMPLEX1R1 ReaQUATERNIK12 z & Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z) & Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z) & Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_45:
" for z be QuaternionQUATERNIM1 holds z =HIDDENR1 0NUMBERSK6 implies z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for z be QuaternionQUATERNIM1 holds z =HIDDENR1 0NUMBERSK6 implies z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: "z =HIDDENR1 0NUMBERSK6"
    then have A2: "ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6"
      using quaterni_lm_5 quaterni_th_23 sorry
    have A3: "Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have A4: "Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have "Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    thus "z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6"
      using A2 A3 A4 quaterni_lm_5 quaterni_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_46:
" for z be QuaternionQUATERNIM1 holds z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6"
proof-
  have " for z be QuaternionQUATERNIM1 holds z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: "z *'QUATERNIK26 =XBOOLE-0R4 0NUMBERSK6"
    have A2: "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_th_43 sorry
    have A3: "ReaQUATERNIK12 z *'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have A4: "Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have A5: "Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have A6: "Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have A7: "ReaQUATERNIK12 z *'QUATERNIK26 =COMPLEX1R1 ReaQUATERNIK12 z"
      using A2 quaterni_th_23 sorry
    have A8: "Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z"
      using A2 quaterni_th_23 sorry
    have A9: "Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z"
      using A2 quaterni_th_23 sorry
    have "Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
      using A2 quaterni_th_23 sorry
    thus "z =HIDDENR1 0NUMBERSK6"
      using A3 A4 A5 A6 A7 A8 A9 quaterni_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_47:
"(1qQUATERNIK17)*'QUATERNIK26 =HIDDENR1 1qQUATERNIK17"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have Lm2: "<i>XCMPLX-0K1 =HIDDENR1 [*ARYTM-0K5 zz,jj *]"
    using arytm_0_def_5 sorry
  have "[*ARYTM-0K5 jj,zz *] =XBOOLE-0R4 [*QUATERNIK5 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
    using quaterni_lm_2 sorry
  then have A1: "1qQUATERNIK17 =HIDDENR1 [*QUATERNIK5 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
    using arytm_0_def_5 sorry
  have A2: "ReaQUATERNIK12 ([*QUATERNIK5 jj,zz,zz,zz *]) =COMPLEX1R1 \<one>\<^sub>M"
    using quaterni_th_23 sorry
  have A3: "Im1QUATERNIK13 ([*QUATERNIK5 jj,zz,zz,zz *]) =COMPLEX1R1 0NUMBERSK6"
    using quaterni_th_23 sorry
  have A4: "Im2QUATERNIK14 ([*QUATERNIK5 jj,zz,zz,zz *]) =COMPLEX1R1 0NUMBERSK6"
    using quaterni_th_23 sorry
  have "Im3QUATERNIK15 ([*QUATERNIK5 jj,zz,zz,zz *]) =COMPLEX1R1 0NUMBERSK6"
    using quaterni_th_23 sorry
  thus "(1qQUATERNIK17)*'QUATERNIK26 =HIDDENR1 1qQUATERNIK17"
    using A1 A2 A3 A4 quaterni_th_43 sorry
qed

mtheorem quaterni_th_48:
"((ReaQUATERNIK12 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & Im2QUATERNIK14 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have "(<i>XCMPLX-0K1)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 zz,-REAL-1K1 jj,zz,zz *]"
    using quaterni_th_30 quaterni_th_43 sorry
  thus "((ReaQUATERNIK12 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & Im2QUATERNIK14 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<i>XCMPLX-0K1)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
    using quaterni_th_23 sorry
qed

mtheorem quaterni_th_49:
"((ReaQUATERNIK12 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & Im3QUATERNIK15 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have "(<j>QUATERNIK10)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 zz,zz,-REAL-1K1 jj,zz *]"
    using quaterni_th_31 quaterni_th_43 sorry
  thus "((ReaQUATERNIK12 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M) & Im3QUATERNIK15 (<j>QUATERNIK10)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6"
    using quaterni_th_23 sorry
qed

mtheorem quaterni_th_50:
"((ReaQUATERNIK12 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have "(<k>QUATERNIK11)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 zz,zz,zz,-REAL-1K1 jj *]"
    using quaterni_th_31 quaterni_th_43 sorry
  thus "((ReaQUATERNIK12 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (<k>QUATERNIK11)*'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
    using quaterni_th_23 sorry
qed

mtheorem quaterni_th_51:
"(<i>XCMPLX-0K1)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 <i>XCMPLX-0K1"
  using quaterni_th_30 quaterni_lm_22 sorry

mtheorem quaterni_th_52:
"(<j>QUATERNIK10)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 <j>QUATERNIK10"
  using quaterni_th_31 quaterni_lm_22 sorry

mtheorem quaterni_th_53:
"(<k>QUATERNIK11)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 <k>QUATERNIK11"
  using quaterni_th_31 quaterni_lm_22 sorry

mtheorem quaterni_th_54:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 +QUATERNIK21 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 +QUATERNIK21 z2 *'QUATERNIK26"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 +QUATERNIK21 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 +QUATERNIK21 z2 *'QUATERNIK26"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have A1: "z1 *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1,-XCMPLX-0K4 Im1QUATERNIK13 z1,-XCMPLX-0K4 Im2QUATERNIK14 z1,-XCMPLX-0K4 Im3QUATERNIK15 z1 *]"
      using quaterni_th_43 sorry
    have A2: "z2 *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 z2,-XCMPLX-0K4 Im2QUATERNIK14 z2,-XCMPLX-0K4 Im3QUATERNIK15 z2 *]"
      using quaterni_th_43 sorry
    have A3: "(z1 +QUATERNIK21 z2)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im1QUATERNIK13 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 +QUATERNIK21 z2) *]"
      using quaterni_th_43 sorry
    have "z1 *'QUATERNIK26 +QUATERNIK21 z2 *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z2),(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z2),(-XCMPLX-0K4 Im3QUATERNIK15 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z2) *]"
      using A1 A2 quaterni_def_7 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2),-XCMPLX-0K4 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2),-XCMPLX-0K4 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2) *]"
      using quaterni_th_36 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im1QUATERNIK13 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2),-XCMPLX-0K4 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2) *]"
      using quaterni_th_36 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im1QUATERNIK13 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2) *]"
      using quaterni_th_36 sorry
    finally have "z1 *'QUATERNIK26 +QUATERNIK21 z2 *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im1QUATERNIK13 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 +QUATERNIK21 z2),-XCMPLX-0K4 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2) *]"
       sorry
    thus "(z1 +QUATERNIK21 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 +QUATERNIK21 z2 *'QUATERNIK26"
      using A3 quaterni_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_55:
" for z be QuaternionQUATERNIM1 holds (-QUATERNIK23 z)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z *'QUATERNIK26"
proof-
  have " for z be QuaternionQUATERNIM1 holds (-QUATERNIK23 z)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z *'QUATERNIK26"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_th_43 sorry
    have "(-QUATERNIK23 z)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 (-QUATERNIK23 z),-XCMPLX-0K4 Im1QUATERNIK13 (-QUATERNIK23 z),-XCMPLX-0K4 Im2QUATERNIK14 (-QUATERNIK23 z),-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z) *]"
      using quaterni_th_43 sorry
    then have "(-QUATERNIK23 z)*'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 (-QUATERNIK23 z),-XCMPLX-0K4 Im2QUATERNIK14 (-QUATERNIK23 z),-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 (-XCMPLX-0K4 Im1QUATERNIK13 z),-XCMPLX-0K4 Im2QUATERNIK14 (-QUATERNIK23 z),-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,Im1QUATERNIK13 z,-XCMPLX-0K4 (-XCMPLX-0K4 Im2QUATERNIK14 z),-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,-XCMPLX-0K4 (-XCMPLX-0K4 Im3QUATERNIK15 z) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
       sorry
    finally have "(-QUATERNIK23 z)*'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
       sorry
    then have "z *'QUATERNIK26 +QUATERNIK21 (-QUATERNIK23 z)*'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z),(-XCMPLX-0K4 Im1QUATERNIK13 z)+XCMPLX-0K2 Im1QUATERNIK13 z,(-XCMPLX-0K4 Im2QUATERNIK14 z)+XCMPLX-0K2 Im2QUATERNIK14 z,(-XCMPLX-0K4 Im3QUATERNIK15 z)+XCMPLX-0K2 Im3QUATERNIK15 z *]"
      using A1 quaterni_def_7 sorry
    also have "... = 0NUMBERSK6"
      using quaterni_lm_5 sorry
    finally have "z *'QUATERNIK26 +QUATERNIK21 (-QUATERNIK23 z)*'QUATERNIK26 =HIDDENR1 0NUMBERSK6"
       sorry
    thus "(-QUATERNIK23 z)*'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z *'QUATERNIK26"
      using quaterni_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_56:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 -QUATERNIK24 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 -QUATERNIK24 z2 *'QUATERNIK26"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 -QUATERNIK24 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 -QUATERNIK24 z2 *'QUATERNIK26"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have A1: "z1 *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1,-XCMPLX-0K4 Im1QUATERNIK13 z1,-XCMPLX-0K4 Im2QUATERNIK14 z1,-XCMPLX-0K4 Im3QUATERNIK15 z1 *]"
      using quaterni_th_43 sorry
    have A2: "(-QUATERNIK23 z2)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 (-QUATERNIK23 z2),-XCMPLX-0K4 Im1QUATERNIK13 (-QUATERNIK23 z2),-XCMPLX-0K4 Im2QUATERNIK14 (-QUATERNIK23 z2),-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z2) *]"
      using quaterni_th_43 sorry
    have A3: "(z1 -QUATERNIK24 z2)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 (z1 -QUATERNIK24 z2),-XCMPLX-0K4 Im1QUATERNIK13 (z1 -QUATERNIK24 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 -QUATERNIK24 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 -QUATERNIK24 z2) *]"
      using quaterni_th_43 sorry
    have A4: "z1 *'QUATERNIK26 -QUATERNIK24 z2 *'QUATERNIK26 =HIDDENR1 z1 *'QUATERNIK26 +QUATERNIK21 (-QUATERNIK23 z2)*'QUATERNIK26"
      using quaterni_th_55 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 (-QUATERNIK23 z2),(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 (-QUATERNIK23 z2)),(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 (-QUATERNIK23 z2)),(-XCMPLX-0K4 Im3QUATERNIK15 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z2)) *]"
      using A1 A2 quaterni_def_7 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z2),(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 (-QUATERNIK23 z2)),(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 (-QUATERNIK23 z2)),(-XCMPLX-0K4 Im3QUATERNIK15 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z2)) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)-XCMPLX-0K6 (-XCMPLX-0K4 Im1QUATERNIK13 z2),(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 (-QUATERNIK23 z2)),(-XCMPLX-0K4 Im3QUATERNIK15 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z2)) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 Im1QUATERNIK13 z2,(-XCMPLX-0K4 Im2QUATERNIK14 z1)-XCMPLX-0K6 (-XCMPLX-0K4 Im2QUATERNIK14 z2),(-XCMPLX-0K4 Im3QUATERNIK15 z1)+XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 (-QUATERNIK23 z2)) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 Im1QUATERNIK13 z2,(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 Im2QUATERNIK14 z2,(-XCMPLX-0K4 Im3QUATERNIK15 z1)-XCMPLX-0K6 (-XCMPLX-0K4 Im3QUATERNIK15 z2) *]"
      using quaterni_th_41 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 Im1QUATERNIK13 z2,(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 Im2QUATERNIK14 z2,(-XCMPLX-0K4 Im3QUATERNIK15 z1)+XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
       sorry
    finally have "z1 *'QUATERNIK26 -QUATERNIK24 z2 *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 Im1QUATERNIK13 z2,(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 Im2QUATERNIK14 z2,(-XCMPLX-0K4 Im3QUATERNIK15 z1)+XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
       sorry
    have "(z1 -QUATERNIK24 z2)*'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 (z1 -QUATERNIK24 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 -QUATERNIK24 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 -QUATERNIK24 z2) *]"
      using A3 quaterni_th_42 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,-XCMPLX-0K4 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 -QUATERNIK24 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 -QUATERNIK24 z2) *]"
      using quaterni_th_42 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 Im1QUATERNIK13 z2,-XCMPLX-0K4 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 -QUATERNIK24 z2) *]"
      using quaterni_th_42 sorry
    also have "... = [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 Im1QUATERNIK13 z2,(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 Im2QUATERNIK14 z2,-XCMPLX-0K4 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2) *]"
      using quaterni_th_42 sorry
    finally have "(z1 -QUATERNIK24 z2)*'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,(-XCMPLX-0K4 Im1QUATERNIK13 z1)+XCMPLX-0K2 Im1QUATERNIK13 z2,(-XCMPLX-0K4 Im2QUATERNIK14 z1)+XCMPLX-0K2 Im2QUATERNIK14 z2,-XCMPLX-0K4 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2) *]"
       sorry
    thus "(z1 -QUATERNIK24 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 -QUATERNIK24 z2 *'QUATERNIK26"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_57:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 *QUATERNIK22 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 *QUATERNIK22 z2 *'QUATERNIK26 implies (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds (z1 *QUATERNIK22 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 *QUATERNIK22 z2 *'QUATERNIK26 implies (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    assume A1: "(z1 *QUATERNIK22 z2)*'QUATERNIK26 =XBOOLE-0R4 z1 *'QUATERNIK26 *QUATERNIK22 z2 *'QUATERNIK26"
    have A2: "z1 *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1,-XCMPLX-0K4 Im1QUATERNIK13 z1,-XCMPLX-0K4 Im2QUATERNIK14 z1,-XCMPLX-0K4 Im3QUATERNIK15 z1 *]"
      using quaterni_th_43 sorry
    have A3: "z2 *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 z2,-XCMPLX-0K4 Im2QUATERNIK14 z2,-XCMPLX-0K4 Im3QUATERNIK15 z2 *]"
      using quaterni_th_43 sorry
    have A4: "(z1 *QUATERNIK22 z2)*'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 (z1 *QUATERNIK22 z2),-XCMPLX-0K4 Im1QUATERNIK13 (z1 *QUATERNIK22 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 *QUATERNIK22 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 *QUATERNIK22 z2) *]"
      using quaterni_th_43 sorry
    have A5: "z1 *'QUATERNIK26 *QUATERNIK22 z2 *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (-XCMPLX-0K4 Im1QUATERNIK13 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im1QUATERNIK13 z2))-XCMPLX-0K6 (-XCMPLX-0K4 Im2QUATERNIK14 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z2))-XCMPLX-0K6 (-XCMPLX-0K4 Im3QUATERNIK15 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im3QUATERNIK15 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im1QUATERNIK13 z2) +XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im3QUATERNIK15 z2))-XCMPLX-0K6 (-XCMPLX-0K4 Im3QUATERNIK15 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z2),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z2) +XCMPLX-0K2 (ReaQUATERNIK12 z2)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z1))+XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z2)*XCMPLX-0K3 (-XCMPLX-0K4 Im3QUATERNIK15 z1))-XCMPLX-0K6 (-XCMPLX-0K4 Im3QUATERNIK15 z2)*XCMPLX-0K3 (-XCMPLX-0K4 Im1QUATERNIK13 z1),(((ReaQUATERNIK12 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im3QUATERNIK15 z2) +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z2))-XCMPLX-0K6 (-XCMPLX-0K4 Im2QUATERNIK14 z1)*XCMPLX-0K3 (-XCMPLX-0K4 Im1QUATERNIK13 z2) *]"
      using A2 A3 quaterni_def_10 sorry
    also have "... = [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (ReaQUATERNIK12 z2)*XCMPLX-0K3 (Im2QUATERNIK14 z1))+XCMPLX-0K2 (Im1QUATERNIK13 z2)*XCMPLX-0K3 (Im3QUATERNIK15 z1))-XCMPLX-0K6 (Im3QUATERNIK15 z2)*XCMPLX-0K3 (Im1QUATERNIK13 z1),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
       sorry
    finally have "z1 *'QUATERNIK26 *QUATERNIK22 z2 *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (ReaQUATERNIK12 z2)*XCMPLX-0K3 (Im2QUATERNIK14 z1))+XCMPLX-0K2 (Im1QUATERNIK13 z2)*XCMPLX-0K3 (Im3QUATERNIK15 z1))-XCMPLX-0K6 (Im3QUATERNIK15 z2)*XCMPLX-0K3 (Im1QUATERNIK13 z1),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
       sorry
    have A6: "(z1 *QUATERNIK22 z2)*'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),-XCMPLX-0K4 Im1QUATERNIK13 (z1 *QUATERNIK22 z2),-XCMPLX-0K4 Im2QUATERNIK14 (z1 *QUATERNIK22 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 *QUATERNIK22 z2) *]"
      using A4 quaterni_lm_15 sorry
    also have "... = [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),-XCMPLX-0K4 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)),-XCMPLX-0K4 Im2QUATERNIK14 (z1 *QUATERNIK22 z2),-XCMPLX-0K4 Im3QUATERNIK15 (z1 *QUATERNIK22 z2) *]"
      using quaterni_lm_15 sorry
    also have "... = [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),-XCMPLX-0K4 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)),-XCMPLX-0K4 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)),-XCMPLX-0K4 Im3QUATERNIK15 (z1 *QUATERNIK22 z2) *]"
      using quaterni_lm_15 sorry
    also have "... = [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),-XCMPLX-0K4 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)),-XCMPLX-0K4 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)),-XCMPLX-0K4 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)) *]"
      using quaterni_lm_15 sorry
    also have "... = [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
       sorry
    finally have "(z1 *QUATERNIK22 z2)*'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2),(((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) *]"
       sorry
    have A7: "Im1QUATERNIK13 (z1 *'QUATERNIK26 *QUATERNIK22 z2 *'QUATERNIK26) =COMPLEX1R1 (((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)"
      using A5 quaterni_th_23 sorry
    have "Im1QUATERNIK13 (z1 *QUATERNIK22 z2)*'QUATERNIK26 =COMPLEX1R1 (((-XCMPLX-0K4 (ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)"
      using A6 quaterni_th_23 sorry
    thus "(Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) =COMPLEX1R1 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)"
      using A1 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_58:
" for z be QuaternionQUATERNIM1 holds (Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6 & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6 implies z *'QUATERNIK26 =HIDDENR1 z"
proof-
  have " for z be QuaternionQUATERNIM1 holds Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6 & (Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6 & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6) implies z *'QUATERNIK26 =HIDDENR1 z"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: "Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6"
      and A2: "Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6"
      and A3: "Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
    obtain Rz zz where 
      [ty]:"Rz be ElementSUBSET-1M1-of REALNUMBERSK2" and RzDef:"Rz = ReaQUATERNIK12 z" and
      [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
      using xreal_0_def_1 sorry
    have A4: "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
      using A1 A2 A3 quaterni_th_24 sorry
    also have "... = [*ARYTM-0K5 Rz,zz *]"
      using quaterni_lm_2 sorry
    also have "... = ReaQUATERNIK12 z"
      using arytm_0_def_5 sorry
    finally have "z =HIDDENR1 ReaQUATERNIK12 z"
       sorry
    have "z *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
      using A1 A2 A3 quaterni_th_43 sorry
    also have "... = [*ARYTM-0K5 Rz,zz *]"
      using quaterni_lm_2 sorry
    also have "... = ReaQUATERNIK12 z"
      using arytm_0_def_5 sorry
    finally have "z *'QUATERNIK26 =HIDDENR1 ReaQUATERNIK12 z"
       sorry
    thus "z *'QUATERNIK26 =HIDDENR1 z"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_59:
" for z be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6 implies z *'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z"
proof-
  have " for z be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6 implies z *'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: "ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6"
    have "-QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
      using quaterni_lm_22 sorry
    thus "z *'QUATERNIK26 =XBOOLE-0R4 -QUATERNIK23 z"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_60:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
      using quaterni_th_24 sorry
    have "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_th_43 sorry
    then have "z *QUATERNIK22 z *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z)*XCMPLX-0K3 (ReaQUATERNIK12 z) -XCMPLX-0K6 (Im1QUATERNIK13 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im1QUATERNIK13 z))-XCMPLX-0K6 (Im2QUATERNIK14 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z))-XCMPLX-0K6 (Im3QUATERNIK15 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im3QUATERNIK15 z),(((ReaQUATERNIK12 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im1QUATERNIK13 z) +XCMPLX-0K2 (Im1QUATERNIK13 z)*XCMPLX-0K3 (ReaQUATERNIK12 z))+XCMPLX-0K2 (Im2QUATERNIK14 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im3QUATERNIK15 z))-XCMPLX-0K6 (Im3QUATERNIK15 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z),(((ReaQUATERNIK12 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z) +XCMPLX-0K2 (ReaQUATERNIK12 z)*XCMPLX-0K3 (Im2QUATERNIK14 z))+XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z)*XCMPLX-0K3 (Im3QUATERNIK15 z))-XCMPLX-0K6 (-XCMPLX-0K4 Im3QUATERNIK15 z)*XCMPLX-0K3 (Im1QUATERNIK13 z),(((ReaQUATERNIK12 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im3QUATERNIK15 z) +XCMPLX-0K2 (Im3QUATERNIK15 z)*XCMPLX-0K3 (ReaQUATERNIK12 z))+XCMPLX-0K2 (Im1QUATERNIK13 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im2QUATERNIK14 z))-XCMPLX-0K6 (Im2QUATERNIK14 z)*XCMPLX-0K3 (-XCMPLX-0K4 Im1QUATERNIK13 z) *]"
      using A1 quaterni_def_10 sorry
    also have "... = [*QUATERNIK5 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
       sorry
    finally have "z *QUATERNIK22 z *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
       sorry
    thus "((ReaQUATERNIK12 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 & Im1QUATERNIK13 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z *QUATERNIK22 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_61:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (ReaQUATERNIK12 z) & Im1QUATERNIK13 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (ReaQUATERNIK12 z) & Im1QUATERNIK13 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
      using quaterni_th_24 sorry
    have "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_th_43 sorry
    then have "z +QUATERNIK21 z *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 ReaQUATERNIK12 z,Im1QUATERNIK13 z +XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z),Im2QUATERNIK14 z +XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z),Im3QUATERNIK15 z +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z) *]"
      using A1 quaterni_def_7 sorry
    also have "... = [*QUATERNIK5 \<two>\<^sub>M *XCMPLX-0K3 (ReaQUATERNIK12 z),0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
       sorry
    finally have "z +QUATERNIK21 z *'QUATERNIK26 =HIDDENR1 [*QUATERNIK5 \<two>\<^sub>M *XCMPLX-0K3 (ReaQUATERNIK12 z),0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *]"
       sorry
    thus "((ReaQUATERNIK12 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (ReaQUATERNIK12 z) & Im1QUATERNIK13 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 (z +QUATERNIK21 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_62:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
proof-
  have " for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
      using quaterni_th_24 sorry
    let ?z9 = "[*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
    have "z +QUATERNIK21 ?z9 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z),Im1QUATERNIK13 z +XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z),Im2QUATERNIK14 z +XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z),Im3QUATERNIK15 z +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z) *]"
      using A1 quaterni_def_7 sorry
    also have "... = 0NUMBERSK6"
      using quaterni_lm_5 sorry
    finally have "z +QUATERNIK21 ?z9 =HIDDENR1 0NUMBERSK6"
       sorry
    thus "-QUATERNIK23 z =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_63:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have A1: "z1 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1,Im1QUATERNIK13 z1,Im2QUATERNIK14 z1,Im3QUATERNIK15 z1 *]"
      using quaterni_th_24 sorry
    have A2: "z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z2,Im1QUATERNIK13 z2,Im2QUATERNIK14 z2,Im3QUATERNIK15 z2 *]"
      using quaterni_th_24 sorry
    let ?z9 = "[*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 z2,-XCMPLX-0K4 Im2QUATERNIK14 z2,-XCMPLX-0K4 Im3QUATERNIK15 z2 *]"
    have "z2 +QUATERNIK21 ?z9 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z2 +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z2),Im1QUATERNIK13 z2 +XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z2),Im2QUATERNIK14 z2 +XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z2),Im3QUATERNIK15 z2 +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z2) *]"
      using A2 quaterni_def_7 sorry
    also have "... = 0NUMBERSK6"
      using quaterni_lm_5 sorry
    finally have "z2 +QUATERNIK21 ?z9 =HIDDENR1 0NUMBERSK6"
       sorry
    then have "-QUATERNIK23 z2 =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 z2,-XCMPLX-0K4 Im2QUATERNIK14 z2,-XCMPLX-0K4 Im3QUATERNIK15 z2 *]"
      using quaterni_def_8 sorry
    thus "z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
      using A1 quaterni_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_64:
" for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im1QUATERNIK13 z)) & Im2QUATERNIK14 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im2QUATERNIK14 z)) & Im3QUATERNIK15 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im3QUATERNIK15 z)"
proof-
  have " for z be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im1QUATERNIK13 z)) & Im2QUATERNIK14 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im2QUATERNIK14 z)) & Im3QUATERNIK15 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im3QUATERNIK15 z)"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "z =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
      using quaterni_th_24 sorry
    have A2: "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_th_43 sorry
    have A3: "Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z"
      using A2 quaterni_th_23 sorry
    have A4: "Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z"
      using A2 quaterni_th_23 sorry
    have A5: "Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
      using A2 quaterni_th_23 sorry
    let ?zz = "z *'QUATERNIK26"
    have "-QUATERNIK23 ?zz =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 ?zz,-XCMPLX-0K4 Im1QUATERNIK13 ?zz,-XCMPLX-0K4 Im2QUATERNIK14 ?zz,-XCMPLX-0K4 Im3QUATERNIK15 ?zz *]"
      using quaterni_th_62 sorry
    then have "-QUATERNIK23 ?zz =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,Im1QUATERNIK13 z,Im2QUATERNIK14 z,Im3QUATERNIK15 z *]"
      using A2 quaterni_th_23 A3 A4 A5 sorry
    then have "z -QUATERNIK24 ?zz =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z),Im1QUATERNIK13 z +XCMPLX-0K2 Im1QUATERNIK13 z,Im2QUATERNIK14 z +XCMPLX-0K2 Im2QUATERNIK14 z,Im3QUATERNIK15 z +XCMPLX-0K2 Im3QUATERNIK15 z *]"
      using A1 quaterni_def_7 sorry
    also have "... = [*QUATERNIK5 0NUMBERSK6,\<two>\<^sub>M *XCMPLX-0K3 (Im1QUATERNIK13 z),\<two>\<^sub>M *XCMPLX-0K3 (Im2QUATERNIK14 z),\<two>\<^sub>M *XCMPLX-0K3 (Im3QUATERNIK15 z) *]"
       sorry
    finally have "z -QUATERNIK24 ?zz =HIDDENR1 [*QUATERNIK5 0NUMBERSK6,\<two>\<^sub>M *XCMPLX-0K3 (Im1QUATERNIK13 z),\<two>\<^sub>M *XCMPLX-0K3 (Im2QUATERNIK14 z),\<two>\<^sub>M *XCMPLX-0K3 (Im3QUATERNIK15 z) *]"
       sorry
    thus "((ReaQUATERNIK12 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 0NUMBERSK6 & Im1QUATERNIK13 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im1QUATERNIK13 z)) & Im2QUATERNIK14 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im2QUATERNIK14 z)) & Im3QUATERNIK15 (z -QUATERNIK24 z *'QUATERNIK26) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (Im3QUATERNIK15 z)"
      using quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef quaterni_def_23 (" |.QUATERNIK27  _ .|" [0]164 ) where
  mlet "z be QuaternionQUATERNIM1"
"func  |.QUATERNIK27 z.| \<rightarrow> RealXREAL-0M1 equals
  sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1)"
proof-
  (*coherence*)
    show "sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem quaterni_th_65:
" |.QUATERNIK27 0qQUATERNIK16 .| =COMPLEX1R1 0NUMBERSK6"
proof-
  have A1: "ReaQUATERNIK12 (0qQUATERNIK16) =COMPLEX1R1 0NUMBERSK6"
    using quaterni_lm_5 quaterni_th_23 sorry
  have A2: "Im1QUATERNIK13 (0qQUATERNIK16) =COMPLEX1R1 0NUMBERSK6"
    using quaterni_lm_5 quaterni_th_23 sorry
  have "Im2QUATERNIK14 (0qQUATERNIK16) =COMPLEX1R1 0NUMBERSK6"
    using quaterni_lm_5 quaterni_th_23 sorry
  thus " |.QUATERNIK27 0qQUATERNIK16 .| =COMPLEX1R1 0NUMBERSK6"
    using A1 A2 quaterni_lm_5 quaterni_th_23 square_1_th_17 sorry
qed

mtheorem quaterni_th_66:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z.| =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6"
proof-
  have " for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z.| =COMPLEX1R1 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    assume A1: " |.QUATERNIK27 z.| =COMPLEX1R1 0NUMBERSK6"
    have A2: "0NUMBERSK6 <=XXREAL-0R1 (ReaQUATERNIK12 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A3: "0NUMBERSK6 <=XXREAL-0R1 (Im1QUATERNIK13 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A4: "0NUMBERSK6 <=XXREAL-0R1 (Im2QUATERNIK14 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (Im3QUATERNIK15 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A5: "0NUMBERSK6 =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1"
      using A1 A2 A3 A4 square_1_th_25 sorry
    then have A6: "ReaQUATERNIK12 z =COMPLEX1R1 0NUMBERSK6"
      using quaterni_lm_8 sorry
    have A7: "Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6"
      using A5 quaterni_lm_8 sorry
    have A8: "Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6"
      using A5 quaterni_lm_8 sorry
    have "Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
      using A5 quaterni_lm_8 sorry
    thus "z =HIDDENR1 0NUMBERSK6"
      using A6 A7 A8 quaterni_lm_5 quaterni_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_67:
" for z be QuaternionQUATERNIM1 holds 0NUMBERSK6 <=XXREAL-0R1  |.QUATERNIK27 z.|"
proof-
  have " for z be QuaternionQUATERNIM1 holds 0NUMBERSK6 <=XXREAL-0R1  |.QUATERNIK27 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "0NUMBERSK6 <=XXREAL-0R1 (ReaQUATERNIK12 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A2: "0NUMBERSK6 <=XXREAL-0R1 (Im1QUATERNIK13 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A3: "0NUMBERSK6 <=XXREAL-0R1 (Im2QUATERNIK14 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (Im3QUATERNIK15 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1  |.QUATERNIK27 z.|"
      using A1 A2 A3 square_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_68:
" |.QUATERNIK27 1qQUATERNIK17 .| =COMPLEX1R1 \<one>\<^sub>M"
proof-
  obtain jj zz where 
    [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M" and
    [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
    using xreal_0_def_1 sorry
  have "[*QUATERNIK5 \<one>\<^sub>M,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 jj,zz *]"
    using quaterni_lm_2 sorry
  then have Lm10: "[*QUATERNIK5 jj,zz,zz,zz *] =XBOOLE-0R4 \<one>\<^sub>M"
    using arytm_0_def_5 sorry
  have A1: "ReaQUATERNIK12 (1qQUATERNIK17) =COMPLEX1R1 jj"
    using Lm10 quaterni_th_23 sorry
  have A2: "Im1QUATERNIK13 (1qQUATERNIK17) =COMPLEX1R1 zz"
    using Lm10 quaterni_th_23 sorry
  have "Im2QUATERNIK14 (1qQUATERNIK17) =COMPLEX1R1 zz"
    using Lm10 quaterni_th_23 sorry
  thus " |.QUATERNIK27 1qQUATERNIK17 .| =COMPLEX1R1 \<one>\<^sub>M"
    using A1 A2 Lm10 quaterni_th_23 square_1_th_18 sorry
qed

mtheorem quaterni_th_69:
" |.QUATERNIK27 <i>XCMPLX-0K1 .| =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_30 square_1_th_18 sorry

mtheorem quaterni_th_70:
" |.QUATERNIK27 <j>QUATERNIK10 .| =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_31 square_1_th_18 sorry

mtheorem quaterni_th_71:
" |.QUATERNIK27 <k>QUATERNIK11 .| =COMPLEX1R1 \<one>\<^sub>M"
  using quaterni_th_31 square_1_th_18 sorry

mtheorem quaterni_th_72:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 -QUATERNIK23 z .| =COMPLEX1R1  |.QUATERNIK27 z.|"
proof-
  have " for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 -QUATERNIK23 z .| =COMPLEX1R1  |.QUATERNIK27 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "-QUATERNIK23 z =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_th_62 sorry
    then have A2: "ReaQUATERNIK12 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 ReaQUATERNIK12 z"
      using quaterni_th_23 sorry
    have A3: "Im1QUATERNIK13 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z"
      using A1 quaterni_th_23 sorry
    have A4: "Im2QUATERNIK14 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z"
      using A1 quaterni_th_23 sorry
    have "Im3QUATERNIK15 (-QUATERNIK23 z) =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
      using A1 quaterni_th_23 sorry
    thus " |.QUATERNIK27 -QUATERNIK23 z .| =COMPLEX1R1  |.QUATERNIK27 z.|"
      using A2 A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_73:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *'QUATERNIK26.| =COMPLEX1R1  |.QUATERNIK27 z.|"
proof-
  have " for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *'QUATERNIK26.| =COMPLEX1R1  |.QUATERNIK27 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "z *'QUATERNIK26 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z,-XCMPLX-0K4 Im1QUATERNIK13 z,-XCMPLX-0K4 Im2QUATERNIK14 z,-XCMPLX-0K4 Im3QUATERNIK15 z *]"
      using quaterni_th_43 sorry
    then have A2: "Im1QUATERNIK13 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im1QUATERNIK13 z"
      using quaterni_th_23 sorry
    have A3: "Im2QUATERNIK14 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im2QUATERNIK14 z"
      using A1 quaterni_th_23 sorry
    have "Im3QUATERNIK15 z *'QUATERNIK26 =COMPLEX1R1 -XCMPLX-0K4 Im3QUATERNIK15 z"
      using A1 quaterni_th_23 sorry
    thus " |.QUATERNIK27 z *'QUATERNIK26.| =COMPLEX1R1  |.QUATERNIK27 z.|"
      using A1 A2 A3 quaterni_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_74:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  fix c assume [ty]: "c be RealXREAL-0M1"
  fix d assume [ty]: "d be RealXREAL-0M1"
  have A1: "a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
    using xreal_1_th_63 sorry
  have A2: "b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
    using xreal_1_th_63 sorry
  have A3: "c ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
    using xreal_1_th_63 sorry
  have "d ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
    using xreal_1_th_63 sorry
  thus "((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
    using A1 A2 A3 sorry
qed "sorry"

mlemma quaterni_lm_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    have A1: "0NUMBERSK6 <=XXREAL-0R1 c ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A2: "0NUMBERSK6 <=XXREAL-0R1 d ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have "a ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1"
      using xreal_1_th_31 xreal_1_th_63 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 a ^2SQUARE-1K1 <=XXREAL-0R1 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1"
      using A1 xreal_1_th_7 sorry
    thus "a ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
      using A2 xreal_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds c ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  fix c assume [ty]: "c be RealXREAL-0M1"
  fix d assume [ty]: "d be RealXREAL-0M1"
  have A1: "0NUMBERSK6 <=XXREAL-0R1 b ^2SQUARE-1K1"
    using xreal_1_th_63 sorry
  have A2: "0NUMBERSK6 <=XXREAL-0R1 d ^2SQUARE-1K1"
    using xreal_1_th_63 sorry
  have "c ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1"
    using xreal_1_th_31 xreal_1_th_63 sorry
  then have "0NUMBERSK6 +XCMPLX-0K2 c ^2SQUARE-1K1 <=XXREAL-0R1 (a ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 b ^2SQUARE-1K1"
    using A1 xreal_1_th_7 sorry
  thus "c ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
    using A2 xreal_1_th_7 sorry
qed "sorry"

mlemma quaterni_lm_26:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds d ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds d ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    have A1: "0NUMBERSK6 <=XXREAL-0R1 b ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have A2: "0NUMBERSK6 <=XXREAL-0R1 c ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have "d ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1 +XCMPLX-0K2 d ^2SQUARE-1K1"
      using xreal_1_th_31 xreal_1_th_63 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 d ^2SQUARE-1K1 <=XXREAL-0R1 (a ^2SQUARE-1K1 +XCMPLX-0K2 d ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1"
      using A2 xreal_1_th_7 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 d ^2SQUARE-1K1 <=XXREAL-0R1 b ^2SQUARE-1K1 +XCMPLX-0K2 ((a ^2SQUARE-1K1 +XCMPLX-0K2 d ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
      using A1 xreal_1_th_7 sorry
    thus "d ^2SQUARE-1K1 <=XXREAL-0R1 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 b ^2SQUARE-1K1 implies sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 b ^2SQUARE-1K1 implies sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 b ^2SQUARE-1K1"
    have "b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A2: "sqrtSQUARE-1K3 a >=XXREAL-0R2 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
      using A1 square_1_th_26 sorry
    show "sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
    proof-
      have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
      proof(rule impI)
        assume "b >=XXREAL-0R2 0NUMBERSK6"
        thus "sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
          using A2 square_1_th_22 sorry
      qed
      have case2: "b <XXREAL-0R3 0NUMBERSK6 implies sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
      proof(rule impI)
        assume A3: "b <XXREAL-0R3 0NUMBERSK6"
        then have "sqrtSQUARE-1K3 a >=XXREAL-0R2 -XCMPLX-0K4 b"
          using A2 square_1_th_23 sorry
        thus "sqrtSQUARE-1K3 a >=XXREAL-0R2 b"
          using A3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_28:
" for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for a6 be RealXREAL-0M1 holds  for b1 be RealXREAL-0M1 holds  for b2 be RealXREAL-0M1 holds  for b3 be RealXREAL-0M1 holds  for b4 be RealXREAL-0M1 holds  for b5 be RealXREAL-0M1 holds  for b6 be RealXREAL-0M1 holds ((((a1 >=XXREAL-0R2 b1 & a2 >=XXREAL-0R2 b2) & a3 >=XXREAL-0R2 b3) & a4 >=XXREAL-0R2 b4) & a5 >=XXREAL-0R2 b5) & a6 >=XXREAL-0R2 b6 implies ((((a1 +XCMPLX-0K2 a2)+XCMPLX-0K2 a3)+XCMPLX-0K2 a4)+XCMPLX-0K2 a5)+XCMPLX-0K2 a6 >=XXREAL-0R2 ((((b1 +XCMPLX-0K2 b2)+XCMPLX-0K2 b3)+XCMPLX-0K2 b4)+XCMPLX-0K2 b5)+XCMPLX-0K2 b6"
proof-
  have " for a1 be RealXREAL-0M1 holds  for a2 be RealXREAL-0M1 holds  for a3 be RealXREAL-0M1 holds  for a4 be RealXREAL-0M1 holds  for a5 be RealXREAL-0M1 holds  for a6 be RealXREAL-0M1 holds  for b1 be RealXREAL-0M1 holds  for b2 be RealXREAL-0M1 holds  for b3 be RealXREAL-0M1 holds  for b4 be RealXREAL-0M1 holds  for b5 be RealXREAL-0M1 holds  for b6 be RealXREAL-0M1 holds a1 >=XXREAL-0R2 b1 & (a2 >=XXREAL-0R2 b2 & (a3 >=XXREAL-0R2 b3 & (a4 >=XXREAL-0R2 b4 & (a5 >=XXREAL-0R2 b5 & a6 >=XXREAL-0R2 b6)))) implies ((((a1 +XCMPLX-0K2 a2)+XCMPLX-0K2 a3)+XCMPLX-0K2 a4)+XCMPLX-0K2 a5)+XCMPLX-0K2 a6 >=XXREAL-0R2 ((((b1 +XCMPLX-0K2 b2)+XCMPLX-0K2 b3)+XCMPLX-0K2 b4)+XCMPLX-0K2 b5)+XCMPLX-0K2 b6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a1 assume [ty]: "a1 be RealXREAL-0M1"
    fix a2 assume [ty]: "a2 be RealXREAL-0M1"
    fix a3 assume [ty]: "a3 be RealXREAL-0M1"
    fix a4 assume [ty]: "a4 be RealXREAL-0M1"
    fix a5 assume [ty]: "a5 be RealXREAL-0M1"
    fix a6 assume [ty]: "a6 be RealXREAL-0M1"
    fix b1 assume [ty]: "b1 be RealXREAL-0M1"
    fix b2 assume [ty]: "b2 be RealXREAL-0M1"
    fix b3 assume [ty]: "b3 be RealXREAL-0M1"
    fix b4 assume [ty]: "b4 be RealXREAL-0M1"
    fix b5 assume [ty]: "b5 be RealXREAL-0M1"
    fix b6 assume [ty]: "b6 be RealXREAL-0M1"
    assume A1: "a1 >=XXREAL-0R2 b1"
      and A2: "a2 >=XXREAL-0R2 b2"
      and A3: "a3 >=XXREAL-0R2 b3"
      and A4: "a4 >=XXREAL-0R2 b4"
      and A5: "a5 >=XXREAL-0R2 b5"
      and A6: "a6 >=XXREAL-0R2 b6"
    have A7: "a1 +XCMPLX-0K2 a2 >=XXREAL-0R2 b1 +XCMPLX-0K2 b2"
      using A1 A2 xreal_1_th_7 sorry
    have A8: "a3 +XCMPLX-0K2 a4 >=XXREAL-0R2 b3 +XCMPLX-0K2 b4"
      using A3 A4 xreal_1_th_7 sorry
    have A9: "a5 +XCMPLX-0K2 a6 >=XXREAL-0R2 b5 +XCMPLX-0K2 b6"
      using A5 A6 xreal_1_th_7 sorry
    have "(a1 +XCMPLX-0K2 a2)+XCMPLX-0K2 (a3 +XCMPLX-0K2 a4) >=XXREAL-0R2 (b1 +XCMPLX-0K2 b2)+XCMPLX-0K2 (b3 +XCMPLX-0K2 b4)"
      using A7 A8 xreal_1_th_7 sorry
    then have "((a1 +XCMPLX-0K2 a2)+XCMPLX-0K2 (a3 +XCMPLX-0K2 a4))+XCMPLX-0K2 (a5 +XCMPLX-0K2 a6) >=XXREAL-0R2 ((b1 +XCMPLX-0K2 b2)+XCMPLX-0K2 (b3 +XCMPLX-0K2 b4))+XCMPLX-0K2 (b5 +XCMPLX-0K2 b6)"
      using A9 xreal_1_th_7 sorry
    thus "((((a1 +XCMPLX-0K2 a2)+XCMPLX-0K2 a3)+XCMPLX-0K2 a4)+XCMPLX-0K2 a5)+XCMPLX-0K2 a6 >=XXREAL-0R2 ((((b1 +XCMPLX-0K2 b2)+XCMPLX-0K2 b3)+XCMPLX-0K2 b4)+XCMPLX-0K2 b5)+XCMPLX-0K2 b6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & a ^2SQUARE-1K1 >=XXREAL-0R2 b ^2SQUARE-1K1 implies a >=XXREAL-0R2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (b >=XXREAL-0R2 0NUMBERSK6 & a ^2SQUARE-1K1 >=XXREAL-0R2 b ^2SQUARE-1K1) implies a >=XXREAL-0R2 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b >=XXREAL-0R2 0NUMBERSK6"
      and A3: "a ^2SQUARE-1K1 >=XXREAL-0R2 b ^2SQUARE-1K1"
    have "sqrtSQUARE-1K3 a ^2SQUARE-1K1 >=XXREAL-0R2 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
      using A2 A3 square_1_th_26 sorry
    then have "a >=XXREAL-0R2 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
      using A1 square_1_th_22 sorry
    thus "a >=XXREAL-0R2 b"
      using A1 square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_30:
" for m1 be RealXREAL-0M1 holds  for m2 be RealXREAL-0M1 holds  for m4 be RealXREAL-0M1 holds  for m3 be RealXREAL-0M1 holds  for n1 be RealXREAL-0M1 holds  for n2 be RealXREAL-0M1 holds  for n3 be RealXREAL-0M1 holds  for n4 be RealXREAL-0M1 holds (sqrtSQUARE-1K3 (((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 (((n1 ^2SQUARE-1K1 +XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((((((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1)+XCMPLX-0K2 n1 ^2SQUARE-1K1)+XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((n1 ^2SQUARE-1K1 +XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1))"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix m1 assume [ty]: "m1 be RealXREAL-0M1"
  fix m2 assume [ty]: "m2 be RealXREAL-0M1"
  fix m4 assume [ty]: "m4 be RealXREAL-0M1"
  fix m3 assume [ty]: "m3 be RealXREAL-0M1"
  fix n1 assume [ty]: "n1 be RealXREAL-0M1"
  fix n2 assume [ty]: "n2 be RealXREAL-0M1"
  fix n3 assume [ty]: "n3 be RealXREAL-0M1"
  fix n4 assume [ty]: "n4 be RealXREAL-0M1"
  let ?a = "((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1"
  let ?b = "((n1 ^2SQUARE-1K1 +XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1"
  have A1: "?a >=XXREAL-0R2 0NUMBERSK6"
    using quaterni_th_74 sorry
  have A2: "?b >=XXREAL-0R2 0NUMBERSK6"
    using quaterni_th_74 sorry
  have "(sqrtSQUARE-1K3 ?a +XCMPLX-0K2 sqrtSQUARE-1K3 ?b)^2SQUARE-1K1 =HIDDENR1 ((sqrtSQUARE-1K3 ?a)^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ?a)*XCMPLX-0K3 sqrtSQUARE-1K3 ?b)+XCMPLX-0K2 (sqrtSQUARE-1K3 ?b)^2SQUARE-1K1"
     sorry
  also have "... = (?a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ?a)*XCMPLX-0K3 sqrtSQUARE-1K3 ?b)+XCMPLX-0K2 (sqrtSQUARE-1K3 ?b)^2SQUARE-1K1"
    using A1 square_1_def_2 sorry
  also have "... = (?a +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 ?a *XCMPLX-0K3 sqrtSQUARE-1K3 ?b))+XCMPLX-0K2 ?b"
    using A2 square_1_def_2 sorry
  also have "... = (?a +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?a *XCMPLX-0K3 ?b))+XCMPLX-0K2 ?b"
    using A1 A2 square_1_th_29 sorry
  finally have "(sqrtSQUARE-1K3 ?a +XCMPLX-0K2 sqrtSQUARE-1K3 ?b)^2SQUARE-1K1 =HIDDENR1 (?a +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?a *XCMPLX-0K3 ?b))+XCMPLX-0K2 ?b"
     sorry
  thus "(sqrtSQUARE-1K3 (((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 (((n1 ^2SQUARE-1K1 +XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((((((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1)+XCMPLX-0K2 n1 ^2SQUARE-1K1)+XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((((m1 ^2SQUARE-1K1 +XCMPLX-0K2 m2 ^2SQUARE-1K1)+XCMPLX-0K2 m3 ^2SQUARE-1K1)+XCMPLX-0K2 m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((n1 ^2SQUARE-1K1 +XCMPLX-0K2 n2 ^2SQUARE-1K1)+XCMPLX-0K2 n3 ^2SQUARE-1K1)+XCMPLX-0K2 n4 ^2SQUARE-1K1))"
     sorry
qed "sorry"

mlemma quaterni_lm_31:
" for m1 be RealXREAL-0M1 holds  for m2 be RealXREAL-0M1 holds  for m3 be RealXREAL-0M1 holds  for m4 be RealXREAL-0M1 holds  for n1 be RealXREAL-0M1 holds  for n2 be RealXREAL-0M1 holds  for n3 be RealXREAL-0M1 holds  for n4 be RealXREAL-0M1 holds (sqrtSQUARE-1K3 ((((m1 +XCMPLX-0K2 n1)^2SQUARE-1K1 +XCMPLX-0K2 (m2 +XCMPLX-0K2 n2)^2SQUARE-1K1)+XCMPLX-0K2 (m3 +XCMPLX-0K2 n3)^2SQUARE-1K1)+XCMPLX-0K2 (m4 +XCMPLX-0K2 n4)^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((m1 +XCMPLX-0K2 n1)^2SQUARE-1K1 +XCMPLX-0K2 (m2 +XCMPLX-0K2 n2)^2SQUARE-1K1)+XCMPLX-0K2 (m3 +XCMPLX-0K2 n3)^2SQUARE-1K1)+XCMPLX-0K2 (m4 +XCMPLX-0K2 n4)^2SQUARE-1K1"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix m1 assume [ty]: "m1 be RealXREAL-0M1"
  fix m2 assume [ty]: "m2 be RealXREAL-0M1"
  fix m3 assume [ty]: "m3 be RealXREAL-0M1"
  fix m4 assume [ty]: "m4 be RealXREAL-0M1"
  fix n1 assume [ty]: "n1 be RealXREAL-0M1"
  fix n2 assume [ty]: "n2 be RealXREAL-0M1"
  fix n3 assume [ty]: "n3 be RealXREAL-0M1"
  fix n4 assume [ty]: "n4 be RealXREAL-0M1"
  have "(((m1 +XCMPLX-0K2 n1)^2SQUARE-1K1 +XCMPLX-0K2 (m2 +XCMPLX-0K2 n2)^2SQUARE-1K1)+XCMPLX-0K2 (m3 +XCMPLX-0K2 n3)^2SQUARE-1K1)+XCMPLX-0K2 (m4 +XCMPLX-0K2 n4)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
    using quaterni_th_74 sorry
  thus "(sqrtSQUARE-1K3 ((((m1 +XCMPLX-0K2 n1)^2SQUARE-1K1 +XCMPLX-0K2 (m2 +XCMPLX-0K2 n2)^2SQUARE-1K1)+XCMPLX-0K2 (m3 +XCMPLX-0K2 n3)^2SQUARE-1K1)+XCMPLX-0K2 (m4 +XCMPLX-0K2 n4)^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((m1 +XCMPLX-0K2 n1)^2SQUARE-1K1 +XCMPLX-0K2 (m2 +XCMPLX-0K2 n2)^2SQUARE-1K1)+XCMPLX-0K2 (m3 +XCMPLX-0K2 n3)^2SQUARE-1K1)+XCMPLX-0K2 (m4 +XCMPLX-0K2 n4)^2SQUARE-1K1"
    using square_1_def_2 sorry
qed "sorry"

mtheorem quaterni_th_75:
" for z be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
proof-
  have " for z be QuaternionQUATERNIM1 holds ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "0NUMBERSK6 <=XXREAL-0R1 (ReaQUATERNIK12 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A1: "sqrtSQUARE-1K3 (ReaQUATERNIK12 z)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1)"
      using quaterni_lm_24 square_1_th_26 sorry
    show "ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
    proof-
      have cases: "ReaQUATERNIK12 z >=XXREAL-0R2 0NUMBERSK6 or ReaQUATERNIK12 z <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "ReaQUATERNIK12 z >=XXREAL-0R2 0NUMBERSK6 implies ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume "ReaQUATERNIK12 z >=XXREAL-0R2 0NUMBERSK6"
        thus "ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_22 sorry
      qed
      have case2: "ReaQUATERNIK12 z <XXREAL-0R3 0NUMBERSK6 implies ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume A2: "ReaQUATERNIK12 z <XXREAL-0R3 0NUMBERSK6"
        then have "-XCMPLX-0K4 ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_23 sorry
        thus "ReaQUATERNIK12 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_76:
" for z be QuaternionQUATERNIM1 holds Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
proof-
  have " for z be QuaternionQUATERNIM1 holds Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "0NUMBERSK6 <=XXREAL-0R1 (Im1QUATERNIK13 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A1: "sqrtSQUARE-1K3 (Im1QUATERNIK13 z)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1)"
      using quaterni_lm_24 square_1_th_26 sorry
    show "Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
    proof-
      have cases: "Im1QUATERNIK13 z >=XXREAL-0R2 0NUMBERSK6 or Im1QUATERNIK13 z <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "Im1QUATERNIK13 z >=XXREAL-0R2 0NUMBERSK6 implies Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume "Im1QUATERNIK13 z >=XXREAL-0R2 0NUMBERSK6"
        thus "Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_22 sorry
      qed
      have case2: "Im1QUATERNIK13 z <XXREAL-0R3 0NUMBERSK6 implies Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume A2: "Im1QUATERNIK13 z <XXREAL-0R3 0NUMBERSK6"
        then have "-XCMPLX-0K4 Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_23 sorry
        thus "Im1QUATERNIK13 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_77:
" for z be QuaternionQUATERNIM1 holds Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
proof-
  have " for z be QuaternionQUATERNIM1 holds Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "0NUMBERSK6 <=XXREAL-0R1 (Im2QUATERNIK14 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A1: "sqrtSQUARE-1K3 (Im2QUATERNIK14 z)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1)"
      using quaterni_lm_25 square_1_th_26 sorry
    show "Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
    proof-
      have cases: "Im2QUATERNIK14 z >=XXREAL-0R2 0NUMBERSK6 or Im2QUATERNIK14 z <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "Im2QUATERNIK14 z >=XXREAL-0R2 0NUMBERSK6 implies Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume "Im2QUATERNIK14 z >=XXREAL-0R2 0NUMBERSK6"
        thus "Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_22 sorry
      qed
      have case2: "Im2QUATERNIK14 z <XXREAL-0R3 0NUMBERSK6 implies Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume A2: "Im2QUATERNIK14 z <XXREAL-0R3 0NUMBERSK6"
        then have "-XCMPLX-0K4 Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_23 sorry
        thus "Im2QUATERNIK14 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_78:
" for z be QuaternionQUATERNIM1 holds Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
proof-
  have " for z be QuaternionQUATERNIM1 holds Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have "0NUMBERSK6 <=XXREAL-0R1 (Im3QUATERNIK15 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A1: "sqrtSQUARE-1K3 (Im3QUATERNIK15 z)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1)"
      using quaterni_lm_26 square_1_th_26 sorry
    show "Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
    proof-
      have cases: "Im3QUATERNIK15 z >=XXREAL-0R2 0NUMBERSK6 or Im3QUATERNIK15 z <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "Im3QUATERNIK15 z >=XXREAL-0R2 0NUMBERSK6 implies Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume "Im3QUATERNIK15 z >=XXREAL-0R2 0NUMBERSK6"
        thus "Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_22 sorry
      qed
      have case2: "Im3QUATERNIK15 z <XXREAL-0R3 0NUMBERSK6 implies Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
      proof(rule impI)
        assume A2: "Im3QUATERNIK15 z <XXREAL-0R3 0NUMBERSK6"
        then have "-XCMPLX-0K4 Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A1 square_1_th_23 sorry
        thus "Im3QUATERNIK15 z <=XXREAL-0R1  |.QUATERNIK27 z.|"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_79:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 +QUATERNIK21 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 +QUATERNIK21 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    let ?m1 = "ReaQUATERNIK12 z1"
    let ?m2 = "Im1QUATERNIK13 z1"
    let ?m3 = "Im2QUATERNIK14 z1"
    let ?m4 = "Im3QUATERNIK15 z1"
    let ?n1 = "ReaQUATERNIK12 z2"
    let ?n2 = "Im1QUATERNIK13 z2"
    let ?n3 = "Im2QUATERNIK14 z2"
    let ?n4 = "Im3QUATERNIK15 z2"
    let ?a = "((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1"
    let ?b = "((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1"
    have A1: " |.QUATERNIK27 z1.| >=XXREAL-0R2 0NUMBERSK6"
      using quaterni_th_67 sorry
    have " |.QUATERNIK27 z2.| >=XXREAL-0R2 0NUMBERSK6"
      using quaterni_th_67 sorry
    then have A2: " |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.| >=XXREAL-0R2 0NUMBERSK6"
      using A1 sorry
    have A3: "(sqrtSQUARE-1K3 (((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 (((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((((((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1)+XCMPLX-0K2 ?n1 ^2SQUARE-1K1)+XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1))"
      using quaterni_lm_30 sorry
    have A4: "(sqrtSQUARE-1K3 ((((?m1 +XCMPLX-0K2 ?n1)^2SQUARE-1K1 +XCMPLX-0K2 (?m2 +XCMPLX-0K2 ?n2)^2SQUARE-1K1)+XCMPLX-0K2 (?m3 +XCMPLX-0K2 ?n3)^2SQUARE-1K1)+XCMPLX-0K2 (?m4 +XCMPLX-0K2 ?n4)^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (((?m1 +XCMPLX-0K2 ?n1)^2SQUARE-1K1 +XCMPLX-0K2 (?m2 +XCMPLX-0K2 ?n2)^2SQUARE-1K1)+XCMPLX-0K2 (?m3 +XCMPLX-0K2 ?n3)^2SQUARE-1K1)+XCMPLX-0K2 (?m4 +XCMPLX-0K2 ?n4)^2SQUARE-1K1"
      using quaterni_lm_31 sorry
    have A5: "ReaQUATERNIK12 (z1 +QUATERNIK21 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2"
      using quaterni_th_36 sorry
    have A6: "Im1QUATERNIK13 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2"
      using quaterni_th_36 sorry
    have A7: "Im2QUATERNIK14 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2"
      using quaterni_th_36 sorry
    have A8: "Im3QUATERNIK15 (z1 +QUATERNIK21 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2"
      using quaterni_th_36 sorry
    have A9: "(?m1 *XCMPLX-0K3 ?n2)^2SQUARE-1K1 +XCMPLX-0K2 (?m2 *XCMPLX-0K3 ?n1)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (?m1 *XCMPLX-0K3 ?n2))*XCMPLX-0K3 (?m2 *XCMPLX-0K3 ?n1)"
      using series_3_th_6 sorry
    have A10: "(?m1 *XCMPLX-0K3 ?n3)^2SQUARE-1K1 +XCMPLX-0K2 (?m3 *XCMPLX-0K3 ?n1)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (?m1 *XCMPLX-0K3 ?n3))*XCMPLX-0K3 (?m3 *XCMPLX-0K3 ?n1)"
      using series_3_th_6 sorry
    have A11: "(?m1 *XCMPLX-0K3 ?n4)^2SQUARE-1K1 +XCMPLX-0K2 (?m4 *XCMPLX-0K3 ?n1)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (?m1 *XCMPLX-0K3 ?n4))*XCMPLX-0K3 (?m4 *XCMPLX-0K3 ?n1)"
      using series_3_th_6 sorry
    have A12: "(?m2 *XCMPLX-0K3 ?n3)^2SQUARE-1K1 +XCMPLX-0K2 (?m3 *XCMPLX-0K3 ?n2)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (?m2 *XCMPLX-0K3 ?n3))*XCMPLX-0K3 (?m3 *XCMPLX-0K3 ?n2)"
      using series_3_th_6 sorry
    have A13: "(?m2 *XCMPLX-0K3 ?n4)^2SQUARE-1K1 +XCMPLX-0K2 (?m4 *XCMPLX-0K3 ?n2)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (?m2 *XCMPLX-0K3 ?n4))*XCMPLX-0K3 (?m4 *XCMPLX-0K3 ?n2)"
      using series_3_th_6 sorry
    have A14: "(?m3 *XCMPLX-0K3 ?n4)^2SQUARE-1K1 +XCMPLX-0K2 (?m4 *XCMPLX-0K3 ?n3)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (?m3 *XCMPLX-0K3 ?n4))*XCMPLX-0K3 (?m4 *XCMPLX-0K3 ?n3)"
      using series_3_th_6 sorry
    let ?a1 = "(?m1 *XCMPLX-0K3 ?n2)^2SQUARE-1K1"
    let ?a2 = "(?m2 *XCMPLX-0K3 ?n1)^2SQUARE-1K1"
    let ?a3 = "(?m1 *XCMPLX-0K3 ?n3)^2SQUARE-1K1"
    let ?a4 = "(?m3 *XCMPLX-0K3 ?n1)^2SQUARE-1K1"
    let ?a5 = "(?m1 *XCMPLX-0K3 ?n4)^2SQUARE-1K1"
    let ?a6 = "(?m4 *XCMPLX-0K3 ?n1)^2SQUARE-1K1"
    let ?a7 = "(?m2 *XCMPLX-0K3 ?n3)^2SQUARE-1K1"
    let ?a8 = "(?m3 *XCMPLX-0K3 ?n2)^2SQUARE-1K1"
    let ?a9 = "(?m2 *XCMPLX-0K3 ?n4)^2SQUARE-1K1"
    let ?a10 = "(?m4 *XCMPLX-0K3 ?n2)^2SQUARE-1K1"
    let ?a11 = "(?m3 *XCMPLX-0K3 ?n4)^2SQUARE-1K1"
    let ?a12 = "(?m4 *XCMPLX-0K3 ?n3)^2SQUARE-1K1"
    let ?b1 = "(\<two>\<^sub>M *XCMPLX-0K3 (?m1 *XCMPLX-0K3 ?n2))*XCMPLX-0K3 (?m2 *XCMPLX-0K3 ?n1)"
    let ?b2 = "(\<two>\<^sub>M *XCMPLX-0K3 (?m1 *XCMPLX-0K3 ?n3))*XCMPLX-0K3 (?m3 *XCMPLX-0K3 ?n1)"
    let ?b3 = "(\<two>\<^sub>M *XCMPLX-0K3 (?m1 *XCMPLX-0K3 ?n4))*XCMPLX-0K3 (?m4 *XCMPLX-0K3 ?n1)"
    let ?b4 = "(\<two>\<^sub>M *XCMPLX-0K3 (?m2 *XCMPLX-0K3 ?n3))*XCMPLX-0K3 (?m3 *XCMPLX-0K3 ?n2)"
    let ?b5 = "(\<two>\<^sub>M *XCMPLX-0K3 (?m2 *XCMPLX-0K3 ?n4))*XCMPLX-0K3 (?m4 *XCMPLX-0K3 ?n2)"
    let ?b6 = "(\<two>\<^sub>M *XCMPLX-0K3 (?m3 *XCMPLX-0K3 ?n4))*XCMPLX-0K3 (?m4 *XCMPLX-0K3 ?n3)"
    have "(((((?a1 +XCMPLX-0K2 ?a2)+XCMPLX-0K2 (?a3 +XCMPLX-0K2 ?a4))+XCMPLX-0K2 (?a5 +XCMPLX-0K2 ?a6))+XCMPLX-0K2 (?a7 +XCMPLX-0K2 ?a8))+XCMPLX-0K2 (?a9 +XCMPLX-0K2 ?a10))+XCMPLX-0K2 (?a11 +XCMPLX-0K2 ?a12) >=XXREAL-0R2 ((((?b1 +XCMPLX-0K2 ?b2)+XCMPLX-0K2 ?b3)+XCMPLX-0K2 ?b4)+XCMPLX-0K2 ?b5)+XCMPLX-0K2 ?b6"
      using A9 A10 A11 A12 A13 A14 quaterni_lm_28 sorry
    then have "(((((((((((?a1 +XCMPLX-0K2 ?a2)+XCMPLX-0K2 ?a3)+XCMPLX-0K2 ?a4)+XCMPLX-0K2 ?a5)+XCMPLX-0K2 ?a6)+XCMPLX-0K2 ?a7)+XCMPLX-0K2 ?a8)+XCMPLX-0K2 ?a9)+XCMPLX-0K2 ?a10)+XCMPLX-0K2 ?a11)+XCMPLX-0K2 ?a12)+XCMPLX-0K2 ((((?m1 *XCMPLX-0K3 ?n1)^2SQUARE-1K1 +XCMPLX-0K2 (?m2 *XCMPLX-0K3 ?n2)^2SQUARE-1K1)+XCMPLX-0K2 (?m3 *XCMPLX-0K3 ?n3)^2SQUARE-1K1)+XCMPLX-0K2 (?m4 *XCMPLX-0K3 ?n4)^2SQUARE-1K1) >=XXREAL-0R2 (((((?b1 +XCMPLX-0K2 ?b2)+XCMPLX-0K2 ?b3)+XCMPLX-0K2 ?b4)+XCMPLX-0K2 ?b5)+XCMPLX-0K2 ?b6)+XCMPLX-0K2 ((((?m1 *XCMPLX-0K3 ?n1)^2SQUARE-1K1 +XCMPLX-0K2 (?m2 *XCMPLX-0K3 ?n2)^2SQUARE-1K1)+XCMPLX-0K2 (?m3 *XCMPLX-0K3 ?n3)^2SQUARE-1K1)+XCMPLX-0K2 (?m4 *XCMPLX-0K3 ?n4)^2SQUARE-1K1)"
      using xreal_1_th_6 sorry
    then have "(((((((((((?a1 +XCMPLX-0K2 ?a2)+XCMPLX-0K2 ?a3)+XCMPLX-0K2 ?a4)+XCMPLX-0K2 ?a5)+XCMPLX-0K2 ?a6)+XCMPLX-0K2 ?a7)+XCMPLX-0K2 ?a8)+XCMPLX-0K2 ?a9)+XCMPLX-0K2 ?a10)+XCMPLX-0K2 ?a11)+XCMPLX-0K2 ?a12)+XCMPLX-0K2 ((((?m1 *XCMPLX-0K3 ?n1)^2SQUARE-1K1 +XCMPLX-0K2 (?m2 *XCMPLX-0K3 ?n2)^2SQUARE-1K1)+XCMPLX-0K2 (?m3 *XCMPLX-0K3 ?n3)^2SQUARE-1K1)+XCMPLX-0K2 (?m4 *XCMPLX-0K3 ?n4)^2SQUARE-1K1) >=XXREAL-0R2 (((?m1 *XCMPLX-0K3 ?n1 +XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n2)+XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n3)+XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n4)^2SQUARE-1K1"
       sorry
    then have "sqrtSQUARE-1K3 ((((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1)) >=XXREAL-0R2 ((?m1 *XCMPLX-0K3 ?n1 +XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n2)+XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n3)+XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n4"
      using quaterni_lm_27 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1)) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 (((?m1 *XCMPLX-0K3 ?n1 +XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n2)+XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n3)+XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n4)"
      using xreal_1_th_64 sorry
    then have "(?a +XCMPLX-0K2 ?b)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1)) >=XXREAL-0R2 (?a +XCMPLX-0K2 ?b)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (((?m1 *XCMPLX-0K3 ?n1 +XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n2)+XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n3)+XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n4)"
      using xreal_1_th_6 sorry
    thus " |.QUATERNIK27 z1 +QUATERNIK21 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
      using A2 A3 A4 A5 A6 A7 A8 quaterni_lm_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_80:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 -QUATERNIK23 z2 .|"
      using quaterni_th_79 sorry
    thus " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1.| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
      using quaterni_th_72 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_32:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 =HIDDENR1 (z1 +QUATERNIK21 z2)-QUATERNIK24 z2"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 =HIDDENR1 (z1 +QUATERNIK21 z2)-QUATERNIK24 z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have A1: "z1 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1,Im1QUATERNIK13 z1,Im2QUATERNIK14 z1,Im3QUATERNIK15 z1 *]"
      using quaterni_th_24 sorry
    have A2: "z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z2,Im1QUATERNIK13 z2,Im2QUATERNIK14 z2,Im3QUATERNIK15 z2 *]"
      using quaterni_th_24 sorry
    have A3: "-QUATERNIK23 z2 =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 z2,-XCMPLX-0K4 Im2QUATERNIK14 z2,-XCMPLX-0K4 Im3QUATERNIK15 z2 *]"
      using quaterni_th_62 sorry
    have "z1 +QUATERNIK21 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
      using A1 A2 quaterni_def_7 sorry
    then have "(z1 +QUATERNIK21 z2)-QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 (ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)-XCMPLX-0K6 ReaQUATERNIK12 z2,(Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)-XCMPLX-0K6 Im1QUATERNIK13 z2,(Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)-XCMPLX-0K6 Im2QUATERNIK14 z2,(Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)-XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
      using A3 quaterni_def_7 sorry
    thus "z1 =HIDDENR1 (z1 +QUATERNIK21 z2)-QUATERNIK24 z2"
      using quaterni_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_33:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 =HIDDENR1 (z1 -QUATERNIK24 z2)+QUATERNIK21 z2"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 =HIDDENR1 (z1 -QUATERNIK24 z2)+QUATERNIK21 z2"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have A1: "z1 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1,Im1QUATERNIK13 z1,Im2QUATERNIK14 z1,Im3QUATERNIK15 z1 *]"
      using quaterni_th_24 sorry
    have A2: "z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z2,Im1QUATERNIK13 z2,Im2QUATERNIK14 z2,Im3QUATERNIK15 z2 *]"
      using quaterni_th_24 sorry
    have "-QUATERNIK23 z2 =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 z2,-XCMPLX-0K4 Im2QUATERNIK14 z2,-XCMPLX-0K4 Im3QUATERNIK15 z2 *]"
      using quaterni_th_62 sorry
    then have "z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z2),Im1QUATERNIK13 z1 +XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z2),Im2QUATERNIK14 z1 +XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z2),Im3QUATERNIK15 z1 +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z2) *]"
      using A1 quaterni_def_7 sorry
    then have "(z1 -QUATERNIK24 z2)+QUATERNIK21 z2 =HIDDENR1 [*QUATERNIK5 (ReaQUATERNIK12 z1 +XCMPLX-0K2 (-XCMPLX-0K4 ReaQUATERNIK12 z2))+XCMPLX-0K2 ReaQUATERNIK12 z2,(Im1QUATERNIK13 z1 +XCMPLX-0K2 (-XCMPLX-0K4 Im1QUATERNIK13 z2))+XCMPLX-0K2 Im1QUATERNIK13 z2,(Im2QUATERNIK14 z1 +XCMPLX-0K2 (-XCMPLX-0K4 Im2QUATERNIK14 z2))+XCMPLX-0K2 Im2QUATERNIK14 z2,(Im3QUATERNIK15 z1 +XCMPLX-0K2 (-XCMPLX-0K4 Im3QUATERNIK15 z2))+XCMPLX-0K2 Im3QUATERNIK15 z2 *]"
      using A2 quaterni_def_7 sorry
    also have "... = [*QUATERNIK5 (ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)-XCMPLX-0K6 ReaQUATERNIK12 z2,(Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)-XCMPLX-0K6 Im1QUATERNIK13 z2,(Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)-XCMPLX-0K6 Im2QUATERNIK14 z2,(Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)-XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
       sorry
    finally have "(z1 -QUATERNIK24 z2)+QUATERNIK21 z2 =HIDDENR1 [*QUATERNIK5 (ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)-XCMPLX-0K6 ReaQUATERNIK12 z2,(Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)-XCMPLX-0K6 Im1QUATERNIK13 z2,(Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)-XCMPLX-0K6 Im2QUATERNIK14 z2,(Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)-XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
       sorry
    thus "z1 =HIDDENR1 (z1 -QUATERNIK24 z2)+QUATERNIK21 z2"
      using quaterni_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_34:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have A1: "z1 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1,Im1QUATERNIK13 z1,Im2QUATERNIK14 z1,Im3QUATERNIK15 z1 *]"
      using quaterni_th_24 sorry
    have "-QUATERNIK23 z2 =XBOOLE-0R4 [*QUATERNIK5 -XCMPLX-0K4 ReaQUATERNIK12 z2,-XCMPLX-0K4 Im1QUATERNIK13 z2,-XCMPLX-0K4 Im2QUATERNIK14 z2,-XCMPLX-0K4 Im3QUATERNIK15 z2 *]"
      using quaterni_th_62 sorry
    thus "z1 -QUATERNIK24 z2 =XBOOLE-0R4 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2 *]"
      using A1 quaterni_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_35:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 -QUATERNIK23 (z2 -QUATERNIK24 z1)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 -QUATERNIK23 (z2 -QUATERNIK24 z1)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have A1: "ReaQUATERNIK12 (z2 -QUATERNIK24 z1) =COMPLEX1R1 ReaQUATERNIK12 z2 -XCMPLX-0K6 ReaQUATERNIK12 z1"
      using quaterni_th_42 sorry
    have A2: "Im1QUATERNIK13 (z2 -QUATERNIK24 z1) =COMPLEX1R1 Im1QUATERNIK13 z2 -XCMPLX-0K6 Im1QUATERNIK13 z1"
      using quaterni_th_42 sorry
    have A3: "Im2QUATERNIK14 (z2 -QUATERNIK24 z1) =COMPLEX1R1 Im2QUATERNIK14 z2 -XCMPLX-0K6 Im2QUATERNIK14 z1"
      using quaterni_th_42 sorry
    have A4: "Im3QUATERNIK15 (z2 -QUATERNIK24 z1) =COMPLEX1R1 Im3QUATERNIK15 z2 -XCMPLX-0K6 Im3QUATERNIK15 z1"
      using quaterni_th_42 sorry
    have A5: "ReaQUATERNIK12 (-QUATERNIK23 (z2 -QUATERNIK24 z1)) =COMPLEX1R1 -XCMPLX-0K4 (ReaQUATERNIK12 z2 -XCMPLX-0K6 ReaQUATERNIK12 z1)"
      using A1 quaterni_th_41 sorry
    have A6: "Im1QUATERNIK13 (-QUATERNIK23 (z2 -QUATERNIK24 z1)) =COMPLEX1R1 -XCMPLX-0K4 (Im1QUATERNIK13 z2 -XCMPLX-0K6 Im1QUATERNIK13 z1)"
      using A2 quaterni_th_41 sorry
    have A7: "Im2QUATERNIK14 (-QUATERNIK23 (z2 -QUATERNIK24 z1)) =COMPLEX1R1 -XCMPLX-0K4 (Im2QUATERNIK14 z2 -XCMPLX-0K6 Im2QUATERNIK14 z1)"
      using A3 quaterni_th_41 sorry
    have A8: "Im3QUATERNIK15 (-QUATERNIK23 (z2 -QUATERNIK24 z1)) =COMPLEX1R1 -XCMPLX-0K4 (Im3QUATERNIK15 z2 -XCMPLX-0K6 Im3QUATERNIK15 z1)"
      using A4 quaterni_th_41 sorry
    have A9: "ReaQUATERNIK12 (z1 -QUATERNIK24 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2"
      using quaterni_th_42 sorry
    have A10: "Im1QUATERNIK13 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2"
      using quaterni_th_42 sorry
    have A11: "Im2QUATERNIK14 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2"
      using quaterni_th_42 sorry
    have "Im3QUATERNIK15 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2"
      using quaterni_th_42 sorry
    thus "z1 -QUATERNIK24 z2 =XBOOLE-0R4 -QUATERNIK23 (z2 -QUATERNIK24 z1)"
      using quaterni_th_25 A9 A10 A11 A5 A6 A7 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_36:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 0NUMBERSK6 implies z1 =HIDDENR1 z2"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 0NUMBERSK6 implies z1 =HIDDENR1 z2"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    assume A1: "z1 -QUATERNIK24 z2 =XBOOLE-0R4 0NUMBERSK6"
    have A2: "ReaQUATERNIK12 (z1 -QUATERNIK24 z2) =COMPLEX1R1 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2"
      using quaterni_th_42 sorry
    have A3: "Im1QUATERNIK13 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2"
      using quaterni_th_42 sorry
    have A4: "Im2QUATERNIK14 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2"
      using quaterni_th_42 sorry
    have A5: "Im3QUATERNIK15 (z1 -QUATERNIK24 z2) =COMPLEX1R1 Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2"
      using quaterni_th_42 sorry
    have A6: "ReaQUATERNIK12 (z1 -QUATERNIK24 z2) =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have A7: "Im1QUATERNIK13 (z1 -QUATERNIK24 z2) =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have A8: "Im2QUATERNIK14 (z1 -QUATERNIK24 z2) =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    have "Im3QUATERNIK15 (z1 -QUATERNIK24 z2) =COMPLEX1R1 0NUMBERSK6"
      using A1 quaterni_lm_5 quaterni_th_23 sorry
    thus "z1 =HIDDENR1 z2"
      using A2 A3 A4 A5 A6 A7 A8 quaterni_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_81:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 +QUATERNIK21 z2 .|"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 +QUATERNIK21 z2 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 =HIDDENR1 (z1 +QUATERNIK21 z2)-QUATERNIK24 z2"
      using quaterni_lm_32 sorry
    then have " |.QUATERNIK27 z1.| <=XXREAL-0R1  |.QUATERNIK27 z1 +QUATERNIK21 z2 .| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
      using quaterni_th_80 sorry
    thus " |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 +QUATERNIK21 z2 .|"
      using xreal_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_82:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have "z1 =HIDDENR1 (z1 -QUATERNIK24 z2)+QUATERNIK21 z2"
      using quaterni_lm_33 sorry
    then have " |.QUATERNIK27 z1.| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| +XCMPLX-0K2  |.QUATERNIK27 z2.|"
      using quaterni_th_79 sorry
    thus " |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
      using xreal_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_83:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1  |.QUATERNIK27 z2 -QUATERNIK24 z1 .|"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =HIDDENR1  |.QUATERNIK27 z2 -QUATERNIK24 z1 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =HIDDENR1  |.QUATERNIK27 -QUATERNIK23 (z2 -QUATERNIK24 z1) .|"
      using quaterni_lm_35 sorry
    also have "... =  |.QUATERNIK27 z2 -QUATERNIK24 z1 .|"
      using quaterni_th_72 sorry
    finally show " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =HIDDENR1  |.QUATERNIK27 z2 -QUATERNIK24 z1 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_84:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1 0NUMBERSK6 iff z1 =HIDDENR1 z2"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ( |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1 0NUMBERSK6 implies z1 =HIDDENR1 z2) & (z1 =HIDDENR1 z2 implies  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    show " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1 0NUMBERSK6 implies z1 =HIDDENR1 z2"
      using quaterni_lm_36 quaterni_th_66 sorry
    assume "z1 =HIDDENR1 z2"
    then have "z1 -QUATERNIK24 z2 =HIDDENR1 [*QUATERNIK5 ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z1,Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z1,Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z1,Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z1 *]"
      using quaterni_lm_34 sorry
    also have "... = 0NUMBERSK6"
      using quaterni_lm_5 sorry
    finally have "z1 -QUATERNIK24 z2 =HIDDENR1 0NUMBERSK6"
       sorry
    thus " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1 0NUMBERSK6"
      using quaterni_th_65 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma quaterni_lm_37:
" for z be QuaternionQUATERNIM1 holds  for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 (z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)"
proof(rule ballI,rule ballI,rule ballI)
  fix z assume [ty]: "z be QuaternionQUATERNIM1"
  fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
  fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
  have A1: "ReaQUATERNIK12 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 ReaQUATERNIK12 (z1 -QUATERNIK24 z) +XCMPLX-0K2 ReaQUATERNIK12 (z -QUATERNIK24 z2)"
    using quaterni_lm_10 sorry
  also have "... = ReaQUATERNIK12 (z1 -QUATERNIK24 z) +XCMPLX-0K2 (ReaQUATERNIK12 z -XCMPLX-0K6 ReaQUATERNIK12 z2)"
    using quaterni_th_42 sorry
  also have "... = (ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z)+XCMPLX-0K2 (ReaQUATERNIK12 z -XCMPLX-0K6 ReaQUATERNIK12 z2)"
    using quaterni_th_42 sorry
  also have "... = ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2"
     sorry
  also have "... = ReaQUATERNIK12 (z1 -QUATERNIK24 z2)"
    using quaterni_th_42 sorry
  finally have "ReaQUATERNIK12 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 ReaQUATERNIK12 (z1 -QUATERNIK24 z2)"
     sorry
  have A2: "Im1QUATERNIK13 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 Im1QUATERNIK13 (z1 -QUATERNIK24 z) +XCMPLX-0K2 Im1QUATERNIK13 (z -QUATERNIK24 z2)"
    using quaterni_lm_10 sorry
  also have "... = Im1QUATERNIK13 (z1 -QUATERNIK24 z) +XCMPLX-0K2 (Im1QUATERNIK13 z -XCMPLX-0K6 Im1QUATERNIK13 z2)"
    using quaterni_th_42 sorry
  also have "... = (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z)+XCMPLX-0K2 (Im1QUATERNIK13 z -XCMPLX-0K6 Im1QUATERNIK13 z2)"
    using quaterni_th_42 sorry
  also have "... = Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2"
     sorry
  also have "... = Im1QUATERNIK13 (z1 -QUATERNIK24 z2)"
    using quaterni_th_42 sorry
  finally have "Im1QUATERNIK13 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 Im1QUATERNIK13 (z1 -QUATERNIK24 z2)"
     sorry
  have A3: "Im2QUATERNIK14 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 Im2QUATERNIK14 (z1 -QUATERNIK24 z) +XCMPLX-0K2 Im2QUATERNIK14 (z -QUATERNIK24 z2)"
    using quaterni_lm_10 sorry
  also have "... = Im2QUATERNIK14 (z1 -QUATERNIK24 z) +XCMPLX-0K2 (Im2QUATERNIK14 z -XCMPLX-0K6 Im2QUATERNIK14 z2)"
    using quaterni_th_42 sorry
  also have "... = (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z)+XCMPLX-0K2 (Im2QUATERNIK14 z -XCMPLX-0K6 Im2QUATERNIK14 z2)"
    using quaterni_th_42 sorry
  also have "... = Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2"
     sorry
  also have "... = Im2QUATERNIK14 (z1 -QUATERNIK24 z2)"
    using quaterni_th_42 sorry
  finally have "Im2QUATERNIK14 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 Im2QUATERNIK14 (z1 -QUATERNIK24 z2)"
     sorry
  have "Im3QUATERNIK15 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 Im3QUATERNIK15 (z1 -QUATERNIK24 z) +XCMPLX-0K2 Im3QUATERNIK15 (z -QUATERNIK24 z2)"
    using quaterni_lm_10 sorry
  also have "... = Im3QUATERNIK15 (z1 -QUATERNIK24 z) +XCMPLX-0K2 (Im3QUATERNIK15 z -XCMPLX-0K6 Im3QUATERNIK15 z2)"
    using quaterni_th_42 sorry
  also have "... = (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z)+XCMPLX-0K2 (Im3QUATERNIK15 z -XCMPLX-0K6 Im3QUATERNIK15 z2)"
    using quaterni_th_42 sorry
  also have "... = Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2"
     sorry
  also have "... = Im3QUATERNIK15 (z1 -QUATERNIK24 z2)"
    using quaterni_th_42 sorry
  finally have "Im3QUATERNIK15 ((z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)) =HIDDENR1 Im3QUATERNIK15 (z1 -QUATERNIK24 z2)"
     sorry
  thus "z1 -QUATERNIK24 z2 =XBOOLE-0R4 (z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2)"
    using A1 A2 A3 quaterni_th_25 sorry
qed "sorry"

mtheorem quaterni_th_85:
" for z be QuaternionQUATERNIM1 holds  for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z .| +XCMPLX-0K2  |.QUATERNIK27 z -QUATERNIK24 z2 .|"
proof-
  have " for z be QuaternionQUATERNIM1 holds  for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z .| +XCMPLX-0K2  |.QUATERNIK27 z -QUATERNIK24 z2 .|"
  proof(rule ballI,rule ballI,rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| =COMPLEX1R1  |.QUATERNIK27 (z1 -QUATERNIK24 z)+QUATERNIK21 (z -QUATERNIK24 z2) .|"
      using quaterni_lm_37 sorry
    thus " |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z .| +XCMPLX-0K2  |.QUATERNIK27 z -QUATERNIK24 z2 .|"
      using quaterni_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_86:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.COMPLEX1K10  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.COMPLEX1K10  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    have " |.QUATERNIK27 z2.| -XCMPLX-0K6  |.QUATERNIK27 z1.| <=XXREAL-0R1  |.QUATERNIK27 z2 -QUATERNIK24 z1 .|"
      using quaterni_th_82 sorry
    then have "-XCMPLX-0K4 ( |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.|) <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
      using quaterni_th_83 sorry
    then have A1: "-XCMPLX-0K4  |.QUATERNIK27 z1 -QUATERNIK24 z2 .| <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 ( |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.|))"
      using xreal_1_th_24 sorry
    have " |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
      using quaterni_th_82 sorry
    thus " |.COMPLEX1K10  |.QUATERNIK27 z1.| -XCMPLX-0K6  |.QUATERNIK27 z2.| .| <=XXREAL-0R1  |.QUATERNIK27 z1 -QUATERNIK24 z2 .|"
      using A1 absvalue_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_87:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 *QUATERNIK22 z2 .| =COMPLEX1R1 ( |.QUATERNIK27 z1.|)*XCMPLX-0K3 ( |.QUATERNIK27 z2.|)"
proof-
  have " for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z1 *QUATERNIK22 z2 .| =COMPLEX1R1 ( |.QUATERNIK27 z1.|)*XCMPLX-0K3 ( |.QUATERNIK27 z2.|)"
  proof(rule ballI,rule ballI)
    fix z1 assume [ty]: "z1 be QuaternionQUATERNIM1"
    fix z2 assume [ty]: "z2 be QuaternionQUATERNIM1"
    let ?m1 = "ReaQUATERNIK12 z1"
    let ?m2 = "Im1QUATERNIK13 z1"
    let ?m3 = "Im2QUATERNIK14 z1"
    let ?m4 = "Im3QUATERNIK15 z1"
    let ?n1 = "ReaQUATERNIK12 z2"
    let ?n2 = "Im1QUATERNIK13 z2"
    let ?n3 = "Im2QUATERNIK14 z2"
    let ?n4 = "Im3QUATERNIK15 z2"
    have A1: "ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((?m1 *XCMPLX-0K3 ?n1 -XCMPLX-0K6 ?m2 *XCMPLX-0K3 ?n2)-XCMPLX-0K6 ?m3 *XCMPLX-0K3 ?n3)-XCMPLX-0K6 ?m4 *XCMPLX-0K3 ?n4"
      using quaterni_lm_15 sorry
    have A2: "Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((?m1 *XCMPLX-0K3 ?n2 +XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n1)+XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n4)-XCMPLX-0K6 ?m4 *XCMPLX-0K3 ?n3"
      using quaterni_lm_15 sorry
    have A3: "Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((?m1 *XCMPLX-0K3 ?n3 +XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n1)+XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n2)-XCMPLX-0K6 ?m2 *XCMPLX-0K3 ?n4"
      using quaterni_lm_15 sorry
    have A4: "Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 ((?m1 *XCMPLX-0K3 ?n4 +XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n1)+XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n3)-XCMPLX-0K6 ?m3 *XCMPLX-0K3 ?n2"
      using quaterni_lm_15 sorry
    let ?b1 = "((?m1 *XCMPLX-0K3 ?n1 -XCMPLX-0K6 ?m2 *XCMPLX-0K3 ?n2)-XCMPLX-0K6 ?m3 *XCMPLX-0K3 ?n3)-XCMPLX-0K6 ?m4 *XCMPLX-0K3 ?n4"
    let ?b2 = "((?m1 *XCMPLX-0K3 ?n2 +XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n1)+XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n4)-XCMPLX-0K6 ?m4 *XCMPLX-0K3 ?n3"
    let ?b3 = "((?m1 *XCMPLX-0K3 ?n3 +XCMPLX-0K2 ?m3 *XCMPLX-0K3 ?n1)+XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n2)-XCMPLX-0K6 ?m2 *XCMPLX-0K3 ?n4"
    let ?b4 = "((?m1 *XCMPLX-0K3 ?n4 +XCMPLX-0K2 ?m4 *XCMPLX-0K3 ?n1)+XCMPLX-0K2 ?m2 *XCMPLX-0K3 ?n3)-XCMPLX-0K6 ?m3 *XCMPLX-0K3 ?n2"
    have A5: "((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using quaterni_th_74 sorry
    have A6: "((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using quaterni_th_74 sorry
    have "sqrtSQUARE-1K3 (((?b1 ^2SQUARE-1K1 +XCMPLX-0K2 ?b2 ^2SQUARE-1K1)+XCMPLX-0K2 ?b3 ^2SQUARE-1K1)+XCMPLX-0K2 ?b4 ^2SQUARE-1K1) =COMPLEX1R1 sqrtSQUARE-1K3 ((((?m1 ^2SQUARE-1K1 +XCMPLX-0K2 ?m2 ^2SQUARE-1K1)+XCMPLX-0K2 ?m3 ^2SQUARE-1K1)+XCMPLX-0K2 ?m4 ^2SQUARE-1K1)*XCMPLX-0K3 (((?n1 ^2SQUARE-1K1 +XCMPLX-0K2 ?n2 ^2SQUARE-1K1)+XCMPLX-0K2 ?n3 ^2SQUARE-1K1)+XCMPLX-0K2 ?n4 ^2SQUARE-1K1))"
       sorry
    thus " |.QUATERNIK27 z1 *QUATERNIK22 z2 .| =COMPLEX1R1 ( |.QUATERNIK27 z1.|)*XCMPLX-0K3 ( |.QUATERNIK27 z2.|)"
      using A1 A2 A3 A4 A5 A6 square_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_88:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *QUATERNIK22 z .| =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1"
proof-
  have " for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *QUATERNIK22 z .| =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have A1: "(((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using quaterni_th_74 sorry
    have "( |.QUATERNIK27 z.|)*XCMPLX-0K3 ( |.QUATERNIK27 z.|) =HIDDENR1 (sqrtSQUARE-1K3 ((((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1))^2SQUARE-1K1"
       sorry
    also have "... = (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1"
      using A1 square_1_def_2 sorry
    finally have "( |.QUATERNIK27 z.|)*XCMPLX-0K3 ( |.QUATERNIK27 z.|) =HIDDENR1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1"
       sorry
    thus " |.QUATERNIK27 z *QUATERNIK22 z .| =COMPLEX1R1 (((ReaQUATERNIK12 z)^2SQUARE-1K1 +XCMPLX-0K2 (Im1QUATERNIK13 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im2QUATERNIK14 z)^2SQUARE-1K1)+XCMPLX-0K2 (Im3QUATERNIK15 z)^2SQUARE-1K1"
      using quaterni_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_89:
" for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *QUATERNIK22 z .| =COMPLEX1R1  |.QUATERNIK27 z *QUATERNIK22 z *'QUATERNIK26 .|"
proof-
  have " for z be QuaternionQUATERNIM1 holds  |.QUATERNIK27 z *QUATERNIK22 z .| =HIDDENR1  |.QUATERNIK27 z *QUATERNIK22 z *'QUATERNIK26 .|"
  proof(rule ballI)
    fix z assume [ty]: "z be QuaternionQUATERNIM1"
    have " |.QUATERNIK27 z *QUATERNIK22 z .| =HIDDENR1 ( |.QUATERNIK27 z.|)*XCMPLX-0K3 ( |.QUATERNIK27 z.|)"
      using quaterni_th_87 sorry
    also have "... = ( |.QUATERNIK27 z.|)*XCMPLX-0K3 ( |.QUATERNIK27 z *'QUATERNIK26.|)"
      using quaterni_th_73 sorry
    also have "... =  |.QUATERNIK27 z *QUATERNIK22 z *'QUATERNIK26 .|"
      using quaterni_th_87 sorry
    finally show " |.QUATERNIK27 z *QUATERNIK22 z .| =HIDDENR1  |.QUATERNIK27 z *QUATERNIK22 z *'QUATERNIK26 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem quaterni_th_90:
" for z be QuaternionQUATERNIM1 holds z be realXREAL-0V1 implies ((ReaQUATERNIK12 z =HIDDENR1 z & Im1QUATERNIK13 z =COMPLEX1R1 0NUMBERSK6) & Im2QUATERNIK14 z =COMPLEX1R1 0NUMBERSK6) & Im3QUATERNIK15 z =COMPLEX1R1 0NUMBERSK6"
  using quaterni_lm_16 sorry

mtheorem quaterni_th_91:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds [*QUATERNIK5 x,y,0NUMBERSK6,0NUMBERSK6 *] =XBOOLE-0R4 [*ARYTM-0K5 x,y *]"
  using quaterni_lm_2 sorry

mtheorem quaterni_th_92:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 +QUATERNIK21 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 +XCMPLX-0K2 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 +XCMPLX-0K2 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 +XCMPLX-0K2 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 +XCMPLX-0K2 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_18 sorry

mtheorem quaterni_th_93:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 *QUATERNIK22 z2 =XBOOLE-0R4 ((((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))+QUATERNIK18 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 ((((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_19 sorry

mtheorem quaterni_th_94:
" for z be QuaternionQUATERNIM1 holds -QUATERNIK23 z =XBOOLE-0R4 (((-XCMPLX-0K4 ReaQUATERNIK12 z)+QUATERNIK18 (-XCMPLX-0K4 Im1QUATERNIK13 z)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (-XCMPLX-0K4 Im2QUATERNIK14 z)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (-XCMPLX-0K4 Im3QUATERNIK15 z)*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_22 sorry

mtheorem quaterni_th_95:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds z1 -QUATERNIK24 z2 =XBOOLE-0R4 (((ReaQUATERNIK12 z1 -XCMPLX-0K6 ReaQUATERNIK12 z2)+QUATERNIK18 (Im1QUATERNIK13 z1 -XCMPLX-0K6 Im1QUATERNIK13 z2)*QUATERNIK20 (<i>XCMPLX-0K1))+QUATERNIK21 (Im2QUATERNIK14 z1 -XCMPLX-0K6 Im2QUATERNIK14 z2)*QUATERNIK20 (<j>QUATERNIK10))+QUATERNIK21 (Im3QUATERNIK15 z1 -XCMPLX-0K6 Im3QUATERNIK15 z2)*QUATERNIK20 (<k>QUATERNIK11)"
  using quaterni_lm_23 sorry

mtheorem quaterni_th_96:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 d ^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6 implies ((a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6) & c =COMPLEX1R1 0NUMBERSK6) & d =COMPLEX1R1 0NUMBERSK6"
  using quaterni_lm_8 sorry

mtheorem quaterni_th_97:
" for z1 be QuaternionQUATERNIM1 holds  for z2 be QuaternionQUATERNIM1 holds ((ReaQUATERNIK12 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2) -XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) & Im1QUATERNIK13 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2) +XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2))-XCMPLX-0K6 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2)) & Im2QUATERNIK14 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2) +XCMPLX-0K2 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2))-XCMPLX-0K6 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2)) & Im3QUATERNIK15 (z1 *QUATERNIK22 z2) =COMPLEX1R1 (((ReaQUATERNIK12 z1)*XCMPLX-0K3 (Im3QUATERNIK15 z2) +XCMPLX-0K2 (Im3QUATERNIK15 z1)*XCMPLX-0K3 (ReaQUATERNIK12 z2))+XCMPLX-0K2 (Im1QUATERNIK13 z1)*XCMPLX-0K3 (Im2QUATERNIK14 z2))-XCMPLX-0K6 (Im2QUATERNIK14 z1)*XCMPLX-0K3 (Im1QUATERNIK13 z2)"
  using quaterni_lm_15 sorry

end
