theory xboole_1
  imports xboole_0
begin
(*begin*)
reserve x, A, B, X, X9, Y, Y9, Z, V for "setHIDDENM2"
(*\$N Modus Barbara*)
mtheorem xboole_1_th_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y & Y c=TARSKIR1 Z implies X c=TARSKIR1 Z"
   sorry

mtheorem xboole_1_th_2:
" for X be setHIDDENM2 holds {}XBOOLE-0K1 c=TARSKIR1 X"
   sorry

mtheorem xboole_1_th_3:
" for X be setHIDDENM2 holds X c=TARSKIR1 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds X c=TARSKIR1 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume Cut41: "X c=TARSKIR1 {}XBOOLE-0K1"
    have "X c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 X"
    proof-
      show "X c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 X"
        using Cut41 sorry
    qed
    thus "X =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =XBOOLE-0R4 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =XBOOLE-0R4 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "(X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z c=TARSKIR1 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z) & X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z"
    proof(rule conjMI)
      show "(X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z c=TARSKIR1 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z implies x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z"
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y or x inHIDDENR3 Z"
            using xboole_0_def_3 sorry
          then have "(x inHIDDENR3 X or x inHIDDENR3 Y) or x inHIDDENR3 Z"
            using xboole_0_def_3 sorry
          then have "x inHIDDENR3 X or x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "(X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z c=TARSKIR1 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z) implies x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
        then have "x inHIDDENR3 X or x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using xboole_0_def_3 sorry
        then have "(x inHIDDENR3 X or x inHIDDENR3 Y) or x inHIDDENR3 Z"
          using xboole_0_def_3 sorry
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y or x inHIDDENR3 Z"
          using xboole_0_def_3 sorry
        thus "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z"
        using tarski_def_3 sorry
    qed
    thus "(X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =XBOOLE-0R4 X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "(X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =HIDDENR1 X \\/XBOOLE-0K2 ((Z \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 Y)"
      using xboole_1_th_4 sorry
    also have "... = X \\/XBOOLE-0K2 (Z \\/XBOOLE-0K2 (Z \\/XBOOLE-0K2 Y))"
      using xboole_1_th_4 sorry
    also have "... = (X \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
      using xboole_1_th_4 sorry
    finally have "(X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =HIDDENR1 (X \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
       sorry
    thus "(X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\/XBOOLE-0K2 (X \\/XBOOLE-0K2 Y) =HIDDENR1 (X \\/XBOOLE-0K2 X)\\/XBOOLE-0K2 Y"
      using xboole_1_th_4 sorry
    also have "... = X \\/XBOOLE-0K2 Y"
       sorry
    finally have "X \\/XBOOLE-0K2 (X \\/XBOOLE-0K2 Y) =HIDDENR1 X \\/XBOOLE-0K2 Y"
       sorry
    thus "X \\/XBOOLE-0K2 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 X \\/XBOOLE-0K2 Y"
  using xboole_0_def_3 sorry

mtheorem xboole_1_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Y c=TARSKIR1 Z implies X \\/XBOOLE-0K2 Y c=TARSKIR1 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Z & Y c=TARSKIR1 Z implies X \\/XBOOLE-0K2 Y c=TARSKIR1 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Z & Y c=TARSKIR1 Z"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x inHIDDENR3 Z"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
      then have "x inHIDDENR3 X or x inHIDDENR3 Y"
        using xboole_0_def_3 sorry
      thus "x inHIDDENR3 Z"
        using A1 sorry
    qed "sorry"
    thus "X \\/XBOOLE-0K2 Y c=TARSKIR1 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X \\/XBOOLE-0K2 Z c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X \\/XBOOLE-0K2 Z c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Z implies x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X \\/XBOOLE-0K2 Z"
      then have "x inHIDDENR3 X or x inHIDDENR3 Z"
        using xboole_0_def_3 sorry
      then have "x inHIDDENR3 Y or x inHIDDENR3 Z"
        using A1 sorry
      thus "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "X \\/XBOOLE-0K2 Z c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X c=TARSKIR1 Z \\/XBOOLE-0K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not (X c=TARSKIR1 Y &  not X c=TARSKIR1 Z \\/XBOOLE-0K2 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "Y c=TARSKIR1 Z \\/XBOOLE-0K2 Y"
      using xboole_1_th_7 sorry
    thus " not (X c=TARSKIR1 Y &  not X c=TARSKIR1 Z \\/XBOOLE-0K2 Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\/XBOOLE-0K2 Y c=TARSKIR1 Z implies X c=TARSKIR1 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not (X \\/XBOOLE-0K2 Y c=TARSKIR1 Z &  not X c=TARSKIR1 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X c=TARSKIR1 X \\/XBOOLE-0K2 Y"
      using xboole_1_th_7 sorry
    thus " not (X \\/XBOOLE-0K2 Y c=TARSKIR1 Z &  not X c=TARSKIR1 Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_12:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have "X \\/XBOOLE-0K2 Y c=TARSKIR1 Y & Y c=TARSKIR1 X \\/XBOOLE-0K2 Y"
    proof(rule conjMI)
      show "X \\/XBOOLE-0K2 Y c=TARSKIR1 Y"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          then have "x inHIDDENR3 X or x inHIDDENR3 Y"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 Y"
            using A1 sorry
        qed "sorry"
        thus "X \\/XBOOLE-0K2 Y c=TARSKIR1 Y"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Y &  not x inHIDDENR3 X \\/XBOOLE-0K2 Y)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show " not (x inHIDDENR3 Y &  not x inHIDDENR3 X \\/XBOOLE-0K2 Y)"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 X \\/XBOOLE-0K2 Y"
        using tarski_def_3 sorry
    qed
    thus "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_13:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds X c=TARSKIR1 Y & Z c=TARSKIR1 V implies X \\/XBOOLE-0K2 Z c=TARSKIR1 Y \\/XBOOLE-0K2 V"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds X c=TARSKIR1 Y implies (Z c=TARSKIR1 V implies X \\/XBOOLE-0K2 Z c=TARSKIR1 Y \\/XBOOLE-0K2 V)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V assume [ty]: "V be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    assume A2: "Z c=TARSKIR1 V"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Z implies x inHIDDENR3 Y \\/XBOOLE-0K2 V"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X \\/XBOOLE-0K2 Z"
      then have "x inHIDDENR3 X or x inHIDDENR3 Z"
        using xboole_0_def_3 sorry
      then have "x inHIDDENR3 Y or x inHIDDENR3 V"
        using A1 A2 sorry
      thus "x inHIDDENR3 Y \\/XBOOLE-0K2 V"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "X \\/XBOOLE-0K2 Z c=TARSKIR1 Y \\/XBOOLE-0K2 V"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_14:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (Y c=TARSKIR1 X & Z c=TARSKIR1 X) & ( for V be setHIDDENM2 holds Y c=TARSKIR1 V & Z c=TARSKIR1 V implies X c=TARSKIR1 V) implies X =XBOOLE-0R4 Y \\/XBOOLE-0K2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (Y c=TARSKIR1 X & Z c=TARSKIR1 X) & ( for V be setHIDDENM2 holds Y c=TARSKIR1 V & Z c=TARSKIR1 V implies X c=TARSKIR1 V) implies X =XBOOLE-0R4 Y \\/XBOOLE-0K2 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "Y c=TARSKIR1 X & Z c=TARSKIR1 X"
      and A2: " for V be setHIDDENM2 holds Y c=TARSKIR1 V & Z c=TARSKIR1 V implies X c=TARSKIR1 V"
    have Cut159: "Y c=TARSKIR1 Y \\/XBOOLE-0K2 Z & Z c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
      using xboole_1_th_7 sorry
    have "X c=TARSKIR1 Y \\/XBOOLE-0K2 Z & Y \\/XBOOLE-0K2 Z c=TARSKIR1 X"
    proof(rule conjMI)
      show "X c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
        using A2 Cut159 sorry
      show "Y \\/XBOOLE-0K2 Z c=TARSKIR1 X"
        using A1 xboole_1_th_8 sorry
    qed
    thus "X =XBOOLE-0R4 Y \\/XBOOLE-0K2 Z"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_15:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
   sorry

mtheorem xboole_1_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z =XBOOLE-0R4 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z =XBOOLE-0R4 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "(X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z c=TARSKIR1 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) & X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) c=TARSKIR1 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
    proof(rule conjMI)
      show "(X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z c=TARSKIR1 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z implies x inHIDDENR3 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
          then have A2: "x inHIDDENR3 Z"
            using xboole_0_def_4 sorry
          have A3: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
            using A1 xboole_0_def_4 sorry
          then have A4: "x inHIDDENR3 X"
            using xboole_0_def_4 sorry
          have "x inHIDDENR3 Y"
            using A3 xboole_0_def_4 sorry
          then have "x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
            using A2 xboole_0_def_4 sorry
          thus "x inHIDDENR3 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
            using A4 xboole_0_def_4 sorry
        qed "sorry"
        thus "(X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z c=TARSKIR1 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) implies x inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
        then have A6: "x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
          using xboole_0_def_4 sorry
        then have A7: "x inHIDDENR3 Y"
          using xboole_0_def_4 sorry
        have A8: "x inHIDDENR3 Z"
          using A6 xboole_0_def_4 sorry
        have "x inHIDDENR3 X"
          using A5 xboole_0_def_4 sorry
        then have "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using A7 xboole_0_def_4 sorry
        thus "x inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
          using A8 xboole_0_def_4 sorry
      qed "sorry"
      thus "X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) c=TARSKIR1 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
        using tarski_def_3 sorry
    qed
    thus "(X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z =XBOOLE-0R4 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_17:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y c=TARSKIR1 X"
  using xboole_0_def_4 sorry

mtheorem xboole_1_th_18:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y /\\XBOOLE-0K3 Z implies X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not (X c=TARSKIR1 Y /\\XBOOLE-0K3 Z &  not X c=TARSKIR1 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "Y /\\XBOOLE-0K3 Z c=TARSKIR1 Y"
      using xboole_1_th_17 sorry
    thus " not (X c=TARSKIR1 Y /\\XBOOLE-0K3 Z &  not X c=TARSKIR1 Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z c=TARSKIR1 X & Z c=TARSKIR1 Y implies Z c=TARSKIR1 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Z c=TARSKIR1 X & Z c=TARSKIR1 Y implies Z c=TARSKIR1 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "Z c=TARSKIR1 X & Z c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Z implies x inHIDDENR3 X /\\XBOOLE-0K3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 Z"
      then have "x inHIDDENR3 X & x inHIDDENR3 Y"
        using A1 sorry
      thus "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
    qed "sorry"
    thus "Z c=TARSKIR1 X /\\XBOOLE-0K3 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_20:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X c=TARSKIR1 Y & X c=TARSKIR1 Z) & ( for V be setHIDDENM2 holds V c=TARSKIR1 Y & V c=TARSKIR1 Z implies V c=TARSKIR1 X) implies X =XBOOLE-0R4 Y /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X c=TARSKIR1 Y & X c=TARSKIR1 Z) & ( for V be setHIDDENM2 holds V c=TARSKIR1 Y & V c=TARSKIR1 Z implies V c=TARSKIR1 X) implies X =XBOOLE-0R4 Y /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y & X c=TARSKIR1 Z"
      and A2: " for V be setHIDDENM2 holds V c=TARSKIR1 Y & V c=TARSKIR1 Z implies V c=TARSKIR1 X"
    have "X c=TARSKIR1 Y /\\XBOOLE-0K3 Z & Y /\\XBOOLE-0K3 Z c=TARSKIR1 X"
    proof(rule conjMI)
      show "X c=TARSKIR1 Y /\\XBOOLE-0K3 Z"
        using A1 xboole_1_th_19 sorry
      have "Y /\\XBOOLE-0K3 Z c=TARSKIR1 Y & Y /\\XBOOLE-0K3 Z c=TARSKIR1 Z implies Y /\\XBOOLE-0K3 Z c=TARSKIR1 X"
        using A2 sorry
      thus "Y /\\XBOOLE-0K3 Z c=TARSKIR1 X"
        using xboole_1_th_17 sorry
    qed
    thus "X =XBOOLE-0R4 Y /\\XBOOLE-0K3 Z"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_21:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 X & X c=TARSKIR1 X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y)"
    proof(rule conjMI)
      show "X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y) c=TARSKIR1 X"
        using xboole_0_def_4 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 X"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 sorry
        thus "x inHIDDENR3 X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y)"
          using A1 xboole_0_def_4 sorry
      qed "sorry"
      thus "X c=TARSKIR1 X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y)"
        using tarski_def_3 sorry
    qed
    thus "X /\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y c=TARSKIR1 X & X c=TARSKIR1 X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
    proof(rule conjMI)
      show "X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y c=TARSKIR1 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
          then have "x inHIDDENR3 X or x inHIDDENR3 X /\\XBOOLE-0K3 Y"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 X"
            using xboole_0_def_4 sorry
        qed "sorry"
        thus "X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x inHIDDENR3 X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show " not (x inHIDDENR3 X &  not x inHIDDENR3 X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y)"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "X c=TARSKIR1 X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
        using tarski_def_3 sorry
    qed
    thus "X \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_23:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z & X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z c=TARSKIR1 X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z)"
    proof(rule conjMI)
      show "X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) implies x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z)"
          then have "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
            using xboole_0_def_4 sorry
          then have A2: "x inHIDDENR3 Y or x inHIDDENR3 Z"
            using xboole_0_def_3 sorry
          have "x inHIDDENR3 X"
            using A1 xboole_0_def_4 sorry
          then have "x inHIDDENR3 X /\\XBOOLE-0K3 Y or x inHIDDENR3 X /\\XBOOLE-0K3 Z"
            using A2 xboole_0_def_4 sorry
          thus "x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z implies x inHIDDENR3 X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
        then have "x inHIDDENR3 X /\\XBOOLE-0K3 Y or x inHIDDENR3 X /\\XBOOLE-0K3 Z"
          using xboole_0_def_3 sorry
        then have A3: "x inHIDDENR3 X & x inHIDDENR3 Y or x inHIDDENR3 X & x inHIDDENR3 Z"
          using xboole_0_def_4 sorry
        then have "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using xboole_0_def_3 sorry
        thus "x inHIDDENR3 X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z)"
          using A3 xboole_0_def_4 sorry
      qed "sorry"
      thus "X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z c=TARSKIR1 X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z)"
        using tarski_def_3 sorry
    qed
    thus "X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_24:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z) & (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z) c=TARSKIR1 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
    proof(rule conjMI)
      show "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z implies x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
          then have "x inHIDDENR3 X or x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
            using xboole_0_def_3 sorry
          then have "x inHIDDENR3 X or x inHIDDENR3 Y & x inHIDDENR3 Z"
            using xboole_0_def_4 sorry
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y & x inHIDDENR3 X \\/XBOOLE-0K2 Z"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
            using xboole_0_def_4 sorry
        qed "sorry"
        thus "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z) implies x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Z"
          using xboole_0_def_4 sorry
        then have A2: "x inHIDDENR3 X or x inHIDDENR3 Z"
          using xboole_0_def_3 sorry
        have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using A1 xboole_0_def_4 sorry
        then have "x inHIDDENR3 X or x inHIDDENR3 Y"
          using xboole_0_def_3 sorry
        then have "x inHIDDENR3 X or x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
          using A2 xboole_0_def_4 sorry
        thus "x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "(X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z) c=TARSKIR1 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
        using tarski_def_3 sorry
    qed
    thus "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_25:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 Z /\\XBOOLE-0K3 X =XBOOLE-0R4 ((X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 (Z \\/XBOOLE-0K2 X)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 Z /\\XBOOLE-0K3 X =HIDDENR1 ((X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 (Z \\/XBOOLE-0K2 X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "(X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 Z /\\XBOOLE-0K3 X =HIDDENR1 ((X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 ((X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 X)"
      using xboole_1_th_24 sorry
    also have "... = (X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (Y /\\XBOOLE-0K3 Z \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 ((X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 X)"
      using xboole_1_th_4 sorry
    also have "... = (X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 ((X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 X)"
      using xboole_1_th_22 sorry
    also have "... = (X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 ((X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X)\\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)"
      using xboole_1_th_4 sorry
    also have "... = (X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)"
      using xboole_1_th_22 sorry
    also have "... = ((X \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)"
      using xboole_1_th_24 sorry
    also have "... = ((X \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 ((X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z))"
      using xboole_1_th_24 sorry
    also have "... = (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (((Y \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z))"
      using xboole_1_th_16 sorry
    also have "... = (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 ((Y \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 ((X \\/XBOOLE-0K2 Z)/\\XBOOLE-0K3 (X \\/XBOOLE-0K2 Z)))"
      using xboole_1_th_16 sorry
    also have "... = ((X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 (Z \\/XBOOLE-0K2 X)"
      using xboole_1_th_16 sorry
    finally show "(X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 Z /\\XBOOLE-0K3 X =HIDDENR1 ((X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z))/\\XBOOLE-0K3 (Z \\/XBOOLE-0K2 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_26:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X /\\XBOOLE-0K3 Z c=TARSKIR1 Y /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X /\\XBOOLE-0K3 Z c=TARSKIR1 Y /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Z implies x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 X /\\XBOOLE-0K3 Z"
      then have "x inHIDDENR3 X"
        using xboole_0_def_4 sorry
      then have A3: "x inHIDDENR3 Y"
        using A1 sorry
      have "x inHIDDENR3 Z"
        using A2 xboole_0_def_4 sorry
      thus "x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
        using A3 xboole_0_def_4 sorry
    qed "sorry"
    thus "X /\\XBOOLE-0K3 Z c=TARSKIR1 Y /\\XBOOLE-0K3 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_27:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds X c=TARSKIR1 Y & Z c=TARSKIR1 V implies X /\\XBOOLE-0K3 Z c=TARSKIR1 Y /\\XBOOLE-0K3 V"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds X c=TARSKIR1 Y & Z c=TARSKIR1 V implies X /\\XBOOLE-0K3 Z c=TARSKIR1 Y /\\XBOOLE-0K3 V"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V assume [ty]: "V be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "Z c=TARSKIR1 V"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Z implies x inHIDDENR3 Y /\\XBOOLE-0K3 V"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 X /\\XBOOLE-0K3 Z"
      then have "x inHIDDENR3 Z"
        using xboole_0_def_4 sorry
      then have A4: "x inHIDDENR3 V"
        using A2 sorry
      have "x inHIDDENR3 X"
        using A3 xboole_0_def_4 sorry
      then have "x inHIDDENR3 Y"
        using A1 sorry
      thus "x inHIDDENR3 Y /\\XBOOLE-0K3 V"
        using A4 xboole_0_def_4 sorry
    qed "sorry"
    thus "X /\\XBOOLE-0K3 Z c=TARSKIR1 Y /\\XBOOLE-0K3 V"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_28:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have "X /\\XBOOLE-0K3 Y c=TARSKIR1 X & X c=TARSKIR1 X /\\XBOOLE-0K3 Y"
    proof(rule conjMI)
      show "X /\\XBOOLE-0K3 Y c=TARSKIR1 X"
        using xboole_1_th_17 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 X /\\XBOOLE-0K3 Y"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 X"
        then have "x inHIDDENR3 Y"
          using A1 sorry
        thus "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using A2 xboole_0_def_4 sorry
      qed "sorry"
      thus "X c=TARSKIR1 X /\\XBOOLE-0K3 Y"
        using tarski_def_3 sorry
    qed
    thus "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_29:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Y c=TARSKIR1 X \\/XBOOLE-0K2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Y c=TARSKIR1 X \\/XBOOLE-0K2 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Y c=TARSKIR1 X & X c=TARSKIR1 X \\/XBOOLE-0K2 Z"
      using xboole_1_th_7 xboole_1_th_17 sorry
    thus "X /\\XBOOLE-0K3 Y c=TARSKIR1 X \\/XBOOLE-0K2 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_30:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Z implies X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Z implies X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Z"
    have "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z & (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z c=TARSKIR1 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
    proof(rule conjMI)
      show "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z implies x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
          then have A2: "x inHIDDENR3 X or x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
            using xboole_0_def_3 sorry
          then have "x inHIDDENR3 X or x inHIDDENR3 Y & x inHIDDENR3 Z"
            using xboole_0_def_4 sorry
          then have A3: "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
          have "x inHIDDENR3 Z"
            using A1 A2 xboole_0_def_4 sorry
          thus "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
            using A3 xboole_0_def_4 sorry
        qed "sorry"
        thus "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z implies x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_4 sorry
        then have A5: "x inHIDDENR3 X or x inHIDDENR3 Y"
          using xboole_0_def_3 sorry
        have "x inHIDDENR3 Z"
          using A4 xboole_0_def_4 sorry
        then have "x inHIDDENR3 X & x inHIDDENR3 Z or x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
          using A5 xboole_0_def_4 sorry
        thus "x inHIDDENR3 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "(X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z c=TARSKIR1 X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z"
        using tarski_def_3 sorry
    qed
    thus "X \\/XBOOLE-0K2 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Z"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_31:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z implies x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
      then have "x inHIDDENR3 X /\\XBOOLE-0K3 Y or x inHIDDENR3 X /\\XBOOLE-0K3 Z"
        using xboole_0_def_3 sorry
      then have "x inHIDDENR3 X & x inHIDDENR3 Y or x inHIDDENR3 X & x inHIDDENR3 Z"
        using xboole_0_def_4 sorry
      thus "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xboole_1_lm_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y =XBOOLE-0R4 {}XBOOLE-0K1 iff X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X \\XBOOLE-0K4 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X c=TARSKIR1 Y) & (X c=TARSKIR1 Y implies X \\XBOOLE-0K4 Y =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "X \\XBOOLE-0K4 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X c=TARSKIR1 Y"
      using xboole_0_def_5 sorry
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y iff x inHIDDENR3 {}XBOOLE-0K1"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 X &  not x inHIDDENR3 Y iff  False "
        using A1 sorry
      thus "x inHIDDENR3 X \\XBOOLE-0K4 Y iff x inHIDDENR3 {}XBOOLE-0K1"
        using xboole_0_def_5 sorry
    qed "sorry"
    thus "X \\XBOOLE-0K4 Y =XBOOLE-0R4 {}XBOOLE-0K1"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_32:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y =XBOOLE-0R4 Y \\XBOOLE-0K4 X implies X =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y =XBOOLE-0R4 Y \\XBOOLE-0K4 X implies X =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X \\XBOOLE-0K4 Y =XBOOLE-0R4 Y \\XBOOLE-0K4 X"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Y"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 X &  not x inHIDDENR3 Y iff x inHIDDENR3 Y \\XBOOLE-0K4 X"
        using A1 xboole_0_def_5 sorry
      thus "x inHIDDENR3 X iff x inHIDDENR3 Y"
        using xboole_0_def_5 sorry
    qed "sorry"
    thus "X =XBOOLE-0R4 Y"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_33:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X \\XBOOLE-0K4 Z c=TARSKIR1 Y \\XBOOLE-0K4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X \\XBOOLE-0K4 Z c=TARSKIR1 Y \\XBOOLE-0K4 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Z implies x inHIDDENR3 Y \\XBOOLE-0K4 Z"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 X \\XBOOLE-0K4 Z"
      then have "x inHIDDENR3 X"
        using xboole_0_def_5 sorry
      then have A3: "x inHIDDENR3 Y"
        using A1 sorry
      have " not x inHIDDENR3 Z"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 Y \\XBOOLE-0K4 Z"
        using A3 xboole_0_def_5 sorry
    qed "sorry"
    thus "X \\XBOOLE-0K4 Z c=TARSKIR1 Y \\XBOOLE-0K4 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_34:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies Z \\XBOOLE-0K4 Y c=TARSKIR1 Z \\XBOOLE-0K4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies Z \\XBOOLE-0K4 Y c=TARSKIR1 Z \\XBOOLE-0K4 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Z \\XBOOLE-0K4 Y implies x inHIDDENR3 Z \\XBOOLE-0K4 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 Z \\XBOOLE-0K4 Y"
      then have " not x inHIDDENR3 Y"
        using xboole_0_def_5 sorry
      then have A3: " not x inHIDDENR3 X"
        using A1 sorry
      have "x inHIDDENR3 Z"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 Z \\XBOOLE-0K4 X"
        using A3 xboole_0_def_5 sorry
    qed "sorry"
    thus "Z \\XBOOLE-0K4 Y c=TARSKIR1 Z \\XBOOLE-0K4 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xboole_1_lm_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z) & (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z) c=TARSKIR1 X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z"
    proof(rule conjMI)
      show "X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z implies x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z"
          then have " not x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
            using xboole_0_def_5 sorry
          then have A2: " not x inHIDDENR3 Y or  not x inHIDDENR3 Z"
            using xboole_0_def_4 sorry
          have "x inHIDDENR3 X"
            using A1 xboole_0_def_5 sorry
          then have "x inHIDDENR3 X \\XBOOLE-0K4 Y or x inHIDDENR3 X \\XBOOLE-0K4 Z"
            using A2 xboole_0_def_5 sorry
          thus "x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z c=TARSKIR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
          using tarski_def_3 sorry
      qed
      have "X \\XBOOLE-0K4 Y c=TARSKIR1 X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z & X \\XBOOLE-0K4 Z c=TARSKIR1 X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z"
        using xboole_1_th_17 xboole_1_th_34 sorry
      thus "(X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z) c=TARSKIR1 X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z"
        using xboole_1_th_8 sorry
    qed
    thus "X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_35:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds X c=TARSKIR1 Y & Z c=TARSKIR1 V implies X \\XBOOLE-0K4 V c=TARSKIR1 Y \\XBOOLE-0K4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds X c=TARSKIR1 Y & Z c=TARSKIR1 V implies X \\XBOOLE-0K4 V c=TARSKIR1 Y \\XBOOLE-0K4 Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V assume [ty]: "V be setHIDDENM2"
    assume "X c=TARSKIR1 Y & Z c=TARSKIR1 V"
    then have "X \\XBOOLE-0K4 V c=TARSKIR1 Y \\XBOOLE-0K4 V & Y \\XBOOLE-0K4 V c=TARSKIR1 Y \\XBOOLE-0K4 Z"
      using xboole_1_th_33 xboole_1_th_34 sorry
    thus "X \\XBOOLE-0K4 V c=TARSKIR1 Y \\XBOOLE-0K4 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_36:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y c=TARSKIR1 X"
  using xboole_0_def_5 sorry

mtheorem xboole_1_th_37:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y =XBOOLE-0R4 {}XBOOLE-0K1 iff X c=TARSKIR1 Y"
  using xboole_1_lm_1 sorry

mtheorem xboole_1_th_38:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y \\XBOOLE-0K4 X implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y \\XBOOLE-0K4 X implies X =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y \\XBOOLE-0K4 X"
    have "X c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 X"
    proof(rule conjMI)
      show "X c=TARSKIR1 {}XBOOLE-0K1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 {}XBOOLE-0K1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A2: "x inHIDDENR3 X"
          then have "x inHIDDENR3 Y \\XBOOLE-0K4 X"
            using A1 sorry
          thus "x inHIDDENR3 {}XBOOLE-0K1"
            using A2 xboole_0_def_5 sorry
        qed "sorry"
        thus "X c=TARSKIR1 {}XBOOLE-0K1"
          using tarski_def_3 sorry
      qed
      show "{}XBOOLE-0K1 c=TARSKIR1 X"
         sorry
    qed
    thus "X =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_39:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) c=TARSKIR1 X \\/XBOOLE-0K2 Y & X \\/XBOOLE-0K2 Y c=TARSKIR1 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
    proof(rule conjMI)
      show "X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) c=TARSKIR1 X \\/XBOOLE-0K2 Y"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) implies x inHIDDENR3 X \\/XBOOLE-0K2 Y"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
          then have "x inHIDDENR3 X or x inHIDDENR3 Y \\XBOOLE-0K4 X"
            using xboole_0_def_3 sorry
          then have "x inHIDDENR3 X or x inHIDDENR3 Y"
            using xboole_0_def_5 sorry
          thus "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) c=TARSKIR1 X \\/XBOOLE-0K2 Y"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
        then have "x inHIDDENR3 X or x inHIDDENR3 Y &  not x inHIDDENR3 X"
          using xboole_0_def_3 sorry
        then have "x inHIDDENR3 X or x inHIDDENR3 Y \\XBOOLE-0K4 X"
          using xboole_0_def_5 sorry
        thus "x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "X \\/XBOOLE-0K2 Y c=TARSKIR1 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
        using tarski_def_3 sorry
    qed
    thus "X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y =XBOOLE-0R4 X \\XBOOLE-0K4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y =XBOOLE-0R4 X \\XBOOLE-0K4 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y implies x inHIDDENR3 X \\XBOOLE-0K4 Y) & X \\XBOOLE-0K4 Y c=TARSKIR1 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y implies x inHIDDENR3 X \\XBOOLE-0K4 Y"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_5 sorry
        then have A2: "x inHIDDENR3 X or x inHIDDENR3 Y"
          using xboole_0_def_3 sorry
        have " not x inHIDDENR3 Y"
          using A1 xboole_0_def_5 sorry
        thus "x inHIDDENR3 X \\XBOOLE-0K4 Y"
          using A2 xboole_0_def_5 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y implies x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y"
      proof-
        show " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y implies x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 X \\XBOOLE-0K4 Y"
          then have "x inHIDDENR3 X or x inHIDDENR3 Y"
            using xboole_0_def_5 sorry
          then have A4: "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
          have " not x inHIDDENR3 Y"
            using A3 xboole_0_def_5 sorry
          thus "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y"
            using A4 xboole_0_def_5 sorry
        qed "sorry"
      qed
      thus "X \\XBOOLE-0K4 Y c=TARSKIR1 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y"
        using tarski_def_3 sorry
    qed
    thus "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y =XBOOLE-0R4 X \\XBOOLE-0K4 Y"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z =XBOOLE-0R4 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z =XBOOLE-0R4 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z implies x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)) & X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z implies x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z"
        then have A2: " not x inHIDDENR3 Z"
          using xboole_0_def_5 sorry
        have A3: "x inHIDDENR3 X \\XBOOLE-0K4 Y"
          using A1 xboole_0_def_5 sorry
        then have A4: "x inHIDDENR3 X"
          using xboole_0_def_5 sorry
        have " not x inHIDDENR3 Y"
          using A3 xboole_0_def_5 sorry
        then have " not x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using A2 xboole_0_def_3 sorry
        thus "x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
          using A4 xboole_0_def_5 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) implies x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z"
      proof-
        show " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) implies x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
          then have A6: " not x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
            using xboole_0_def_5 sorry
          then have A7: " not x inHIDDENR3 Y"
            using xboole_0_def_3 sorry
          have A8: " not x inHIDDENR3 Z"
            using A6 xboole_0_def_3 sorry
          have "x inHIDDENR3 X"
            using A5 xboole_0_def_5 sorry
          then have "x inHIDDENR3 X \\XBOOLE-0K4 Y"
            using A7 xboole_0_def_5 sorry
          thus "x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z"
            using A8 xboole_0_def_5 sorry
        qed "sorry"
      qed
      thus "X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 (X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z"
        using tarski_def_3 sorry
    qed
    thus "(X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z =XBOOLE-0R4 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_42:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z c=TARSKIR1 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z) & (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z) c=TARSKIR1 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z"
    proof(rule conjMI)
      show "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z c=TARSKIR1 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z implies x inHIDDENR3 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z"
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_5 sorry
          then have "x inHIDDENR3 X &  not x inHIDDENR3 Z or x inHIDDENR3 Y &  not x inHIDDENR3 Z"
            using A1 xboole_0_def_3 xboole_0_def_5 sorry
          then have "x inHIDDENR3 X \\XBOOLE-0K4 Z or x inHIDDENR3 Y \\XBOOLE-0K4 Z"
            using xboole_0_def_5 sorry
          thus "x inHIDDENR3 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z c=TARSKIR1 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z) implies x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
        then have "x inHIDDENR3 X \\XBOOLE-0K4 Z or x inHIDDENR3 Y \\XBOOLE-0K4 Z"
          using xboole_0_def_3 sorry
        then have A2: "x inHIDDENR3 X &  not x inHIDDENR3 Z or x inHIDDENR3 Y &  not x inHIDDENR3 Z"
          using xboole_0_def_5 sorry
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 sorry
        thus "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z"
          using A2 xboole_0_def_5 sorry
      qed "sorry"
      thus "(X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z) c=TARSKIR1 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z"
        using tarski_def_3 sorry
    qed
    thus "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Z)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_43:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y \\/XBOOLE-0K2 Z implies X \\XBOOLE-0K4 Y c=TARSKIR1 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y \\/XBOOLE-0K2 Z implies X \\XBOOLE-0K4 Y c=TARSKIR1 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y implies x inHIDDENR3 Z"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 X \\XBOOLE-0K4 Y"
      then have "x inHIDDENR3 X"
        using xboole_0_def_5 sorry
      then have A3: "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
        using A1 sorry
      have " not x inHIDDENR3 Y"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 Z"
        using A3 xboole_0_def_3 sorry
    qed "sorry"
    thus "X \\XBOOLE-0K4 Y c=TARSKIR1 Z"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_44:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 Y c=TARSKIR1 Z implies X c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not (X \\XBOOLE-0K4 Y c=TARSKIR1 Z &  not X c=TARSKIR1 Y \\/XBOOLE-0K2 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y implies x inHIDDENR3 Z) implies X c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
    proof(rule impI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y implies x inHIDDENR3 Z"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then have "x inHIDDENR3 X \\XBOOLE-0K4 Y or x inHIDDENR3 Y"
          using xboole_0_def_5 sorry
        then have "x inHIDDENR3 Z or x inHIDDENR3 Y"
          using A1 sorry
        thus "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "X c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
        using tarski_def_3 sorry
    qed
    thus " not (X \\XBOOLE-0K4 Y c=TARSKIR1 Z &  not X c=TARSKIR1 Y \\/XBOOLE-0K2 Z)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_45:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies Y =XBOOLE-0R4 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies Y =XBOOLE-0R4 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 Y iff x inHIDDENR3 X or x inHIDDENR3 Y \\XBOOLE-0K4 X"
        using A1 xboole_0_def_5 sorry
      thus "x inHIDDENR3 Y iff x inHIDDENR3 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "Y =XBOOLE-0R4 X \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_46:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 {}XBOOLE-0K1"
  using xboole_1_th_7 xboole_1_lm_1 sorry

mtheorem xboole_1_th_47:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X \\XBOOLE-0K4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X \\XBOOLE-0K4 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y iff x inHIDDENR3 X \\XBOOLE-0K4 Y"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 X &  not x inHIDDENR3 X /\\XBOOLE-0K3 Y iff x inHIDDENR3 X &  not x inHIDDENR3 Y"
        using xboole_0_def_4 sorry
      thus "x inHIDDENR3 X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y iff x inHIDDENR3 X \\XBOOLE-0K4 Y"
        using xboole_0_def_5 sorry
    qed "sorry"
    thus "X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X \\XBOOLE-0K4 Y"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_48:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y) implies x inHIDDENR3 X /\\XBOOLE-0K3 Y) & X /\\XBOOLE-0K3 Y c=TARSKIR1 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y)"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y) implies x inHIDDENR3 X /\\XBOOLE-0K3 Y"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y)"
        then have " not x inHIDDENR3 X \\XBOOLE-0K4 Y"
          using xboole_0_def_5 sorry
        then have A2: " not x inHIDDENR3 X or x inHIDDENR3 Y"
          using xboole_0_def_5 sorry
        have "x inHIDDENR3 X"
          using A1 xboole_0_def_5 sorry
        thus "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using A2 xboole_0_def_4 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y implies x inHIDDENR3 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y)"
      proof-
        show " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y implies x inHIDDENR3 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          then have " not x inHIDDENR3 X or x inHIDDENR3 Y"
            using xboole_0_def_4 sorry
          then have A4: " not x inHIDDENR3 X \\XBOOLE-0K4 Y"
            using xboole_0_def_5 sorry
          have "x inHIDDENR3 X"
            using A3 xboole_0_def_4 sorry
          thus "x inHIDDENR3 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y)"
            using A4 xboole_0_def_5 sorry
        qed "sorry"
      qed
      thus "X /\\XBOOLE-0K3 Y c=TARSKIR1 X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y)"
        using tarski_def_3 sorry
    qed
    thus "X \\XBOOLE-0K4 (X \\XBOOLE-0K4 Y) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_49:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) iff x inHIDDENR3 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "(x inHIDDENR3 X & x inHIDDENR3 Y) &  not x inHIDDENR3 Z iff (x inHIDDENR3 X & x inHIDDENR3 Y) &  not x inHIDDENR3 Z"
         sorry
      then have "x inHIDDENR3 X & x inHIDDENR3 Y \\XBOOLE-0K4 Z iff x inHIDDENR3 X /\\XBOOLE-0K3 Y &  not x inHIDDENR3 Z"
        using xboole_0_def_4 xboole_0_def_5 sorry
      thus "x inHIDDENR3 X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) iff x inHIDDENR3 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z"
        using xboole_0_def_4 xboole_0_def_5 sorry
    qed "sorry"
    thus "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_50:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have A1: "X /\\XBOOLE-0K3 Y c=TARSKIR1 X"
      using xboole_1_th_17 sorry
    have "X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X /\\XBOOLE-0K3 Z =HIDDENR1 (X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X)\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z)"
      using xboole_1_lm_2 sorry
    also have "... = {}XBOOLE-0K1 \\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z)"
      using A1 xboole_1_lm_1 sorry
    also have "... = X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z"
       sorry
    finally have "X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X /\\XBOOLE-0K3 Z =HIDDENR1 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 Z"
       sorry
    thus "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X /\\XBOOLE-0K3 Z"
      using xboole_1_th_49 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_51:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y) c=TARSKIR1 X & X c=TARSKIR1 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y)"
    proof(rule conjMI)
      show "X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y) c=TARSKIR1 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y) implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y)"
          then have "x inHIDDENR3 X /\\XBOOLE-0K3 Y or x inHIDDENR3 X \\XBOOLE-0K4 Y"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 X"
            using xboole_0_def_4 xboole_0_def_5 sorry
        qed "sorry"
        thus "X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y) c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then have "x inHIDDENR3 X & x inHIDDENR3 Y or x inHIDDENR3 X \\XBOOLE-0K4 Y"
          using xboole_0_def_5 sorry
        then have "x inHIDDENR3 X /\\XBOOLE-0K3 Y or x inHIDDENR3 X \\XBOOLE-0K4 Y"
          using xboole_0_def_4 sorry
        thus "x inHIDDENR3 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y)"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "X c=TARSKIR1 X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y)"
        using tarski_def_3 sorry
    qed
    thus "X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 (X \\XBOOLE-0K4 Y) =XBOOLE-0R4 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_52:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z) implies x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z) & (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z c=TARSKIR1 X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z)"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z) implies x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z)"
        then have " not x inHIDDENR3 Y \\XBOOLE-0K4 Z"
          using xboole_0_def_5 sorry
        then have "x inHIDDENR3 X &  not x inHIDDENR3 Y or x inHIDDENR3 X & x inHIDDENR3 Z"
          using A1 xboole_0_def_5 sorry
        then have "x inHIDDENR3 X \\XBOOLE-0K4 Y or x inHIDDENR3 X /\\XBOOLE-0K3 Z"
          using xboole_0_def_4 xboole_0_def_5 sorry
        thus "x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
          using xboole_0_def_3 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z implies x inHIDDENR3 X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
        then have "x inHIDDENR3 X \\XBOOLE-0K4 Y or x inHIDDENR3 X /\\XBOOLE-0K3 Z"
          using xboole_0_def_3 sorry
        then have A2: "x inHIDDENR3 X &  not x inHIDDENR3 Y or x inHIDDENR3 X & x inHIDDENR3 Z"
          using xboole_0_def_4 xboole_0_def_5 sorry
        then have " not x inHIDDENR3 Y \\XBOOLE-0K4 Z"
          using xboole_0_def_5 sorry
        thus "x inHIDDENR3 X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z)"
          using A2 xboole_0_def_5 sorry
      qed "sorry"
      thus "(X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z c=TARSKIR1 X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z)"
        using tarski_def_3 sorry
    qed
    thus "X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 Z) =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_53:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have Cut759: "X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 X \\XBOOLE-0K4 Y & X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 X \\XBOOLE-0K4 Z"
      using xboole_1_th_7 xboole_1_th_34 sorry
    have "X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z) & (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z) c=TARSKIR1 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
    proof(rule conjMI)
      show "X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) c=TARSKIR1 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z)"
        using xboole_1_th_19 Cut759 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z) implies x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z)"
        then have A2: "x inHIDDENR3 X \\XBOOLE-0K4 Y"
          using xboole_0_def_4 sorry
        then have A3: "x inHIDDENR3 X"
          using xboole_0_def_5 sorry
        have "x inHIDDENR3 X \\XBOOLE-0K4 Z"
          using A1 xboole_0_def_4 sorry
        then have A4: " not x inHIDDENR3 Z"
          using xboole_0_def_5 sorry
        have " not x inHIDDENR3 Y"
          using A2 xboole_0_def_5 sorry
        then have " not x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using A4 xboole_0_def_3 sorry
        thus "x inHIDDENR3 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
          using A3 xboole_0_def_5 sorry
      qed "sorry"
      thus "(X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z) c=TARSKIR1 X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
        using tarski_def_3 sorry
    qed
    thus "X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_54:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X \\XBOOLE-0K4 Z)"
  using xboole_1_lm_2 sorry

mtheorem xboole_1_th_55:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y iff x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y implies x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)) & (x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X) implies x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y implies x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
        proof(rule impI)
          assume A1: "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
          then have " not x inHIDDENR3 X /\\XBOOLE-0K3 Y"
            using xboole_0_def_5 sorry
          then have A2: " not x inHIDDENR3 X or  not x inHIDDENR3 Y"
            using xboole_0_def_4 sorry
          have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using A1 xboole_0_def_5 sorry
          then have "x inHIDDENR3 X or x inHIDDENR3 Y"
            using xboole_0_def_3 sorry
          then have "x inHIDDENR3 X \\XBOOLE-0K4 Y or x inHIDDENR3 Y \\XBOOLE-0K4 X"
            using A2 xboole_0_def_5 sorry
          thus "x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
            using xboole_0_def_3 sorry
        qed
        assume "x inHIDDENR3 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
        then have "x inHIDDENR3 X \\XBOOLE-0K4 Y or x inHIDDENR3 Y \\XBOOLE-0K4 X"
          using xboole_0_def_3 sorry
        then have "x inHIDDENR3 X &  not x inHIDDENR3 Y or x inHIDDENR3 Y &  not x inHIDDENR3 X"
          using xboole_0_def_5 sorry
        then have " not x inHIDDENR3 X /\\XBOOLE-0K3 Y & x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 xboole_0_def_4 sorry
        thus "x inHIDDENR3 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
          using xboole_0_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xboole_1_lm_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y & Y c<XBOOLE-0R2 Z implies X c<XBOOLE-0R2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y & Y c<XBOOLE-0R2 Z implies X c<XBOOLE-0R2 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
      and A2: "Y c<XBOOLE-0R2 Z"
    have Cut811: "Y c=TARSKIR1 Z"
      using A2 sorry
    have "X c=TARSKIR1 Z & X <>HIDDENR2 Z"
    proof-
      show "X c=TARSKIR1 Z & X <>HIDDENR2 Z"
        using A1 A2 xboole_0_def_10 Cut811 sorry
    qed
    thus "X c<XBOOLE-0R2 Z"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_56:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c<XBOOLE-0R2 Y & Y c<XBOOLE-0R2 Z implies X c<XBOOLE-0R2 Z"
  using xboole_1_lm_3 sorry

mtheorem xboole_1_th_57:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (X c<XBOOLE-0R2 Y & Y c<XBOOLE-0R2 X)"
   sorry

mtheorem xboole_1_th_58:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c<XBOOLE-0R2 Y & Y c=TARSKIR1 Z implies X c<XBOOLE-0R2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c<XBOOLE-0R2 Y & Y c=TARSKIR1 Z implies X c<XBOOLE-0R2 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c<XBOOLE-0R2 Y"
      and A2: "Y c=TARSKIR1 Z"
    have Cut828: "X c=TARSKIR1 Y"
      using A1 sorry
    have "X c=TARSKIR1 Z & X <>HIDDENR2 Z"
    proof-
      show "X c=TARSKIR1 Z & X <>HIDDENR2 Z"
        using A1 A2 xboole_0_def_10 Cut828 sorry
    qed
    thus "X c<XBOOLE-0R2 Z"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_59:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y & Y c<XBOOLE-0R2 Z implies X c<XBOOLE-0R2 Z"
  using xboole_1_lm_3 sorry

mtheorem xboole_1_th_60:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies  not Y c<XBOOLE-0R2 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (X c=TARSKIR1 Y & Y c<XBOOLE-0R2 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "(X c=TARSKIR1 Y & Y c=TARSKIR1 X) & X <>HIDDENR2 Y implies  False "
    proof(rule impI)
      assume "(X c=TARSKIR1 Y & Y c=TARSKIR1 X) & X <>HIDDENR2 Y"
      thus " False "
         sorry
    qed
    thus " not (X c=TARSKIR1 Y & Y c<XBOOLE-0R2 X)"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_61:
" for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies {}XBOOLE-0K1 c<XBOOLE-0R2 X"
proof-
  have " for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies {}XBOOLE-0K1 c<XBOOLE-0R2 X"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "{}XBOOLE-0K1 c=TARSKIR1 X &  not {}XBOOLE-0K1 =HIDDENR1 X"
    proof(rule conjMI)
      show "{}XBOOLE-0K1 c=TARSKIR1 X"
         sorry
      show " not {}XBOOLE-0K1 =HIDDENR1 X"
        using A1 sorry
    qed
    thus "{}XBOOLE-0K1 c<XBOOLE-0R2 X"
      using xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_62:
" for X be setHIDDENM2 holds  not X c<XBOOLE-0R2 {}XBOOLE-0K1"
  using xboole_1_th_3 sorry

(*\$N Modus Celarent*)
(*\$N Modus Darii*)
mtheorem xboole_1_th_63:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y & Y missesXBOOLE-0R1 Z implies X missesXBOOLE-0R1 Z"
  using xboole_1_th_3 xboole_1_th_26 sorry

mtheorem xboole_1_th_64:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (A c=TARSKIR1 X & B c=TARSKIR1 Y) & X missesXBOOLE-0R1 Y implies A missesXBOOLE-0R1 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds A c=TARSKIR1 X & (B c=TARSKIR1 Y & X missesXBOOLE-0R1 Y) implies A missesXBOOLE-0R1 B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "A c=TARSKIR1 X"
      and A2: "B c=TARSKIR1 Y"
      and A3: "X missesXBOOLE-0R1 Y"
    have "A missesXBOOLE-0R1 Y"
      using A1 A3 xboole_1_th_63 sorry
    thus "A missesXBOOLE-0R1 B"
      using A2 xboole_1_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_65:
" for X be setHIDDENM2 holds X missesXBOOLE-0R1 {}XBOOLE-0K1"
   sorry

mtheorem xboole_1_th_66:
" for X be setHIDDENM2 holds X meetsXBOOLE-0R5 X iff X <>HIDDENR2 {}XBOOLE-0K1"
   sorry

mtheorem xboole_1_th_67:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X c=TARSKIR1 Y & X c=TARSKIR1 Z) & Y missesXBOOLE-0R1 Z implies X =XBOOLE-0R4 {}XBOOLE-0K1"
  using xboole_1_th_3 xboole_1_th_19 sorry

(*\$N Modus Darapti*)
mtheorem xboole_1_th_68:
" for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds A c=TARSKIR1 Y & A c=TARSKIR1 Z implies Y meetsXBOOLE-0R5 Z"
proof-
  have " for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds A c=TARSKIR1 Y & A c=TARSKIR1 Z implies  not Y meetsXBOOLE-0R5 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 A"
      using xboole_0_def_1 sorry
    assume "A c=TARSKIR1 Y & A c=TARSKIR1 Z"
    then have "x inHIDDENR3 Y & x inHIDDENR3 Z"
      using A1 sorry
    thus " not Y meetsXBOOLE-0R5 Z"
      using xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_69:
" for Y be setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds A c=TARSKIR1 Y implies A meetsXBOOLE-0R5 Y"
  using xboole_1_th_68 sorry

mtheorem xboole_1_th_70:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z iff X meetsXBOOLE-0R5 Y or X meetsXBOOLE-0R5 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z implies X meetsXBOOLE-0R5 Y or X meetsXBOOLE-0R5 Z) &  not ( not (X meetsXBOOLE-0R5 Y & X meetsXBOOLE-0R5 Z) & X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    show "X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z implies X meetsXBOOLE-0R5 Y or X meetsXBOOLE-0R5 Z"
    proof-
      have "X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z implies  not (X meetsXBOOLE-0R5 Y & X meetsXBOOLE-0R5 Z)"
      proof(rule impI)
        assume "X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 X & x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using xboole_0_th_3 sorry
        have "x inHIDDENR3 X & x inHIDDENR3 Y or x inHIDDENR3 X & x inHIDDENR3 Z"
          using A1 xboole_0_def_3 sorry
        thus " not (X meetsXBOOLE-0R5 Y & X meetsXBOOLE-0R5 Z)"
          using xboole_0_th_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A2: "X meetsXBOOLE-0R5 Z implies X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z"
    proof-
      have "X meetsXBOOLE-0R5 Z implies  not X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z"
      proof(rule impI)
        assume "X meetsXBOOLE-0R5 Z"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "x inHIDDENR3 X"and A4: "x inHIDDENR3 Z"
          using xboole_0_th_3 sorry
        have "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using A4 xboole_0_def_3 sorry
        thus " not X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z"
          using A3 xboole_0_th_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "X meetsXBOOLE-0R5 Y implies X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z"
    proof-
      have "X meetsXBOOLE-0R5 Y implies  not X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z"
      proof(rule impI)
        assume "X meetsXBOOLE-0R5 Y"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A5: "x inHIDDENR3 X"and A6: "x inHIDDENR3 Y"
          using xboole_0_th_3 sorry
        have "x inHIDDENR3 Y \\/XBOOLE-0K2 Z"
          using A6 xboole_0_def_3 sorry
        thus " not X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z"
          using A5 xboole_0_th_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( not (X meetsXBOOLE-0R5 Y & X meetsXBOOLE-0R5 Z) & X meetsXBOOLE-0R5 Y \\/XBOOLE-0K2 Z)"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_71:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Z \\/XBOOLE-0K2 Y & X missesXBOOLE-0R1 Y) & Z missesXBOOLE-0R1 Y implies X =XBOOLE-0R4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not (((X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Z \\/XBOOLE-0K2 Y & X missesXBOOLE-0R1 Y) & Z missesXBOOLE-0R1 Y) &  not X =XBOOLE-0R4 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Z \\/XBOOLE-0K2 Y & (X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 & Z /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1) implies X =XBOOLE-0R4 Z"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A1: "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Z \\/XBOOLE-0K2 Y"
        and A2: "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
        and A3: "Z /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
      have "X c=TARSKIR1 Z & Z c=TARSKIR1 X"
      proof(rule conjMI)
        show "X c=TARSKIR1 Z"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A4: "x inHIDDENR3 X"
            have "X c=TARSKIR1 Z \\/XBOOLE-0K2 Y"
              using A1 xboole_1_th_7 sorry
            then have A5: "x inHIDDENR3 Z \\/XBOOLE-0K2 Y"
              using A4 sorry
            have " not x inHIDDENR3 Y"
              using A2 A4 xboole_0_def_4 sorry
            thus "x inHIDDENR3 Z"
              using A5 xboole_0_def_3 sorry
          qed "sorry"
          thus "X c=TARSKIR1 Z"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Z implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A6: "x inHIDDENR3 Z"
          have "Z c=TARSKIR1 X \\/XBOOLE-0K2 Y"
            using A1 xboole_1_th_7 sorry
          then have A7: "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using A6 sorry
          have " not x inHIDDENR3 Y"
            using A3 A6 xboole_0_def_4 sorry
          thus "x inHIDDENR3 X"
            using A7 xboole_0_def_3 sorry
        qed "sorry"
        thus "Z c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
      thus "X =XBOOLE-0R4 Z"
        using xboole_0_def_10 sorry
    qed
    thus " not (((X \\/XBOOLE-0K2 Y =XBOOLE-0R4 Z \\/XBOOLE-0K2 Y & X missesXBOOLE-0R1 Y) & Z missesXBOOLE-0R1 Y) &  not X =XBOOLE-0R4 Z)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_72:
" for X be setHIDDENM2 holds  for X9 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y9 be setHIDDENM2 holds (X9 \\/XBOOLE-0K2 Y9 =XBOOLE-0R4 X \\/XBOOLE-0K2 Y & X missesXBOOLE-0R1 X9) & Y missesXBOOLE-0R1 Y9 implies X =XBOOLE-0R4 Y9"
proof-
  have " for X be setHIDDENM2 holds  for X9 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y9 be setHIDDENM2 holds X9 \\/XBOOLE-0K2 Y9 =XBOOLE-0R4 X \\/XBOOLE-0K2 Y implies (X missesXBOOLE-0R1 X9 & Y missesXBOOLE-0R1 Y9 implies X =HIDDENR1 Y9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X9 assume [ty]: "X9 be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Y9 assume [ty]: "Y9 be setHIDDENM2"
    assume A1: "X9 \\/XBOOLE-0K2 Y9 =XBOOLE-0R4 X \\/XBOOLE-0K2 Y"
    assume "X missesXBOOLE-0R1 X9 & Y missesXBOOLE-0R1 Y9"
    then have A2: "X /\\XBOOLE-0K3 X9 =XBOOLE-0R4 {}XBOOLE-0K1 & Y /\\XBOOLE-0K3 Y9 =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    have "X =HIDDENR1 X /\\XBOOLE-0K3 (X9 \\/XBOOLE-0K2 Y9)"
      using A1 xboole_1_th_7 xboole_1_th_28 sorry
    also have "... = X /\\XBOOLE-0K3 X9 \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y9"
      using xboole_1_th_23 sorry
    also have "... = (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 Y9"
      using A2 xboole_1_th_23 sorry
    also have "... = Y9"
      using A1 xboole_1_th_7 xboole_1_th_28 sorry
    finally show "X =HIDDENR1 Y9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_73:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y \\/XBOOLE-0K2 Z & X missesXBOOLE-0R1 Z implies X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not ((X c=TARSKIR1 Y \\/XBOOLE-0K2 Z & X missesXBOOLE-0R1 Z) &  not X c=TARSKIR1 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X c=TARSKIR1 Y \\/XBOOLE-0K2 Z & X /\\XBOOLE-0K3 Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X c=TARSKIR1 Y"
    proof(rule impMI ,rule impI)
      assume A1: "X c=TARSKIR1 Y \\/XBOOLE-0K2 Z"
        and A2: "X /\\XBOOLE-0K3 Z =XBOOLE-0R4 {}XBOOLE-0K1"
      have "X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 X"
        using A1 xboole_1_th_28 sorry
      then have "Y /\\XBOOLE-0K3 X \\/XBOOLE-0K2 {}XBOOLE-0K1 =XBOOLE-0R4 X"
        using A2 xboole_1_th_23 sorry
      thus "X c=TARSKIR1 Y"
        using xboole_1_th_17 sorry
    qed
    thus " not ((X c=TARSKIR1 Y \\/XBOOLE-0K2 Z & X missesXBOOLE-0R1 Z) &  not X c=TARSKIR1 Y)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_74:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X meetsXBOOLE-0R5 Y /\\XBOOLE-0K3 Z implies X meetsXBOOLE-0R5 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X meetsXBOOLE-0R5 Y /\\XBOOLE-0K3 Z implies  not X meetsXBOOLE-0R5 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume "X meetsXBOOLE-0R5 Y /\\XBOOLE-0K3 Z"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"and A2: "x inHIDDENR3 Y /\\XBOOLE-0K3 Z"
      using xboole_0_th_3 sorry
    have "x inHIDDENR3 Y"
      using A2 xboole_0_def_4 sorry
    thus " not X meetsXBOOLE-0R5 Y"
      using A1 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X meetsXBOOLE-0R5 Y implies X /\\XBOOLE-0K3 Y meetsXBOOLE-0R5 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X meetsXBOOLE-0R5 Y implies  not X /\\XBOOLE-0K3 Y meetsXBOOLE-0R5 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X meetsXBOOLE-0R5 Y"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"and A2: "x inHIDDENR3 Y"
      using xboole_0_th_3 sorry
    have "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
      using A1 A2 xboole_0_def_4 sorry
    thus " not X /\\XBOOLE-0K3 Y meetsXBOOLE-0R5 Y"
      using A2 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_76:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y missesXBOOLE-0R1 Z implies X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y missesXBOOLE-0R1 Z implies X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume "Y missesXBOOLE-0R1 Z"
    then have "X /\\XBOOLE-0K3 Z missesXBOOLE-0R1 Y"
      using xboole_1_th_74 sorry
    thus "X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X /\\XBOOLE-0K3 Z"
      using xboole_1_th_74 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_77:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X meetsXBOOLE-0R5 Y & X c=TARSKIR1 Z implies X meetsXBOOLE-0R5 Y /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X meetsXBOOLE-0R5 Y & X c=TARSKIR1 Z implies  not X meetsXBOOLE-0R5 Y /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X meetsXBOOLE-0R5 Y"
      and A2: "X c=TARSKIR1 Z"
    have "X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume A3: "X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) =XBOOLE-0R4 {}XBOOLE-0K1"
      have "X /\\XBOOLE-0K3 Y =HIDDENR1 (X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 Y"
        using A2 xboole_1_th_28 sorry
      also have "... = {}XBOOLE-0K1"
        using A3 xboole_1_th_16 sorry
      finally have "X /\\XBOOLE-0K3 Y =HIDDENR1 {}XBOOLE-0K1"
         sorry
      thus " False "
        using A1 sorry
    qed
    thus " not X meetsXBOOLE-0R5 Y /\\XBOOLE-0K3 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_78:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =XBOOLE-0R4 X /\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =HIDDENR1 X /\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume "X missesXBOOLE-0R1 Y"
    then have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    then have "X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =HIDDENR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 X /\\XBOOLE-0K3 Z"
      using xboole_1_th_23 sorry
    also have "... = X /\\XBOOLE-0K3 Z"
       sorry
    finally show "X /\\XBOOLE-0K3 (Y \\/XBOOLE-0K2 Z) =HIDDENR1 X /\\XBOOLE-0K3 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_79:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y missesXBOOLE-0R1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y missesXBOOLE-0R1 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have Cut1037: " not ( ex x be objectHIDDENM1 st x inHIDDENR3 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Y)"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Y) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Y"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Y"
           sorry
        have "x inHIDDENR3 X \\XBOOLE-0K4 Y & x inHIDDENR3 Y"
          using A1 xboole_0_def_4 sorry
        thus " False "
          using xboole_0_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "(X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
    proof-
      show "(X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_0_def_1 Cut1037 sorry
    qed
    thus "X \\XBOOLE-0K4 Y missesXBOOLE-0R1 Y"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_80:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies X missesXBOOLE-0R1 Y \\XBOOLE-0K4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies (X meetsXBOOLE-0R5 Y \\XBOOLE-0K4 Z implies  not  True )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X missesXBOOLE-0R1 Y"
    assume "X meetsXBOOLE-0R5 Y \\XBOOLE-0K4 Z"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 X"and A3: "x inHIDDENR3 Y \\XBOOLE-0K4 Z"
      using xboole_0_th_3 sorry
    have "x inHIDDENR3 Y"
      using A3 xboole_0_def_5 sorry
    thus " not  True "
      using A1 A2 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_81:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X missesXBOOLE-0R1 Y \\XBOOLE-0K4 Z implies Y missesXBOOLE-0R1 X \\XBOOLE-0K4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not (X missesXBOOLE-0R1 Y \\XBOOLE-0K4 Z &  not Y missesXBOOLE-0R1 X \\XBOOLE-0K4 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =HIDDENR1 Y /\\XBOOLE-0K3 X \\XBOOLE-0K4 Z"
      using xboole_1_th_49 sorry
    also have "... = Y /\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z)"
      using xboole_1_th_49 sorry
    finally have "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =HIDDENR1 Y /\\XBOOLE-0K3 (X \\XBOOLE-0K4 Z)"
       sorry
    thus " not (X missesXBOOLE-0R1 Y \\XBOOLE-0K4 Z &  not Y missesXBOOLE-0R1 X \\XBOOLE-0K4 Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_82:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y missesXBOOLE-0R1 Y \\XBOOLE-0K4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y meetsXBOOLE-0R5 Y \\XBOOLE-0K4 X implies  not  True "
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X \\XBOOLE-0K4 Y meetsXBOOLE-0R5 Y \\XBOOLE-0K4 X"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X \\XBOOLE-0K4 Y"and A2: "x inHIDDENR3 Y \\XBOOLE-0K4 X"
      using xboole_0_th_3 sorry
    have "x inHIDDENR3 X"
      using A1 xboole_0_def_5 sorry
    thus " not  True "
      using A2 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_83:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X missesXBOOLE-0R1 Y iff X \\XBOOLE-0K4 Y =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X missesXBOOLE-0R1 Y implies X \\XBOOLE-0K4 Y =XBOOLE-0R4 X) & (X \\XBOOLE-0K4 Y =XBOOLE-0R4 X implies X missesXBOOLE-0R1 Y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "X missesXBOOLE-0R1 Y implies X \\XBOOLE-0K4 Y =XBOOLE-0R4 X"
    proof-
      have " not (X missesXBOOLE-0R1 Y &  not X \\XBOOLE-0K4 Y =XBOOLE-0R4 X)"
      proof-
        have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X \\XBOOLE-0K4 Y =XBOOLE-0R4 X"
        proof(rule impI)
          assume A1: "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
          have "( for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y implies x inHIDDENR3 X) & X c=TARSKIR1 X \\XBOOLE-0K4 Y"
          proof(rule conjMI)
            show " for x be objectHIDDENM1 holds x inHIDDENR3 X \\XBOOLE-0K4 Y implies x inHIDDENR3 X"
              using xboole_0_def_5 sorry
            have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x inHIDDENR3 X \\XBOOLE-0K4 Y)"
            proof(rule ballI)
              fix x assume [ty]: "x be objectHIDDENM1"
              have " not x inHIDDENR3 X /\\XBOOLE-0K3 Y implies  not x inHIDDENR3 X or  not x inHIDDENR3 Y"
                using xboole_0_def_4 sorry
              thus " not (x inHIDDENR3 X &  not x inHIDDENR3 X \\XBOOLE-0K4 Y)"
                using A1 xboole_0_def_5 sorry
            qed "sorry"
            thus "X c=TARSKIR1 X \\XBOOLE-0K4 Y"
              using tarski_def_3 sorry
          qed
          thus "X \\XBOOLE-0K4 Y =XBOOLE-0R4 X"
            using tarski_def_3 xboole_0_def_10 sorry
        qed
        thus " not (X missesXBOOLE-0R1 Y &  not X \\XBOOLE-0K4 Y =XBOOLE-0R4 X)"
          using xboole_0_def_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "X \\XBOOLE-0K4 Y =XBOOLE-0R4 X"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y)"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 X /\\XBOOLE-0K3 Y"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
           sorry
        have "x inHIDDENR3 X & x inHIDDENR3 Y"
          using A3 xboole_0_def_4 sorry
        thus " False "
          using A2 xboole_0_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "X missesXBOOLE-0R1 Y"
      using xboole_0_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_84:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X meetsXBOOLE-0R5 Y & X missesXBOOLE-0R1 Z implies X meetsXBOOLE-0R5 Y \\XBOOLE-0K4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X meetsXBOOLE-0R5 Y & X missesXBOOLE-0R1 Z implies  not X meetsXBOOLE-0R5 Y \\XBOOLE-0K4 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X meetsXBOOLE-0R5 Y"
      and A2: "X missesXBOOLE-0R1 Z"
    have Cut1109: "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =HIDDENR1 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X /\\XBOOLE-0K3 Z"
      using xboole_1_th_50 sorry
    also have "... = X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 {}XBOOLE-0K1"
      using A2 sorry
    finally have "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) =HIDDENR1 X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 {}XBOOLE-0K1"
       sorry
    have "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) <>HIDDENR2 {}XBOOLE-0K1"
    proof-
      show "X /\\XBOOLE-0K3 (Y \\XBOOLE-0K4 Z) <>HIDDENR2 {}XBOOLE-0K1"
        using A1 Cut1109 sorry
    qed
    thus " not X meetsXBOOLE-0R5 Y \\XBOOLE-0K4 Z"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_85:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X missesXBOOLE-0R1 Z \\XBOOLE-0K4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y implies X missesXBOOLE-0R1 Z \\XBOOLE-0K4 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have "X /\\XBOOLE-0K3 (Z \\XBOOLE-0K4 Y) =HIDDENR1 {}XBOOLE-0K1"
    proof-
      have "X /\\XBOOLE-0K3 (Z \\XBOOLE-0K4 Y) =HIDDENR1 Z /\\XBOOLE-0K3 X \\XBOOLE-0K4 Y"
        using xboole_1_th_49 sorry
      also have "... = Z /\\XBOOLE-0K3 (X \\XBOOLE-0K4 Y)"
        using xboole_1_th_49 sorry
      also have "... = Z /\\XBOOLE-0K3 {}XBOOLE-0K1"
        using A1 xboole_1_lm_1 sorry
      also have "... = {}XBOOLE-0K1"
         sorry
      finally show "X /\\XBOOLE-0K3 (Z \\XBOOLE-0K4 Y) =HIDDENR1 {}XBOOLE-0K1"
         sorry
    qed
    thus "X missesXBOOLE-0R1 Z \\XBOOLE-0K4 Y"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_86:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X c=TARSKIR1 Y & X missesXBOOLE-0R1 Z implies X c=TARSKIR1 Y \\XBOOLE-0K4 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  not ((X c=TARSKIR1 Y & X missesXBOOLE-0R1 Z) &  not X c=TARSKIR1 Y \\XBOOLE-0K4 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X c=TARSKIR1 Y & X /\\XBOOLE-0K3 Z =XBOOLE-0R4 {}XBOOLE-0K1 implies X c=TARSKIR1 Y \\XBOOLE-0K4 Z"
    proof(rule impI)
      assume A1: "X c=TARSKIR1 Y & X /\\XBOOLE-0K3 Z =XBOOLE-0R4 {}XBOOLE-0K1"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y \\XBOOLE-0K4 Z"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then have "x inHIDDENR3 Y &  not x inHIDDENR3 Z"
          using A1 xboole_0_def_4 sorry
        thus "x inHIDDENR3 Y \\XBOOLE-0K4 Z"
          using xboole_0_def_5 sorry
      qed "sorry"
      thus "X c=TARSKIR1 Y \\XBOOLE-0K4 Z"
        using tarski_def_3 sorry
    qed
    thus " not ((X c=TARSKIR1 Y & X missesXBOOLE-0R1 Z) &  not X c=TARSKIR1 Y \\XBOOLE-0K4 Z)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_87:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y missesXBOOLE-0R1 Z implies (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 Z =XBOOLE-0R4 (X \\/XBOOLE-0K2 Z)\\XBOOLE-0K4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y missesXBOOLE-0R1 Z implies (X \\/XBOOLE-0K2 Z)\\XBOOLE-0K4 Y =HIDDENR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "Y missesXBOOLE-0R1 Z"
    have "(X \\/XBOOLE-0K2 Z)\\XBOOLE-0K4 Y =HIDDENR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 Y)"
      using xboole_1_th_42 sorry
    also have "... = (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 Z"
      using A1 xboole_1_th_83 sorry
    finally show "(X \\/XBOOLE-0K2 Z)\\XBOOLE-0K4 Y =HIDDENR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_88:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X missesXBOOLE-0R1 Y implies (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y =HIDDENR1 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X missesXBOOLE-0R1 Y"
    have "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y =HIDDENR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 Y)"
      using xboole_1_th_42 sorry
    also have "... = (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 {}XBOOLE-0K1"
      using xboole_1_lm_1 sorry
    also have "... = X"
      using A1 xboole_1_th_83 sorry
    finally show "(X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 Y =HIDDENR1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_89:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\XBOOLE-0K4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\XBOOLE-0K4 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X /\\XBOOLE-0K3 Y & x inHIDDENR3 X \\XBOOLE-0K4 Y)"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have " not ((x inHIDDENR3 X & x inHIDDENR3 Y) &  not x inHIDDENR3 Y)"
         sorry
      thus " not (x inHIDDENR3 X /\\XBOOLE-0K3 Y & x inHIDDENR3 X \\XBOOLE-0K4 Y)"
        using xboole_0_def_4 xboole_0_def_5 sorry
    qed "sorry"
    thus "X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\XBOOLE-0K4 Y"
      using xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_90:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X \\XBOOLE-0K4 Y"
      using xboole_1_th_47 sorry
    thus "X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 Y"
      using xboole_1_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_91:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 Z =XBOOLE-0R4 X \\+\\XBOOLE-0K5 (Y \\+\\XBOOLE-0K5 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 Z =HIDDENR1 X \\+\\XBOOLE-0K5 (Y \\+\\XBOOLE-0K5 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    let ?S1 = "X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z)"
    let ?S2 = "Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z)"
    let ?S3 = "Z \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y)"
    let ?S4 = "(X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
    have "(X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 Z =HIDDENR1 (((X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z)\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 X)\\XBOOLE-0K4 Z))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 ((X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)))"
      using xboole_1_th_42 sorry
    also have "... = ((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 X)\\XBOOLE-0K4 Z))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 ((X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)))"
      using xboole_1_th_41 sorry
    also have "... = ((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z)))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 ((X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)))"
      using xboole_1_th_41 sorry
    also have "... = ((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z)))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 ((X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y))"
      using xboole_1_th_55 sorry
    also have "... = ((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z)))\\/XBOOLE-0K2 ((X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z \\/XBOOLE-0K2 (Z \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y)))"
      using xboole_1_th_52 sorry
    also have "... = (((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z)))\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y))"
      using xboole_1_th_4 sorry
    also have "... = (((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z)))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y))"
      using xboole_1_th_4 sorry
    also have "... = ((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z)\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y)))"
      using xboole_1_th_4 sorry
    also have "... = ((X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z))\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y)))"
      using xboole_1_th_16 sorry
    also have "... = (X \\XBOOLE-0K4 ((Y \\/XBOOLE-0K2 Z)\\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z))\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y)))"
      using xboole_1_th_52 sorry
    also have "... = (X \\XBOOLE-0K4 ((Y \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 Y)))\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 X)))"
      using xboole_1_th_55 sorry
    also have "... = (X \\XBOOLE-0K4 ((Y \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 Y)))\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 (Z \\/XBOOLE-0K2 X))\\/XBOOLE-0K2 ((Z \\XBOOLE-0K4 Y)\\XBOOLE-0K4 X))"
      using xboole_1_th_41 sorry
    also have "... = (X \\XBOOLE-0K4 ((Y \\XBOOLE-0K4 Z)\\/XBOOLE-0K2 (Z \\XBOOLE-0K4 Y)))\\/XBOOLE-0K2 (((Y \\XBOOLE-0K4 Z)\\XBOOLE-0K4 X)\\/XBOOLE-0K2 ((Z \\XBOOLE-0K4 Y)\\XBOOLE-0K4 X))"
      using xboole_1_th_41 sorry
    also have "... = X \\+\\XBOOLE-0K5 (Y \\+\\XBOOLE-0K5 Z)"
      using xboole_1_th_42 sorry
    finally show "(X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 Z =HIDDENR1 X \\+\\XBOOLE-0K5 (Y \\+\\XBOOLE-0K5 Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_92:
" for X be setHIDDENM2 holds X \\+\\XBOOLE-0K5 X =XBOOLE-0R4 {}XBOOLE-0K1"
  using xboole_1_lm_1 sorry

mtheorem xboole_1_th_93:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =HIDDENR1 (X \\+\\XBOOLE-0K5 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\/XBOOLE-0K2 Y =HIDDENR1 ((X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y)\\/XBOOLE-0K2 Y"
      using xboole_1_th_51 sorry
    also have "... = (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y \\/XBOOLE-0K2 Y)"
      using xboole_1_th_4 sorry
    also have "... = (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 Y"
      using xboole_1_th_22 sorry
    also have "... = (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 X)\\/XBOOLE-0K2 Y /\\XBOOLE-0K3 X)"
      using xboole_1_th_51 sorry
    also have "... = (X \\+\\XBOOLE-0K5 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
      using xboole_1_th_4 sorry
    finally show "X \\/XBOOLE-0K2 Y =HIDDENR1 (X \\+\\XBOOLE-0K5 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xboole_1_lm_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\+\\XBOOLE-0K5 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\+\\XBOOLE-0K5 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\XBOOLE-0K4 Y & X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 Y \\XBOOLE-0K4 X"
      using xboole_1_th_89 sorry
    thus "X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\+\\XBOOLE-0K5 Y"
      using xboole_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xboole_1_lm_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\+\\XBOOLE-0K5 Y =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\+\\XBOOLE-0K5 Y =HIDDENR1 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\+\\XBOOLE-0K5 Y =HIDDENR1 (X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)"
      using xboole_1_th_47 sorry
    also have "... = (X \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y)\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X /\\XBOOLE-0K3 Y)"
      using xboole_1_th_47 sorry
    also have "... = (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
      using xboole_1_th_42 sorry
    finally show "X \\+\\XBOOLE-0K5 Y =HIDDENR1 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_94:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\+\\XBOOLE-0K5 Y"
      using xboole_1_lm_4 sorry
    then have "(X \\+\\XBOOLE-0K5 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 Y & X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 (X \\+\\XBOOLE-0K5 Y) =XBOOLE-0R4 X /\\XBOOLE-0K3 Y"
      using xboole_1_th_83 sorry
    thus "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 X /\\XBOOLE-0K3 Y"
      using xboole_1_th_93 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_95:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 X \\/XBOOLE-0K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 X \\/XBOOLE-0K2 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\+\\XBOOLE-0K5 Y =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
      using xboole_1_lm_5 sorry
    then have "X \\+\\XBOOLE-0K5 Y c=TARSKIR1 X \\/XBOOLE-0K2 Y"
      using xboole_1_th_36 sorry
    then have A1: "(X \\+\\XBOOLE-0K5 Y)\\XBOOLE-0K4 (X \\/XBOOLE-0K2 Y) =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_1_lm_1 sorry
    have "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 Y"
      using xboole_1_th_93 sorry
    thus "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)\\+\\XBOOLE-0K5 X \\/XBOOLE-0K2 Y"
      using A1 xboole_1_lm_4 xboole_1_th_88 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_96:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y c=TARSKIR1 X \\+\\XBOOLE-0K5 Y"
  using xboole_1_th_7 sorry

mtheorem xboole_1_th_97:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 Y c=TARSKIR1 Z & Y \\XBOOLE-0K4 X c=TARSKIR1 Z implies X \\+\\XBOOLE-0K5 Y c=TARSKIR1 Z"
  using xboole_1_th_8 sorry

mtheorem xboole_1_th_98:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 Y \\XBOOLE-0K4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\/XBOOLE-0K2 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 Y \\XBOOLE-0K4 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "(Y \\XBOOLE-0K4 X)\\XBOOLE-0K4 X =HIDDENR1 Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 X)"
      using xboole_1_th_41 sorry
    also have "... = Y \\XBOOLE-0K4 X"
       sorry
    finally have "(Y \\XBOOLE-0K4 X)\\XBOOLE-0K4 X =HIDDENR1 Y \\XBOOLE-0K4 X"
       sorry
    have "X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 X) =HIDDENR1 (X \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 X"
      using xboole_1_th_52 sorry
    also have "... = X"
      using xboole_1_th_12 xboole_1_th_36 sorry
    finally have "X \\XBOOLE-0K4 (Y \\XBOOLE-0K4 X) =HIDDENR1 X"
       sorry
    thus "X \\/XBOOLE-0K2 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 Y \\XBOOLE-0K4 X"
      using A1 xboole_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_99:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\+\\XBOOLE-0K5 Y)\\XBOOLE-0K4 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X \\+\\XBOOLE-0K5 Y)\\XBOOLE-0K4 Z =HIDDENR1 (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "(X \\+\\XBOOLE-0K5 Y)\\XBOOLE-0K4 Z =HIDDENR1 ((X \\XBOOLE-0K4 Y)\\XBOOLE-0K4 Z)\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 X)\\XBOOLE-0K4 Z)"
      using xboole_1_th_42 sorry
    also have "... = (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 ((Y \\XBOOLE-0K4 X)\\XBOOLE-0K4 Z)"
      using xboole_1_th_41 sorry
    also have "... = (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))"
      using xboole_1_th_41 sorry
    finally show "(X \\+\\XBOOLE-0K5 Y)\\XBOOLE-0K4 Z =HIDDENR1 (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (Y \\XBOOLE-0K4 (X \\/XBOOLE-0K2 Z))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_100:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\XBOOLE-0K4 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Y c=TARSKIR1 X"
      using xboole_1_th_17 sorry
    then have "X /\\XBOOLE-0K3 Y \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_1_lm_1 sorry
    thus "X \\XBOOLE-0K4 Y =XBOOLE-0R4 X \\+\\XBOOLE-0K5 X /\\XBOOLE-0K3 Y"
      using xboole_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_101:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X \\+\\XBOOLE-0K5 Y =XBOOLE-0R4 (X \\/XBOOLE-0K2 Y)\\XBOOLE-0K4 X /\\XBOOLE-0K3 Y"
  using xboole_1_lm_5 sorry

mtheorem xboole_1_th_102:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 (Y \\+\\XBOOLE-0K5 Z) =XBOOLE-0R4 (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X \\XBOOLE-0K4 (Y \\+\\XBOOLE-0K5 Z) =HIDDENR1 (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X \\XBOOLE-0K4 (Y \\+\\XBOOLE-0K5 Z) =HIDDENR1 X \\XBOOLE-0K4 ((Y \\/XBOOLE-0K2 Z)\\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z)"
      using xboole_1_lm_5 sorry
    also have "... = (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z)"
      using xboole_1_th_52 sorry
    also have "... = (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
      using xboole_1_th_16 sorry
    finally show "X \\XBOOLE-0K4 (Y \\+\\XBOOLE-0K5 Z) =HIDDENR1 (X \\XBOOLE-0K4 (Y \\/XBOOLE-0K2 Z))\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_103:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X /\\XBOOLE-0K3 Y missesXBOOLE-0R1 X \\+\\XBOOLE-0K5 Y"
  using xboole_1_lm_4 sorry

mtheorem xboole_1_th_104:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X c<XBOOLE-0R2 Y or X =XBOOLE-0R4 Y) or Y c<XBOOLE-0R2 X iff (X,Y)are-c=-comparableXBOOLE-0R3"
   sorry

(*begin*)
mtheorem xboole_1_th_105:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c<XBOOLE-0R2 Y implies Y \\XBOOLE-0K4 X <>HIDDENR2 {}XBOOLE-0K1"
  using xboole_1_th_60 xboole_1_lm_1 sorry

mtheorem xboole_1_th_106:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A \\XBOOLE-0K4 B implies X c=TARSKIR1 A & X missesXBOOLE-0R1 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A \\XBOOLE-0K4 B implies X c=TARSKIR1 A & X missesXBOOLE-0R1 B"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X c=TARSKIR1 A \\XBOOLE-0K4 B"
    have "A \\XBOOLE-0K4 B c=TARSKIR1 A"
      using xboole_1_th_36 sorry
    thus "X c=TARSKIR1 A"
      using A1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies  not x inHIDDENR3 B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      then have "x inHIDDENR3 A \\XBOOLE-0K4 B"
        using A1 sorry
      thus " not x inHIDDENR3 B"
        using xboole_0_def_5 sorry
    qed "sorry"
    thus "X missesXBOOLE-0R1 B"
      using xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_107:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A \\+\\XBOOLE-0K5 B iff X c=TARSKIR1 A \\/XBOOLE-0K2 B & X missesXBOOLE-0R1 A /\\XBOOLE-0K3 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be setHIDDENM2 holds  not (X c=TARSKIR1 A \\+\\XBOOLE-0K5 B &  not (X c=TARSKIR1 A \\/XBOOLE-0K2 B & X missesXBOOLE-0R1 A /\\XBOOLE-0K3 B)) &  not ((X c=TARSKIR1 A \\/XBOOLE-0K2 B & X missesXBOOLE-0R1 A /\\XBOOLE-0K3 B) &  not X c=TARSKIR1 A \\+\\XBOOLE-0K5 B)"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    have "A \\+\\XBOOLE-0K5 B =XBOOLE-0R4 (A \\/XBOOLE-0K2 B)\\XBOOLE-0K4 A /\\XBOOLE-0K3 B"
      using xboole_1_lm_5 sorry
    thus " not (X c=TARSKIR1 A \\+\\XBOOLE-0K5 B &  not (X c=TARSKIR1 A \\/XBOOLE-0K2 B & X missesXBOOLE-0R1 A /\\XBOOLE-0K3 B)) &  not ((X c=TARSKIR1 A \\/XBOOLE-0K2 B & X missesXBOOLE-0R1 A /\\XBOOLE-0K3 B) &  not X c=TARSKIR1 A \\+\\XBOOLE-0K5 B)"
      using xboole_1_th_86 xboole_1_th_106 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_108:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 A implies X /\\XBOOLE-0K3 Y c=TARSKIR1 A"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (X c=TARSKIR1 A &  not X /\\XBOOLE-0K3 Y c=TARSKIR1 A)"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Y c=TARSKIR1 X"
      using xboole_1_th_17 sorry
    thus " not (X c=TARSKIR1 A &  not X /\\XBOOLE-0K3 Y c=TARSKIR1 A)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_109:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 A implies X \\XBOOLE-0K4 Y c=TARSKIR1 A"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (X c=TARSKIR1 A &  not X \\XBOOLE-0K4 Y c=TARSKIR1 A)"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "X \\XBOOLE-0K4 Y c=TARSKIR1 X"
      using xboole_1_th_36 sorry
    thus " not (X c=TARSKIR1 A &  not X \\XBOOLE-0K4 Y c=TARSKIR1 A)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_110:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 A & Y c=TARSKIR1 A implies X \\+\\XBOOLE-0K5 Y c=TARSKIR1 A"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 A & Y c=TARSKIR1 A implies X \\+\\XBOOLE-0K5 Y c=TARSKIR1 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X c=TARSKIR1 A & Y c=TARSKIR1 A"
    then have "X \\XBOOLE-0K4 Y c=TARSKIR1 A & Y \\XBOOLE-0K4 X c=TARSKIR1 A"
      using xboole_1_th_109 sorry
    thus "X \\+\\XBOOLE-0K5 Y c=TARSKIR1 A"
      using xboole_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_111:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =HIDDENR1 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =HIDDENR1 (X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 (X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Z)"
      using xboole_1_lm_2 sorry
    also have "... = (X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 (Z \\XBOOLE-0K4 Z)"
      using xboole_1_th_49 sorry
    also have "... = (X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 {}XBOOLE-0K1"
      using xboole_1_lm_1 sorry
    also have "... = (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Z"
      using xboole_1_th_49 sorry
    finally show "X /\\XBOOLE-0K3 Z \\XBOOLE-0K4 Y /\\XBOOLE-0K3 Z =HIDDENR1 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_112:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Z \\+\\XBOOLE-0K5 Y /\\XBOOLE-0K3 Z =XBOOLE-0R4 (X \\+\\XBOOLE-0K5 Y)/\\XBOOLE-0K3 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 Z \\+\\XBOOLE-0K5 Y /\\XBOOLE-0K3 Z =HIDDENR1 (X \\+\\XBOOLE-0K5 Y)/\\XBOOLE-0K3 Z"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X /\\XBOOLE-0K3 Z \\+\\XBOOLE-0K5 Y /\\XBOOLE-0K3 Z =HIDDENR1 (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Z \\/XBOOLE-0K2 (Y /\\XBOOLE-0K3 Z \\XBOOLE-0K4 X /\\XBOOLE-0K3 Z)"
      using xboole_1_th_111 sorry
    also have "... = (X \\XBOOLE-0K4 Y)/\\XBOOLE-0K3 Z \\/XBOOLE-0K2 (Y \\XBOOLE-0K4 X)/\\XBOOLE-0K3 Z"
      using xboole_1_th_111 sorry
    also have "... = (X \\+\\XBOOLE-0K5 Y)/\\XBOOLE-0K3 Z"
      using xboole_1_th_23 sorry
    finally show "X /\\XBOOLE-0K3 Z \\+\\XBOOLE-0K5 Y /\\XBOOLE-0K3 Z =HIDDENR1 (X \\+\\XBOOLE-0K5 Y)/\\XBOOLE-0K3 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_113:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds ((X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V =XBOOLE-0R4 X \\/XBOOLE-0K2 ((Y \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for V be setHIDDENM2 holds ((X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V =XBOOLE-0R4 X \\/XBOOLE-0K2 ((Y \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix V assume [ty]: "V be setHIDDENM2"
    have "((X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V =HIDDENR1 (X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 (Z \\/XBOOLE-0K2 V)"
      using xboole_1_th_4 sorry
    also have "... = X \\/XBOOLE-0K2 (Y \\/XBOOLE-0K2 (Z \\/XBOOLE-0K2 V))"
      using xboole_1_th_4 sorry
    also have "... = X \\/XBOOLE-0K2 ((Y \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V)"
      using xboole_1_th_4 sorry
    finally have "((X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V =HIDDENR1 X \\/XBOOLE-0K2 ((Y \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V)"
       sorry
    thus "((X \\/XBOOLE-0K2 Y)\\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V =XBOOLE-0R4 X \\/XBOOLE-0K2 ((Y \\/XBOOLE-0K2 Z)\\/XBOOLE-0K2 V)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_114:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds (A missesXBOOLE-0R1 D & B missesXBOOLE-0R1 D) & C missesXBOOLE-0R1 D implies (A \\/XBOOLE-0K2 B)\\/XBOOLE-0K2 C missesXBOOLE-0R1 D"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds A missesXBOOLE-0R1 D & B missesXBOOLE-0R1 D implies (C missesXBOOLE-0R1 D implies (A \\/XBOOLE-0K2 B)\\/XBOOLE-0K2 C missesXBOOLE-0R1 D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    fix D assume [ty]: "D be setHIDDENM2"
    assume "A missesXBOOLE-0R1 D & B missesXBOOLE-0R1 D"
    then have A1: "A \\/XBOOLE-0K2 B missesXBOOLE-0R1 D"
      using xboole_1_th_70 sorry
    assume "C missesXBOOLE-0R1 D"
    thus "(A \\/XBOOLE-0K2 B)\\/XBOOLE-0K2 C missesXBOOLE-0R1 D"
      using A1 xboole_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem xboole_1_th_116:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) =XBOOLE-0R4 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) =HIDDENR1 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 Z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    have "X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) =HIDDENR1 ((X /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 Z"
      using xboole_1_th_16 sorry
    also have "... = (X /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 Y))/\\XBOOLE-0K3 Z"
      using xboole_1_th_16 sorry
    also have "... = (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 Z)"
      using xboole_1_th_16 sorry
    finally show "X /\\XBOOLE-0K3 (Y /\\XBOOLE-0K3 Z) =HIDDENR1 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xboole_1_th_117:
" for P be setHIDDENM2 holds  for G be setHIDDENM2 holds  for C be setHIDDENM2 holds C c=TARSKIR1 G implies P \\XBOOLE-0K4 C =XBOOLE-0R4 (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix P assume [ty]: "P be setHIDDENM2"
  fix G assume [ty]: "G be setHIDDENM2"
  fix C assume [ty]: "C be setHIDDENM2"
  assume "C c=TARSKIR1 G"
  then have A1: "P \\XBOOLE-0K4 G c=TARSKIR1 P \\XBOOLE-0K4 C"
    using xboole_1_th_34 sorry
  have "P \\XBOOLE-0K4 C c=TARSKIR1 (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C) & (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C) c=TARSKIR1 P \\XBOOLE-0K4 C"
  proof(rule conjMI)
    show "P \\XBOOLE-0K4 C c=TARSKIR1 (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 P \\XBOOLE-0K4 C implies x inHIDDENR3 (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 P \\XBOOLE-0K4 C"
        then have "x inHIDDENR3 P &  not x inHIDDENR3 G or (x inHIDDENR3 P & x inHIDDENR3 G) &  not x inHIDDENR3 C"
          using xboole_0_def_5 sorry
        then have "x inHIDDENR3 P \\XBOOLE-0K4 G or x inHIDDENR3 P & x inHIDDENR3 G \\XBOOLE-0K4 C"
          using xboole_0_def_5 sorry
        then have "x inHIDDENR3 P \\XBOOLE-0K4 G or x inHIDDENR3 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C)"
          using xboole_0_def_4 sorry
        thus "x inHIDDENR3 (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C)"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "P \\XBOOLE-0K4 C c=TARSKIR1 (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C)"
        using tarski_def_3 sorry
    qed
    have "P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C) =XBOOLE-0R4 P /\\XBOOLE-0K3 G \\XBOOLE-0K4 C & P /\\XBOOLE-0K3 G \\XBOOLE-0K4 C c=TARSKIR1 P \\XBOOLE-0K4 C"
      using xboole_1_th_17 xboole_1_th_33 xboole_1_th_49 sorry
    thus "(P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C) c=TARSKIR1 P \\XBOOLE-0K4 C"
      using A1 xboole_1_th_8 sorry
  qed
  thus "P \\XBOOLE-0K4 C =XBOOLE-0R4 (P \\XBOOLE-0K4 G)\\/XBOOLE-0K2 P /\\XBOOLE-0K3 (G \\XBOOLE-0K4 C)"
    using xboole_0_def_10 sorry
qed "sorry"

end
