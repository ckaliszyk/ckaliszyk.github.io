theory arytm_2
  imports arytm_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve r, s, t, x9, y9, z9, p, q for "ElementSUBSET-1M1-of RAT+ARYTM-3K5"
mdef arytm_2_def_1 ("DEDEKIND-CUTSARYTM-2K1" 164 ) where
"func DEDEKIND-CUTSARYTM-2K1 \<rightarrow> Subset-FamilySETFAM-1M1-of RAT+ARYTM-3K5 equals
  ({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })\\SUBSET-1K6 {TARSKIK1 RAT+ARYTM-3K5 }"
proof-
  (*coherence*)
    show "({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })\\SUBSET-1K6 {TARSKIK1 RAT+ARYTM-3K5 } be Subset-FamilySETFAM-1M1-of RAT+ARYTM-3K5"
    proof-
      have "({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) })\\SUBSET-1K6 {TARSKIK1 RAT+ARYTM-3K5 } be Subset-FamilySETFAM-1M1-of RAT+ARYTM-3K5"
      proof-
        let ?C = "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
        have "?C c=TARSKIR1 boolZFMISC-1K1 (RAT+ARYTM-3K5)"
        proof-
          have "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) } c=TARSKIR1 boolZFMISC-1K1 (RAT+ARYTM-3K5)"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } implies e inHIDDENR3 boolZFMISC-1K1 (RAT+ARYTM-3K5)"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ?C"
              then have " ex A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st e =HIDDENR1 A & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s))"
                 sorry
              thus "e inHIDDENR3 boolZFMISC-1K1 (RAT+ARYTM-3K5)"
                 sorry
            qed "sorry"
            thus "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) } c=TARSKIR1 boolZFMISC-1K1 (RAT+ARYTM-3K5)"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) })\\SUBSET-1K6 {TARSKIK1 RAT+ARYTM-3K5 } be Subset-FamilySETFAM-1M1-of RAT+ARYTM-3K5"
          using xboole_1_th_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem arytm_2_cl_1:
"cluster DEDEKIND-CUTSARYTM-2K1 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "DEDEKIND-CUTSARYTM-2K1 be  non emptyXBOOLE-0V1"
  proof-
    have " not DEDEKIND-CUTSARYTM-2K1 be emptyXBOOLE-0V1"
    proof-
      let ?X = "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 oneARYTM-3K13 }"
      have A1: "?X c=TARSKIR1 RAT+ARYTM-3K5"
      proof-
        have "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 oneARYTM-3K13 } c=TARSKIR1 RAT+ARYTM-3K5"
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 oneARYTM-3K13 } implies e inHIDDENR3 RAT+ARYTM-3K5"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 ?X"
            then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =HIDDENR1 e & s <ARYTM-3R4 oneARYTM-3K13"
               sorry
            thus "e inHIDDENR3 RAT+ARYTM-3K5"
               sorry
          qed "sorry"
          thus "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 oneARYTM-3K13 } c=TARSKIR1 RAT+ARYTM-3K5"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "oneARYTM-3K13 inTARSKIR2 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 oneARYTM-3K13 } implies  False "
      proof(rule impI)
        assume "oneARYTM-3K13 inTARSKIR2 ?X"
        then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 oneARYTM-3K13 & s <ARYTM-3R4 oneARYTM-3K13"
           sorry
        thus " False "
           sorry
      qed
      then have A2: "?X <>HIDDENR2 RAT+ARYTM-3K5"
         sorry
      have "{}ARYTM-3K12 <='ARYTM-3R3 oneARYTM-3K13"
        using arytm_3_th_64 sorry
      then have "{}ARYTM-3K12 <ARYTM-3R4 oneARYTM-3K13"
        using arytm_3_th_68 sorry
      then have "{}ARYTM-3K12 inTARSKIR2 ?X"
         sorry
      then obtain X where 
        [ty]:"X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and XDef:"X = ?X"
        using A1 sorry
      have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 X implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 X) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 X & r <ARYTM-3R4 s)"
      proof-
        have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 X implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 X) & ( ex tVar1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar1 inTARSKIR2 X &  not r <ARYTM-3R4 tVar1)"
        proof(rule ballI,rule impI,rule conjMI)
          fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
          assume "r inTARSKIR2 X"
          then have A3: " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r & s <ARYTM-3R4 oneARYTM-3K13"
             sorry
          show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 X"
          proof(rule ballI,rule impI)
            fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
            assume "s <='ARYTM-3R3 r"
            then have "s <ARYTM-3R4 oneARYTM-3K13"
              using A3 arytm_3_th_67 sorry
            thus "s inTARSKIR2 X"
               sorry
          qed "sorry"
          obtain s where
            [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A4: "r <ARYTM-3R4 s"and A5: "s <ARYTM-3R4 oneARYTM-3K13"
            using A3 arytm_3_th_93 sorry
          show " ex tVar1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar1 inTARSKIR2 X &  not r <ARYTM-3R4 tVar1"
          proof(rule bexI[of _ "s"],rule conjMI)
            show "s inTARSKIR2 X"
              using A5 sorry
            show " not r <ARYTM-3R4 s"
              using A4 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "X inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
         sorry
      thus " not DEDEKIND-CUTSARYTM-2K1 be emptyXBOOLE-0V1"
        using A2 zfmisc_1_th_56 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef arytm_2_def_2 ("REAL+ARYTM-2K2" 164 ) where
"func REAL+ARYTM-2K2 \<rightarrow> setHIDDENM2 equals
  (RAT+ARYTM-3K5 \\/XBOOLE-0K2 DEDEKIND-CUTSARYTM-2K1)\\SUBSET-1K6 ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 })"
proof-
  (*coherence*)
    show "(RAT+ARYTM-3K5 \\/XBOOLE-0K2 DEDEKIND-CUTSARYTM-2K1)\\SUBSET-1K6 ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }) be setHIDDENM2"
       sorry
qed "sorry"

reserve x, y, z for "ElementSUBSET-1M1-of REAL+ARYTM-2K2"
mlemma arytm_2_lm_1:
" not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })"
proof-
  have "( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }) implies  False "
  proof(rule impI)
    assume Given: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A1: "[TARSKIK4 x,y ] inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
       sorry
    obtain A where
      [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
      A2: "[TARSKIK4 x,y ] =HIDDENR1 A"and A3: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
      using A1 sorry
    have "{TARSKIK1 x} inTARSKIR2 A & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A)"
      using A2 A3 tarski_def_2 sorry
    then obtain r1 r2 r3 where
      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A4: "r1 inTARSKIR2 A"and A5: "r2 inTARSKIR2 A"and A6: "((r3 inTARSKIR2 A & r1 <>HIDDENR2 r2) & r2 <>HIDDENR2 r3) & r3 <>HIDDENR2 r1"
      using arytm_3_th_75 sorry
    have A7: "r2 =XBOOLE-0R4 {TARSKIK2 x,y } or r2 =XBOOLE-0R4 {TARSKIK1 x}"
      using A2 A5 tarski_def_2 sorry
    have "r1 =XBOOLE-0R4 {TARSKIK2 x,y } or r1 =XBOOLE-0R4 {TARSKIK1 x}"
      using A2 A4 tarski_def_2 sorry
    thus " False "
      using A2 A6 A7 tarski_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_2:
"RAT+ARYTM-3K5 missesXBOOLE-0R1 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
proof-
  have "RAT+ARYTM-3K5 meetsXBOOLE-0R5 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } implies  False "
  proof(rule impI)
    assume "RAT+ARYTM-3K5 meetsXBOOLE-0R5 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
    then obtain e where
      [ty]:"e be objectHIDDENM1" and 
      A1: "e inHIDDENR3 RAT+ARYTM-3K5"and A2: "e inHIDDENR3 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
      using xboole_0_th_3 sorry
    have 
      [ty]:"e be setHIDDENM2"
      using tarski_th_1 sorry
    obtain t where
      [ty]:"t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A3: "e =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t }"and A4: "t <>HIDDENR2 {}ARYTM-3K12"
      using A2 sorry
    have "{}ARYTM-3K12 <='ARYTM-3R3 t"
      using arytm_3_th_64 sorry
    then have "{}ARYTM-3K12 <ARYTM-3R4 t"
      using A4 arytm_3_th_68 sorry
    then have A5: "{}ARYTM-3K12 inTARSKIR2 e"
      using A3 sorry
    have "e c=TARSKIR1 RAT+ARYTM-3K5"
    proof-
      have " for u be objectHIDDENM1 holds u inHIDDENR3 e implies u inHIDDENR3 RAT+ARYTM-3K5"
      proof(rule ballI,rule impI)
        fix u assume [ty]: "u be objectHIDDENM1"
        assume "u inHIDDENR3 e"
        then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =HIDDENR1 u & s <ARYTM-3R4 t"
          using A3 sorry
        thus "u inHIDDENR3 RAT+ARYTM-3K5"
           sorry
      qed "sorry"
      thus "e c=TARSKIR1 RAT+ARYTM-3K5"
        using tarski_def_3 sorry
    qed
    then have 
      [ty]:"e be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5"
      using A5 sorry
    obtain s where
      [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A6: "s inTARSKIR2 e"and A7: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 e implies r <='ARYTM-3R3 s"
      using A1 arytm_3_th_91 sorry
    have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st r =XBOOLE-0R4 s & r <ARYTM-3R4 t"
      using A3 A6 sorry
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A8: "s <ARYTM-3R4 r"and A9: "r <ARYTM-3R4 t"
      using arytm_3_th_93 sorry
    have "r inTARSKIR2 e"
      using A3 A9 sorry
    thus " False "
      using A7 A8 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_1:
"RAT+ARYTM-3K5 c=TARSKIR1 REAL+ARYTM-2K2"
  using arytm_2_lm_2 xboole_1_th_7 xboole_1_th_86 sorry

mlemma
"RAT+ARYTM-3K5 \\/XBOOLE-0K2 DEDEKIND-CUTSARYTM-2K1 c=TARSKIR1 RAT+ARYTM-3K5 \\/XBOOLE-0K2 ({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })"
  using xboole_1_th_9 sorry

mlemma arytm_2_lm_3:
"REAL+ARYTM-2K2 c=TARSKIR1 RAT+ARYTM-3K5 \\/XBOOLE-0K2 ({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })"
   sorry

mlemma
"REAL+ARYTM-2K2 =XBOOLE-0R4 RAT+ARYTM-3K5 \\/XBOOLE-0K2 ((({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })\\SUBSET-1K6 {TARSKIK1 RAT+ARYTM-3K5 })\\SUBSET-1K7\<^bsub>({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) })\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }))"
  using arytm_2_lm_2 xboole_1_th_87 sorry

mlemma arytm_2_lm_4:
"DEDEKIND-CUTSARYTM-2K1 \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }) c=TARSKIR1 REAL+ARYTM-2K2"
  using xboole_1_th_7 sorry

mlemma arytm_2_lm_5:
"omegaORDINAL1K4 c=TARSKIR1 (({[TARSKIK4 c,d ] where c be ElementSUBSET-1M1-of omegaORDINAL1K4, d be ElementSUBSET-1M1-of omegaORDINAL1K4 : (c,d)are-coprimeARYTM-3R1 & d <>HIDDENR2 {}ARYTM-3K12 })\\SUBSET-1K6 ({[TARSKIK4 k,\<one>\<^sub>M ] where k be ElementSUBSET-1M1-of omegaORDINAL1K4 :  True  }))\\/XBOOLE-0K2 omegaORDINAL1K4"
  using xboole_1_th_7 sorry

mtheorem arytm_2_th_2:
"omegaORDINAL1K4 c=TARSKIR1 REAL+ARYTM-2K2"
  using arytm_2_lm_5 arytm_2_th_1 sorry

mtheorem arytm_2_cl_2:
"cluster REAL+ARYTM-2K2 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "REAL+ARYTM-2K2 be  non emptyXBOOLE-0V1"
    using arytm_2_th_1 sorry
qed "sorry"

mdef arytm_2_def_3 ("DEDEKIND-CUTARYTM-2K3  _ " [230]230 ) where
  mlet "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
"func DEDEKIND-CUTARYTM-2K3 x \<rightarrow> ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 means
  \<lambda>it.  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 r & it =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r } if x inTARSKIR2 RAT+ARYTM-3K5 otherwise \<lambda>it. it =XBOOLE-0R4 x"
proof-
  (*existence*)
    show "(x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex it be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 r & it =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r })) & ( not x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex it be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st it =XBOOLE-0R4 x))"
    proof-
      have "(x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex IT be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 r & IT =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r })) & ( not x inTARSKIR2 RAT+ARYTM-3K5 implies  not ( for VarFor1 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  not VarFor1 =XBOOLE-0R4 x))"
      proof(rule conjMI,rule impI)
        show "x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex IT be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 r & IT =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r })"
        proof-
          have "x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex tVar3 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st  ex tVar4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar4 & tVar3 =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 tVar4 })"
          proof(rule impI)
            assume "x inTARSKIR2 RAT+ARYTM-3K5"
            then obtain r where 
              [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and rDef:"r = x"
               sorry
            let ?IT = "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }"
            have A1: "?IT c=TARSKIR1 RAT+ARYTM-3K5"
            proof-
              have "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r } c=TARSKIR1 RAT+ARYTM-3K5"
              proof-
                have " for e be objectHIDDENM1 holds e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r } implies e inHIDDENR3 RAT+ARYTM-3K5"
                proof(rule ballI,rule impI)
                  fix e assume [ty]: "e be objectHIDDENM1"
                  assume "e inHIDDENR3 ?IT"
                  then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =HIDDENR1 e & s <ARYTM-3R4 r"
                     sorry
                  thus "e inHIDDENR3 RAT+ARYTM-3K5"
                     sorry
                qed "sorry"
                thus "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r } c=TARSKIR1 RAT+ARYTM-3K5"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have " not ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r & s <ARYTM-3R4 r)"
               sorry
            then have " not r inTARSKIR2 ?IT"
               sorry
            then have A2: "?IT <>HIDDENR2 RAT+ARYTM-3K5"
               sorry
            obtain IT where 
              [ty]:"IT be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and ITDef:"IT = ?IT"
              using A1 sorry
            have " for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 IT implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 IT) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 IT & t <ARYTM-3R4 s)"
            proof-
              have " for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 IT implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 IT) & ( ex tVar2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar2 inTARSKIR2 IT &  not t <ARYTM-3R4 tVar2)"
              proof(rule ballI,rule impI,rule conjMI)
                fix t assume [ty]: "t be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
                assume "t inTARSKIR2 IT"
                then have A3: " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t =XBOOLE-0R4 s & s <ARYTM-3R4 r"
                   sorry
                then obtain s0 where
                  [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A4: "t <ARYTM-3R4 s0"and A5: "s0 <ARYTM-3R4 r"
                  using arytm_3_th_93 sorry
                show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 IT"
                proof(rule ballI,rule impI)
                  fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
                  assume "s <='ARYTM-3R3 t"
                  then have "s <ARYTM-3R4 r"
                    using A3 arytm_3_th_69 sorry
                  thus "s inTARSKIR2 IT"
                     sorry
                qed "sorry"
                show " ex tVar2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar2 inTARSKIR2 IT &  not t <ARYTM-3R4 tVar2"
                proof(rule bexI[of _ "s0"],rule conjMI)
                  show "s0 inTARSKIR2 IT"
                    using A5 sorry
                  show " not t <ARYTM-3R4 s0"
                    using A4 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            then have "IT inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
               sorry
            then have 
              [ty]:"IT be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
              using A2 zfmisc_1_th_56 sorry
            show " ex tVar3 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st  ex tVar4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar4 & tVar3 =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 tVar4 }"
            proof(rule bexI[of _ "IT"])
              show " ex tVar4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar4 & IT =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 tVar4 }"
              proof(rule bexI[of _ "r"])
                show "x =XBOOLE-0R4 r & IT =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r }"
                   sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have A6: "x inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        assume " not x inTARSKIR2 RAT+ARYTM-3K5"
        then have "x inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
          using A6 xboole_0_def_3 sorry
        thus " not ( for VarFor1 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  not VarFor1 =XBOOLE-0R4 x)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for it2 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds (x inTARSKIR2 RAT+ARYTM-3K5 implies (( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 r & it1 =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }) & ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 r & it2 =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }) implies it1 =HIDDENR1 it2)) & ( not x inTARSKIR2 RAT+ARYTM-3K5 implies (it1 =XBOOLE-0R4 x & it2 =XBOOLE-0R4 x implies it1 =HIDDENR1 it2))"
       sorry
  (*consistency*)
    show " for it be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  True "
       sorry
qed "sorry"

mtheorem arytm_2_th_3:
" not ( ex y be objectHIDDENM1 st [TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 REAL+ARYTM-2K2)"
proof-
  have "( ex y be objectHIDDENM1 st [TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 REAL+ARYTM-2K2) implies  False "
  proof(rule impI)
    assume Given: " ex y be objectHIDDENM1 st [TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 REAL+ARYTM-2K2"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A1: "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 REAL+ARYTM-2K2"
       sorry
    show " False "
    proof-
      have cases: "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 RAT+ARYTM-3K5 or [TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
        using A1 arytm_2_lm_3 xboole_0_def_3 sorry
      have case1: "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 RAT+ARYTM-3K5 implies  False "
      proof(rule impI)
        assume "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 RAT+ARYTM-3K5"
        thus " False "
          using arytm_3_th_61 sorry
      qed
      have case2: "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } implies  False "
      proof(rule impI)
        assume "[TARSKIK4 {}ARYTM-3K12,y ] inHIDDENR3 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
        thus " False "
          using arytm_2_lm_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_6:
" for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r <ARYTM-3R4 s iff r <ARYTM-3R4 t) implies s =XBOOLE-0R4 t"
proof-
  have " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r <ARYTM-3R4 s iff r <ARYTM-3R4 t) implies s =XBOOLE-0R4 t"
  proof(rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix t assume [ty]: "t be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    assume A1: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r <ARYTM-3R4 s iff r <ARYTM-3R4 t"
    have "s <='ARYTM-3R3 s"
       sorry
    then have A2: "t <='ARYTM-3R3 s"
      using A1 sorry
    have "t <='ARYTM-3R3 t"
       sorry
    then have "s <='ARYTM-3R3 t"
      using A1 sorry
    thus "s =XBOOLE-0R4 t"
      using A2 arytm_3_th_66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef arytm_2_def_4 ("GLUEDARYTM-2K4  _ " [230]230 ) where
  mlet "x be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
"func GLUEDARYTM-2K4 x \<rightarrow> ElementSUBSET-1M1-of REAL+ARYTM-2K2 means
  \<lambda>it.  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st it =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) if  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r otherwise \<lambda>it. it =XBOOLE-0R4 x"
proof-
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for it2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies (( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st it1 =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r)) & ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st it2 =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r)) implies it1 =HIDDENR1 it2)) & ( not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies (it1 =XBOOLE-0R4 x & it2 =XBOOLE-0R4 x implies it1 =HIDDENR1 it2))"
    proof-
      have " for IT1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for IT2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies (( ex r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st IT1 =XBOOLE-0R4 r1 & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r1)) implies (( ex r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st IT2 =XBOOLE-0R4 r2 & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r2)) implies IT1 =XBOOLE-0R4 IT2))) &  not (((( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 x & s <ARYTM-3R4 r) &  not ( not s <ARYTM-3R4 r &  not s inTARSKIR2 x))) & IT1 =XBOOLE-0R4 x) & IT2 =XBOOLE-0R4 x) &  not IT1 =HIDDENR1 IT2)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix IT1 assume [ty]: "IT1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
        fix IT2 assume [ty]: "IT2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
        show "( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies (( ex r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st IT1 =XBOOLE-0R4 r1 & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r1)) implies (( ex r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st IT2 =XBOOLE-0R4 r2 & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r2)) implies IT1 =XBOOLE-0R4 IT2))"
        proof(rule impI,rule impI,rule impI)
          assume " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r"
          assume Given: " ex r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st IT1 =XBOOLE-0R4 r1 & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r1)"
          then obtain r1 where
            [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A1: "IT1 =XBOOLE-0R4 r1"and A2: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r1"
             sorry
          assume Given: " ex r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st IT2 =XBOOLE-0R4 r2 & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r2)"
          then obtain r2 where
            [ty]:"r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A3: "IT2 =XBOOLE-0R4 r2"and A4: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r2"
             sorry
          have " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <ARYTM-3R4 r1 iff s <ARYTM-3R4 r2"
            using A2 A4 sorry
          thus "IT1 =XBOOLE-0R4 IT2"
            using A1 A3 arytm_2_lm_6 sorry
        qed
        show " not (((( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 x & s <ARYTM-3R4 r) &  not ( not s <ARYTM-3R4 r &  not s inTARSKIR2 x))) & IT1 =XBOOLE-0R4 x) & IT2 =XBOOLE-0R4 x) &  not IT1 =HIDDENR1 IT2)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*existence*)
    show "(( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies ( ex it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st it =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r))) & ( not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies ( ex it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st it =XBOOLE-0R4 x))"
    proof-
      have "(( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies ( ex y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st y =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r))) & ( not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies ( ex tVar7 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar7 =XBOOLE-0R4 x))"
      proof(rule conjMI,rule impI)
        show "( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r) implies ( ex y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st y =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r))"
        proof(rule impI)
          assume Given: " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r"
          then obtain r where
            [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A5: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r"
             sorry
          obtain y where 
            [ty]:"y be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and yDef:"y = r"
            using arytm_2_th_1 sorry
          show " ex y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st y =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r)"
          proof(rule bexI[of _ "y"])
            show " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st y =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r)"
            proof(rule bexI[of _ "r"],rule conjMI)
              show "y =XBOOLE-0R4 r"
                 sorry
              show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r"
                using A5 sorry
            qed "sorry"
          qed "sorry"
        qed
        assume A6: " not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 r)"
        have "x inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } implies  False "
        proof(rule impI)
          assume "x inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
          then obtain t where
            [ty]:"t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A7: "x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t }"and "t <>HIDDENR2 {}ARYTM-3K12"
             sorry
          have " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 x iff s <ARYTM-3R4 t"
          proof-
            have " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds (s inTARSKIR2 x implies s <ARYTM-3R4 t) &  not ( not s <ARYTM-3R4 t &  not s inTARSKIR2 x)"
            proof(rule ballI,rule conjMI)
              fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
              show "s inTARSKIR2 x implies s <ARYTM-3R4 t"
              proof(rule impI)
                assume "s inTARSKIR2 x"
                then have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r & r <ARYTM-3R4 t"
                  using A7 sorry
                thus "s <ARYTM-3R4 t"
                   sorry
              qed
              show " not ( not s <ARYTM-3R4 t &  not s inTARSKIR2 x)"
                using A7 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " False "
            using A6 sorry
        qed
        then have "x inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 })"
          using xboole_0_def_5 sorry
        then obtain y where 
          [ty]:"y be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and yDef:"y = x"
          using arytm_2_lm_4 sorry
        show " ex tVar7 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar7 =XBOOLE-0R4 x"
        proof(rule bexI[of _ "y"])
          show "y =XBOOLE-0R4 x"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  True "
       sorry
qed "sorry"

mlemma arytm_2_lm_7:
" for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 & r inTARSKIR2 B implies ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
proof-
  have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 implies  not (r inTARSKIR2 B & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 B &  not r <ARYTM-3R4 s)))"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix B assume [ty]: "B be setHIDDENM2"
    assume "B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
    then have "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
       sorry
    then have " ex A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st B =XBOOLE-0R4 A & ( for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & t <ARYTM-3R4 s))"
       sorry
    thus " not (r inTARSKIR2 B & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 B &  not r <ARYTM-3R4 s)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_8:
"{}ARYTM-3K12 inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
proof-
  obtain B where 
    [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and BDef:"B = {}ARYTM-3K12"
    using xboole_1_th_2 sorry
  have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
     sorry
  then have "{}ARYTM-3K12 inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
     sorry
  thus "{}ARYTM-3K12 inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
    using zfmisc_1_th_56 sorry
qed

mlemma arytm_2_lm_9:
"(DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5) =XBOOLE-0R4 {TARSKIK1 {}ARYTM-3K12 }"
proof-
  have " for e be objectHIDDENM1 holds (e inHIDDENR3 (DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5) implies e =HIDDENR1 {}ARYTM-3K12) & (e =HIDDENR1 {}ARYTM-3K12 implies e inHIDDENR3 (DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5))"
  proof(rule ballI,rule conjMI)
    fix e assume [ty]: "e be objectHIDDENM1"
    show "e inHIDDENR3 (DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5) implies e =HIDDENR1 {}ARYTM-3K12"
    proof-
      have "e inHIDDENR3 (DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5) & e <>HIDDENR2 {}ARYTM-3K12 implies  False "
      proof(rule impMI ,rule impI)
        assume A1: "e inHIDDENR3 (DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5)"
          and A2: "e <>HIDDENR2 {}ARYTM-3K12"
        obtain A where 
          [ty]:"A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and ADef:"A = e"
          using A1 A2 sorry
        have "A inTARSKIR2 RAT+ARYTM-3K5"
          using A1 xboole_0_def_4 sorry
        then have A3: " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies r <='ARYTM-3R3 s)"
          using arytm_3_th_91 sorry
        have "e inHIDDENR3 DEDEKIND-CUTSARYTM-2K1"
          using A1 xboole_0_def_4 sorry
        thus " False "
          using A3 arytm_2_lm_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "e =HIDDENR1 {}ARYTM-3K12 implies e inHIDDENR3 (DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5)"
      using arytm_2_lm_8 xboole_0_def_4 sorry
  qed "sorry"
  thus "(DEDEKIND-CUTSARYTM-2K1)/\\SUBSET-1K8\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (RAT+ARYTM-3K5) =XBOOLE-0R4 {TARSKIK1 {}ARYTM-3K12 }"
    using tarski_def_1 sorry
qed

mlemma arytm_2_lm_10:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12 iff x =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12 implies x =XBOOLE-0R4 {}ARYTM-3K12) & (x =XBOOLE-0R4 {}ARYTM-3K12 implies DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have A1: " not ( ex e be objectHIDDENM1 st e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 {}ARYTM-3K12 })"
    proof-
      have "( ex e be objectHIDDENM1 st e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 {}ARYTM-3K12 }) implies  False "
      proof(rule impI)
        assume Given: " ex e be objectHIDDENM1 st e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 {}ARYTM-3K12 }"
        then obtain e where
          [ty]:"e be objectHIDDENM1" and 
          A2: "e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 {}ARYTM-3K12 }"
           sorry
        have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =HIDDENR1 e & s <ARYTM-3R4 {}ARYTM-3K12"
          using A2 sorry
        thus " False "
          using arytm_3_th_64 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12 implies x =XBOOLE-0R4 {}ARYTM-3K12"
    proof-
      have "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12 implies (x <>HIDDENR2 {}ARYTM-3K12 implies  False )"
      proof(rule impI)
        assume A3: "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12"
        show "x <>HIDDENR2 {}ARYTM-3K12 implies  False "
        proof-
          have cases: "x inTARSKIR2 RAT+ARYTM-3K5 or  not x inTARSKIR2 RAT+ARYTM-3K5"
             sorry
          have case1: "x inTARSKIR2 RAT+ARYTM-3K5 implies (x <>HIDDENR2 {}ARYTM-3K12 implies  False )"
          proof(rule impI,rule impI)
            assume A4: "x inTARSKIR2 RAT+ARYTM-3K5"
            assume A5: "x <>HIDDENR2 {}ARYTM-3K12"
            obtain r where
              [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A6: "x =XBOOLE-0R4 r"and A7: "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }"
              using A4 arytm_2_def_3 sorry
            have "{}ARYTM-3K12 <='ARYTM-3R3 r"
              using arytm_3_th_64 sorry
            then have "{}ARYTM-3K12 <ARYTM-3R4 r"
              using A6 A5 arytm_3_th_68 sorry
            then have "{}ARYTM-3K12 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x"
              using A7 sorry
            thus " False "
              using A3 sorry
          qed
          have case2: " not x inTARSKIR2 RAT+ARYTM-3K5 implies x =XBOOLE-0R4 {}ARYTM-3K12"
          proof(rule impI)
            assume " not x inTARSKIR2 RAT+ARYTM-3K5"
            thus "x =XBOOLE-0R4 {}ARYTM-3K12"
              using A3 arytm_2_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    assume "x =XBOOLE-0R4 {}ARYTM-3K12"
    then have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st {}ARYTM-3K12 =XBOOLE-0R4 r & DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }"
      using arytm_2_def_3 sorry
    thus "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12"
      using A1 xboole_0_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_11:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds GLUEDARYTM-2K4 A =XBOOLE-0R4 {}ARYTM-3K12 iff A =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds (GLUEDARYTM-2K4 A =XBOOLE-0R4 {}ARYTM-3K12 implies A =XBOOLE-0R4 {}ARYTM-3K12) & (A =XBOOLE-0R4 {}ARYTM-3K12 implies (GLUEDARYTM-2K4 A <>HIDDENR2 {}ARYTM-3K12 implies  False ))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    show "GLUEDARYTM-2K4 A =XBOOLE-0R4 {}ARYTM-3K12 implies A =XBOOLE-0R4 {}ARYTM-3K12"
    proof-
      have "GLUEDARYTM-2K4 A =XBOOLE-0R4 {}ARYTM-3K12 implies (A <>HIDDENR2 {}ARYTM-3K12 implies  False )"
      proof(rule impI)
        assume A1: "GLUEDARYTM-2K4 A =XBOOLE-0R4 {}ARYTM-3K12"
        show "A <>HIDDENR2 {}ARYTM-3K12 implies  False "
        proof-
          have cases: "( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r) or  not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r)"
             sorry
          have case1: "( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r) implies (A <>HIDDENR2 {}ARYTM-3K12 implies  False )"
          proof(rule impI,rule impI)
            assume A2: " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r"
            assume "A <>HIDDENR2 {}ARYTM-3K12"
            then obtain r where
              [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A3: "r inTARSKIR2 A"
              using subset_1_th_4 sorry
            have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st GLUEDARYTM-2K4 A =XBOOLE-0R4 r & ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r)"
              using A2 arytm_2_def_4 sorry
            then have "r <ARYTM-3R4 {}ARYTM-3K12"
              using A1 A3 sorry
            thus " False "
              using arytm_3_th_64 sorry
          qed
          have case2: " not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r) implies A =XBOOLE-0R4 {}ARYTM-3K12"
          proof(rule impI)
            assume " not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r)"
            thus "A =XBOOLE-0R4 {}ARYTM-3K12"
              using A1 arytm_2_def_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: "A =XBOOLE-0R4 {}ARYTM-3K12"
    then have " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 {}ARYTM-3K12"
      using arytm_3_th_64 sorry
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A5: "GLUEDARYTM-2K4 A =XBOOLE-0R4 r"and A6: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r"
      using arytm_2_def_4 sorry
    assume A7: "GLUEDARYTM-2K4 A <>HIDDENR2 {}ARYTM-3K12"
    have "{}ARYTM-3K12 <='ARYTM-3R3 r"
      using arytm_3_th_64 sorry
    then have "{}ARYTM-3K12 <ARYTM-3R4 r"
      using A5 A7 arytm_3_th_68 sorry
    thus " False "
      using A4 A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_12:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 A"
proof-
  have " for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) c=TARSKIR1 A"
  proof(rule ballI)
    fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    show "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) c=TARSKIR1 A"
    proof-
      have cases: "(( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r) or A =XBOOLE-0R4 {}ARYTM-3K12) or A <>HIDDENR2 {}ARYTM-3K12 &  not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r)"
         sorry
      have case1: "( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r) implies DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 A"
      proof(rule impI)
        assume " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r"
        then obtain r where
          [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A1: "r =XBOOLE-0R4 GLUEDARYTM-2K4 A"and A2: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r"
          using arytm_2_def_4 sorry
        obtain s where
          [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A3: "r =XBOOLE-0R4 s"and A4: "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 {t where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <ARYTM-3R4 s }"
          using A1 arytm_2_def_3 sorry
        have "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) c=TARSKIR1 A & A c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A)"
        proof(rule conjMI)
          show "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) c=TARSKIR1 A"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) implies e inHIDDENR3 A"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A)"
              then have " ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t =HIDDENR1 e & t <ARYTM-3R4 s"
                using A4 sorry
              thus "e inHIDDENR3 A"
                using A2 A3 sorry
            qed "sorry"
            thus "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) c=TARSKIR1 A"
              using tarski_def_3 sorry
          qed
          have " for e be objectHIDDENM1 holds e inHIDDENR3 A implies e inHIDDENR3 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A)"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume A5: "e inHIDDENR3 A"
            then obtain s where 
              [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and sDef:"s = e"
               sorry
            have "s <ARYTM-3R4 r"
              using A2 A5 sorry
            thus "e inHIDDENR3 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A)"
              using A3 A4 sorry
          qed "sorry"
          thus "A c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A)"
            using tarski_def_3 sorry
        qed
        thus "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 A"
          using xboole_0_def_10 sorry
      qed
      have case2: "A =XBOOLE-0R4 {}ARYTM-3K12 implies DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 A"
      proof(rule impI)
        assume A6: "A =XBOOLE-0R4 {}ARYTM-3K12"
        then have "GLUEDARYTM-2K4 A =XBOOLE-0R4 {}ARYTM-3K12"
          using arytm_2_lm_11 sorry
        thus "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 A"
          using A6 arytm_2_lm_10 sorry
      qed
      have case3: "A <>HIDDENR2 {}ARYTM-3K12 &  not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r) implies DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 A"
      proof(rule impMI ,rule impI)
        assume A7: "A <>HIDDENR2 {}ARYTM-3K12"
          and A8: " not ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 A iff s <ARYTM-3R4 r)"
        have A9: "GLUEDARYTM-2K4 A =XBOOLE-0R4 A"
          using A8 arytm_2_def_4 sorry
        have "GLUEDARYTM-2K4 A inTARSKIR2 RAT+ARYTM-3K5 implies  False "
        proof(rule impI)
          assume "GLUEDARYTM-2K4 A inTARSKIR2 RAT+ARYTM-3K5"
          then have "GLUEDARYTM-2K4 A inTARSKIR2 (RAT+ARYTM-3K5)/\\SUBSET-1K9\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> (DEDEKIND-CUTSARYTM-2K1)"
            using A9 xboole_0_def_4 sorry
          then have "GLUEDARYTM-2K4 A =XBOOLE-0R4 {}ARYTM-3K12"
            using arytm_2_lm_9 tarski_def_1 sorry
          thus " False "
            using A7 arytm_2_lm_11 sorry
        qed
        thus "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 A) =XBOOLE-0R4 A"
          using A9 arytm_2_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_13:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } & y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } implies x c=TARSKIR1 y or y c=TARSKIR1 x"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } implies (y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } implies ( not x c=TARSKIR1 y implies y c=TARSKIR1 x))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
    then have A1: " ex A9 be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 A9 & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A9 implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A9) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A9 & r <ARYTM-3R4 s))"
       sorry
    assume "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
    then have A2: " ex B9 be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st y =XBOOLE-0R4 B9 & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B9 implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B9) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B9 & r <ARYTM-3R4 s))"
       sorry
    assume " not x c=TARSKIR1 y"
    then obtain s where
      [ty]:"s be objectHIDDENM1" and 
      A3: "s inHIDDENR3 x"and A4: " not s inHIDDENR3 y"
       sorry
    have 
      [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
      using A1 A3 sorry
    have " for e be objectHIDDENM1 holds e inHIDDENR3 y implies e inHIDDENR3 x"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A5: "e inHIDDENR3 y"
      then obtain r where 
        [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and rDef:"r = e"
        using A2 sorry
      have "r <='ARYTM-3R3 s"
        using A2 A4 A5 sorry
      thus "e inHIDDENR3 x"
        using A1 A3 sorry
    qed "sorry"
    thus "y c=TARSKIR1 x"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef arytm_2_def_5 (" _ <=''ARYTM-2R1  _ " [50,50]50 ) where
  mlet "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2", "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
"pred x <='ARYTM-2R1 y means
   ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9 if x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5,
  x inTARSKIR2 y if x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5,
   not y inTARSKIR2 x if  not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 otherwise x c=TARSKIR1 y"
proof-
  (*consistency*)
    show "(((x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) & (x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5) implies (( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9) iff x inTARSKIR2 y)) & ((x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) & ( not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) implies (( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9) iff  not y inTARSKIR2 x))) & ((x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5) & ( not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) implies (x inTARSKIR2 y iff  not y inTARSKIR2 x))"
       sorry
qed "sorry"

mtheorem ARYTM_2R1_connectedness:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not x <='ARYTM-2R1 y implies y <='ARYTM-2R1 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9)) & ((x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies x inTARSKIR2 y) & (( not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies  not y inTARSKIR2 x) & ( not (x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) & ( not (x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5) &  not ( not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5)) implies x c=TARSKIR1 y)))) implies (y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (y =XBOOLE-0R4 x9 & x =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9)) & ((y inTARSKIR2 RAT+ARYTM-3K5 &  not x inTARSKIR2 RAT+ARYTM-3K5 implies y inTARSKIR2 x) & (( not y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 implies  not x inTARSKIR2 y) & ( not (y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5) & ( not (y inTARSKIR2 RAT+ARYTM-3K5 &  not x inTARSKIR2 RAT+ARYTM-3K5) &  not ( not y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5)) implies y c=TARSKIR1 x)))"
  proof-
    have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (( not (x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9)) or  not (x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies x inTARSKIR2 y)) or  not ( not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies  not y inTARSKIR2 x)) or  not ( not ((x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 or x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5) or  not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) implies x c=TARSKIR1 y) implies (y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (y =XBOOLE-0R4 y9 & x =XBOOLE-0R4 x9) & y9 <='ARYTM-3R3 x9)) & ((y inTARSKIR2 RAT+ARYTM-3K5 &  not x inTARSKIR2 RAT+ARYTM-3K5 implies y inTARSKIR2 x) & (( not y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 implies  not x inTARSKIR2 y) & ( not ((y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 or y inTARSKIR2 RAT+ARYTM-3K5 &  not x inTARSKIR2 RAT+ARYTM-3K5) or  not y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5) implies y c=TARSKIR1 x)))"
    proof(rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
      fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
      assume A1: "(( not (x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9)) or  not (x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies x inTARSKIR2 y)) or  not ( not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies  not y inTARSKIR2 x)) or  not ( not ((x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 or x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5) or  not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) implies x c=TARSKIR1 y)"
      show "y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 implies ( ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (y =XBOOLE-0R4 y9 & x =XBOOLE-0R4 x9) & y9 <='ARYTM-3R3 x9)"
      proof-
        have "y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 implies  not ( for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not ((y =XBOOLE-0R4 y9 & x =XBOOLE-0R4 x9) & y9 <='ARYTM-3R3 x9))"
        proof(rule impI)
          assume "y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5"
          then obtain y9 x9 where 
            [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y" and
            [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
             sorry
          have "y9 <='ARYTM-3R3 x9"
            using A1 sorry
          thus " not ( for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not ((y =XBOOLE-0R4 y9 & x =XBOOLE-0R4 x9) & y9 <='ARYTM-3R3 x9))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
      show "y inTARSKIR2 RAT+ARYTM-3K5 &  not x inTARSKIR2 RAT+ARYTM-3K5 implies y inTARSKIR2 x"
        using A1 sorry
      show " not y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 implies  not x inTARSKIR2 y"
        using A1 sorry
      assume A2: " not ((y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5 or y inTARSKIR2 RAT+ARYTM-3K5 &  not x inTARSKIR2 RAT+ARYTM-3K5) or  not y inTARSKIR2 RAT+ARYTM-3K5 & x inTARSKIR2 RAT+ARYTM-3K5)"
      have "y inTARSKIR2 REAL+ARYTM-2K2"
         sorry
      then have A3: "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
        using A2 arytm_2_lm_3 xboole_0_def_3 sorry
      have "x inTARSKIR2 REAL+ARYTM-2K2"
         sorry
      then have "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
        using A2 arytm_2_lm_3 xboole_0_def_3 sorry
      thus "y c=TARSKIR1 x"
        using A1 A2 A3 arytm_2_lm_13 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using arytm_2_def_5 sorry
qed

syntax ARYTM_2R2 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ <ARYTM-2R2  _ " [50,50]50)
translations "y <ARYTM-2R2 x" \<rightharpoonup> " not x <='ARYTM-2R1 y"

mlemma arytm_2_lm_14:
" for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9 implies (x <='ARYTM-2R1 y iff x9 <='ARYTM-3R3 y9)"
proof-
  have " for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9 implies (x <='ARYTM-2R1 y implies x9 <='ARYTM-3R3 y9) &  not (x9 <='ARYTM-3R3 y9 &  not x <='ARYTM-2R1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9"
    show "x <='ARYTM-2R1 y implies x9 <='ARYTM-3R3 y9"
    proof(rule impI)
      assume "x <='ARYTM-2R1 y"
      then have " ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x9 <='ARYTM-3R3 y9"
        using A1 arytm_2_def_5 sorry
      thus "x9 <='ARYTM-3R3 y9"
        using A1 sorry
    qed
    show " not (x9 <='ARYTM-3R3 y9 &  not x <='ARYTM-2R1 y)"
      using A1 arytm_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_15:
" for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 & B <>HIDDENR2 {}ARYTM-3K12 implies ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st r inTARSKIR2 B & r <>HIDDENR2 {}ARYTM-3K12)"
proof-
  have " for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 & B <>HIDDENR2 {}ARYTM-3K12 implies  not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 B &  not r <>HIDDENR2 {}ARYTM-3K12))"
  proof(rule ballI,rule impMI ,rule impI)
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
      and A2: "B <>HIDDENR2 {}ARYTM-3K12"
    have "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
      using A1 sorry
    then obtain A where
      [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
      A3: "B =XBOOLE-0R4 A"and A4: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
       sorry
    have 
      [ty]:"A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5"
      using A2 A3 sorry
    obtain r0 where
      [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A5: "r0 inTARSKIR2 A"
      using subset_1_th_4 sorry
    obtain r1 where
      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A6: "r1 inTARSKIR2 A"and A7: "r0 <ARYTM-3R4 r1"
      using A4 A5 sorry
    have A8: "r1 <>HIDDENR2 {}ARYTM-3K12 or r0 <>HIDDENR2 {}ARYTM-3K12"
      using A7 sorry
    have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A"
      using A4 sorry
    then obtain r1 r2 r3 where
      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A9: "r1 inTARSKIR2 A & r2 inTARSKIR2 A"and "r3 inTARSKIR2 A"and A10: "r1 <>HIDDENR2 r2"and "r2 <>HIDDENR2 r3"and "r3 <>HIDDENR2 r1"
      using A5 A6 A8 arytm_3_th_75 sorry
    have "r1 <>HIDDENR2 {}ARYTM-3K12 or r2 <>HIDDENR2 {}ARYTM-3K12"
      using A10 sorry
    thus " not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 B &  not r <>HIDDENR2 {}ARYTM-3K12))"
      using A3 A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_16:
" for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds (B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 & r inTARSKIR2 B) & s <='ARYTM-3R3 r implies s inTARSKIR2 B"
proof-
  have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 & (r inTARSKIR2 B & s <='ARYTM-3R3 r) implies s inTARSKIR2 B"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
      and A2: "r inTARSKIR2 B & s <='ARYTM-3R3 r"
    have "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
      using A1 sorry
    then have " ex A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st B =XBOOLE-0R4 A & ( for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & t <ARYTM-3R4 s))"
       sorry
    thus "s inTARSKIR2 B"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_17:
" for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 & B <>HIDDENR2 {}ARYTM-3K12 implies {}ARYTM-3K12 inTARSKIR2 B"
proof(rule ballI,rule impMI ,rule impI)
  fix B assume [ty]: "B be setHIDDENM2"
  assume A1: "B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
    and A2: "B <>HIDDENR2 {}ARYTM-3K12"
  have 
    [ty]:"B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5"
    using A1 A2 sorry
  have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st r inTARSKIR2 B"
    using subset_1_th_4 sorry
  thus "{}ARYTM-3K12 inTARSKIR2 B"
    using A1 arytm_2_lm_16 arytm_3_th_64 sorry
qed "sorry"

mlemma arytm_2_lm_18:
" for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds (B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }) &  not r inTARSKIR2 B) & B <>HIDDENR2 {}ARYTM-3K12 implies ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not s inTARSKIR2 B & s <ARYTM-3R4 r)"
proof-
  have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }) & ( not r inTARSKIR2 B & B <>HIDDENR2 {}ARYTM-3K12) implies (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not s inTARSKIR2 B implies  not s <ARYTM-3R4 r) implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 })"
      and A2: " not r inTARSKIR2 B"
      and A3: "B <>HIDDENR2 {}ARYTM-3K12"
    have A4: "B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
      using A1 xboole_0_def_5 sorry
    assume A5: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not s inTARSKIR2 B implies  not s <ARYTM-3R4 r"
    have A6: "B =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }"
    proof-
      have "B =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r }"
      proof-
        have "B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r } & {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r } c=TARSKIR1 B"
        proof(rule conjMI)
          show "B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }"
          proof-
            have "B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r }"
            proof-
              have " for e be objectHIDDENM1 holds e inHIDDENR3 B implies e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r }"
              proof(rule ballI,rule impI)
                fix e assume [ty]: "e be objectHIDDENM1"
                assume A7: "e inHIDDENR3 B"
                have 
                  [ty]:"B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
                  using A1 xboole_0_def_5 sorry
                have "B c=TARSKIR1 RAT+ARYTM-3K5"
                   sorry
                then obtain t where 
                  [ty]:"t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and tDef:"t = e"
                  using A7 sorry
                have " not r <='ARYTM-3R3 t"
                  using A2 A4 A7 arytm_2_lm_16 sorry
                thus "e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r }"
                   sorry
              qed "sorry"
              thus "B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have " for e be objectHIDDENM1 holds e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r } implies e inHIDDENR3 B"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }"
            then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =HIDDENR1 e & s <ARYTM-3R4 r"
               sorry
            thus "e inHIDDENR3 B"
              using A5 sorry
          qed "sorry"
          thus "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r } c=TARSKIR1 B"
            using tarski_def_3 sorry
        qed
        thus "B =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "r <>HIDDENR2 {}ARYTM-3K12"
      using A2 A3 A4 arytm_2_lm_17 sorry
    then have "B inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
      using A6 sorry
    thus " False "
      using A1 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_19:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds DEDEKIND-CUTARYTM-2K3 x inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } implies x inTARSKIR2 RAT+ARYTM-3K5"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds DEDEKIND-CUTARYTM-2K3 x inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } implies ( not x inTARSKIR2 RAT+ARYTM-3K5 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "DEDEKIND-CUTARYTM-2K3 x inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
    assume " not x inTARSKIR2 RAT+ARYTM-3K5"
    then have "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 x"
      using arytm_2_def_3 sorry
    thus " False "
      using A1 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_20:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds DEDEKIND-CUTARYTM-2K3 x c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 y implies x <='ARYTM-2R1 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds DEDEKIND-CUTARYTM-2K3 x c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 y implies x <='ARYTM-2R1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "DEDEKIND-CUTARYTM-2K3 x c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 y"
    show "x <='ARYTM-2R1 y"
    proof-
      have cases: "((((x =XBOOLE-0R4 {}ARYTM-3K12 &  not y inTARSKIR2 RAT+ARYTM-3K5 or y =XBOOLE-0R4 {}ARYTM-3K12) or x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) or x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 & x <>HIDDENR2 {}ARYTM-3K12)) or  not x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 & y <>HIDDENR2 {}ARYTM-3K12)) or  not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5"
         sorry
      have case1: "x =XBOOLE-0R4 {}ARYTM-3K12 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies x <='ARYTM-2R1 y"
      proof(rule impMI ,rule impI)
        assume A2: "x =XBOOLE-0R4 {}ARYTM-3K12"
          and A3: " not y inTARSKIR2 RAT+ARYTM-3K5"
        have "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 y & y <>HIDDENR2 {}ARYTM-3K12"
          using A3 arytm_2_def_3 sorry
        then have "x inTARSKIR2 y"
          using A2 arytm_2_lm_17 sorry
        thus "x <='ARYTM-2R1 y"
          using A2 A3 arytm_2_def_5 sorry
      qed
      have case2: "y =XBOOLE-0R4 {}ARYTM-3K12 implies x <='ARYTM-2R1 y"
      proof(rule impI)
        assume A4: "y =XBOOLE-0R4 {}ARYTM-3K12"
        then have "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {}ARYTM-3K12"
          using arytm_2_lm_10 sorry
        then have "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12"
          using A1 sorry
        then have "x =XBOOLE-0R4 {}ARYTM-3K12"
          using arytm_2_lm_10 sorry
        thus "x <='ARYTM-2R1 y"
          using A4 sorry
      qed
      have case3: "x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies (y <ARYTM-2R2 x implies  False )"
      proof(rule impMI ,rule impI,rule impI)
        assume A5: "x inTARSKIR2 RAT+ARYTM-3K5"
          and A6: "y inTARSKIR2 RAT+ARYTM-3K5"
        obtain ry where
          [ty]:"ry be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A7: "y =XBOOLE-0R4 ry"and A8: "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 ry }"
          using A6 arytm_2_def_3 sorry
        obtain rx where
          [ty]:"rx be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A9: "x =XBOOLE-0R4 rx"and A10: "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 rx }"
          using A5 arytm_2_def_3 sorry
        assume "y <ARYTM-2R2 x"
        then have "ry <ARYTM-3R4 rx"
          using A9 A7 arytm_2_lm_14 sorry
        then have "ry inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x"
          using A10 sorry
        then have "ry inTARSKIR2 DEDEKIND-CUTARYTM-2K3 y"
          using A1 sorry
        then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 ry & s <ARYTM-3R4 ry"
          using A8 sorry
        thus " False "
           sorry
      qed
      have case4: "x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 & x <>HIDDENR2 {}ARYTM-3K12) implies x <='ARYTM-2R1 y"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A11: "x inTARSKIR2 RAT+ARYTM-3K5"
          and A12: " not y inTARSKIR2 RAT+ARYTM-3K5"
          and A13: "x <>HIDDENR2 {}ARYTM-3K12"
        have A14: "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 y"
          using A12 arytm_2_def_3 sorry
        obtain rx where
          [ty]:"rx be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A15: "x =XBOOLE-0R4 rx"and A16: "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 rx }"
          using A11 arytm_2_def_3 sorry
        have "DEDEKIND-CUTARYTM-2K3 x inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
          using A13 A15 A16 sorry
        then have "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 y"
          using A12 A14 arytm_2_lm_19 sorry
        then have " not DEDEKIND-CUTARYTM-2K3 y c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 x"
          using A1 A14 sorry
        then obtain r0 where
          [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A17: "r0 inTARSKIR2 y"and A18: " not r0 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x"
          using A14 sorry
        have "rx <='ARYTM-3R3 r0"
          using A16 A18 sorry
        then have "x inTARSKIR2 y"
          using A15 A14 A17 arytm_2_lm_16 sorry
        thus "x <='ARYTM-2R1 y"
          using A11 A12 arytm_2_def_5 sorry
      qed
      have case5: " not x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 & y <>HIDDENR2 {}ARYTM-3K12) implies x <='ARYTM-2R1 y"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A19: " not x inTARSKIR2 RAT+ARYTM-3K5"
          and A20: "y inTARSKIR2 RAT+ARYTM-3K5"
          and A21: "y <>HIDDENR2 {}ARYTM-3K12"
        obtain ry where
          [ty]:"ry be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A22: "y =XBOOLE-0R4 ry"and A23: "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 ry }"
          using A20 arytm_2_def_3 sorry
        have A24: "DEDEKIND-CUTARYTM-2K3 y inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
          using A21 A22 A23 sorry
        have A25: "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 x"
          using A19 arytm_2_def_3 sorry
        then have " not x inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
          using A19 arytm_2_lm_19 sorry
        then have " not DEDEKIND-CUTARYTM-2K3 y c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 x"
          using A1 A24 A25 xboole_0_def_10 sorry
        then obtain r0 where
          [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A26: "r0 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 y"and A27: " not r0 inTARSKIR2 x"
          using A25 sorry
        have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r0 & s <ARYTM-3R4 ry"
          using A23 A26 sorry
        then have " not y inTARSKIR2 x"
          using A22 A25 A27 arytm_2_lm_16 sorry
        thus "x <='ARYTM-2R1 y"
          using A19 A20 arytm_2_def_5 sorry
      qed
      have case6: " not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies x <='ARYTM-2R1 y"
      proof(rule impI)
        assume A28: " not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5"
        have "x =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 x & y =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 y"
          using A28 arytm_2_def_3 sorry
        thus "x <='ARYTM-2R1 y"
          using A1 A28 arytm_2_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_21:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y <='ARYTM-2R1 x implies x =XBOOLE-0R4 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y <='ARYTM-2R1 x implies x =XBOOLE-0R4 y"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
      and A2: "y <='ARYTM-2R1 x"
    show "x =XBOOLE-0R4 y"
    proof-
      have cases: "((x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 or x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5) or  not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) or  not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5"
         sorry
      have case1: "x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies x =XBOOLE-0R4 y"
      proof(rule impI)
        assume "x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5"
        then obtain x9 y9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x" and
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
           sorry
        have "x9 <='ARYTM-3R3 y9 & y9 <='ARYTM-3R3 x9"
          using A1 A2 arytm_2_lm_14 sorry
        thus "x =XBOOLE-0R4 y"
          using arytm_3_th_66 sorry
      qed
      have case2: "x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies x =XBOOLE-0R4 y"
      proof(rule impI)
        assume A3: "x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5"
        have "x inTARSKIR2 y"
          using A1 A3 arytm_2_def_5 sorry
        thus "x =XBOOLE-0R4 y"
          using A2 A3 arytm_2_def_5 sorry
      qed
      have case3: " not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies x =XBOOLE-0R4 y"
      proof(rule impI)
        assume A4: " not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5"
        have "y inTARSKIR2 x"
          using A2 A4 arytm_2_def_5 sorry
        thus "x =XBOOLE-0R4 y"
          using A1 A4 arytm_2_def_5 sorry
      qed
      have case4: " not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies x =XBOOLE-0R4 y"
      proof(rule impI)
        assume " not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5"
        then have "x c=TARSKIR1 y & y c=TARSKIR1 x"
          using A1 A2 arytm_2_def_5 sorry
        thus "x =XBOOLE-0R4 y"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_22:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 y implies x =XBOOLE-0R4 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 y implies x =XBOOLE-0R4 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 y"
    then have "x <='ARYTM-2R1 y & y <='ARYTM-2R1 x"
      using arytm_2_lm_20 sorry
    thus "x =XBOOLE-0R4 y"
      using arytm_2_lm_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_23:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x) =XBOOLE-0R4 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x) =XBOOLE-0R4 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x)) =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 x"
      using arytm_2_lm_12 sorry
    thus "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x) =XBOOLE-0R4 x"
      using arytm_2_lm_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef arytm_2_def_6 (" _ +ARYTM-2K5  _ " [132,132]132 ) where
  mlet "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1", "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
"func A +ARYTM-2K5 B \<rightarrow> ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 equals
  {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
proof-
  (*coherence*)
    show "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    proof-
      have "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
      proof-
        have "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
        proof-
          have "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
          proof-
            let ?C = "{s +ARYTM-3K10 t where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A & t inTARSKIR2 B }"
            have "?C c=TARSKIR1 RAT+ARYTM-3K5"
            proof-
              have "{s +ARYTM-3K10 t where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A & t inTARSKIR2 B } c=TARSKIR1 RAT+ARYTM-3K5"
              proof-
                have " for e be objectHIDDENM1 holds e inHIDDENR3 {s +ARYTM-3K10 t where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A & t inTARSKIR2 B } implies e inHIDDENR3 RAT+ARYTM-3K5"
                proof(rule ballI,rule impI)
                  fix e assume [ty]: "e be objectHIDDENM1"
                  assume "e inHIDDENR3 ?C"
                  then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 s +ARYTM-3K10 t & s inTARSKIR2 A) & t inTARSKIR2 B"
                     sorry
                  thus "e inHIDDENR3 RAT+ARYTM-3K5"
                     sorry
                qed "sorry"
                thus "{s +ARYTM-3K10 t where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A & t inTARSKIR2 B } c=TARSKIR1 RAT+ARYTM-3K5"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain C where 
              [ty]:"C be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and CDef:"C = ?C"
               sorry
            have "A <>HIDDENR2 RAT+ARYTM-3K5"
              using zfmisc_1_th_56 sorry
            then obtain a0 where
              [ty]:"a0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A1: " not a0 inTARSKIR2 A"
              using subset_1_th_28 sorry
            have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 C & r <ARYTM-3R4 s)"
            proof-
              have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex t2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t2 inTARSKIR2 C &  not r <ARYTM-3R4 t2)"
              proof(rule ballI,rule impI,rule conjMI)
                fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
                assume "r inTARSKIR2 C"
                then obtain s0 t0 where
                  [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A2: "r =XBOOLE-0R4 s0 +ARYTM-3K10 t0"and A3: "s0 inTARSKIR2 A"and A4: "t0 inTARSKIR2 B"
                   sorry
                show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C"
                proof(rule ballI,rule impI)
                  fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
                  assume "s <='ARYTM-3R3 r"
                  then obtain s1 t1 where
                    [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    A5: "s =XBOOLE-0R4 s1 +ARYTM-3K10 t1"and A6: "s1 <='ARYTM-3R3 s0 & t1 <='ARYTM-3R3 t0"
                    using A2 arytm_3_th_87 sorry
                  have "s1 inTARSKIR2 A & t1 inTARSKIR2 B"
                    using A3 A4 A6 arytm_2_lm_16 sorry
                  thus "s inTARSKIR2 C"
                    using A5 sorry
                qed "sorry"
                obtain s1 where
                  [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A7: "s1 inTARSKIR2 A"and A8: "s0 <ARYTM-3R4 s1"
                  using A3 arytm_2_lm_7 sorry
                obtain t2 where 
                  [ty]:"t2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and t2Def:"t2 = s1 +ARYTM-3K10 t0"
                   sorry
                show " ex t2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t2 inTARSKIR2 C &  not r <ARYTM-3R4 t2"
                proof(rule bexI[of _ "t2"],rule conjMI)
                  show "t2 inTARSKIR2 C"
                    using A4 A7 sorry
                  show " not r <ARYTM-3R4 t2"
                    using A2 A8 arytm_3_th_76 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            then have A9: "C inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
               sorry
            have "B <>HIDDENR2 RAT+ARYTM-3K5"
              using zfmisc_1_th_56 sorry
            then obtain b0 where
              [ty]:"b0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A10: " not b0 inTARSKIR2 B"
              using subset_1_th_28 sorry
            have "a0 +ARYTM-3K10 b0 inTARSKIR2 C implies  False "
            proof(rule impI)
              assume "a0 +ARYTM-3K10 b0 inTARSKIR2 C"
              then obtain s t where
                [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                A11: "a0 +ARYTM-3K10 b0 =XBOOLE-0R4 s +ARYTM-3K10 t"and A12: "s inTARSKIR2 A & t inTARSKIR2 B"
                 sorry
              have "a0 <='ARYTM-3R3 s or b0 <='ARYTM-3R3 t"
                using A11 arytm_3_th_81 sorry
              thus " False "
                using A1 A10 A12 arytm_2_lm_16 sorry
            qed
            then have "C <>HIDDENR2 RAT+ARYTM-3K5"
               sorry
            thus "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
              using A9 zfmisc_1_th_56 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem ARYTM_2K5_commutativity:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A +ARYTM-2K5 B =HIDDENR1 B +ARYTM-2K5 A"
proof-
  have " for it be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds it =HIDDENR1 A +ARYTM-2K5 B implies it =HIDDENR1 B +ARYTM-2K5 A"
  proof-
    have " for it be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds it =HIDDENR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } implies it =HIDDENR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
    proof-
      have " for IT be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  not (IT =HIDDENR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } &  not IT =HIDDENR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A })"
      proof(rule ballI,rule ballI,rule ballI)
        fix IT assume [ty]: "IT be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
        fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
        fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
        let ?C = "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
        let ?D = "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
        have A13: "?D c=TARSKIR1 ?C"
        proof-
          have "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A } c=TARSKIR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A } implies e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ?D"
              then have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 r +ARYTM-3K10 s & r inTARSKIR2 B) & s inTARSKIR2 A"
                 sorry
              thus "e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
                 sorry
            qed "sorry"
            thus "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A } c=TARSKIR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "?C c=TARSKIR1 ?D"
        proof-
          have "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } c=TARSKIR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } implies e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ?C"
              then have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 r +ARYTM-3K10 s & r inTARSKIR2 A) & s inTARSKIR2 B"
                 sorry
              thus "e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
                 sorry
            qed "sorry"
            thus "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } c=TARSKIR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not (IT =HIDDENR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } &  not IT =HIDDENR1 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A })"
          using A13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using arytm_2_def_6 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_24:
" for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 implies ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not r inTARSKIR2 B)"
proof-
  have " for B be setHIDDENM2 holds B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 implies  not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B)"
  proof(rule ballI,rule impI)
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
    then have 
      [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5"
       sorry
    have "B <>HIDDENR2 RAT+ARYTM-3K5"
      using A1 zfmisc_1_th_56 sorry
    thus " not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B)"
      using subset_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef arytm_2_def_7 (" _ *''ARYTM-2K6  _ " [228,228]228 ) where
  mlet "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1", "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
"func A *'ARYTM-2K6 B \<rightarrow> ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 equals
  {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
proof-
  (*coherence*)
    show "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    proof-
      have "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
      proof-
        show "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
        proof-
          have cases: "A =XBOOLE-0R4 {}ARYTM-3K12 or A <>HIDDENR2 {}ARYTM-3K12"
             sorry
          have case1: "A =XBOOLE-0R4 {}ARYTM-3K12 implies {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
          proof(rule impI)
            assume A1: "A =XBOOLE-0R4 {}ARYTM-3K12"
            have " not ( ex e be objectHIDDENM1 st e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B })"
            proof-
              have "( ex e be objectHIDDENM1 st e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }) implies  False "
              proof(rule impI)
                assume Given: " ex e be objectHIDDENM1 st e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
                then obtain e where
                  [ty]:"e be objectHIDDENM1" and 
                  A2: "e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
                   sorry
                have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 r *'ARYTM-3K11 s & r inTARSKIR2 A) & s inTARSKIR2 B"
                  using A2 sorry
                thus " False "
                  using A1 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            thus "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
              using arytm_2_lm_8 xboole_0_def_1 sorry
          qed
          have case2: "A <>HIDDENR2 {}ARYTM-3K12 implies {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
          proof(rule impI)
            assume A3: "A <>HIDDENR2 {}ARYTM-3K12"
            let ?C = "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
            have "?C c=TARSKIR1 RAT+ARYTM-3K5"
            proof-
              have "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } c=TARSKIR1 RAT+ARYTM-3K5"
              proof-
                have " for e be objectHIDDENM1 holds e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } implies e inHIDDENR3 RAT+ARYTM-3K5"
                proof(rule ballI,rule impI)
                  fix e assume [ty]: "e be objectHIDDENM1"
                  assume "e inHIDDENR3 ?C"
                  then have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (r *'ARYTM-3K11 s =HIDDENR1 e & r inTARSKIR2 A) & s inTARSKIR2 B"
                     sorry
                  thus "e inHIDDENR3 RAT+ARYTM-3K5"
                     sorry
                qed "sorry"
                thus "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } c=TARSKIR1 RAT+ARYTM-3K5"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain C where 
              [ty]:"C be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and CDef:"C = ?C"
               sorry
            have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 C & r <ARYTM-3R4 s)"
            proof-
              have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex tVar9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar9 inTARSKIR2 C &  not r <ARYTM-3R4 tVar9)"
              proof(rule ballI,rule impI,rule conjMI)
                fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
                assume "r inTARSKIR2 C"
                then obtain r0 s0 where
                  [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A4: "r =XBOOLE-0R4 r0 *'ARYTM-3K11 s0"and A5: "r0 inTARSKIR2 A"and A6: "s0 inTARSKIR2 B"
                   sorry
                show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C"
                proof(rule ballI,rule impI)
                  fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
                  assume "s <='ARYTM-3R3 r"
                  then obtain t0 where
                    [ty]:"t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    A7: "s =XBOOLE-0R4 r0 *'ARYTM-3K11 t0"and A8: "t0 <='ARYTM-3R3 s0"
                    using A4 arytm_3_th_79 sorry
                  have "t0 inTARSKIR2 B"
                    using A6 A8 arytm_2_lm_16 sorry
                  thus "s inTARSKIR2 C"
                    using A5 A7 sorry
                qed "sorry"
                obtain t0 where
                  [ty]:"t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A9: "t0 inTARSKIR2 B"and A10: "s0 <ARYTM-3R4 t0"
                  using A6 arytm_2_lm_7 sorry
                show " ex tVar9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar9 inTARSKIR2 C &  not r <ARYTM-3R4 tVar9"
                proof-
                  have cases: "r0 =XBOOLE-0R4 {}ARYTM-3K12 or r0 <>HIDDENR2 {}ARYTM-3K12"
                     sorry
                  have case1: "r0 =XBOOLE-0R4 {}ARYTM-3K12 implies ( ex tVar9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar9 inTARSKIR2 C &  not r <ARYTM-3R4 tVar9)"
                  proof(rule impI)
                    assume A11: "r0 =XBOOLE-0R4 {}ARYTM-3K12"
                    obtain r1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                      A12: "r1 inTARSKIR2 A"and A13: "r1 <>HIDDENR2 {}ARYTM-3K12"
                      using A3 arytm_2_lm_15 sorry
                    show " ex tVar9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar9 inTARSKIR2 C &  not r <ARYTM-3R4 tVar9"
                    proof(rule bexI[of _ "r1 *'ARYTM-3K11 t0"],rule conjMI)
                      show "r1 *'ARYTM-3K11 t0 inTARSKIR2 C"
                        using A9 A12 sorry
                      have "t0 <>HIDDENR2 {}ARYTM-3K12"
                        using A10 arytm_3_th_64 sorry
                      then have A14: "r1 *'ARYTM-3K11 t0 <>HIDDENR2 {}ARYTM-3K12"
                        using A13 arytm_3_th_78 sorry
                      have A15: "r =XBOOLE-0R4 {}ARYTM-3K12"
                        using A4 A11 arytm_3_th_48 sorry
                      then have "r <='ARYTM-3R3 r1 *'ARYTM-3K11 t0"
                        using arytm_3_th_64 sorry
                      thus " not r <ARYTM-3R4 r1 *'ARYTM-3K11 t0"
                        using A15 A14 arytm_3_th_68 sorry
                    qed "sorry"
                  qed
                  have case2: "r0 <>HIDDENR2 {}ARYTM-3K12 implies ( ex tVar10 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar10 inTARSKIR2 C &  not r <ARYTM-3R4 tVar10)"
                  proof(rule impI)
                    assume A16: "r0 <>HIDDENR2 {}ARYTM-3K12"
                    have "s0 <>HIDDENR2 t0"
                      using A10 sorry
                    then have A17: "r <>HIDDENR2 r0 *'ARYTM-3K11 t0"
                      using A4 A16 arytm_3_th_56 sorry
                    show " ex tVar10 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar10 inTARSKIR2 C &  not r <ARYTM-3R4 tVar10"
                    proof(rule bexI[of _ "r0 *'ARYTM-3K11 t0"],rule conjMI)
                      show "r0 *'ARYTM-3K11 t0 inTARSKIR2 C"
                        using A5 A9 sorry
                      have "r <='ARYTM-3R3 r0 *'ARYTM-3K11 t0"
                        using A4 A10 arytm_3_th_82 sorry
                      thus " not r <ARYTM-3R4 r0 *'ARYTM-3K11 t0"
                        using A17 arytm_3_th_68 sorry
                    qed "sorry"
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            then have A18: "C inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
               sorry
            obtain r0 where
              [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A19: " not r0 inTARSKIR2 A"
              using arytm_2_lm_24 sorry
            obtain s0 where
              [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A20: " not s0 inTARSKIR2 B"
              using arytm_2_lm_24 sorry
            have "r0 *'ARYTM-3K11 s0 inTARSKIR2 C implies  False "
            proof(rule impI)
              assume "r0 *'ARYTM-3K11 s0 inTARSKIR2 C"
              then obtain r1 s1 where
                [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                A21: "r0 *'ARYTM-3K11 s0 =XBOOLE-0R4 r1 *'ARYTM-3K11 s1"and A22: "r1 inTARSKIR2 A & s1 inTARSKIR2 B"
                 sorry
              have "r0 <='ARYTM-3R3 r1 or s0 <='ARYTM-3R3 s1"
                using A21 arytm_3_th_83 sorry
              thus " False "
                using A19 A20 A22 arytm_2_lm_16 sorry
            qed
            then have "C <>HIDDENR2 RAT+ARYTM-3K5"
               sorry
            thus "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
              using A18 zfmisc_1_th_56 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem ARYTM_2K6_commutativity:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A *'ARYTM-2K6 B =HIDDENR1 B *'ARYTM-2K6 A"
proof-
  have " for it be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds it =HIDDENR1 A *'ARYTM-2K6 B implies it =HIDDENR1 B *'ARYTM-2K6 A"
  proof-
    have " for it be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds it =HIDDENR1 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } implies it =HIDDENR1 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
    proof-
      have " for D be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds D =XBOOLE-0R4 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B } implies D =HIDDENR1 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
      proof(rule ballI,rule ballI,rule ballI,rule impI)
        fix D assume [ty]: "D be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
        fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
        fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
        assume A23: "D =XBOOLE-0R4 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
        have " for e be objectHIDDENM1 holds e inHIDDENR3 D iff e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
        proof(rule ballI)
          fix e assume [ty]: "e be objectHIDDENM1"
          have "e inHIDDENR3 D iff ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 r *'ARYTM-3K11 s & r inTARSKIR2 A) & s inTARSKIR2 B)"
            using A23 sorry
          then have "e inHIDDENR3 D iff ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 r *'ARYTM-3K11 s & r inTARSKIR2 B) & s inTARSKIR2 A)"
             sorry
          thus "e inHIDDENR3 D iff e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
             sorry
        qed "sorry"
        thus "D =HIDDENR1 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 B & s inTARSKIR2 A }"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using arytm_2_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef arytm_2_def_8 (" _ +ARYTM-2K7  _ " [132,132]132 ) where
  mlet "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2", "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
"func x +ARYTM-2K7 y \<rightarrow> ElementSUBSET-1M1-of REAL+ARYTM-2K2 equals
  x if y =XBOOLE-0R4 {}ARYTM-3K12,
  y if x =XBOOLE-0R4 {}ARYTM-3K12 otherwise GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y)"
proof-
  (*coherence*)
    show "(y =XBOOLE-0R4 {}ARYTM-3K12 implies x be ElementSUBSET-1M1-of REAL+ARYTM-2K2) & ((x =XBOOLE-0R4 {}ARYTM-3K12 implies y be ElementSUBSET-1M1-of REAL+ARYTM-2K2) & ( not y =XBOOLE-0R4 {}ARYTM-3K12 &  not x =XBOOLE-0R4 {}ARYTM-3K12 implies GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y) be ElementSUBSET-1M1-of REAL+ARYTM-2K2))"
       sorry
  (*consistency*)
    show " for it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y =XBOOLE-0R4 {}ARYTM-3K12 & x =XBOOLE-0R4 {}ARYTM-3K12 implies (it =HIDDENR1 x iff it =HIDDENR1 y)"
       sorry
qed "sorry"

mtheorem ARYTM_2K7_commutativity:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =HIDDENR1 y +ARYTM-2K7 x"
proof-
  have " for it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds it =HIDDENR1 x +ARYTM-2K7 y implies it =HIDDENR1 y +ARYTM-2K7 x"
  proof-
    have " for it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (y =XBOOLE-0R4 {}ARYTM-3K12 implies it =HIDDENR1 x) & ((x =XBOOLE-0R4 {}ARYTM-3K12 implies it =HIDDENR1 y) & ( not y =XBOOLE-0R4 {}ARYTM-3K12 &  not x =XBOOLE-0R4 {}ARYTM-3K12 implies it =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y))) implies (x =XBOOLE-0R4 {}ARYTM-3K12 implies it =HIDDENR1 y) & ((y =XBOOLE-0R4 {}ARYTM-3K12 implies it =HIDDENR1 x) & ( not x =XBOOLE-0R4 {}ARYTM-3K12 &  not y =XBOOLE-0R4 {}ARYTM-3K12 implies it =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 x)))"
       sorry
    thus " ?thesis "
      using arytm_2_def_8 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef arytm_2_def_9 (" _ *''ARYTM-2K8  _ " [228,228]228 ) where
  mlet "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2", "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
"func x *'ARYTM-2K8 y \<rightarrow> ElementSUBSET-1M1-of REAL+ARYTM-2K2 equals
  GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y)"
proof-
  (*coherence*)
    show "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y) be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
       sorry
qed "sorry"

mtheorem ARYTM_2K8_commutativity:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y =HIDDENR1 y *'ARYTM-2K8 x"
proof-
  have " for it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds it =HIDDENR1 x *'ARYTM-2K8 y implies it =HIDDENR1 y *'ARYTM-2K8 x"
  proof-
    have " for it be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds it =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y) implies it =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 x)"
       sorry
    thus " ?thesis "
      using arytm_2_def_9 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_4:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 {}ARYTM-3K12 implies x *'ARYTM-2K8 y =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 {}ARYTM-3K12 implies x *'ARYTM-2K8 y =XBOOLE-0R4 {}ARYTM-3K12"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    let ?A = "DEDEKIND-CUTARYTM-2K3 x"
    let ?B = "DEDEKIND-CUTARYTM-2K3 y"
    assume A1: "x =XBOOLE-0R4 {}ARYTM-3K12"
    have " not ( ex e be objectHIDDENM1 st e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 ?A & s inTARSKIR2 ?B })"
    proof-
      have "( ex e be objectHIDDENM1 st e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 y }) implies  False "
      proof(rule impI)
        assume Given: " ex e be objectHIDDENM1 st e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 ?A & s inTARSKIR2 ?B }"
        then obtain e where
          [ty]:"e be objectHIDDENM1" and 
          A2: "e inHIDDENR3 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 ?A & s inTARSKIR2 ?B }"
           sorry
        have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 r *'ARYTM-3K11 s & r inTARSKIR2 ?A) & s inTARSKIR2 ?B"
          using A2 sorry
        thus " False "
          using A1 arytm_2_lm_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have "{r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 ?A & s inTARSKIR2 ?B } =XBOOLE-0R4 {}ARYTM-3K12"
      using xboole_0_def_1 sorry
    thus "x *'ARYTM-2K8 y =XBOOLE-0R4 {}ARYTM-3K12"
      using arytm_2_lm_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_5:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =XBOOLE-0R4 {}ARYTM-3K12 implies x =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =XBOOLE-0R4 {}ARYTM-3K12 implies x =XBOOLE-0R4 {}ARYTM-3K12"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x +ARYTM-2K7 y =XBOOLE-0R4 {}ARYTM-3K12"
    show "x =XBOOLE-0R4 {}ARYTM-3K12"
    proof-
      have cases: "y =XBOOLE-0R4 {}ARYTM-3K12 or y <>HIDDENR2 {}ARYTM-3K12"
         sorry
      have case1: "y =XBOOLE-0R4 {}ARYTM-3K12 implies x =XBOOLE-0R4 {}ARYTM-3K12"
      proof(rule impI)
        assume "y =XBOOLE-0R4 {}ARYTM-3K12"
        thus "x =XBOOLE-0R4 {}ARYTM-3K12"
          using A1 arytm_2_def_8 sorry
      qed
      have case2: "y <>HIDDENR2 {}ARYTM-3K12 implies (x <>HIDDENR2 {}ARYTM-3K12 implies  False )"
      proof(rule impI,rule impI)
        assume A2: "y <>HIDDENR2 {}ARYTM-3K12"
        then have "DEDEKIND-CUTARYTM-2K3 y <>HIDDENR2 {}ARYTM-3K12"
          using arytm_2_lm_10 sorry
        then obtain s0 where
          [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A3: "s0 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 y"
          using subset_1_th_4 sorry
        assume A4: "x <>HIDDENR2 {}ARYTM-3K12"
        then have "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 {}ARYTM-3K12"
          using arytm_2_lm_10 sorry
        then obtain r0 where
          [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A5: "r0 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x"
          using subset_1_th_4 sorry
        have A6: "r0 +ARYTM-3K10 s0 inTARSKIR2 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 y }"
          using A5 A3 sorry
        have "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y) =XBOOLE-0R4 {}ARYTM-3K12"
          using A1 A2 A4 arytm_2_def_8 sorry
        thus " False "
          using A6 arytm_2_lm_11 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_25:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A +ARYTM-2K5 (B +ARYTM-2K5 C) c=TARSKIR1 (A +ARYTM-2K5 B)+ARYTM-2K5 C"
proof(rule ballI,rule ballI,rule ballI)
  fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  fix C assume [ty]: "C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  have " for e be objectHIDDENM1 holds e inHIDDENR3 A +ARYTM-2K5 (B +ARYTM-2K5 C) implies e inHIDDENR3 (A +ARYTM-2K5 B)+ARYTM-2K5 C"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume "e inHIDDENR3 A +ARYTM-2K5 (B +ARYTM-2K5 C)"
    then obtain r0 s0 where
      [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A1: "e =HIDDENR1 r0 +ARYTM-3K10 s0 & r0 inTARSKIR2 A"and A2: "s0 inTARSKIR2 B +ARYTM-2K5 C"
       sorry
    obtain r1 s1 where
      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A3: "s0 =XBOOLE-0R4 r1 +ARYTM-3K10 s1 & r1 inTARSKIR2 B"and A4: "s1 inTARSKIR2 C"
      using A2 sorry
    have "e =HIDDENR1 (r0 +ARYTM-3K10 r1)+ARYTM-3K10 s1 & r0 +ARYTM-3K10 r1 inTARSKIR2 A +ARYTM-2K5 B"
      using A1 A3 arytm_3_th_51 sorry
    thus "e inHIDDENR3 (A +ARYTM-2K5 B)+ARYTM-2K5 C"
      using A4 sorry
  qed "sorry"
  thus "A +ARYTM-2K5 (B +ARYTM-2K5 C) c=TARSKIR1 (A +ARYTM-2K5 B)+ARYTM-2K5 C"
    using tarski_def_3 sorry
qed "sorry"

mlemma arytm_2_lm_26:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A +ARYTM-2K5 (B +ARYTM-2K5 C) =XBOOLE-0R4 (A +ARYTM-2K5 B)+ARYTM-2K5 C"
  using arytm_2_lm_25 sorry

mlemma arytm_2_lm_27:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A +ARYTM-2K5 B =XBOOLE-0R4 {}ARYTM-3K12 implies A =XBOOLE-0R4 {}ARYTM-3K12 or B =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A +ARYTM-2K5 B =XBOOLE-0R4 {}ARYTM-3K12 implies (A <>HIDDENR2 {}ARYTM-3K12 implies (B <>HIDDENR2 {}ARYTM-3K12 implies  False ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    assume A1: "A +ARYTM-2K5 B =XBOOLE-0R4 {}ARYTM-3K12"
    assume "A <>HIDDENR2 {}ARYTM-3K12"
    then obtain r0 where
      [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A2: "r0 inTARSKIR2 A"
      using subset_1_th_4 sorry
    assume "B <>HIDDENR2 {}ARYTM-3K12"
    then obtain s0 where
      [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A3: "s0 inTARSKIR2 B"
      using subset_1_th_4 sorry
    have "r0 +ARYTM-3K10 s0 inTARSKIR2 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & s inTARSKIR2 B }"
      using A2 A3 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_6:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 (y +ARYTM-2K7 z) =XBOOLE-0R4 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    show "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
    proof-
      have cases: "((x =XBOOLE-0R4 {}ARYTM-3K12 or y =XBOOLE-0R4 {}ARYTM-3K12) or z =XBOOLE-0R4 {}ARYTM-3K12) or x <>HIDDENR2 {}ARYTM-3K12 & (y <>HIDDENR2 {}ARYTM-3K12 & z <>HIDDENR2 {}ARYTM-3K12)"
         sorry
      have case1: "x =XBOOLE-0R4 {}ARYTM-3K12 implies x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
      proof(rule impI)
        assume A1: "x =XBOOLE-0R4 {}ARYTM-3K12"
        then have "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 y +ARYTM-2K7 z"
          using arytm_2_def_8 sorry
        also have "... = (x +ARYTM-2K7 y)+ARYTM-2K7 z"
          using A1 arytm_2_def_8 sorry
        finally show "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
           sorry
      qed
      have case2: "y =XBOOLE-0R4 {}ARYTM-3K12 implies x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
      proof(rule impI)
        assume A2: "y =XBOOLE-0R4 {}ARYTM-3K12"
        then have "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 x +ARYTM-2K7 z"
          using arytm_2_def_8 sorry
        also have "... = (x +ARYTM-2K7 y)+ARYTM-2K7 z"
          using A2 arytm_2_def_8 sorry
        finally show "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
           sorry
      qed
      have case3: "z =XBOOLE-0R4 {}ARYTM-3K12 implies x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
      proof(rule impI)
        assume A3: "z =XBOOLE-0R4 {}ARYTM-3K12"
        then have "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 x +ARYTM-2K7 y"
          using arytm_2_def_8 sorry
        also have "... = (x +ARYTM-2K7 y)+ARYTM-2K7 z"
          using A3 arytm_2_def_8 sorry
        finally show "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
           sorry
      qed
      have case4: "x <>HIDDENR2 {}ARYTM-3K12 & (y <>HIDDENR2 {}ARYTM-3K12 & z <>HIDDENR2 {}ARYTM-3K12) implies x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A4: "x <>HIDDENR2 {}ARYTM-3K12"
          and A5: "y <>HIDDENR2 {}ARYTM-3K12"
          and A6: "z <>HIDDENR2 {}ARYTM-3K12"
        have A7: "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z) =XBOOLE-0R4 {}ARYTM-3K12 implies  False "
        proof(rule impI)
          assume "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z) =XBOOLE-0R4 {}ARYTM-3K12"
          then have "DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z =XBOOLE-0R4 {}ARYTM-3K12"
            using arytm_2_lm_11 sorry
          then have "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {}ARYTM-3K12 or DEDEKIND-CUTARYTM-2K3 z =XBOOLE-0R4 {}ARYTM-3K12"
            using arytm_2_lm_27 sorry
          thus " False "
            using A5 A6 arytm_2_lm_10 sorry
        qed
        have A8: "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y) =XBOOLE-0R4 {}ARYTM-3K12 implies  False "
        proof(rule impI)
          assume "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y) =XBOOLE-0R4 {}ARYTM-3K12"
          then have "DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {}ARYTM-3K12"
            using arytm_2_lm_11 sorry
          then have "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12 or DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {}ARYTM-3K12"
            using arytm_2_lm_27 sorry
          thus " False "
            using A4 A5 arytm_2_lm_10 sorry
        qed
        have "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 x +ARYTM-2K7 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z)"
          using A5 A6 arytm_2_def_8 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z)))"
          using A4 A7 arytm_2_def_8 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z))"
          using arytm_2_lm_12 sorry
        also have "... = GLUEDARYTM-2K4 ((DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y)+ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z)"
          using arytm_2_lm_26 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y)) +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z)"
          using arytm_2_lm_12 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y) +ARYTM-2K7 z"
          using A6 A8 arytm_2_def_8 sorry
        also have "... = (x +ARYTM-2K7 y)+ARYTM-2K7 z"
          using A4 A5 arytm_2_def_8 sorry
        finally show "x +ARYTM-2K7 (y +ARYTM-2K7 z) =HIDDENR1 (x +ARYTM-2K7 y)+ARYTM-2K7 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_7:
"{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } be c=-linearORDINAL1V6"
proof-
  have "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) } be c=-linearORDINAL1V6"
  proof-
    let ?IR = "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
    have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } implies (y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } implies (x,y)are-c=-comparableXBOOLE-0R3)"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      fix y assume [ty]: "y be setHIDDENM2"
      assume "x inTARSKIR2 ?IR"
      then have A1: " ex A9 be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 A9 & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A9 implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A9) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A9 & r <ARYTM-3R4 s))"
         sorry
      assume "y inTARSKIR2 ?IR"
      then have A2: " ex B9 be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st y =XBOOLE-0R4 B9 & ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B9 implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B9) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B9 & r <ARYTM-3R4 s))"
         sorry
      have " not x c=TARSKIR1 y implies y c=TARSKIR1 x"
      proof(rule impI)
        assume " not x c=TARSKIR1 y"
        then obtain s where
          [ty]:"s be objectHIDDENM1" and 
          A3: "s inHIDDENR3 x"and A4: " not s inHIDDENR3 y"
           sorry
        have 
          [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
          using A1 A3 sorry
        have " for e be objectHIDDENM1 holds e inHIDDENR3 y implies e inHIDDENR3 x"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume A5: "e inHIDDENR3 y"
          then obtain r where 
            [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and rDef:"r = e"
            using A2 sorry
          have "r <='ARYTM-3R3 s"
            using A2 A4 A5 sorry
          thus "e inHIDDENR3 x"
            using A1 A3 sorry
        qed "sorry"
        thus "y c=TARSKIR1 x"
          using tarski_def_3 sorry
      qed
      thus "(x,y)are-c=-comparableXBOOLE-0R3"
        using xboole_0_def_9 sorry
    qed "sorry"
    thus "{A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) } be c=-linearORDINAL1V6"
      using ordinal1_def_8 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_28:
" for e be setHIDDENM2 holds e inTARSKIR2 REAL+ARYTM-2K2 implies e <>HIDDENR2 RAT+ARYTM-3K5"
proof-
  have " for e be setHIDDENM2 holds e inTARSKIR2 REAL+ARYTM-2K2 implies  not e <>HIDDENR2 RAT+ARYTM-3K5"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be setHIDDENM2"
    assume "e inTARSKIR2 REAL+ARYTM-2K2"
    then have "e inTARSKIR2 RAT+ARYTM-3K5 or e inTARSKIR2 DEDEKIND-CUTSARYTM-2K1"
      using xboole_0_def_3 sorry
    thus " not e <>HIDDENR2 RAT+ARYTM-3K5"
      using zfmisc_1_th_56 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_29:
" for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds (B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } & r inTARSKIR2 B) & s <='ARYTM-3R3 r implies s inTARSKIR2 B"
proof-
  have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for B be setHIDDENM2 holds B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } & (r inTARSKIR2 B & s <='ARYTM-3R3 r) implies s inTARSKIR2 B"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
      and A2: "r inTARSKIR2 B & s <='ARYTM-3R3 r"
    have " ex A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 st B =XBOOLE-0R4 A & ( for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & t <ARYTM-3R4 s))"
      using A1 sorry
    thus "s inTARSKIR2 B"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_30:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <ARYTM-2R2 x implies ( ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z inTARSKIR2 RAT+ARYTM-3K5 & z <ARYTM-2R2 x) & y <ARYTM-2R2 z)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y <ARYTM-2R2 x implies ( ex tVar11 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (tVar11 inTARSKIR2 RAT+ARYTM-3K5 &  not tVar11 <ARYTM-2R2 x) &  not y <ARYTM-2R2 tVar11)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "y <ARYTM-2R2 x"
    show " ex tVar11 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (tVar11 inTARSKIR2 RAT+ARYTM-3K5 &  not tVar11 <ARYTM-2R2 x) &  not y <ARYTM-2R2 tVar11"
    proof-
      have cases: "((x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 or  not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5) or x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5) or  not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5"
         sorry
      have case1: "x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex tVar11 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (tVar11 inTARSKIR2 RAT+ARYTM-3K5 &  not tVar11 <ARYTM-2R2 x) &  not y <ARYTM-2R2 tVar11)"
      proof(rule impI)
        assume "x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5"
        then obtain x9 y9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x" and
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
           sorry
        have "y9 <ARYTM-3R4 x9"
          using A1 arytm_2_lm_14 sorry
        then obtain z9 where
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A2: "y9 <ARYTM-3R4 z9 & z9 <ARYTM-3R4 x9"
          using arytm_3_th_93 sorry
        obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = z9"
          using arytm_2_th_1 sorry
        show " ex tVar11 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (tVar11 inTARSKIR2 RAT+ARYTM-3K5 &  not tVar11 <ARYTM-2R2 x) &  not y <ARYTM-2R2 tVar11"
        proof(rule bexI[of _ "z"])
          show "(z inTARSKIR2 RAT+ARYTM-3K5 &  not z <ARYTM-2R2 x) &  not y <ARYTM-2R2 z"
            using A2 arytm_2_lm_14 sorry
        qed "sorry"
      qed
      have case2: " not x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex tVar12 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar12 inTARSKIR2 RAT+ARYTM-3K5 & (tVar12 <ARYTM-2R2 x &  not y <ARYTM-2R2 tVar12))"
      proof(rule impMI ,rule impI)
        assume A3: " not x inTARSKIR2 RAT+ARYTM-3K5"
          and A4: "y inTARSKIR2 RAT+ARYTM-3K5"
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
          using A4 sorry
        have "x inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A3 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A5: "x =XBOOLE-0R4 A"and A6: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
           sorry
        have "y9 inTARSKIR2 x"
          using A1 A3 arytm_2_def_5 sorry
        then obtain s where
          [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A7: "s inTARSKIR2 A"and A8: "y9 <ARYTM-3R4 s"
          using A5 A6 sorry
        obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = s"
          using arytm_2_th_1 sorry
        show " ex tVar12 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar12 inTARSKIR2 RAT+ARYTM-3K5 & (tVar12 <ARYTM-2R2 x &  not y <ARYTM-2R2 tVar12)"
        proof(rule bexI[of _ "z"],rule conjMI,rule conjMI)
          show "z inTARSKIR2 RAT+ARYTM-3K5"
             sorry
          show "z <ARYTM-2R2 x"
            using A3 A5 A7 arytm_2_def_5 sorry
          show " not y <ARYTM-2R2 z"
            using A8 arytm_2_lm_14 sorry
        qed "sorry"
      qed
      have case3: "x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex tVar13 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar13 inTARSKIR2 RAT+ARYTM-3K5 & (tVar13 <ARYTM-2R2 x &  not y <ARYTM-2R2 tVar13))"
      proof(rule impMI ,rule impI)
        assume A9: "x inTARSKIR2 RAT+ARYTM-3K5"
          and A10: " not y inTARSKIR2 RAT+ARYTM-3K5"
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
          using A9 sorry
        have A11: " not x9 inTARSKIR2 y"
          using A1 A10 arytm_2_def_5 sorry
        have "y inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A10 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A12: "y =XBOOLE-0R4 B"and A13: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
           sorry
        have "B <>HIDDENR2 {}ARYTM-3K12"
          using A10 A12 sorry
        then obtain y1 where
          [ty]:"y1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A14: "y1 inTARSKIR2 B"
          using subset_1_th_4 sorry
        have "{}ARYTM-3K12 <='ARYTM-3R3 y1"
          using arytm_3_th_64 sorry
        then have A15: "x9 <>HIDDENR2 {}ARYTM-3K12"
          using A12 A13 A11 A14 sorry
        have " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 <ARYTM-3R4 x9 &  not z9 inTARSKIR2 y"
        proof-
          have " not ( ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 <ARYTM-3R4 x9 &  not z9 inTARSKIR2 y) implies  False "
          proof(rule impI)
            let ?C = "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 x9 }"
            assume A16: " not ( ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 <ARYTM-3R4 x9 &  not z9 inTARSKIR2 y)"
            have "y =XBOOLE-0R4 ?C"
            proof-
              have "y =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 }"
              proof-
                have "y c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 x9 } & {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 } c=TARSKIR1 y"
                proof(rule conjMI)
                  show "y c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 x9 }"
                  proof-
                    have "y c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 }"
                    proof-
                      have " for e be objectHIDDENM1 holds e inHIDDENR3 y implies e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 }"
                      proof(rule ballI,rule impI)
                        fix e assume [ty]: "e be objectHIDDENM1"
                        assume A17: "e inHIDDENR3 y"
                        then obtain z9 where 
                          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and z9Def:"z9 = e"
                          using A12 sorry
                        have " not x9 <='ARYTM-3R3 z9"
                          using A12 A13 A11 A17 sorry
                        thus "e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 }"
                           sorry
                      qed "sorry"
                      thus "y c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 }"
                        using tarski_def_3 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  have " for e be objectHIDDENM1 holds e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 x9 } implies e inHIDDENR3 y"
                  proof(rule ballI,rule impI)
                    fix e assume [ty]: "e be objectHIDDENM1"
                    assume "e inHIDDENR3 ?C"
                    then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st e =HIDDENR1 s & s <ARYTM-3R4 x9"
                       sorry
                    thus "e inHIDDENR3 y"
                      using A16 sorry
                  qed "sorry"
                  thus "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 } c=TARSKIR1 y"
                    using tarski_def_3 sorry
                qed
                thus "y =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 x9 }"
                  using xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then have "y inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
              using A15 sorry
            thus " False "
              using xboole_0_def_5 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain z9 where
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A18: "z9 <ARYTM-3R4 x9"and A19: " not z9 inTARSKIR2 y"
           sorry
        obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = z9"
          using arytm_2_th_1 sorry
        show " ex tVar13 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar13 inTARSKIR2 RAT+ARYTM-3K5 & (tVar13 <ARYTM-2R2 x &  not y <ARYTM-2R2 tVar13)"
        proof(rule bexI[of _ "z"],rule conjMI,rule conjMI)
          show "z inTARSKIR2 RAT+ARYTM-3K5"
             sorry
          show "z <ARYTM-2R2 x"
            using A18 arytm_2_lm_14 sorry
          show " not y <ARYTM-2R2 z"
            using A10 A19 arytm_2_def_5 sorry
        qed "sorry"
      qed
      have case4: " not x inTARSKIR2 RAT+ARYTM-3K5 &  not y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex tVar14 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar14 inTARSKIR2 RAT+ARYTM-3K5 & (tVar14 <ARYTM-2R2 x &  not y <ARYTM-2R2 tVar14))"
      proof(rule impMI ,rule impI)
        assume A20: " not x inTARSKIR2 RAT+ARYTM-3K5"
          and A21: " not y inTARSKIR2 RAT+ARYTM-3K5"
        have "y inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A21 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A22: "y =XBOOLE-0R4 B"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
           sorry
        have "x inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A20 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A23: "x =XBOOLE-0R4 A"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
           sorry
        have " not x c=TARSKIR1 y"
          using A1 A20 A21 arytm_2_def_5 sorry
        then obtain z9 where
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A24: "z9 inTARSKIR2 A"and A25: " not z9 inTARSKIR2 B"
          using A23 A22 sorry
        obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = z9"
          using arytm_2_th_1 sorry
        show " ex tVar14 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st tVar14 inTARSKIR2 RAT+ARYTM-3K5 & (tVar14 <ARYTM-2R2 x &  not y <ARYTM-2R2 tVar14)"
        proof(rule bexI[of _ "z"],rule conjMI,rule conjMI)
          show "z inTARSKIR2 RAT+ARYTM-3K5"
             sorry
          show "z <ARYTM-2R2 x"
            using A20 A23 A24 arytm_2_def_5 sorry
          show " not y <ARYTM-2R2 z"
            using A21 A22 A25 arytm_2_def_5 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_31:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y <='ARYTM-2R1 z implies x <='ARYTM-2R1 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y & y <='ARYTM-2R1 z implies x <='ARYTM-2R1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
      and A2: "y <='ARYTM-2R1 z"
    show "x <='ARYTM-2R1 z"
    proof-
      have cases: "((((((x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5) or x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5)) or x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5)) or x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5)) or  not x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5)) or  not x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5)) or  not x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5)) or  not x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5)"
         sorry
      have case1: "x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A3: "x inTARSKIR2 RAT+ARYTM-3K5"
          and A4: "y inTARSKIR2 RAT+ARYTM-3K5"
          and A5: "z inTARSKIR2 RAT+ARYTM-3K5"
        obtain z9 where 
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and z9Def:"z9 = z"
          using A5 sorry
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
          using A4 sorry
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
          using A3 sorry
        have "x9 <='ARYTM-3R3 y9 & y9 <='ARYTM-3R3 z9"
          using A1 A2 arytm_2_lm_14 sorry
        then have "x9 <='ARYTM-3R3 z9"
          using arytm_3_th_67 sorry
        thus "x <='ARYTM-2R1 z"
          using arytm_2_lm_14 sorry
      qed
      have case2: "x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A6: "x inTARSKIR2 RAT+ARYTM-3K5"
          and A7: "y inTARSKIR2 RAT+ARYTM-3K5"
          and A8: " not z inTARSKIR2 RAT+ARYTM-3K5"
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
          using A7 sorry
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
          using A6 sorry
        have A9: "x9 <='ARYTM-3R3 y9"
          using A1 arytm_2_lm_14 sorry
        have "z inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "z inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A8 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain C where
          [ty]:"C be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A10: "z =XBOOLE-0R4 C"and A11: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 C & r <ARYTM-3R4 s)"
           sorry
        have "y inTARSKIR2 C"
          using A2 A7 A8 A10 arytm_2_def_5 sorry
        then have "x9 inTARSKIR2 C"
          using A11 A9 sorry
        thus "x <='ARYTM-2R1 z"
          using A8 A10 arytm_2_def_5 sorry
      qed
      have case3: "x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A12: "x inTARSKIR2 RAT+ARYTM-3K5"
          and A13: " not y inTARSKIR2 RAT+ARYTM-3K5"
          and A14: "z inTARSKIR2 RAT+ARYTM-3K5"
        obtain z9 where 
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and z9Def:"z9 = z"
          using A14 sorry
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
          using A12 sorry
        have "y inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A13 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A15: "y =XBOOLE-0R4 B"and A16: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
           sorry
        have "x9 inTARSKIR2 B &  not z9 inTARSKIR2 B"
          using A1 A2 A13 A15 arytm_2_def_5 sorry
        then have "x9 <='ARYTM-3R3 z9"
          using A16 sorry
        thus "x <='ARYTM-2R1 z"
          using arytm_2_lm_14 sorry
      qed
      have case4: "x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A17: "x inTARSKIR2 RAT+ARYTM-3K5"
          and A18: " not y inTARSKIR2 RAT+ARYTM-3K5"
          and A19: " not z inTARSKIR2 RAT+ARYTM-3K5"
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
          using A17 sorry
        have "y inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A18 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A20: "y =XBOOLE-0R4 B"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
           sorry
        have A21: "x9 inTARSKIR2 B"
          using A1 A18 A20 arytm_2_def_5 sorry
        have "z inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "z inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A19 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain C where
          [ty]:"C be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A22: "z =XBOOLE-0R4 C"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 C & r <ARYTM-3R4 s)"
           sorry
        have "B c=TARSKIR1 C"
          using A2 A18 A19 A20 A22 arytm_2_def_5 sorry
        thus "x <='ARYTM-2R1 z"
          using A19 A22 A21 arytm_2_def_5 sorry
      qed
      have case5: " not x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A23: " not x inTARSKIR2 RAT+ARYTM-3K5"
          and A24: "y inTARSKIR2 RAT+ARYTM-3K5"
          and A25: "z inTARSKIR2 RAT+ARYTM-3K5"
        obtain z9 where 
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and z9Def:"z9 = z"
          using A25 sorry
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
          using A24 sorry
        have A26: "y9 <='ARYTM-3R3 z9"
          using A2 arytm_2_lm_14 sorry
        have "x inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A23 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A27: "x =XBOOLE-0R4 A"and A28: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
           sorry
        have " not y9 inTARSKIR2 A"
          using A1 A23 A27 arytm_2_def_5 sorry
        then have " not z9 inTARSKIR2 A"
          using A28 A26 sorry
        thus "x <='ARYTM-2R1 z"
          using A23 A27 arytm_2_def_5 sorry
      qed
      have case6: " not x inTARSKIR2 RAT+ARYTM-3K5 & (y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A29: " not x inTARSKIR2 RAT+ARYTM-3K5"
          and A30: "y inTARSKIR2 RAT+ARYTM-3K5"
          and A31: " not z inTARSKIR2 RAT+ARYTM-3K5"
        have "x inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A29 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A32: "x =XBOOLE-0R4 A"and A33: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
           sorry
        have A34: " not y inTARSKIR2 A"
          using A1 A29 A32 arytm_2_def_5 sorry
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
          using A30 sorry
        have "z inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "z inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A31 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain C where
          [ty]:"C be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A35: "z =XBOOLE-0R4 C"and A36: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 C & r <ARYTM-3R4 s)"
           sorry
        have A37: "y inTARSKIR2 C"
          using A2 A30 A31 A35 arytm_2_def_5 sorry
        have "A c=TARSKIR1 C"
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 A implies e inHIDDENR3 C"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume A38: "e inHIDDENR3 A"
            then obtain x9 where 
              [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = e"
               sorry
            have "x9 <='ARYTM-3R3 y9"
              using A33 A34 A38 sorry
            thus "e inHIDDENR3 C"
              using A36 A37 sorry
          qed "sorry"
          thus "A c=TARSKIR1 C"
            using tarski_def_3 sorry
        qed
        thus "x <='ARYTM-2R1 z"
          using A29 A31 A32 A35 arytm_2_def_5 sorry
      qed
      have case7: " not x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 & z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A39: " not x inTARSKIR2 RAT+ARYTM-3K5"
          and A40: " not y inTARSKIR2 RAT+ARYTM-3K5"
          and A41: "z inTARSKIR2 RAT+ARYTM-3K5"
        obtain z9 where 
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and z9Def:"z9 = z"
          using A41 sorry
        have "x inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A39 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A42: "x =XBOOLE-0R4 A"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
           sorry
        have "y inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A40 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A43: "y =XBOOLE-0R4 B"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
           sorry
        have "A c=TARSKIR1 B"
          using A1 A39 A40 A42 A43 arytm_2_def_5 sorry
        then have " not z9 inTARSKIR2 A"
          using A2 A40 A43 arytm_2_def_5 sorry
        thus "x <='ARYTM-2R1 z"
          using A39 A42 arytm_2_def_5 sorry
      qed
      have case8: " not x inTARSKIR2 RAT+ARYTM-3K5 & ( not y inTARSKIR2 RAT+ARYTM-3K5 &  not z inTARSKIR2 RAT+ARYTM-3K5) implies x <='ARYTM-2R1 z"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A44: " not x inTARSKIR2 RAT+ARYTM-3K5"
          and A45: " not y inTARSKIR2 RAT+ARYTM-3K5"
          and A46: " not z inTARSKIR2 RAT+ARYTM-3K5"
        have "z inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "z inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A46 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain C where
          [ty]:"C be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A47: "z =XBOOLE-0R4 C"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 C implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 C) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 C & r <ARYTM-3R4 s)"
           sorry
        have "y inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A45 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain B where
          [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A48: "y =XBOOLE-0R4 B"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
           sorry
        have A49: "B c=TARSKIR1 C"
          using A2 A45 A46 A48 A47 arytm_2_def_5 sorry
        have "x inTARSKIR2 REAL+ARYTM-2K2"
           sorry
        then have "x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using A44 arytm_2_lm_3 xboole_0_def_3 sorry
        then obtain A where
          [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
          A50: "x =XBOOLE-0R4 A"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
           sorry
        have "A c=TARSKIR1 B"
          using A1 A44 A45 A50 A48 arytm_2_def_5 sorry
        then have "A c=TARSKIR1 C"
          using A49 sorry
        thus "x <='ARYTM-2R1 z"
          using A44 A46 A50 A47 arytm_2_def_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 case7 case8 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_8:
" for X be SubsetSUBSET-1M2-of REAL+ARYTM-2K2 holds  for Y be SubsetSUBSET-1M2-of REAL+ARYTM-2K2 holds ( ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x inTARSKIR2 Y) & ( for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 y) implies ( ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 z & z <='ARYTM-2R1 y)"
proof-
  have " for X be SubsetSUBSET-1M2-of REAL+ARYTM-2K2 holds  for Y be SubsetSUBSET-1M2-of REAL+ARYTM-2K2 holds ( ex x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x1 inTARSKIR2 Y) implies (( for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 y) implies ( ex tVar15 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 tVar15 & (y <ARYTM-2R2 tVar15 implies  False )))"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REAL+ARYTM-2K2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REAL+ARYTM-2K2"
    assume Given: " ex x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x1 inTARSKIR2 Y"
    then obtain x1 where
      [ty]:"x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A1: "x1 inTARSKIR2 Y"
       sorry
    let ?Z = "{z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x }"
    assume A2: " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 y"
    show " ex tVar15 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 tVar15 & (y <ARYTM-2R2 tVar15 implies  False )"
    proof-
      have cases: "( ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z iff x9 <ARYTM-3R4 z9) or  not ( ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z iff x9 <ARYTM-3R4 z9)"
         sorry
      have case1: "( ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 {z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x } iff x9 <ARYTM-3R4 z9) implies ( ex tVar15 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 tVar15 & (y <ARYTM-2R2 tVar15 implies  False ))"
      proof(rule impI)
        assume " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z iff x9 <ARYTM-3R4 z9"
        then obtain z9 where
          [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A3: " for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z iff x9 <ARYTM-3R4 z9"
           sorry
        obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = z9"
          using arytm_2_th_1 sorry
        show " ex tVar15 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies x <='ARYTM-2R1 tVar15 & (y <ARYTM-2R2 tVar15 implies  False )"
        proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
          assume A4: "x inTARSKIR2 X"
            and A5: "y inTARSKIR2 Y"
          show "x <='ARYTM-2R1 z"
          proof-
            have "z <ARYTM-2R2 x implies  False "
            proof(rule impI)
              assume "z <ARYTM-2R2 x"
              then obtain x0 where
                [ty]:"x0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A6: "x0 inTARSKIR2 RAT+ARYTM-3K5"and A7: "x0 <ARYTM-2R2 x & z <ARYTM-2R2 x0"
                using arytm_2_lm_30 sorry
              obtain x9 where 
                [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x0"
                using A6 sorry
              have "z9 <ARYTM-3R4 x9 & x9 inTARSKIR2 ?Z"
                using A4 A7 arytm_2_lm_14 sorry
              thus " False "
                using A3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          assume "y <ARYTM-2R2 z"
          then obtain y0 where
            [ty]:"y0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
            A8: "y0 inTARSKIR2 RAT+ARYTM-3K5"and A9: "y0 <ARYTM-2R2 z"and A10: "y <ARYTM-2R2 y0"
            using arytm_2_lm_30 sorry
          obtain y9 where 
            [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y0"
            using A8 sorry
          have "y9 <ARYTM-3R4 z9"
            using A9 arytm_2_lm_14 sorry
          then have "y9 inTARSKIR2 ?Z"
            using A3 sorry
          then have " ex y99 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st y9 =XBOOLE-0R4 y99 & ( ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 y99 & x inTARSKIR2 X) & z <ARYTM-2R2 x)"
             sorry
          then obtain x1 y1 where
            [ty]:"x1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
            A11: "y1 =XBOOLE-0R4 y9"and A12: "x1 inTARSKIR2 X"and A13: "y1 <ARYTM-2R2 x1"
             sorry
          have "y <ARYTM-2R2 x1"
            using A10 A11 A13 arytm_2_lm_31 sorry
          thus " False "
            using A2 A5 A12 sorry
        qed "sorry"
      qed
      have case2: " not ( ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z iff x9 <ARYTM-3R4 z9) implies ( ex tVar17 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies (tVar17 <ARYTM-2R2 x implies  False ) & (y <ARYTM-2R2 tVar17 implies  False ))"
      proof(rule impI)
        assume A14: " not ( ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z iff x9 <ARYTM-3R4 z9)"
        have A15: "{z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x } inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } implies  False "
        proof(rule impI)
          assume "?Z inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
          then obtain t where
            [ty]:"t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A16: "?Z =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t }"and "t <>HIDDENR2 {}ARYTM-3K12"
             sorry
          have " for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z iff x9 <ARYTM-3R4 t"
          proof-
            have " for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds (x9 inTARSKIR2 {z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x } implies x9 <ARYTM-3R4 t) &  not ( not x9 <ARYTM-3R4 t &  not x9 inTARSKIR2 {z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((z =XBOOLE-0R4 z9 & x inTARSKIR2 X) &  not z <ARYTM-2R2 x)) })"
            proof(rule ballI,rule conjMI)
              fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
              show "x9 inTARSKIR2 {z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x } implies x9 <ARYTM-3R4 t"
              proof(rule impI)
                assume "x9 inTARSKIR2 ?Z"
                then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 x9 & s <ARYTM-3R4 t"
                  using A16 sorry
                thus "x9 <ARYTM-3R4 t"
                   sorry
              qed
              show " not ( not x9 <ARYTM-3R4 t &  not x9 inTARSKIR2 {z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((z =XBOOLE-0R4 z9 & x inTARSKIR2 X) &  not z <ARYTM-2R2 x)) })"
                using A16 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " False "
            using A14 sorry
        qed
        have A17: "?Z c=TARSKIR1 RAT+ARYTM-3K5"
        proof-
          have "{z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((z =XBOOLE-0R4 z9 & x inTARSKIR2 X) &  not z <ARYTM-2R2 x)) } c=TARSKIR1 RAT+ARYTM-3K5"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 {z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x } implies e inHIDDENR3 RAT+ARYTM-3K5"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ?Z"
              then have " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st e =HIDDENR1 z9 & ( ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x)"
                 sorry
              thus "e inHIDDENR3 RAT+ARYTM-3K5"
                 sorry
            qed "sorry"
            thus "{z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((z =XBOOLE-0R4 z9 & x inTARSKIR2 X) &  not z <ARYTM-2R2 x)) } c=TARSKIR1 RAT+ARYTM-3K5"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "{z9 where z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x } =XBOOLE-0R4 {}ARYTM-3K12 implies  False "
        proof(rule impI)
          assume "?Z =XBOOLE-0R4 {}ARYTM-3K12"
          then have A18: " for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 inTARSKIR2 ?Z implies x9 <ARYTM-3R4 {}ARYTM-3K12"
             sorry
          have " for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds x9 <ARYTM-3R4 {}ARYTM-3K12 implies x9 inTARSKIR2 ?Z"
            using arytm_3_th_64 sorry
          thus " False "
            using A14 A18 sorry
        qed
        then obtain Z where 
          [ty]:"Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and ZDef:"Z = ?Z"
          using A17 sorry
        have A19: "Z =XBOOLE-0R4 RAT+ARYTM-3K5 implies  False "
        proof(rule impI)
          assume A20: "Z =XBOOLE-0R4 RAT+ARYTM-3K5"
          show " False "
          proof-
            have cases: "x1 inTARSKIR2 RAT+ARYTM-3K5 or  not x1 inTARSKIR2 RAT+ARYTM-3K5"
               sorry
            have case1: "x1 inTARSKIR2 RAT+ARYTM-3K5 implies  False "
            proof(rule impI)
              assume "x1 inTARSKIR2 RAT+ARYTM-3K5"
              then obtain x9 where 
                [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x1"
                 sorry
              have "x9 inTARSKIR2 Z"
                using A20 sorry
              then have " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x9 =XBOOLE-0R4 z9 & ( ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x)"
                 sorry
              thus " False "
                using A1 A2 sorry
            qed
            have case2: " not x1 inTARSKIR2 RAT+ARYTM-3K5 implies  False "
            proof(rule impI)
              assume A21: " not x1 inTARSKIR2 RAT+ARYTM-3K5"
              have "x1 inTARSKIR2 REAL+ARYTM-2K2"
                 sorry
              then have "x1 inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
                using A21 arytm_2_lm_3 xboole_0_def_3 sorry
              then obtain A where
                [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
                A22: "x1 =XBOOLE-0R4 A"and " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
                 sorry
              have "x1 <>HIDDENR2 RAT+ARYTM-3K5"
                using arytm_2_lm_28 sorry
              then obtain x9 where
                [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                A23: " not x9 inTARSKIR2 A"
                using A22 subset_1_th_28 sorry
              obtain x2 where 
                [ty]:"x2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and x2Def:"x2 = x9"
                using arytm_2_th_1 sorry
              have "x2 inTARSKIR2 Z"
                using A20 sorry
              then have " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x9 =XBOOLE-0R4 z9 & ( ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x)"
                 sorry
              then obtain x where
                [ty]:"x be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
                A24: "x inTARSKIR2 X"and A25: "x2 <ARYTM-2R2 x"
                 sorry
              have "x1 <ARYTM-2R2 x2"
                using A21 A22 A23 arytm_2_def_5 sorry
              then have "x1 <ARYTM-2R2 x"
                using A25 arytm_2_lm_31 sorry
              thus " False "
                using A1 A2 A24 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have " for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 Z implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 Z) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 Z & t <ARYTM-3R4 s)"
        proof-
          have " for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 Z implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 Z) & ( ex tVar16 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar16 inTARSKIR2 Z &  not t <ARYTM-3R4 tVar16)"
          proof(rule ballI,rule impI,rule conjMI)
            fix t assume [ty]: "t be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
            obtain y0 where 
              [ty]:"y0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and y0Def:"y0 = t"
              using arytm_2_th_1 sorry
            assume "t inTARSKIR2 Z"
            then have " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 t & ( ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x)"
               sorry
            then obtain x0 where
              [ty]:"x0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A26: "x0 inTARSKIR2 X"and A27: "y0 <ARYTM-2R2 x0"
               sorry
            show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 Z"
            proof(rule ballI,rule impI)
              fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
              obtain z where 
                [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = s"
                using arytm_2_th_1 sorry
              assume "s <='ARYTM-3R3 t"
              then have "z <='ARYTM-2R1 y0"
                using arytm_2_lm_14 sorry
              then have "z <ARYTM-2R2 x0"
                using A27 arytm_2_lm_31 sorry
              thus "s inTARSKIR2 Z"
                using A26 sorry
            qed "sorry"
            obtain z where
              [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A28: "z inTARSKIR2 RAT+ARYTM-3K5"and A29: "z <ARYTM-2R2 x0"and A30: "y0 <ARYTM-2R2 z"
              using A27 arytm_2_lm_30 sorry
            obtain z9 where 
              [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and z9Def:"z9 = z"
              using A28 sorry
            show " ex tVar16 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar16 inTARSKIR2 Z &  not t <ARYTM-3R4 tVar16"
            proof(rule bexI[of _ "z9"],rule conjMI)
              show "z9 inTARSKIR2 Z"
                using A26 A29 sorry
              show " not t <ARYTM-3R4 z9"
                using A30 arytm_2_lm_14 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have "Z inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
           sorry
        then have A31: "Z inTARSKIR2 ({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })\\SUBSET-1K6 {TARSKIK1 RAT+ARYTM-3K5 }"
          using A19 zfmisc_1_th_56 sorry
        then have "Z inTARSKIR2 (({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) })\\SUBSET-1K6 {TARSKIK1 RAT+ARYTM-3K5 })\\SUBSET-1K7\<^bsub>({A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 A &  not (( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s <='ARYTM-3R3 r &  not s inTARSKIR2 A)) &  not ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (s inTARSKIR2 A &  not r <ARYTM-3R4 s)))) })\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 })"
          using A15 xboole_0_def_5 sorry
        then obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = Z"
          using arytm_2_lm_4 sorry
        show " ex tVar17 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies (tVar17 <ARYTM-2R2 x implies  False ) & (y <ARYTM-2R2 tVar17 implies  False )"
        proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
          assume A32: "x inTARSKIR2 X"
            and A33: "y inTARSKIR2 Y"
          have A34: "z inTARSKIR2 RAT+ARYTM-3K5 implies  False "
          proof(rule impI)
            assume "z inTARSKIR2 RAT+ARYTM-3K5"
            then have "z inTARSKIR2 {TARSKIK1 {}ARYTM-3K12 }"
              using A31 arytm_2_lm_9 xboole_0_def_4 sorry
            thus " False "
              using tarski_def_1 sorry
          qed
          show "z <ARYTM-2R2 x implies  False "
          proof(rule impI)
            assume "z <ARYTM-2R2 x"
            then obtain x0 where
              [ty]:"x0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
              A35: "x0 inTARSKIR2 RAT+ARYTM-3K5"and A36: "x0 <ARYTM-2R2 x"and A37: "z <ARYTM-2R2 x0"
              using arytm_2_lm_30 sorry
            obtain x9 where 
              [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x0"
              using A35 sorry
            have "x9 inTARSKIR2 z"
              using A32 A36 sorry
            thus " False "
              using A34 A37 arytm_2_def_5 sorry
          qed
          assume "y <ARYTM-2R2 z"
          then obtain y0 where
            [ty]:"y0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
            A38: "y0 inTARSKIR2 RAT+ARYTM-3K5"and A39: "y0 <ARYTM-2R2 z"and A40: "y <ARYTM-2R2 y0"
            using arytm_2_lm_30 sorry
          obtain y9 where 
            [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y0"
            using A38 sorry
          have "y9 inTARSKIR2 z"
            using A34 A39 arytm_2_def_5 sorry
          then have " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st y9 =XBOOLE-0R4 z9 & ( ex x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (z =XBOOLE-0R4 z9 & x inTARSKIR2 X) & z <ARYTM-2R2 x)"
             sorry
          then obtain x0 where
            [ty]:"x0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
            A41: "x0 inTARSKIR2 X"and A42: "y0 <ARYTM-2R2 x0"
             sorry
          have "y <ARYTM-2R2 x0"
            using A40 A42 arytm_2_lm_31 sorry
          thus " False "
            using A2 A33 A41 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_32:
"oneARYTM-3K13 =XBOOLE-0R4 \<one>\<^sub>M"
   sorry

mlemma arytm_2_lm_33:
"{}ARYTM-3K12 =XBOOLE-0R4 {}ARYTM-3K12"
   sorry

mlemma arytm_2_lm_34:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A +ARYTM-2K5 B =XBOOLE-0R4 A & A <>HIDDENR2 {}ARYTM-3K12 implies B =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A +ARYTM-2K5 B =XBOOLE-0R4 A & (A <>HIDDENR2 {}ARYTM-3K12 & B <>HIDDENR2 {}ARYTM-3K12) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    assume A1: "A +ARYTM-2K5 B =XBOOLE-0R4 A"
      and A2: "A <>HIDDENR2 {}ARYTM-3K12"
      and A3: "B <>HIDDENR2 {}ARYTM-3K12"
    have A4: " ex A0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st A0 inTARSKIR2 A"
      using A2 subset_1_th_4 sorry
    obtain y9 where
      [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A5: "y9 inTARSKIR2 B"and A6: "y9 <>HIDDENR2 {}ARYTM-3K12"
      using A3 arytm_2_lm_15 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 *'ARYTM-3K11 y9 inTARSKIR2 A"
    have "({}ARYTM-3K12)*'ARYTM-3K11 y9 =XBOOLE-0R4 {}ARYTM-3K12"
      using arytm_3_th_48 sorry
    then have A7: "?P({}ARYTM-3K12)"
      using A4 arytm_2_lm_16 arytm_3_th_64 sorry
    have "A <>HIDDENR2 RAT+ARYTM-3K5"
      using zfmisc_1_th_56 sorry
    then obtain r where
      [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A8: " not r inTARSKIR2 A"
      using subset_1_th_28 sorry
    obtain n where
      [ty]:"n be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A9: "n inTARSKIR2 omegaORDINAL1K4"and A10: "r <='ARYTM-3R3 n *'ARYTM-3K11 y9"
      using A6 arytm_3_th_95 sorry
    have A11: " not ?P(n)"
      using A8 A10 arytm_2_lm_16 sorry
    obtain n0 where
      [ty]:"n0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      "n0 inTARSKIR2 omegaORDINAL1K4"and A12: "?P(n0) &  not ?P(n0 +ARYTM-3K10 oneARYTM-3K13)"
      using arytm_3_sch_1 arytm_2_lm_32 arytm_2_lm_33 A9 A7 A11 sorry
    have "(n0 +ARYTM-3K10 oneARYTM-3K13)*'ARYTM-3K11 y9 =HIDDENR1 n0 *'ARYTM-3K11 y9 +ARYTM-3K10 (oneARYTM-3K13)*'ARYTM-3K11 y9"
      using arytm_3_th_57 sorry
    also have "... = n0 *'ARYTM-3K11 y9 +ARYTM-3K10 y9"
      using arytm_3_th_53 sorry
    finally have "(n0 +ARYTM-3K10 oneARYTM-3K13)*'ARYTM-3K11 y9 =HIDDENR1 n0 *'ARYTM-3K11 y9 +ARYTM-3K10 y9"
       sorry
    thus " False "
      using A1 A5 A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_35:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =XBOOLE-0R4 x implies y =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =XBOOLE-0R4 x & y <>HIDDENR2 {}ARYTM-3K12 implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x +ARYTM-2K7 y =XBOOLE-0R4 x"
      and A2: "y <>HIDDENR2 {}ARYTM-3K12"
    have A3: "x <>HIDDENR2 {}ARYTM-3K12"
      using A1 A2 arytm_2_th_5 sorry
    then have A4: "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 {}ARYTM-3K12"
      using arytm_2_lm_10 sorry
    have "DEDEKIND-CUTARYTM-2K3 x =HIDDENR1 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y))"
      using A1 A2 A3 arytm_2_def_8 sorry
    also have "... = DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y"
      using arytm_2_lm_12 sorry
    finally have "DEDEKIND-CUTARYTM-2K3 x =HIDDENR1 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y"
       sorry
    then have "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {}ARYTM-3K12"
      using A4 arytm_2_lm_34 sorry
    thus " False "
      using A2 arytm_2_lm_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_36:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds (A <>HIDDENR2 {}ARYTM-3K12 & A c=TARSKIR1 B) & A <>HIDDENR2 B implies ( ex C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st A +ARYTM-2K5 C =XBOOLE-0R4 B)"
proof-
  have " for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A <>HIDDENR2 {}ARYTM-3K12 & (A c=TARSKIR1 B & A <>HIDDENR2 B) implies ( ex tVar19 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st A +ARYTM-2K5 tVar19 =XBOOLE-0R4 B)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    assume A1: "A <>HIDDENR2 {}ARYTM-3K12"
      and A2: "A c=TARSKIR1 B & A <>HIDDENR2 B"
    have " not B c=TARSKIR1 A"
      using A2 sorry
    then obtain s1 where
      [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A3: "s1 inTARSKIR2 B &  not s1 inTARSKIR2 A"
       sorry
    let ?DIF = "{t where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 t =XBOOLE-0R4 s }"
    have A4: "?DIF c=TARSKIR1 RAT+ARYTM-3K5"
    proof-
      have "{t where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 t =XBOOLE-0R4 s)) } c=TARSKIR1 RAT+ARYTM-3K5"
      proof-
        have " for e be objectHIDDENM1 holds e inHIDDENR3 {t where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 t =XBOOLE-0R4 s } implies e inHIDDENR3 RAT+ARYTM-3K5"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume "e inHIDDENR3 ?DIF"
          then have " ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t =HIDDENR1 e & ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 t =XBOOLE-0R4 s)"
             sorry
          thus "e inHIDDENR3 RAT+ARYTM-3K5"
             sorry
        qed "sorry"
        thus "{t where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 t =XBOOLE-0R4 s)) } c=TARSKIR1 RAT+ARYTM-3K5"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "s1 +ARYTM-3K10 {}ARYTM-3K12 =XBOOLE-0R4 s1"
      using arytm_3_th_84 sorry
    then have A5: "{}ARYTM-3K12 inTARSKIR2 ?DIF"
      using A3 sorry
    then obtain DIF where 
      [ty]:"DIF be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and DIFDef:"DIF = ?DIF"
      using A4 sorry
    have " for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 DIF implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 DIF) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 DIF & t <ARYTM-3R4 s)"
    proof-
      have " for t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds t inTARSKIR2 DIF implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 DIF) & ( ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar18 inTARSKIR2 DIF &  not t <ARYTM-3R4 tVar18)"
      proof(rule ballI,rule impI,rule conjMI)
        fix t assume [ty]: "t be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
        assume "t inTARSKIR2 DIF"
        then have " ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x9 =XBOOLE-0R4 t & ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 x9 =XBOOLE-0R4 s)"
           sorry
        then obtain r0 s0 where
          [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A6: " not r0 inTARSKIR2 A"and A7: "s0 inTARSKIR2 B"and A8: "r0 +ARYTM-3K10 t =XBOOLE-0R4 s0"
           sorry
        show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 t implies s inTARSKIR2 DIF"
        proof(rule ballI,rule impI)
          fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
          assume "s <='ARYTM-3R3 t"
          then obtain p where
            [ty]:"p be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A9: "s +ARYTM-3K10 p =XBOOLE-0R4 t"
             sorry
          have A10: "t <='ARYTM-3R3 s0"
            using A8 sorry
          have "p <='ARYTM-3R3 t"
            using A9 sorry
          then have "p <='ARYTM-3R3 s0"
            using A10 arytm_3_th_67 sorry
          then obtain q where
            [ty]:"q be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A11: "p +ARYTM-3K10 q =XBOOLE-0R4 s0"
             sorry
          have "(r0 +ARYTM-3K10 s)+ARYTM-3K10 p =XBOOLE-0R4 q +ARYTM-3K10 p"
            using A8 A9 A11 arytm_3_th_51 sorry
          then have A12: "r0 +ARYTM-3K10 s =XBOOLE-0R4 q"
            using arytm_3_th_62 sorry
          have "q inTARSKIR2 B"
            using A7 A11 arytm_2_lm_16 arytm_3_th_77 sorry
          thus "s inTARSKIR2 DIF"
            using A6 A12 sorry
        qed "sorry"
        obtain s1 where
          [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A13: "s1 inTARSKIR2 B"and A14: "s0 <ARYTM-3R4 s1"
          using A7 arytm_2_lm_7 sorry
        obtain q where
          [ty]:"q be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A15: "s0 +ARYTM-3K10 q =XBOOLE-0R4 s1"
          using A14 arytm_3_def_13 sorry
        show " ex tVar18 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar18 inTARSKIR2 DIF &  not t <ARYTM-3R4 tVar18"
        proof(rule bexI[of _ "t +ARYTM-3K10 q"],rule conjMI)
          have A16: "r0 +ARYTM-3K10 (t +ARYTM-3K10 q) =XBOOLE-0R4 s1"
            using A8 A15 arytm_3_th_51 sorry
          thus "t +ARYTM-3K10 q inTARSKIR2 DIF"
            using A6 A13 sorry
          have "t <='ARYTM-3R3 t +ARYTM-3K10 q & t <>HIDDENR2 t +ARYTM-3K10 q"
            using A8 A14 A16 sorry
          thus " not t <ARYTM-3R4 t +ARYTM-3K10 q"
            using arytm_3_th_68 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A17: "DIF inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
       sorry
    have "B <>HIDDENR2 RAT+ARYTM-3K5"
      using zfmisc_1_th_56 sorry
    then obtain s2 where
      [ty]:"s2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A18: " not s2 inTARSKIR2 B"
      using subset_1_th_28 sorry
    have "s2 inTARSKIR2 DIF implies  False "
    proof(rule impI)
      assume "s2 inTARSKIR2 DIF"
      then have " ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t =XBOOLE-0R4 s2 & ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 t =XBOOLE-0R4 s)"
         sorry
      thus " False "
        using A18 arytm_2_lm_16 arytm_3_th_77 sorry
    qed
    then have "DIF <>HIDDENR2 RAT+ARYTM-3K5"
       sorry
    then have 
      [ty]:"DIF be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
      using A17 zfmisc_1_th_56 sorry
    show " ex tVar19 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st A +ARYTM-2K5 tVar19 =XBOOLE-0R4 B"
    proof(rule bexI[of _ "DIF"])
      let ?C = "{r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
      have "B =XBOOLE-0R4 ?C"
      proof-
        have "B =XBOOLE-0R4 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
        proof-
          have "B c=TARSKIR1 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF } & {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF } c=TARSKIR1 B"
          proof(rule conjMI)
            show "B c=TARSKIR1 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
            proof-
              have "B c=TARSKIR1 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
              proof-
                have " for e be objectHIDDENM1 holds e inHIDDENR3 B implies e inHIDDENR3 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
                proof(rule ballI,rule impI)
                  fix e assume [ty]: "e be objectHIDDENM1"
                  assume A19: "e inHIDDENR3 B"
                  then obtain y9 where 
                    [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = e"
                     sorry
                  show "e inHIDDENR3 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
                  proof-
                    have cases: "y9 inTARSKIR2 A or  not y9 inTARSKIR2 A"
                       sorry
                    have case1: "y9 inTARSKIR2 A implies e inHIDDENR3 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
                    proof(rule impI)
                      assume A20: "y9 inTARSKIR2 A"
                      have "y9 =XBOOLE-0R4 y9 +ARYTM-3K10 {}ARYTM-3K12"
                        using arytm_3_th_84 sorry
                      thus "e inHIDDENR3 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
                        using A5 A20 sorry
                    qed
                    have case2: " not y9 inTARSKIR2 A implies e inHIDDENR3 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
                    proof(rule impI)
                      assume A21: " not y9 inTARSKIR2 A"
                      obtain s0 where
                        [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                        A22: "s0 inTARSKIR2 B"and A23: "y9 <ARYTM-3R4 s0"
                        using A19 arytm_2_lm_7 sorry
                      let ?Z = "{r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 }"
                      have A24: " not s0 inTARSKIR2 A"
                        using A21 A23 arytm_2_lm_16 sorry
                      have A25: "s0 +ARYTM-3K10 {}ARYTM-3K12 =XBOOLE-0R4 s0"
                        using arytm_3_th_84 sorry
                      have " for r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r2 <ARYTM-3R4 s0 implies ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (s inTARSKIR2 A & t inTARSKIR2 ?Z) & r2 =XBOOLE-0R4 s +ARYTM-3K10 t)"
                      proof-
                        have " for r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r2 <ARYTM-3R4 s0 implies ( ex tVar20 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar21 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar20 inTARSKIR2 A & (tVar21 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & tVar20 =XBOOLE-0R4 tVar20 +ARYTM-3K10 tVar21))"
                        proof(rule ballI,rule impI)
                          fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
                          assume A26: "r2 <ARYTM-3R4 s0"
                          then have A27: "r2 <>HIDDENR2 s0"
                             sorry
                          show " ex tVar20 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar21 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar20 inTARSKIR2 A & (tVar21 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & tVar20 =XBOOLE-0R4 tVar20 +ARYTM-3K10 tVar21)"
                          proof-
                            have cases: "r2 inTARSKIR2 A or  not r2 inTARSKIR2 A"
                               sorry
                            have case1: "r2 inTARSKIR2 A implies ( ex tVar20 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar21 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar20 inTARSKIR2 A & (tVar21 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & tVar20 =XBOOLE-0R4 tVar20 +ARYTM-3K10 tVar21))"
                            proof(rule impI)
                              assume A28: "r2 inTARSKIR2 A"
                              show " ex tVar20 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar21 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar20 inTARSKIR2 A & (tVar21 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & tVar20 =XBOOLE-0R4 tVar20 +ARYTM-3K10 tVar21)"
                              proof(rule bexI[of _ "r2"])
                                show " ex tVar21 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st r2 inTARSKIR2 A & (tVar21 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & r2 =XBOOLE-0R4 r2 +ARYTM-3K10 tVar21)"
                                proof(rule bexI[of _ "{}ARYTM-3K12"],rule conjMI,rule conjMI)
                                  show "r2 inTARSKIR2 A"
                                    using A28 sorry
                                  show "{}ARYTM-3K12 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 }"
                                    using A24 A25 sorry
                                  show "r2 =XBOOLE-0R4 r2 +ARYTM-3K10 {}ARYTM-3K12"
                                    using arytm_3_th_84 sorry
                                qed "sorry"
                              qed "sorry"
                            qed
                            have case2: " not r2 inTARSKIR2 A implies ( ex tVar22 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar23 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar22 inTARSKIR2 A & (tVar23 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & r2 =XBOOLE-0R4 tVar22 +ARYTM-3K10 tVar23))"
                            proof(rule impI)
                              assume A29: " not r2 inTARSKIR2 A"
                              obtain q where
                                [ty]:"q be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                                A30: "r2 +ARYTM-3K10 q =XBOOLE-0R4 s0"
                                using A26 arytm_3_def_13 sorry
                              let ?P = "\<lambda>Lamb1. Lamb1 *'ARYTM-3K11 q inTARSKIR2 A"
                              have "({}ARYTM-3K12)*'ARYTM-3K11 q =XBOOLE-0R4 {}ARYTM-3K12"
                                using arytm_3_th_48 sorry
                              then have A31: "?P({}ARYTM-3K12)"
                                using A1 arytm_2_lm_17 sorry
                              have "q <>HIDDENR2 {}ARYTM-3K12"
                                using A27 A30 arytm_3_th_84 sorry
                              then obtain n where
                                [ty]:"n be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                                A32: "n inTARSKIR2 omegaORDINAL1K4"and A33: "s0 <='ARYTM-3R3 n *'ARYTM-3K11 q"
                                using arytm_3_th_95 sorry
                              have A34: " not ?P(n)"
                                using A24 A33 arytm_2_lm_16 sorry
                              obtain n0 where
                                [ty]:"n0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                                "n0 inTARSKIR2 omegaORDINAL1K4"and A35: "?P(n0)"and A36: " not ?P(n0 +ARYTM-3K10 oneARYTM-3K13)"
                                using arytm_3_sch_1 arytm_2_lm_32 arytm_2_lm_33 A32 A31 A34 sorry
                              have "n0 *'ARYTM-3K11 q <='ARYTM-3R3 r2"
                                using A29 A35 arytm_2_lm_16 sorry
                              then have "n0 *'ARYTM-3K11 q +ARYTM-3K10 q <='ARYTM-3R3 s0"
                                using A30 arytm_3_th_76 sorry
                              then obtain t where
                                [ty]:"t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                                A37: "(n0 *'ARYTM-3K11 q +ARYTM-3K10 q)+ARYTM-3K10 t =XBOOLE-0R4 s0"
                                 sorry
                              show " ex tVar22 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar23 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar22 inTARSKIR2 A & (tVar23 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & r2 =XBOOLE-0R4 tVar22 +ARYTM-3K10 tVar23)"
                              proof(rule bexI[of _ "n0 *'ARYTM-3K11 q"])
                                show " ex tVar23 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st n0 *'ARYTM-3K11 q inTARSKIR2 A & (tVar23 inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 } & r2 =XBOOLE-0R4 n0 *'ARYTM-3K11 q +ARYTM-3K10 tVar23)"
                                proof(rule bexI[of _ "t"],rule conjMI,rule conjMI)
                                  show "n0 *'ARYTM-3K11 q inTARSKIR2 A"
                                    using A35 sorry
                                  have "(n0 +ARYTM-3K10 oneARYTM-3K13)*'ARYTM-3K11 q =HIDDENR1 n0 *'ARYTM-3K11 q +ARYTM-3K10 (oneARYTM-3K13)*'ARYTM-3K11 q"
                                    using arytm_3_th_57 sorry
                                  also have "... = n0 *'ARYTM-3K11 q +ARYTM-3K10 q"
                                    using arytm_3_th_53 sorry
                                  finally have "(n0 +ARYTM-3K10 oneARYTM-3K13)*'ARYTM-3K11 q =HIDDENR1 n0 *'ARYTM-3K11 q +ARYTM-3K10 q"
                                     sorry
                                  thus "t inTARSKIR2 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0 }"
                                    using A36 A37 sorry
                                  have "(n0 *'ARYTM-3K11 q +ARYTM-3K10 t)+ARYTM-3K10 q =XBOOLE-0R4 r2 +ARYTM-3K10 q"
                                    using A30 A37 arytm_3_th_51 sorry
                                  thus "r2 =XBOOLE-0R4 n0 *'ARYTM-3K11 q +ARYTM-3K10 t"
                                    using arytm_3_th_62 sorry
                                qed "sorry"
                              qed "sorry"
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed "sorry"
                        thus " ?thesis "
                           sorry
                      qed
                      then obtain s t where
                        [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                        A38: "s inTARSKIR2 A"and A39: "t inTARSKIR2 ?Z"and A40: "y9 =XBOOLE-0R4 s +ARYTM-3K10 t"
                        using A23 sorry
                      have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t =XBOOLE-0R4 r & ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 +ARYTM-3K10 r =XBOOLE-0R4 s0)"
                        using A39 sorry
                      then have "t inTARSKIR2 DIF"
                        using A22 sorry
                      thus "e inHIDDENR3 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
                        using A38 A40 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
                thus "B c=TARSKIR1 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have " for e be objectHIDDENM1 holds e inHIDDENR3 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF } implies e inHIDDENR3 B"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ?C"
              then obtain s3 t3 where
                [ty]:"s3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                A41: "e =HIDDENR1 s3 +ARYTM-3K10 t3"and A42: "s3 inTARSKIR2 A"and A43: "t3 inTARSKIR2 DIF"
                 sorry
              have " ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t3 =XBOOLE-0R4 t & ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st ( not r inTARSKIR2 A & s inTARSKIR2 B) & r +ARYTM-3K10 t =XBOOLE-0R4 s)"
                using A43 sorry
              then obtain r4 s4 where
                [ty]:"r4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s4 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                A44: " not r4 inTARSKIR2 A"and A45: "s4 inTARSKIR2 B"and A46: "r4 +ARYTM-3K10 t3 =XBOOLE-0R4 s4"
                 sorry
              have "s3 <='ARYTM-3R3 r4"
                using A42 A44 arytm_2_lm_16 sorry
              then have "s3 +ARYTM-3K10 t3 <='ARYTM-3R3 s4"
                using A46 arytm_3_th_76 sorry
              thus "e inHIDDENR3 B"
                using A41 A45 arytm_2_lm_16 sorry
            qed "sorry"
            thus "{r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF } c=TARSKIR1 B"
              using tarski_def_3 sorry
          qed
          thus "B =XBOOLE-0R4 {r +ARYTM-3K10 t where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 A & t inTARSKIR2 DIF }"
            using xboole_0_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "A +ARYTM-2K5 DIF =XBOOLE-0R4 B"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_37:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies DEDEKIND-CUTARYTM-2K3 x c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies ( not DEDEKIND-CUTARYTM-2K3 x c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 y implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
    assume A2: " not DEDEKIND-CUTARYTM-2K3 x c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 y"
    have "DEDEKIND-CUTARYTM-2K3 x inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } & DEDEKIND-CUTARYTM-2K3 y inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
      using xboole_0_def_5 sorry
    then have "DEDEKIND-CUTARYTM-2K3 y c=TARSKIR1 DEDEKIND-CUTARYTM-2K3 x"
      using A2 arytm_2_lm_13 sorry
    then have "y <='ARYTM-2R1 x"
      using arytm_2_lm_20 sorry
    thus " not  True "
      using A1 A2 arytm_2_lm_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_9:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies ( ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 z =XBOOLE-0R4 y)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <='ARYTM-2R1 y implies ( ex tVar24 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar24 =XBOOLE-0R4 tVar24)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x <='ARYTM-2R1 y"
    show " ex tVar24 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar24 =XBOOLE-0R4 tVar24"
    proof-
      have cases: "(x =XBOOLE-0R4 {}ARYTM-3K12 or x =XBOOLE-0R4 y) or x <>HIDDENR2 {}ARYTM-3K12 & x <>HIDDENR2 y"
         sorry
      have case1: "x =XBOOLE-0R4 {}ARYTM-3K12 implies ( ex tVar24 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar24 =XBOOLE-0R4 tVar24)"
      proof(rule impI)
        assume A2: "x =XBOOLE-0R4 {}ARYTM-3K12"
        show " ex tVar24 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar24 =XBOOLE-0R4 tVar24"
        proof(rule bexI[of _ "y"])
          show "x +ARYTM-2K7 y =XBOOLE-0R4 y"
            using A2 arytm_2_def_8 sorry
        qed "sorry"
      qed
      have case2: "x =XBOOLE-0R4 y implies ( ex tVar25 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar25 =XBOOLE-0R4 y)"
      proof(rule impI)
        assume A3: "x =XBOOLE-0R4 y"
        obtain z where 
          [ty]:"z be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zDef:"z = {}ARYTM-3K12"
          using arytm_2_th_1 sorry
        show " ex tVar25 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar25 =XBOOLE-0R4 y"
        proof(rule bexI[of _ "z"])
          show "x +ARYTM-2K7 z =XBOOLE-0R4 y"
            using A3 arytm_2_def_8 sorry
        qed "sorry"
      qed
      have case3: "x <>HIDDENR2 {}ARYTM-3K12 & x <>HIDDENR2 y implies ( ex tVar26 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar26 =HIDDENR1 y)"
      proof(rule impMI ,rule impI)
        assume A4: "x <>HIDDENR2 {}ARYTM-3K12"
          and A5: "x <>HIDDENR2 y"
        have A6: "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 {}ARYTM-3K12"
          using A4 arytm_2_lm_10 sorry
        have "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 DEDEKIND-CUTARYTM-2K3 y"
          using A5 arytm_2_lm_22 sorry
        then obtain C where
          [ty]:"C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1" and 
          A7: "DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 C =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 y"
          using A1 A6 arytm_2_lm_36 arytm_2_lm_37 sorry
        show " ex tVar26 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 tVar26 =HIDDENR1 y"
        proof(rule bexI[of _ "GLUEDARYTM-2K4 C"])
          have "C =XBOOLE-0R4 {}ARYTM-3K12 implies  False "
          proof(rule impI)
            assume A8: "C =XBOOLE-0R4 {}ARYTM-3K12"
            have " not ( ex e be objectHIDDENM1 st e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 C & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x })"
            proof-
              have "( ex e be objectHIDDENM1 st e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 C & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x }) implies  False "
              proof(rule impI)
                assume Given: " ex e be objectHIDDENM1 st e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 C & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x }"
                then obtain e where
                  [ty]:"e be objectHIDDENM1" and 
                  A9: "e inHIDDENR3 {r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 C & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x }"
                   sorry
                have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (e =HIDDENR1 r +ARYTM-3K10 s & r inTARSKIR2 C) & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x"
                  using A9 sorry
                thus " False "
                  using A8 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then have "{r +ARYTM-3K10 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 C & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x } =XBOOLE-0R4 {}ARYTM-3K12"
              using xboole_0_def_1 sorry
            then have "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {}ARYTM-3K12"
              using A7 arytm_2_def_6 sorry
            thus " False "
              using A1 A6 arytm_2_lm_37 xboole_1_th_3 sorry
          qed
          then have "GLUEDARYTM-2K4 C <>HIDDENR2 {}ARYTM-3K12"
            using arytm_2_lm_11 sorry
          then have "x +ARYTM-2K7 GLUEDARYTM-2K4 C =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 C))"
            using A4 arytm_2_def_8 sorry
          also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y)"
            using A7 arytm_2_lm_12 sorry
          also have "... = y"
            using arytm_2_lm_23 sorry
          finally show "x +ARYTM-2K7 GLUEDARYTM-2K4 C =HIDDENR1 y"
             sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_10:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  ex z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x +ARYTM-2K7 z =XBOOLE-0R4 y or y +ARYTM-2K7 z =XBOOLE-0R4 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ( for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not x +ARYTM-2K7 z =XBOOLE-0R4 y &  not y +ARYTM-2K7 z =XBOOLE-0R4 x)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have "x <='ARYTM-2R1 y or y <='ARYTM-2R1 x"
       sorry
    thus " not ( for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not x +ARYTM-2K7 z =XBOOLE-0R4 y &  not y +ARYTM-2K7 z =XBOOLE-0R4 x)"
      using arytm_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_11:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =XBOOLE-0R4 x +ARYTM-2K7 z implies y =XBOOLE-0R4 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x +ARYTM-2K7 y =XBOOLE-0R4 x +ARYTM-2K7 z implies y =XBOOLE-0R4 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x +ARYTM-2K7 y =XBOOLE-0R4 x +ARYTM-2K7 z"
    obtain q where
      [ty]:"q be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A2: "z +ARYTM-2K7 q =XBOOLE-0R4 y or y +ARYTM-2K7 q =XBOOLE-0R4 z"
      using arytm_2_th_10 sorry
    show "y =XBOOLE-0R4 z"
    proof-
      have cases: "z +ARYTM-2K7 q =XBOOLE-0R4 y or y +ARYTM-2K7 q =XBOOLE-0R4 z"
        using A2 sorry
      have case1: "z +ARYTM-2K7 q =XBOOLE-0R4 y implies y =XBOOLE-0R4 z"
      proof(rule impI)
        assume A3: "z +ARYTM-2K7 q =XBOOLE-0R4 y"
        then have "x +ARYTM-2K7 y =XBOOLE-0R4 (x +ARYTM-2K7 y)+ARYTM-2K7 q"
          using A1 arytm_2_th_6 sorry
        then have "q =XBOOLE-0R4 {}ARYTM-3K12"
          using arytm_2_lm_35 sorry
        thus "y =XBOOLE-0R4 z"
          using A3 arytm_2_def_8 sorry
      qed
      have case2: "y +ARYTM-2K7 q =XBOOLE-0R4 z implies y =XBOOLE-0R4 z"
      proof(rule impI)
        assume A4: "y +ARYTM-2K7 q =XBOOLE-0R4 z"
        then have "x +ARYTM-2K7 z =XBOOLE-0R4 (x +ARYTM-2K7 z)+ARYTM-2K7 q"
          using A1 arytm_2_th_6 sorry
        then have "q =XBOOLE-0R4 {}ARYTM-3K12"
          using arytm_2_lm_35 sorry
        thus "y =XBOOLE-0R4 z"
          using A4 arytm_2_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_38:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A *'ARYTM-2K6 (B *'ARYTM-2K6 C) c=TARSKIR1 (A *'ARYTM-2K6 B)*'ARYTM-2K6 C"
proof(rule ballI,rule ballI,rule ballI)
  fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  fix C assume [ty]: "C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  have " for e be objectHIDDENM1 holds e inHIDDENR3 A *'ARYTM-2K6 (B *'ARYTM-2K6 C) implies e inHIDDENR3 (A *'ARYTM-2K6 B)*'ARYTM-2K6 C"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume "e inHIDDENR3 A *'ARYTM-2K6 (B *'ARYTM-2K6 C)"
    then obtain r0 s0 where
      [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A1: "e =HIDDENR1 r0 *'ARYTM-3K11 s0 & r0 inTARSKIR2 A"and A2: "s0 inTARSKIR2 B *'ARYTM-2K6 C"
       sorry
    obtain r1 s1 where
      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A3: "s0 =XBOOLE-0R4 r1 *'ARYTM-3K11 s1 & r1 inTARSKIR2 B"and A4: "s1 inTARSKIR2 C"
      using A2 sorry
    have "e =HIDDENR1 (r0 *'ARYTM-3K11 r1)*'ARYTM-3K11 s1 & r0 *'ARYTM-3K11 r1 inTARSKIR2 A *'ARYTM-2K6 B"
      using A1 A3 arytm_3_th_52 sorry
    thus "e inHIDDENR3 (A *'ARYTM-2K6 B)*'ARYTM-2K6 C"
      using A4 sorry
  qed "sorry"
  thus "A *'ARYTM-2K6 (B *'ARYTM-2K6 C) c=TARSKIR1 (A *'ARYTM-2K6 B)*'ARYTM-2K6 C"
    using tarski_def_3 sorry
qed "sorry"

mlemma arytm_2_lm_39:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A *'ARYTM-2K6 (B *'ARYTM-2K6 C) =XBOOLE-0R4 (A *'ARYTM-2K6 B)*'ARYTM-2K6 C"
  using arytm_2_lm_38 sorry

mtheorem arytm_2_th_12:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 (y *'ARYTM-2K8 z) =XBOOLE-0R4 (x *'ARYTM-2K8 y)*'ARYTM-2K8 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 (y *'ARYTM-2K8 z) =HIDDENR1 (x *'ARYTM-2K8 y)*'ARYTM-2K8 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have "x *'ARYTM-2K8 (y *'ARYTM-2K8 z) =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 (DEDEKIND-CUTARYTM-2K3 y *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 z))"
      using arytm_2_lm_12 sorry
    also have "... = GLUEDARYTM-2K4 ((DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y)*'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 z)"
      using arytm_2_lm_39 sorry
    also have "... = (x *'ARYTM-2K8 y)*'ARYTM-2K8 z"
      using arytm_2_lm_12 sorry
    finally show "x *'ARYTM-2K8 (y *'ARYTM-2K8 z) =HIDDENR1 (x *'ARYTM-2K8 y)*'ARYTM-2K8 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_40:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y =XBOOLE-0R4 {}ARYTM-3K12 implies x =XBOOLE-0R4 {}ARYTM-3K12 or y =XBOOLE-0R4 {}ARYTM-3K12"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 y =XBOOLE-0R4 {}ARYTM-3K12 implies  not ( not x =XBOOLE-0R4 {}ARYTM-3K12 &  not y =XBOOLE-0R4 {}ARYTM-3K12)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x *'ARYTM-2K8 y =XBOOLE-0R4 {}ARYTM-3K12"
    have "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {}ARYTM-3K12 or DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {}ARYTM-3K12"
    proof-
      have "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 {}ARYTM-3K12 implies (DEDEKIND-CUTARYTM-2K3 y <>HIDDENR2 {}ARYTM-3K12 implies  False )"
      proof(rule impI,rule impI)
        assume "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 {}ARYTM-3K12"
        then obtain r0 where
          [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A2: "r0 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x"
          using subset_1_th_4 sorry
        assume "DEDEKIND-CUTARYTM-2K3 y <>HIDDENR2 {}ARYTM-3K12"
        then obtain s0 where
          [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A3: "s0 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 y"
          using subset_1_th_4 sorry
        have "r0 *'ARYTM-3K11 s0 inTARSKIR2 {r *'ARYTM-3K11 s where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5, s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x & s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 y }"
          using A2 A3 sorry
        thus " False "
          using A1 arytm_2_lm_11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( not x =XBOOLE-0R4 {}ARYTM-3K12 &  not y =XBOOLE-0R4 {}ARYTM-3K12)"
      using arytm_2_lm_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_41:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A *'ARYTM-2K6 (B +ARYTM-2K5 C) =XBOOLE-0R4 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C"
proof(rule ballI,rule ballI,rule ballI)
  fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  fix C assume [ty]: "C be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  have "A *'ARYTM-2K6 (B +ARYTM-2K5 C) c=TARSKIR1 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C & A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C c=TARSKIR1 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
  proof(rule conjMI)
    show "A *'ARYTM-2K6 (B +ARYTM-2K5 C) c=TARSKIR1 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C) implies e inHIDDENR3 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
        then obtain r0 v0 where
          [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "v0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A1: "e =HIDDENR1 r0 *'ARYTM-3K11 v0"and A2: "r0 inTARSKIR2 A"and A3: "v0 inTARSKIR2 B +ARYTM-2K5 C"
           sorry
        obtain s0 t0 where
          [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A4: "v0 =XBOOLE-0R4 s0 +ARYTM-3K10 t0"and A5: "s0 inTARSKIR2 B & t0 inTARSKIR2 C"
          using A3 sorry
        have A6: "e =HIDDENR1 r0 *'ARYTM-3K11 s0 +ARYTM-3K10 r0 *'ARYTM-3K11 t0"
          using A1 A4 arytm_3_th_57 sorry
        have "r0 *'ARYTM-3K11 s0 inTARSKIR2 A *'ARYTM-2K6 B & r0 *'ARYTM-3K11 t0 inTARSKIR2 A *'ARYTM-2K6 C"
          using A2 A5 sorry
        thus "e inHIDDENR3 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C"
          using A6 sorry
      qed "sorry"
      thus "A *'ARYTM-2K6 (B +ARYTM-2K5 C) c=TARSKIR1 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C"
        using tarski_def_3 sorry
    qed
    have " for e be objectHIDDENM1 holds e inHIDDENR3 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C implies e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C"
      then obtain s1 t1 where
        [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
        A7: "e =HIDDENR1 s1 +ARYTM-3K10 t1"and A8: "s1 inTARSKIR2 A *'ARYTM-2K6 B"and A9: "t1 inTARSKIR2 A *'ARYTM-2K6 C"
         sorry
      obtain r0 s0 where
        [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
        A10: "s1 =XBOOLE-0R4 r0 *'ARYTM-3K11 s0"and A11: "r0 inTARSKIR2 A"and A12: "s0 inTARSKIR2 B"
        using A8 sorry
      obtain r09 t0 where
        [ty]:"r09 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
        A13: "t1 =XBOOLE-0R4 r09 *'ARYTM-3K11 t0"and A14: "r09 inTARSKIR2 A"and A15: "t0 inTARSKIR2 C"
        using A9 sorry
      show "e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
      proof-
        have cases: "r0 <='ARYTM-3R3 r09 or r09 <='ARYTM-3R3 r0"
           sorry
        have case1: "r0 <='ARYTM-3R3 r09 implies e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
        proof(rule impI)
          assume "r0 <='ARYTM-3R3 r09"
          then have "r0 *'ARYTM-3K11 s0 <='ARYTM-3R3 r09 *'ARYTM-3K11 s0"
            using arytm_3_th_82 sorry
          then obtain s09 where
            [ty]:"s09 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A16: "r0 *'ARYTM-3K11 s0 =XBOOLE-0R4 r09 *'ARYTM-3K11 s09"and A17: "s09 <='ARYTM-3R3 s0"
            using arytm_3_th_79 sorry
          have "s09 inTARSKIR2 B"
            using A12 A17 arytm_2_lm_16 sorry
          then have A18: "s09 +ARYTM-3K10 t0 inTARSKIR2 B +ARYTM-2K5 C"
            using A15 sorry
          have "e =HIDDENR1 r09 *'ARYTM-3K11 (s09 +ARYTM-3K10 t0)"
            using A7 A10 A13 A16 arytm_3_th_57 sorry
          thus "e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
            using A14 A18 sorry
        qed
        have case2: "r09 <='ARYTM-3R3 r0 implies e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
        proof(rule impI)
          assume "r09 <='ARYTM-3R3 r0"
          then have "r09 *'ARYTM-3K11 t0 <='ARYTM-3R3 r0 *'ARYTM-3K11 t0"
            using arytm_3_th_82 sorry
          then obtain t09 where
            [ty]:"t09 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
            A19: "r09 *'ARYTM-3K11 t0 =XBOOLE-0R4 r0 *'ARYTM-3K11 t09"and A20: "t09 <='ARYTM-3R3 t0"
            using arytm_3_th_79 sorry
          have "t09 inTARSKIR2 C"
            using A15 A20 arytm_2_lm_16 sorry
          then have A21: "s0 +ARYTM-3K10 t09 inTARSKIR2 B +ARYTM-2K5 C"
            using A12 sorry
          have "e =HIDDENR1 r0 *'ARYTM-3K11 (s0 +ARYTM-3K10 t09)"
            using A7 A10 A13 A19 arytm_3_th_57 sorry
          thus "e inHIDDENR3 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
            using A11 A21 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C c=TARSKIR1 A *'ARYTM-2K6 (B +ARYTM-2K5 C)"
      using tarski_def_3 sorry
  qed
  thus "A *'ARYTM-2K6 (B +ARYTM-2K5 C) =XBOOLE-0R4 A *'ARYTM-2K6 B +ARYTM-2K5 A *'ARYTM-2K6 C"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem arytm_2_th_13:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 (y +ARYTM-2K7 z) =XBOOLE-0R4 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    show "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
    proof-
      have cases: "((x =XBOOLE-0R4 {}ARYTM-3K12 or y =XBOOLE-0R4 {}ARYTM-3K12) or z =XBOOLE-0R4 {}ARYTM-3K12) or x <>HIDDENR2 {}ARYTM-3K12 & (y <>HIDDENR2 {}ARYTM-3K12 & z <>HIDDENR2 {}ARYTM-3K12)"
         sorry
      have case1: "x =XBOOLE-0R4 {}ARYTM-3K12 implies x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
      proof(rule impI)
        assume A1: "x =XBOOLE-0R4 {}ARYTM-3K12"
        then have "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x"
          using arytm_2_th_4 sorry
        also have "... = x +ARYTM-2K7 x"
          using A1 arytm_2_def_8 sorry
        also have "... = x +ARYTM-2K7 x *'ARYTM-2K8 z"
          using A1 arytm_2_th_4 sorry
        also have "... = x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
          using A1 arytm_2_th_4 sorry
        finally show "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
           sorry
      qed
      have case2: "y =XBOOLE-0R4 {}ARYTM-3K12 implies x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
      proof(rule impI)
        assume A2: "y =XBOOLE-0R4 {}ARYTM-3K12"
        then have "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 z"
          using arytm_2_def_8 sorry
        also have "... = y +ARYTM-2K7 x *'ARYTM-2K8 z"
          using A2 arytm_2_def_8 sorry
        also have "... = x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
          using A2 arytm_2_th_4 sorry
        finally show "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
           sorry
      qed
      have case3: "z =XBOOLE-0R4 {}ARYTM-3K12 implies x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
      proof(rule impI)
        assume A3: "z =XBOOLE-0R4 {}ARYTM-3K12"
        then have "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y"
          using arytm_2_def_8 sorry
        also have "... = x *'ARYTM-2K8 y +ARYTM-2K7 z"
          using A3 arytm_2_def_8 sorry
        also have "... = x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
          using A3 arytm_2_th_4 sorry
        finally show "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
           sorry
      qed
      have case4: "x <>HIDDENR2 {}ARYTM-3K12 & (y <>HIDDENR2 {}ARYTM-3K12 & z <>HIDDENR2 {}ARYTM-3K12) implies x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
      proof(rule impMI ,rule impI)
        assume A4: "x <>HIDDENR2 {}ARYTM-3K12"
          and A5: "y <>HIDDENR2 {}ARYTM-3K12 & z <>HIDDENR2 {}ARYTM-3K12"
        have A6: "x *'ARYTM-2K8 y <>HIDDENR2 {}ARYTM-3K12 & x *'ARYTM-2K8 z <>HIDDENR2 {}ARYTM-3K12"
          using A4 A5 arytm_2_lm_40 sorry
        have "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z)))"
          using A5 arytm_2_def_8 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 (DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 z))"
          using arytm_2_lm_12 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 z)"
          using arytm_2_lm_41 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 (x *'ARYTM-2K8 z))"
          using arytm_2_lm_12 sorry
        also have "... = GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 (x *'ARYTM-2K8 y) +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 (x *'ARYTM-2K8 z))"
          using arytm_2_lm_12 sorry
        also have "... = x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
          using A6 arytm_2_def_8 sorry
        finally show "x *'ARYTM-2K8 (y +ARYTM-2K7 z) =HIDDENR1 x *'ARYTM-2K8 y +ARYTM-2K7 x *'ARYTM-2K8 z"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_42:
" for B be setHIDDENM2 holds B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } & B <>HIDDENR2 {}ARYTM-3K12 implies ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st r inTARSKIR2 B & r <>HIDDENR2 {}ARYTM-3K12)"
proof-
  have " for B be setHIDDENM2 holds B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) } & B <>HIDDENR2 {}ARYTM-3K12 implies  not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 B &  not r <>HIDDENR2 {}ARYTM-3K12))"
  proof(rule ballI,rule impMI ,rule impI)
    fix B assume [ty]: "B be setHIDDENM2"
    assume A1: "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
      and A2: "B <>HIDDENR2 {}ARYTM-3K12"
    obtain A where
      [ty]:"A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and 
      A3: "B =XBOOLE-0R4 A"and A4: " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s)"
      using A1 sorry
    obtain r0 where
      [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A5: "r0 inTARSKIR2 A"
      using A2 A3 subset_1_th_4 sorry
    obtain r1 where
      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A6: "r1 inTARSKIR2 A"and A7: "r0 <ARYTM-3R4 r1"
      using A4 A5 sorry
    have A8: "r1 <>HIDDENR2 {}ARYTM-3K12 or r0 <>HIDDENR2 {}ARYTM-3K12"
      using A7 sorry
    have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A & s <='ARYTM-3R3 r implies s inTARSKIR2 A"
      using A4 sorry
    then obtain r1 r2 r3 where
      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r3 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A9: "r1 inTARSKIR2 A & r2 inTARSKIR2 A"and "r3 inTARSKIR2 A"and A10: "r1 <>HIDDENR2 r2"and "r2 <>HIDDENR2 r3"and "r3 <>HIDDENR2 r1"
      using A5 A6 A8 arytm_3_th_75 sorry
    have "r1 <>HIDDENR2 {}ARYTM-3K12 or r2 <>HIDDENR2 {}ARYTM-3K12"
      using A10 sorry
    thus " not ( for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not (r inTARSKIR2 B &  not r <>HIDDENR2 {}ARYTM-3K12))"
      using A3 A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_43:
" for rone be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds rone =XBOOLE-0R4 oneARYTM-3K13 implies ( for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A <>HIDDENR2 {}ARYTM-3K12 implies ( ex B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st A *'ARYTM-2K6 B =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone))"
proof-
  have " for rone be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds rone =XBOOLE-0R4 oneARYTM-3K13 implies ( for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A <>HIDDENR2 {}ARYTM-3K12 implies  not ( for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  not A *'ARYTM-2K6 B =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix rone assume [ty]: "rone be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A0: "rone =XBOOLE-0R4 oneARYTM-3K13"
    fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
    assume A1: "A <>HIDDENR2 {}ARYTM-3K12"
    show " not ( for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  not A *'ARYTM-2K6 B =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone)"
    proof-
      have cases: "A inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } or  not A inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
         sorry
      have case1: "A inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } implies  not ( for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  not A *'ARYTM-2K6 B =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone)"
      proof(rule impI)
        assume "A inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
        then obtain r0 where
          [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A2: "A =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r0 }"and A3: "r0 <>HIDDENR2 {}ARYTM-3K12"
           sorry
        obtain s0 where
          [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A4: "r0 *'ARYTM-3K11 s0 =XBOOLE-0R4 oneARYTM-3K13"
          using A3 arytm_3_th_54 sorry
        let ?B = "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 s0 }"
        have "?B c=TARSKIR1 RAT+ARYTM-3K5"
        proof-
          have "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 s0 } c=TARSKIR1 RAT+ARYTM-3K5"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 s0 } implies e inHIDDENR3 RAT+ARYTM-3K5"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ?B"
              then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =HIDDENR1 e & s <ARYTM-3R4 s0"
                 sorry
              thus "e inHIDDENR3 RAT+ARYTM-3K5"
                 sorry
            qed "sorry"
            thus "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 s0 } c=TARSKIR1 RAT+ARYTM-3K5"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain B where 
          [ty]:"B be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and BDef:"B = ?B"
           sorry
        have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
        proof-
          have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex tVar27 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar27 inTARSKIR2 B &  not r <ARYTM-3R4 tVar27)"
          proof(rule ballI,rule impI,rule conjMI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
            assume "r inTARSKIR2 B"
            then have A5: " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r & s <ARYTM-3R4 s0"
               sorry
            then obtain t where
              [ty]:"t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A6: "r <ARYTM-3R4 t"and A7: "t <ARYTM-3R4 s0"
              using arytm_3_th_93 sorry
            show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B"
            proof(rule ballI,rule impI)
              fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
              assume "s <='ARYTM-3R3 r"
              then have "s <ARYTM-3R4 s0"
                using A5 arytm_3_th_69 sorry
              thus "s inTARSKIR2 B"
                 sorry
            qed "sorry"
            show " ex tVar27 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar27 inTARSKIR2 B &  not r <ARYTM-3R4 tVar27"
            proof(rule bexI[of _ "t"],rule conjMI)
              show "t inTARSKIR2 B"
                using A7 sorry
              show " not r <ARYTM-3R4 t"
                using A6 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A8: "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
           sorry
        have " not ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 s0 & s <ARYTM-3R4 s0)"
           sorry
        then have " not s0 inTARSKIR2 B"
           sorry
        then have "B <>HIDDENR2 RAT+ARYTM-3K5"
           sorry
        then have 
          [ty]:"B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
          using A8 zfmisc_1_th_56 sorry
        have A9: "A *'ARYTM-2K6 B =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
        proof-
          have "A *'ARYTM-2K6 B =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
          proof-
            have "A *'ARYTM-2K6 B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 } & {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 } c=TARSKIR1 A *'ARYTM-2K6 B"
            proof(rule conjMI)
              show "A *'ARYTM-2K6 B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
              proof-
                have "A *'ARYTM-2K6 B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
                proof-
                  have " for e be objectHIDDENM1 holds e inHIDDENR3 A *'ARYTM-2K6 B implies e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
                  proof(rule ballI,rule impI)
                    fix e assume [ty]: "e be objectHIDDENM1"
                    assume "e inHIDDENR3 A *'ARYTM-2K6 B"
                    then obtain r1 s1 where
                      [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                      A10: "e =HIDDENR1 r1 *'ARYTM-3K11 s1"and A11: "r1 inTARSKIR2 A"and A12: "s1 inTARSKIR2 B"
                       sorry
                    have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r1 & s <ARYTM-3R4 r0"
                      using A2 A11 sorry
                    then have A13: "r1 *'ARYTM-3K11 s1 <='ARYTM-3R3 r0 *'ARYTM-3K11 s1"
                      using arytm_3_th_82 sorry
                    have A14: " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 s1 & s <ARYTM-3R4 s0"
                      using A12 sorry
                    then have "s1 <>HIDDENR2 s0"
                       sorry
                    then have A15: "r0 *'ARYTM-3K11 s1 <>HIDDENR2 r0 *'ARYTM-3K11 s0"
                      using A3 arytm_3_th_56 sorry
                    have "r0 *'ARYTM-3K11 s1 <='ARYTM-3R3 r0 *'ARYTM-3K11 s0"
                      using A14 arytm_3_th_82 sorry
                    then have "r0 *'ARYTM-3K11 s1 <ARYTM-3R4 r0 *'ARYTM-3K11 s0"
                      using A15 arytm_3_th_68 sorry
                    then have "r1 *'ARYTM-3K11 s1 <ARYTM-3R4 r0 *'ARYTM-3K11 s0"
                      using A13 arytm_3_th_69 sorry
                    thus "e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
                      using A10 sorry
                  qed "sorry"
                  thus "A *'ARYTM-2K6 B c=TARSKIR1 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have " for e be objectHIDDENM1 holds e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 } implies e inHIDDENR3 A *'ARYTM-2K6 B"
              proof(rule ballI,rule impI)
                fix e assume [ty]: "e be objectHIDDENM1"
                assume "e inHIDDENR3 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
                then obtain s1 where
                  [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A16: "e =HIDDENR1 s1"and A17: "s1 <ARYTM-3R4 r0 *'ARYTM-3K11 s0"
                   sorry
                obtain t0 where
                  [ty]:"t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A18: "s1 =XBOOLE-0R4 r0 *'ARYTM-3K11 t0"and A19: "t0 <='ARYTM-3R3 s0"
                  using A17 arytm_3_th_79 sorry
                have "t0 <>HIDDENR2 s0"
                  using A17 A18 sorry
                then have "t0 <ARYTM-3R4 s0"
                  using A19 arytm_3_th_68 sorry
                then have "t0 inTARSKIR2 B"
                   sorry
                then obtain t1 where
                  [ty]:"t1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A20: "t1 inTARSKIR2 B"and A21: "t0 <ARYTM-3R4 t1"
                  using arytm_2_lm_7 sorry
                have "r0 *'ARYTM-3K11 t0 <='ARYTM-3R3 t1 *'ARYTM-3K11 r0"
                  using A21 arytm_3_th_82 sorry
                then obtain r1 where
                  [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A22: "r0 *'ARYTM-3K11 t0 =XBOOLE-0R4 t1 *'ARYTM-3K11 r1"and A23: "r1 <='ARYTM-3R3 r0"
                  using arytm_3_th_79 sorry
                have "t0 <>HIDDENR2 t1"
                  using A21 sorry
                then have "r1 <>HIDDENR2 r0"
                  using A3 A22 arytm_3_th_56 sorry
                then have "r1 <ARYTM-3R4 r0"
                  using A23 arytm_3_th_68 sorry
                then have "r1 inTARSKIR2 A"
                  using A2 sorry
                thus "e inHIDDENR3 A *'ARYTM-2K6 B"
                  using A16 A18 A20 A22 sorry
              qed "sorry"
              thus "{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 } c=TARSKIR1 A *'ARYTM-2K6 B"
                using tarski_def_3 sorry
            qed
            thus "A *'ARYTM-2K6 B =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not s <ARYTM-3R4 r0 *'ARYTM-3K11 s0 }"
              using xboole_0_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have " ex t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t0 =XBOOLE-0R4 rone & DEDEKIND-CUTARYTM-2K3 rone =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t0 }"
          using arytm_2_def_3 A0 sorry
        thus " not ( for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  not A *'ARYTM-2K6 B =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone)"
          using A4 A9 A0 sorry
      qed
      have case2: " not A inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 } implies ( ex tVar29 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st A *'ARYTM-2K6 tVar29 =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone)"
      proof(rule impI)
        assume A24: " not A inTARSKIR2 {{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 }"
        let ?B = "{y9 where y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 y9 <='ARYTM-3R3 oneARYTM-3K13 }"
        have A25: "?B c=TARSKIR1 RAT+ARYTM-3K5"
        proof-
          have "{y9 where y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not ( not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 y9 <='ARYTM-3R3 oneARYTM-3K13)) } c=TARSKIR1 RAT+ARYTM-3K5"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 {y9 where y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 y9 <='ARYTM-3R3 oneARYTM-3K13 } implies e inHIDDENR3 RAT+ARYTM-3K5"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ?B"
              then have " ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st y9 =HIDDENR1 e & ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 y9 <='ARYTM-3R3 oneARYTM-3K13)"
                 sorry
              thus "e inHIDDENR3 RAT+ARYTM-3K5"
                 sorry
            qed "sorry"
            thus "{y9 where y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 :  not ( for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  not ( not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 y9 <='ARYTM-3R3 oneARYTM-3K13)) } c=TARSKIR1 RAT+ARYTM-3K5"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A26: "A <>HIDDENR2 RAT+ARYTM-3K5"
          using zfmisc_1_th_56 sorry
        then obtain x0 where
          [ty]:"x0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A27: " not x0 inTARSKIR2 A"
          using subset_1_th_28 sorry
        have "x0 *'ARYTM-3K11 ({}ARYTM-3K12) =XBOOLE-0R4 {}ARYTM-3K12"
          using arytm_3_th_48 sorry
        then have "x0 *'ARYTM-3K11 ({}ARYTM-3K12) <='ARYTM-3R3 oneARYTM-3K13"
          using arytm_3_th_64 sorry
        then have A28: "{}ARYTM-3K12 inTARSKIR2 ?B"
          using A27 sorry
        then obtain B where 
          [ty]:"B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and BDef:"B = ?B"
          using A25 sorry
        have A29: "A inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
          using zfmisc_1_th_56 sorry
        have " ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x9 inTARSKIR2 A"
          using A1 subset_1_th_4 sorry
        then have A30: "{}ARYTM-3K12 inTARSKIR2 A"
          using A29 arytm_2_lm_29 arytm_3_th_64 sorry
        have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 B & r <ARYTM-3R4 s)"
        proof-
          have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 B implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B) & ( ex tVar28 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar28 inTARSKIR2 B &  not r <ARYTM-3R4 tVar28)"
          proof(rule ballI,rule impI,rule conjMI)
            fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
            assume "r inTARSKIR2 B"
            then have " ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st r =XBOOLE-0R4 y9 & ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 y9 <='ARYTM-3R3 oneARYTM-3K13)"
               sorry
            then obtain x9 where
              [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A31: " not x9 inTARSKIR2 A"and A32: "x9 *'ARYTM-3K11 r <='ARYTM-3R3 oneARYTM-3K13"
               sorry
            show " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 B"
            proof(rule ballI,rule impI)
              fix s assume [ty]: "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
              assume "s <='ARYTM-3R3 r"
              then have "x9 *'ARYTM-3K11 s <='ARYTM-3R3 x9 *'ARYTM-3K11 r"
                using arytm_3_th_82 sorry
              then have "x9 *'ARYTM-3K11 s <='ARYTM-3R3 oneARYTM-3K13"
                using A32 arytm_3_th_67 sorry
              thus "s inTARSKIR2 B"
                using A31 sorry
            qed "sorry"
            have "A inTARSKIR2 DEDEKIND-CUTSARYTM-2K1 \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub> ({{s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 t } where t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : t <>HIDDENR2 {}ARYTM-3K12 })"
              using A24 xboole_0_def_5 sorry
            then obtain x99 where
              [ty]:"x99 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A33: " not x99 inTARSKIR2 A"and A34: "x99 <ARYTM-3R4 x9"
              using A1 A31 arytm_2_lm_18 sorry
            obtain s where
              [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A35: "oneARYTM-3K13 =XBOOLE-0R4 x99 *'ARYTM-3K11 s"
              using A30 A33 arytm_3_th_55 sorry
            show " ex tVar28 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st tVar28 inTARSKIR2 B &  not r <ARYTM-3R4 tVar28"
            proof(rule bexI[of _ "s"],rule conjMI)
              have "x99 *'ARYTM-3K11 s <='ARYTM-3R3 oneARYTM-3K13"
                using A35 sorry
              thus "s inTARSKIR2 B"
                using A33 sorry
              have A36: "s <>HIDDENR2 {}ARYTM-3K12"
                using A35 arytm_3_th_48 sorry
              have "x99 *'ARYTM-3K11 r <='ARYTM-3R3 x9 *'ARYTM-3K11 r"
                using A34 arytm_3_th_82 sorry
              then have "x99 *'ARYTM-3K11 r <='ARYTM-3R3 x99 *'ARYTM-3K11 s"
                using A32 A35 arytm_3_th_67 sorry
              then have A37: "r <='ARYTM-3R3 s"
                using A30 A33 arytm_3_th_80 sorry
              have "x99 <>HIDDENR2 x9 & x99 *'ARYTM-3K11 s <='ARYTM-3R3 x9 *'ARYTM-3K11 s"
                using A34 arytm_3_th_82 sorry
              then have "r <>HIDDENR2 s"
                using A32 A35 A36 arytm_3_th_56 arytm_3_th_66 sorry
              thus " not r <ARYTM-3R4 s"
                using A37 arytm_3_th_68 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A38: "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of RAT+ARYTM-3K5 :  for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A implies ( for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <='ARYTM-3R3 r implies s inTARSKIR2 A) & ( ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s inTARSKIR2 A & r <ARYTM-3R4 s) }"
           sorry
        obtain x9 where
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A39: "x9 inTARSKIR2 A"and A40: "x9 <>HIDDENR2 {}ARYTM-3K12"
          using A1 A29 arytm_2_lm_42 sorry
        obtain y9 where
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A41: "x9 *'ARYTM-3K11 y9 =XBOOLE-0R4 oneARYTM-3K13"
          using A40 arytm_3_th_55 sorry
        have "y9 inTARSKIR2 B implies  False "
        proof(rule impI)
          assume "y9 inTARSKIR2 B"
          then have A42: " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 y9 & ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 s <='ARYTM-3R3 oneARYTM-3K13)"
             sorry
          have "y9 <>HIDDENR2 {}ARYTM-3K12"
            using A41 arytm_3_th_48 sorry
          thus " False "
            using A29 A39 A41 A42 arytm_2_lm_29 arytm_3_th_80 sorry
        qed
        then have "B <>HIDDENR2 RAT+ARYTM-3K5"
           sorry
        then have " not B inTARSKIR2 {TARSKIK1 RAT+ARYTM-3K5 }"
          using tarski_def_1 sorry
        then have 
          [ty]:"B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
          using A38 xboole_0_def_5 sorry
        show " ex tVar29 be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 st A *'ARYTM-2K6 tVar29 =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone"
        proof(rule bexI[of _ "B"])
          have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds r inTARSKIR2 A *'ARYTM-2K6 B iff r <ARYTM-3R4 oneARYTM-3K13"
          proof-
            have " for r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds (r inTARSKIR2 A *'ARYTM-2K6 B implies r <ARYTM-3R4 oneARYTM-3K13) & (r <ARYTM-3R4 oneARYTM-3K13 implies r inTARSKIR2 A *'ARYTM-2K6 B)"
            proof(rule ballI,rule conjMI,rule impI)
              fix r assume [ty]: "r be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
              show "r inTARSKIR2 A *'ARYTM-2K6 B implies r <ARYTM-3R4 oneARYTM-3K13"
              proof(rule impI)
                assume "r inTARSKIR2 A *'ARYTM-2K6 B"
                then obtain s t where
                  [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A43: "r =XBOOLE-0R4 s *'ARYTM-3K11 t"and A44: "s inTARSKIR2 A"and A45: "t inTARSKIR2 B"
                   sorry
                have " ex z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 t & ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  not x9 inTARSKIR2 A & x9 *'ARYTM-3K11 z9 <='ARYTM-3R3 oneARYTM-3K13)"
                  using A45 sorry
                then obtain x9 where
                  [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A46: " not x9 inTARSKIR2 A"and A47: "x9 *'ARYTM-3K11 t <='ARYTM-3R3 oneARYTM-3K13"
                   sorry
                have "s <='ARYTM-3R3 x9"
                  using A29 A44 A46 arytm_2_lm_29 sorry
                then have A48: "s *'ARYTM-3K11 t <='ARYTM-3R3 x9 *'ARYTM-3K11 t"
                  using arytm_3_th_82 sorry
                have A49: "r =XBOOLE-0R4 oneARYTM-3K13 implies  False "
                proof(rule impI)
                  assume A50: "r =XBOOLE-0R4 oneARYTM-3K13"
                  then have "t <>HIDDENR2 {}ARYTM-3K12"
                    using A43 arytm_3_th_48 sorry
                  thus " False "
                    using A43 A44 A46 A47 A48 A50 arytm_3_th_56 arytm_3_th_66 sorry
                qed
                have "r <='ARYTM-3R3 oneARYTM-3K13"
                  using A43 A47 A48 arytm_3_th_67 sorry
                thus "r <ARYTM-3R4 oneARYTM-3K13"
                  using A49 arytm_3_th_68 sorry
              qed
              assume A51: "r <ARYTM-3R4 oneARYTM-3K13"
              then have A52: "r <>HIDDENR2 oneARYTM-3K13"
                 sorry
              show "r inTARSKIR2 A *'ARYTM-2K6 B"
              proof-
                have cases: "r =XBOOLE-0R4 {}ARYTM-3K12 or r <>HIDDENR2 {}ARYTM-3K12"
                   sorry
                have case1: "r =XBOOLE-0R4 {}ARYTM-3K12 implies r inTARSKIR2 A *'ARYTM-2K6 B"
                proof(rule impI)
                  assume "r =XBOOLE-0R4 {}ARYTM-3K12"
                  then have "r =XBOOLE-0R4 ({}ARYTM-3K12)*'ARYTM-3K11 ({}ARYTM-3K12)"
                    using arytm_3_th_48 sorry
                  thus "r inTARSKIR2 A *'ARYTM-2K6 B"
                    using A28 A30 sorry
                qed
                have case2: "r <>HIDDENR2 {}ARYTM-3K12 implies r inTARSKIR2 A *'ARYTM-2K6 B"
                proof(rule impI)
                  assume "r <>HIDDENR2 {}ARYTM-3K12"
                  then obtain r9 where
                    [ty]:"r9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    A53: "r *'ARYTM-3K11 r9 =XBOOLE-0R4 oneARYTM-3K13"
                    using arytm_3_th_55 sorry
                  have "{r *'ARYTM-3K11 s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A } c=TARSKIR1 RAT+ARYTM-3K5"
                  proof-
                    have "{r *'ARYTM-3K11 s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A } c=TARSKIR1 RAT+ARYTM-3K5"
                    proof-
                      have " for e be objectHIDDENM1 holds e inHIDDENR3 {r *'ARYTM-3K11 s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A } implies e inHIDDENR3 RAT+ARYTM-3K5"
                      proof(rule ballI,rule impI)
                        fix e assume [ty]: "e be objectHIDDENM1"
                        assume "e inHIDDENR3 {r *'ARYTM-3K11 s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A }"
                        then have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st e =HIDDENR1 r *'ARYTM-3K11 s & s inTARSKIR2 A"
                           sorry
                        thus "e inHIDDENR3 RAT+ARYTM-3K5"
                           sorry
                      qed "sorry"
                      thus "{r *'ARYTM-3K11 s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A } c=TARSKIR1 RAT+ARYTM-3K5"
                        using tarski_def_3 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  then obtain rA where 
                    [ty]:"rA be SubsetSUBSET-1M2-of RAT+ARYTM-3K5" and rADef:"rA = {r *'ARYTM-3K11 s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s inTARSKIR2 A }"
                     sorry
                  obtain dr where
                    [ty]:"dr be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    A54: "r +ARYTM-3K10 dr =XBOOLE-0R4 oneARYTM-3K13"
                    using A51 arytm_3_def_13 sorry
                  obtain xx where
                    [ty]:"xx be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    A55: " not xx inTARSKIR2 A"
                    using A26 subset_1_th_28 sorry
                  let ?rr = "x9 *'ARYTM-3K11 dr"
                  have "dr <>HIDDENR2 {}ARYTM-3K12"
                    using A52 A54 arytm_3_th_50 sorry
                  then obtain n0 where
                    [ty]:"n0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    A56: "n0 inTARSKIR2 omegaORDINAL1K4"and A57: "xx <='ARYTM-3R3 n0 *'ARYTM-3K11 ?rr"
                    using A40 arytm_3_th_78 arytm_3_th_95 sorry
                  let ?P = "\<lambda>Lamb1. Lamb1 *'ARYTM-3K11 ?rr inTARSKIR2 A"
                  have A58: "?P({}ARYTM-3K12)"
                    using A30 arytm_3_th_48 sorry
                  have A59: " not ?P(n0)"
                    using A29 A55 A57 arytm_2_lm_29 sorry
                  obtain n1 where
                    [ty]:"n1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    "n1 inTARSKIR2 omegaORDINAL1K4"and A60: "?P(n1)"and A61: " not ?P(n1 +ARYTM-3K10 oneARYTM-3K13)"
                    using arytm_3_sch_1 arytm_2_lm_32 arytm_2_lm_33 A56 A58 A59 sorry
                  let ?s0 = "n1 *'ARYTM-3K11 ?rr"
                  have A62: "n1 *'ARYTM-3K11 (x9 *'ARYTM-3K11 dr) inTARSKIR2 rA implies  False "
                  proof(rule impI)
                    assume "n1 *'ARYTM-3K11 ?rr inTARSKIR2 rA"
                    then obtain s0 where
                      [ty]:"s0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                      A63: "r *'ARYTM-3K11 s0 =XBOOLE-0R4 n1 *'ARYTM-3K11 ?rr"and A64: "s0 inTARSKIR2 A"
                       sorry
                    have A65: "(n1 +ARYTM-3K10 oneARYTM-3K13)*'ARYTM-3K11 ?rr =HIDDENR1 n1 *'ARYTM-3K11 ?rr +ARYTM-3K10 (oneARYTM-3K13)*'ARYTM-3K11 ?rr"
                      using arytm_3_th_57 sorry
                    also have "... = r *'ARYTM-3K11 s0 +ARYTM-3K10 dr *'ARYTM-3K11 x9"
                      using A63 arytm_3_th_53 sorry
                    finally have "(n1 +ARYTM-3K10 oneARYTM-3K13)*'ARYTM-3K11 ?rr =HIDDENR1 r *'ARYTM-3K11 s0 +ARYTM-3K10 dr *'ARYTM-3K11 x9"
                       sorry
                    have "s0 <='ARYTM-3R3 x9 or x9 <='ARYTM-3R3 s0"
                       sorry
                    then obtain s1 where
                      [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                      A66: "s1 =XBOOLE-0R4 s0 & x9 <='ARYTM-3R3 s1 or s1 =XBOOLE-0R4 x9 & s0 <='ARYTM-3R3 s1"
                       sorry
                    have "dr *'ARYTM-3K11 x9 <='ARYTM-3R3 dr *'ARYTM-3K11 s1"
                      using A66 arytm_3_th_82 sorry
                    then have A67: "r *'ARYTM-3K11 s1 +ARYTM-3K10 dr *'ARYTM-3K11 x9 <='ARYTM-3R3 r *'ARYTM-3K11 s1 +ARYTM-3K10 dr *'ARYTM-3K11 s1"
                      using arytm_3_th_76 sorry
                    have "r *'ARYTM-3K11 s0 <='ARYTM-3R3 r *'ARYTM-3K11 s1"
                      using A66 arytm_3_th_82 sorry
                    then have A68: "r *'ARYTM-3K11 s0 +ARYTM-3K10 dr *'ARYTM-3K11 x9 <='ARYTM-3R3 r *'ARYTM-3K11 s1 +ARYTM-3K10 dr *'ARYTM-3K11 x9"
                      using arytm_3_th_76 sorry
                    have "r *'ARYTM-3K11 s1 +ARYTM-3K10 dr *'ARYTM-3K11 s1 =HIDDENR1 (r +ARYTM-3K10 dr)*'ARYTM-3K11 s1"
                      using arytm_3_th_57 sorry
                    also have "... = s1"
                      using A54 arytm_3_th_53 sorry
                    finally have "r *'ARYTM-3K11 s1 +ARYTM-3K10 dr *'ARYTM-3K11 s1 =HIDDENR1 s1"
                       sorry
                    thus " False "
                      using A29 A39 A61 A64 A65 A66 A68 A67 arytm_2_lm_29 sorry
                  qed
                  have A69: "(n1 *'ARYTM-3K11 (x9 *'ARYTM-3K11 dr))*'ARYTM-3K11 r9 inTARSKIR2 A implies  False "
                  proof(rule impI)
                    assume A70: "?s0 *'ARYTM-3K11 r9 inTARSKIR2 A"
                    have "r *'ARYTM-3K11 (?s0 *'ARYTM-3K11 r9) =HIDDENR1 (oneARYTM-3K13)*'ARYTM-3K11 ?s0"
                      using A53 arytm_3_th_52 sorry
                    also have "... = ?s0"
                      using arytm_3_th_53 sorry
                    finally have "r *'ARYTM-3K11 (?s0 *'ARYTM-3K11 r9) =HIDDENR1 ?s0"
                       sorry
                    thus " False "
                      using A62 A70 sorry
                  qed
                  have "r *'ARYTM-3K11 ({}ARYTM-3K12) =XBOOLE-0R4 {}ARYTM-3K12"
                    using arytm_3_th_48 sorry
                  then have "{}ARYTM-3K12 inTARSKIR2 rA"
                    using A30 sorry
                  then obtain s9 where
                    [ty]:"s9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                    A71: "?s0 *'ARYTM-3K11 s9 =XBOOLE-0R4 oneARYTM-3K13"
                    using A62 arytm_3_th_55 sorry
                  have A72: "?s0 *'ARYTM-3K11 (r *'ARYTM-3K11 s9) =HIDDENR1 (?s0 *'ARYTM-3K11 s9)*'ARYTM-3K11 r"
                    using arytm_3_th_52 sorry
                  also have "... = r"
                    using A71 arytm_3_th_53 sorry
                  finally have "?s0 *'ARYTM-3K11 (r *'ARYTM-3K11 s9) =HIDDENR1 r"
                     sorry
                  have "(?s0 *'ARYTM-3K11 r9)*'ARYTM-3K11 (r *'ARYTM-3K11 s9) =HIDDENR1 ((?s0 *'ARYTM-3K11 r9)*'ARYTM-3K11 r)*'ARYTM-3K11 s9"
                    using arytm_3_th_52 sorry
                  also have "... = (?s0 *'ARYTM-3K11 (oneARYTM-3K13))*'ARYTM-3K11 s9"
                    using A53 arytm_3_th_52 sorry
                  also have "... = oneARYTM-3K13"
                    using A71 arytm_3_th_53 sorry
                  finally have "(?s0 *'ARYTM-3K11 r9)*'ARYTM-3K11 (r *'ARYTM-3K11 s9) =HIDDENR1 oneARYTM-3K13"
                     sorry
                  then have "(?s0 *'ARYTM-3K11 r9)*'ARYTM-3K11 (r *'ARYTM-3K11 s9) <='ARYTM-3R3 oneARYTM-3K13"
                     sorry
                  then have "r *'ARYTM-3K11 s9 inTARSKIR2 B"
                    using A69 sorry
                  thus "r inTARSKIR2 A *'ARYTM-2K6 B"
                    using A60 A72 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then have "DEDEKIND-CUTARYTM-2K3 (GLUEDARYTM-2K4 (A *'ARYTM-2K6 B)) =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone"
            using A0 arytm_2_def_4 sorry
          thus "A *'ARYTM-2K6 B =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone"
            using arytm_2_lm_12 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_14:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <>HIDDENR2 {}ARYTM-3K12 implies ( ex y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x *'ARYTM-2K8 y =XBOOLE-0R4 oneARYTM-3K13)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x <>HIDDENR2 {}ARYTM-3K12 implies ( ex y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x *'ARYTM-2K8 y =HIDDENR1 oneARYTM-3K13)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    obtain rone where 
      [ty]:"rone be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and roneDef:"rone = oneARYTM-3K13"
      using arytm_2_th_1 sorry
    assume "x <>HIDDENR2 {}ARYTM-3K12"
    then have "DEDEKIND-CUTARYTM-2K3 x <>HIDDENR2 {}ARYTM-3K12"
      using arytm_2_lm_10 sorry
    then obtain B where
      [ty]:"B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1" and 
      A1: "DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 B =XBOOLE-0R4 DEDEKIND-CUTARYTM-2K3 rone"
      using arytm_2_lm_43 sorry
    obtain y where 
      [ty]:"y be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and yDef:"y = GLUEDARYTM-2K4 B"
       sorry
    show " ex y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st x *'ARYTM-2K8 y =HIDDENR1 oneARYTM-3K13"
    proof(rule bexI[of _ "y"])
      have "x *'ARYTM-2K8 y =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 rone)"
        using A1 arytm_2_lm_12 sorry
      also have "... = oneARYTM-3K13"
        using arytm_2_lm_23 sorry
      finally show "x *'ARYTM-2K8 y =HIDDENR1 oneARYTM-3K13"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_44:
" for A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds  for B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1 holds A =XBOOLE-0R4 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r <ARYTM-3R4 oneARYTM-3K13 } implies A *'ARYTM-2K6 B =XBOOLE-0R4 B"
proof(rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  fix B assume [ty]: "B be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (RAT+ARYTM-3K5))\<^esub>-of DEDEKIND-CUTSARYTM-2K1"
  assume A1: "A =XBOOLE-0R4 {r where r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : r <ARYTM-3R4 oneARYTM-3K13 }"
  have "A *'ARYTM-2K6 B c=TARSKIR1 B & B c=TARSKIR1 A *'ARYTM-2K6 B"
  proof(rule conjMI)
    show "A *'ARYTM-2K6 B c=TARSKIR1 B"
    proof-
      have " for e be objectHIDDENM1 holds e inHIDDENR3 A *'ARYTM-2K6 B implies e inHIDDENR3 B"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 A *'ARYTM-2K6 B"
        then obtain r s where
          [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A2: "e =HIDDENR1 r *'ARYTM-3K11 s"and A3: "r inTARSKIR2 A"and A4: "s inTARSKIR2 B"
           sorry
        have " ex t be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st t =XBOOLE-0R4 r & t <ARYTM-3R4 oneARYTM-3K13"
          using A1 A3 sorry
        then have "r *'ARYTM-3K11 s <='ARYTM-3R3 (oneARYTM-3K13)*'ARYTM-3K11 s"
          using arytm_3_th_82 sorry
        then have "r *'ARYTM-3K11 s <='ARYTM-3R3 s"
          using arytm_3_th_53 sorry
        thus "e inHIDDENR3 B"
          using A2 A4 arytm_2_lm_16 sorry
      qed "sorry"
      thus "A *'ARYTM-2K6 B c=TARSKIR1 B"
        using tarski_def_3 sorry
    qed
    have " for e be objectHIDDENM1 holds e inHIDDENR3 B implies e inHIDDENR3 A *'ARYTM-2K6 B"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A5: "e inHIDDENR3 B"
      then obtain s where 
        [ty]:"s be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and sDef:"s = e"
         sorry
      obtain s1 where
        [ty]:"s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
        A6: "s1 inTARSKIR2 B"and A7: "s <ARYTM-3R4 s1"
        using A5 arytm_2_lm_7 sorry
      have "s1 <>HIDDENR2 {}ARYTM-3K12"
        using A7 arytm_3_th_64 sorry
      then obtain s2 where
        [ty]:"s2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
        A8: "s1 *'ARYTM-3K11 s2 =XBOOLE-0R4 s"
        using arytm_3_th_55 sorry
      have A9: "s2 =XBOOLE-0R4 oneARYTM-3K13 implies  False "
      proof(rule impI)
        assume "s2 =XBOOLE-0R4 oneARYTM-3K13"
        then have "s =XBOOLE-0R4 s1"
          using A8 arytm_3_th_53 sorry
        thus " False "
          using A7 sorry
      qed
      have "(oneARYTM-3K13)*'ARYTM-3K11 s =XBOOLE-0R4 s2 *'ARYTM-3K11 s1"
        using A8 arytm_3_th_53 sorry
      then have "s2 <='ARYTM-3R3 oneARYTM-3K13"
        using A7 arytm_3_th_83 sorry
      then have "s2 <ARYTM-3R4 oneARYTM-3K13"
        using A9 arytm_3_th_68 sorry
      then have "s2 inTARSKIR2 A"
        using A1 sorry
      thus "e inHIDDENR3 A *'ARYTM-2K6 B"
        using A6 A8 sorry
    qed "sorry"
    thus "B c=TARSKIR1 A *'ARYTM-2K6 B"
      using tarski_def_3 sorry
  qed
  thus "A *'ARYTM-2K6 B =XBOOLE-0R4 B"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem arytm_2_th_15:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 oneARYTM-3K13 implies x *'ARYTM-2K8 y =XBOOLE-0R4 y"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 oneARYTM-3K13 implies x *'ARYTM-2K8 y =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x =XBOOLE-0R4 oneARYTM-3K13"
    then have " ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 r & DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 r }"
      using arytm_2_def_3 sorry
    then have "x *'ARYTM-2K8 y =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 y)"
      using A1 arytm_2_lm_44 sorry
    also have "... = y"
      using arytm_2_lm_23 sorry
    finally show "x *'ARYTM-2K8 y =HIDDENR1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_45:
" for i be ElementSUBSET-1M1-of omegaORDINAL1K4 holds  for j be ElementSUBSET-1M1-of omegaORDINAL1K4 holds  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds i =XBOOLE-0R4 x9 & j =XBOOLE-0R4 y9 implies i +^ORDINAL2K10 j =XBOOLE-0R4 x9 +ARYTM-3K10 y9"
proof-
  have " for i be ElementSUBSET-1M1-of omegaORDINAL1K4 holds  for j be ElementSUBSET-1M1-of omegaORDINAL1K4 holds  for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds i =XBOOLE-0R4 x9 implies (j =XBOOLE-0R4 y9 implies i +^ORDINAL2K10 j =HIDDENR1 x9 +ARYTM-3K10 y9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix i assume [ty]: "i be ElementSUBSET-1M1-of omegaORDINAL1K4"
    fix j assume [ty]: "j be ElementSUBSET-1M1-of omegaORDINAL1K4"
    fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    let ?a = "denominatorARYTM-3K7 x9 *^ORDINAL2K11 denominatorARYTM-3K7 y9"
    let ?b = "numeratorARYTM-3K6 x9 *^ORDINAL2K11 denominatorARYTM-3K7 y9 +^ORDINAL2K10 numeratorARYTM-3K6 y9 *^ORDINAL2K11 denominatorARYTM-3K7 x9"
    assume A1: "i =XBOOLE-0R4 x9"
    then have A2: "denominatorARYTM-3K7 x9 =XBOOLE-0R4 oneARYTM-3K13"
      using arytm_3_def_9 sorry
    assume A3: "j =XBOOLE-0R4 y9"
    then have A4: "denominatorARYTM-3K7 y9 =XBOOLE-0R4 oneARYTM-3K13"
      using arytm_3_def_9 sorry
    then have A5: "?a =XBOOLE-0R4 oneARYTM-3K13"
      using A2 ordinal2_th_39 sorry
    then have A6: "REDARYTM-3K4(?a,?b) =XBOOLE-0R4 oneARYTM-3K13"
      using arytm_3_th_24 sorry
    have "?b =HIDDENR1 numeratorARYTM-3K6 x9 *^ORDINAL2K11 oneARYTM-3K13 +^ORDINAL2K10 numeratorARYTM-3K6 y9"
      using A2 A4 ordinal2_th_39 sorry
    also have "... = numeratorARYTM-3K6 x9 +^ORDINAL2K10 numeratorARYTM-3K6 y9"
      using ordinal2_th_39 sorry
    also have "... = i +^ORDINAL2K10 numeratorARYTM-3K6 y9"
      using A1 arytm_3_def_8 sorry
    also have "... = i +^ORDINAL2K10 j"
      using A3 arytm_3_def_8 sorry
    finally have "?b =HIDDENR1 i +^ORDINAL2K10 j"
       sorry
    then have "i +^ORDINAL2K10 j =HIDDENR1 REDARYTM-3K4(numeratorARYTM-3K6 x9 *^ORDINAL2K11 denominatorARYTM-3K7 y9 +^ORDINAL2K10 numeratorARYTM-3K6 y9 *^ORDINAL2K11 denominatorARYTM-3K7 x9,denominatorARYTM-3K7 x9 *^ORDINAL2K11 denominatorARYTM-3K7 y9)"
      using A5 arytm_3_th_24 sorry
    also have "... = x9 +ARYTM-3K10 y9"
      using A6 arytm_3_def_10 sorry
    finally show "i +^ORDINAL2K10 j =HIDDENR1 x9 +ARYTM-3K10 y9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_46:
" for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds (z9 <ARYTM-3R4 x9 +ARYTM-3K10 y9 & x9 <>HIDDENR2 {}ARYTM-3K12) & y9 <>HIDDENR2 {}ARYTM-3K12 implies ( ex r be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (z9 =XBOOLE-0R4 r +ARYTM-3K10 s & r <ARYTM-3R4 x9) & s <ARYTM-3R4 y9)"
proof-
  have " for x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds  for z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds z9 <ARYTM-3R4 x9 +ARYTM-3K10 y9 & (x9 <>HIDDENR2 {}ARYTM-3K12 & y9 <>HIDDENR2 {}ARYTM-3K12) implies ( ex tVar31 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar32 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 tVar31 +ARYTM-3K10 tVar32 & (tVar31 <ARYTM-3R4 x9 &  not tVar32 <ARYTM-3R4 y9))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix y9 assume [ty]: "y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    fix z9 assume [ty]: "z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
    assume A1: "z9 <ARYTM-3R4 x9 +ARYTM-3K10 y9"
      and A2: "x9 <>HIDDENR2 {}ARYTM-3K12"
      and A3: "y9 <>HIDDENR2 {}ARYTM-3K12"
    obtain r0 t0 where
      [ty]:"r0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A4: "z9 =XBOOLE-0R4 r0 +ARYTM-3K10 t0"and A5: "r0 <='ARYTM-3R3 x9"and A6: "t0 <='ARYTM-3R3 y9 & t0 <>HIDDENR2 y9"
      using A1 A3 arytm_3_th_90 sorry
    show " ex tVar31 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar32 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 tVar31 +ARYTM-3K10 tVar32 & (tVar31 <ARYTM-3R4 x9 &  not tVar32 <ARYTM-3R4 y9)"
    proof-
      have cases: "r0 =XBOOLE-0R4 {}ARYTM-3K12 or r0 <>HIDDENR2 {}ARYTM-3K12"
         sorry
      have case1: "r0 =XBOOLE-0R4 {}ARYTM-3K12 implies ( ex tVar31 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar32 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 tVar31 +ARYTM-3K10 tVar32 & (tVar31 <ARYTM-3R4 x9 &  not tVar32 <ARYTM-3R4 y9))"
      proof(rule impI)
        assume A7: "r0 =XBOOLE-0R4 {}ARYTM-3K12"
        show " ex tVar31 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar32 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 tVar31 +ARYTM-3K10 tVar32 & (tVar31 <ARYTM-3R4 x9 &  not tVar32 <ARYTM-3R4 y9)"
        proof(rule bexI[of _ "{}ARYTM-3K12"])
          show " ex tVar32 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 {}ARYTM-3K12 +ARYTM-3K10 tVar32 & ({}ARYTM-3K12 <ARYTM-3R4 x9 &  not tVar32 <ARYTM-3R4 y9)"
          proof(rule bexI[of _ "t0"],rule conjMI,rule conjMI)
            show "z9 =XBOOLE-0R4 {}ARYTM-3K12 +ARYTM-3K10 t0"
              using A4 A7 sorry
            have "{}ARYTM-3K12 <='ARYTM-3R3 x9"
              using arytm_3_th_64 sorry
            thus "{}ARYTM-3K12 <ARYTM-3R4 x9"
              using A2 arytm_3_th_68 sorry
            show " not t0 <ARYTM-3R4 y9"
              using A6 arytm_3_th_68 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: "r0 <>HIDDENR2 {}ARYTM-3K12 implies ( ex tVar33 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar34 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 tVar33 +ARYTM-3K10 tVar34 & (tVar33 <ARYTM-3R4 x9 &  not tVar34 <ARYTM-3R4 y9))"
      proof(rule impI)
        assume A8: "r0 <>HIDDENR2 {}ARYTM-3K12"
        have "t0 <ARYTM-3R4 y9"
          using A6 arytm_3_th_68 sorry
        then obtain t1 where
          [ty]:"t1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A9: "t0 <ARYTM-3R4 t1"and A10: "t1 <ARYTM-3R4 y9"
          using arytm_3_th_93 sorry
        have "z9 <ARYTM-3R4 t1 +ARYTM-3K10 r0"
          using A4 A9 arytm_3_th_76 sorry
        then obtain t2 r1 where
          [ty]:"t2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A11: "z9 =XBOOLE-0R4 t2 +ARYTM-3K10 r1"and A12: "t2 <='ARYTM-3R3 t1"and A13: "r1 <='ARYTM-3R3 r0 & r1 <>HIDDENR2 r0"
          using A8 arytm_3_th_90 sorry
        show " ex tVar33 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar34 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 tVar33 +ARYTM-3K10 tVar34 & (tVar33 <ARYTM-3R4 x9 &  not tVar34 <ARYTM-3R4 y9)"
        proof(rule bexI[of _ "r1"])
          show " ex tVar34 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st z9 =XBOOLE-0R4 r1 +ARYTM-3K10 tVar34 & (r1 <ARYTM-3R4 x9 &  not tVar34 <ARYTM-3R4 y9)"
          proof(rule bexI[of _ "t2"],rule conjMI,rule conjMI)
            show "z9 =XBOOLE-0R4 r1 +ARYTM-3K10 t2"
              using A11 sorry
            have "r1 <ARYTM-3R4 r0"
              using A13 arytm_3_th_68 sorry
            thus "r1 <ARYTM-3R4 x9"
              using A5 arytm_3_th_69 sorry
            show " not t2 <ARYTM-3R4 y9"
              using A10 A12 arytm_3_th_69 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma arytm_2_lm_47:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x +ARYTM-2K7 y =XBOOLE-0R4 x9 +ARYTM-3K10 y9)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex tVar35 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar36 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar35 & (y =XBOOLE-0R4 tVar36 & x +ARYTM-2K7 y =HIDDENR1 tVar35 +ARYTM-3K10 tVar36))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x inTARSKIR2 RAT+ARYTM-3K5"
      and A2: "y inTARSKIR2 RAT+ARYTM-3K5"
    show " ex tVar35 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar36 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar35 & (y =XBOOLE-0R4 tVar36 & x +ARYTM-2K7 y =HIDDENR1 tVar35 +ARYTM-3K10 tVar36)"
    proof-
      have cases: "(x =XBOOLE-0R4 {}ARYTM-3K12 or y =XBOOLE-0R4 {}ARYTM-3K12) or y <>HIDDENR2 {}ARYTM-3K12 & x <>HIDDENR2 {}ARYTM-3K12"
         sorry
      have case1: "x =XBOOLE-0R4 {}ARYTM-3K12 implies ( ex tVar35 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar36 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar35 & (y =XBOOLE-0R4 tVar36 & x +ARYTM-2K7 y =HIDDENR1 tVar35 +ARYTM-3K10 tVar36))"
      proof(rule impI)
        assume A3: "x =XBOOLE-0R4 {}ARYTM-3K12"
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
          using A2 sorry
        show " ex tVar35 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar36 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar35 & (y =XBOOLE-0R4 tVar36 & x +ARYTM-2K7 y =HIDDENR1 tVar35 +ARYTM-3K10 tVar36)"
        proof(rule bexI[of _ "{}ARYTM-3K12"])
          show " ex tVar36 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 {}ARYTM-3K12 & (y =XBOOLE-0R4 tVar36 & x +ARYTM-2K7 y =HIDDENR1 {}ARYTM-3K12 +ARYTM-3K10 tVar36)"
          proof(rule bexI[of _ "y9"],rule conjMI,rule conjMI)
            show "x =XBOOLE-0R4 {}ARYTM-3K12"
              using A3 sorry
            show "y =XBOOLE-0R4 y9"
               sorry
            have "x +ARYTM-2K7 y =HIDDENR1 y"
              using A3 arytm_2_def_8 sorry
            also have "... = {}ARYTM-3K12 +ARYTM-3K10 y9"
              using arytm_3_th_50 sorry
            finally show "x +ARYTM-2K7 y =HIDDENR1 {}ARYTM-3K12 +ARYTM-3K10 y9"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: "y =XBOOLE-0R4 {}ARYTM-3K12 implies ( ex tVar37 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar38 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar37 & (y =XBOOLE-0R4 tVar38 & x +ARYTM-2K7 y =HIDDENR1 tVar37 +ARYTM-3K10 tVar38))"
      proof(rule impI)
        assume A4: "y =XBOOLE-0R4 {}ARYTM-3K12"
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
          using A1 sorry
        show " ex tVar37 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar38 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar37 & (y =XBOOLE-0R4 tVar38 & x +ARYTM-2K7 y =HIDDENR1 tVar37 +ARYTM-3K10 tVar38)"
        proof(rule bexI[of _ "x9"])
          show " ex tVar38 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 x9 & (y =XBOOLE-0R4 tVar38 & x +ARYTM-2K7 y =HIDDENR1 x9 +ARYTM-3K10 tVar38)"
          proof(rule bexI[of _ "{}ARYTM-3K12"],rule conjMI,rule conjMI)
            show "x =XBOOLE-0R4 x9"
               sorry
            show "y =XBOOLE-0R4 {}ARYTM-3K12"
              using A4 sorry
            have "x +ARYTM-2K7 y =HIDDENR1 x"
              using A4 arytm_2_def_8 sorry
            also have "... = x9 +ARYTM-3K10 {}ARYTM-3K12"
              using arytm_3_th_50 sorry
            finally show "x +ARYTM-2K7 y =HIDDENR1 x9 +ARYTM-3K10 {}ARYTM-3K12"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      have case3: "y <>HIDDENR2 {}ARYTM-3K12 & x <>HIDDENR2 {}ARYTM-3K12 implies ( ex tVar39 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar40 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 tVar39 & y =XBOOLE-0R4 tVar40) & x +ARYTM-2K7 y =HIDDENR1 tVar39 +ARYTM-3K10 tVar40)"
      proof(rule impI)
        assume A5: "y <>HIDDENR2 {}ARYTM-3K12 & x <>HIDDENR2 {}ARYTM-3K12"
        let ?A = "DEDEKIND-CUTARYTM-2K3 x"
        let ?B = "DEDEKIND-CUTARYTM-2K3 y"
        obtain x9 where
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A6: "x =XBOOLE-0R4 x9"and A7: "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 x9 }"
          using A1 arytm_2_def_3 sorry
        obtain y9 where
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A8: "y =XBOOLE-0R4 y9"and A9: "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 y9 }"
          using A2 arytm_2_def_3 sorry
        have A10: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y iff s <ARYTM-3R4 x9 +ARYTM-3K10 y9"
        proof-
          have " for s2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds (s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y implies s2 <ARYTM-3R4 x9 +ARYTM-3K10 y9) & (s2 <ARYTM-3R4 x9 +ARYTM-3K10 y9 implies s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y)"
          proof(rule ballI,rule conjMI,rule impI)
            fix s2 assume [ty]: "s2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
            show "s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y implies s2 <ARYTM-3R4 x9 +ARYTM-3K10 y9"
            proof-
              have "s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y implies  not s2 <ARYTM-3R4 x9 +ARYTM-3K10 y9"
              proof(rule impI)
                assume "s2 inTARSKIR2 ?A +ARYTM-2K5 ?B"
                then obtain r1 s1 where
                  [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A11: "s2 =XBOOLE-0R4 r1 +ARYTM-3K10 s1"and A12: "r1 inTARSKIR2 ?A"and A13: "s1 inTARSKIR2 ?B"
                   sorry
                have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r1 & s <ARYTM-3R4 x9"
                  using A7 A12 sorry
                then have A14: "r1 +ARYTM-3K10 s1 <='ARYTM-3R3 x9 +ARYTM-3K10 s1"
                  using arytm_3_th_76 sorry
                have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 s1 & s <ARYTM-3R4 y9"
                  using A9 A13 sorry
                then have "x9 +ARYTM-3K10 s1 <ARYTM-3R4 x9 +ARYTM-3K10 y9"
                  using arytm_3_th_76 sorry
                thus " not s2 <ARYTM-3R4 x9 +ARYTM-3K10 y9"
                  using A11 A14 arytm_3_th_69 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            assume "s2 <ARYTM-3R4 x9 +ARYTM-3K10 y9"
            then obtain t2 t0 where
              [ty]:"t2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A15: "s2 =XBOOLE-0R4 t2 +ARYTM-3K10 t0"and A16: "t2 <ARYTM-3R4 x9 & t0 <ARYTM-3R4 y9"
              using A5 A6 A8 arytm_2_lm_46 sorry
            have "t0 inTARSKIR2 ?B & t2 inTARSKIR2 ?A"
              using A7 A9 A16 sorry
            thus "s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y"
              using A15 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then obtain r where
          [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A17: "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y) =XBOOLE-0R4 r"and A18: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y iff s <ARYTM-3R4 r"
          using arytm_2_def_4 sorry
        have A19: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <ARYTM-3R4 x9 +ARYTM-3K10 y9 iff s <ARYTM-3R4 r"
          using A10 A18 sorry
        show " ex tVar39 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar40 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 tVar39 & y =XBOOLE-0R4 tVar40) & x +ARYTM-2K7 y =HIDDENR1 tVar39 +ARYTM-3K10 tVar40"
        proof(rule bexI[of _ "x9"])
          show " ex tVar40 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 tVar40) & x +ARYTM-2K7 y =HIDDENR1 x9 +ARYTM-3K10 tVar40"
          proof(rule bexI[of _ "y9"],rule conjMI)
            show "x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9"
              using A6 A8 sorry
            have "x +ARYTM-2K7 y =HIDDENR1 GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x +ARYTM-2K5 DEDEKIND-CUTARYTM-2K3 y)"
              using A5 arytm_2_def_8 sorry
            also have "... = x9 +ARYTM-3K10 y9"
              using A17 A19 arytm_2_lm_6 sorry
            finally show "x +ARYTM-2K7 y =HIDDENR1 x9 +ARYTM-3K10 y9"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_16:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 omegaORDINAL1K4 & y inTARSKIR2 omegaORDINAL1K4 implies y +ARYTM-2K7 x inTARSKIR2 omegaORDINAL1K4"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 omegaORDINAL1K4 & y inTARSKIR2 omegaORDINAL1K4 implies y +ARYTM-2K7 x inTARSKIR2 omegaORDINAL1K4"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x inTARSKIR2 omegaORDINAL1K4 & y inTARSKIR2 omegaORDINAL1K4"
    then obtain x0 y0 where 
      [ty]:"x0 be ElementSUBSET-1M1-of omegaORDINAL1K4" and x0Def:"x0 = x" and
      [ty]:"y0 be ElementSUBSET-1M1-of omegaORDINAL1K4" and y0Def:"y0 = y"
       sorry
    obtain x9 y9 where
      [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A2: "x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9"and A3: "x +ARYTM-2K7 y =XBOOLE-0R4 x9 +ARYTM-3K10 y9"
      using A1 arytm_2_lm_5 arytm_2_lm_47 sorry
    have "x9 +ARYTM-3K10 y9 =XBOOLE-0R4 x0 +^ORDINAL2K10 y0"
      using A2 arytm_2_lm_45 sorry
    thus "y +ARYTM-2K7 x inTARSKIR2 omegaORDINAL1K4"
      using A3 ordinal1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_17:
" for A be SubsetSUBSET-1M2-of REAL+ARYTM-2K2 holds 0ORDINAL1K5 inTARSKIR2 A & ( for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 A & y =XBOOLE-0R4 oneARYTM-3K13 implies x +ARYTM-2K7 y inTARSKIR2 A) implies omegaORDINAL1K4 c=TARSKIR1 A"
proof(rule ballI,rule impMI ,rule impI)
  fix A assume [ty]: "A be SubsetSUBSET-1M2-of REAL+ARYTM-2K2"
  let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
  assume A1: "?P(0ORDINAL1K5)"
    and A2: " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 A & y =XBOOLE-0R4 oneARYTM-3K13 implies x +ARYTM-2K7 y inTARSKIR2 A"
  have " for e be objectHIDDENM1 holds e inHIDDENR3 omegaORDINAL1K4 implies e inHIDDENR3 A"
  proof(rule ballI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    assume "e inHIDDENR3 omegaORDINAL1K4"
    then obtain a where 
      [ty]:"a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3" and aDef:"a = e"
       sorry
    have A3: " for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds ?P(a) implies ?P(succORDINAL1K1 a)"
    proof-
      have " for a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3 holds a inTARSKIR2 A implies succORDINAL1K1 a inTARSKIR2 A"
      proof(rule ballI,rule impI)
        obtain rone where 
          [ty]:"rone be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and roneDef:"rone = oneARYTM-3K13"
          using arytm_2_th_1 sorry
        fix a assume [ty]: "a be naturalORDINAL1V7\<bar>OrdinalORDINAL1M3"
        assume A4: "a inTARSKIR2 A"
        obtain i where 
          [ty]:"i be ElementSUBSET-1M1-of omegaORDINAL1K4" and iDef:"i = a"
          using ordinal1_def_12 sorry
        have A5: "a inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_12 sorry
        then have "a inTARSKIR2 RAT+ARYTM-3K5"
          using arytm_2_lm_5 sorry
        then obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and xDef:"x = a"
          using arytm_2_th_1 sorry
        obtain x9 y9 where
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A6: "x =XBOOLE-0R4 x9 & rone =XBOOLE-0R4 y9"and A7: "x +ARYTM-2K7 rone =XBOOLE-0R4 x9 +ARYTM-3K10 y9"
          using A5 arytm_2_lm_5 arytm_2_lm_47 sorry
        have "x9 +ARYTM-3K10 y9 =HIDDENR1 i +^ORDINAL2K10 \<one>\<^sub>M"
          using A6 arytm_2_lm_45 sorry
        also have "... = succORDINAL1K1 i"
          using ordinal2_th_31 sorry
        finally have "x9 +ARYTM-3K10 y9 =HIDDENR1 succORDINAL1K1 i"
           sorry
        thus "succORDINAL1K1 a inTARSKIR2 A"
          using A2 A4 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "?P(a)"
      using ordinal2_sch_17 A1 A3 sorry
    thus "e inHIDDENR3 A"
       sorry
  qed "sorry"
  thus "omegaORDINAL1K4 c=TARSKIR1 A"
    using tarski_def_3 sorry
qed "sorry"

mtheorem arytm_2_th_18:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 omegaORDINAL1K4 implies ( for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds y inTARSKIR2 x iff (y inTARSKIR2 omegaORDINAL1K4 & y <>HIDDENR2 x) & y <='ARYTM-2R1 x)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 omegaORDINAL1K4 implies ( for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds (y inTARSKIR2 x implies y inTARSKIR2 omegaORDINAL1K4 & (y <>HIDDENR2 x & y <='ARYTM-2R1 x)) & (y inTARSKIR2 omegaORDINAL1K4 implies (y <>HIDDENR2 x implies (y <='ARYTM-2R1 x implies y inTARSKIR2 x))))"
  proof(rule ballI,rule impI,rule ballI,rule conjMI,rule impI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x inTARSKIR2 omegaORDINAL1K4"
    then obtain m where 
      [ty]:"m be ElementSUBSET-1M1-of omegaORDINAL1K4" and mDef:"m = x"
       sorry
    obtain x9 where 
      [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
      using A1 arytm_2_lm_5 sorry
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    have A2: "x c=TARSKIR1 omegaORDINAL1K4"
      using A1 ordinal1_def_2 sorry
    show "y inTARSKIR2 x implies y inTARSKIR2 omegaORDINAL1K4 & (y <>HIDDENR2 x & y <='ARYTM-2R1 x)"
    proof(rule impI,rule conjMI,rule conjMI)
      assume A3: "y inTARSKIR2 x"
      then obtain n where 
        [ty]:"n be ElementSUBSET-1M1-of omegaORDINAL1K4" and nDef:"n = y"
        using A2 sorry
      show "y inTARSKIR2 omegaORDINAL1K4"
        using A2 A3 sorry
      then obtain y9 where 
        [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
        using arytm_2_lm_5 sorry
      show "y <>HIDDENR2 x"
        using A3 sorry
      have "n c=ORDINAL1R1 m"
        using A3 ordinal1_def_2 sorry
      then obtain C where
        [ty]:"C be OrdinalORDINAL1M3" and 
        A4: "m =XBOOLE-0R4 n +^ORDINAL2K10 C"
        using ordinal3_th_27 sorry
      have "C c=ORDINAL1R1 m"
        using A4 ordinal3_th_24 sorry
      then have 
        [ty]:"C be ElementSUBSET-1M1-of omegaORDINAL1K4"
        using ordinal1_th_12 sorry
      obtain z9 where 
        [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and z9Def:"z9 = C"
        using arytm_2_lm_5 sorry
      have "x9 =XBOOLE-0R4 y9 +ARYTM-3K10 z9"
        using A4 arytm_2_lm_45 sorry
      then have "y9 <='ARYTM-3R3 x9"
         sorry
      thus "y <='ARYTM-2R1 x"
        using arytm_2_lm_14 sorry
    qed
    assume A5: "y inTARSKIR2 omegaORDINAL1K4"
    then obtain y9 where 
      [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
      using arytm_2_lm_5 sorry
    obtain n where 
      [ty]:"n be ElementSUBSET-1M1-of omegaORDINAL1K4" and nDef:"n = y"
      using A5 sorry
    assume A6: "y <>HIDDENR2 x"
    assume "y <='ARYTM-2R1 x"
    then have "y9 <='ARYTM-3R3 x9"
      using arytm_2_lm_14 sorry
    then obtain z9 where
      [ty]:"z9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
      A7: "y9 +ARYTM-3K10 z9 =XBOOLE-0R4 x9"
       sorry
    obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of omegaORDINAL1K4" and kDef:"k = z9"
      using A1 A5 A7 arytm_3_th_71 sorry
    have "n +^ORDINAL2K10 k =XBOOLE-0R4 m"
      using A7 arytm_2_lm_45 sorry
    then have "n c=ORDINAL1R1 m"
      using ordinal3_th_24 sorry
    then have "n c<XBOOLE-0R2 m"
      using A6 sorry
    thus "y inTARSKIR2 x"
      using ordinal1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_19:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 y +ARYTM-2K7 z implies z <='ARYTM-2R1 x"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for z be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x =XBOOLE-0R4 y +ARYTM-2K7 z implies ( not z <='ARYTM-2R1 x implies  not  True )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    obtain zz where 
      [ty]:"zz be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and zzDef:"zz = {}ARYTM-3K12"
      using arytm_2_th_1 sorry
    assume A1: "x =XBOOLE-0R4 y +ARYTM-2K7 z"
    assume A2: " not z <='ARYTM-2R1 x"
    then obtain y0 where
      [ty]:"y0 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
      A3: "x +ARYTM-2K7 y0 =XBOOLE-0R4 z"
      using arytm_2_th_9 sorry
    have "x =XBOOLE-0R4 x +ARYTM-2K7 (y +ARYTM-2K7 y0)"
      using A1 A3 arytm_2_th_6 sorry
    then have "x +ARYTM-2K7 zz =XBOOLE-0R4 x +ARYTM-2K7 (y +ARYTM-2K7 y0)"
      using arytm_2_def_8 sorry
    then have "y0 =XBOOLE-0R4 {}ARYTM-3K12"
      using arytm_2_th_5 arytm_2_th_11 sorry
    then have "z =XBOOLE-0R4 x"
      using A3 arytm_2_def_8 sorry
    thus " not  True "
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem arytm_2_th_20:
"{}ARYTM-3K12 inTARSKIR2 REAL+ARYTM-2K2 & oneARYTM-3K13 inTARSKIR2 REAL+ARYTM-2K2"
  using arytm_2_th_1 sorry

mtheorem arytm_2_th_21:
" for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & x *'ARYTM-2K8 y =XBOOLE-0R4 x9 *'ARYTM-3K11 y9)"
proof-
  have " for x be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for y be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds x inTARSKIR2 RAT+ARYTM-3K5 & y inTARSKIR2 RAT+ARYTM-3K5 implies ( ex tVar41 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar42 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar41 & (y =XBOOLE-0R4 tVar42 & x *'ARYTM-2K8 y =HIDDENR1 tVar41 *'ARYTM-3K11 tVar42))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
    assume A1: "x inTARSKIR2 RAT+ARYTM-3K5"
      and A2: "y inTARSKIR2 RAT+ARYTM-3K5"
    show " ex tVar41 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar42 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar41 & (y =XBOOLE-0R4 tVar42 & x *'ARYTM-2K8 y =HIDDENR1 tVar41 *'ARYTM-3K11 tVar42)"
    proof-
      have cases: "(x =XBOOLE-0R4 {}ARYTM-3K12 or y =XBOOLE-0R4 {}ARYTM-3K12) or y <>HIDDENR2 {}ARYTM-3K12 & x <>HIDDENR2 {}ARYTM-3K12"
         sorry
      have case1: "x =XBOOLE-0R4 {}ARYTM-3K12 implies ( ex tVar41 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar42 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar41 & (y =XBOOLE-0R4 tVar42 & x *'ARYTM-2K8 y =HIDDENR1 tVar41 *'ARYTM-3K11 tVar42))"
      proof(rule impI)
        assume A3: "x =XBOOLE-0R4 {}ARYTM-3K12"
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and y9Def:"y9 = y"
          using A2 sorry
        show " ex tVar41 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar42 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar41 & (y =XBOOLE-0R4 tVar42 & x *'ARYTM-2K8 y =HIDDENR1 tVar41 *'ARYTM-3K11 tVar42)"
        proof(rule bexI[of _ "{}ARYTM-3K12"])
          show " ex tVar42 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 {}ARYTM-3K12 & (y =XBOOLE-0R4 tVar42 & x *'ARYTM-2K8 y =HIDDENR1 ({}ARYTM-3K12)*'ARYTM-3K11 tVar42)"
          proof(rule bexI[of _ "y9"],rule conjMI,rule conjMI)
            show "x =XBOOLE-0R4 {}ARYTM-3K12"
              using A3 sorry
            show "y =XBOOLE-0R4 y9"
               sorry
            have "x *'ARYTM-2K8 y =HIDDENR1 {}ARYTM-3K12"
              using A3 arytm_2_th_4 sorry
            also have "... = ({}ARYTM-3K12)*'ARYTM-3K11 y9"
              using arytm_3_th_48 sorry
            finally show "x *'ARYTM-2K8 y =HIDDENR1 ({}ARYTM-3K12)*'ARYTM-3K11 y9"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: "y =XBOOLE-0R4 {}ARYTM-3K12 implies ( ex tVar43 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar44 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar43 & (y =XBOOLE-0R4 tVar44 & x *'ARYTM-2K8 y =HIDDENR1 tVar43 *'ARYTM-3K11 tVar44))"
      proof(rule impI)
        assume A4: "y =XBOOLE-0R4 {}ARYTM-3K12"
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and x9Def:"x9 = x"
          using A1 sorry
        show " ex tVar43 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar44 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 tVar43 & (y =XBOOLE-0R4 tVar44 & x *'ARYTM-2K8 y =HIDDENR1 tVar43 *'ARYTM-3K11 tVar44)"
        proof(rule bexI[of _ "x9"])
          show " ex tVar44 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st x =XBOOLE-0R4 x9 & (y =XBOOLE-0R4 tVar44 & x *'ARYTM-2K8 y =HIDDENR1 x9 *'ARYTM-3K11 tVar44)"
          proof(rule bexI[of _ "{}ARYTM-3K12"],rule conjMI,rule conjMI)
            show "x =XBOOLE-0R4 x9"
               sorry
            show "y =XBOOLE-0R4 {}ARYTM-3K12"
              using A4 sorry
            have "x *'ARYTM-2K8 y =HIDDENR1 {}ARYTM-3K12"
              using A4 arytm_2_th_4 sorry
            also have "... = x9 *'ARYTM-3K11 ({}ARYTM-3K12)"
              using arytm_3_th_48 sorry
            finally show "x *'ARYTM-2K8 y =HIDDENR1 x9 *'ARYTM-3K11 ({}ARYTM-3K12)"
               sorry
          qed "sorry"
        qed "sorry"
      qed
      have case3: "y <>HIDDENR2 {}ARYTM-3K12 & x <>HIDDENR2 {}ARYTM-3K12 implies ( ex tVar45 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar46 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 tVar45 & y =XBOOLE-0R4 tVar46) & x *'ARYTM-2K8 y =XBOOLE-0R4 tVar45 *'ARYTM-3K11 tVar46)"
      proof(rule impMI ,rule impI)
        assume "y <>HIDDENR2 {}ARYTM-3K12"
          and A5: "x <>HIDDENR2 {}ARYTM-3K12"
        obtain y9 where
          [ty]:"y9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A6: "y =XBOOLE-0R4 y9"and A7: "DEDEKIND-CUTARYTM-2K3 y =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 y9 }"
          using A2 arytm_2_def_3 sorry
        let ?A = "DEDEKIND-CUTARYTM-2K3 x"
        let ?B = "DEDEKIND-CUTARYTM-2K3 y"
        obtain x9 where
          [ty]:"x9 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A8: "x =XBOOLE-0R4 x9"and A9: "DEDEKIND-CUTARYTM-2K3 x =XBOOLE-0R4 {s where s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 : s <ARYTM-3R4 x9 }"
          using A1 arytm_2_def_3 sorry
        have A10: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y iff s <ARYTM-3R4 x9 *'ARYTM-3K11 y9"
        proof-
          have " for s2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds (s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y implies s2 <ARYTM-3R4 x9 *'ARYTM-3K11 y9) & (s2 <ARYTM-3R4 x9 *'ARYTM-3K11 y9 implies s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y)"
          proof(rule ballI,rule conjMI,rule impI)
            fix s2 assume [ty]: "s2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5"
            show "s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y implies s2 <ARYTM-3R4 x9 *'ARYTM-3K11 y9"
            proof-
              have "s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y implies  not s2 <ARYTM-3R4 x9 *'ARYTM-3K11 y9"
              proof(rule impI)
                assume "s2 inTARSKIR2 ?A *'ARYTM-2K6 ?B"
                then obtain r1 s1 where
                  [ty]:"r1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" "s1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
                  A11: "s2 =XBOOLE-0R4 r1 *'ARYTM-3K11 s1"and A12: "r1 inTARSKIR2 ?A"and A13: "s1 inTARSKIR2 ?B"
                   sorry
                have " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 r1 & s <ARYTM-3R4 x9"
                  using A9 A12 sorry
                then have A14: "r1 *'ARYTM-3K11 s1 <='ARYTM-3R3 x9 *'ARYTM-3K11 s1"
                  using arytm_3_th_82 sorry
                have A15: " ex s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st s =XBOOLE-0R4 s1 & s <ARYTM-3R4 y9"
                  using A7 A13 sorry
                then have "s1 <>HIDDENR2 y9"
                   sorry
                then have A16: "x9 *'ARYTM-3K11 s1 <>HIDDENR2 x9 *'ARYTM-3K11 y9"
                  using A5 A8 arytm_3_th_56 sorry
                have "x9 *'ARYTM-3K11 s1 <='ARYTM-3R3 x9 *'ARYTM-3K11 y9"
                  using A15 arytm_3_th_82 sorry
                then have "x9 *'ARYTM-3K11 s1 <ARYTM-3R4 x9 *'ARYTM-3K11 y9"
                  using A16 arytm_3_th_68 sorry
                thus " not s2 <ARYTM-3R4 x9 *'ARYTM-3K11 y9"
                  using A11 A14 arytm_3_th_69 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            assume A17: "s2 <ARYTM-3R4 x9 *'ARYTM-3K11 y9"
            then obtain t0 where
              [ty]:"t0 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A18: "s2 =XBOOLE-0R4 x9 *'ARYTM-3K11 t0"and A19: "t0 <='ARYTM-3R3 y9"
              using arytm_3_th_79 sorry
            have "t0 <>HIDDENR2 y9"
              using A17 A18 sorry
            then have "t0 <ARYTM-3R4 y9"
              using A19 arytm_3_th_68 sorry
            then obtain t1 where
              [ty]:"t1 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A20: "t0 <ARYTM-3R4 t1"and A21: "t1 <ARYTM-3R4 y9"
              using arytm_3_th_93 sorry
            have "s2 <='ARYTM-3R3 t1 *'ARYTM-3K11 x9"
              using A18 A20 arytm_3_th_82 sorry
            then obtain t2 where
              [ty]:"t2 be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
              A22: "s2 =XBOOLE-0R4 t1 *'ARYTM-3K11 t2"and A23: "t2 <='ARYTM-3R3 x9"
              using arytm_3_th_79 sorry
            have "t2 =XBOOLE-0R4 x9 implies  False "
            proof(rule impI)
              assume "t2 =XBOOLE-0R4 x9"
              then have "t0 =XBOOLE-0R4 t1"
                using A5 A8 A18 A22 arytm_3_th_56 sorry
              thus " False "
                using A20 sorry
            qed
            then have "t2 <ARYTM-3R4 x9"
              using A23 arytm_3_th_68 sorry
            then have A24: "t2 inTARSKIR2 ?A"
              using A9 sorry
            have "t1 inTARSKIR2 ?B"
              using A7 A21 sorry
            thus "s2 inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y"
              using A22 A24 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then obtain r where
          [ty]:"r be ElementSUBSET-1M1-of RAT+ARYTM-3K5" and 
          A25: "GLUEDARYTM-2K4 (DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y) =XBOOLE-0R4 r"and A26: " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s inTARSKIR2 DEDEKIND-CUTARYTM-2K3 x *'ARYTM-2K6 DEDEKIND-CUTARYTM-2K3 y iff s <ARYTM-3R4 r"
          using arytm_2_def_4 sorry
        show " ex tVar45 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st  ex tVar46 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 tVar45 & y =XBOOLE-0R4 tVar46) & x *'ARYTM-2K8 y =XBOOLE-0R4 tVar45 *'ARYTM-3K11 tVar46"
        proof(rule bexI[of _ "x9"])
          show " ex tVar46 be ElementSUBSET-1M1-of RAT+ARYTM-3K5 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 tVar46) & x *'ARYTM-2K8 y =XBOOLE-0R4 x9 *'ARYTM-3K11 tVar46"
          proof(rule bexI[of _ "y9"],rule conjMI)
            show "x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9"
              using A8 A6 sorry
            have " for s be ElementSUBSET-1M1-of RAT+ARYTM-3K5 holds s <ARYTM-3R4 x9 *'ARYTM-3K11 y9 iff s <ARYTM-3R4 r"
              using A10 A26 sorry
            thus "x *'ARYTM-2K8 y =XBOOLE-0R4 x9 *'ARYTM-3K11 y9"
              using A25 arytm_2_lm_6 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
