theory cfcont_1
  imports cfunct_1 comseq_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, n1, m, m1, k for "NatNAT-1M1"
reserve x, X, X1 for "setHIDDENM2"
reserve g, g1, g2, t, x0, x1, x2 for "ComplexXCMPLX-0M1"
reserve s1, s2, q1, seq, seq1, seq2, seq3 for "Complex-SequenceCOMSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
reserve f, f1, f2, h, h1, h2 for "PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
reserve p, r, s for "RealXREAL-0M1"
reserve Ns, Nseq for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mdef cfcont_1_def_1 (" _ is-continuous-inCFCONT-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "x0 be ComplexXCMPLX-0M1"
"pred f is-continuous-inCFCONT-1R1 x0 means
  x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0 implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"..

mtheorem cfcont_1_th_1:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 iff ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)) & (( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    show "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
    proof-
      have "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 implies ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
      proof(rule impI)
        assume A1: "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
        have " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A2: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
            using A1 valued_1_th_1 A2 sorry
          then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-XCMPLX-0K4 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
            using valued_1_th_8 sorry
          thus "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
             sorry
        qed "sorry"
        thus " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using A3 sorry
      also have "... = seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-XCMPLX-0K4 seq3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_8 sorry
      also have "... = (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_2:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds ((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns & (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns) & (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 *COMSEQ-3K9 Ns)"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns & ((seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns & (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 *COMSEQ-3K9 Ns))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 *COMSEQ-3K9 Ns +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n) +XCMPLX-0K2 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using valued_1_th_1 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 *COMSEQ-3K9 Ns +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 *COMSEQ-3K9 Ns -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n) -XCMPLX-0K6 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using cfcont_1_th_1 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 (seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using cfcont_1_th_1 sorry
      finally show "((seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 *COMSEQ-3K9 Ns -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Ns -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 *COMSEQ-3K9 Ns"
      using funct_2_th_63 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 *COMSEQ-3K9 Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = seq1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n) *XCMPLX-0K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using valued_1_th_5 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (seq1 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq2 *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = ((seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 *COMSEQ-3K9 Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 *COMSEQ-3K9 Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 *COMSEQ-3K9 Ns)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_3:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
proof-
  have " for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
  proof(rule ballI,rule ballI,rule ballI)
    fix g assume [ty]: "g be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = g *XCMPLX-0K3 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using valued_1_th_6 sorry
      also have "... = g *XCMPLX-0K3 (seq *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      finally show "((g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_4:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns & ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns .|"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =HIDDENR1 -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns & ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns .|"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have "(-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =HIDDENR1 ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns"
      using comseq_1_th_11 sorry
    also have "... = (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
      using cfcont_1_th_3 sorry
    also have "... = -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns"
      using comseq_1_th_11 sorry
    finally show "(-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =HIDDENR1 -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns .|).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... =  |.COMPLEX1K10 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n).|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 (seq *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n.|"
        using funct_2_th_15 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns .|).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using valued_1_th_18 sorry
      finally show "(( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns .|).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns .|"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_5:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq *COMSEQ-3K9 Ns)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq *COMSEQ-3K9 Ns)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq *COMSEQ-3K9 Ns)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq *COMSEQ-3K9 Ns)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using valued_1_th_10 sorry
      also have "... = (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n))\<inverse>XCMPLX-0K5"
        using funct_2_th_15 sorry
      also have "... = seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)"
        using valued_1_th_10 sorry
      also have "... = (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using funct_2_th_15 sorry
      finally show "(seq *COMSEQ-3K9 Ns)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq *COMSEQ-3K9 Ns)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_6:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 *COMSEQ-3K9 Ns)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =HIDDENR1 (seq1 *COMSEQ-3K9 Ns)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have "(seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =HIDDENR1 (seq1 *COMSEQ-3K9 Ns)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> *COMSEQ-3K9 Ns)"
      using cfcont_1_th_2 sorry
    also have "... = (seq1 *COMSEQ-3K9 Ns)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
      using cfcont_1_th_5 sorry
    finally show "(seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)*COMSEQ-3K9 Ns =HIDDENR1 (seq1 *COMSEQ-3K9 Ns)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_7:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2 implies ((h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & (h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) & (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2 implies (h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & ((h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    have A1: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1"
      using xboole_1_th_17 sorry
    have A2: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2"
      using xboole_1_th_17 sorry
    assume A3: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2"
    then have A4: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)"
      using valued_1_def_1 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A5: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A4 funct_2_th_109 sorry
      also have "... = h1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) +XCMPLX-0K2 h2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A4 A5 cfunct_1_th_1 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 h2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A3 A1 funct_2_th_109 xboole_1_th_1 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using A3 A2 funct_2_th_109 xboole_1_th_1 sorry
      also have "... = (h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "(h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using funct_2_th_63 sorry
    have A6: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)"
      using A3 cfunct_1_th_2 sorry
    have " for n be NatNAT-1M1 holds (h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A7: "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A8: "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using A6 funct_2_th_109 A7 sorry
      also have "... = h1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -XCMPLX-0K6 h2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using A6 A8 cfunct_1_th_2 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 h2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using A3 A1 funct_2_th_109 xboole_1_th_1 A7 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using A3 A2 funct_2_th_109 xboole_1_th_1 A7 sorry
      finally show "(h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using cfcont_1_th_1 sorry
    have A9: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)"
      using A3 valued_1_def_4 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A10: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A9 funct_2_th_109 sorry
      also have "... = h1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) *XCMPLX-0K3 h2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A9 A10 cfunct_1_th_3 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 h2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A3 A1 funct_2_th_109 xboole_1_th_1 sorry
      also have "... = h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using A3 A2 funct_2_th_109 xboole_1_th_1 sorry
      also have "... = (h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "(h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_8:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix g assume [ty]: "g be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h"
    then have A2: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)"
      using valued_1_def_5 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A3: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A2 funct_2_th_109 sorry
      also have "... = g *XCMPLX-0K3 h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A2 A3 cfunct_1_th_4 sorry
      also have "... = g *XCMPLX-0K3 h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using A1 funct_2_th_109 sorry
      also have "... = (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      finally show "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_9:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  using cfcont_1_th_8 sorry

mtheorem cfcont_1_th_10:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) implies h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) implies h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9"
  proof(rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
    then have A2: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_def_2 xboole_1_th_36 sorry
    have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies  False "
    proof(rule impI)
      assume Given: " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
      then obtain n where
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A3: "h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
         sorry
      have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_28 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
        using A1 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using cfunct_1_def_2 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h &  not seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using xboole_0_def_5 sorry
      then have A4: " not h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
        using partfun2_th_26 sorry
      have "h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 0cCOMPLEX1K6"
        using A2 A3 funct_2_th_109 xboole_1_th_1 sorry
      thus " False "
        using A4 tarski_def_1 sorry
    qed
    thus "h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9"
      using comseq_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_11:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) implies (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) implies (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
  proof(rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
    then have A2: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using cfunct_1_def_2 xboole_1_th_36 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A3: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_28 sorry
      have "(h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A1 funct_2_th_109 sorry
      also have "... = (h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))\<inverse>XCMPLX-0K5"
        using A1 A3 cfunct_1_def_2 sorry
      also have "... = (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using A2 funct_2_th_109 xboole_1_th_1 sorry
      also have "... = (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "(h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_12:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    assume A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "seq *COMSEQ-3K9 Ns be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq"
        using valued_0_def_17 sorry
      then have A2: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns) c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_21 sorry
      have "ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 ((h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n))"
        using funct_2_th_15 sorry
      also have "... = ReCOMPLEX1K3 (h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)))"
        using A1 funct_2_th_109 sorry
      also have "... = ReCOMPLEX1K3 (h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((seq *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))"
        using funct_2_th_15 sorry
      also have "... = ReCOMPLEX1K3 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A1 A2 funct_2_th_109 xboole_1_th_1 sorry
      also have "... = ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      finally show "ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_13:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h implies ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix Ns assume [ty]: "Ns be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    assume A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "seq *COMSEQ-3K9 Ns be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq"
        using valued_0_def_17 sorry
      then have A2: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns) c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_21 sorry
      have "ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMPLEX1K4 ((h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n))"
        using funct_2_th_15 sorry
      also have "... = ImCOMPLEX1K4 (h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Ns .RECDEF-1K1 n)))"
        using A1 funct_2_th_109 sorry
      also have "... = ImCOMPLEX1K4 (h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((seq *COMSEQ-3K9 Ns).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))"
        using funct_2_th_15 sorry
      also have "... = ImCOMPLEX1K4 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A1 A2 funct_2_th_109 xboole_1_th_1 sorry
      also have "... = ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      finally show "ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns)) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Ns) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq *COMSEQ-3K9 Ns))"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_14:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds h1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> implies ((h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & (h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) & (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds h1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> implies (h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & ((h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & (h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h1 assume [ty]: "h1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix h2 assume [ty]: "h2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume "h1 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & h2 be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2) =XBOOLE-0R4 COMPLEXNUMBERSK3"
      using partfun1_def_2 sorry
    then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2 =XBOOLE-0R4 COMPLEXNUMBERSK3"
      using valued_1_def_1 sorry
    then have A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h2"
       sorry
    thus "(h1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using cfcont_1_th_7 sorry
    show "(h1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using A1 cfcont_1_th_7 sorry
    show "(h1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using A1 cfcont_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_15:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds h be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds h be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix g assume [ty]: "g be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume "h be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h =XBOOLE-0R4 COMPLEXNUMBERSK3"
      using partfun1_def_2 sorry
    then have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h"
       sorry
    thus "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> h)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> h /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using cfcont_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_16:
" for X be setHIDDENM2 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) & h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) & h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
      and A2: "h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq implies x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
        using A1 sorry
      then have A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
        using relat_1_th_61 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using A2 xboole_0_def_4 sorry
      then have A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
        using cfunct_1_def_2 sorry
      have "x inHIDDENR3 X"
        using A3 xboole_0_def_4 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
        using A4 xboole_0_def_4 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
    qed "sorry"
    then have A5: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A6: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
        using valued_0_th_28 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
        using A1 sorry
      then have A7: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
        using relat_1_th_61 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> h \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using A2 xboole_0_def_4 sorry
      then have A8: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
        using cfunct_1_def_2 sorry
      have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 X"
        using A7 xboole_0_def_4 sorry
      then have "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
        using A8 xboole_0_def_4 sorry
      then have A9: "seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have "((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A5 funct_2_th_109 sorry
      also have "... = (h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
        using A9 partfun2_th_15 sorry
      also have "... = (h /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))\<inverse>XCMPLX-0K5"
        using A8 cfunct_1_def_2 sorry
      also have "... = ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))\<inverse>XCMPLX-0K5"
        using A1 A6 partfun2_th_15 sorry
      also have "... = ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using A1 funct_2_th_109 sorry
      also have "... = ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "((h ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((h  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_17:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq be convergentCOMSEQ-2V3 implies seq1 be convergentCOMSEQ-2V3"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq be convergentCOMSEQ-2V3 implies seq1 be convergentCOMSEQ-2V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq"
      and A2: "seq be convergentCOMSEQ-2V3"
    obtain g where
      [ty]:"g be ComplexXCMPLX-0M1" and 
      A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      using A2 sorry
    obtain t where 
      [ty]:"t be ComplexXCMPLX-0M1" and tDef:"t = g"
       sorry
    have " ex t be ComplexXCMPLX-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 t .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "t"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        using A3 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 t .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "n <=XXREAL-0R1 m"
        obtain Nseq where
          [ty]:"Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
          A6: "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Nseq"
          using A1 valued_0_def_17 sorry
        have "m <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using seqm_3_th_14 sorry
        then have A7: "n <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using A5 xxreal_0_th_2 sorry
        have "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Nseq .RECDEF-1K1 m)"
          using A6 funct_2_th_15 sorry
        thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 t .| <XXREAL-0R3 p"
          using A4 A7 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be convergentCOMSEQ-2V3"
      using comseq_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_18:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq be convergentCOMSEQ-2V3 implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq be convergentCOMSEQ-2V3 implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq"
      and A2: "seq be convergentCOMSEQ-2V3"
    obtain Nseq where
      [ty]:"Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A3: "seq1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq *COMSEQ-3K9 Nseq"
      using A1 valued_0_def_17 sorry
    have A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
        using A2 comseq_2_def_6 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A6: "n <=XXREAL-0R1 m"
        have "m <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using seqm_3_th_14 sorry
        then have A7: "n <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using A6 xxreal_0_th_2 sorry
        have A8: "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (Nseq .RECDEF-1K1 m)"
          using A3 funct_2_th_15 A8 sorry
        thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
          using A5 A7 sorry
      qed "sorry"
    qed "sorry"
    have "seq1 be convergentCOMSEQ-2V3"
      using A1 A2 cfcont_1_th_17 sorry
    thus "limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
      using A4 comseq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_19:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies seq1 be convergentCOMSEQ-2V3"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies seq1 be convergentCOMSEQ-2V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be convergentCOMSEQ-2V3"
      and A2: " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    obtain g1 where
      [ty]:"g1 be ComplexXCMPLX-0M1" and 
      A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
      using A1 sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      using A2 sorry
    obtain g where 
      [ty]:"g be ComplexXCMPLX-0M1" and gDef:"g = g1"
       sorry
    have " ex g be ComplexXCMPLX-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
        using A3 sorry
      have A6: "n1 <=XXREAL-0R1 k implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A7: "n1 <=XXREAL-0R1 k"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = k"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A8: "n <=XXREAL-0R1 m"
          then have "n1 <=XXREAL-0R1 m"
            using A7 xxreal_0_th_2 sorry
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
            using A5 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A4 A8 sorry
        qed "sorry"
      qed
      have "k <=XXREAL-0R1 n1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A9: "k <=XXREAL-0R1 n1"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A10: "n <=XXREAL-0R1 m"
          then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
            using A4 A9 xxreal_0_th_2 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A5 A10 sorry
        qed "sorry"
      qed
      thus " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        using A6 sorry
    qed "sorry"
    thus "seq1 be convergentCOMSEQ-2V3"
      using comseq_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_20:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies limCOMSEQ-2K3 seq =COMPLEX1R1 limCOMSEQ-2K3 seq1"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies limCOMSEQ-2K3 seq =COMPLEX1R1 limCOMSEQ-2K3 seq1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be convergentCOMSEQ-2V3"
      and A2: " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A3: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      using A2 sorry
    have A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
        using A1 comseq_2_def_6 sorry
      have A6: "n1 <=XXREAL-0R1 k implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A7: "n1 <=XXREAL-0R1 k"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = k"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A8: "n <=XXREAL-0R1 m"
          then have "n1 <=XXREAL-0R1 m"
            using A7 xxreal_0_th_2 sorry
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
            using A5 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
            using A3 A8 sorry
        qed "sorry"
      qed
      have "k <=XXREAL-0R1 n1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A9: "k <=XXREAL-0R1 n1"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A10: "n <=XXREAL-0R1 m"
          then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
            using A3 A9 xxreal_0_th_2 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
            using A5 A10 sorry
        qed "sorry"
      qed
      thus " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
        using A6 sorry
    qed "sorry"
    have "seq1 be convergentCOMSEQ-2V3"
      using A1 A2 cfcont_1_th_19 sorry
    thus "limCOMSEQ-2K3 seq =COMPLEX1R1 limCOMSEQ-2K3 seq1"
      using A4 comseq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_21:
" for k be NatNAT-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 implies seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) =COMPLEX1R1 limCOMSEQ-2K3 seq"
  using cfcont_1_th_17 cfcont_1_th_18 sorry

mtheorem cfcont_1_th_22:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies seq1 be convergentCOMSEQ-2V3"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies seq1 be convergentCOMSEQ-2V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be convergentCOMSEQ-2V3"
      and A2: " ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A3: "seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using A2 sorry
    obtain g1 where
      [ty]:"g1 be ComplexXCMPLX-0M1" and 
      A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
      using A1 sorry
    obtain g where 
      [ty]:"g be ComplexXCMPLX-0M1" and gDef:"g = g1"
       sorry
    have " ex g be ComplexXCMPLX-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
        using A4 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 k"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A6: "n <=XXREAL-0R1 m"
        then obtain l where
          [ty]:"l be NatNAT-1M1" and 
          A7: "m =COMPLEX1R1 (n1 +XCMPLX-0K2 k)+XCMPLX-0K2 l"
          using nat_1_th_10 sorry
        have 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "m -XCMPLX-0K6 k =COMPLEX1R1 ((n1 +NAT-1K1 l)+XCMPLX-0K2 k)+XCMPLX-0K2 (-XCMPLX-0K4 k)"
          using A7 sorry
        then obtain m1 where
          [ty]:"m1 be NatNAT-1M1" and 
          A8: "m1 =COMPLEX1R1 m -XCMPLX-0K6 k"
           sorry
        have " not n1 <=XXREAL-0R1 m1 implies  False "
        proof(rule impI)
          assume " not n1 <=XXREAL-0R1 m1"
          then have "m1 +XCMPLX-0K2 k <XXREAL-0R3 n1 +XCMPLX-0K2 k"
            using xreal_1_th_6 sorry
          thus " False "
            using A6 A8 sorry
        qed
        then have A9: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m1 -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
          using A5 sorry
        have "m1 +XCMPLX-0K2 k =COMPLEX1R1 m"
          using A8 sorry
        thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
          using A3 A9 nat_1_def_3 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be convergentCOMSEQ-2V3"
      using comseq_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_23:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & ( ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be convergentCOMSEQ-2V3"
      and A2: " ex k be NatNAT-1M1 st seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A3: "seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"
      using A2 sorry
    have A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
        using A1 comseq_2_def_6 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 k"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A6: "n <=XXREAL-0R1 m"
        then obtain l where
          [ty]:"l be NatNAT-1M1" and 
          A7: "m =COMPLEX1R1 (n1 +XCMPLX-0K2 k)+XCMPLX-0K2 l"
          using nat_1_th_10 sorry
        have 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "m -XCMPLX-0K6 k =COMPLEX1R1 ((n1 +NAT-1K1 l)+XCMPLX-0K2 k)+XCMPLX-0K2 (-XCMPLX-0K4 k)"
          using A7 sorry
        then obtain m1 where
          [ty]:"m1 be NatNAT-1M1" and 
          A8: "m1 =COMPLEX1R1 m -XCMPLX-0K6 k"
           sorry
        have " not n1 <=XXREAL-0R1 m1 implies  False "
        proof(rule impI)
          assume " not n1 <=XXREAL-0R1 m1"
          then have "m1 +XCMPLX-0K2 k <XXREAL-0R3 n1 +XCMPLX-0K2 k"
            using xreal_1_th_6 sorry
          thus " False "
            using A6 A8 sorry
        qed
        then have A9: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m1 -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
          using A5 sorry
        have "m1 +XCMPLX-0K2 k =COMPLEX1R1 m"
          using A8 sorry
        thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 seq .| <XXREAL-0R3 p"
          using A3 A9 nat_1_def_3 sorry
      qed "sorry"
    qed "sorry"
    have "seq1 be convergentCOMSEQ-2V3"
      using A1 A2 cfcont_1_th_22 sorry
    thus "limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
      using A4 comseq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_24:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9)"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be convergentCOMSEQ-2V3"
      and A2: "limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6"
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A3: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies ( |.COMPLEX1K10 limCOMSEQ-2K3 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m.|"
      using A1 A2 comseq_2_th_33 sorry
    obtain k where 
      [ty]:"k be NatNAT-1M1" and kDef:"k = n1"
       sorry
    show " ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9"
    proof(rule bexI[of _ "k"])
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "0NUMBERSK6 +XCMPLX-0K2 k <=XXREAL-0R1 n +XCMPLX-0K2 k"
          using xreal_1_th_7 sorry
        then have "( |.COMPLEX1K10 limCOMSEQ-2K3 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k).|"
          using A3 sorry
        then have A4: "( |.COMPLEX1K10 limCOMSEQ-2K3 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n.|"
          using nat_1_def_3 sorry
        have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 limCOMSEQ-2K3 seq .|"
          using A2 complex1_th_47 sorry
        then have "(0NUMBERSK6)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ( |.COMPLEX1K10 limCOMSEQ-2K3 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_74 sorry
        then have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n.|"
          using A4 sorry
        thus "(seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
          using complex1_th_47 sorry
      qed "sorry"
      thus "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9"
        using comseq_1_th_4 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_25:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( ex seq1 be Complex-SequenceCOMSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( ex tVar13 be Complex-SequenceCOMSEQ-1M1 st tVar13 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & tVar13 be non-zeroORDINAL1V9)"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9"
      using cfcont_1_th_24 sorry
    show " ex tVar13 be Complex-SequenceCOMSEQ-1M1 st tVar13 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & tVar13 be non-zeroORDINAL1V9"
    proof(rule bexI[of _ "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k"])
      show "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k be non-zeroORDINAL1V9"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_26:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 implies seq be convergentCOMSEQ-2V3"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 implies seq be convergentCOMSEQ-2V3"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume "seq be constantVALUED-0V15"
    then obtain t where
      [ty]:"t be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
      A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 t"
      using valued_0_def_18 sorry
    obtain g where 
      [ty]:"g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and gDef:"g = t"
       sorry
    have " ex g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain n where 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = 0NUMBERSK6"
         sorry
      show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 t -XCMPLX-0K6 g .|"
          using A1 sorry
        also have "... = 0NUMBERSK6"
          using complex1_th_44 sorry
        finally have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| =HIDDENR1 0NUMBERSK6"
           sorry
        thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
          using A2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be convergentCOMSEQ-2V3"
      using comseq_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_27:
" for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq or seq be constantVALUED-0V15 & ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g) implies limCOMSEQ-2K3 seq =COMPLEX1R1 g"
proof-
  have " for g be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq or seq be constantVALUED-0V15 & ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g) implies limCOMSEQ-2K3 seq =COMPLEX1R1 g"
  proof(rule ballI,rule ballI,rule impI)
    fix g assume [ty]: "g be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have A1: "seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq implies  not ( not ( not (seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq) &  not (seq be constantVALUED-0V15 &  not ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g))) &  not limCOMSEQ-2K3 seq =COMPLEX1R1 g)"
    proof(rule impMI ,rule impI)
      assume A2: "seq be constantVALUED-0V15"
        and A3: "g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
      obtain g1 where
        [ty]:"g1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
        A4: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq =XBOOLE-0R4 {TARSKIK1 g1}"
        using A2 funct_2_th_111 sorry
      obtain g2 where
        [ty]:"g2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
        A5: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g2"
        using A2 valued_0_def_18 sorry
      have A6: "g =COMPLEX1R1 g1"
        using A3 A4 tarski_def_1 sorry
      have A7: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A8: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          have "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
            using comseq_1_th_2 sorry
          then have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
            using funct_1_def_3 sorry
          then have "g2 inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
            using A5 sorry
          then have "g2 =COMPLEX1R1 g"
            using A4 A6 tarski_def_1 sorry
          then have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 g"
            using A5 sorry
          thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A8 complex1_th_44 sorry
        qed "sorry"
      qed "sorry"
      have "seq be convergentCOMSEQ-2V3"
        using A2 cfcont_1_th_26 sorry
      thus " not ( not ( not (seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq) &  not (seq be constantVALUED-0V15 &  not ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g))) &  not limCOMSEQ-2K3 seq =COMPLEX1R1 g)"
        using A7 comseq_2_def_6 sorry
    qed
    have A9: "seq be constantVALUED-0V15 & ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g) implies  not ( not ( not (seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq) &  not (seq be constantVALUED-0V15 &  not ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g))) &  not limCOMSEQ-2K3 seq =COMPLEX1R1 g)"
    proof(rule impMI ,rule impI)
      assume "seq be constantVALUED-0V15"
        and A10: " ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A11: "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g"
        using A10 sorry
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
        using comseq_1_th_2 sorry
      thus " not ( not ( not (seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq) &  not (seq be constantVALUED-0V15 &  not ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g))) &  not limCOMSEQ-2K3 seq =COMPLEX1R1 g)"
        using A1 A11 funct_1_def_3 sorry
    qed
    assume "seq be constantVALUED-0V15 & g inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq or seq be constantVALUED-0V15 & ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 g)"
    thus "limCOMSEQ-2K3 seq =COMPLEX1R1 g"
      using A1 A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_28:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 implies ( for n be NatNAT-1M1 holds limCOMSEQ-2K3 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
  using cfcont_1_th_27 sorry

mtheorem cfcont_1_th_29:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9 implies limCOMSEQ-2K3 seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =COMPLEX1R1 (limCOMSEQ-2K3 seq)\<inverse>XCMPLX-0K5)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6 implies ( for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9 implies limCOMSEQ-2K3 seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =COMPLEX1R1 (limCOMSEQ-2K3 seq)\<inverse>XCMPLX-0K5)"
  proof(rule ballI,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be convergentCOMSEQ-2V3"
      and A2: "limCOMSEQ-2K3 seq <>HIDDENR2 0NUMBERSK6"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A3: "seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq"
      and A4: "seq1 be non-zeroORDINAL1V9"
    have "limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq"
      using A1 A3 cfcont_1_th_18 sorry
    thus "limCOMSEQ-2K3 seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =COMPLEX1R1 (limCOMSEQ-2K3 seq)\<inverse>XCMPLX-0K5"
      using A1 A2 A3 A4 cfcont_1_th_17 comseq_2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_30:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 & seq1 be convergentCOMSEQ-2V3 implies ((limCOMSEQ-2K3 (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limCOMSEQ-2K3 seq1 & limCOMSEQ-2K3 (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limCOMSEQ-2K3 seq1) & limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =COMPLEX1R1 limCOMSEQ-2K3 seq1 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)) & limCOMSEQ-2K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =COMPLEX1R1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limCOMSEQ-2K3 seq1)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be constantVALUED-0V15 & seq1 be convergentCOMSEQ-2V3 implies limCOMSEQ-2K3 (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limCOMSEQ-2K3 seq1 & (limCOMSEQ-2K3 (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limCOMSEQ-2K3 seq1 & (limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 limCOMSEQ-2K3 seq1 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) & limCOMSEQ-2K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limCOMSEQ-2K3 seq1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be constantVALUED-0V15"
      and A2: "seq1 be convergentCOMSEQ-2V3"
    have A3: "seq be convergentCOMSEQ-2V3"
      using A1 cfcont_1_th_26 sorry
    then have "limCOMSEQ-2K3 (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 limCOMSEQ-2K3 seq +XCMPLX-0K2 limCOMSEQ-2K3 seq1"
      using A2 comseq_2_th_14 sorry
    also have "... = seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limCOMSEQ-2K3 seq1"
      using A1 cfcont_1_th_27 sorry
    finally show "limCOMSEQ-2K3 (seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limCOMSEQ-2K3 seq1"
       sorry
    have "limCOMSEQ-2K3 (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 limCOMSEQ-2K3 seq -XCMPLX-0K6 limCOMSEQ-2K3 seq1"
      using A2 A3 comseq_2_th_26 sorry
    also have "... = seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limCOMSEQ-2K3 seq1"
      using A1 cfcont_1_th_27 sorry
    finally show "limCOMSEQ-2K3 (seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limCOMSEQ-2K3 seq1"
       sorry
    have "limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 limCOMSEQ-2K3 seq1 -XCMPLX-0K6 limCOMSEQ-2K3 seq"
      using A2 A3 comseq_2_th_26 sorry
    also have "... = limCOMSEQ-2K3 seq1 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using A1 cfcont_1_th_27 sorry
    finally show "limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 limCOMSEQ-2K3 seq1 -XCMPLX-0K6 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
       sorry
    have "limCOMSEQ-2K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 (limCOMSEQ-2K3 seq)*XCMPLX-0K3 (limCOMSEQ-2K3 seq1)"
      using A2 A3 comseq_2_th_30 sorry
    also have "... = seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limCOMSEQ-2K3 seq1)"
      using A1 cfcont_1_th_27 sorry
    finally show "limCOMSEQ-2K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 seq .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limCOMSEQ-2K3 seq1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem cfcont_1_sch_1:
  fixes Pp2 
  assumes
    A1: " for n be NatNAT-1M1 holds  ex g be ComplexXCMPLX-0M1 st Pp2(n,g)"
  shows " ex s1 be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds Pp2(n,s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
  proof-
    have " ex tVar18 be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds Pp2(n,tVar18 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
    proof-
      have A2: " for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex ff be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st Pp2(t,ff)"
      proof-
        have " for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar17 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st Pp2(t,tVar17)"
        proof(rule ballI)
          fix t assume [ty]: "t be ElementSUBSET-1M1-of NATNUMBERSK1"
          obtain g where
            [ty]:"g be ComplexXCMPLX-0M1" and 
            A3: "Pp2(t,g)"
            using A1 sorry
          have 
            [ty]:"g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
            using xcmplx_0_def_2 sorry
          show " ex tVar17 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st Pp2(t,tVar17)"
          proof(rule bexI[of _ "g"])
            show "Pp2(t,g)"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of COMPLEXNUMBERSK3" and 
        A4: " for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds Pp2(t,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> t)"
        using funct_2_sch_3 A2 sorry
      obtain s where 
        [ty]:"s be Complex-SequenceCOMSEQ-1M1" and sDef:"s = f"
         sorry
      show " ex tVar18 be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds Pp2(n,tVar18 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
      proof(rule bexI[of _ "s"],rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        thus "Pp2(n,s .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

(*begin*)
mtheorem cfcont_1_th_31:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 iff x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
proof-
  have " for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f is-continuous-inCFCONT-1R1 x0 implies x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)) & (x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1) implies f is-continuous-inCFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    show "f is-continuous-inCFCONT-1R1 x0 implies x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
       sorry
    assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A2: " for s1 be Complex-SequenceCOMSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s2 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & (s2 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s2 =COMPLEX1R1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI)
      show "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A1 sorry
      fix s2 assume [ty]: "s2 be Complex-SequenceCOMSEQ-1M1"
      assume A3: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        and A4: "s2 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s2 =COMPLEX1R1 x0"
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
      proof-
        show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
        proof-
          have cases: "( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 x0) or ( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0)"
             sorry
          have case1: "( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
          proof(rule impI)
            assume " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 x0"
            then obtain N where
              [ty]:"N be NatNAT-1M1" and 
              A5: " for m be NatNAT-1M1 holds N <=XXREAL-0R1 m implies s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 x0"
               sorry
            have A6: " for n be NatNAT-1M1 holds (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have "s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 N) =COMPLEX1R1 x0"
                using A5 nat_1_th_12 sorry
              thus "(s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x0"
                using nat_1_def_3 sorry
            qed "sorry"
            have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N"
              using A3 valued_0_th_27 sorry
            have A8: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s2"
              using valued_0_th_21 sorry
            have A9: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p)"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be RealXREAL-0M1"
              assume A10: "p >XXREAL-0R4 0NUMBERSK6"
              obtain n where 
                [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
                 sorry
              show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
              proof(rule bexI[of _ "n"],rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume "n <=XXREAL-0R1 m"
                have "m inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                  using A3 A8 funct_2_th_109 xboole_1_th_1 sorry
                also have "... =  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                  using A6 sorry
                also have "... = 0NUMBERSK6"
                  using complex1_th_44 sorry
                finally have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1 0NUMBERSK6"
                   sorry
                thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                  using A10 sorry
              qed "sorry"
            qed "sorry"
            then have A11: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N) be convergentCOMSEQ-2V3"
               sorry
            then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> N)"
              using A9 A7 comseq_2_def_6 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
              using A11 A7 cfcont_1_th_18 cfcont_1_th_22 sorry
          qed
          have case2: "( for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
          proof(rule impI,rule conjMI)
            assume A12: " for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <=XXREAL-0R1 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0"
            let ?P2 = "\<lambda>Lamb1. \<lambda>Lamb2.  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds Lamb1 =XBOOLE-0R4 n & Lamb2 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0) & ( for k be NatNAT-1M1 holds n <XXREAL-0R3 k & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k)"
            let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. ?P2(Lamb2,Lamb3)"
            let ?P = "\<lambda>Lamb1. s2 .FUNCT-1K1 Lamb1 <>HIDDENR2 x0"
            have " ex m1 be NatNAT-1M1 st 0NUMBERSK6 <=XXREAL-0R1 m1 & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m1 <>HIDDENR2 x0"
              using A12 sorry
            then have A13: " ex m be NatNAT-1M1 st ?P(m)"
               sorry
            obtain M where
              [ty]:"M be NatNAT-1M1" and 
              A14: "?P(M) & ( for n be NatNAT-1M1 holds ?P(n) implies M <=XXREAL-0R1 n)"
              using nat_1_sch_5 A13 sorry
            obtain M9 where 
              [ty]:"M9 be ElementSUBSET-1M1-of NATNUMBERSK1" and M9Def:"M9 = M"
              using ordinal1_def_12 sorry
            have A15: " for n be NatNAT-1M1 holds  ex m be NatNAT-1M1 st n <XXREAL-0R3 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              obtain m where
                [ty]:"m be NatNAT-1M1" and 
                A16: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0"
                using A12 sorry
              show " ex m be NatNAT-1M1 st n <XXREAL-0R3 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0"
              proof(rule bexI[of _ "m"])
                show "n <XXREAL-0R3 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0"
                  using A16 nat_1_th_13 sorry
              qed "sorry"
            qed "sorry"
            have A17: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?R(n,x,y)"
            proof-
              have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar21 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar21 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be NatNAT-1M1 holds  for m be NatNAT-1M1 holds tVar21 =XBOOLE-0R4 nc & tVar21 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0) & ( for k be NatNAT-1M1 holds nc <XXREAL-0R3 k & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k))"
              proof(rule ballI,rule ballI)
                fix n assume [ty]: "n be NatNAT-1M1"
                fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                let ?P = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 <>HIDDENR2 x0"
                have " ex m be NatNAT-1M1 st ?P(m)"
                  using A15 sorry
                then have A18: " ex m be NatNAT-1M1 st ?P(m)"
                   sorry
                obtain l where
                  [ty]:"l be NatNAT-1M1" and 
                  A19: "?P(l) & ( for k be NatNAT-1M1 holds ?P(k) implies l <=XXREAL-0R1 k)"
                  using nat_1_sch_5 A18 sorry
                show " ex tVar21 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar21 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be NatNAT-1M1 holds  for m be NatNAT-1M1 holds tVar21 =XBOOLE-0R4 nc & tVar21 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0) & ( for k be NatNAT-1M1 holds nc <XXREAL-0R3 k & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k))"
                proof(rule bexI[of _ "l"])
                  have "l inTARSKIR2 NATNUMBERSK1"
                    using ordinal1_def_12 sorry
                  thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be NatNAT-1M1 holds  for m be NatNAT-1M1 holds l =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0) & ( for k be NatNAT-1M1 holds nc <XXREAL-0R3 k & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k))"
                    using A19 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain F where
              [ty]:"F be sequenceNAT-1M2-of NATNUMBERSK1" and 
              A20: "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M9 & ( for n be NatNAT-1M1 holds ?R(n,F .RECDEF-1K1 n,F .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
              using recdef_1_sch_2 A17 sorry
            have A21: " for n be NatNAT-1M1 holds F .RECDEF-1K1 n be realXREAL-0V1"
               sorry
            have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =XBOOLE-0R4 NATNUMBERSK1"
              using funct_2_def_1 sorry
            then have 
              [ty]:"F be Real-SequenceSEQ-1M1"
              using A21 seq_1_th_2 sorry
            have " for n be NatNAT-1M1 holds F .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
              using A20 sorry
            then have 
              [ty]:"F be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
              using seqm_3_def_6 sorry
            have A22: "s2 *COMSEQ-3K9 F be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of s2"
              using valued_0_def_17 sorry
            then have A23: "s2 *COMSEQ-3K9 F be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 (s2 *COMSEQ-3K9 F) =COMPLEX1R1 x0"
              using A4 cfcont_1_th_17 cfcont_1_th_18 sorry
            have A24: " for n be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 x0 implies ( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 n)"
            proof-
              have "( ex n be NatNAT-1M1 st s2 .FUNCT-1K1 n <>HIDDENR2 x0 & ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
              proof(rule impI)
                let ?P = "\<lambda>Lamb1. s2 .FUNCT-1K1 Lamb1 <>HIDDENR2 x0 & ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                assume " ex n be NatNAT-1M1 st ?P(n)"
                then have A25: " ex n be NatNAT-1M1 st ?P(n)"
                   sorry
                obtain M1 where
                  [ty]:"M1 be NatNAT-1M1" and 
                  A26: "?P(M1) & ( for n be NatNAT-1M1 holds ?P(n) implies M1 <=XXREAL-0R1 n)"
                  using nat_1_sch_5 A25 sorry
                let ?E = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 M1 & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 <>HIDDENR2 x0) & ( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                have A27: " ex n be NatNAT-1M1 st ?E(n)"
                proof-
                  have " ex tVar22 be NatNAT-1M1 st tVar22 <XXREAL-0R3 M1 & (s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar22 <>HIDDENR2 x0 & ( ex tVar23 be NatNAT-1M1 st F .RECDEF-1K1 tVar23 =COMPLEX1R1 tVar22))"
                  proof-
                    show " ex tVar22 be NatNAT-1M1 st tVar22 <XXREAL-0R3 M1 & (s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar22 <>HIDDENR2 x0 & ( ex tVar23 be NatNAT-1M1 st F .RECDEF-1K1 tVar23 =COMPLEX1R1 tVar22))"
                    proof(rule bexI[of _ "M"],rule conjMI,rule conjMI)
                      have "M <=XXREAL-0R1 M1 & M <>HIDDENR2 M1"
                        using A14 A20 A26 sorry
                      thus "M <XXREAL-0R3 M1"
                        using xxreal_0_th_1 sorry
                      show "s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> M <>HIDDENR2 x0"
                        using A14 sorry
                      show " ex tVar23 be NatNAT-1M1 st F .RECDEF-1K1 tVar23 =COMPLEX1R1 M"
                      proof(rule bexI[of _ "0NUMBERSK6"])
                        show "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M"
                          using A20 sorry
                      qed "sorry"
                    qed "sorry"
                  qed
                  thus " ?thesis "
                     sorry
                qed
                have A28: " for n be NatNAT-1M1 holds ?E(n) implies n <=XXREAL-0R1 M1"
                   sorry
                obtain MX where
                  [ty]:"MX be NatNAT-1M1" and 
                  A29: "?E(MX) & ( for n be NatNAT-1M1 holds ?E(n) implies n <=XXREAL-0R1 MX)"
                  using nat_1_sch_6 A28 A27 sorry
                have A30: " for k be NatNAT-1M1 holds MX <XXREAL-0R3 k & k <XXREAL-0R3 M1 implies s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 x0"
                proof-
                  have "( ex k be NatNAT-1M1 st MX <XXREAL-0R3 k & (k <XXREAL-0R3 M1 & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0)) implies  False "
                  proof(rule impI)
                    assume Given: " ex k be NatNAT-1M1 st MX <XXREAL-0R3 k & (k <XXREAL-0R3 M1 & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0)"
                    then obtain k where
                      [ty]:"k be NatNAT-1M1" and 
                      A31: "MX <XXREAL-0R3 k"and A32: "k <XXREAL-0R3 M1 & s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0"
                       sorry
                    have " False "
                    proof-
                      show " False "
                      proof-
                        have cases: "( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k)"
                           sorry
                        have case1: "( ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                        proof(rule impI)
                          assume " ex m be NatNAT-1M1 st F .RECDEF-1K1 m =COMPLEX1R1 k"
                          thus " False "
                            using A29 A31 A32 sorry
                        qed
                        have case2: "( for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                        proof(rule impI)
                          assume " for m be NatNAT-1M1 holds F .RECDEF-1K1 m <>HIDDENR2 k"
                          thus " False "
                            using A26 A32 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " False "
                       sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                obtain m where
                  [ty]:"m be NatNAT-1M1" and 
                  A33: "F .RECDEF-1K1 m =COMPLEX1R1 MX"
                  using A29 sorry
                have A34: "MX <XXREAL-0R3 F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) <>HIDDENR2 x0"
                  using A20 A33 sorry
                have A35: "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 M1"
                  using A20 A26 A29 A33 sorry
                have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1 implies  False "
                proof(rule impI)
                  assume "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1"
                  then have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 M1"
                    using A35 xxreal_0_th_1 sorry
                  thus " False "
                    using A30 A34 sorry
                qed
                thus " False "
                  using A26 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            let ?P = "\<lambda>Lamb1. (s2 *COMSEQ-3K9 F).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 <>HIDDENR2 x0"
            have A36: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have " for k be NatNAT-1M1 holds (s2 *COMSEQ-3K9 F).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0 implies (s2 *COMSEQ-3K9 F).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 x0"
              proof(rule ballI,rule impI)
                fix k assume [ty]: "k be NatNAT-1M1"
                assume "(s2 *COMSEQ-3K9 F).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k <>HIDDENR2 x0"
                have "?P2(F .RECDEF-1K1 k,F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                  using A20 sorry
                then have "s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) <>HIDDENR2 x0"
                   sorry
                thus "(s2 *COMSEQ-3K9 F).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 x0"
                  using funct_2_th_15 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have A37: "?P(0NUMBERSK6)"
              using A14 A20 funct_2_th_15 sorry
            have A38: " for n be NatNAT-1M1 holds ?P(n)"
              using nat_1_sch_2 A37 A36 sorry
            have A39: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s2 *COMSEQ-3K9 F) c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s2"
              using A22 valued_0_th_21 sorry
            then have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s2 *COMSEQ-3K9 F) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
              using A3 sorry
            then have A40: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 *COMSEQ-3K9 F) be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 *COMSEQ-3K9 F)"
              using A2 A38 A23 sorry
            have A41: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p)"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be RealXREAL-0M1"
              assume A42: "0NUMBERSK6 <XXREAL-0R3 p"
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A43: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 *COMSEQ-3K9 F) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                using A40 comseq_2_def_6 sorry
              obtain k where 
                [ty]:"k be NatNAT-1M1" and kDef:"k = F .RECDEF-1K1 n"
                 sorry
              show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
              proof(rule bexI[of _ "k"],rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume A44: "k <=XXREAL-0R1 m"
                show " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                proof-
                  have cases: "s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 x0 or s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0"
                     sorry
                  have case1: "s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 x0 implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                  proof(rule impI)
                    assume A45: "s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 x0"
                    have "m inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                      using A3 funct_2_th_109 A45 sorry
                    also have "... = 0NUMBERSK6"
                      using complex1_th_44 sorry
                    finally have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1 0NUMBERSK6"
                       sorry
                    thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                      using A42 sorry
                  qed
                  have case2: "s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0 implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                  proof(rule impI)
                    assume "s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m <>HIDDENR2 x0"
                    then obtain l where
                      [ty]:"l be NatNAT-1M1" and 
                      A46: "m =COMPLEX1R1 F .RECDEF-1K1 l"
                      using A24 sorry
                    have A47: "l inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have A48: "m inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have "n <=XXREAL-0R1 l"
                      using A44 A46 seqm_3_th_1 sorry
                    then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (s2 *COMSEQ-3K9 F) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                      using A43 sorry
                    then have " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((s2 *COMSEQ-3K9 F).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                      using A3 A39 funct_2_th_109 xboole_1_th_1 A47 sorry
                    then have " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                      using A46 funct_2_th_15 A47 sorry
                    thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
                      using A3 funct_2_th_109 A48 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed "sorry"
            qed "sorry"
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3"
               sorry
            thus "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
              using A41 comseq_2_def_6 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
         sorry
    qed "sorry"
    thus "f is-continuous-inCFCONT-1R1 x0"
      using cfcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_32:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 iff x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))"
proof-
  have " for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f is-continuous-inCFCONT-1R1 x0 implies x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))) & (x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))) implies f is-continuous-inCFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    show "f is-continuous-inCFCONT-1R1 x0 implies x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))"
    proof-
      have "f is-continuous-inCFCONT-1R1 x0 implies x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for s be RealXREAL-0M1 holds  not 0NUMBERSK6 <XXREAL-0R3 s or ( ex x1 be ComplexXCMPLX-0M1 st (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))) implies  False )"
      proof(rule impI,rule conjMI,rule impI)
        assume A1: "f is-continuous-inCFCONT-1R1 x0"
        thus "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
           sorry
        assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for s be RealXREAL-0M1 holds  not 0NUMBERSK6 <XXREAL-0R3 s or ( ex x1 be ComplexXCMPLX-0M1 st (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))"
        then obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A2: "0NUMBERSK6 <XXREAL-0R3 r"and A3: " for s be RealXREAL-0M1 holds  not 0NUMBERSK6 <XXREAL-0R3 s or ( ex x1 be ComplexXCMPLX-0M1 st (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)"
           sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 Lamb2 -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb2 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
        have A4: " for n be NatNAT-1M1 holds  ex g be ComplexXCMPLX-0M1 st ?P(n,g)"
        proof-
          have " for n be NatNAT-1M1 holds  ex tVar25 be ComplexXCMPLX-0M1 st (tVar25 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 tVar25 -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar25 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
               sorry
            then obtain g where
              [ty]:"g be ComplexXCMPLX-0M1" and 
              A5: "(g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
              using A3 sorry
            show " ex tVar25 be ComplexXCMPLX-0M1 st (tVar25 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 tVar25 -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar25 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
            proof(rule bexI[of _ "g"])
              show "(g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 g -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
                using A5 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s1 where
          [ty]:"s1 be Complex-SequenceCOMSEQ-1M1" and 
          A6: " for n be NatNAT-1M1 holds ?P(n,s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
          using cfcont_1_sch_1 A4 sorry
        have A7: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
            then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
              using funct_2_th_113 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
              using A6 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
            using tarski_def_3 sorry
        qed
        have A8: " for n be NatNAT-1M1 holds  not  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A9: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have " not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
            using A6 sorry
          thus " not  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
            using A7 funct_2_th_109 A9 sorry
        qed "sorry"
        have A10: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s)"
        proof(rule ballI,rule impI)
          fix s assume [ty]: "s be RealXREAL-0M1"
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A11: "s \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
            using seq_4_th_3 sorry
          assume "0NUMBERSK6 <XXREAL-0R3 s"
          then have A12: "0NUMBERSK6 <XXREAL-0R3 s \<inverse>XCMPLX-0K5"
             sorry
          have "s \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A11 xreal_1_th_8 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 s \<inverse>XCMPLX-0K5"
            using A12 xreal_1_th_76 sorry
          then have A13: "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
            using xcmplx_1_th_216 sorry
          obtain k where 
            [ty]:"k be NatNAT-1M1" and kDef:"k = n"
             sorry
          show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
          proof(rule bexI[of _ "k"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume "k <=XXREAL-0R1 m"
            then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_6 sorry
            then have "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M)"
              using xreal_1_th_118 sorry
            then have "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
              using A13 xxreal_0_th_2 sorry
            thus " |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
              using A6 xxreal_0_th_2 sorry
          qed "sorry"
        qed "sorry"
        then have A14: "s1 be convergentCOMSEQ-2V3"
           sorry
        then have "limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
          using A10 comseq_2_def_6 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
          using A1 A7 A14 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A15: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
          using A2 comseq_2_def_6 sorry
        have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
          using A15 sorry
        thus " False "
          using A8 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A16: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A17: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))"
    have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A18: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        and A19: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
      have A20: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume "0NUMBERSK6 <XXREAL-0R3 p"
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A21: "0NUMBERSK6 <XXREAL-0R3 s"and A22: " for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
          using A17 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A23: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
          using A19 A21 comseq_2_def_6 sorry
        obtain k where 
          [ty]:"k be NatNAT-1M1" and kDef:"k = n"
           sorry
        show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A24: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "k <=XXREAL-0R1 m"
          then have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 &  |.COMPLEX1K10 s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
            using A23 valued_0_th_28 sorry
          then have " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
            using A18 A22 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 p"
            using A18 funct_2_th_109 A24 sorry
        qed "sorry"
      qed "sorry"
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
         sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A20 comseq_2_def_6 sorry
    qed "sorry"
    thus "f is-continuous-inCFCONT-1R1 x0"
      using A16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_33:
" for x0 be ComplexXCMPLX-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-inCFCONT-1R1 x0 & f2 is-continuous-inCFCONT-1R1 x0 implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0 & f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0) & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0"
proof-
  have " for x0 be ComplexXCMPLX-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-inCFCONT-1R1 x0 & f2 is-continuous-inCFCONT-1R1 x0 implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0 & (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0 & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f1 is-continuous-inCFCONT-1R1 x0"
      and A2: "f2 is-continuous-inCFCONT-1R1 x0"
    have A3: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 & x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A1 A2 sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule conjMI)
      have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A3 xboole_0_def_4 sorry
      thus A4: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using valued_1_def_1 sorry
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A5: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        and A6: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
      have A7: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A5 valued_1_def_1 sorry
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A8: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A5 sorry
      then have A9: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A2 A6 sorry
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A10: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
        using A5 sorry
      then have A11: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A1 A6 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A9 sorry
      thus "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A7 cfcont_1_th_7 sorry
      have A12: "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A6 A10 sorry
      have A13: "f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A2 A6 A8 sorry
      have "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 +XCMPLX-0K2 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A4 cfunct_1_th_1 sorry
      also have "... = limCOMSEQ-2K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A11 A12 A9 A13 comseq_2_th_14 sorry
      also have "... = limCOMSEQ-2K3 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A7 cfcont_1_th_7 sorry
      finally show "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0"
       sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) implies (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule conjMI)
      have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A3 xboole_0_def_4 sorry
      thus A14: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using cfunct_1_th_2 sorry
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A15: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        and A16: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
      have A17: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A15 cfunct_1_th_2 sorry
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using cfunct_1_th_2 sorry
      then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A18: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A15 sorry
      then have A19: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A2 A16 sorry
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using cfunct_1_th_2 sorry
      then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A20: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
        using A15 sorry
      then have A21: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A1 A16 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A19 sorry
      thus "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A17 cfcont_1_th_7 sorry
      have A22: "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A16 A20 sorry
      have A23: "f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A2 A16 A18 sorry
      have "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 -XCMPLX-0K6 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A14 cfunct_1_th_2 sorry
      also have "... = limCOMSEQ-2K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A21 A22 A19 A23 comseq_2_th_26 sorry
      also have "... = limCOMSEQ-2K3 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A17 cfcont_1_th_7 sorry
      finally show "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0"
       sorry
    have Cut1125: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using A3 xboole_0_def_4 sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) implies (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule conjMI)
      show A24: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using valued_1_def_4 Cut1125 sorry
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A25: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        and A26: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using valued_1_def_4 sorry
      then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A27: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A25 sorry
      then have A28: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A2 A26 sorry
      have A29: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A25 valued_1_def_4 sorry
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using valued_1_def_4 sorry
      then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A30: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1"
        using A25 sorry
      then have A31: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A1 A26 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A28 sorry
      thus "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A29 cfcont_1_th_7 sorry
      have A32: "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A26 A30 sorry
      have A33: "f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A2 A26 A27 sorry
      have "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 *XCMPLX-0K3 f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A24 cfunct_1_th_3 sorry
      also have "... = limCOMSEQ-2K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A31 A32 A28 A33 comseq_2_th_30 sorry
      also have "... = limCOMSEQ-2K3 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A29 cfcont_1_th_7 sorry
      finally show "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-inCFCONT-1R1 x0"
      using cfcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_34:
" for g be ComplexXCMPLX-0M1 holds  for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 implies g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-inCFCONT-1R1 x0"
proof-
  have " for g be ComplexXCMPLX-0M1 holds  for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 implies g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-inCFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix g assume [ty]: "g be ComplexXCMPLX-0M1"
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f is-continuous-inCFCONT-1R1 x0"
    then have Cut1159: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
       sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule conjMI)
      show A2: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
        using valued_1_def_5 Cut1159 sorry
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A3: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
        and A4: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
      have A5: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A3 valued_1_def_5 sorry
      then have A6: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A4 sorry
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A1 A4 A5 sorry
      then have "g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
         sorry
      thus "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A5 cfcont_1_th_8 sorry
      have "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 g *XCMPLX-0K3 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0"
        using A2 cfunct_1_th_4 sorry
      also have "... = limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A7 A6 comseq_2_th_18 sorry
      also have "... = limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A5 cfcont_1_th_8 sorry
      finally show "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
    qed "sorry"
    thus "g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-inCFCONT-1R1 x0"
      using cfcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_35:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 implies -VALUED-1K33\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-inCFCONT-1R1 x0"
  using cfcont_1_th_34 sorry

mtheorem cfcont_1_th_36:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-inCFCONT-1R1 x0"
proof-
  have " for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-inCFCONT-1R1 x0 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-inCFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f is-continuous-inCFCONT-1R1 x0"
      and A2: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6"
    have " not f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
      using A2 tarski_def_1 sorry
    then have A3: " not x0 inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using partfun2_th_26 sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A1 sorry
    then have Cut1191: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
      using A3 xboole_0_def_5 sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0) implies (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
    proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule conjMI)
      show A4: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
        using cfunct_1_def_2 Cut1191 sorry
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A5: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
        and A6: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x0"
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0cCOMPLEX1K6 }"
        using A5 cfunct_1_def_2 xboole_1_th_36 sorry
      then have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
         sorry
      then have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A6 sorry
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be non-zeroORDINAL1V9"
        using A5 cfcont_1_th_10 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be convergentCOMSEQ-2V3"
        using A2 A7 comseq_2_th_34 sorry
      thus "(f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A5 cfcont_1_th_11 sorry
      have "(f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0)\<inverse>XCMPLX-0K5"
        using A4 cfunct_1_def_2 sorry
      also have "... = limCOMSEQ-2K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
        using A2 A5 A7 cfcont_1_th_10 comseq_2_th_35 sorry
      also have "... = limCOMSEQ-2K3 (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A5 cfcont_1_th_11 sorry
      finally show "(f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 =HIDDENR1 limCOMSEQ-2K3 (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-inCFCONT-1R1 x0"
      using cfcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_37:
" for x0 be ComplexXCMPLX-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f1 is-continuous-inCFCONT-1R1 x0 & f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6) & f2 is-continuous-inCFCONT-1R1 x0 implies f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-inCFCONT-1R1 x0"
proof-
  have " for x0 be ComplexXCMPLX-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f1 is-continuous-inCFCONT-1R1 x0 & f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6) & f2 is-continuous-inCFCONT-1R1 x0 implies f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-inCFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f1 is-continuous-inCFCONT-1R1 x0 & f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 <>HIDDENR2 0NUMBERSK6"
      and A2: "f2 is-continuous-inCFCONT-1R1 x0"
    have "f1 ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-inCFCONT-1R1 x0"
      using A1 cfcont_1_th_36 sorry
    then have "f2 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) is-continuous-inCFCONT-1R1 x0"
      using A2 cfcont_1_th_33 sorry
    thus "f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-inCFCONT-1R1 x0"
      using cfunct_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef cfcont_1_def_2 (" _ is-continuous-onCFCONT-1R2  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)", "X be setHIDDENM2"
"pred f is-continuous-onCFCONT-1R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x0)"..

mtheorem cfcont_1_th_38:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X iff X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f is-continuous-onCFCONT-1R2 X implies X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)) & (X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1) implies f is-continuous-onCFCONT-1R2 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    show "f is-continuous-onCFCONT-1R2 X implies X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
    proof-
      have "f is-continuous-onCFCONT-1R2 X implies X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds  not (((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X) &  not (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)))"
      proof(rule impI)
        assume A1: "f is-continuous-onCFCONT-1R2 X"
        then have A2: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
           sorry
        have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 inHIDDENR3 X) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        proof(rule ballI,rule impMI ,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
          assume A3: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X"
            and A4: "s1 be convergentCOMSEQ-2V3"
            and A5: "limCOMSEQ-2K3 s1 inHIDDENR3 X"
          have A6: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 limCOMSEQ-2K3 s1"
            using A1 A5 sorry
          have A7: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
            using relat_1_th_61 sorry
          also have "... = X"
            using A2 xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 X"
             sorry
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A8: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
              using valued_0_th_28 sorry
            have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A3 A7 funct_2_th_109 sorry
            also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A3 A7 A8 partfun2_th_15 sorry
            also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
              using A2 A3 funct_2_th_109 xboole_1_th_1 sorry
            finally show "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
               sorry
          qed "sorry"
          then have A9: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
            using funct_2_th_63 sorry
          have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1)"
            using A5 A7 partfun2_th_15 sorry
          also have "... = limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
            using A3 A4 A7 A6 A9 sorry
          finally have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
             sorry
          thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
            using A3 A4 A7 A6 A9 sorry
        qed "sorry"
        thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds  not (((rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X) &  not (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)))"
          using A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A10: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A11: " for s1 be Complex-SequenceCOMSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
    have " for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x1"
    proof(rule ballI,rule impI)
      have A12: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
        using relat_1_th_61 sorry
      also have "... = X"
        using A10 xboole_1_th_28 sorry
      finally have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 X"
         sorry
      fix x1 assume [ty]: "x1 be ComplexXCMPLX-0M1"
      assume A13: "x1 inHIDDENR3 X"
      have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 x1) implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
        assume A14: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
          and A15: "s1 be convergentCOMSEQ-2V3"
          and A16: "limCOMSEQ-2K3 s1 =COMPLEX1R1 x1"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have A17: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
            using valued_0_th_28 sorry
          have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
            using A14 funct_2_th_109 sorry
          also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
            using A14 A17 partfun2_th_15 sorry
          also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using A10 A12 A14 funct_2_th_109 xboole_1_th_1 sorry
          finally show "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
             sorry
        qed "sorry"
        then have A18: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
          using funct_2_th_63 sorry
        have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1)"
          using A13 A12 A16 partfun2_th_15 sorry
        also have "... = limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
          using A11 A13 A12 A14 A15 A16 A18 sorry
        finally have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
           sorry
        thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
          using A11 A13 A12 A14 A15 A16 A18 sorry
      qed "sorry"
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x1"
        using A13 A12 sorry
    qed "sorry"
    thus "f is-continuous-onCFCONT-1R2 X"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_39:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X iff X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f is-continuous-onCFCONT-1R2 X implies X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))) & (X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))) implies f is-continuous-onCFCONT-1R2 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    show "f is-continuous-onCFCONT-1R2 X implies X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))"
    proof-
      have "f is-continuous-onCFCONT-1R2 X implies X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for x0 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar28 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar28 & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar28 implies  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)))"
      proof(rule impI,rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
        assume A1: "f is-continuous-onCFCONT-1R2 X"
        thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
           sorry
        have A2: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A1 sorry
        fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume A3: "x0 inHIDDENR3 X"
          and A4: "0NUMBERSK6 <XXREAL-0R3 r"
        have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x0"
          using A1 A3 sorry
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A5: "0NUMBERSK6 <XXREAL-0R3 s"and A6: " for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
          using A4 cfcont_1_th_32 sorry
        show " ex tVar28 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar28 & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar28 implies  not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)"
        proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 s"
            using A5 sorry
          fix x1 assume [ty]: "x1 be ComplexXCMPLX-0M1"
          assume A7: "x1 inHIDDENR3 X"
            and A8: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
          have A9: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
            using relat_1_th_61 sorry
          also have "... = X"
            using A2 xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 X"
             sorry
          then have " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
            using A7 partfun2_th_15 sorry
          also have "... =  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
            using A3 A9 partfun2_th_15 sorry
          finally have " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
             sorry
          thus " not  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
            using A6 A9 A7 A8 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A10: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A11: " for x0 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))"
    have A12: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = X"
      using A10 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) =HIDDENR1 X"
       sorry
    have " for x0 be ComplexXCMPLX-0M1 holds x0 inHIDDENR3 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
      assume A13: "x0 inHIDDENR3 X"
      have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))"
      proof-
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar29 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar29 & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar29 implies  not  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r))"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A14: "0NUMBERSK6 <XXREAL-0R3 s"and A15: " for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
            using A11 A13 sorry
          show " ex tVar29 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar29 & ( for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar29 implies  not  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r)"
          proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
            show "0NUMBERSK6 <XXREAL-0R3 s"
              using A14 sorry
            fix x1 assume [ty]: "x1 be ComplexXCMPLX-0M1"
            assume A16: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
              and A17: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
            have " |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
              using A12 A13 partfun2_th_15 sorry
            also have "... =  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
              using A16 partfun2_th_15 sorry
            finally have " |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
               sorry
            thus " not  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
              using A12 A15 A16 A17 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 x0"
        using A12 A13 cfcont_1_th_32 sorry
    qed "sorry"
    thus "f is-continuous-onCFCONT-1R2 X"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_40:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X iff f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f is-continuous-onCFCONT-1R2 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X) & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X implies f is-continuous-onCFCONT-1R2 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    show "f is-continuous-onCFCONT-1R2 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X"
    proof(rule impI)
      assume A1: "f is-continuous-onCFCONT-1R2 X"
      then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
         sorry
      then have Cut1372: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
        using xboole_1_th_28 sorry
      have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) & ( for g be ComplexXCMPLX-0M1 holds g inHIDDENR3 X implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g)"
      proof(rule conjMI,rule ballI,rule impI)
        show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
          using relat_1_th_61 Cut1372 sorry
        fix g assume [ty]: "g be ComplexXCMPLX-0M1"
        assume "g inHIDDENR3 X"
        then have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g"
          using A1 sorry
        thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g"
          using relat_1_th_72 sorry
      qed "sorry"
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X"
        using cfcont_1_def_2 sorry
    qed
    assume A2: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X"
    then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
       sorry
    then have Cut1382: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
      using relat_1_th_61 xboole_1_th_17 sorry
    have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for g be ComplexXCMPLX-0M1 holds g inHIDDENR3 X implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g)"
    proof(rule conjMI,rule ballI,rule impI)
      show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using Cut1382 sorry
      fix g assume [ty]: "g be ComplexXCMPLX-0M1"
      assume "g inHIDDENR3 X"
      then have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g"
        using A2 sorry
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g"
        using relat_1_th_72 sorry
    qed "sorry"
    thus "f is-continuous-onCFCONT-1R2 X"
      using cfcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_41:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & X1 c=TARSKIR1 X implies f is-continuous-onCFCONT-1R2 X1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & X1 c=TARSKIR1 X implies f is-continuous-onCFCONT-1R2 X1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f is-continuous-onCFCONT-1R2 X"
      and A2: "X1 c=TARSKIR1 X"
    have Cut1396: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A1 sorry
    have "X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for g be ComplexXCMPLX-0M1 holds g inHIDDENR3 X1 implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1 is-continuous-inCFCONT-1R1 g)"
    proof(rule conjMI,rule ballI,rule impI)
      show A3: "X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A2 Cut1396 sorry
      fix g assume [ty]: "g be ComplexXCMPLX-0M1"
      assume A4: "g inHIDDENR3 X1"
      then have A5: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g"
        using A1 A2 sorry
      show "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1 is-continuous-inCFCONT-1R1 g"
      proof-
        have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
          using A2 xboole_1_th_26 sorry
        then have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
          using relat_1_th_61 sorry
        then have A6: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1) c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
          using relat_1_th_61 sorry
        have Cut1410: "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X1"
          using A3 A4 xboole_0_def_4 sorry
        have "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1) & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 g) implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        proof(rule conjMI,rule ballI,rule impMI ,rule impI)
          show A7: "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)"
            using relat_1_th_61 Cut1410 sorry
          then have A8: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g"
            using A6 partfun2_th_15 sorry
          also have "... = (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g"
            using A7 partfun2_th_15 sorry
          finally have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g"
             sorry
          fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
          assume A9: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)"
            and A10: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 g"
          have A11: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
            using A9 A6 sorry
          have A12: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A13: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
              using valued_0_th_28 sorry
            have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A9 A6 funct_2_th_109 xboole_1_th_1 sorry
            also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A11 A13 partfun2_th_15 sorry
            also have "... = (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
              using A9 A13 partfun2_th_15 sorry
            also have "... = (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
              using A9 funct_2_th_109 sorry
            finally show "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
               sorry
          qed "sorry"
          have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
            using A5 A10 A11 sorry
          thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
            using A8 A12 funct_2_th_63 sorry
        qed "sorry"
        thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X1 is-continuous-inCFCONT-1R1 g"
          using cfcont_1_def_1 sorry
      qed
    qed "sorry"
    thus "f is-continuous-onCFCONT-1R2 X1"
      using cfcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_42:
" for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f is-continuous-onCFCONT-1R2 {TARSKIK1 x0}"
proof-
  have " for x0 be ComplexXCMPLX-0M1 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies f is-continuous-onCFCONT-1R2 {TARSKIK1 x0}"
  proof(rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be ComplexXCMPLX-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    have "{TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & ( for t be ComplexXCMPLX-0M1 holds t inHIDDENR3 {TARSKIK1 x0} implies f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0} is-continuous-inCFCONT-1R1 t)"
    proof(rule conjMI,rule ballI,rule impI)
      show "{TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A1 tarski_def_1 sorry
      fix t assume [ty]: "t be ComplexXCMPLX-0M1"
      assume A2: "t inHIDDENR3 {TARSKIK1 x0}"
      show "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0} is-continuous-inCFCONT-1R1 t"
      proof-
        have "t inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A1 A2 tarski_def_1 sorry
        then have Cut1445: "t inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0}"
          using A2 xboole_0_def_4 sorry
        have "t inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0}) & ( for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0}) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 t) implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> t =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        proof(rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
          show "t inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})"
            using relat_1_th_61 Cut1445 sorry
          fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
          assume A3: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})"
            and "s1 be convergentCOMSEQ-2V3"
            and "limCOMSEQ-2K3 s1 =COMPLEX1R1 t"
          have A4: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0} c=TARSKIR1 {TARSKIK1 x0}"
            using xboole_1_th_17 sorry
          have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0}"
            using A3 relat_1_th_61 sorry
          then have A5: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 {TARSKIK1 x0}"
            using A4 sorry
          have A6: " for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x0"
          proof(rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
              using valued_0_th_28 sorry
            thus "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 x0"
              using A5 tarski_def_1 sorry
          qed "sorry"
          have A7: "t =COMPLEX1R1 x0"
            using A2 tarski_def_1 sorry
          have A8: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> t .| <XXREAL-0R3 r)"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume A9: "0NUMBERSK6 <XXREAL-0R3 r"
            obtain n where 
              [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
               sorry
            show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> t .| <XXREAL-0R3 r"
            proof(rule bexI[of _ "n"],rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume "n <=XXREAL-0R1 m"
              have A10: "m inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have " |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> t .| =HIDDENR1  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                using A7 A3 funct_2_th_109 A10 sorry
              also have "... =  |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
                using A6 sorry
              also have "... = 0NUMBERSK6"
                using complex1_th_44 sorry
              finally have " |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> t .| =HIDDENR1 0NUMBERSK6"
                 sorry
              thus " |.COMPLEX1K10 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> t .| <XXREAL-0R3 r"
                using A9 sorry
            qed "sorry"
          qed "sorry"
          thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
             sorry
          thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> t =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
            using A8 comseq_2_def_6 sorry
        qed "sorry"
        thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 x0} is-continuous-inCFCONT-1R1 t"
          using cfcont_1_def_1 sorry
      qed
    qed "sorry"
    thus "f is-continuous-onCFCONT-1R2 {TARSKIK1 x0}"
      using cfcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_43:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-onCFCONT-1R2 X & f2 is-continuous-onCFCONT-1R2 X implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X & f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X) & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-onCFCONT-1R2 X & f2 is-continuous-onCFCONT-1R2 X implies f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X & (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f1 is-continuous-onCFCONT-1R2 X & f2 is-continuous-onCFCONT-1R2 X"
    then have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 & X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
       sorry
    then have A2: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
      using xboole_1_th_19 sorry
    then have A3: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using cfunct_1_th_1 sorry
    have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 inHIDDENR3 X) implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A4: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X"
        and A5: "s1 be convergentCOMSEQ-2V3"
        and A6: "limCOMSEQ-2K3 s1 inHIDDENR3 X"
      have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A1 A4 A5 A6 cfcont_1_th_38 sorry
      then have A8: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
         sorry
      have A9: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A2 A4 sorry
      have A10: "limCOMSEQ-2K3 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A3 A6 sorry
      have "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 & f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A4 A5 A6 cfcont_1_th_38 sorry
      then have "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 +XCMPLX-0K2 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A10 cfunct_1_th_1 sorry
      also have "... = limCOMSEQ-2K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A7 comseq_2_th_14 sorry
      also have "... = limCOMSEQ-2K3 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A9 cfcont_1_th_7 sorry
      finally have "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
      thus "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A9 A8 cfcont_1_th_7 sorry
    qed "sorry"
    thus "f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X"
      using A3 cfcont_1_th_38 sorry
    have A11: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using A2 cfunct_1_th_2 sorry
    have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 inHIDDENR3 X) implies (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A12: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X"
        and A13: "s1 be convergentCOMSEQ-2V3"
        and A14: "limCOMSEQ-2K3 s1 inHIDDENR3 X"
      have A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A1 A12 A13 A14 cfcont_1_th_38 sorry
      then have A16: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
         sorry
      have A17: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A2 A12 sorry
      have A18: "limCOMSEQ-2K3 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A11 A14 sorry
      have "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 & f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A12 A13 A14 cfcont_1_th_38 sorry
      then have "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 -XCMPLX-0K6 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A18 cfunct_1_th_2 sorry
      also have "... = limCOMSEQ-2K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A15 comseq_2_th_26 sorry
      also have "... = limCOMSEQ-2K3 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A17 cfcont_1_th_7 sorry
      finally have "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
      thus "(f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A17 A16 cfcont_1_th_7 sorry
    qed "sorry"
    thus "f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X"
      using A11 cfcont_1_th_38 sorry
    have A19: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
      using A2 cfunct_1_th_3 sorry
    have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 inHIDDENR3 X) implies (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
      assume A20: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X"
        and A21: "s1 be convergentCOMSEQ-2V3"
        and A22: "limCOMSEQ-2K3 s1 inHIDDENR3 X"
      have A23: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
        using A1 A20 A21 A22 cfcont_1_th_38 sorry
      then have A24: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
         sorry
      have A25: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f2"
        using A2 A20 sorry
      have A26: "limCOMSEQ-2K3 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)"
        using A19 A22 sorry
      have "f1 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 & f2 /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A1 A20 A21 A22 cfcont_1_th_38 sorry
      then have "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 (limCOMSEQ-2K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)*XCMPLX-0K3 (limCOMSEQ-2K3 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A26 cfunct_1_th_3 sorry
      also have "... = limCOMSEQ-2K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
        using A23 comseq_2_th_30 sorry
      also have "... = limCOMSEQ-2K3 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A25 cfcont_1_th_7 sorry
      finally have "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
         sorry
      thus "(f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
        using A25 A24 cfcont_1_th_7 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X"
      using A19 cfcont_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_44:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f1 is-continuous-onCFCONT-1R2 X & f2 is-continuous-onCFCONT-1R2 X1 implies (f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1 & f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1) & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix X1 assume [ty]: "X1 be setHIDDENM2"
  fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
  fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
  assume "f1 is-continuous-onCFCONT-1R2 X & f2 is-continuous-onCFCONT-1R2 X1"
  then have "f1 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1 & f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1"
    using cfcont_1_th_41 xboole_1_th_17 sorry
  thus "(f1 +VALUED-1K2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1 & f1 -VALUED-1K48\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1) & f1 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f2 is-continuous-onCFCONT-1R2 X /\\XBOOLE-0K3 X1"
    using cfcont_1_th_43 sorry
qed "sorry"

mtheorem cfcont_1_th_45:
" for g be ComplexXCMPLX-0M1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X implies g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-onCFCONT-1R2 X"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix g assume [ty]: "g be ComplexXCMPLX-0M1"
  fix X assume [ty]: "X be setHIDDENM2"
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
  assume A1: "f is-continuous-onCFCONT-1R2 X"
  then have A2: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
     sorry
  then have A3: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
    using cfunct_1_th_4 sorry
  have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 inHIDDENR3 X) implies (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
    assume A4: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X"
      and A5: "s1 be convergentCOMSEQ-2V3"
      and A6: "limCOMSEQ-2K3 s1 inHIDDENR3 X"
    have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
      using A1 A4 A5 A6 cfcont_1_th_38 sorry
    then have A8: "g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
       sorry
    have A9: "limCOMSEQ-2K3 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)"
      using A3 A6 sorry
    have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
      using A1 A4 A5 A6 cfcont_1_th_38 sorry
    then have "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 g *XCMPLX-0K3 (limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
      using cfunct_1_th_4 A9 sorry
    also have "... = limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)"
      using A7 comseq_2_th_18 sorry
    also have "... = limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
      using A2 A4 cfcont_1_th_8 xboole_1_th_1 sorry
    finally have "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =HIDDENR1 limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
       sorry
    thus "(g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s1) =COMPLEX1R1 limCOMSEQ-2K3 (g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
      using A2 A4 A8 cfcont_1_th_8 xboole_1_th_1 sorry
  qed "sorry"
  thus "g (#)VALUED-1K27\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-onCFCONT-1R2 X"
    using A3 cfcont_1_th_38 sorry
qed "sorry"

mtheorem cfcont_1_th_46:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X implies -VALUED-1K33\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> f is-continuous-onCFCONT-1R2 X"
  using cfcont_1_th_45 sorry

mtheorem cfcont_1_th_47:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f is-continuous-onCFCONT-1R2 X"
      and A2: "f \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
    have A3: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f \\SUBSET-1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> {}XBOOLE-0K1"
      using A2 cfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
       sorry
    finally have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
       sorry
    have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) & ( for g be ComplexXCMPLX-0M1 holds g inHIDDENR3 X implies (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g)"
    proof(rule conjMI,rule ballI,rule impI)
      show A4: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
        using A1 A3 sorry
      fix g assume [ty]: "g be ComplexXCMPLX-0M1"
      assume A5: "g inHIDDENR3 X"
      then have A6: "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g"
        using A1 sorry
      have "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
        using A4 A5 xboole_0_def_4 sorry
      then have A7: "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
        using relat_1_th_61 sorry
      have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X) & (s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 g) implies ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =HIDDENR1 ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g"
      proof(rule ballI,rule impMI ,rule impI,rule conjMI)
        fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
        assume A8: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
          and A9: "s1 be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s1 =COMPLEX1R1 g"
        have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
          using A8 relat_1_th_61 sorry
        then have A10: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
          using A3 relat_1_th_61 sorry
        then have A11: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
          using A6 A9 sorry
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have A12: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
            using valued_0_th_28 sorry
          have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X & domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
            using A3 A8 relat_1_th_61 xboole_1_th_17 sorry
          then have A13: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
             sorry
          have A14: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 0cCOMPLEX1K6 implies  False "
          proof(rule impI)
            assume "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 0cCOMPLEX1K6"
            then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
              using tarski_def_1 sorry
            thus " False "
              using A2 A13 A12 partfun2_th_26 sorry
          qed
          have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
            using A10 funct_2_th_109 sorry
          also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
            using A10 A12 partfun2_th_15 sorry
          finally have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
             sorry
          thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
            using A14 sorry
        qed "sorry"
        then have A15: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be non-zeroORDINAL1V9"
          using comseq_1_th_4 sorry
        have "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
          using A3 A4 A5 xboole_0_def_4 sorry
        then have A16: "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
          using relat_1_th_61 sorry
        then have A17: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g"
          using partfun2_th_15 sorry
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have A18: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
            using valued_0_th_28 sorry
          then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)"
            using A8 sorry
          then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) /\\SUBSET-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> X"
            using relat_1_th_61 sorry
          then have A19: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)"
            using xboole_0_def_4 sorry
          have "((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
            using A8 funct_2_th_109 sorry
          also have "... = (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)"
            using A8 A18 partfun2_th_15 sorry
          also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))\<inverse>XCMPLX-0K5"
            using A19 cfunct_1_def_2 sorry
          also have "... = ((f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n))\<inverse>XCMPLX-0K5"
            using A10 A18 partfun2_th_15 sorry
          also have "... = ((f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
            using A10 funct_2_th_109 sorry
          also have "... = ((f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
            using valued_1_th_10 sorry
          finally show "((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
             sorry
        qed "sorry"
        then have A20: "((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
          using funct_2_th_63 sorry
        obtain gg where 
          [ty]:"gg be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and ggDef:"gg = g"
          using xcmplx_0_def_2 sorry
        have A21: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 0cCOMPLEX1K6 implies  False "
        proof(rule impI)
          assume "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 0cCOMPLEX1K6"
          then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> gg inTARSKIR2 {TARSKIK1 0cCOMPLEX1K6 }"
            using tarski_def_1 sorry
          thus " False "
            using A2 A3 A4 A5 partfun2_th_26 sorry
        qed
        then have "limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 <>HIDDENR2 0cCOMPLEX1K6"
          using A6 A9 A10 A17 sorry
        thus "((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
          using A11 A15 A20 comseq_2_th_34 sorry
        have "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 limCOMSEQ-2K3 (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1"
          using A6 A9 A10 sorry
        then have "limCOMSEQ-2K3 ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =HIDDENR1 ((f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g)\<inverse>XCMPLX-0K5"
          using A11 A17 A21 A15 A20 comseq_2_th_35 sorry
        also have "... = (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g)\<inverse>XCMPLX-0K5"
          using A16 partfun2_th_15 sorry
        also have "... = (f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> gg"
          using A4 A5 cfunct_1_def_2 sorry
        also have "... = ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g"
          using A7 partfun2_th_15 sorry
        finally show "limCOMSEQ-2K3 ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 =HIDDENR1 ((f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)/.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g"
           sorry
      qed "sorry"
      thus "(f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-inCFCONT-1R1 g"
        using A7 sorry
    qed "sorry"
    thus "f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
      using cfcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_48:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f is-continuous-onCFCONT-1R2 X & (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f is-continuous-onCFCONT-1R2 X"
      and A2: "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
    have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X"
      using A1 cfcont_1_th_40 sorry
    then have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
      using A2 cfcont_1_th_47 sorry
    then have "(f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> X is-continuous-onCFCONT-1R2 X"
      using cfunct_1_th_54 sorry
    thus "f ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
      using cfcont_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_49:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f1 is-continuous-onCFCONT-1R2 X & f1 \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 is-continuous-onCFCONT-1R2 X implies f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-onCFCONT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds  for f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f1 is-continuous-onCFCONT-1R2 X & f1 \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 is-continuous-onCFCONT-1R2 X implies f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-onCFCONT-1R2 X"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f1 is-continuous-onCFCONT-1R2 X & f1 \<inverse>RELSET-1K8\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      and A2: "f2 is-continuous-onCFCONT-1R2 X"
    have "f1 ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> is-continuous-onCFCONT-1R2 X"
      using A1 cfcont_1_th_47 sorry
    then have "f2 (#)VALUED-1K20\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (f1 ^CFUNCT-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>) is-continuous-onCFCONT-1R2 X"
      using A2 cfcont_1_th_43 sorry
    thus "f2 /CFUNCT-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f1 is-continuous-onCFCONT-1R2 X"
      using cfunct_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem cfcont_1_th_50:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & ( for x1 be ComplexXCMPLX-0M1 holds  for x2 be ComplexXCMPLX-0M1 holds f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2)) & ( ex x0 be ComplexXCMPLX-0M1 st f is-continuous-inCFCONT-1R1 x0) implies f is-continuous-onCFCONT-1R2 COMPLEXNUMBERSK3"
proof-
  have " for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> & (( for x1 be ComplexXCMPLX-0M1 holds  for x2 be ComplexXCMPLX-0M1 holds f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2) & ( ex x0 be ComplexXCMPLX-0M1 st f is-continuous-inCFCONT-1R1 x0)) implies f is-continuous-onCFCONT-1R2 COMPLEXNUMBERSK3"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "f be totalPARTFUN1V1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
      and A2: " for x1 be ComplexXCMPLX-0M1 holds  for x2 be ComplexXCMPLX-0M1 holds f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2"
      and A3: " ex x0 be ComplexXCMPLX-0M1 st f is-continuous-inCFCONT-1R1 x0"
    have A4: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =XBOOLE-0R4 COMPLEXNUMBERSK3"
      using A1 partfun1_def_2 sorry
    obtain x0 where
      [ty]:"x0 be ComplexXCMPLX-0M1" and 
      A5: "f is-continuous-inCFCONT-1R1 x0"
      using A3 sorry
    have A6: "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 +XCMPLX-0K2 0cCOMPLEX1K6 =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x0 +XCMPLX-0K2 0cCOMPLEX1K6)"
       sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
      using A2 sorry
    finally have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 +XCMPLX-0K2 0cCOMPLEX1K6 =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
       sorry
    have A7: " for x1 be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 x1)"
    proof(rule ballI)
      fix x1 assume [ty]: "x1 be ComplexXCMPLX-0M1"
      have "0cCOMPLEX1K6 =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 +XCMPLX-0K2 (-XCMPLX-0K4 x1))"
        using A6 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 x1)"
        using A2 sorry
      finally have "0cCOMPLEX1K6 =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 x1)"
         sorry
      thus "-XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 =COMPLEX1R1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 x1)"
         sorry
    qed "sorry"
    have A8: " for x1 be ComplexXCMPLX-0M1 holds  for x2 be ComplexXCMPLX-0M1 holds f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 -XCMPLX-0K6 x2) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2"
    proof(rule ballI,rule ballI)
      fix x1 assume [ty]: "x1 be ComplexXCMPLX-0M1"
      fix x2 assume [ty]: "x2 be ComplexXCMPLX-0M1"
      have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 -XCMPLX-0K6 x2) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 +XCMPLX-0K2 (-XCMPLX-0K4 x2))"
         sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 x2)"
        using A2 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 +XCMPLX-0K2 (-XCMPLX-0K4 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2)"
        using A7 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2"
         sorry
      finally show "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x1 -XCMPLX-0K6 x2) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2"
         sorry
    qed "sorry"
    have " for x1 be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds x1 inHIDDENR3 COMPLEXNUMBERSK3 & r >XXREAL-0R4 0NUMBERSK6 implies ( ex s be RealXREAL-0M1 st s >XXREAL-0R4 0NUMBERSK6 & ( for x2 be ComplexXCMPLX-0M1 holds x2 inHIDDENR3 COMPLEXNUMBERSK3 &  |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be ComplexXCMPLX-0M1"
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "x1 inHIDDENR3 COMPLEXNUMBERSK3"
        and A9: "r >XXREAL-0R4 0NUMBERSK6"
      let ?y = "x1 -XCMPLX-0K6 x0"
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A10: "0NUMBERSK6 <XXREAL-0R3 s"and A11: " for x1 be ComplexXCMPLX-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .| <XXREAL-0R3 r"
        using A5 A9 cfcont_1_th_32 sorry
      show " ex s be RealXREAL-0M1 st s >XXREAL-0R4 0NUMBERSK6 & ( for x2 be ComplexXCMPLX-0M1 holds x2 inHIDDENR3 COMPLEXNUMBERSK3 &  |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
        show "s >XXREAL-0R4 0NUMBERSK6"
          using A10 sorry
        fix x2 assume [ty]: "x2 be ComplexXCMPLX-0M1"
        assume "x2 inHIDDENR3 COMPLEXNUMBERSK3"
          and A12: " |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .| <XXREAL-0R3 s"
        have A13: " |.COMPLEX1K10 (x2 -XCMPLX-0K6 ?y)-XCMPLX-0K6 x0 .| =COMPLEX1R1  |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .|"
           sorry
        have A14: "x2 -XCMPLX-0K6 ?y inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
          using A4 xcmplx_0_def_2 sorry
        have "(x1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 =COMPLEX1R1 x1"
           sorry
        then have " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 .| =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2 -XCMPLX-0K6 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?y +XCMPLX-0K2 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0) .|"
          using A2 sorry
        also have "... =  |.COMPLEX1K10 (f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?y)-XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
           sorry
        also have "... =  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x2 -XCMPLX-0K6 ?y) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
          using A8 sorry
        finally have " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 .| =HIDDENR1  |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (x2 -XCMPLX-0K6 ?y) -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x0 .|"
           sorry
        thus " |.COMPLEX1K10 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x2 -XCMPLX-0K6 f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> x1 .| <XXREAL-0R3 r"
          using A11 A12 A13 A14 sorry
      qed "sorry"
    qed "sorry"
    thus "f is-continuous-onCFCONT-1R2 COMPLEXNUMBERSK3"
      using A4 cfcont_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef cfcont_1_def_3 ("compactCFCONT-1V1" 70 ) where
"attr compactCFCONT-1V1 for setHIDDENM2 means
  (\<lambda>X.  for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 X implies ( ex s2 be Complex-SequenceCOMSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s2 inHIDDENR3 X))"..

mtheorem cfcont_1_th_51:
" for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f be compactCFCONT-1V1 & f is-continuous-onCFCONT-1R2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f be compactCFCONT-1V1"
proof(rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
  assume A1: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f be compactCFCONT-1V1"
    and A2: "f is-continuous-onCFCONT-1R2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
  have " for s1 be Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f implies ( ex q2 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,COMPLEXNUMBERSK3 :]) st (q2 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of s1 & q2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 q2 inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f)"
  proof(rule ballI,rule impI)
    fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
    assume A3: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb2 =COMPLEX1R1 s1 .FUNCT-1K1 Lamb1"
    have A4: " for n be NatNAT-1M1 holds  ex g be ComplexXCMPLX-0M1 st ?P(n,g)"
    proof-
      have " for n be NatNAT-1M1 holds  ex tVar32 be ComplexXCMPLX-0M1 st tVar32 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar32 =COMPLEX1R1 s1 .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s1"
          using valued_0_th_28 sorry
        then obtain g where
          [ty]:"g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and 
          A5: "g inTARSKIR2 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & s1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 g"
          using A3 partfun1_th_3 sorry
        show " ex tVar32 be ComplexXCMPLX-0M1 st tVar32 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar32 =COMPLEX1R1 s1 .FUNCT-1K1 n"
        proof(rule bexI[of _ "g"])
          show "g inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> g =COMPLEX1R1 s1 .FUNCT-1K1 n"
            using A5 partfun1_def_6 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain q1 where
      [ty]:"q1 be Complex-SequenceCOMSEQ-1M1" and 
      A6: " for n be NatNAT-1M1 holds ?P(n,q1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
      using cfcont_1_sch_1 A4 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> q1 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> q1"
      then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
        using funct_2_th_113 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A6 sorry
    qed "sorry"
    then have A7: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> q1 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
       sorry
    then obtain s2 where
      [ty]:"s2 be Complex-SequenceCOMSEQ-1M1" and 
      A8: "s2 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of q1"and A9: "s2 be convergentCOMSEQ-2V3"and A10: "limCOMSEQ-2K3 s2 inHIDDENR3 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      using A1 sorry
    obtain q2 where 
      [ty]:"q2 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,COMPLEXNUMBERSK3 :])" and q2Def:"q2 = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
       sorry
    show " ex q2 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,COMPLEXNUMBERSK3 :]) st (q2 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of s1 & q2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 q2 inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
    proof(rule bexI[of _ "q2"])
      have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s2 c=TARSKIR1 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> q1"
        using A8 valued_0_th_21 sorry
      then have A11: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A7 sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using A6 sorry
        thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> n"
          using A7 funct_2_th_109 sorry
      qed "sorry"
      then have A12: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> q1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s1"
        using funct_2_th_63 sorry
      have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f is-continuous-inCFCONT-1R1 limCOMSEQ-2K3 s2"
        using A2 A10 sorry
      then have A13: "f is-continuous-inCFCONT-1R1 limCOMSEQ-2K3 s2"
        using relat_1_th_68 sorry
      then have "f /.PARTFUN1K7\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (limCOMSEQ-2K3 s2) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
        using A9 A11 sorry
      then have "f .FUNCT-1K1 (limCOMSEQ-2K3 s2) =COMPLEX1R1 limCOMSEQ-2K3 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s2"
        using A10 partfun1_def_6 sorry
      thus "(q2 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of s1 & q2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 q2 inHIDDENR3 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
        using A7 A12 A8 A9 A13 A11 funct_1_def_3 valued_0_th_22 sorry
    qed "sorry"
  qed "sorry"
  thus "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f be compactCFCONT-1V1"
     sorry
qed "sorry"

mtheorem cfcont_1_th_52:
" for Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & Y be compactCFCONT-1V1) & f is-continuous-onCFCONT-1R2 Y implies f .:RELSET-1K7\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y be compactCFCONT-1V1"
proof-
  have " for Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3 holds  for f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3) holds Y c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f & (Y be compactCFCONT-1V1 & f is-continuous-onCFCONT-1R2 Y) implies f .:RELSET-1K7\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y be compactCFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of COMPLEXNUMBERSK3"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)"
    assume A1: "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f"
      and A2: "Y be compactCFCONT-1V1"
      and A3: "f is-continuous-onCFCONT-1R2 Y"
    have A4: "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) =HIDDENR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f /\\SUBSET-1K9\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Y"
      using relat_1_th_61 sorry
    also have "... = Y"
      using A1 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) =HIDDENR1 Y"
       sorry
    have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y is-continuous-onCFCONT-1R2 Y"
    proof-
      have "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) & ( for g be ComplexXCMPLX-0M1 holds g inHIDDENR3 Y implies (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y is-continuous-inCFCONT-1R1 g)"
      proof(rule conjMI,rule ballI,rule impI)
        show "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y)"
          using A4 sorry
        fix g assume [ty]: "g be ComplexXCMPLX-0M1"
        assume "g inHIDDENR3 Y"
        then have "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y is-continuous-inCFCONT-1R1 g"
          using A3 sorry
        thus "(f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y is-continuous-inCFCONT-1R1 g"
          using relat_1_th_72 sorry
      qed "sorry"
      thus "f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y is-continuous-onCFCONT-1R2 Y"
        using cfcont_1_def_2 sorry
    qed
    then have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f  |RELSET-1K5\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y) be compactCFCONT-1V1"
      using A2 A4 cfcont_1_th_51 sorry
    thus "f .:RELSET-1K7\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Y be compactCFCONT-1V1"
      using relat_1_th_115 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
