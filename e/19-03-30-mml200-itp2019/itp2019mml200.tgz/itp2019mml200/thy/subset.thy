theory subset
  imports subset_1
begin
(*begin*)
mtheorem subset_th_1:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds a inTARSKIR2 b implies a be ElementSUBSET-1M1-of b"
  using subset_1_def_1 sorry

mtheorem subset_th_2:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds a be ElementSUBSET-1M1-of b & b be  non emptyXBOOLE-0V1 implies a inTARSKIR2 b"
  using subset_1_def_1 sorry

mtheorem subset_th_3:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds a be SubsetSUBSET-1M2-of b iff a c=TARSKIR1 b"
proof-
  have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds (a be SubsetSUBSET-1M2-of b implies a c=TARSKIR1 b) & (a c=TARSKIR1 b implies a be SubsetSUBSET-1M2-of b)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix b assume [ty]: "b be setHIDDENM2"
    show "a be SubsetSUBSET-1M2-of b implies a c=TARSKIR1 b"
    proof(rule impI)
      assume "a be SubsetSUBSET-1M2-of b"
      then have "a inTARSKIR2 boolZFMISC-1K1 b"
        using subset_1_def_1 sorry
      thus "a c=TARSKIR1 b"
        using zfmisc_1_def_1 sorry
    qed
    assume "a c=TARSKIR1 b"
    then have "a inTARSKIR2 boolZFMISC-1K1 b"
      using zfmisc_1_def_1 sorry
    thus "a be SubsetSUBSET-1M2-of b"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_th_4:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds a inTARSKIR2 b & b be SubsetSUBSET-1M2-of c implies a be ElementSUBSET-1M1-of c"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be setHIDDENM2"
  fix b assume [ty]: "b be setHIDDENM2"
  fix c assume [ty]: "c be setHIDDENM2"
  assume A1: "a inTARSKIR2 b"
    and A2: "b be SubsetSUBSET-1M2-of c"
  have "b c=TARSKIR1 c"
    using A2 subset_th_3 sorry
  then have "a inTARSKIR2 c"
    using A1 tarski_def_3 sorry
  thus "a be ElementSUBSET-1M1-of c"
    using subset_1_def_1 sorry
qed "sorry"

mtheorem subset_th_5:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds a inTARSKIR2 b & b be SubsetSUBSET-1M2-of c implies c be  non emptyXBOOLE-0V1"
   sorry

end
