theory toler_1
  imports eqrel_1 enumset1 xfamily
begin
(*begin*)
reserve X, Y, Z, x, y, z for "setHIDDENM2"
mtheorem toler_1_cl_1:
"cluster emptyXBOOLE-0V1 also-is reflexiveRELAT-2V1\<bar>irreflexiveRELAT-2V2\<bar>symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>asymmetricRELAT-2V5\<bar>connectedRELAT-2V6\<bar>strongly-connectedRELAT-2V7\<bar>transitiveRELAT-2V8 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be emptyXBOOLE-0V1 implies it be reflexiveRELAT-2V1\<bar>irreflexiveRELAT-2V2\<bar>symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>asymmetricRELAT-2V5\<bar>connectedRELAT-2V6\<bar>strongly-connectedRELAT-2V7\<bar>transitiveRELAT-2V8"
  proof-
    have " for R be RelationRELAT-1M1 holds R be emptyXBOOLE-0V1 implies R be reflexiveRELAT-2V1 & (R be irreflexiveRELAT-2V2 & (R be symmetricRELAT-2V3 & (R be antisymmetricRELAT-2V4 & (R be asymmetricRELAT-2V5 & (R be connectedRELAT-2V6 & (R be strongly-connectedRELAT-2V7 & R be transitiveRELAT-2V8))))))"
    proof(rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      assume A1: "R be emptyXBOOLE-0V1"
      have "{}XBOOLE-0K1 is-reflexive-inRELAT-2R1 fieldRELAT-1K3 ({}XBOOLE-0K1)"
         sorry
      thus "R be reflexiveRELAT-2V1"
        using A1 sorry
      have "{}XBOOLE-0K1 is-irreflexive-inRELAT-2R2 fieldRELAT-1K3 ({}XBOOLE-0K1)"
         sorry
      thus "R be irreflexiveRELAT-2V2"
        using A1 sorry
      show "R be symmetricRELAT-2V3"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R & (y inHIDDENR3 fieldRELAT-1K3 R & [TARSKIK4 x,y ] inHIDDENR3 R) implies [TARSKIK4 y,x ] inHIDDENR3 R"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "x inHIDDENR3 fieldRELAT-1K3 R"
            and "y inHIDDENR3 fieldRELAT-1K3 R"
            and A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
          show "[TARSKIK4 y,x ] inHIDDENR3 R"
            using A1 A2 sorry
        qed "sorry"
        thus "R be symmetricRELAT-2V3"
          using relat_2_def_3 relat_2_def_11 sorry
      qed
      have "{}XBOOLE-0K1 is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 ({}XBOOLE-0K1)"
         sorry
      thus "R be antisymmetricRELAT-2V4"
        using A1 sorry
      have "{}XBOOLE-0K1 is-asymmetric-inRELAT-2R5 fieldRELAT-1K3 ({}XBOOLE-0K1)"
         sorry
      thus "R be asymmetricRELAT-2V5"
        using A1 sorry
      have "{}XBOOLE-0K1 is-connected-inRELAT-2R6 fieldRELAT-1K3 ({}XBOOLE-0K1)"
         sorry
      thus "R be connectedRELAT-2V6"
        using A1 sorry
      have "{}XBOOLE-0K1 is-strongly-connected-inRELAT-2R7 fieldRELAT-1K3 ({}XBOOLE-0K1)"
         sorry
      thus "R be strongly-connectedRELAT-2V7"
        using A1 sorry
      have "{}XBOOLE-0K1 is-transitive-inRELAT-2R8 fieldRELAT-1K3 ({}XBOOLE-0K1)"
         sorry
      thus "R be transitiveRELAT-2V8"
        using A1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) TOLER_1K1("TotalTOLER-1K1  _ " [164]164) where
  "TotalTOLER-1K1 X \<equiv> nablaEQREL-1K1 X"

abbreviation(input) TOLER_1K2(" _  |-2TOLER-1K2  _ " [200,200]200) where
  "R  |-2TOLER-1K2 Y \<equiv> R  |-2WELLORD1K2 Y"

mtheorem toler_1_add_1:
  mlet "R be RelationRELAT-1M1", "Y be setHIDDENM2"
"cluster R  |-2WELLORD1K2 Y as-term-is RelationRELSET-1M1-of(Y,Y)"
proof
(*coherence*)
  show "R  |-2WELLORD1K2 Y be RelationRELSET-1M1-of(Y,Y)"
    using xboole_1_th_17 sorry
qed "sorry"

mtheorem toler_1_th_1:
" for X be setHIDDENM2 holds rngRELSET-1K2\<^bsub>(X)\<^esub> (TotalTOLER-1K1 X) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds rngRELSET-1K2\<^bsub>(X)\<^esub> (TotalTOLER-1K1 X) =XBOOLE-0R4 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X)"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X)) &  not ( not ( for y be objectHIDDENM1 holds  not [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X) &  not x inHIDDENR3 X)"
      proof(rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X)"
        proof-
          have "x inHIDDENR3 X implies ( ex tVar1 be objectHIDDENM1 st [TARSKIK4 tVar1,tVar1 ] inHIDDENR3 TotalTOLER-1K1 X)"
          proof(rule impI)
            assume A1: "x inHIDDENR3 X"
            show " ex tVar1 be objectHIDDENM1 st [TARSKIK4 tVar1,tVar1 ] inHIDDENR3 TotalTOLER-1K1 X"
            proof(rule bexI[of _ "x"])
              have "[TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
                using A1 zfmisc_1_th_87 sorry
              thus "[TARSKIK4 x,x ] inHIDDENR3 TotalTOLER-1K1 X"
                using eqrel_1_def_1 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show " not ( not ( for y be objectHIDDENM1 holds  not [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X) &  not x inHIDDENR3 X)"
          using zfmisc_1_th_87 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "rngRELSET-1K2\<^bsub>(X)\<^esub> (TotalTOLER-1K1 X) =XBOOLE-0R4 X"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_2:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 X implies [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 X implies [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume "x inTARSKIR2 X & y inTARSKIR2 X"
    then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
      using zfmisc_1_th_87 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
      using eqrel_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_3:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 fieldRELAT-1K3 (TotalTOLER-1K1 X) & y inTARSKIR2 fieldRELAT-1K3 (TotalTOLER-1K1 X) implies [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 fieldRELAT-1K3 (TotalTOLER-1K1 X) & y inTARSKIR2 fieldRELAT-1K3 (TotalTOLER-1K1 X) implies [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume "x inTARSKIR2 fieldRELAT-1K3 (TotalTOLER-1K1 X) & y inTARSKIR2 fieldRELAT-1K3 (TotalTOLER-1K1 X)"
    then have "x inTARSKIR2 X & y inTARSKIR2 X"
      using orders_1_th_12 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
      using toler_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_4:
" for X be setHIDDENM2 holds TotalTOLER-1K1 X be strongly-connectedRELAT-2V7"
proof-
  have " for X be setHIDDENM2 holds TotalTOLER-1K1 X be strongly-connectedRELAT-2V7"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X) & y inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X) implies  not ( not [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X &  not [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X)"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "x inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X) & y inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X)"
      then have "x inHIDDENR3 X & y inHIDDENR3 X"
        using orders_1_th_12 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
        using zfmisc_1_th_87 sorry
      thus " not ( not [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X &  not [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X)"
        using eqrel_1_def_1 sorry
    qed "sorry"
    thus "TotalTOLER-1K1 X be strongly-connectedRELAT-2V7"
      using relat_2_def_7 relat_2_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_5:
" for X be setHIDDENM2 holds TotalTOLER-1K1 X be connectedRELAT-2V6"
proof-
  have " for X be setHIDDENM2 holds TotalTOLER-1K1 X be connectedRELAT-2V6"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X) & y inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X)) & x <>HIDDENR2 y implies  not ( not [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X &  not [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "x inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X) & y inHIDDENR3 fieldRELAT-1K3 (TotalTOLER-1K1 X)"
        and "x <>HIDDENR2 y"
      have "x inHIDDENR3 X & y inHIDDENR3 X"
        using A1 orders_1_th_12 sorry
      then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
        using zfmisc_1_th_87 sorry
      thus " not ( not [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X &  not [TARSKIK4 y,x ] inHIDDENR3 TotalTOLER-1K1 X)"
        using eqrel_1_def_1 sorry
    qed "sorry"
    thus "TotalTOLER-1K1 X be connectedRELAT-2V6"
      using relat_2_def_6 relat_2_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve T, R for "ToleranceEQREL-1M1-of X"
mtheorem toler_1_th_6:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds rngRELSET-1K2\<^bsub>(X)\<^esub> T =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds rngRELSET-1K2\<^bsub>(X)\<^esub> T =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> T iff x inHIDDENR3 X"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> T &  not x inHIDDENR3 X) &  not (x inHIDDENR3 X &  not x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> T)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "x inHIDDENR3 X implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> T"
        proof(rule impI)
          have "fieldRELAT-1K3 T =XBOOLE-0R4 X"
            using orders_1_th_12 sorry
          then have A1: "T is-reflexive-inRELAT-2R1 X"
            using relat_2_def_9 sorry
          assume "x inHIDDENR3 X"
          then have "[TARSKIK4 x,x ] inHIDDENR3 T"
            using A1 sorry
          thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> T"
            using xtuple_0_def_13 sorry
        qed
        thus " not (x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> T &  not x inHIDDENR3 X) &  not (x inHIDDENR3 X &  not x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> T)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "rngRELSET-1K2\<^bsub>(X)\<^esub> T =XBOOLE-0R4 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_7:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for T be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>RelationRELSET-1M2-of X holds x inHIDDENR3 X iff [TARSKIK4 x,x ] inHIDDENR3 T"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for T be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>RelationRELSET-1M2-of X holds (x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 T) & ([TARSKIK4 x,x ] inHIDDENR3 T implies x inHIDDENR3 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix T assume [ty]: "T be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>RelationRELSET-1M2-of X"
    show "x inHIDDENR3 X implies [TARSKIK4 x,x ] inHIDDENR3 T"
      using eqrel_1_th_5 sorry
    assume A1: "[TARSKIK4 x,x ] inHIDDENR3 T"
    have "fieldRELAT-1K3 T =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    thus "x inHIDDENR3 X"
      using A1 relat_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_8:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T is-reflexive-inRELAT-2R1 X"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T is-reflexive-inRELAT-2R1 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have "fieldRELAT-1K3 T =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    thus "T is-reflexive-inRELAT-2R1 X"
      using relat_2_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_9:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T is-symmetric-inRELAT-2R3 X"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T is-symmetric-inRELAT-2R3 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have "fieldRELAT-1K3 T =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    thus "T is-symmetric-inRELAT-2R3 X"
      using relat_2_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R be symmetricRELAT-2V3 implies R  |-2TOLER-1K2 Z be symmetricRELAT-2V3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R be symmetricRELAT-2V3 implies R  |-2TOLER-1K2 Z be symmetricRELAT-2V3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    assume "R be symmetricRELAT-2V3"
    then have A1: "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
       sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 fieldRELAT-1K3 (R  |-2TOLER-1K2 Z) & y inHIDDENR3 fieldRELAT-1K3 (R  |-2TOLER-1K2 Z)) & [TARSKIK4 x,y ] inHIDDENR3 R  |-2TOLER-1K2 Z implies [TARSKIK4 y,x ] inHIDDENR3 R  |-2TOLER-1K2 Z"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "x inHIDDENR3 fieldRELAT-1K3 (R  |-2TOLER-1K2 Z) & y inHIDDENR3 fieldRELAT-1K3 (R  |-2TOLER-1K2 Z)"
        and A3: "[TARSKIK4 x,y ] inHIDDENR3 R  |-2TOLER-1K2 Z"
      have A4: "[TARSKIK4 x,y ] inHIDDENR3 R"
        using A3 xboole_0_def_4 sorry
      have A5: "[TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Z,Z :]"
        using A3 zfmisc_1_th_88 sorry
      have "x inHIDDENR3 fieldRELAT-1K3 R & y inHIDDENR3 fieldRELAT-1K3 R"
        using A2 wellord1_th_12 sorry
      then have "[TARSKIK4 y,x ] inHIDDENR3 R"
        using A1 A4 sorry
      thus "[TARSKIK4 y,x ] inHIDDENR3 R  |-2TOLER-1K2 Z"
        using A5 xboole_0_def_4 sorry
    qed "sorry"
    then have "R  |-2TOLER-1K2 Z is-symmetric-inRELAT-2R3 fieldRELAT-1K3 (R  |-2TOLER-1K2 Z)"
       sorry
    thus "R  |-2TOLER-1K2 Z be symmetricRELAT-2V3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax TOLER_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |-2TOLER-1K3\<^bsub>'( _ ')\<^esub>  _ " [200,0,200]200)
translations "T  |-2TOLER-1K3\<^bsub>(X)\<^esub> Y" \<rightharpoonup> "T  |-2WELLORD1K2 Y"

mtheorem toler_1_add_2:
  mlet "X be setHIDDENM2", "T be ToleranceEQREL-1M1-of X", "Y be SubsetSUBSET-1M2-of X"
"cluster T  |-2WELLORD1K2 Y as-term-is ToleranceEQREL-1M1-of Y"
proof
(*coherence*)
  show "T  |-2WELLORD1K2 Y be ToleranceEQREL-1M1-of Y"
  proof-
    have "T  |-2TOLER-1K2 Y be ToleranceEQREL-1M1-of Y"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (T  |-2TOLER-1K2 Y)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 Y"
        then have "[TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 Y,Y :] & [TARSKIK4 x,x ] inHIDDENR3 T"
          using toler_1_th_7 zfmisc_1_th_87 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 T  |-2TOLER-1K2 Y"
          using xboole_0_def_4 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (T  |-2TOLER-1K2 Y)"
          using xtuple_0_def_12 sorry
      qed "sorry"
      then have "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(Y)\<^esub> (T  |-2TOLER-1K2 Y)"
         sorry
      then have "domRELSET-1K1\<^bsub>(Y)\<^esub> (T  |-2TOLER-1K2 Y) =XBOOLE-0R4 Y"
        using xboole_0_def_10 sorry
      thus "T  |-2TOLER-1K2 Y be ToleranceEQREL-1M1-of Y"
        using toler_1_th_10 partfun1_def_2 wellord1_th_15 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem toler_1_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds Y c=TARSKIR1 X implies T  |-2TOLER-1K2 Y be ToleranceEQREL-1M1-of Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds Y c=TARSKIR1 X implies T  |-2TOLER-1K2 Y be ToleranceEQREL-1M1-of Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    assume "Y c=TARSKIR1 X"
    then obtain Z where 
      [ty]:"Z be SubsetSUBSET-1M2-of X" and ZDef:"Z = Y"
       sorry
    have "T  |-2TOLER-1K3\<^bsub>(X)\<^esub> Z be ToleranceEQREL-1M1-of Z"
       sorry
    thus "T  |-2TOLER-1K2 Y be ToleranceEQREL-1M1-of Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef toler_1_def_1 ("TolSetTOLER-1M1\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70 ) where
  mlet "X be setHIDDENM2", "T be ToleranceEQREL-1M1-of X"
"mode TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T \<rightarrow> setHIDDENM2 means
  (\<lambda>it.  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 it & y inTARSKIR2 it implies [TARSKIK4 x,y ] inHIDDENR3 T)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 it & y inTARSKIR2 it implies [TARSKIK4 x,y ] inHIDDENR3 T"
    proof-
      have " ex tVar2 be setHIDDENM2 st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 tVar2 & y inTARSKIR2 tVar2 implies [TARSKIK4 x,y ] inHIDDENR3 T"
      proof-
        show " ex tVar2 be setHIDDENM2 st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 tVar2 & y inTARSKIR2 tVar2 implies [TARSKIK4 x,y ] inHIDDENR3 T"
        proof(rule bexI[of _ "{}XBOOLE-0K1"],rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          fix y assume [ty]: "y be setHIDDENM2"
          assume A1: "x inTARSKIR2 {}XBOOLE-0K1"
            and "y inTARSKIR2 {}XBOOLE-0K1"
          show "[TARSKIK4 x,y ] inHIDDENR3 T"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem toler_1_th_12:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds {}XBOOLE-0K1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds {}XBOOLE-0K1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 {}XBOOLE-0K1 & y inTARSKIR2 {}XBOOLE-0K1 implies [TARSKIK4 x,y ] inHIDDENR3 T"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      fix y assume [ty]: "y be setHIDDENM2"
      assume A1: "x inTARSKIR2 {}XBOOLE-0K1"
        and "y inTARSKIR2 {}XBOOLE-0K1"
      show "[TARSKIK4 x,y ] inHIDDENR3 T"
        using A1 sorry
    qed "sorry"
    thus "{}XBOOLE-0K1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
      using toler_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef toler_1_def_2 ("TolClass-likeTOLER-1V1\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "T be ToleranceEQREL-1M1-of X"
"attr TolClass-likeTOLER-1V1\<^bsub>(X,T)\<^esub> for TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T means
  (\<lambda>IT.  for x be setHIDDENM2 holds  not x inTARSKIR2 IT & x inTARSKIR2 X implies ( ex y be setHIDDENM2 st y inTARSKIR2 IT &  not [TARSKIK4 x,y ] inHIDDENR3 T))"..

mtheorem toler_1_cl_2:
  mlet "X be setHIDDENM2", "T be ToleranceEQREL-1M1-of X"
"cluster TolClass-likeTOLER-1V1\<^bsub>(X,T)\<^esub> for TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
proof
(*existence*)
  show " ex it be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T st it be TolClass-likeTOLER-1V1\<^bsub>(X,T)\<^esub>"
  proof-
    have " ex tVar4 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T st tVar4 be TolClass-likeTOLER-1V1\<^bsub>(X,T)\<^esub>"
    proof-
      let ?X = "\<lambda>Lamb1. Lamb1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
      obtain TS where
        [ty]:"TS be setHIDDENM2" and 
        A1: " for x be setHIDDENM2 holds x inTARSKIR2 TS iff x inTARSKIR2 boolZFMISC-1K1 X & ?X(x)"
        using xfamily_sch_1 sorry
      have A2: "TS c=TARSKIR1 boolZFMISC-1K1 X"
        using A1 sorry
      have A3: " for Z be setHIDDENM2 holds Z c=TARSKIR1 TS & Z be c=-linearORDINAL1V6 implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 Y))"
      proof-
        have " for Z be setHIDDENM2 holds Z c=TARSKIR1 TS & Z be c=-linearORDINAL1V6 implies ( ex tVar3 be setHIDDENM2 st tVar3 inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 tVar3))"
        proof(rule ballI,rule impMI ,rule impI)
          fix Z assume [ty]: "Z be setHIDDENM2"
          assume A4: "Z c=TARSKIR1 TS"
            and A5: "Z be c=-linearORDINAL1V6"
          have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 unionTARSKIK3 Z & y inTARSKIR2 unionTARSKIK3 Z implies [TARSKIK4 x,y ] inHIDDENR3 T"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be setHIDDENM2"
            fix y assume [ty]: "y be setHIDDENM2"
            assume A6: "x inTARSKIR2 unionTARSKIK3 Z"
              and A7: "y inTARSKIR2 unionTARSKIK3 Z"
            obtain Zy where
              [ty]:"Zy be setHIDDENM2" and 
              A8: "y inTARSKIR2 Zy"and A9: "Zy inTARSKIR2 Z"
              using A7 tarski_def_4 sorry
            have 
              [ty]:"Zy be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
              using A1 A4 A9 sorry
            obtain Zx where
              [ty]:"Zx be setHIDDENM2" and 
              A10: "x inTARSKIR2 Zx"and A11: "Zx inTARSKIR2 Z"
              using A6 tarski_def_4 sorry
            have 
              [ty]:"Zx be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
              using A1 A4 A11 sorry
            have "(Zx,Zy)are-c=-comparableXBOOLE-0R3"
              using A5 A11 A9 ordinal1_def_8 sorry
            then have "Zx c=TARSKIR1 Zy or Zy c=TARSKIR1 Zx"
              using xboole_0_def_9 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 T"
              using A10 A8 toler_1_def_1 sorry
          qed "sorry"
          then have A12: "unionTARSKIK3 Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using toler_1_def_1 sorry
          show " ex tVar3 be setHIDDENM2 st tVar3 inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 tVar3)"
          proof(rule bexI[of _ "unionTARSKIK3 Z"],rule conjMI,rule ballI,rule impI)
            have "Z c=TARSKIR1 boolZFMISC-1K1 X"
              using A2 A4 sorry
            then have "unionTARSKIK3 Z c=TARSKIR1 unionTARSKIK3 (boolZFMISC-1K1 X)"
              using zfmisc_1_th_77 sorry
            then have "unionTARSKIK3 Z c=TARSKIR1 X"
              using zfmisc_1_th_81 sorry
            thus "unionTARSKIK3 Z inTARSKIR2 TS"
              using A1 A12 sorry
            fix X1 assume [ty]: "X1 be setHIDDENM2"
            assume "X1 inTARSKIR2 Z"
            thus "X1 c=TARSKIR1 unionTARSKIK3 Z"
              using zfmisc_1_th_74 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "{}XBOOLE-0K1 c=RELAT-1R2 X & {}XBOOLE-0K1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
        using toler_1_th_12 sorry
      then have "TS <>HIDDENR2 {}XBOOLE-0K1"
        using A1 sorry
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A13: "Y inTARSKIR2 TS"and A14: " for Z be setHIDDENM2 holds Z inTARSKIR2 TS & Z <>HIDDENR2 Y implies  not Y c=TARSKIR1 Z"
        using A3 orders_1_th_65 sorry
      have 
        [ty]:"Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
        using A1 A13 sorry
      show " ex tVar4 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T st tVar4 be TolClass-likeTOLER-1V1\<^bsub>(X,T)\<^esub>"
      proof(rule bexI[of _ "Y"])
        have " for x be setHIDDENM2 holds  not x inTARSKIR2 Y & x inTARSKIR2 X implies (( for y be setHIDDENM2 holds y inTARSKIR2 Y implies [TARSKIK4 x,y ] inHIDDENR3 T) implies  False )"
        proof(rule ballI,rule impMI ,rule impI,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          assume A15: " not x inTARSKIR2 Y"
            and A16: "x inTARSKIR2 X"
          let ?Y1 = "Y \\/XBOOLE-0K2 {TARSKIK1 x}"
          have A17: "{TARSKIK1 x} c=TARSKIR1 X"
            using A16 zfmisc_1_th_31 sorry
          assume A18: " for y be setHIDDENM2 holds y inTARSKIR2 Y implies [TARSKIK4 x,y ] inHIDDENR3 T"
          have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 ?Y1 & z inTARSKIR2 ?Y1 implies [TARSKIK4 y,z ] inHIDDENR3 T"
          proof-
            have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 Y \\/XBOOLE-0K2 {TARSKIK1 x} & z inTARSKIR2 Y \\/XBOOLE-0K2 {TARSKIK1 x} implies ( not [TARSKIK4 y,z ] inHIDDENR3 T implies  False )"
            proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
              fix y assume [ty]: "y be setHIDDENM2"
              fix z assume [ty]: "z be setHIDDENM2"
              assume A19: "y inTARSKIR2 ?Y1"
                and A20: "z inTARSKIR2 ?Y1"
              have "y inTARSKIR2 Y or y inTARSKIR2 {TARSKIK1 x}"
                using A19 xboole_0_def_3 sorry
              then have A21: "y inTARSKIR2 Y or y =XBOOLE-0R4 x"
                using tarski_def_1 sorry
              have "z inTARSKIR2 Y or z inTARSKIR2 {TARSKIK1 x}"
                using A20 xboole_0_def_3 sorry
              then have A22: "z inTARSKIR2 Y or z =XBOOLE-0R4 x"
                using tarski_def_1 sorry
              assume A23: " not [TARSKIK4 y,z ] inHIDDENR3 T"
              then have " not [TARSKIK4 z,y ] inHIDDENR3 T"
                using eqrel_1_th_6 sorry
              thus " False "
                using A16 A18 A21 A22 A23 toler_1_def_1 toler_1_th_7 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then have A24: "?Y1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using toler_1_def_1 sorry
          have A25: "?Y1 <>HIDDENR2 Y"
          proof-
            have "Y \\/XBOOLE-0K2 {TARSKIK1 x} =XBOOLE-0R4 Y implies  False "
            proof(rule impI)
              have A26: "x inTARSKIR2 {TARSKIK1 x}"
                using tarski_def_1 sorry
              assume "?Y1 =XBOOLE-0R4 Y"
              thus " False "
                using A15 A26 xboole_0_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have "Y inTARSKIR2 boolZFMISC-1K1 X"
            using A1 A13 sorry
          then have "?Y1 c=TARSKIR1 X"
            using A17 xboole_1_th_8 sorry
          then have "?Y1 inTARSKIR2 TS"
            using A1 A24 sorry
          thus " False "
            using A14 A25 xboole_1_th_7 sorry
        qed "sorry"
        thus "Y be TolClass-likeTOLER-1V1\<^bsub>(X,T)\<^esub>"
          using toler_1_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) TOLER_1M2("TolClassTOLER-1M2\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70) where
  "TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T \<equiv> TolClass-likeTOLER-1V1\<^bsub>(X,T)\<^esub>\<bar>TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"

mtheorem toler_1_th_13:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds {}XBOOLE-0K1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T implies T =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds {}XBOOLE-0K1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T implies (T <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    assume "{}XBOOLE-0K1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
    then obtain O0 where 
      [ty]:"O0 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T" and O0Def:"O0 = {}XBOOLE-0K1"
       sorry
    assume "T <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A1: "[TARSKIK4 x,y ] inHIDDENR3 T"
       sorry
    have "x inHIDDENR3 X"
      using A1 zfmisc_1_th_87 sorry
    then have " ex z be setHIDDENM2 st z inTARSKIR2 O0 &  not [TARSKIK4 x,z ] inHIDDENR3 T"
      using toler_1_def_2 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_14:
"{}XBOOLE-0K1 be ToleranceEQREL-1M1-of {}XBOOLE-0K1"
  using relset_1_th_12 sorry

mtheorem toler_1_th_15:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 T implies {TARSKIK2 x,y } be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 T implies {TARSKIK2 x,y } be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 T"
    then have A2: "x inTARSKIR2 X & y inTARSKIR2 X"
      using zfmisc_1_th_87 sorry
    have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds a inTARSKIR2 {TARSKIK2 x,y } & b inTARSKIR2 {TARSKIK2 x,y } implies [TARSKIK4 a,b ] inHIDDENR3 T"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be setHIDDENM2"
      fix b assume [ty]: "b be setHIDDENM2"
      assume A3: "a inTARSKIR2 {TARSKIK2 x,y }"
        and A4: "b inTARSKIR2 {TARSKIK2 x,y }"
      have A5: "b =XBOOLE-0R4 x or b =XBOOLE-0R4 y"
        using A4 tarski_def_2 sorry
      have "a =XBOOLE-0R4 x or a =XBOOLE-0R4 y"
        using A3 tarski_def_2 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 T"
        using A1 A2 A5 toler_1_th_7 eqrel_1_th_6 sorry
    qed "sorry"
    thus "{TARSKIK2 x,y } be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
      using toler_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_16:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds x inTARSKIR2 X implies {TARSKIK1 x} be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds x inTARSKIR2 X implies {TARSKIK1 x} be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be setHIDDENM2"
    assume "x inTARSKIR2 X"
    then have "[TARSKIK4 x,x ] inHIDDENR3 T"
      using toler_1_th_7 sorry
    then have "{TARSKIK2 x,x } be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
      using toler_1_th_15 sorry
    thus "{TARSKIK1 x} be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
      using enumset1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_17:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T implies Y /\\XBOOLE-0K3 Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T implies Y /\\XBOOLE-0K3 Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
    have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Y /\\XBOOLE-0K3 Z & y inTARSKIR2 Y /\\XBOOLE-0K3 Z implies [TARSKIK4 x,y ] inHIDDENR3 T"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be setHIDDENM2"
      fix y assume [ty]: "y be setHIDDENM2"
      assume "x inTARSKIR2 Y /\\XBOOLE-0K3 Z & y inTARSKIR2 Y /\\XBOOLE-0K3 Z"
      then have "x inTARSKIR2 Y & y inTARSKIR2 Y"
        using xboole_0_def_4 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 T"
        using A1 toler_1_def_1 sorry
    qed "sorry"
    thus "Y /\\XBOOLE-0K3 Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
      using toler_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_18:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T implies Y c=TARSKIR1 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T implies Y c=TARSKIR1 X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    assume A1: "Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 Y"
      then have "[TARSKIK4 x,x ] inHIDDENR3 T"
        using A1 toler_1_def_1 sorry
      thus "x inHIDDENR3 X"
        using toler_1_th_7 sorry
    qed "sorry"
    thus "Y c=TARSKIR1 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_19:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T holds  ex Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st Y c=TARSKIR1 Z"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T holds  ex tVar7 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st Y c=TARSKIR1 tVar7"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix Y assume [ty]: "Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
    let ?X = "\<lambda>Lamb1. Lamb1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T & ( ex Z be setHIDDENM2 st Lamb1 =XBOOLE-0R4 Z & Y c=TARSKIR1 Z)"
    obtain TS where
      [ty]:"TS be setHIDDENM2" and 
      A1: " for x be setHIDDENM2 holds x inTARSKIR2 TS iff x inTARSKIR2 boolZFMISC-1K1 X & ?X(x)"
      using xfamily_sch_1 sorry
    have A2: " for x be setHIDDENM2 holds x inTARSKIR2 TS iff (x inTARSKIR2 boolZFMISC-1K1 X & x be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & Y c=TARSKIR1 x"
    proof-
      have " for x be setHIDDENM2 holds (x inTARSKIR2 TS implies (x inTARSKIR2 boolZFMISC-1K1 X & x be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & Y c=TARSKIR1 x) &  not (((x inTARSKIR2 boolZFMISC-1K1 X & x be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & Y c=TARSKIR1 x) &  not x inTARSKIR2 TS)"
      proof(rule ballI,rule conjMI)
        fix x assume [ty]: "x be setHIDDENM2"
        show "x inTARSKIR2 TS implies (x inTARSKIR2 boolZFMISC-1K1 X & x be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & Y c=TARSKIR1 x"
        proof(rule impI,rule conjMI)
          assume A3: "x inTARSKIR2 TS"
          thus "x inTARSKIR2 boolZFMISC-1K1 X & x be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using A1 sorry
          have " ex Z be setHIDDENM2 st x =XBOOLE-0R4 Z & Y c=TARSKIR1 Z"
            using A1 A3 sorry
          thus "Y c=TARSKIR1 x"
             sorry
        qed
        show " not (((x inTARSKIR2 boolZFMISC-1K1 X & x be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & Y c=TARSKIR1 x) &  not x inTARSKIR2 TS)"
          using A1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Y c=TARSKIR1 X"
      using toler_1_th_18 sorry
    then have A4: "TS <>HIDDENR2 {}XBOOLE-0K1"
      using A2 sorry
    have A5: "TS c=TARSKIR1 boolZFMISC-1K1 X"
      using A1 sorry
    have " for Z be setHIDDENM2 holds Z c=TARSKIR1 TS & Z be c=-linearORDINAL1V6 implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 Y))"
    proof-
      have " for Z be setHIDDENM2 holds Z c=TARSKIR1 TS & Z be c=-linearORDINAL1V6 implies  not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 Z &  not X1 c=TARSKIR1 Y))))"
      proof(rule ballI,rule impMI ,rule impI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        assume A6: "Z c=TARSKIR1 TS"
          and A7: "Z be c=-linearORDINAL1V6"
        have A8: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 unionTARSKIK3 Z & y inTARSKIR2 unionTARSKIK3 Z implies [TARSKIK4 x,y ] inHIDDENR3 T"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          fix y assume [ty]: "y be setHIDDENM2"
          assume A9: "x inTARSKIR2 unionTARSKIK3 Z"
            and A10: "y inTARSKIR2 unionTARSKIK3 Z"
          obtain Zy where
            [ty]:"Zy be setHIDDENM2" and 
            A11: "y inTARSKIR2 Zy"and A12: "Zy inTARSKIR2 Z"
            using A10 tarski_def_4 sorry
          have 
            [ty]:"Zy be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using A1 A6 A12 sorry
          obtain Zx where
            [ty]:"Zx be setHIDDENM2" and 
            A13: "x inTARSKIR2 Zx"and A14: "Zx inTARSKIR2 Z"
            using A9 tarski_def_4 sorry
          have 
            [ty]:"Zx be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using A1 A6 A14 sorry
          have "(Zx,Zy)are-c=-comparableXBOOLE-0R3"
            using A7 A14 A12 ordinal1_def_8 sorry
          then have "Zx c=TARSKIR1 Zy or Zy c=TARSKIR1 Zx"
            using xboole_0_def_9 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 T"
            using A13 A11 toler_1_def_1 sorry
        qed "sorry"
        have A15: "Z <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 Z &  not X1 c=TARSKIR1 Y))))"
        proof-
          have "Z <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar5 be setHIDDENM2 st tVar5 inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 tVar5))"
          proof(rule impI)
            assume A16: "Z <>HIDDENR2 {}XBOOLE-0K1"
            have A17: "Y c=TARSKIR1 unionTARSKIK3 Z"
            proof-
              let ?y = "the ElementSUBSET-1M1-of Z"
              have "?y inTARSKIR2 TS"
                using A6 A16 sorry
              then have A18: "Y c=TARSKIR1 ?y"
                using A2 sorry
              have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 unionTARSKIK3 Z"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 Y"
                thus "x inHIDDENR3 unionTARSKIK3 Z"
                  using A16 A18 tarski_def_4 sorry
              qed "sorry"
              thus "Y c=TARSKIR1 unionTARSKIK3 Z"
                using tarski_def_3 sorry
            qed
            have "Z c=TARSKIR1 boolZFMISC-1K1 X"
              using A5 A6 sorry
            then have "unionTARSKIK3 Z c=TARSKIR1 unionTARSKIK3 (boolZFMISC-1K1 X)"
              using zfmisc_1_th_77 sorry
            then have A19: "unionTARSKIK3 Z c=TARSKIR1 X"
              using zfmisc_1_th_81 sorry
            show " ex tVar5 be setHIDDENM2 st tVar5 inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 tVar5)"
            proof(rule bexI[of _ "unionTARSKIK3 Z"],rule conjMI,rule ballI,rule impI)
              have "unionTARSKIK3 Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
                using A8 toler_1_def_1 sorry
              thus "unionTARSKIK3 Z inTARSKIR2 TS"
                using A2 A19 A17 sorry
              fix X1 assume [ty]: "X1 be setHIDDENM2"
              assume "X1 inTARSKIR2 Z"
              thus "X1 c=TARSKIR1 unionTARSKIK3 Z"
                using zfmisc_1_th_74 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 Z &  not X1 c=TARSKIR1 Y))))"
        proof-
          have "Z =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 tVar6))"
          proof(rule impI)
            let ?Y = "the ElementSUBSET-1M1-of TS"
            assume A20: "Z =XBOOLE-0R4 {}XBOOLE-0K1"
            show " ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 tVar6)"
            proof(rule bexI[of _ "?Y"],rule conjMI,rule ballI,rule impI)
              show "the ElementSUBSET-1M1-of TS inTARSKIR2 TS"
                using A4 sorry
              fix X1 assume [ty]: "X1 be setHIDDENM2"
              assume "X1 inTARSKIR2 Z"
              thus "X1 c=TARSKIR1 the ElementSUBSET-1M1-of TS"
                using A20 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 TS & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 Z &  not X1 c=TARSKIR1 Y))))"
          using A15 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then obtain Z1 where
      [ty]:"Z1 be setHIDDENM2" and 
      A21: "Z1 inTARSKIR2 TS"and A22: " for Z be setHIDDENM2 holds Z inTARSKIR2 TS & Z <>HIDDENR2 Z1 implies  not Z1 c=TARSKIR1 Z"
      using A4 orders_1_th_65 sorry
    have 
      [ty]:"Z1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
      using A1 A21 sorry
    have "Z1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
    proof-
      have " not Z1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T implies  False "
      proof(rule impI)
        assume " not Z1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
        then obtain x where
          [ty]:"x be setHIDDENM2" and 
          A23: " not x inTARSKIR2 Z1"and A24: "x inTARSKIR2 X"and A25: " for y be setHIDDENM2 holds y inTARSKIR2 Z1 implies [TARSKIK4 x,y ] inHIDDENR3 T"
          using toler_1_def_2 sorry
        let ?Y1 = "Z1 \\/XBOOLE-0K2 {TARSKIK1 x}"
        have A26: "{TARSKIK1 x} c=TARSKIR1 X"
          using A24 zfmisc_1_th_31 sorry
        have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 ?Y1 & z inTARSKIR2 ?Y1 implies [TARSKIK4 y,z ] inHIDDENR3 T"
        proof-
          have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 Z1 \\/XBOOLE-0K2 {TARSKIK1 x} & z inTARSKIR2 Z1 \\/XBOOLE-0K2 {TARSKIK1 x} implies ( not [TARSKIK4 y,z ] inHIDDENR3 T implies  False )"
          proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
            fix y assume [ty]: "y be setHIDDENM2"
            fix z assume [ty]: "z be setHIDDENM2"
            assume A27: "y inTARSKIR2 ?Y1"
              and A28: "z inTARSKIR2 ?Y1"
            have "y inTARSKIR2 Z1 or y inTARSKIR2 {TARSKIK1 x}"
              using A27 xboole_0_def_3 sorry
            then have A29: "y inTARSKIR2 Z1 or y =XBOOLE-0R4 x"
              using tarski_def_1 sorry
            have "z inTARSKIR2 Z1 or z inTARSKIR2 {TARSKIK1 x}"
              using A28 xboole_0_def_3 sorry
            then have A30: "z inTARSKIR2 Z1 or z =XBOOLE-0R4 x"
              using tarski_def_1 sorry
            assume A31: " not [TARSKIK4 y,z ] inHIDDENR3 T"
            then have " not [TARSKIK4 z,y ] inHIDDENR3 T"
              using eqrel_1_th_6 sorry
            thus " False "
              using A24 A25 A29 A30 A31 toler_1_def_1 toler_1_th_7 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A32: "?Y1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
          using toler_1_def_1 sorry
        have "Y c=TARSKIR1 Z1 & Z1 c=TARSKIR1 ?Y1"
          using A2 A21 xboole_1_th_7 sorry
        then have A33: "Y c=TARSKIR1 ?Y1"
           sorry
        have A34: "?Y1 <>HIDDENR2 Z1"
        proof-
          have "Z1 \\/XBOOLE-0K2 {TARSKIK1 x} =XBOOLE-0R4 Z1 implies  False "
          proof(rule impI)
            have A35: "x inTARSKIR2 {TARSKIK1 x}"
              using tarski_def_1 sorry
            assume "?Y1 =XBOOLE-0R4 Z1"
            thus " False "
              using A23 A35 xboole_0_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "Z1 inTARSKIR2 boolZFMISC-1K1 X"
          using A1 A21 sorry
        then have "?Y1 c=TARSKIR1 X"
          using A26 xboole_1_th_8 sorry
        then have "?Y1 inTARSKIR2 TS"
          using A2 A32 A33 sorry
        thus " False "
          using A22 A34 xboole_1_th_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have 
      [ty]:"Z1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
       sorry
    show " ex tVar7 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st Y c=TARSKIR1 tVar7"
    proof(rule bexI[of _ "Z1"])
      show "Y c=TARSKIR1 Z1"
        using A2 A21 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_20:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T implies ( ex Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st x inHIDDENR3 Z & y inHIDDENR3 Z)"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T implies ( ex tVar8 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st x inHIDDENR3 tVar8 & y inHIDDENR3 tVar8)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "[TARSKIK4 x,y ] inHIDDENR3 T"
    then have A2: "x inHIDDENR3 X & y inHIDDENR3 X"
      using zfmisc_1_th_87 sorry
    have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds a inTARSKIR2 {TARSKIK2 x,y } & b inTARSKIR2 {TARSKIK2 x,y } implies [TARSKIK4 a,b ] inHIDDENR3 T"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be setHIDDENM2"
      fix b assume [ty]: "b be setHIDDENM2"
      assume A3: "a inTARSKIR2 {TARSKIK2 x,y }"
        and A4: "b inTARSKIR2 {TARSKIK2 x,y }"
      have A5: "b =HIDDENR1 x or b =HIDDENR1 y"
        using A4 tarski_def_2 sorry
      have "a =HIDDENR1 x or a =HIDDENR1 y"
        using A3 tarski_def_2 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 T"
        using A1 A2 A5 toler_1_th_7 eqrel_1_th_6 sorry
    qed "sorry"
    then obtain PS where 
      [ty]:"PS be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T" and PSDef:"PS = {TARSKIK2 x,y }"
      using toler_1_def_1 sorry
    obtain Z where
      [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T" and 
      A6: "PS c=TARSKIR1 Z"
      using toler_1_th_19 sorry
    show " ex tVar8 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st x inHIDDENR3 tVar8 & y inHIDDENR3 tVar8"
    proof(rule bexI[of _ "Z"],rule conjMI)
      have "x inHIDDENR3 {TARSKIK2 x,y }"
        using tarski_def_2 sorry
      thus "x inHIDDENR3 Z"
        using A6 sorry
      have "y inHIDDENR3 {TARSKIK2 x,y }"
        using tarski_def_2 sorry
      thus "y inHIDDENR3 Z"
        using A6 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_21:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds x inTARSKIR2 X implies ( ex Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st x inTARSKIR2 Z)"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds x inTARSKIR2 X implies  not ( for Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T holds  not x inTARSKIR2 Z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be setHIDDENM2"
    assume "x inTARSKIR2 X"
    then have "[TARSKIK4 x,x ] inHIDDENR3 T"
      using toler_1_th_7 sorry
    then have " ex Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T st x inTARSKIR2 Z & x inTARSKIR2 Z"
      using toler_1_th_20 sorry
    thus " not ( for Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T holds  not x inTARSKIR2 Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_22:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T c=RELSET-1R1\<^bsub>(X,X)\<^esub> TotalTOLER-1K1 X"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T c=RELSET-1R1\<^bsub>(X,X)\<^esub> TotalTOLER-1K1 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T implies [TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 T"
      then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,X :]"
         sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 TotalTOLER-1K1 X"
        using eqrel_1_def_1 sorry
    qed "sorry"
    thus "T c=RELSET-1R1\<^bsub>(X,X)\<^esub> TotalTOLER-1K1 X"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_23:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds idPARTFUN1K6 X c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds idPARTFUN1K6 X c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idPARTFUN1K6 X implies [TARSKIK4 x,y ] inHIDDENR3 T"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 idPARTFUN1K6 X"
      then have "x inHIDDENR3 X & x =HIDDENR1 y"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 T"
        using toler_1_th_7 sorry
    qed "sorry"
    thus "idPARTFUN1K6 X c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem toler_1_sch_1:
  fixes Af0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
   A1: " for x be setHIDDENM2 holds x inTARSKIR2 Af0 implies Pp2(x,x)" and
   A2: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (x inTARSKIR2 Af0 & y inTARSKIR2 Af0) & Pp2(x,y) implies Pp2(y,x)"
  shows " ex T be ToleranceEQREL-1M1-of Af0 st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Af0 & y inTARSKIR2 Af0 implies ([TARSKIK4 x,y ] inHIDDENR3 T iff Pp2(x,y))"
  proof-
    have " ex tVar9 be ToleranceEQREL-1M1-of Af0 st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Af0 & y inTARSKIR2 Af0 implies ([TARSKIK4 x,y ] inHIDDENR3 tVar9 implies Pp2(x,y)) & (Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 tVar9)"
    proof-
      let ?X = "\<lambda>Lamb1.  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st Lamb1 =HIDDENR1 [TARSKIK4 y,z ] & Pp2(y,z)"
      obtain T where
        [ty]:"T be setHIDDENM2" and 
        A3: " for x be objectHIDDENM1 holds x inHIDDENR3 T iff x inHIDDENR3 [:ZFMISC-1K2 Af0,Af0 :] & ?X(x)"
        using xboole_0_sch_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 T implies x inHIDDENR3 [:ZFMISC-1K2 Af0,Af0 :]"
        using A3 sorry
      then have 
        [ty]:"T be RelationRELSET-1M1-of(Af0,Af0)"
        using tarski_def_3 sorry
      have A4: "fieldRELAT-1K3 T c=TARSKIR1 Af0 \\/XBOOLE-0K2 Af0"
        using relset_1_th_8 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 T implies [TARSKIK4 x,x ] inHIDDENR3 T"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 fieldRELAT-1K3 T"
        then have "[TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 Af0,Af0 :] & Pp2(x,x)"
          using A1 A4 zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x,x ] inHIDDENR3 T"
          using A3 sorry
      qed "sorry"
      then have A5: "T is-reflexive-inRELAT-2R1 fieldRELAT-1K3 T"
         sorry
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 fieldRELAT-1K3 T & y inHIDDENR3 fieldRELAT-1K3 T) & [TARSKIK4 x,y ] inHIDDENR3 T implies [TARSKIK4 y,x ] inHIDDENR3 T"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A6: "x inHIDDENR3 fieldRELAT-1K3 T & y inHIDDENR3 fieldRELAT-1K3 T"
          and A7: "[TARSKIK4 x,y ] inHIDDENR3 T"
        have "(x inHIDDENR3 Af0 & y inHIDDENR3 Af0) & Pp2(x,y)"
        proof(rule conjMI)
          show "x inHIDDENR3 Af0 & y inHIDDENR3 Af0"
            using A4 A6 sorry
          obtain a b where
            [ty]:"a be objectHIDDENM1" "b be objectHIDDENM1" and 
            A8: "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 a,b ]"and A9: "Pp2(a,b)"
            using A3 A7 sorry
          have "x =HIDDENR1 a"
            using A8 xtuple_0_th_1 sorry
          thus "Pp2(x,y)"
            using A8 A9 xtuple_0_th_1 sorry
        qed
        then have "[TARSKIK4 y,x ] inHIDDENR3 [:ZFMISC-1K2 Af0,Af0 :] & Pp2(y,x)"
          using A2 zfmisc_1_th_87 sorry
        thus "[TARSKIK4 y,x ] inHIDDENR3 T"
          using A3 sorry
      qed "sorry"
      then have A10: "T is-symmetric-inRELAT-2R3 fieldRELAT-1K3 T"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(Af0)\<^esub> T"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 Af0"
        then have "[TARSKIK4 x,x ] inHIDDENR3 [:ZFMISC-1K2 Af0,Af0 :] & Pp2(x,x)"
          using A1 zfmisc_1_th_87 sorry
        then have "[TARSKIK4 x,x ] inHIDDENR3 T"
          using A3 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(Af0)\<^esub> T"
          using xtuple_0_def_12 sorry
      qed "sorry"
      then have "Af0 c=TARSKIR1 domRELSET-1K1\<^bsub>(Af0)\<^esub> T"
         sorry
      then have "domRELSET-1K1\<^bsub>(Af0)\<^esub> T =XBOOLE-0R4 Af0"
        using xboole_0_def_10 sorry
      then have 
        [ty]:"T be ToleranceEQREL-1M1-of Af0"
        using A5 A10 partfun1_def_2 relat_2_def_9 relat_2_def_11 sorry
      show " ex tVar9 be ToleranceEQREL-1M1-of Af0 st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Af0 & y inTARSKIR2 Af0 implies ([TARSKIK4 x,y ] inHIDDENR3 tVar9 implies Pp2(x,y)) & (Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 tVar9)"
      proof(rule bexI[of _ "T"],rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        fix y assume [ty]: "y be setHIDDENM2"
        assume A11: "x inTARSKIR2 Af0 & y inTARSKIR2 Af0"
        show "[TARSKIK4 x,y ] inHIDDENR3 T implies Pp2(x,y)"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 T"
          then obtain a b where
            [ty]:"a be objectHIDDENM1" "b be objectHIDDENM1" and 
            A12: "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 a,b ]"and A13: "Pp2(a,b)"
            using A3 sorry
          have "x =HIDDENR1 a"
            using A12 xtuple_0_th_1 sorry
          thus "Pp2(x,y)"
            using A12 A13 xtuple_0_th_1 sorry
        qed
        assume A14: "Pp2(x,y)"
        have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Af0,Af0 :]"
          using A11 zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 T"
          using A3 A14 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem toler_1_th_24:
" for Y be setHIDDENM2 holds  ex T be ToleranceEQREL-1M1-of unionTARSKIK3 Y st  for Z be setHIDDENM2 holds Z inTARSKIR2 Y implies Z be TolSetTOLER-1M1\<^bsub>(unionTARSKIK3 Y)\<^esub>-of T"
proof-
  have " for Y be setHIDDENM2 holds  ex tVar10 be ToleranceEQREL-1M1-of unionTARSKIK3 Y st  for Z be setHIDDENM2 holds Z inTARSKIR2 Y implies Z be TolSetTOLER-1M1\<^bsub>(unionTARSKIK3 Y)\<^esub>-of tVar10"
  proof(rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & Lamb1 inTARSKIR2 Z) & Lamb2 inTARSKIR2 Z"
    have A1: " for x be setHIDDENM2 holds x inTARSKIR2 unionTARSKIK3 Y implies ?X(x,x)"
    proof-
      have " for x be setHIDDENM2 holds x inTARSKIR2 unionTARSKIK3 Y implies ( ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inTARSKIR2 Z) & x inTARSKIR2 Z)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 unionTARSKIK3 Y"
        then have " ex Z be setHIDDENM2 st x inTARSKIR2 Z & Z inTARSKIR2 Y"
          using tarski_def_4 sorry
        thus " ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inTARSKIR2 Z) & x inTARSKIR2 Z"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A2: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds (x inTARSKIR2 unionTARSKIK3 Y & y inTARSKIR2 unionTARSKIK3 Y) & ?X(x,y) implies ?X(y,x)"
       sorry
    obtain T where
      [ty]:"T be ToleranceEQREL-1M1-of unionTARSKIK3 Y" and 
      A3: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 unionTARSKIK3 Y & y inTARSKIR2 unionTARSKIK3 Y implies ([TARSKIK4 x,y ] inHIDDENR3 T iff ?X(x,y))"
      using toler_1_sch_1 A1 A2 sorry
    show " ex tVar10 be ToleranceEQREL-1M1-of unionTARSKIK3 Y st  for Z be setHIDDENM2 holds Z inTARSKIR2 Y implies Z be TolSetTOLER-1M1\<^bsub>(unionTARSKIK3 Y)\<^esub>-of tVar10"
    proof(rule bexI[of _ "T"],rule ballI,rule impI)
      fix Z assume [ty]: "Z be setHIDDENM2"
      assume A4: "Z inTARSKIR2 Y"
      have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Z & y inTARSKIR2 Z implies [TARSKIK4 x,y ] inHIDDENR3 T"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        fix y assume [ty]: "y be setHIDDENM2"
        assume A5: "x inTARSKIR2 Z & y inTARSKIR2 Z"
        then have "x inTARSKIR2 unionTARSKIK3 Y & y inTARSKIR2 unionTARSKIK3 Y"
          using A4 tarski_def_4 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 T"
          using A3 A4 A5 sorry
      qed "sorry"
      thus "Z be TolSetTOLER-1M1\<^bsub>(unionTARSKIK3 Y)\<^esub>-of T"
        using toler_1_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_25:
" for Y be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of unionTARSKIK3 Y holds  for R be ToleranceEQREL-1M1-of unionTARSKIK3 Y holds ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T iff ( ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inHIDDENR3 Z) & y inHIDDENR3 Z)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff ( ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inHIDDENR3 Z) & y inHIDDENR3 Z)) implies T =RELSET-1R2\<^bsub>(unionTARSKIK3 Y,unionTARSKIK3 Y)\<^esub> R"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix T assume [ty]: "T be ToleranceEQREL-1M1-of unionTARSKIK3 Y"
  fix R assume [ty]: "R be ToleranceEQREL-1M1-of unionTARSKIK3 Y"
  assume A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T iff ( ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inHIDDENR3 Z) & y inHIDDENR3 Z)"
    and A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff ( ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inHIDDENR3 Z) & y inHIDDENR3 Z)"
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T iff [TARSKIK4 x,y ] inHIDDENR3 R"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 T implies [TARSKIK4 x,y ] inHIDDENR3 R) & ([TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 T)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 T implies [TARSKIK4 x,y ] inHIDDENR3 R"
      proof(rule impI)
        assume "[TARSKIK4 x,y ] inHIDDENR3 T"
        then have " ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inHIDDENR3 Z) & y inHIDDENR3 Z"
          using A1 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A2 sorry
      qed
      assume "[TARSKIK4 x,y ] inHIDDENR3 R"
      then have " ex Z be setHIDDENM2 st (Z inTARSKIR2 Y & x inHIDDENR3 Z) & y inHIDDENR3 Z"
        using A2 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 T"
        using A1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "T =RELSET-1R2\<^bsub>(unionTARSKIK3 Y,unionTARSKIK3 Y)\<^esub> R"
     sorry
qed "sorry"

mtheorem toler_1_th_26:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds ( for Z be setHIDDENM2 holds Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T iff Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R) implies T =RELSET-1R2\<^bsub>(X,X)\<^esub> R"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds ( for Z be setHIDDENM2 holds Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T iff Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R) implies T =RELSET-1R2\<^bsub>(X,X)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix R assume [ty]: "R be ToleranceEQREL-1M1-of X"
    assume A1: " for Z be setHIDDENM2 holds Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T iff Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T iff [TARSKIK4 x,y ] inHIDDENR3 R"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 T implies [TARSKIK4 x,y ] inHIDDENR3 R) & ([TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 T)"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 T implies [TARSKIK4 x,y ] inHIDDENR3 R"
        proof(rule impI)
          assume "[TARSKIK4 x,y ] inHIDDENR3 T"
          then obtain Z where
            [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T" and 
            A2: "x inHIDDENR3 Z & y inHIDDENR3 Z"
            using toler_1_th_20 sorry
          have 
            [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R"
            using A1 sorry
          have "Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of R"
             sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 R"
            using A2 toler_1_def_1 sorry
        qed
        assume "[TARSKIK4 x,y ] inHIDDENR3 R"
        then obtain Z where
          [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R" and 
          A3: "x inHIDDENR3 Z & y inHIDDENR3 Z"
          using toler_1_th_20 sorry
        have 
          [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
          using A1 sorry
        have "Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
           sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 T"
          using A3 toler_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "T =RELSET-1R2\<^bsub>(X,X)\<^esub> R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax TOLER_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("neighbourhoodTOLER-1K4\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]164)
translations "neighbourhoodTOLER-1K4\<^bsub>(X,Y)\<^esub>(x,T)" \<rightharpoonup> "ClassEQREL-1K6(T,x)"

mtheorem toler_1_th_27:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds y inHIDDENR3 ImRELAT-1K12(T,x) iff [TARSKIK4 x,y ] inHIDDENR3 T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (y inHIDDENR3 ImRELAT-1K12(T,x) implies [TARSKIK4 x,y ] inHIDDENR3 T) & ([TARSKIK4 x,y ] inHIDDENR3 T implies y inHIDDENR3 ImRELAT-1K12(T,x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 ImRELAT-1K12(T,x) implies [TARSKIK4 x,y ] inHIDDENR3 T"
    proof(rule impI)
      assume "y inHIDDENR3 ImRELAT-1K12(T,x)"
      then have "[TARSKIK4 y,x ] inHIDDENR3 T"
        using eqrel_1_th_19 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 T"
        using eqrel_1_th_6 sorry
    qed
    assume "[TARSKIK4 x,y ] inHIDDENR3 T"
    then have "[TARSKIK4 y,x ] inHIDDENR3 T"
      using eqrel_1_th_6 sorry
    thus "y inHIDDENR3 ImRELAT-1K12(T,x)"
      using eqrel_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_28:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 Y iff x inTARSKIR2 Z & Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) implies ImRELAT-1K12(T,x) =XBOOLE-0R4 unionTARSKIK3 Y"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 Y iff x inTARSKIR2 Z & Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) implies ImRELAT-1K12(T,x) =XBOOLE-0R4 unionTARSKIK3 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: " for Z be setHIDDENM2 holds Z inTARSKIR2 Y iff x inTARSKIR2 Z & Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 ImRELAT-1K12(T,x) iff y inHIDDENR3 unionTARSKIK3 Y"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 ImRELAT-1K12(T,x) implies y inHIDDENR3 unionTARSKIK3 Y) & (y inHIDDENR3 unionTARSKIK3 Y implies y inHIDDENR3 ImRELAT-1K12(T,x))"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 ImRELAT-1K12(T,x) implies y inHIDDENR3 unionTARSKIK3 Y"
        proof(rule impI)
          assume "y inHIDDENR3 ImRELAT-1K12(T,x)"
          then have "[TARSKIK4 x,y ] inHIDDENR3 T"
            using toler_1_th_27 sorry
          then obtain Z where
            [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T" and 
            A2: "x inTARSKIR2 Z"and A3: "y inHIDDENR3 Z"
            using toler_1_th_20 sorry
          have "Z inTARSKIR2 Y"
            using A1 A2 sorry
          thus "y inHIDDENR3 unionTARSKIK3 Y"
            using A3 tarski_def_4 sorry
        qed
        assume "y inHIDDENR3 unionTARSKIK3 Y"
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A4: "y inHIDDENR3 Z"and A5: "Z inTARSKIR2 Y"
          using tarski_def_4 sorry
        have 
          [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
          using A1 A5 sorry
        have "x inTARSKIR2 Z"
          using A1 A5 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 T"
          using A4 toler_1_def_1 sorry
        thus "y inHIDDENR3 ImRELAT-1K12(T,x)"
          using toler_1_th_27 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "ImRELAT-1K12(T,x) =XBOOLE-0R4 unionTARSKIK3 Y"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_29:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 Y iff x inTARSKIR2 Z & Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) implies ImRELAT-1K12(T,x) =XBOOLE-0R4 unionTARSKIK3 Y"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for Y be setHIDDENM2 holds ( for Z be setHIDDENM2 holds Z inTARSKIR2 Y iff x inTARSKIR2 Z & Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) implies ImRELAT-1K12(T,x) =XBOOLE-0R4 unionTARSKIK3 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: " for Z be setHIDDENM2 holds Z inTARSKIR2 Y iff x inTARSKIR2 Z & Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 ImRELAT-1K12(T,x) iff y inHIDDENR3 unionTARSKIK3 Y"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 ImRELAT-1K12(T,x) implies y inHIDDENR3 unionTARSKIK3 Y) & (y inHIDDENR3 unionTARSKIK3 Y implies y inHIDDENR3 ImRELAT-1K12(T,x))"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 ImRELAT-1K12(T,x) implies y inHIDDENR3 unionTARSKIK3 Y"
        proof(rule impI)
          assume "y inHIDDENR3 ImRELAT-1K12(T,x)"
          then have "[TARSKIK4 x,y ] inHIDDENR3 T"
            using toler_1_th_27 sorry
          then obtain Z where
            [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T" and 
            A2: "x inTARSKIR2 Z"and A3: "y inHIDDENR3 Z"
            using toler_1_th_20 sorry
          have "Z inTARSKIR2 Y"
            using A1 A2 sorry
          thus "y inHIDDENR3 unionTARSKIK3 Y"
            using A3 tarski_def_4 sorry
        qed
        assume "y inHIDDENR3 unionTARSKIK3 Y"
        then obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A4: "y inHIDDENR3 Z"and A5: "Z inTARSKIR2 Y"
          using tarski_def_4 sorry
        have 
          [ty]:"Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
          using A1 A5 sorry
        have "x inTARSKIR2 Z"
          using A1 A5 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 T"
          using A4 toler_1_def_1 sorry
        thus "y inHIDDENR3 ImRELAT-1K12(T,x)"
          using toler_1_th_27 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "ImRELAT-1K12(T,x) =XBOOLE-0R4 unionTARSKIK3 Y"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef toler_1_def_3 ("TolSetsTOLER-1K5\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be setHIDDENM2", "T be ToleranceEQREL-1M1-of X"
"func TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for Y be setHIDDENM2 holds Y inTARSKIR2 it iff Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for Y be setHIDDENM2 holds Y inTARSKIR2 it iff Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
    proof-
      have " ex tVar11 be setHIDDENM2 st  for Y be setHIDDENM2 holds (Y inTARSKIR2 tVar11 implies Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & (Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T implies Y inTARSKIR2 tVar11)"
      proof-
        let ?X = "\<lambda>Lamb1. Lamb1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
        obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A1: " for x be setHIDDENM2 holds x inTARSKIR2 Z iff x inTARSKIR2 boolZFMISC-1K1 X & ?X(x)"
          using xfamily_sch_1 sorry
        show " ex tVar11 be setHIDDENM2 st  for Y be setHIDDENM2 holds (Y inTARSKIR2 tVar11 implies Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & (Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T implies Y inTARSKIR2 tVar11)"
        proof(rule bexI[of _ "Z"],rule ballI,rule conjMI,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          show "Y inTARSKIR2 Z implies Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using A1 sorry
          assume A2: "Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 X"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Y"
            then have "[TARSKIK4 x,x ] inHIDDENR3 T"
              using A2 toler_1_def_1 sorry
            thus "x inHIDDENR3 X"
              using zfmisc_1_th_87 sorry
          qed "sorry"
          then have "Y c=TARSKIR1 X"
             sorry
          thus "Y inTARSKIR2 Z"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for Y be setHIDDENM2 holds Y inTARSKIR2 it1 iff Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & ( for Y be setHIDDENM2 holds Y inTARSKIR2 it2 iff Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) implies it1 =HIDDENR1 it2"
    proof-
      have " for Z1 be setHIDDENM2 holds  for Z2 be setHIDDENM2 holds ( for Y be setHIDDENM2 holds Y inTARSKIR2 Z1 iff Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) & ( for Y be setHIDDENM2 holds Y inTARSKIR2 Z2 iff Y be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) implies Z1 =HIDDENR1 Z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1. Lamb1 be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
        fix Z1 assume [ty]: "Z1 be setHIDDENM2"
        fix Z2 assume [ty]: "Z2 be setHIDDENM2"
        assume A3: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z1 iff ?P(Y)"
          and A4: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z2 iff ?P(Y)"
        have "Z1 =XBOOLE-0R4 Z2"
          using xfamily_sch_2 A3 A4 sorry
        thus "Z1 =HIDDENR1 Z2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef toler_1_def_4 ("TolClassesTOLER-1K6\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "X be setHIDDENM2", "T be ToleranceEQREL-1M1-of X"
"func TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for Y be setHIDDENM2 holds Y inTARSKIR2 it iff Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for Y be setHIDDENM2 holds Y inTARSKIR2 it iff Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
    proof-
      have " ex tVar12 be setHIDDENM2 st  for Y be setHIDDENM2 holds (Y inTARSKIR2 tVar12 implies Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) & (Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T implies Y inTARSKIR2 tVar12)"
      proof-
        let ?X = "\<lambda>Lamb1. Lamb1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
        obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A5: " for x be setHIDDENM2 holds x inTARSKIR2 Z iff x inTARSKIR2 boolZFMISC-1K1 X & ?X(x)"
          using xfamily_sch_1 sorry
        show " ex tVar12 be setHIDDENM2 st  for Y be setHIDDENM2 holds (Y inTARSKIR2 tVar12 implies Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) & (Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T implies Y inTARSKIR2 tVar12)"
        proof(rule bexI[of _ "Z"],rule ballI,rule conjMI,rule impI)
          fix Y assume [ty]: "Y be setHIDDENM2"
          show "Y inTARSKIR2 Z implies Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
            using A5 sorry
          assume A6: "Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 X"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Y"
            then have "[TARSKIK4 x,x ] inHIDDENR3 T"
              using A6 toler_1_def_1 sorry
            thus "x inHIDDENR3 X"
              using zfmisc_1_th_87 sorry
          qed "sorry"
          then have "Y c=TARSKIR1 X"
             sorry
          thus "Y inTARSKIR2 Z"
            using A5 A6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for Y be setHIDDENM2 holds Y inTARSKIR2 it1 iff Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) & ( for Y be setHIDDENM2 holds Y inTARSKIR2 it2 iff Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) implies it1 =HIDDENR1 it2"
    proof-
      have " for C1 be setHIDDENM2 holds  for C2 be setHIDDENM2 holds ( for Y be setHIDDENM2 holds Y inTARSKIR2 C1 iff Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) & ( for Y be setHIDDENM2 holds Y inTARSKIR2 C2 iff Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T) implies C1 =HIDDENR1 C2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1. Lamb1 be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
        fix C1 assume [ty]: "C1 be setHIDDENM2"
        fix C2 assume [ty]: "C2 be setHIDDENM2"
        assume A7: " for Y be setHIDDENM2 holds Y inTARSKIR2 C1 iff ?P(Y)"
          and A8: " for Y be setHIDDENM2 holds Y inTARSKIR2 C2 iff ?P(Y)"
        have "C1 =XBOOLE-0R4 C2"
          using xfamily_sch_2 A7 A8 sorry
        thus "C1 =HIDDENR1 C2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem toler_1_th_30:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R c=TARSKIR1 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T implies R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R c=TARSKIR1 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T implies R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix R assume [ty]: "R be ToleranceEQREL-1M1-of X"
    assume A1: "TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R c=TARSKIR1 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 T"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 R"
      then obtain Z where
        [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R" and 
        A2: "x inHIDDENR3 Z & y inHIDDENR3 Z"
        using toler_1_th_20 sorry
      have "Z inTARSKIR2 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R"
        using toler_1_def_4 sorry
      then have "Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
        using A1 toler_1_def_4 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 T"
        using A2 toler_1_def_1 sorry
    qed "sorry"
    thus "R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_31:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T =XBOOLE-0R4 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R implies T =RELSET-1R2\<^bsub>(X,X)\<^esub> R"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T =XBOOLE-0R4 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R implies T =RELSET-1R2\<^bsub>(X,X)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix R assume [ty]: "R be ToleranceEQREL-1M1-of X"
    assume A1: "TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T =XBOOLE-0R4 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R"
    have " for Z be setHIDDENM2 holds Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T iff Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R"
    proof-
      have " for Z be setHIDDENM2 holds  not (Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T &  not Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R) &  not (Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R &  not Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T)"
      proof(rule ballI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        have "Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T iff Z inTARSKIR2 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> R"
          using A1 toler_1_def_4 sorry
        thus " not (Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T &  not Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R) &  not (Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R &  not Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T)"
          using toler_1_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "T =RELSET-1R2\<^bsub>(X,X)\<^esub> R"
      using toler_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_32:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T) iff x inHIDDENR3 X"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T) implies x inHIDDENR3 X) & (x inHIDDENR3 X implies x inHIDDENR3 unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T) implies x inHIDDENR3 X"
        proof(rule impI)
          assume "x inHIDDENR3 unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T)"
          then obtain Z where
            [ty]:"Z be setHIDDENM2" and 
            A1: "x inHIDDENR3 Z"and A2: "Z inTARSKIR2 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T"
            using tarski_def_4 sorry
          have "Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using A2 toler_1_def_4 sorry
          then have "Z c=TARSKIR1 X"
            using toler_1_th_18 sorry
          thus "x inHIDDENR3 X"
            using A1 sorry
        qed
        assume "x inHIDDENR3 X"
        then obtain Z where
          [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T" and 
          A3: "x inHIDDENR3 Z"
          using toler_1_th_21 sorry
        have "Z inTARSKIR2 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T"
          using toler_1_def_4 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T)"
          using A3 tarski_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "unionTARSKIK3 (TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T) =XBOOLE-0R4 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_33:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T) iff x inHIDDENR3 X"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T) implies x inHIDDENR3 X) & (x inHIDDENR3 X implies x inHIDDENR3 unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T) implies x inHIDDENR3 X"
        proof(rule impI)
          assume "x inHIDDENR3 unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T)"
          then obtain Z where
            [ty]:"Z be setHIDDENM2" and 
            A1: "x inHIDDENR3 Z"and A2: "Z inTARSKIR2 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
            using tarski_def_4 sorry
          have "Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
            using A2 toler_1_def_3 sorry
          then have "Z c=TARSKIR1 X"
            using toler_1_th_18 sorry
          thus "x inHIDDENR3 X"
            using A1 sorry
        qed
        assume "x inHIDDENR3 X"
        then obtain Z where
          [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T" and 
          A3: "x inHIDDENR3 Z"
          using toler_1_th_21 sorry
        have "Z inTARSKIR2 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
          using toler_1_def_3 sorry
        thus "x inHIDDENR3 unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T)"
          using A3 tarski_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "unionTARSKIK3 (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T) =XBOOLE-0R4 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_34:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(T,x) be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) implies T be transitiveRELAT-2V8"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(T,x) be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T) implies T be transitiveRELAT-2V8"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    assume A1: " for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(T,x) be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
    have A2: "fieldRELAT-1K3 T =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (((x inHIDDENR3 fieldRELAT-1K3 T & y inHIDDENR3 fieldRELAT-1K3 T) & z inHIDDENR3 fieldRELAT-1K3 T) & [TARSKIK4 x,y ] inHIDDENR3 T) & [TARSKIK4 y,z ] inHIDDENR3 T implies [TARSKIK4 x,z ] inHIDDENR3 T"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 T & (y inHIDDENR3 fieldRELAT-1K3 T & (z inHIDDENR3 fieldRELAT-1K3 T & ([TARSKIK4 x,y ] inHIDDENR3 T & [TARSKIK4 y,z ] inHIDDENR3 T))) implies [TARSKIK4 x,z ] inHIDDENR3 T"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "x inHIDDENR3 fieldRELAT-1K3 T"
          and A3: "y inHIDDENR3 fieldRELAT-1K3 T"
          and "z inHIDDENR3 fieldRELAT-1K3 T"
          and A4: "[TARSKIK4 x,y ] inHIDDENR3 T"
          and A5: "[TARSKIK4 y,z ] inHIDDENR3 T"
        obtain N where 
          [ty]:"N be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T" and NDef:"N = ImRELAT-1K12(T,y)"
          using A2 A1 A3 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 T"
          using A4 eqrel_1_th_6 sorry
        then have A6: "x inHIDDENR3 N"
          using toler_1_th_27 sorry
        have "z inHIDDENR3 N"
          using A5 toler_1_th_27 sorry
        thus "[TARSKIK4 x,z ] inHIDDENR3 T"
          using A6 toler_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "T is-transitive-inRELAT-2R8 fieldRELAT-1K3 T"
       sorry
    thus "T be transitiveRELAT-2V8"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_35:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T be transitiveRELAT-2V8 implies ( for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(T,x) be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T)"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T be transitiveRELAT-2V8 implies ( for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(T,x) be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T)"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    assume A1: "T be transitiveRELAT-2V8"
    fix x assume [ty]: "x be setHIDDENM2"
    assume A2: "x inTARSKIR2 X"
    let ?N = "ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(T,x)"
    have "fieldRELAT-1K3 T =XBOOLE-0R4 X"
      using orders_1_th_12 sorry
    then have A3: "T is-transitive-inRELAT-2R8 X"
      using A1 sorry
    have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 ?N & z inTARSKIR2 ?N implies [TARSKIK4 y,z ] inHIDDENR3 T"
    proof-
      have " for y be setHIDDENM2 holds  for z be setHIDDENM2 holds y inTARSKIR2 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(T,x) & z inTARSKIR2 ClassEQREL-1K7\<^bsub>(X,X)\<^esub>(T,x) implies [TARSKIK4 y,z ] inHIDDENR3 T"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix y assume [ty]: "y be setHIDDENM2"
        fix z assume [ty]: "z be setHIDDENM2"
        assume A4: "y inTARSKIR2 ?N"
          and A5: "z inTARSKIR2 ?N"
        have "[TARSKIK4 x,y ] inHIDDENR3 T"
          using A4 toler_1_th_27 sorry
        then have A6: "[TARSKIK4 y,x ] inHIDDENR3 T"
          using eqrel_1_th_6 sorry
        have "[TARSKIK4 x,z ] inHIDDENR3 T"
          using A5 toler_1_th_27 sorry
        thus "[TARSKIK4 y,z ] inHIDDENR3 T"
          using A3 A2 A4 A5 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then obtain Z where 
      [ty]:"Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T" and ZDef:"Z = ?N"
      using toler_1_def_1 sorry
    have " for x be setHIDDENM2 holds  not x inTARSKIR2 Z & x inTARSKIR2 X implies ( ex y be setHIDDENM2 st y inTARSKIR2 Z &  not [TARSKIK4 x,y ] inHIDDENR3 T)"
    proof-
      have " for y be setHIDDENM2 holds  not y inTARSKIR2 Z & y inTARSKIR2 X implies (( for z be setHIDDENM2 holds z inTARSKIR2 Z implies [TARSKIK4 y,z ] inHIDDENR3 T) implies  False )"
      proof(rule ballI,rule impMI ,rule impI,rule impI)
        fix y assume [ty]: "y be setHIDDENM2"
        assume A7: " not y inTARSKIR2 Z"
          and "y inTARSKIR2 X"
        have A8: "x inTARSKIR2 Z"
          using A2 eqrel_1_th_20 sorry
        assume " for z be setHIDDENM2 holds z inTARSKIR2 Z implies [TARSKIK4 y,z ] inHIDDENR3 T"
        then have "[TARSKIK4 y,x ] inHIDDENR3 T"
          using A8 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 T"
          using eqrel_1_th_6 sorry
        thus " False "
          using A7 toler_1_th_27 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "ImRELAT-1K12(T,x) be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
      using toler_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_36:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds  for Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T holds x inTARSKIR2 Y implies Y c=TARSKIR1 ImRELAT-1K12(T,x)"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for x be setHIDDENM2 holds  for Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T holds x inTARSKIR2 Y implies Y c=TARSKIR1 ImRELAT-1K12(T,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix x assume [ty]: "x be setHIDDENM2"
    fix Y assume [ty]: "Y be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of T"
    assume A1: "x inTARSKIR2 Y"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 ImRELAT-1K12(T,x)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 Y"
      then have "[TARSKIK4 x,y ] inHIDDENR3 T"
        using A1 toler_1_def_1 sorry
      thus "y inHIDDENR3 ImRELAT-1K12(T,x)"
        using toler_1_th_27 sorry
    qed "sorry"
    thus "Y c=TARSKIR1 ImRELAT-1K12(T,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_37:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T iff R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds (TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T implies R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T) & (R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T implies TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix R assume [ty]: "R be ToleranceEQREL-1M1-of X"
    show "TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T implies R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
    proof(rule impI)
      assume A1: "TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 T"
      proof(rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "[TARSKIK4 x,y ] inHIDDENR3 R"
        then obtain Z where
          [ty]:"Z be TolClassTOLER-1M2\<^bsub>(X)\<^esub>-of R" and 
          A2: "x inHIDDENR3 Z & y inHIDDENR3 Z"
          using toler_1_th_20 sorry
        have "Z inTARSKIR2 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R"
          using toler_1_def_3 sorry
        then have "Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
          using A1 toler_1_def_3 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 T"
          using A2 toler_1_def_1 sorry
      qed "sorry"
      thus "R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
        using relat_1_def_3 sorry
    qed
    assume A3: "R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R implies x inHIDDENR3 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R"
      then obtain Z where 
        [ty]:"Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of R" and ZDef:"Z = x"
        using toler_1_def_3 sorry
      have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Z & y inTARSKIR2 Z implies [TARSKIK4 x,y ] inHIDDENR3 T"
        using toler_1_def_1 A3 sorry
      then have "Z be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
        using toler_1_def_1 sorry
      thus "x inHIDDENR3 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
        using toler_1_def_3 sorry
    qed "sorry"
    thus "TolSetsTOLER-1K5\<^bsub>(X)\<^esub> R c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_38:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T implies x inHIDDENR3 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T"
      then have "x be TolSetTOLER-1M1\<^bsub>(X)\<^esub>-of T"
        using toler_1_def_4 sorry
      thus "x inHIDDENR3 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
        using toler_1_def_3 sorry
    qed "sorry"
    thus "TolClassesTOLER-1K6\<^bsub>(X)\<^esub> T c=TARSKIR1 TolSetsTOLER-1K5\<^bsub>(X)\<^esub> T"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_39:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(R,x) c=TARSKIR1 ImRELAT-1K12(T,x)) implies R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds  for R be ToleranceEQREL-1M1-of X holds ( for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(R,x) c=TARSKIR1 ImRELAT-1K12(T,x)) implies R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    fix R assume [ty]: "R be ToleranceEQREL-1M1-of X"
    assume A1: " for x be setHIDDENM2 holds x inTARSKIR2 X implies ImRELAT-1K12(R,x) c=TARSKIR1 ImRELAT-1K12(T,x)"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 T"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
      then have "x inHIDDENR3 X"
        using zfmisc_1_th_87 sorry
      then have A3: "ImRELAT-1K12(R,x) c=TARSKIR1 ImRELAT-1K12(T,x)"
        using A1 sorry
      have "y inHIDDENR3 ImRELAT-1K12(R,x)"
        using A2 toler_1_th_27 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 T"
        using A3 toler_1_th_27 sorry
    qed "sorry"
    thus "R c=RELSET-1R1\<^bsub>(X,X)\<^esub> T"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem toler_1_th_40:
" for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T c=RELSET-1R1\<^bsub>(X,X)\<^esub> T *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> T"
proof-
  have " for X be setHIDDENM2 holds  for T be ToleranceEQREL-1M1-of X holds T c=RELSET-1R1\<^bsub>(X,X)\<^esub> T *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> T"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix T assume [ty]: "T be ToleranceEQREL-1M1-of X"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 T implies [TARSKIK4 x,y ] inHIDDENR3 T *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> T"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "[TARSKIK4 x,y ] inHIDDENR3 T"
      then have "y inHIDDENR3 X"
        using zfmisc_1_th_87 sorry
      then have "[TARSKIK4 y,y ] inHIDDENR3 T"
        using toler_1_th_7 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 T *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> T"
        using A1 relat_1_def_8 sorry
    qed "sorry"
    thus "T c=RELSET-1R1\<^bsub>(X,X)\<^esub> T *RELSET-1K4\<^bsub>(X,X,X,X)\<^esub> T"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
