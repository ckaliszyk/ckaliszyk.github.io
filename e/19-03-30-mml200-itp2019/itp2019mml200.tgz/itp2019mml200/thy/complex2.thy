theory complex2
  imports comptrig funct_4
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem complex2_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies ( ex r be RealXREAL-0M1 st (r =COMPLEX1R1 b *XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 a /XCMPLX-0K7 b /]) +XCMPLX-0K2 a & 0NUMBERSK6 <=XXREAL-0R1 r) & r <XXREAL-0R3 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies ( ex r be setHIDDENM2 st r =COMPLEX1R1 b *XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 a /XCMPLX-0K7 b /]) +XCMPLX-0K2 a & (0NUMBERSK6 <=XXREAL-0R1 r &  not r <XXREAL-0R3 b))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
    let ?ab = "[\\INT-1K2 a /XCMPLX-0K7 b /]"
    let ?i = "-XCMPLX-0K4 ?ab"
    obtain r where 
      [ty]:"r be setHIDDENM2" and rDef:"r = b *XCMPLX-0K3 ?i +XCMPLX-0K2 a"
       sorry
    show " ex r be setHIDDENM2 st r =COMPLEX1R1 b *XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 a /XCMPLX-0K7 b /]) +XCMPLX-0K2 a & (0NUMBERSK6 <=XXREAL-0R1 r &  not r <XXREAL-0R3 b)"
    proof(rule bexI[of _ "r"],rule conjMI,rule conjMI)
      show "r =COMPLEX1R1 b *XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 a /XCMPLX-0K7 b /]) +XCMPLX-0K2 a"
         sorry
      have "?ab <=XXREAL-0R1 a /XCMPLX-0K7 b"
        using int_1_def_6 sorry
      then have "?ab *XCMPLX-0K3 b <=XXREAL-0R1 (a /XCMPLX-0K7 b)*XCMPLX-0K3 b"
        using A1 xreal_1_th_64 sorry
      then have "?ab *XCMPLX-0K3 b <=XXREAL-0R1 a"
        using A1 xcmplx_1_th_87 sorry
      then have "-XCMPLX-0K4 ?ab *XCMPLX-0K3 b >=XXREAL-0R2 -XCMPLX-0K4 a"
        using xreal_1_th_24 sorry
      then have "b *XCMPLX-0K3 ?i +XCMPLX-0K2 a >=XXREAL-0R2 a +XCMPLX-0K2 (-XCMPLX-0K4 a)"
        using xreal_1_th_6 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 r"
         sorry
      have "a /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 ?ab"
        using int_1_def_6 sorry
      then have "-XCMPLX-0K4 (a /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 ?i"
        using xreal_1_th_24 sorry
      then have "((-XCMPLX-0K4 a /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 b >XXREAL-0R4 ?i *XCMPLX-0K3 b"
        using A1 xreal_1_th_68 sorry
      then have "(-XCMPLX-0K4 (a /XCMPLX-0K7 b)*XCMPLX-0K3 b)+XCMPLX-0K2 b >XXREAL-0R4 ?i *XCMPLX-0K3 b"
         sorry
      then have "(-XCMPLX-0K4 a)+XCMPLX-0K2 b >XXREAL-0R4 ?i *XCMPLX-0K3 b"
        using A1 xcmplx_1_th_87 sorry
      then have "((-XCMPLX-0K4 a)+XCMPLX-0K2 b)+XCMPLX-0K2 a >XXREAL-0R4 r"
        using xreal_1_th_8 sorry
      thus " not r <XXREAL-0R3 b"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a >XXREAL-0R4 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & c >=XXREAL-0R2 0NUMBERSK6) & b <XXREAL-0R3 a) & c <XXREAL-0R3 a implies ( for i be IntegerINT-1M1 holds b =COMPLEX1R1 c +XCMPLX-0K2 a *XCMPLX-0K3 i implies b =COMPLEX1R1 c)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (b >=XXREAL-0R2 0NUMBERSK6 & (c >=XXREAL-0R2 0NUMBERSK6 & (b <XXREAL-0R3 a & c <XXREAL-0R3 a))) implies ( for i be IntegerINT-1M1 holds b =COMPLEX1R1 c +XCMPLX-0K2 a *XCMPLX-0K3 i implies b =COMPLEX1R1 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >=XXREAL-0R2 0NUMBERSK6"
      and A3: "c >=XXREAL-0R2 0NUMBERSK6"
      and A4: "b <XXREAL-0R3 a"
      and A5: "c <XXREAL-0R3 a"
    have A6: "0NUMBERSK6 +XCMPLX-0K2 a <=XXREAL-0R1 c +XCMPLX-0K2 a"
      using A3 xreal_1_th_7 sorry
    fix i assume [ty]: "i be IntegerINT-1M1"
    assume A7: "b =COMPLEX1R1 c +XCMPLX-0K2 a *XCMPLX-0K3 i"
    show "b =COMPLEX1R1 c"
    proof-
      have cases: "(i <XXREAL-0R3 0NUMBERSK6 or i =COMPLEX1R1 0NUMBERSK6) or i >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: "i <XXREAL-0R3 0NUMBERSK6 implies b =COMPLEX1R1 c"
      proof(rule impI)
        assume "i <XXREAL-0R3 0NUMBERSK6"
        then have "i <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
          using int_1_th_8 sorry
        then have "a *XCMPLX-0K3 i <=XXREAL-0R1 a *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
          using A1 xreal_1_th_64 sorry
        then have "c +XCMPLX-0K2 a *XCMPLX-0K3 i <=XXREAL-0R1 c -XCMPLX-0K6 a"
          using xreal_1_th_7 sorry
        thus "b =COMPLEX1R1 c"
          using A2 A5 A7 xreal_1_th_49 sorry
      qed
      have case2: "i =COMPLEX1R1 0NUMBERSK6 implies b =COMPLEX1R1 c"
      proof(rule impI)
        assume "i =COMPLEX1R1 0NUMBERSK6"
        thus "b =COMPLEX1R1 c"
          using A7 sorry
      qed
      have case3: "i >XXREAL-0R4 0NUMBERSK6 implies b =COMPLEX1R1 c"
      proof(rule impI)
        assume "i >XXREAL-0R4 0NUMBERSK6"
        then have "0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 i"
          using int_1_th_7 sorry
        then have "a *XCMPLX-0K3 i >=XXREAL-0R2 a"
          using A1 xreal_1_th_151 sorry
        then have "c +XCMPLX-0K2 a *XCMPLX-0K3 i >=XXREAL-0R2 c +XCMPLX-0K2 a"
          using xreal_1_th_7 sorry
        thus "b =COMPLEX1R1 c"
          using A4 A7 A6 xxreal_0_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds sinSIN-COSK18 (a -XCMPLX-0K6 b) =COMPLEX1R1 (sinSIN-COSK18 a)*XCMPLX-0K3 (cosSIN-COSK20 b) -XCMPLX-0K6 (cosSIN-COSK20 a)*XCMPLX-0K3 (sinSIN-COSK18 b) & cosSIN-COSK20 (a -XCMPLX-0K6 b) =COMPLEX1R1 (cosSIN-COSK20 a)*XCMPLX-0K3 (cosSIN-COSK20 b) +XCMPLX-0K2 (sinSIN-COSK18 a)*XCMPLX-0K3 (sinSIN-COSK18 b)"
proof-
  have " for th1 be RealXREAL-0M1 holds  for th2 be RealXREAL-0M1 holds sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2) & cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix th1 assume [ty]: "th1 be RealXREAL-0M1"
    fix th2 assume [ty]: "th2 be RealXREAL-0M1"
    have "sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2))"
      using sin_cos_def_17 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th2) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th2)"
      using sin_cos_th_74 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th2)"
      using sin_cos_th_30 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th2)"
      using sin_cos_th_30 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
      using sin_cos_def_17 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
      using sin_cos_def_19 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
      using sin_cos_def_19 sorry
    also have "... = (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos_def_17 sorry
    finally show "sinSIN-COSK18 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (sinSIN-COSK18 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) -XCMPLX-0K6 (cosSIN-COSK20 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
    have "cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 (th1 +XCMPLX-0K2 (-XCMPLX-0K4 th2))"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 th2) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th2)"
      using sin_cos_th_74 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 th2)"
      using sin_cos_th_30 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th2)"
      using sin_cos_th_30 sorry
    also have "... = (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 th2 +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 th1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
      using sin_cos_def_19 sorry
    also have "... = (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 th2"
      using sin_cos_def_17 sorry
    also have "... = (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
      using sin_cos_def_17 sorry
    finally show "cosSIN-COSK20 (th1 -XCMPLX-0K6 th2) =HIDDENR1 (cosSIN-COSK20 th1)*XCMPLX-0K3 (cosSIN-COSK20 th2) +XCMPLX-0K2 (sinSIN-COSK18 th1)*XCMPLX-0K3 (sinSIN-COSK18 th2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_4:
" for a be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 a & (cosSIN-COSK19).FUNCT-1K1 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 a"
proof-
  have " for th be RealXREAL-0M1 holds (sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th & (cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th"
  proof(rule ballI,rule conjMI)
    fix th assume [ty]: "th be RealXREAL-0M1"
    have "(sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 PISIN-COSK29) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 PISIN-COSK29)"
      using sin_cos_th_74 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 PISIN-COSK29)"
      using sin_cos_th_30 sorry
    also have "... = (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) +XCMPLX-0K2 (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29))"
      using sin_cos_th_30 sorry
    also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
      using sin_cos_th_76 sorry
    finally show "(sinSIN-COSK17).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 th"
       sorry
    have "(cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (-XCMPLX-0K4 PISIN-COSK29) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 PISIN-COSK29)"
      using sin_cos_th_74 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 (-XCMPLX-0K4 PISIN-COSK29)"
      using sin_cos_th_30 sorry
    also have "... = (cosSIN-COSK19).FUNCT-1K1 th *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 (PISIN-COSK29) -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 th *XCMPLX-0K3 (-XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 (PISIN-COSK29))"
      using sin_cos_th_30 sorry
    also have "... = -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th"
      using sin_cos_th_76 sorry
    finally show "(cosSIN-COSK19).FUNCT-1K1 (th -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 (cosSIN-COSK19).FUNCT-1K1 th"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_5:
" for a be RealXREAL-0M1 holds sinSIN-COSK18 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 a & cosSIN-COSK20 (a -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 a"
proof-
  have " for r be RealXREAL-0M1 holds sinSIN-COSK18 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 sinSIN-COSK18 r & cosSIN-COSK20 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 cosSIN-COSK20 r"
  proof(rule ballI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "sinSIN-COSK18 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 (sinSIN-COSK18 r)*XCMPLX-0K3 (cosSIN-COSK20 (PISIN-COSK29)) -XCMPLX-0K6 (cosSIN-COSK20 r)*XCMPLX-0K3 (sinSIN-COSK18 (PISIN-COSK29))"
      using complex2_th_3 sorry
    also have "... = -XCMPLX-0K4 sinSIN-COSK18 r"
      using sin_cos_th_77 sorry
    finally show "sinSIN-COSK18 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 sinSIN-COSK18 r"
       sorry
    have "cosSIN-COSK20 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 (cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 (PISIN-COSK29)) +XCMPLX-0K2 (sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 (PISIN-COSK29))"
      using complex2_th_3 sorry
    also have "... = -XCMPLX-0K4 cosSIN-COSK20 r"
      using sin_cos_th_77 sorry
    finally show "cosSIN-COSK20 (r -XCMPLX-0K6 PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 cosSIN-COSK20 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ & b inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies (a <XXREAL-0R3 b iff sinSIN-COSK18 a <XXREAL-0R3 sinSIN-COSK18 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ & b inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies (a <XXREAL-0R3 b implies sinSIN-COSK18 a <XXREAL-0R3 sinSIN-COSK18 b) & (sinSIN-COSK18 a <XXREAL-0R3 sinSIN-COSK18 b implies (a >=XXREAL-0R2 b implies  False ))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ & b inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
    then have A1: "a inHIDDENR3 (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17) & b inHIDDENR3 (].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      using sin_cos_th_24 xboole_0_def_4 sorry
    have A2: "sinSIN-COSK18 a =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 a & sinSIN-COSK18 b =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 b"
      using sin_cos_def_17 sorry
    thus "a <XXREAL-0R3 b implies sinSIN-COSK18 a <XXREAL-0R3 sinSIN-COSK18 b"
      using A1 rfunct_2_th_20 sin_cos2_th_2 sorry
    assume A3: "sinSIN-COSK18 a <XXREAL-0R3 sinSIN-COSK18 b"
    assume "a >=XXREAL-0R2 b"
    then have "a >XXREAL-0R4 b"
      using A3 xxreal_0_th_1 sorry
    thus " False "
      using A2 A1 A3 rfunct_2_th_20 sin_cos2_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ & b inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies (a <XXREAL-0R3 b iff sinSIN-COSK18 a >XXREAL-0R4 sinSIN-COSK18 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ & b inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies (a <XXREAL-0R3 b implies sinSIN-COSK18 a >XXREAL-0R4 sinSIN-COSK18 b) & (sinSIN-COSK18 a >XXREAL-0R4 sinSIN-COSK18 b implies (a >=XXREAL-0R2 b implies  False ))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ & b inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
    then have A1: "a inHIDDENR3 (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17) & b inHIDDENR3 (].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> domRELAT-1K1 (sinSIN-COSK17)"
      using sin_cos_th_24 xboole_0_def_4 sorry
    have A2: "sinSIN-COSK18 a =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 a & sinSIN-COSK18 b =COMPLEX1R1 (sinSIN-COSK17).FUNCT-1K1 b"
      using sin_cos_def_17 sorry
    thus "a <XXREAL-0R3 b implies sinSIN-COSK18 a >XXREAL-0R4 sinSIN-COSK18 b"
      using A1 rfunct_2_th_21 sin_cos2_th_3 sorry
    assume A3: "sinSIN-COSK18 a >XXREAL-0R4 sinSIN-COSK18 b"
    assume "a >=XXREAL-0R2 b"
    then have "a >XXREAL-0R4 b"
      using A3 xxreal_0_th_1 sorry
    thus " False "
      using A2 A1 A3 rfunct_2_th_21 sin_cos2_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_8:
" for a be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds sinSIN-COSK18 a =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 a)"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    have A1: "(sinSIN-COSK17).FUNCT-1K1 r =COMPLEX1R1 sinSIN-COSK18 r"
      using sin_cos_def_17 sorry
    have A2: "(sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r) =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
      using sin_cos_def_17 sorry
    have A3: "(sinSIN-COSK17).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i) +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)) =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i) +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r))"
      using sin_cos_def_17 sorry
    show "sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
    proof-
      have cases: "i >=XXREAL-0R2 0NUMBERSK6 or i <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "i >=XXREAL-0R2 0NUMBERSK6 implies sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
      proof(rule impI)
        assume "i >=XXREAL-0R2 0NUMBERSK6"
        then obtain iN where 
          [ty]:"iN be ElementSUBSET-1M1-of NATNUMBERSK1" and iNDef:"iN = i"
          using int_1_th_3 sorry
        have "sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 iN +XCMPLX-0K2 r)"
          using A1 A2 sin_cos2_th_10 sorry
        thus "sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
           sorry
      qed
      have case2: "i <XXREAL-0R3 0NUMBERSK6 implies sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
      proof(rule impI)
        assume "i <XXREAL-0R3 0NUMBERSK6"
        then obtain iN where 
          [ty]:"iN be ElementSUBSET-1M1-of NATNUMBERSK1" and iNDef:"iN = -XCMPLX-0K4 i"
          using int_1_th_3 sorry
        let ?aa = "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r"
        have "sinSIN-COSK18 ?aa =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 iN +XCMPLX-0K2 ?aa)"
          using A2 A3 sin_cos2_th_10 sorry
        thus "sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_9:
" for a be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds cosSIN-COSK20 a =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 a)"
proof-
  have " for r be RealXREAL-0M1 holds  for i be IntegerINT-1M1 holds cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix i assume [ty]: "i be IntegerINT-1M1"
    have A1: "(cosSIN-COSK19).FUNCT-1K1 r =COMPLEX1R1 cosSIN-COSK20 r"
      using sin_cos_def_19 sorry
    have A2: "(cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r) =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
      using sin_cos_def_19 sorry
    have A3: "(cosSIN-COSK19).FUNCT-1K1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i) +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)) =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 i) +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r))"
      using sin_cos_def_19 sorry
    show "cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
    proof-
      have cases: "i >=XXREAL-0R2 0NUMBERSK6 or i <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "i >=XXREAL-0R2 0NUMBERSK6 implies cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
      proof(rule impI)
        assume "i >=XXREAL-0R2 0NUMBERSK6"
        then obtain iN where 
          [ty]:"iN be ElementSUBSET-1M1-of NATNUMBERSK1" and iNDef:"iN = i"
          using int_1_th_3 sorry
        have "cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 iN +XCMPLX-0K2 r)"
          using A1 A2 sin_cos2_th_11 sorry
        thus "cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
           sorry
      qed
      have case2: "i <XXREAL-0R3 0NUMBERSK6 implies cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
      proof(rule impI)
        assume "i <XXREAL-0R3 0NUMBERSK6"
        then obtain iN where 
          [ty]:"iN be ElementSUBSET-1M1-of NATNUMBERSK1" and iNDef:"iN = -XCMPLX-0K4 i"
          using int_1_th_3 sorry
        let ?aa = "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r"
        have "cosSIN-COSK20 ?aa =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 iN +XCMPLX-0K2 ?aa)"
          using A2 A3 sin_cos2_th_11 sorry
        thus "cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 r)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_10:
" for a be RealXREAL-0M1 holds sinSIN-COSK18 a =COMPLEX1R1 0NUMBERSK6 implies cosSIN-COSK20 a <>HIDDENR2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds sinSIN-COSK18 a =COMPLEX1R1 0NUMBERSK6 & cosSIN-COSK20 a =COMPLEX1R1 0NUMBERSK6 implies  not  True "
  proof(rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "sinSIN-COSK18 a =COMPLEX1R1 0NUMBERSK6"
      and A2: "cosSIN-COSK20 a =COMPLEX1R1 0NUMBERSK6"
    obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "r =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 a /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) +XCMPLX-0K2 a"and A4: "0NUMBERSK6 <=XXREAL-0R1 r & r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_1 comptrig_th_5 sorry
    have A5: "cosSIN-COSK20 a =COMPLEX1R1 cosSIN-COSK20 r"
      using A3 complex2_th_9 sorry
    have "sinSIN-COSK18 a =COMPLEX1R1 sinSIN-COSK18 r"
      using A3 complex2_th_8 sorry
    then have "r =COMPLEX1R1 0NUMBERSK6 or r =COMPLEX1R1 PISIN-COSK29"
      using A4 A1 comptrig_th_17 sorry
    thus " not  True "
      using A5 A2 comptrig_th_5 comptrig_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((((0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & 0NUMBERSK6 <=XXREAL-0R1 b) & b <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & sinSIN-COSK18 a =COMPLEX1R1 sinSIN-COSK18 b) & cosSIN-COSK20 a =COMPLEX1R1 cosSIN-COSK20 b implies a =COMPLEX1R1 b"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ((r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & 0NUMBERSK6 <=XXREAL-0R1 s) & (s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & (sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 s & cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 s))) implies r =COMPLEX1R1 s"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: "r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & 0NUMBERSK6 <=XXREAL-0R1 s"
      and A3: "s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      and A4: "sinSIN-COSK18 r =COMPLEX1R1 sinSIN-COSK18 s & cosSIN-COSK20 r =COMPLEX1R1 cosSIN-COSK20 s"
    have A5: "cosSIN-COSK20 (r -XCMPLX-0K6 s) =HIDDENR1 (cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 s) +XCMPLX-0K2 (sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 s)"
      using complex2_th_3 sorry
    also have "... = \<one>\<^sub>M"
      using A4 sin_cos_th_29 sorry
    finally have "cosSIN-COSK20 (r -XCMPLX-0K6 s) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A6: "sinSIN-COSK18 (r -XCMPLX-0K6 s) =HIDDENR1 (sinSIN-COSK18 r)*XCMPLX-0K3 (cosSIN-COSK20 s) -XCMPLX-0K6 (cosSIN-COSK20 r)*XCMPLX-0K3 (sinSIN-COSK18 s)"
      using complex2_th_3 sorry
    also have "... = 0NUMBERSK6"
      using A4 sorry
    finally have "sinSIN-COSK18 (r -XCMPLX-0K6 s) =HIDDENR1 0NUMBERSK6"
       sorry
    have A7: "cosSIN-COSK20 (s -XCMPLX-0K6 r) =HIDDENR1 (cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 s) +XCMPLX-0K2 (sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 s)"
      using complex2_th_3 sorry
    also have "... = \<one>\<^sub>M"
      using A4 sin_cos_th_29 sorry
    finally have "cosSIN-COSK20 (s -XCMPLX-0K6 r) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A8: "sinSIN-COSK18 (s -XCMPLX-0K6 r) =HIDDENR1 (sinSIN-COSK18 s)*XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 (cosSIN-COSK20 s)*XCMPLX-0K3 (sinSIN-COSK18 r)"
      using complex2_th_3 sorry
    also have "... = 0NUMBERSK6"
      using A4 sorry
    finally have "sinSIN-COSK18 (s -XCMPLX-0K6 r) =HIDDENR1 0NUMBERSK6"
       sorry
    show "r =COMPLEX1R1 s"
    proof-
      have cases: "(r >XXREAL-0R4 s or r <XXREAL-0R3 s) or r =COMPLEX1R1 s"
        using xxreal_0_th_1 sorry
      have case1: "r >XXREAL-0R4 s implies r =COMPLEX1R1 s"
      proof(rule impI)
        assume A9: "r >XXREAL-0R4 s"
        have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 s"
          using A2 xreal_1_th_8 sorry
        then have A10: "r -XCMPLX-0K6 s <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          using xreal_1_th_19 sorry
        have "r >XXREAL-0R4 s +XCMPLX-0K2 0NUMBERSK6"
          using A9 sorry
        then have "0NUMBERSK6 <=XXREAL-0R1 r -XCMPLX-0K6 s"
          using xreal_1_th_20 sorry
        then have "r -XCMPLX-0K6 s =COMPLEX1R1 0NUMBERSK6 or r -XCMPLX-0K6 s =COMPLEX1R1 PISIN-COSK29"
          using A6 A10 comptrig_th_17 sorry
        thus "r =COMPLEX1R1 s"
          using A5 sin_cos_th_77 sorry
      qed
      have case2: "r <XXREAL-0R3 s implies r =COMPLEX1R1 s"
      proof(rule impI)
        assume "r <XXREAL-0R3 s"
        then have "s >XXREAL-0R4 r +XCMPLX-0K2 0NUMBERSK6"
           sorry
        then have A11: "0NUMBERSK6 <=XXREAL-0R1 s -XCMPLX-0K6 r"
          using xreal_1_th_20 sorry
        have "s +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 r"
          using A1 A3 xreal_1_th_8 sorry
        then have "s -XCMPLX-0K6 r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          using xreal_1_th_19 sorry
        then have "s -XCMPLX-0K6 r =COMPLEX1R1 0NUMBERSK6 or s -XCMPLX-0K6 r =COMPLEX1R1 PISIN-COSK29"
          using A8 A11 comptrig_th_17 sorry
        thus "r =COMPLEX1R1 s"
          using A7 sin_cos_th_77 sorry
      qed
      have case3: "r =COMPLEX1R1 s implies r =COMPLEX1R1 s"
      proof(rule impI)
        assume "r =COMPLEX1R1 s"
        thus "r =COMPLEX1R1 s"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mlemma complex2_lm_1:
"ArgCOMPTRIGK1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
  using comptrig_th_35 sorry

(*\$CT*)
mtheorem complex2_th_13:
" for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies ArgCOMPTRIGK1 (-XCMPLX-0K4 z) =COMPLEX1R1 ArgCOMPTRIGK1 z +XCMPLX-0K2 PISIN-COSK29) & (ArgCOMPTRIGK1 z >=XXREAL-0R2 PISIN-COSK29 implies ArgCOMPTRIGK1 (-XCMPLX-0K4 z) =COMPLEX1R1 ArgCOMPTRIGK1 z -XCMPLX-0K6 PISIN-COSK29)"
proof(rule ballI,rule impI,rule conjMI,rule impI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  assume A1: "z <>HIDDENR2 0NUMBERSK6"
  then have A2: " |.COMPLEX1K10 z.| <>HIDDENR2 0NUMBERSK6"
    using complex1_th_45 sorry
  have "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using comptrig_th_62 sorry
  then have A3: "-XCMPLX-0K4 z =COMPLEX1R1 (-XCMPLX-0K4 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 z)))+XCMPLX-0K2 (-XCMPLX-0K4 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 z)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
     sorry
  have "ArgCOMPTRIGK1 z <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using comptrig_th_34 sorry
  then have "ArgCOMPTRIGK1 z +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 PISIN-COSK29"
    using comptrig_th_5 xreal_1_th_8 sorry
  then have A4: "ArgCOMPTRIGK1 z -XCMPLX-0K6 PISIN-COSK29 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    using xreal_1_th_19 sorry
  have A5: "-XCMPLX-0K4 z =COMPLEX1R1 ( |.COMPLEX1K10 -XCMPLX-0K4 z .|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z))) +XCMPLX-0K2 (( |.COMPLEX1K10 -XCMPLX-0K4 z .|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using comptrig_th_62 sorry
  have A6: " |.COMPLEX1K10 z.| =COMPLEX1R1  |.COMPLEX1K10 -XCMPLX-0K4 z .|"
    using complex1_th_52 sorry
  then have "( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z))) =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 z))"
    using A5 A3 complex1_th_77 sorry
  then have A7: "sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 z)"
    using A2 xcmplx_1_th_5 sorry
  then have A8: "sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 sinSIN-COSK18 (ArgCOMPTRIGK1 z +XCMPLX-0K2 PISIN-COSK29)"
    using sin_cos_th_79 sorry
  have "( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z))) =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (-XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 z))"
    using A5 A3 A6 complex1_th_77 sorry
  then have A9: "cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 z)"
    using A2 xcmplx_1_th_5 sorry
  then have A10: "cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 cosSIN-COSK20 (ArgCOMPTRIGK1 z +XCMPLX-0K2 PISIN-COSK29)"
    using sin_cos_th_79 sorry
  show "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies ArgCOMPTRIGK1 (-XCMPLX-0K4 z) =COMPLEX1R1 ArgCOMPTRIGK1 z +XCMPLX-0K2 PISIN-COSK29"
  proof(rule impI)
    assume "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
    then have A11: "ArgCOMPTRIGK1 z +XCMPLX-0K2 PISIN-COSK29 <XXREAL-0R3 PISIN-COSK29 +XCMPLX-0K2 PISIN-COSK29"
      using xreal_1_th_8 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 z"
      using comptrig_th_34 sorry
    thus "ArgCOMPTRIGK1 (-XCMPLX-0K4 z) =COMPLEX1R1 ArgCOMPTRIGK1 z +XCMPLX-0K2 PISIN-COSK29"
      using A1 A5 A10 A8 A11 comptrig_th_5 comptrig_def_1 sorry
  qed
  assume "ArgCOMPTRIGK1 z >=XXREAL-0R2 PISIN-COSK29"
  then have A12: "ArgCOMPTRIGK1 z -XCMPLX-0K6 PISIN-COSK29 >=XXREAL-0R2 PISIN-COSK29 -XCMPLX-0K6 PISIN-COSK29"
    using xreal_1_th_9 sorry
  have A13: "sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 sinSIN-COSK18 (ArgCOMPTRIGK1 z -XCMPLX-0K6 PISIN-COSK29)"
    using A7 complex2_th_5 sorry
  have "cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 cosSIN-COSK20 (ArgCOMPTRIGK1 z -XCMPLX-0K6 PISIN-COSK29)"
    using A9 complex2_th_5 sorry
  thus "ArgCOMPTRIGK1 (-XCMPLX-0K4 z) =COMPLEX1R1 ArgCOMPTRIGK1 z -XCMPLX-0K6 PISIN-COSK29"
    using A1 A5 A13 A12 A4 comptrig_def_1 sorry
qed "sorry"

(*\$CT*)
mtheorem complex2_th_15:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 iff z =COMPLEX1R1  |.COMPLEX1K10 z.|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1  |.COMPLEX1K10 z.|) & (z =COMPLEX1R1  |.COMPLEX1K10 z.| implies ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule conjMI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 implies z =COMPLEX1R1  |.COMPLEX1K10 z.|"
    proof(rule impI)
      assume "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6"
      then have "z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (cosSIN-COSK20 (0NUMBERSK6)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (0NUMBERSK6)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
        using comptrig_th_62 sorry
      thus "z =COMPLEX1R1  |.COMPLEX1K10 z.|"
        using sin_cos_th_31 sorry
    qed
    assume "z =COMPLEX1R1  |.COMPLEX1K10 z.|"
    thus "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6"
      using comptrig_th_35 complex1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_16:
" for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 iff ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29) & (ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29 implies ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29)"
  proof(rule ballI,rule impI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z <>HIDDENR2 0NUMBERSK6"
    show "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29"
    proof(rule impI)
      have "ArgCOMPTRIGK1 z >=XXREAL-0R2 0NUMBERSK6"
        using comptrig_th_34 sorry
      then have A2: "PISIN-COSK29 +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 PISIN-COSK29 +XCMPLX-0K2 ArgCOMPTRIGK1 z"
        using xreal_1_th_7 sorry
      assume "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      thus "ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29"
        using A1 A2 complex2_th_13 sorry
    qed
    show "ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29 implies ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
    proof-
      have "ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29 implies  not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      proof(rule impI)
        have "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) >XXREAL-0R4 ArgCOMPTRIGK1 (-XCMPLX-0K4 z)"
          using comptrig_th_34 sorry
        then have A3: "(PISIN-COSK29 +XCMPLX-0K2 PISIN-COSK29)-XCMPLX-0K6 PISIN-COSK29 >XXREAL-0R4 ArgCOMPTRIGK1 (-XCMPLX-0K4 z) -XCMPLX-0K6 PISIN-COSK29"
          using xreal_1_th_9 sorry
        assume "ArgCOMPTRIGK1 (-XCMPLX-0K4 z) >=XXREAL-0R2 PISIN-COSK29"
        then have "ArgCOMPTRIGK1 (-XCMPLX-0K4 (-XCMPLX-0K4 z)) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 z) -XCMPLX-0K6 PISIN-COSK29"
          using A1 complex2_th_13 sorry
        thus " not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
          using A3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_17:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x <>HIDDENR2 y or x -XCMPLX-0K6 y <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 PISIN-COSK29 iff ArgCOMPTRIGK1 (y -XCMPLX-0K6 x) >=XXREAL-0R2 PISIN-COSK29)"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds z1 <>HIDDENR2 z2 or z1 -XCMPLX-0K6 z2 <>HIDDENR2 0NUMBERSK6 implies  not ( not ArgCOMPTRIGK1 (z1 -XCMPLX-0K6 z2) <XXREAL-0R3 PISIN-COSK29 &  not ArgCOMPTRIGK1 (z2 -XCMPLX-0K6 z1) >=XXREAL-0R2 PISIN-COSK29) &  not (ArgCOMPTRIGK1 (z2 -XCMPLX-0K6 z1) >=XXREAL-0R2 PISIN-COSK29 & ArgCOMPTRIGK1 (z1 -XCMPLX-0K6 z2) <XXREAL-0R3 PISIN-COSK29)"
  proof(rule ballI,rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume "z1 <>HIDDENR2 z2 or z1 -XCMPLX-0K6 z2 <>HIDDENR2 0NUMBERSK6"
    then have "z1 -XCMPLX-0K6 z2 <>HIDDENR2 0cCOMPLEX1K6"
       sorry
    then have "ArgCOMPTRIGK1 (z1 -XCMPLX-0K6 z2) <XXREAL-0R3 PISIN-COSK29 iff ArgCOMPTRIGK1 (-XCMPLX-0K4 (z1 -XCMPLX-0K6 z2)) >=XXREAL-0R2 PISIN-COSK29"
      using complex2_th_16 sorry
    thus " not ( not ArgCOMPTRIGK1 (z1 -XCMPLX-0K6 z2) <XXREAL-0R3 PISIN-COSK29 &  not ArgCOMPTRIGK1 (z2 -XCMPLX-0K6 z1) >=XXREAL-0R2 PISIN-COSK29) &  not (ArgCOMPTRIGK1 (z2 -XCMPLX-0K6 z1) >=XXREAL-0R2 PISIN-COSK29 & ArgCOMPTRIGK1 (z1 -XCMPLX-0K6 z2) <XXREAL-0R3 PISIN-COSK29)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_18:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ iff ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6) & (ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
    proof-
      have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
        then have A1: "0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
          using xxreal_1_th_4 sorry
        have A2: "(ArgCOMPTRIGK1 z <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) or ArgCOMPTRIGK1 z >XXREAL-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
          using xxreal_0_th_1 sorry
        have "(ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ &  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M & (ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6)) or ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ & (ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6)"
        proof-
          show "(ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ &  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M & (ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6)) or ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ & (ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6)"
          proof-
            have cases: "(ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ or ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) or ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
              using A1 A2 xxreal_1_th_4 sorry
            have case1: "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
              thus " not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
                using comptrig_th_41 sorry
            qed
            have case2: "ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
              thus " not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
                using comptrig_th_48 sin_cos_th_77 sorry
            qed
            have case3: "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ implies  not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
              thus " not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
                using comptrig_th_42 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
        thus " not ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A3: "].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .[ c=TARSKIR1 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using comptrig_th_5 xxreal_1_th_46 sorry
    have A4: "].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ c=TARSKIR1 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using comptrig_th_5 xxreal_1_th_46 sorry
    show "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
    proof(rule impI)
      assume A5: "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
      have "(ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 & (ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)) or ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & (ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
      proof-
        show "(ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 & ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[ or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 & (ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)) or ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & (ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .[)"
        proof-
          have cases: "(ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6) or ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
          proof(rule impI)
            assume "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
            then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
              using A5 comptrig_th_41 sorry
            thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using A4 sorry
          qed
          have case2: "ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
          proof(rule impI)
            assume "ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6"
            then have "z =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
              using complex1_th_13 sorry
            then have "ArgCOMPTRIGK1 z =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
              using A5 comptrig_th_37 sorry
            thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using comptrig_th_5 xxreal_1_th_4 sorry
          qed
          have case3: "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
          proof(rule impI)
            assume "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
            then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
              using A5 comptrig_th_42 sorry
            thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using A3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      thus "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_19:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 iff sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z <>HIDDENR2 0NUMBERSK6 implies (ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6) & (sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29)"
  proof(rule ballI,rule impI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "ArgCOMPTRIGK1 z >=XXREAL-0R2 0NUMBERSK6"
      using comptrig_th_34 sorry
    assume A2: "ArgCOMPTRIGK1 z <>HIDDENR2 0NUMBERSK6"
    show "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
    proof(rule impI)
      assume "ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
        using A2 A1 xxreal_1_th_4 sorry
      then have "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
        using complex2_th_18 sorry
      thus "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
        using comptrig_th_45 sorry
    qed
    have A3: "].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ c=TARSKIR1 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using comptrig_th_5 xxreal_1_th_46 sorry
    show "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
    proof-
      have "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6 implies  not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      proof(rule impI)
        assume A4: "sinSIN-COSK18 (ArgCOMPTRIGK1 z) >XXREAL-0R4 0NUMBERSK6"
        then have A5: "ImCOMPLEX1K4 z >XXREAL-0R4 0NUMBERSK6"
          using comptrig_th_48 sorry
        have " not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
        proof-
          show " not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
          proof-
            have cases: "(ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 or ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6) or ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6 implies  not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
            proof(rule impI)
              assume "ReCOMPLEX1K3 z >XXREAL-0R4 0NUMBERSK6"
              then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
                using A5 comptrig_th_41 sorry
              thus " not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
                using A3 xxreal_1_th_4 sorry
            qed
            have case2: "ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6 implies  not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
            proof(rule impI)
              assume "ReCOMPLEX1K3 z =COMPLEX1R1 0NUMBERSK6"
              then have "z =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
                using complex1_th_13 sorry
              thus " not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
                using A4 comptrig_th_5 comptrig_th_37 comptrig_th_48 sorry
            qed
            have case3: "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 implies  not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
            proof(rule impI)
              assume "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
              then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
                using A5 comptrig_th_42 sorry
              thus " not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
                using xxreal_1_th_4 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
        thus " not ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_20:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 x <XXREAL-0R3 PISIN-COSK29 & ArgCOMPTRIGK1 y <XXREAL-0R3 PISIN-COSK29 implies ArgCOMPTRIGK1 (x +XCMPLX-0K2 y) <XXREAL-0R3 PISIN-COSK29"
proof-
  have " for z1 be ComplexXCMPLX-0M1 holds  for z2 be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z1 <XXREAL-0R3 PISIN-COSK29 & ArgCOMPTRIGK1 z2 <XXREAL-0R3 PISIN-COSK29 implies  not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix z1 assume [ty]: "z1 be ComplexXCMPLX-0M1"
    fix z2 assume [ty]: "z2 be ComplexXCMPLX-0M1"
    assume A1: "ArgCOMPTRIGK1 z1 <XXREAL-0R3 PISIN-COSK29"
      and A2: "ArgCOMPTRIGK1 z2 <XXREAL-0R3 PISIN-COSK29"
    have A3: " |.COMPLEX1K10 z2.| =COMPLEX1R1  |.COMPLEX1K10 z2.| +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    have A4: " |.COMPLEX1K10 z1.| =COMPLEX1R1  |.COMPLEX1K10 z1.| +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    show " not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
    proof-
      have cases: "ArgCOMPTRIGK1 z1 =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z1 >XXREAL-0R4 0NUMBERSK6"
        using comptrig_th_34 sorry
      have case1: "ArgCOMPTRIGK1 z1 =COMPLEX1R1 0NUMBERSK6 implies  not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
      proof(rule impI)
        assume A5: "ArgCOMPTRIGK1 z1 =COMPLEX1R1 0NUMBERSK6"
        then have "z1 =COMPLEX1R1  |.COMPLEX1K10 z1.|"
          using complex2_th_15 sorry
        then have A6: "ImCOMPLEX1K4 z1 =COMPLEX1R1 0NUMBERSK6"
          using A4 complex1_th_12 sorry
        show " not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
        proof-
          have cases: "ArgCOMPTRIGK1 z2 =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z2 >XXREAL-0R4 0NUMBERSK6"
            using comptrig_th_34 sorry
          have case1: "ArgCOMPTRIGK1 z2 =COMPLEX1R1 0NUMBERSK6 implies  not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
          proof(rule impI)
            assume "ArgCOMPTRIGK1 z2 =COMPLEX1R1 0NUMBERSK6"
            then have "z2 =COMPLEX1R1  |.COMPLEX1K10 z2.|"
              using complex2_th_15 sorry
            then have A7: "z1 +XCMPLX-0K2 z2 =COMPLEX1R1 ( |.COMPLEX1K10 z1.| +XCMPLX-0K2  |.COMPLEX1K10 z2.|)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
              using A5 complex2_th_15 sorry
            have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 z1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 z2.|"
              using complex1_th_46 sorry
            thus " not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
              using A7 comptrig_th_5 comptrig_th_35 sorry
          qed
          have case2: "ArgCOMPTRIGK1 z2 >XXREAL-0R4 0NUMBERSK6 implies  not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
          proof(rule impI)
            assume "ArgCOMPTRIGK1 z2 >XXREAL-0R4 0NUMBERSK6"
            then have "ArgCOMPTRIGK1 z2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using A2 xxreal_1_th_4 sorry
            then have A8: "ImCOMPLEX1K4 z2 >XXREAL-0R4 0NUMBERSK6"
              using complex2_th_18 sorry
            have "ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
              using complex1_th_8 sorry
            then have "ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using A6 A8 complex2_th_18 sorry
            thus " not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
              using xxreal_1_th_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "ArgCOMPTRIGK1 z1 >XXREAL-0R4 0NUMBERSK6 implies  not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
      proof(rule impI)
        assume "ArgCOMPTRIGK1 z1 >XXREAL-0R4 0NUMBERSK6"
        then have "ArgCOMPTRIGK1 z1 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
          using A1 xxreal_1_th_4 sorry
        then have A9: "ImCOMPLEX1K4 z1 >XXREAL-0R4 0NUMBERSK6"
          using complex2_th_18 sorry
        show " not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
        proof-
          have cases: "ArgCOMPTRIGK1 z2 =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z2 >XXREAL-0R4 0NUMBERSK6"
            using comptrig_th_34 sorry
          have case1: "ArgCOMPTRIGK1 z2 =COMPLEX1R1 0NUMBERSK6 implies  not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
          proof(rule impI)
            assume "ArgCOMPTRIGK1 z2 =COMPLEX1R1 0NUMBERSK6"
            then have "z2 =COMPLEX1R1  |.COMPLEX1K10 z2.|"
              using complex2_th_15 sorry
            then have A10: "ImCOMPLEX1K4 z2 =COMPLEX1R1 0NUMBERSK6"
              using A3 complex1_th_12 sorry
            have "ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
              using complex1_th_8 sorry
            then have "ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using A9 A10 complex2_th_18 sorry
            thus " not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
              using xxreal_1_th_4 sorry
          qed
          have case2: "ArgCOMPTRIGK1 z2 >XXREAL-0R4 0NUMBERSK6 implies  not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
          proof(rule impI)
            assume "ArgCOMPTRIGK1 z2 >XXREAL-0R4 0NUMBERSK6"
            then have "ArgCOMPTRIGK1 z2 inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using A2 xxreal_1_th_4 sorry
            then have A11: "ImCOMPLEX1K4 z2 >XXREAL-0R4 0NUMBERSK6"
              using complex2_th_18 sorry
            have "ImCOMPLEX1K4 (z1 +XCMPLX-0K2 z2) =COMPLEX1R1 ImCOMPLEX1K4 z1 +REAL-1K3 ImCOMPLEX1K4 z2"
              using complex1_th_8 sorry
            then have "ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
              using A9 A11 complex2_th_18 sorry
            thus " not ArgCOMPTRIGK1 (z1 +XCMPLX-0K2 z2) <XXREAL-0R3 PISIN-COSK29"
              using xxreal_1_th_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_21:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 iff ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6) & (ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: " |.COMPLEX1K10 z.| =COMPLEX1R1  |.COMPLEX1K10 z.| +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    show "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6"
      then have A2: "z =COMPLEX1R1  |.COMPLEX1K10 z.|"
        using complex2_th_15 sorry
      then have "ReCOMPLEX1K3 z =COMPLEX1R1  |.COMPLEX1K10 z.|"
        using A1 complex1_th_12 sorry
      thus "ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 complex1_th_12 complex1_th_46 sorry
    qed
    assume A3: "ReCOMPLEX1K3 z >=XXREAL-0R2 0NUMBERSK6"
      and A4: "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
    have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A4 complex1_th_13 sorry
    thus "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6"
      using A3 comptrig_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_22:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 iff ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6) & (ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume A1: "ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
      show "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
      proof-
        have cases: "z <>HIDDENR2 0NUMBERSK6 or z =COMPLEX1R1 0NUMBERSK6"
           sorry
        have case1: "z <>HIDDENR2 0NUMBERSK6 implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
        proof(rule impI,rule conjMI)
          assume A2: "z <>HIDDENR2 0NUMBERSK6"
          obtain zz where 
            [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz =  |.COMPLEX1K10 z.|"
            using xreal_0_def_1 sorry
          have A3: "z =COMPLEX1R1 zz *XCMPLX-0K3 (cosSIN-COSK20 (PISIN-COSK29)) +XCMPLX-0K2 (( |.COMPLEX1K10 z.|)*XCMPLX-0K3 (sinSIN-COSK18 (PISIN-COSK29)))*XCMPLX-0K3 (<i>COMPLEX1K8) & -XCMPLX-0K4 (-XCMPLX-0K4  |.COMPLEX1K10 z.|) >XXREAL-0R4 0NUMBERSK6"
            using A1 complex1_th_47 comptrig_def_1 A2 sorry
          have "cosSIN-COSK20 (PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M & sinSIN-COSK18 (PISIN-COSK29) =COMPLEX1R1 0NUMBERSK6"
            using sin_cos_th_77 sorry
          then have A5: "z =COMPLEX1R1 zz *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) +XCMPLX-0K2 (zz *XCMPLX-0K3 (0NUMBERSK6))*XCMPLX-0K3 (<i>COMPLEX1K8)"
            using A3 sorry
          thus "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
            using complex1_def_1 A3 sorry
          show "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
            using complex1_def_2 A5 sorry
        qed
        have case2: "z =COMPLEX1R1 0NUMBERSK6 implies ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
        proof(rule impI)
          assume "z =COMPLEX1R1 0NUMBERSK6"
          thus "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6 & ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
            using A1 comptrig_th_5 comptrig_th_35 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    assume A6: "ReCOMPLEX1K3 z <XXREAL-0R3 0NUMBERSK6"
      and A7: "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
    have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A7 complex1_th_13 sorry
    thus "ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
      using A6 comptrig_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_23:
" for z be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 iff ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
proof-
  have " for z be ComplexXCMPLX-0M1 holds (ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29) & (ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 implies ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule conjMI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    show "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
    proof(rule impI)
      have A1: "ArgCOMPTRIGK1 (ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 (ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 PISIN-COSK29"
        using comptrig_th_35 comptrig_th_36 sorry
      assume "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
      thus "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
        using A1 complex1_th_13 sorry
    qed
    assume "ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29"
    thus "ImCOMPLEX1K4 z =COMPLEX1R1 0NUMBERSK6"
      using complex2_th_21 complex2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_24:
" for z be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 z <=XXREAL-0R1 PISIN-COSK29 implies ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
proof(rule ballI,rule impI)
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  assume A1: "ArgCOMPTRIGK1 z <=XXREAL-0R1 PISIN-COSK29"
  show "ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
  proof-
    have cases: "(ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 or ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6) or 0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      using A1 comptrig_th_34 xxreal_0_th_1 sorry
    have case1: "ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 or ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6 implies ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
    proof(rule impI)
      assume "ArgCOMPTRIGK1 z =COMPLEX1R1 PISIN-COSK29 or ArgCOMPTRIGK1 z =COMPLEX1R1 0NUMBERSK6"
      thus "ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
        using complex2_th_23 sorry
    qed
    have case2: "0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29 implies ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
    proof(rule impI)
      assume "0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 z & ArgCOMPTRIGK1 z <XXREAL-0R3 PISIN-COSK29"
      then have "ArgCOMPTRIGK1 z inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
        using xxreal_1_th_4 sorry
      thus "ImCOMPLEX1K4 z >=XXREAL-0R2 0NUMBERSK6"
        using complex2_th_18 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem complex2_th_25:
" for z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds z <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 z) & sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 z)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 z)"
proof-
  have " for a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds a <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 a) & sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a)"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have A1: " |.COMPLEX1K10 -XCMPLX-0K4 a .| =COMPLEX1R1  |.COMPLEX1K10 a.|"
      using complex1_th_52 sorry
    assume "a <>HIDDENR2 0NUMBERSK6"
    then have A2: " |.COMPLEX1K10 a.| <>HIDDENR2 0NUMBERSK6"
      using complex1_th_45 sorry
    have "a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8) & -XCMPLX-0K4 a =COMPLEX1R1 ( |.COMPLEX1K10 -XCMPLX-0K4 a .|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))) +XCMPLX-0K2 (( |.COMPLEX1K10 -XCMPLX-0K4 a .|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_th_62 sorry
    then have A3: "0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))))+XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 sorry
    then have "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a) +XCMPLX-0K2 sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))) =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_4 complex1_th_12 sorry
    then have A4: "sinSIN-COSK18 (ArgCOMPTRIGK1 a) +XCMPLX-0K2 (-XCMPLX-0K4 (-XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a)))) =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    have "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a) +XCMPLX-0K2 cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))) =COMPLEX1R1 0NUMBERSK6"
      using A3 complex1_th_4 complex1_th_12 sorry
    then have "cosSIN-COSK20 (ArgCOMPTRIGK1 a) +XCMPLX-0K2 (-XCMPLX-0K4 (-XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a)))) =COMPLEX1R1 0NUMBERSK6"
      using A2 sorry
    thus "cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 a) & sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a)"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_26:
" for a be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|) & sinSIN-COSK18 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
proof(rule ballI,rule impI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  have "a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using comptrig_th_62 sorry
  then have A1: "ReCOMPLEX1K3 a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) & ImCOMPLEX1K4 a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a))"
    using complex1_th_12 sorry
  assume "a <>HIDDENR2 0NUMBERSK6"
  thus "cosSIN-COSK20 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|) & sinSIN-COSK18 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
    using A1 complex1_th_45 xcmplx_1_th_89 sorry
qed "sorry"

mtheorem complex2_th_27:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume A1: "r >XXREAL-0R4 0NUMBERSK6"
  show "ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
  proof-
    have cases: "a =COMPLEX1R1 0NUMBERSK6 or a <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "a =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
    proof(rule impI)
      assume "a =COMPLEX1R1 0NUMBERSK6"
      thus "ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
         sorry
    qed
    have case2: "a <>HIDDENR2 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
    proof(rule impI)
      assume A2: "a <>HIDDENR2 0NUMBERSK6"
      then have A3: "sinSIN-COSK18 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
        using complex2_th_26 sorry
      let ?b = "a *XCMPLX-0K3 r"
      have A4: " |.COMPLEX1K10 ?b.| =HIDDENR1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 r"
        using A1 absvalue_def_1 sorry
      finally have " |.COMPLEX1K10 ?b.| =HIDDENR1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 r"
         sorry
      have A5: "cosSIN-COSK20 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
        using A2 complex2_th_26 sorry
      have A6: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 a & ArgCOMPTRIGK1 a <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using comptrig_th_34 sorry
      have "r =COMPLEX1R1 r +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
         sorry
      then have A7: "ReCOMPLEX1K3 r =COMPLEX1R1 r & ImCOMPLEX1K4 r =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_12 sorry
      then have A8: "ImCOMPLEX1K4 ?b =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 r *XCMPLX-0K3 ImCOMPLEX1K4 a"
        using complex1_th_9 sorry
      also have "... = r *XCMPLX-0K3 ImCOMPLEX1K4 a"
         sorry
      finally have "ImCOMPLEX1K4 ?b =HIDDENR1 r *XCMPLX-0K3 ImCOMPLEX1K4 a"
         sorry
      have A9: "sinSIN-COSK18 (ArgCOMPTRIGK1 ?b) =HIDDENR1 ImCOMPLEX1K4 ?b /XCMPLX-0K7 ( |.COMPLEX1K10 ?b.|)"
        using A1 A2 complex2_th_26 sorry
      also have "... = sinSIN-COSK18 (ArgCOMPTRIGK1 a)"
        using A1 A8 A4 A3 xcmplx_1_th_91 sorry
      finally have "sinSIN-COSK18 (ArgCOMPTRIGK1 ?b) =HIDDENR1 sinSIN-COSK18 (ArgCOMPTRIGK1 a)"
         sorry
      have A10: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 ?b & ArgCOMPTRIGK1 ?b <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using comptrig_th_34 sorry
      have A11: "ReCOMPLEX1K3 ?b =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 r -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 a"
        using A7 complex1_th_9 sorry
      also have "... = r *XCMPLX-0K3 ReCOMPLEX1K3 a"
         sorry
      finally have "ReCOMPLEX1K3 ?b =HIDDENR1 r *XCMPLX-0K3 ReCOMPLEX1K3 a"
         sorry
      have "cosSIN-COSK20 (ArgCOMPTRIGK1 ?b) =HIDDENR1 ReCOMPLEX1K3 ?b /XCMPLX-0K7 ( |.COMPLEX1K10 ?b.|)"
        using A1 A2 complex2_th_26 sorry
      also have "... = cosSIN-COSK20 (ArgCOMPTRIGK1 a)"
        using A1 A11 A4 A5 xcmplx_1_th_91 sorry
      finally have "cosSIN-COSK20 (ArgCOMPTRIGK1 ?b) =HIDDENR1 cosSIN-COSK20 (ArgCOMPTRIGK1 a)"
         sorry
      thus "ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
        using A9 A10 A6 complex2_th_11 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem complex2_th_28:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume A1: "r <XXREAL-0R3 0NUMBERSK6"
  show "ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
  proof-
    have cases: "a =COMPLEX1R1 0NUMBERSK6 or a <>HIDDENR2 0NUMBERSK6"
       sorry
    have case1: "a =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
    proof(rule impI)
      assume "a =COMPLEX1R1 0NUMBERSK6"
      thus "ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
         sorry
    qed
    have case2: "a <>HIDDENR2 0NUMBERSK6 implies ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
    proof(rule impI)
      assume A2: "a <>HIDDENR2 0NUMBERSK6"
      then have A3: "cosSIN-COSK20 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
        using complex2_th_26 sorry
      have A4: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a) & ArgCOMPTRIGK1 (-XCMPLX-0K4 a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using comptrig_th_34 sorry
      have A5: "sinSIN-COSK18 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
        using A2 complex2_th_26 sorry
      let ?b = "a *XCMPLX-0K3 r"
      have A6: "a inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      have A7: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 ?b & ArgCOMPTRIGK1 ?b <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using comptrig_th_34 sorry
      have A8: " |.COMPLEX1K10 ?b.| =HIDDENR1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 r)"
        using A1 absvalue_def_1 sorry
      finally have " |.COMPLEX1K10 ?b.| =HIDDENR1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 r)"
         sorry
      have "r =COMPLEX1R1 r +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
         sorry
      then have A9: "ReCOMPLEX1K3 r =COMPLEX1R1 r & ImCOMPLEX1K4 r =COMPLEX1R1 0NUMBERSK6"
        using complex1_th_12 sorry
      then have "ImCOMPLEX1K4 ?b =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 r *XCMPLX-0K3 ImCOMPLEX1K4 a"
        using complex1_th_9 sorry
      also have "... = r *XCMPLX-0K3 ImCOMPLEX1K4 a"
         sorry
      finally have "ImCOMPLEX1K4 ?b =HIDDENR1 r *XCMPLX-0K3 ImCOMPLEX1K4 a"
         sorry
      then have A10: "sinSIN-COSK18 (ArgCOMPTRIGK1 ?b) =HIDDENR1 (r *XCMPLX-0K3 ImCOMPLEX1K4 a)/XCMPLX-0K7 (-XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 r)"
        using A1 A2 A8 complex2_th_26 sorry
      also have "... = -XCMPLX-0K4 (r *XCMPLX-0K3 ImCOMPLEX1K4 a)/XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 r)"
        using xcmplx_1_th_188 sorry
      also have "... = -XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a)"
        using A1 A5 xcmplx_1_th_91 sorry
      also have "... = sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))"
        using A2 A6 complex2_th_25 sorry
      finally have "sinSIN-COSK18 (ArgCOMPTRIGK1 ?b) =HIDDENR1 sinSIN-COSK18 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))"
         sorry
      have "ReCOMPLEX1K3 ?b =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 r -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 ImCOMPLEX1K4 a"
        using A9 complex1_th_9 sorry
      also have "... = r *XCMPLX-0K3 ReCOMPLEX1K3 a"
         sorry
      finally have "ReCOMPLEX1K3 ?b =HIDDENR1 r *XCMPLX-0K3 ReCOMPLEX1K3 a"
         sorry
      then have "cosSIN-COSK20 (ArgCOMPTRIGK1 ?b) =HIDDENR1 (r *XCMPLX-0K3 ReCOMPLEX1K3 a)/XCMPLX-0K7 (-XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 r)"
        using A1 A2 A8 complex2_th_26 sorry
      also have "... = -XCMPLX-0K4 (r *XCMPLX-0K3 ReCOMPLEX1K3 a)/XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 r)"
        using xcmplx_1_th_188 sorry
      also have "... = -XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 a)"
        using A1 A3 xcmplx_1_th_91 sorry
      also have "... = cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))"
        using A2 A6 complex2_th_25 sorry
      finally have "cosSIN-COSK20 (ArgCOMPTRIGK1 ?b) =HIDDENR1 cosSIN-COSK20 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a))"
         sorry
      thus "ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
        using A10 A7 A4 complex2_th_11 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

(*begin*)
mdef complex2_def_1 (" _ .|.COMPLEX2K1  _ " [210,210]210 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"func x .|.COMPLEX2K1 y \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  x *XCMPLX-0K3 y *'COMPLEX1K9"
proof-
  (*coherence*)
    show "x *XCMPLX-0K3 y *'COMPLEX1K9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

reserve a, b, c, d, x, y, z for "ComplexXCMPLX-0M1"
mtheorem complex2_th_29:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 y =COMPLEX1R1 (ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y)+XCMPLX-0K2 ((-REAL-1K1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y)+REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 y =COMPLEX1R1 (ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y)+XCMPLX-0K2 ((-REAL-1K1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y)+REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "x =COMPLEX1R1 ReCOMPLEX1K3 x +XCMPLX-0K2 ImCOMPLEX1K4 x *XCMPLX-0K3 (<i>COMPLEX1K8) & y *'COMPLEX1K9 =COMPLEX1R1 ReCOMPLEX1K3 y -XCMPLX-0K6 ImCOMPLEX1K4 y *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 complex1_def_11 sorry
    thus "x .|.COMPLEX2K1 y =COMPLEX1R1 (ReCOMPLEX1K3 x *REAL-1K4 ReCOMPLEX1K3 y +REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ImCOMPLEX1K4 y)+XCMPLX-0K2 ((-REAL-1K1 ReCOMPLEX1K3 x *REAL-1K4 ImCOMPLEX1K4 y)+REAL-1K3 ImCOMPLEX1K4 x *REAL-1K4 ReCOMPLEX1K3 y)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_30:
" for z be ComplexXCMPLX-0M1 holds z .|.COMPLEX2K1 z =COMPLEX1R1 ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z & z .|.COMPLEX2K1 z =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
proof-
  have " for z be ComplexXCMPLX-0M1 holds z .|.COMPLEX2K1 z =HIDDENR1 ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z & z .|.COMPLEX2K1 z =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z .|.COMPLEX2K1 z =HIDDENR1 (ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z)+XCMPLX-0K2 ((-REAL-1K1 ImCOMPLEX1K4 z *REAL-1K4 ReCOMPLEX1K3 z)+REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ReCOMPLEX1K3 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex2_th_29 sorry
    also have "... = ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z"
       sorry
    finally show "z .|.COMPLEX2K1 z =HIDDENR1 ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 z +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 z"
       sorry
    thus "z .|.COMPLEX2K1 z =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_31:
" for z be ComplexXCMPLX-0M1 holds z .|.COMPLEX2K1 z =COMPLEX1R1 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 & ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 ReCOMPLEX1K3 (z .|.COMPLEX2K1 z)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds z .|.COMPLEX2K1 z =HIDDENR1 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 & ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 ReCOMPLEX1K3 (z .|.COMPLEX2K1 z)"
  proof(rule ballI,rule conjMI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A1: "(ReCOMPLEX1K3 z)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & (ImCOMPLEX1K4 z)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A2: " |.COMPLEX1K10 z.| =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using complex1_def_12 sorry
    have A3: "z .|.COMPLEX2K1 z =HIDDENR1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using complex2_th_30 sorry
    also have "... = ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
      using A1 A2 square_1_def_2 sorry
    finally show "z .|.COMPLEX2K1 z =HIDDENR1 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1"
       sorry
    have "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 ReCOMPLEX1K3 (z .|.COMPLEX2K1 z)"
      using A3 complex1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_32:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 x .|.COMPLEX2K1 y.| =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 x .|.COMPLEX2K1 y.| =HIDDENR1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have " |.COMPLEX1K10 x .|.COMPLEX2K1 y.| =HIDDENR1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y *'COMPLEX1K9.|)"
      using complex1_th_65 sorry
    also have "... = ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
      using complex1_th_53 sorry
    finally show " |.COMPLEX1K10 x .|.COMPLEX2K1 y.| =HIDDENR1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_33:
" for x be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for x be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 x =COMPLEX1R1 0NUMBERSK6 implies x =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    assume "x .|.COMPLEX2K1 x =COMPLEX1R1 0NUMBERSK6"
    then have "(ReCOMPLEX1K3 x)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 x)^2SQUARE-1K1 =COMPLEX1R1 0NUMBERSK6"
      using complex2_th_30 sorry
    thus "x =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_34:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds y .|.COMPLEX2K1 x =COMPLEX1R1 (x .|.COMPLEX2K1 y)*'COMPLEX1K9"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds y .|.COMPLEX2K1 x =HIDDENR1 (x .|.COMPLEX2K1 y)*'COMPLEX1K9"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "y .|.COMPLEX2K1 x =HIDDENR1 ((y *XCMPLX-0K3 x *'COMPLEX1K9)*'COMPLEX1K9)*'COMPLEX1K9"
       sorry
    also have "... = ((x *'COMPLEX1K9)*'COMPLEX1K9 *XCMPLX-0K3 y *'COMPLEX1K9)*'COMPLEX1K9"
      using complex1_th_35 sorry
    also have "... = (x .|.COMPLEX2K1 y)*'COMPLEX1K9"
       sorry
    finally show "y .|.COMPLEX2K1 x =HIDDENR1 (x .|.COMPLEX2K1 y)*'COMPLEX1K9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_35:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (x +XCMPLX-0K2 y).|.COMPLEX2K1 z =COMPLEX1R1 x .|.COMPLEX2K1 z +XCMPLX-0K2 y .|.COMPLEX2K1 z"
   sorry

mtheorem complex2_th_36:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (y +XCMPLX-0K2 z) =COMPLEX1R1 x .|.COMPLEX2K1 y +XCMPLX-0K2 x .|.COMPLEX2K1 z"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (y +XCMPLX-0K2 z) =HIDDENR1 x .|.COMPLEX2K1 y +XCMPLX-0K2 x .|.COMPLEX2K1 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "x .|.COMPLEX2K1 (y +XCMPLX-0K2 z) =HIDDENR1 x *XCMPLX-0K3 (y *'COMPLEX1K9 +XCMPLX-0K2 z *'COMPLEX1K9)"
      using complex1_th_32 sorry
    also have "... = x .|.COMPLEX2K1 y +XCMPLX-0K2 x .|.COMPLEX2K1 z"
       sorry
    finally show "x .|.COMPLEX2K1 (y +XCMPLX-0K2 z) =HIDDENR1 x .|.COMPLEX2K1 y +XCMPLX-0K2 x .|.COMPLEX2K1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_37:
" for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 x).|.COMPLEX2K1 y =COMPLEX1R1 a *XCMPLX-0K3 x .|.COMPLEX2K1 y"
   sorry

mtheorem complex2_th_38:
" for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (a *XCMPLX-0K3 y) =COMPLEX1R1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (a *XCMPLX-0K3 y) =HIDDENR1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "x .|.COMPLEX2K1 (a *XCMPLX-0K3 y) =HIDDENR1 x *XCMPLX-0K3 (a *'COMPLEX1K9 *XCMPLX-0K3 y *'COMPLEX1K9)"
      using complex1_th_35 sorry
    also have "... = a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y"
       sorry
    finally show "x .|.COMPLEX2K1 (a *XCMPLX-0K3 y) =HIDDENR1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_39:
" for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 x).|.COMPLEX2K1 y =COMPLEX1R1 x .|.COMPLEX2K1 (a *'COMPLEX1K9 *XCMPLX-0K3 y)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 x).|.COMPLEX2K1 y =HIDDENR1 x .|.COMPLEX2K1 (a *'COMPLEX1K9 *XCMPLX-0K3 y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "(a *XCMPLX-0K3 x).|.COMPLEX2K1 y =HIDDENR1 x *XCMPLX-0K3 ((a *'COMPLEX1K9)*'COMPLEX1K9 *XCMPLX-0K3 y *'COMPLEX1K9)"
       sorry
    also have "... = x .|.COMPLEX2K1 (a *'COMPLEX1K9 *XCMPLX-0K3 y)"
      using complex1_th_35 sorry
    finally show "(a *XCMPLX-0K3 x).|.COMPLEX2K1 y =HIDDENR1 x .|.COMPLEX2K1 (a *'COMPLEX1K9 *XCMPLX-0K3 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_40:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 x +XCMPLX-0K2 b *XCMPLX-0K3 y).|.COMPLEX2K1 z =COMPLEX1R1 a *XCMPLX-0K3 x .|.COMPLEX2K1 z +XCMPLX-0K2 b *XCMPLX-0K3 y .|.COMPLEX2K1 z"
   sorry

mtheorem complex2_th_41:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (a *XCMPLX-0K3 y +XCMPLX-0K2 b *XCMPLX-0K3 z) =COMPLEX1R1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y +XCMPLX-0K2 b *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 z"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (a *XCMPLX-0K3 y +XCMPLX-0K2 b *XCMPLX-0K3 z) =HIDDENR1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y +XCMPLX-0K2 b *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "x .|.COMPLEX2K1 (a *XCMPLX-0K3 y +XCMPLX-0K2 b *XCMPLX-0K3 z) =HIDDENR1 x .|.COMPLEX2K1 (a *XCMPLX-0K3 y) +XCMPLX-0K2 x .|.COMPLEX2K1 (b *XCMPLX-0K3 z)"
      using complex2_th_36 sorry
    also have "... = a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y +XCMPLX-0K2 x .|.COMPLEX2K1 (b *XCMPLX-0K3 z)"
      using complex2_th_38 sorry
    also have "... = a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y +XCMPLX-0K2 b *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 z"
      using complex2_th_38 sorry
    finally show "x .|.COMPLEX2K1 (a *XCMPLX-0K3 y +XCMPLX-0K2 b *XCMPLX-0K3 z) =HIDDENR1 a *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y +XCMPLX-0K2 b *'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_42:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 y =COMPLEX1R1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 y =HIDDENR1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "(-XCMPLX-0K4 x).|.COMPLEX2K1 y =HIDDENR1 (-XCMPLX-0K4 (1rCOMPLEX1K7)*'COMPLEX1K9)*XCMPLX-0K3 x .|.COMPLEX2K1 y"
      using complex1_th_30 complex1_def_4 sorry
    also have "... = (-XCMPLX-0K4 1rCOMPLEX1K7)*'COMPLEX1K9 *XCMPLX-0K3 x .|.COMPLEX2K1 y"
      using complex1_th_33 sorry
    also have "... = x .|.COMPLEX2K1 ((-XCMPLX-0K4 1rCOMPLEX1K7)*XCMPLX-0K3 y)"
      using complex2_th_38 sorry
    also have "... = x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
      using complex1_def_4 sorry
    finally show "(-XCMPLX-0K4 x).|.COMPLEX2K1 y =HIDDENR1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_43:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 y =COMPLEX1R1 -XCMPLX-0K4 x .|.COMPLEX2K1 y"
   sorry

mtheorem complex2_th_44:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 x .|.COMPLEX2K1 y =COMPLEX1R1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 x .|.COMPLEX2K1 y =HIDDENR1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "-XCMPLX-0K4 x .|.COMPLEX2K1 y =HIDDENR1 (-XCMPLX-0K4 x).|.COMPLEX2K1 y"
       sorry
    also have "... = x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
      using complex2_th_42 sorry
    finally show "-XCMPLX-0K4 x .|.COMPLEX2K1 y =HIDDENR1 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_45:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 (-XCMPLX-0K4 y) =COMPLEX1R1 x .|.COMPLEX2K1 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (-XCMPLX-0K4 x).|.COMPLEX2K1 (-XCMPLX-0K4 y) =COMPLEX1R1 x .|.COMPLEX2K1 y"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "(-XCMPLX-0K4 x).|.COMPLEX2K1 (-XCMPLX-0K4 y) =HIDDENR1 -XCMPLX-0K4 x .|.COMPLEX2K1 (-XCMPLX-0K4 y)"
       sorry
    also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 x .|.COMPLEX2K1 y)"
      using complex2_th_44 sorry
    finally have "(-XCMPLX-0K4 x).|.COMPLEX2K1 (-XCMPLX-0K4 y) =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 x .|.COMPLEX2K1 y)"
       sorry
    thus "(-XCMPLX-0K4 x).|.COMPLEX2K1 (-XCMPLX-0K4 y) =COMPLEX1R1 x .|.COMPLEX2K1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_46:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (x -XCMPLX-0K6 y).|.COMPLEX2K1 z =COMPLEX1R1 x .|.COMPLEX2K1 z -XCMPLX-0K6 y .|.COMPLEX2K1 z"
   sorry

mtheorem complex2_th_47:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (y -XCMPLX-0K6 z) =COMPLEX1R1 x .|.COMPLEX2K1 y -XCMPLX-0K6 x .|.COMPLEX2K1 z"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x .|.COMPLEX2K1 (y -XCMPLX-0K6 z) =HIDDENR1 x .|.COMPLEX2K1 y -XCMPLX-0K6 x .|.COMPLEX2K1 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "x .|.COMPLEX2K1 (y -XCMPLX-0K6 z) =HIDDENR1 x *XCMPLX-0K3 (y *'COMPLEX1K9 -XCMPLX-0K6 z *'COMPLEX1K9)"
      using complex1_th_34 sorry
    also have "... = x .|.COMPLEX2K1 y -XCMPLX-0K6 x .|.COMPLEX2K1 z"
       sorry
    finally show "x .|.COMPLEX2K1 (y -XCMPLX-0K6 z) =HIDDENR1 x .|.COMPLEX2K1 y -XCMPLX-0K6 x .|.COMPLEX2K1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_48:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (x +XCMPLX-0K2 y).|.COMPLEX2K1 (x +XCMPLX-0K2 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (x +XCMPLX-0K2 y).|.COMPLEX2K1 (x +XCMPLX-0K2 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "(x +XCMPLX-0K2 y).|.COMPLEX2K1 (x +XCMPLX-0K2 y) =HIDDENR1 x .|.COMPLEX2K1 (x +XCMPLX-0K2 y) +XCMPLX-0K2 y .|.COMPLEX2K1 (x +XCMPLX-0K2 y)"
       sorry
    also have "... = (x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 y .|.COMPLEX2K1 (x +XCMPLX-0K2 y)"
      using complex2_th_36 sorry
    also have "... = (x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 (y .|.COMPLEX2K1 x +XCMPLX-0K2 y .|.COMPLEX2K1 y)"
      using complex2_th_36 sorry
    also have "... = ((x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
       sorry
    finally have "(x +XCMPLX-0K2 y).|.COMPLEX2K1 (x +XCMPLX-0K2 y) =HIDDENR1 ((x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
       sorry
    thus "(x +XCMPLX-0K2 y).|.COMPLEX2K1 (x +XCMPLX-0K2 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x +XCMPLX-0K2 x .|.COMPLEX2K1 y)+XCMPLX-0K2 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_49:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    have "(x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) =HIDDENR1 x .|.COMPLEX2K1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 y .|.COMPLEX2K1 (x -XCMPLX-0K6 y)"
       sorry
    also have "... = (x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 y .|.COMPLEX2K1 (x -XCMPLX-0K6 y)"
      using complex2_th_47 sorry
    also have "... = (x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 (y .|.COMPLEX2K1 x -XCMPLX-0K6 y .|.COMPLEX2K1 y)"
      using complex2_th_47 sorry
    also have "... = ((x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
       sorry
    finally have "(x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) =HIDDENR1 ((x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
       sorry
    thus "(x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ((x .|.COMPLEX2K1 x -XCMPLX-0K6 x .|.COMPLEX2K1 y)-XCMPLX-0K6 y .|.COMPLEX2K1 x)+XCMPLX-0K2 y .|.COMPLEX2K1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex2_lm_2:
" for z be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =COMPLEX1R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
proof-
  have " for z be ComplexXCMPLX-0M1 holds ( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =HIDDENR1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =HIDDENR1  |.COMPLEX1K10 z *XCMPLX-0K3 z .|"
      using complex1_th_65 sorry
    also have "... = (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using complex1_th_68 sorry
    finally show "( |.COMPLEX1K10 z.|)^2SQUARE-1K1 =HIDDENR1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_50:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6 iff ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds (ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6 implies ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)) & (ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) implies ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    show "ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6 implies ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
    proof(rule impI)
      assume A1: "ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6"
      have "(( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|))^2SQUARE-1K1 =HIDDENR1 ( |.COMPLEX1K10 x .|.COMPLEX2K1 y.|)^2SQUARE-1K1"
        using complex2_th_32 sorry
      also have "... = (0NUMBERSK6)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (x .|.COMPLEX2K1 y))^2SQUARE-1K1"
        using A1 complex2_lm_2 sorry
      also have "... = (ImCOMPLEX1K4 (x .|.COMPLEX2K1 y))^2SQUARE-1K1"
         sorry
      finally have "(( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|))^2SQUARE-1K1 =HIDDENR1 (ImCOMPLEX1K4 (x .|.COMPLEX2K1 y))^2SQUARE-1K1"
         sorry
      thus "ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
        using square_1_th_40 sorry
    qed
    show "ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) implies ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|) or ImCOMPLEX1K4 (x .|.COMPLEX2K1 y) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|)"
      then have "(ImCOMPLEX1K4 (x .|.COMPLEX2K1 y))^2SQUARE-1K1 =HIDDENR1 (( |.COMPLEX1K10 x.|)*XCMPLX-0K3 ( |.COMPLEX1K10 y.|))^2SQUARE-1K1"
         sorry
      also have "... = ( |.COMPLEX1K10 x .|.COMPLEX2K1 y.|)^2SQUARE-1K1"
        using complex2_th_32 sorry
      also have "... = (ReCOMPLEX1K3 (x .|.COMPLEX2K1 y))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (x .|.COMPLEX2K1 y))^2SQUARE-1K1"
        using complex2_lm_2 sorry
      finally have "(ImCOMPLEX1K4 (x .|.COMPLEX2K1 y))^2SQUARE-1K1 =HIDDENR1 (ReCOMPLEX1K3 (x .|.COMPLEX2K1 y))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 (x .|.COMPLEX2K1 y))^2SQUARE-1K1"
         sorry
      thus "ReCOMPLEX1K3 (x .|.COMPLEX2K1 y) =COMPLEX1R1 0NUMBERSK6"
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef complex2_def_2 ("RotateCOMPLEX2K2'( _ , _ ')" [0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "r be RealXREAL-0M1"
"func RotateCOMPLEX2K2(a,r) \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  (*coherence*)
    show "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8) be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

reserve r for "RealXREAL-0M1"
mtheorem complex2_th_51:
" for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,0NUMBERSK6) =COMPLEX1R1 a"
  using comptrig_th_62 sorry

mtheorem complex2_th_52:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6 iff a =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds (RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6 implies a =COMPLEX1R1 0NUMBERSK6) & (a =COMPLEX1R1 0NUMBERSK6 implies RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    show "RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6 implies a =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6"
      then have A1: "RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
         sorry
      show "a =COMPLEX1R1 0NUMBERSK6"
      proof-
        have cases: " |.COMPLEX1K10 a.| =COMPLEX1R1 0NUMBERSK6 or cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 0NUMBERSK6 & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 0NUMBERSK6"
          using A1 complex1_th_77 sorry
        have case1: " |.COMPLEX1K10 a.| =COMPLEX1R1 0NUMBERSK6 implies a =COMPLEX1R1 0NUMBERSK6"
        proof(rule impI)
          assume " |.COMPLEX1K10 a.| =COMPLEX1R1 0NUMBERSK6"
          thus "a =COMPLEX1R1 0NUMBERSK6"
            using complex1_th_45 sorry
        qed
        have case2: "cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 0NUMBERSK6 & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 0NUMBERSK6 implies a =COMPLEX1R1 0NUMBERSK6"
        proof(rule impI)
          assume "cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 0NUMBERSK6 & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 0NUMBERSK6"
          thus "a =COMPLEX1R1 0NUMBERSK6"
            using complex2_th_10 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    assume "a =COMPLEX1R1 0NUMBERSK6"
    thus "RotateCOMPLEX2K2(a,r) =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_53:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 RotateCOMPLEX2K2(a,r) .| =COMPLEX1R1  |.COMPLEX1K10 a.|"
proof-
  have " for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 RotateCOMPLEX2K2(a,r) .| =HIDDENR1  |.COMPLEX1K10 a.|"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    have "ReCOMPLEX1K3 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)) & ImCOMPLEX1K4 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))"
      using complex1_th_12 sorry
    then have " |.COMPLEX1K10 RotateCOMPLEX2K2(a,r) .| =HIDDENR1 sqrtSQUARE-1K3 ((( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)))^2SQUARE-1K1 +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)))^2SQUARE-1K1)"
      using complex1_def_12 sorry
    also have "... = sqrtSQUARE-1K3 (( |.COMPLEX1K10 a.|)^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))^2SQUARE-1K1))"
       sorry
    also have "... = sqrtSQUARE-1K3 (( |.COMPLEX1K10 a.|)^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M)"
      using sin_cos_th_29 sorry
    also have "... =  |.COMPLEX1K10 a.|"
      using complex1_th_46 square_1_th_22 sorry
    finally show " |.COMPLEX1K10 RotateCOMPLEX2K2(a,r) .| =HIDDENR1  |.COMPLEX1K10 a.|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_54:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ( ex i be IntegerINT-1M1 st ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))"
proof-
  have " for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ( ex tVar2 be IntegerINT-1M1 st ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 tVar2 +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    have A1: " |.COMPLEX1K10 a.| =COMPLEX1R1  |.COMPLEX1K10 RotateCOMPLEX2K2(a,r) .|"
      using complex2_th_53 sorry
    assume "a <>HIDDENR2 0NUMBERSK6"
    then have A2: "RotateCOMPLEX2K2(a,r) <>HIDDENR2 0cCOMPLEX1K6"
      using complex2_th_52 sorry
    show " ex tVar2 be IntegerINT-1M1 st ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 tVar2 +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
    proof(rule bexI[of _ "-XCMPLX-0K4 [\\INT-1K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]"])
      obtain AR where
        [ty]:"AR be RealXREAL-0M1" and 
        A3: "AR =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"and A4: "0NUMBERSK6 <=XXREAL-0R1 AR & AR <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using complex2_th_1 comptrig_th_5 sorry
      have "cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 cosSIN-COSK20 AR & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) =COMPLEX1R1 sinSIN-COSK18 AR"
        using A3 complex2_th_8 complex2_th_9 sorry
      thus "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (-XCMPLX-0K4 [\\INT-1K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) /]) +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
        using A2 A1 A3 A4 comptrig_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_55:
" for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,-XCMPLX-0K4 ArgCOMPTRIGK1 a) =COMPLEX1R1  |.COMPLEX1K10 a.|"
  using sin_cos_th_31 sorry

mtheorem complex2_th_56:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds ReCOMPLEX1K3 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ReCOMPLEX1K3 a *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 (sinSIN-COSK18 r) & ImCOMPLEX1K4 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ReCOMPLEX1K3 a *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 a *XCMPLX-0K3 (cosSIN-COSK20 r)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds ReCOMPLEX1K3 (RotateCOMPLEX2K2(a,r)) =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 (sinSIN-COSK18 r) & ImCOMPLEX1K4 (RotateCOMPLEX2K2(a,r)) =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 a *XCMPLX-0K3 (cosSIN-COSK20 r)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_th_62 sorry
    then have A1: "ReCOMPLEX1K3 a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) & ImCOMPLEX1K4 a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a))"
      using complex1_th_12 sorry
    have "ReCOMPLEX1K3 (RotateCOMPLEX2K2(a,r)) =HIDDENR1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))"
      using complex1_th_12 sorry
    also have "... = ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ((cosSIN-COSK20 r)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) -XCMPLX-0K6 (sinSIN-COSK18 r)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)))"
      using sin_cos_th_75 sorry
    also have "... = ReCOMPLEX1K3 a *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 (sinSIN-COSK18 r)"
      using A1 sorry
    finally show "ReCOMPLEX1K3 (RotateCOMPLEX2K2(a,r)) =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 (sinSIN-COSK18 r)"
       sorry
    have "ImCOMPLEX1K4 (RotateCOMPLEX2K2(a,r)) =HIDDENR1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a))"
      using complex1_th_12 sorry
    also have "... = ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ((sinSIN-COSK18 r)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (cosSIN-COSK20 r)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)))"
      using sin_cos_th_75 sorry
    also have "... = ReCOMPLEX1K3 a *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 a *XCMPLX-0K3 (cosSIN-COSK20 r)"
      using A1 sorry
    finally show "ImCOMPLEX1K4 (RotateCOMPLEX2K2(a,r)) =HIDDENR1 ReCOMPLEX1K3 a *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 a *XCMPLX-0K3 (cosSIN-COSK20 r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_57:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(a +XCMPLX-0K2 b,r) =COMPLEX1R1 RotateCOMPLEX2K2(a,r) +XCMPLX-0K2 RotateCOMPLEX2K2(b,r)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(a +XCMPLX-0K2 b,r) =COMPLEX1R1 RotateCOMPLEX2K2(a,r) +XCMPLX-0K2 RotateCOMPLEX2K2(b,r)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?ab = "a +XCMPLX-0K2 b"
    let ?rab = "RotateCOMPLEX2K2(?ab,r)"
    let ?ra = "RotateCOMPLEX2K2(a,r)"
    let ?rb = "RotateCOMPLEX2K2(b,r)"
    have A1: "ReCOMPLEX1K3 ?ab =COMPLEX1R1 ReCOMPLEX1K3 a +REAL-1K3 ReCOMPLEX1K3 b & ImCOMPLEX1K4 ?ab =COMPLEX1R1 ImCOMPLEX1K4 a +REAL-1K3 ImCOMPLEX1K4 b"
      using complex1_th_8 sorry
    have A2: "ImCOMPLEX1K4 ?rab =COMPLEX1R1 ReCOMPLEX1K3 ?ab *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 ?ab *XCMPLX-0K3 (cosSIN-COSK20 r)"
      using complex2_th_56 sorry
    have "ImCOMPLEX1K4 ?ra =COMPLEX1R1 ReCOMPLEX1K3 a *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 a *XCMPLX-0K3 (cosSIN-COSK20 r) & ImCOMPLEX1K4 ?rb =COMPLEX1R1 ReCOMPLEX1K3 b *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 b *XCMPLX-0K3 (cosSIN-COSK20 r)"
      using complex2_th_56 sorry
    then have A3: "ImCOMPLEX1K4 (?ra +XCMPLX-0K2 ?rb) =HIDDENR1 (ReCOMPLEX1K3 a *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 a *XCMPLX-0K3 (cosSIN-COSK20 r))+XCMPLX-0K2 (ReCOMPLEX1K3 b *XCMPLX-0K3 (sinSIN-COSK18 r) +XCMPLX-0K2 ImCOMPLEX1K4 b *XCMPLX-0K3 (cosSIN-COSK20 r))"
      using complex1_th_8 sorry
    also have "... = ImCOMPLEX1K4 ?rab"
      using A2 A1 sorry
    finally have "ImCOMPLEX1K4 (?ra +XCMPLX-0K2 ?rb) =HIDDENR1 ImCOMPLEX1K4 ?rab"
       sorry
    have A4: "ReCOMPLEX1K3 ?rab =COMPLEX1R1 ReCOMPLEX1K3 ?ab *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 ?ab *XCMPLX-0K3 (sinSIN-COSK18 r)"
      using complex2_th_56 sorry
    have "ReCOMPLEX1K3 ?ra =COMPLEX1R1 ReCOMPLEX1K3 a *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 (sinSIN-COSK18 r) & ReCOMPLEX1K3 ?rb =COMPLEX1R1 ReCOMPLEX1K3 b *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 b *XCMPLX-0K3 (sinSIN-COSK18 r)"
      using complex2_th_56 sorry
    then have "ReCOMPLEX1K3 (?ra +XCMPLX-0K2 ?rb) =HIDDENR1 (ReCOMPLEX1K3 a *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 a *XCMPLX-0K3 (sinSIN-COSK18 r))+XCMPLX-0K2 (ReCOMPLEX1K3 b *XCMPLX-0K3 (cosSIN-COSK20 r) -XCMPLX-0K6 ImCOMPLEX1K4 b *XCMPLX-0K3 (sinSIN-COSK18 r))"
      using complex1_th_8 sorry
    also have "... = ReCOMPLEX1K3 ?rab"
      using A4 A1 sorry
    finally have "ReCOMPLEX1K3 (?ra +XCMPLX-0K2 ?rb) =HIDDENR1 ReCOMPLEX1K3 ?rab"
       sorry
    thus "RotateCOMPLEX2K2(a +XCMPLX-0K2 b,r) =COMPLEX1R1 RotateCOMPLEX2K2(a,r) +XCMPLX-0K2 RotateCOMPLEX2K2(b,r)"
      using A3 complex1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_58:
" for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =COMPLEX1R1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =COMPLEX1R1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    show "RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =COMPLEX1R1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
    proof-
      have cases: "a <>HIDDENR2 0cCOMPLEX1K6 or a =COMPLEX1R1 0cCOMPLEX1K6"
         sorry
      have case1: "a <>HIDDENR2 0cCOMPLEX1K6 implies RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =COMPLEX1R1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
      proof(rule impI)
        assume A1: "a <>HIDDENR2 0cCOMPLEX1K6"
        have A2: "cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
        proof-
          show "cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
          proof-
            have cases: "ArgCOMPTRIGK1 a <XXREAL-0R3 PISIN-COSK29 or ArgCOMPTRIGK1 a >=XXREAL-0R2 PISIN-COSK29"
               sorry
            have case1: "ArgCOMPTRIGK1 a <XXREAL-0R3 PISIN-COSK29 implies cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 a <XXREAL-0R3 PISIN-COSK29"
              then have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 PISIN-COSK29 +XCMPLX-0K2 ArgCOMPTRIGK1 a"
                using A1 complex2_th_13 sorry
              then have "r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 PISIN-COSK29 +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
                 sorry
              thus "cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
                using sin_cos_th_79 sorry
            qed
            have case2: "ArgCOMPTRIGK1 a >=XXREAL-0R2 PISIN-COSK29 implies cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 a >=XXREAL-0R2 PISIN-COSK29"
              then have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 ArgCOMPTRIGK1 a -XCMPLX-0K6 PISIN-COSK29"
                using A1 complex2_th_13 sorry
              then have "r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 (ArgCOMPTRIGK1 a +XCMPLX-0K2 r)-XCMPLX-0K6 PISIN-COSK29"
                 sorry
              thus "cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 cosSIN-COSK20 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a) & sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)) =COMPLEX1R1 -XCMPLX-0K4 sinSIN-COSK18 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
                using complex2_th_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have " |.COMPLEX1K10 a.| =COMPLEX1R1  |.COMPLEX1K10 -XCMPLX-0K4 a .|"
          using complex1_th_52 sorry
        thus "RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =COMPLEX1R1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
          using A2 sorry
      qed
      have case2: "a =COMPLEX1R1 0cCOMPLEX1K6 implies RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =HIDDENR1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
      proof(rule impI)
        assume A3: "a =COMPLEX1R1 0cCOMPLEX1K6"
        then have "RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =HIDDENR1 -XCMPLX-0K4 0NUMBERSK6"
          using complex2_th_52 sorry
        also have "... = -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
          using A3 complex2_th_52 sorry
        finally show "RotateCOMPLEX2K2(-XCMPLX-0K4 a,r) =HIDDENR1 -XCMPLX-0K4 RotateCOMPLEX2K2(a,r)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_59:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(a -XCMPLX-0K6 b,r) =COMPLEX1R1 RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds RotateCOMPLEX2K2(a -XCMPLX-0K6 b,r) =HIDDENR1 RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "RotateCOMPLEX2K2(a -XCMPLX-0K6 b,r) =HIDDENR1 RotateCOMPLEX2K2(a,r) +XCMPLX-0K2 RotateCOMPLEX2K2(-XCMPLX-0K4 b,r)"
      using complex2_th_57 sorry
    also have "... = RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)"
      using complex2_th_58 sorry
    finally show "RotateCOMPLEX2K2(a -XCMPLX-0K6 b,r) =HIDDENR1 RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_60:
" for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,PISIN-COSK29) =COMPLEX1R1 -XCMPLX-0K4 a"
proof-
  have " for a be ComplexXCMPLX-0M1 holds RotateCOMPLEX2K2(a,PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 a"
  proof(rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    have A1: "a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_th_62 sorry
    have A2: "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a)) =HIDDENR1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a))"
       sorry
    also have "... = -REAL-1K1 ImCOMPLEX1K4 a"
      using A1 complex1_th_12 sorry
    finally have "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a)) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 a"
       sorry
    have A3: "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 a)) =HIDDENR1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a))"
       sorry
    also have "... = -REAL-1K1 ReCOMPLEX1K3 a"
      using A1 complex1_th_12 sorry
    finally have "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 a)) =HIDDENR1 -REAL-1K1 ReCOMPLEX1K3 a"
       sorry
    have "RotateCOMPLEX2K2(a,PISIN-COSK29) =HIDDENR1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (PISIN-COSK29 +XCMPLX-0K2 ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_79 sorry
    also have "... = ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using sin_cos_th_79 sorry
    also have "... = -XCMPLX-0K4 a"
      using A3 A2 complex1_th_83 sorry
    finally show "RotateCOMPLEX2K2(a,PISIN-COSK29) =HIDDENR1 -XCMPLX-0K4 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef complex2_def_3 ("angleCOMPLEX2K3'( _ , _ ')" [0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1"
"func angleCOMPLEX2K3(a,b) \<rightarrow> RealXREAL-0M1 equals
  ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) if ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6 otherwise \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 a"
proof-
  (*coherence*)
    show "(ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6 implies ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) be RealXREAL-0M1) & ( not (ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or b <>HIDDENR2 0NUMBERSK6) implies \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 a be RealXREAL-0M1)"
       sorry
  (*consistency*)
    show " for it be RealXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem complex2_th_61:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds r >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K3(r,a) =COMPLEX1R1 ArgCOMPTRIGK1 a"
proof-
  have " for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds r >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K3(r,a) =HIDDENR1 ArgCOMPTRIGK1 a"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    assume "r >=XXREAL-0R2 0NUMBERSK6"
    then have "ArgCOMPTRIGK1 r =COMPLEX1R1 0NUMBERSK6"
      using comptrig_th_35 sorry
    then have "angleCOMPLEX2K3(r,a) =HIDDENR1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,-XCMPLX-0K4 0NUMBERSK6))"
      using complex2_def_3 sorry
    also have "... = ArgCOMPTRIGK1 a"
      using comptrig_th_62 sorry
    finally show "angleCOMPLEX2K3(r,a) =HIDDENR1 ArgCOMPTRIGK1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_62:
" for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b & a <>HIDDENR2 0NUMBERSK6) & b <>HIDDENR2 0NUMBERSK6 implies ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r))"
proof-
  have " for r be RealXREAL-0M1 holds  for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b & (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) implies ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume A1: "ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b"
      and A2: "a <>HIDDENR2 0NUMBERSK6"
      and A3: "b <>HIDDENR2 0NUMBERSK6"
    obtain i where
      [ty]:"i be IntegerINT-1M1" and 
      A4: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
      using A2 complex2_th_54 sorry
    obtain j where
      [ty]:"j be IntegerINT-1M1" and 
      A5: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 j +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 b)"
      using A3 complex2_th_54 sorry
    have A6: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) & 0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r))"
      using comptrig_th_34 sorry
    have A7: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    have "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (j -XCMPLX-0K6 i) +XCMPLX-0K2 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r))"
      using A1 A4 A5 sorry
    thus "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r))"
      using A6 A7 complex2_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_63:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r >XXREAL-0R4 0NUMBERSK6"
    then have A2: "ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 a"
      using complex2_th_27 sorry
    show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
    proof-
      have cases: "b <>HIDDENR2 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
      proof(rule impI)
        assume A3: "b <>HIDDENR2 0NUMBERSK6"
        then have "angleCOMPLEX2K3(a,b) =HIDDENR1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
          using complex2_def_3 sorry
        also have "... = ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b *XCMPLX-0K3 r,-XCMPLX-0K4 ArgCOMPTRIGK1 (a *XCMPLX-0K3 r)))"
          using A1 A2 A3 complex2_th_27 complex2_th_62 sorry
        also have "... = angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
          using A1 A3 complex2_def_3 sorry
        finally show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
           sorry
      qed
      have case2: "b =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
      proof(rule impI)
        assume A4: "b =COMPLEX1R1 0NUMBERSK6"
        show "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
        proof-
          have "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
          proof-
            show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
            proof-
              have cases: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 a <>HIDDENR2 0NUMBERSK6"
                 sorry
              have case1: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
              proof(rule impI)
                assume A5: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6"
                then have "angleCOMPLEX2K3(a,b) =HIDDENR1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
                  using complex2_def_3 sorry
                also have "... = ArgCOMPTRIGK1 0cCOMPLEX1K6"
                  using A4 complex2_th_52 sorry
                also have "... = ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b *XCMPLX-0K3 r,-XCMPLX-0K4 ArgCOMPTRIGK1 (a *XCMPLX-0K3 r)))"
                  using A4 complex2_th_52 sorry
                also have "... = angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
                  using A2 A5 complex2_def_3 sorry
                finally show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
                   sorry
              qed
              have case2: "ArgCOMPTRIGK1 a <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
              proof(rule impI)
                assume A6: "ArgCOMPTRIGK1 a <>HIDDENR2 0NUMBERSK6"
                then have "angleCOMPLEX2K3(a,b) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 a"
                  using A4 complex2_def_3 sorry
                also have "... = angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
                  using A2 A4 A6 complex2_def_3 sorry
                finally show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_64:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b implies ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 b)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b implies ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume "(a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & ArgCOMPTRIGK1 a =COMPLEX1R1 ArgCOMPTRIGK1 b"
    then have "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,PISIN-COSK29)) =COMPLEX1R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,PISIN-COSK29))"
      using complex2_th_62 sorry
    then have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,PISIN-COSK29))"
      using complex2_th_60 sorry
    thus "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 b)"
      using complex2_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_65:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r))"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "b <>HIDDENR2 0NUMBERSK6"
    obtain i where
      [ty]:"i be IntegerINT-1M1" and 
      A3: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b)"
      using A2 complex2_th_54 sorry
    obtain l where
      [ty]:"l be IntegerINT-1M1" and 
      A4: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 l +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 b)"
      using A2 complex2_th_54 sorry
    obtain k where
      [ty]:"k be IntegerINT-1M1" and 
      A5: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 k +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 a)"
      using A1 complex2_th_54 sorry
    have A6: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(RotateCOMPLEX2K2(b,r),-XCMPLX-0K4 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)))) & ArgCOMPTRIGK1 (RotateCOMPLEX2K2(RotateCOMPLEX2K2(b,r),-XCMPLX-0K4 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)))) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    have A7: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) & ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    have A8: "RotateCOMPLEX2K2(b,r) <>HIDDENR2 0NUMBERSK6"
      using A2 complex2_th_52 sorry
    then obtain j where
      [ty]:"j be IntegerINT-1M1" and 
      A9: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(RotateCOMPLEX2K2(b,r),-XCMPLX-0K4 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)))) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 j +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)))+XCMPLX-0K2 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,r)))"
      using complex2_th_54 sorry
    have A10: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(RotateCOMPLEX2K2(b,r),-XCMPLX-0K4 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r)))) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (((j -XCMPLX-0K6 k)+XCMPLX-0K2 l)-XCMPLX-0K6 i) +XCMPLX-0K2 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
      using A3 A9 A5 A4 sorry
    have "angleCOMPLEX2K3(a,b) =HIDDENR1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
      using A2 complex2_def_3 sorry
    also have "... = ArgCOMPTRIGK1 (RotateCOMPLEX2K2(RotateCOMPLEX2K2(b,r),-XCMPLX-0K4 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r))))"
      using A10 A7 A6 complex2_th_2 sorry
    also have "... = angleCOMPLEX2K3(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r))"
      using A8 complex2_def_3 sorry
    finally show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_66:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds (r <XXREAL-0R3 0NUMBERSK6 & a <>HIDDENR2 0NUMBERSK6) & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 0NUMBERSK6 & (a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) implies angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r <XXREAL-0R3 0NUMBERSK6"
      and A2: "a <>HIDDENR2 0NUMBERSK6"
      and A3: "b <>HIDDENR2 0NUMBERSK6"
    obtain i where
      [ty]:"i be IntegerINT-1M1" and 
      A4: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(-XCMPLX-0K4 b,-XCMPLX-0K4 ArgCOMPTRIGK1 (-XCMPLX-0K4 a))) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 (-XCMPLX-0K4 a))+XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 b))"
      using A3 complex2_th_54 sorry
    let ?br = "b *XCMPLX-0K3 r"
    let ?ar = "a *XCMPLX-0K3 r"
    have "ArgCOMPTRIGK1 (b *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 b) & ArgCOMPTRIGK1 (a *XCMPLX-0K3 r) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)"
      using A1 complex2_th_28 sorry
    then obtain j where
      [ty]:"j be IntegerINT-1M1" and 
      A5: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(?br,-XCMPLX-0K4 ArgCOMPTRIGK1 ?ar)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 j +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 (-XCMPLX-0K4 a))+XCMPLX-0K2 ArgCOMPTRIGK1 (-XCMPLX-0K4 b))"
      using A1 A3 complex2_th_54 sorry
    have A6: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(?br,-XCMPLX-0K4 ArgCOMPTRIGK1 ?ar)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (j -XCMPLX-0K6 i) +XCMPLX-0K2 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(-XCMPLX-0K4 b,-XCMPLX-0K4 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)))"
      using A4 A5 sorry
    have A7: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(?br,-XCMPLX-0K4 ArgCOMPTRIGK1 ?ar)) & ArgCOMPTRIGK1 (RotateCOMPLEX2K2(?br,-XCMPLX-0K4 ArgCOMPTRIGK1 ?ar)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    have A8: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(-XCMPLX-0K4 b,-XCMPLX-0K4 ArgCOMPTRIGK1 (-XCMPLX-0K4 a))) & ArgCOMPTRIGK1 (RotateCOMPLEX2K2(-XCMPLX-0K4 b,-XCMPLX-0K4 ArgCOMPTRIGK1 (-XCMPLX-0K4 a))) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    have "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(RotateCOMPLEX2K2(a,PISIN-COSK29),RotateCOMPLEX2K2(b,PISIN-COSK29))"
      using A2 A3 complex2_th_65 sorry
    also have "... = angleCOMPLEX2K3(-XCMPLX-0K4 a,RotateCOMPLEX2K2(b,PISIN-COSK29))"
      using complex2_th_60 sorry
    also have "... = angleCOMPLEX2K3(-XCMPLX-0K4 a,-XCMPLX-0K4 b)"
      using complex2_th_60 sorry
    also have "... = ArgCOMPTRIGK1 (RotateCOMPLEX2K2(-XCMPLX-0K4 b,-XCMPLX-0K4 ArgCOMPTRIGK1 (-XCMPLX-0K4 a)))"
      using A3 complex2_def_3 sorry
    also have "... = ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b *XCMPLX-0K3 r,-XCMPLX-0K4 ArgCOMPTRIGK1 (a *XCMPLX-0K3 r)))"
      using A6 A7 A8 complex2_th_2 sorry
    also have "... = angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
      using A1 A3 complex2_def_3 sorry
    finally show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(a *XCMPLX-0K3 r,b *XCMPLX-0K3 r)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_67:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(-XCMPLX-0K4 a,-XCMPLX-0K4 b)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(-XCMPLX-0K4 a,-XCMPLX-0K4 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
    then have "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(RotateCOMPLEX2K2(a,PISIN-COSK29),RotateCOMPLEX2K2(b,PISIN-COSK29))"
      using complex2_th_65 sorry
    also have "... = angleCOMPLEX2K3(-XCMPLX-0K4 a,RotateCOMPLEX2K2(b,PISIN-COSK29))"
      using complex2_th_60 sorry
    also have "... = angleCOMPLEX2K3(-XCMPLX-0K4 a,-XCMPLX-0K4 b)"
      using complex2_th_60 sorry
    finally show "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(-XCMPLX-0K4 a,-XCMPLX-0K4 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_68:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 & angleCOMPLEX2K3(a,b) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K3(a,-XCMPLX-0K4 b) =COMPLEX1R1 PISIN-COSK29"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds b <>HIDDENR2 0NUMBERSK6 & angleCOMPLEX2K3(a,b) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K3(a,-XCMPLX-0K4 b) =COMPLEX1R1 PISIN-COSK29"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume A1: "b <>HIDDENR2 0NUMBERSK6"
      and A2: "angleCOMPLEX2K3(a,b) =COMPLEX1R1 0NUMBERSK6"
    have A3: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 complex2_def_3 sorry
    have A4: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(-XCMPLX-0K4 b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) =COMPLEX1R1 ArgCOMPTRIGK1 (-XCMPLX-0K4 RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
      using complex2_th_58 sorry
    have "RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a) <>HIDDENR2 0NUMBERSK6"
      using A1 complex2_th_52 sorry
    then have "ArgCOMPTRIGK1 (-XCMPLX-0K4 RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) =HIDDENR1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) +XCMPLX-0K2 PISIN-COSK29"
      using A3 complex2_th_13 comptrig_th_5 sorry
    also have "... = PISIN-COSK29"
      using A3 sorry
    finally have "ArgCOMPTRIGK1 (-XCMPLX-0K4 RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) =HIDDENR1 PISIN-COSK29"
       sorry
    thus "angleCOMPLEX2K3(a,-XCMPLX-0K4 b) =COMPLEX1R1 PISIN-COSK29"
      using A1 A4 complex2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_69:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)) & sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies cosSIN-COSK20 (angleCOMPLEX2K3(a,b)) =HIDDENR1 ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)) & sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =HIDDENR1 -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "b <>HIDDENR2 0NUMBERSK6"
    have A3: " |.COMPLEX1K10 a.| <>HIDDENR2 0NUMBERSK6 &  |.COMPLEX1K10 b.| <>HIDDENR2 0NUMBERSK6"
      using A1 A2 complex1_th_45 sorry
    let ?ra = "RotateCOMPLEX2K2(a,-XCMPLX-0K4 ArgCOMPTRIGK1 a)"
    let ?rb = "RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)"
    let ?r = "-XCMPLX-0K4 ArgCOMPTRIGK1 a"
    let ?mabi = "(( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5"
    have A4: " |.COMPLEX1K10 a.| >=XXREAL-0R2 0NUMBERSK6 &  |.COMPLEX1K10 b.| >=XXREAL-0R2 0NUMBERSK6"
      using complex1_th_46 sorry
    have "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K3(?ra,?rb)"
      using A1 A2 complex2_th_65 sorry
    then have A5: "angleCOMPLEX2K3(a,b) =HIDDENR1 angleCOMPLEX2K3(( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ?mabi,?rb *XCMPLX-0K3 ?mabi)"
      using A3 A4 complex2_th_63 sin_cos_th_31 sorry
    also have "... = ArgCOMPTRIGK1 (?rb *XCMPLX-0K3 ?mabi)"
      using A4 complex2_th_61 sorry
    finally have "angleCOMPLEX2K3(a,b) =HIDDENR1 ArgCOMPTRIGK1 (?rb *XCMPLX-0K3 ?mabi)"
       sorry
    have A6: "a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_th_62 sorry
    then have "ReCOMPLEX1K3 a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 a))"
      using complex1_th_12 sorry
    then have A7: "cosSIN-COSK20 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
      using A1 complex1_th_45 xcmplx_1_th_89 sorry
    have "ImCOMPLEX1K4 a =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 a))"
      using A6 complex1_th_12 sorry
    then have A8: "sinSIN-COSK18 (ArgCOMPTRIGK1 a) =COMPLEX1R1 ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
      using A1 complex1_th_45 xcmplx_1_th_89 sorry
    have A9: "a .|.COMPLEX2K1 b =COMPLEX1R1 (ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 b +REAL-1K3 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 b)+XCMPLX-0K2 ((-REAL-1K1 ReCOMPLEX1K3 a *REAL-1K4 ImCOMPLEX1K4 b)+REAL-1K3 ImCOMPLEX1K4 a *REAL-1K4 ReCOMPLEX1K3 b)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex2_th_29 sorry
    then have A10: "ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ReCOMPLEX1K3 a *REAL-1K4 ReCOMPLEX1K3 b +REAL-1K3 ImCOMPLEX1K4 a *REAL-1K4 ImCOMPLEX1K4 b"
      using complex1_th_12 sorry
    have "ReCOMPLEX1K3 ?rb =COMPLEX1R1 ReCOMPLEX1K3 b *XCMPLX-0K3 (cosSIN-COSK20 ?r) -XCMPLX-0K6 ImCOMPLEX1K4 b *XCMPLX-0K3 (sinSIN-COSK18 ?r)"
      using complex2_th_56 sorry
    then have A11: "ReCOMPLEX1K3 ?rb =HIDDENR1 ReCOMPLEX1K3 b *XCMPLX-0K3 (cosSIN-COSK20 ?r) -XCMPLX-0K6 ImCOMPLEX1K4 b *XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a))"
      using sin_cos_th_31 sorry
    also have "... = ReCOMPLEX1K3 b *XCMPLX-0K3 (ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)) +XCMPLX-0K2 ImCOMPLEX1K4 b *XCMPLX-0K3 (ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|))"
      using A7 A8 sin_cos_th_31 sorry
    also have "... = ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
      using A10 sorry
    finally have "ReCOMPLEX1K3 ?rb =HIDDENR1 ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
       sorry
    have A12: "(ImCOMPLEX1K4 ?rb)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have "ImCOMPLEX1K4 ?rb =COMPLEX1R1 ReCOMPLEX1K3 b *XCMPLX-0K3 (sinSIN-COSK18 ?r) +XCMPLX-0K2 ImCOMPLEX1K4 b *XCMPLX-0K3 (cosSIN-COSK20 ?r)"
      using complex2_th_56 sorry
    then have A13: "ImCOMPLEX1K4 ?rb =HIDDENR1 ReCOMPLEX1K3 b *XCMPLX-0K3 (-XCMPLX-0K4 sinSIN-COSK18 (ArgCOMPTRIGK1 a)) +XCMPLX-0K2 ImCOMPLEX1K4 b *XCMPLX-0K3 (cosSIN-COSK20 ?r)"
      using sin_cos_th_31 sorry
    also have "... = (-REAL-1K1 ReCOMPLEX1K3 b)*XCMPLX-0K3 (ImCOMPLEX1K4 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)) +XCMPLX-0K2 ImCOMPLEX1K4 b *XCMPLX-0K3 (ReCOMPLEX1K3 a /XCMPLX-0K7 ( |.COMPLEX1K10 a.|))"
      using A7 A8 sin_cos_th_31 sorry
    also have "... = -XCMPLX-0K4 (-REAL-1K1 ((-REAL-1K1 ReCOMPLEX1K3 b)*REAL-1K4 ImCOMPLEX1K4 a +REAL-1K3 ImCOMPLEX1K4 b *REAL-1K4 ReCOMPLEX1K3 a))/XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
       sorry
    also have "... = -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
      using A9 complex1_th_12 sorry
    finally have "ImCOMPLEX1K4 ?rb =HIDDENR1 -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 ( |.COMPLEX1K10 a.|)"
       sorry
    let ?IT = "?rb *XCMPLX-0K3 ?mabi"
    let ?mab = "( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
    have A14: "?mabi ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & (ReCOMPLEX1K3 ?rb)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have "?mabi =COMPLEX1R1 ?mabi +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have A15: "ReCOMPLEX1K3 ?mabi =COMPLEX1R1 ?mabi & ImCOMPLEX1K4 ?mabi =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_12 sorry
    then have A16: "ReCOMPLEX1K3 ?IT =HIDDENR1 ReCOMPLEX1K3 ?rb *XCMPLX-0K3 ?mabi -XCMPLX-0K6 ImCOMPLEX1K4 ?rb *XCMPLX-0K3 (0NUMBERSK6)"
      using complex1_th_9 sorry
    also have "... = ReCOMPLEX1K3 ?rb *XCMPLX-0K3 ?mabi"
       sorry
    finally have "ReCOMPLEX1K3 ?IT =HIDDENR1 ReCOMPLEX1K3 ?rb *XCMPLX-0K3 ?mabi"
       sorry
    have A17: "ImCOMPLEX1K4 ?IT =HIDDENR1 ReCOMPLEX1K3 ?rb *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 ImCOMPLEX1K4 ?rb *XCMPLX-0K3 ?mabi"
      using A15 complex1_th_9 sorry
    also have "... = ImCOMPLEX1K4 ?rb *XCMPLX-0K3 ?mabi"
       sorry
    finally have "ImCOMPLEX1K4 ?IT =HIDDENR1 ImCOMPLEX1K4 ?rb *XCMPLX-0K3 ?mabi"
       sorry
    then have A18: " |.COMPLEX1K10 ?IT.| =HIDDENR1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 ?rb *XCMPLX-0K3 ?mabi)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 ?rb *XCMPLX-0K3 ?mabi)^2SQUARE-1K1)"
      using A16 complex1_def_12 sorry
    also have "... = sqrtSQUARE-1K3 (?mabi ^2SQUARE-1K1 *XCMPLX-0K3 ((ReCOMPLEX1K3 ?rb)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 ?rb)^2SQUARE-1K1))"
       sorry
    also have "... = sqrtSQUARE-1K3 ?mabi ^2SQUARE-1K1 *XCMPLX-0K3 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 ?rb)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 ?rb)^2SQUARE-1K1)"
      using A14 A12 square_1_th_29 sorry
    also have "... = ?mabi *XCMPLX-0K3 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 ?rb)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 ?rb)^2SQUARE-1K1)"
      using A4 square_1_th_22 sorry
    also have "... = ?mabi *XCMPLX-0K3 ( |.COMPLEX1K10 ?rb.|)"
      using complex1_def_12 sorry
    also have "... = ?mabi *XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
      using complex2_th_53 sorry
    finally have " |.COMPLEX1K10 ?IT.| =HIDDENR1 ?mabi *XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
       sorry
    have A19: "?IT =COMPLEX1R1 ( |.COMPLEX1K10 ?IT.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 ?IT)) +XCMPLX-0K2 (( |.COMPLEX1K10 ?IT.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 ?IT)))*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comptrig_th_62 sorry
    then have "( |.COMPLEX1K10 ?IT.|)*XCMPLX-0K3 (cosSIN-COSK20 (ArgCOMPTRIGK1 ?IT)) =COMPLEX1R1 ReCOMPLEX1K3 ?rb *XCMPLX-0K3 ?mabi"
      using A16 complex1_th_12 sorry
    then have "cosSIN-COSK20 (angleCOMPLEX2K3(a,b)) =HIDDENR1 (ReCOMPLEX1K3 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) *XCMPLX-0K3 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5)/XCMPLX-0K7 ( |.COMPLEX1K10 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))*XCMPLX-0K3 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 .|)"
      using A3 A5 A18 xcmplx_1_th_89 sorry
    also have "... = ReCOMPLEX1K3 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) *XCMPLX-0K3 ((( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 /XCMPLX-0K7 ( |.COMPLEX1K10 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))*XCMPLX-0K3 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 .|))"
       sorry
    also have "... = (ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 (((( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5)/XCMPLX-0K7 ( |.COMPLEX1K10 b.|))"
      using A11 A18 xcmplx_1_th_78 sorry
    also have "... = (ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 b.|))"
      using A3 xcmplx_1_th_60 sorry
    also have "... = (ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
      using xcmplx_1_th_76 sorry
    also have "... = ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
       sorry
    finally show "cosSIN-COSK20 (angleCOMPLEX2K3(a,b)) =HIDDENR1 ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
       sorry
    have "( |.COMPLEX1K10 ?IT.|)*XCMPLX-0K3 (sinSIN-COSK18 (ArgCOMPTRIGK1 ?IT)) =COMPLEX1R1 ImCOMPLEX1K4 ?rb *XCMPLX-0K3 ?mabi"
      using A19 A17 complex1_th_12 sorry
    then have "sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =HIDDENR1 (ImCOMPLEX1K4 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) *XCMPLX-0K3 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5)/XCMPLX-0K7 ( |.COMPLEX1K10 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))*XCMPLX-0K3 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 .|)"
      using A3 A5 A18 xcmplx_1_th_89 sorry
    also have "... = ImCOMPLEX1K4 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) *XCMPLX-0K3 ((( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 /XCMPLX-0K7 ( |.COMPLEX1K10 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))*XCMPLX-0K3 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 .|))"
       sorry
    also have "... = (-XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 (((( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5 /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))\<inverse>XCMPLX-0K5)/XCMPLX-0K7 ( |.COMPLEX1K10 b.|))"
      using A13 A18 xcmplx_1_th_78 sorry
    also have "... = ((-REAL-1K1 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b))/XCMPLX-0K7 ( |.COMPLEX1K10 a.|))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 b.|))"
      using A3 xcmplx_1_th_60 sorry
    also have "... = ((-REAL-1K1 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b))*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
      using xcmplx_1_th_76 sorry
    also have "... = -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
       sorry
    finally show "sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =HIDDENR1 -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef complex2_def_4 ("angleCOMPLEX2K4'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1", "z be ComplexXCMPLX-0M1"
"func angleCOMPLEX2K4(x,y,z) \<rightarrow> RealXREAL-0M1 equals
  ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) if ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 otherwise \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))"
proof-
  (*coherence*)
    show "(ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 implies ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) be RealXREAL-0M1) & ( not ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 implies \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)) be RealXREAL-0M1)"
       sorry
  (*consistency*)
    show " for it be RealXREAL-0M1 holds  True "
       sorry
qed "sorry"

mtheorem complex2_th_70:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) & angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 & (0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 & (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
    proof-
      show "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 & (0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) or ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 & (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
      proof-
        have cases: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 or ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        proof(rule impI)
          assume A1: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6"
          have "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6"
            using comptrig_th_34 sorry
          then have "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) +XCMPLX-0K2 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)"
            using xreal_1_th_7 sorry
          then have A2: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <=XXREAL-0R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y)"
            using comptrig_th_34 xreal_1_th_20 sorry
          have "angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)"
            using A1 complex2_def_4 sorry
          thus "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using A1 A2 xxreal_0_th_2 sorry
        qed
        have case2: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        proof(rule impI)
          assume A3: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6"
          have "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6"
            using comptrig_th_34 sorry
          then have "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y)"
            using xreal_1_th_7 sorry
          then have "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)"
            using comptrig_th_34 xreal_1_th_20 sorry
          then have "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using xxreal_0_th_2 sorry
          then have A4: "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y)) >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_50 sorry
          have "(ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using A3 xreal_1_th_8 sorry
          thus "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using A3 A4 complex2_def_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(x,y,z) &  not angleCOMPLEX2K4(x,y,z) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_71:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 angleCOMPLEX2K4(x -XCMPLX-0K6 y,0NUMBERSK6,z -XCMPLX-0K6 y)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 angleCOMPLEX2K4(x -XCMPLX-0K6 y,0NUMBERSK6,z -XCMPLX-0K6 y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6 & angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z) or ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6 & (ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6 implies angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z))"
    proof-
      show "ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6 & angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z) or ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6 & (ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6 implies angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z))"
      proof-
        have cases: "ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6 or ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z)"
        proof(rule impI)
          assume A1: "ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6"
          then have "angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)"
            using complex2_def_4 sorry
          thus "angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z)"
            using A1 complex2_def_4 sorry
        qed
        have case2: "ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6 implies angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z)"
        proof(rule impI)
          assume A2: "ArgCOMPTRIGK1 ((z -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 ((x -XCMPLX-0K6 y)-XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6"
          then have "angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))"
            using complex2_def_4 sorry
          thus "angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y) =COMPLEX1R1 angleCOMPLEX2K4(x,y,z)"
            using A2 complex2_def_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 angleCOMPLEX2K4(x -XCMPLX-0K6 y,0NUMBERSK6,z -XCMPLX-0K6 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_72:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for d be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(a +XCMPLX-0K2 d,b +XCMPLX-0K2 d,c +XCMPLX-0K2 d)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for d be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) =HIDDENR1 angleCOMPLEX2K4(a +XCMPLX-0K2 d,b +XCMPLX-0K2 d,c +XCMPLX-0K2 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    fix d assume [ty]: "d be ComplexXCMPLX-0M1"
    have "angleCOMPLEX2K4(a,b,c) =HIDDENR1 angleCOMPLEX2K4(a -XCMPLX-0K6 b,0cCOMPLEX1K6,c -XCMPLX-0K6 b)"
      using complex2_th_71 sorry
    also have "... = angleCOMPLEX2K4((a +XCMPLX-0K2 d)-XCMPLX-0K6 (b +XCMPLX-0K2 d),0cCOMPLEX1K6,(c +XCMPLX-0K2 d)-XCMPLX-0K6 (b +XCMPLX-0K2 d))"
       sorry
    also have "... = angleCOMPLEX2K4(a +XCMPLX-0K2 d,b +XCMPLX-0K2 d,c +XCMPLX-0K2 d)"
      using complex2_th_71 sorry
    finally show "angleCOMPLEX2K4(a,b,c) =HIDDENR1 angleCOMPLEX2K4(a +XCMPLX-0K2 d,b +XCMPLX-0K2 d,c +XCMPLX-0K2 d)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_73:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    let ?ab2 = "angleCOMPLEX2K3(a,b)"
    have A1: "0NUMBERSK6 <=XXREAL-0R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) & ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using comptrig_th_34 sorry
    show "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
    proof-
      have cases: "b <>HIDDENR2 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "b <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
      proof(rule impI)
        assume A2: "b <>HIDDENR2 0NUMBERSK6"
        then have A3: "?ab2 =COMPLEX1R1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
          using complex2_def_3 sorry
        show "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
        proof-
          show "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
          proof-
            have cases: "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6 or ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6"
              then have A4: "angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) =COMPLEX1R1 (-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b"
                using complex2_def_4 sorry
              have A5: "angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                using complex2_th_70 sorry
              have "( ex i be IntegerINT-1M1 st ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b)) & 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(a,0cCOMPLEX1K6,b)"
                using A2 complex2_th_54 complex2_th_70 sorry
              thus "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
                using A1 A3 A4 A5 complex2_th_2 sorry
            qed
            have case2: "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
            proof(rule impI)
              assume A6: "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) <XXREAL-0R3 0NUMBERSK6"
              obtain i where
                [ty]:"i be IntegerINT-1M1" and 
                A7: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b)"
                using A2 complex2_th_54 sorry
              have A8: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 i +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (i -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b))"
                 sorry
              have A9: "angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 b +XCMPLX-0K2 (-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
                using A6 complex2_def_4 sorry
              then have "0NUMBERSK6 <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b) & \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 ((-XCMPLX-0K4 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 b) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                using complex2_th_70 sorry
              thus "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
                using A1 A3 A9 A7 A8 complex2_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      have case2: "b =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
      proof(rule impI)
        assume A10: "b =COMPLEX1R1 0NUMBERSK6"
        show "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
        proof-
          show "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
          proof-
            have cases: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 or ArgCOMPTRIGK1 a <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
            proof(rule impI)
              assume A11: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6"
              then have A12: "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) =COMPLEX1R1 0NUMBERSK6"
                using A10 comptrig_th_35 sorry
              have "?ab2 =HIDDENR1 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(b,-XCMPLX-0K4 ArgCOMPTRIGK1 a))"
                using A11 complex2_def_3 sorry
              also have "... = 0NUMBERSK6"
                using A10 complex2_lm_1 complex2_th_52 sorry
              finally have "?ab2 =HIDDENR1 0NUMBERSK6"
                 sorry
              thus "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
                using A12 complex2_def_4 sorry
            qed
            have case2: "ArgCOMPTRIGK1 a <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
            proof(rule impI)
              assume A13: "ArgCOMPTRIGK1 a <>HIDDENR2 0NUMBERSK6"
              then have A14: "0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 (-XCMPLX-0K4 ArgCOMPTRIGK1 a)"
                using comptrig_th_34 sorry
              have "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) =COMPLEX1R1 -XCMPLX-0K4 ArgCOMPTRIGK1 a"
                using A10 complex2_lm_1 sorry
              then have "angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 a"
                using A14 complex2_def_4 sorry
              thus "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0NUMBERSK6,b)"
                using A10 A13 complex2_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_74:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 0NUMBERSK6 implies ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 0NUMBERSK6"
    have "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 & (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6) or ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 & (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 implies  False )"
    proof-
      show "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 & (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6) or ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 & (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 implies  False )"
      proof-
        have cases: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 or ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6 implies ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6"
        proof(rule impI)
          assume "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) >=XXREAL-0R2 0NUMBERSK6"
          then have "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 0NUMBERSK6"
            using A1 complex2_def_4 sorry
          thus "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6"
            using complex2_def_4 sorry
        qed
        have case2: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume A2: "ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) <XXREAL-0R3 0NUMBERSK6"
          then have "-XCMPLX-0K4 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)) >XXREAL-0R4 0NUMBERSK6"
             sorry
          then have A3: "angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y)"
            using complex2_def_4 sorry
          have "angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))"
            using A2 complex2_def_4 sorry
          thus " False "
            using A1 A3 complex2_th_70 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) =COMPLEX1R1 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_75:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies (ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6 iff angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies (ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) & (angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    have A1: "-XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)) =COMPLEX1R1 (-REAL-1K1 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b))/XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
       sorry
    assume A2: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
    then have A3: " |.COMPLEX1K10 a.| <>HIDDENR2 0NUMBERSK6 &  |.COMPLEX1K10 b.| <>HIDDENR2 0NUMBERSK6"
      using complex1_th_45 sorry
    have A4: "angleCOMPLEX2K3(a,b) =COMPLEX1R1 angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) & 0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(a,0cCOMPLEX1K6,b)"
      using complex2_th_70 complex2_th_73 sorry
    have A5: "angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_70 comptrig_th_5 xxreal_0_th_2 sorry
    have A6: "cosSIN-COSK20 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
      using A2 complex2_th_69 sorry
    have A7: "sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 -XCMPLX-0K4 ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) /XCMPLX-0K7 (( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
      using A2 complex2_th_69 sorry
    show "ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
    proof(rule impI)
      assume A8: "ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6"
      then have "ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
        using complex2_th_50 sorry
      then have "sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 \<one>\<^sub>M or sinSIN-COSK18 (angleCOMPLEX2K3(a,b)) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using A7 A3 A1 xcmplx_1_th_60 sorry
      thus "angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using A6 A4 A5 A8 complex2_th_11 comptrig_th_5 sin_cos_th_77 sorry
    qed
    assume "angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
    thus "ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6"
      using A6 A3 complex2_th_73 sin_cos_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_76:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies (ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) iff angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6 implies (ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) implies angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) & (angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6"
    show "ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) implies angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
    proof(rule impI)
      assume "ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
      then have "ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6"
        using complex2_th_50 sorry
      thus "angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
        using A1 complex2_th_75 sorry
    qed
    show "angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) implies ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
    proof(rule impI)
      assume "angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,0NUMBERSK6,b) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)"
      then have "ReCOMPLEX1K3 (a .|.COMPLEX2K1 b) =COMPLEX1R1 0NUMBERSK6"
        using A1 complex2_th_75 sorry
      thus "ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|) or ImCOMPLEX1K4 (a .|.COMPLEX2K1 b) =COMPLEX1R1 -XCMPLX-0K4 ( |.COMPLEX1K10 a.|)*XCMPLX-0K3 ( |.COMPLEX1K10 b.|)"
        using complex2_th_50 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex2_lm_3:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds a <>HIDDENR2 b & c <>HIDDENR2 b implies (ReCOMPLEX1K3 ((a -XCMPLX-0K6 b).|.COMPLEX2K1 (c -XCMPLX-0K6 b)) =COMPLEX1R1 0NUMBERSK6 iff angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x <>HIDDENR2 y & z <>HIDDENR2 y implies  not ((ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) =COMPLEX1R1 0NUMBERSK6 &  not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) &  not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) &  not ( not ( not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M &  not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) &  not ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume "x <>HIDDENR2 y & z <>HIDDENR2 y"
    then have A1: "x -XCMPLX-0K6 y <>HIDDENR2 0cCOMPLEX1K6 & z -XCMPLX-0K6 y <>HIDDENR2 0cCOMPLEX1K6"
       sorry
    have "angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 angleCOMPLEX2K4(x -XCMPLX-0K6 y,0cCOMPLEX1K6,z -XCMPLX-0K6 y)"
      using complex2_th_71 sorry
    thus " not ((ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) =COMPLEX1R1 0NUMBERSK6 &  not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M) &  not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) &  not ( not ( not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M &  not angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) &  not ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) =COMPLEX1R1 0NUMBERSK6)"
      using A1 complex2_th_75 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_77:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (x <>HIDDENR2 y & z <>HIDDENR2 y) & (angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) implies ( |.COMPLEX1K10 x -XCMPLX-0K6 y .|)^2SQUARE-1K1 +XCMPLX-0K2 ( |.COMPLEX1K10 z -XCMPLX-0K6 y .|)^2SQUARE-1K1 =COMPLEX1R1 ( |.COMPLEX1K10 x -XCMPLX-0K6 z .|)^2SQUARE-1K1"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (x <>HIDDENR2 y & z <>HIDDENR2 y) & (angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29)) implies ( |.COMPLEX1K10 x -XCMPLX-0K6 y .|)^2SQUARE-1K1 +XCMPLX-0K2 ( |.COMPLEX1K10 z -XCMPLX-0K6 y .|)^2SQUARE-1K1 =COMPLEX1R1 ( |.COMPLEX1K10 x -XCMPLX-0K6 z .|)^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "(x <>HIDDENR2 y & z <>HIDDENR2 y) & (angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M or angleCOMPLEX2K4(x,y,z) =COMPLEX1R1 (\<three>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29))"
    let ?x3 = "x -XCMPLX-0K6 z"
    have A2: "( |.COMPLEX1K10 x -XCMPLX-0K6 y .|)^2SQUARE-1K1 +XCMPLX-0K2 ( |.COMPLEX1K10 z -XCMPLX-0K6 y .|)^2SQUARE-1K1 =HIDDENR1 ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y)) +XCMPLX-0K2 ( |.COMPLEX1K10 z -XCMPLX-0K6 y .|)^2SQUARE-1K1"
      using complex2_th_31 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y)) +REAL-1K3 ReCOMPLEX1K3 ((z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))"
      using complex2_th_31 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))"
      using complex1_th_8 sorry
    finally have "( |.COMPLEX1K10 x -XCMPLX-0K6 y .|)^2SQUARE-1K1 +XCMPLX-0K2 ( |.COMPLEX1K10 z -XCMPLX-0K6 y .|)^2SQUARE-1K1 =HIDDENR1 ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))"
       sorry
    have "?x3 =COMPLEX1R1 (x -XCMPLX-0K6 y)-XCMPLX-0K6 (z -XCMPLX-0K6 y)"
       sorry
    then have "(x -XCMPLX-0K6 z).|.COMPLEX2K1 (x -XCMPLX-0K6 z) =COMPLEX1R1 (((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 (x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))-XCMPLX-0K6 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y))+XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)"
      using complex2_th_49 sorry
    then have "ReCOMPLEX1K3 ((x -XCMPLX-0K6 z).|.COMPLEX2K1 (x -XCMPLX-0K6 z)) =HIDDENR1 ReCOMPLEX1K3 (((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))-XCMPLX-0K6 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y)))"
       sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) -REAL-1K5 ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y))"
      using complex1_th_19 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) -REAL-1K5 (ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) +REAL-1K3 ReCOMPLEX1K3 ((z -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y)))"
      using complex1_th_8 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) -REAL-1K5 (ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) +REAL-1K3 ReCOMPLEX1K3 (((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))*'COMPLEX1K9))"
      using complex2_th_34 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) -REAL-1K5 (ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) +REAL-1K3 ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)))"
      using complex1_th_27 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) -XCMPLX-0K6 (0NUMBERSK6 +XCMPLX-0K2 ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)))"
      using A1 complex2_lm_3 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y)) -XCMPLX-0K6 0NUMBERSK6"
      using A1 complex2_lm_3 sorry
    also have "... = ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))"
       sorry
    finally have "ReCOMPLEX1K3 ((x -XCMPLX-0K6 z).|.COMPLEX2K1 (x -XCMPLX-0K6 z)) =HIDDENR1 ReCOMPLEX1K3 ((x -XCMPLX-0K6 y).|.COMPLEX2K1 (x -XCMPLX-0K6 y) +XCMPLX-0K2 (z -XCMPLX-0K6 y).|.COMPLEX2K1 (z -XCMPLX-0K6 y))"
       sorry
    thus "( |.COMPLEX1K10 x -XCMPLX-0K6 y .|)^2SQUARE-1K1 +XCMPLX-0K2 ( |.COMPLEX1K10 z -XCMPLX-0K6 y .|)^2SQUARE-1K1 =COMPLEX1R1 ( |.COMPLEX1K10 x -XCMPLX-0K6 z .|)^2SQUARE-1K1"
      using A2 complex2_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_78:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds a <>HIDDENR2 b & b <>HIDDENR2 c implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds  for r be RealXREAL-0M1 holds a <>HIDDENR2 b & b <>HIDDENR2 c implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?cb = "c -XCMPLX-0K6 b"
    let ?ab = "a -XCMPLX-0K6 b"
    let ?rc = "RotateCOMPLEX2K2(c,r)"
    let ?rb = "RotateCOMPLEX2K2(b,r)"
    let ?ra = "RotateCOMPLEX2K2(a,r)"
    let ?rcb = "RotateCOMPLEX2K2(c,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)"
    let ?rab = "RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)"
    assume A1: "a <>HIDDENR2 b"
      and A2: "b <>HIDDENR2 c"
    have A3: "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_70 sorry
    have "?cb <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then obtain cbi where
      [ty]:"cbi be IntegerINT-1M1" and 
      A4: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(?cb,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 cbi +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 ?cb)"
      using complex2_th_54 sorry
    have "?ab <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then obtain abi where
      [ty]:"abi be IntegerINT-1M1" and 
      A5: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(?ab,r)) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 abi +XCMPLX-0K2 (r +XCMPLX-0K2 ArgCOMPTRIGK1 ?ab)"
      using complex2_th_54 sorry
    have A6: "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r)) & angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_70 sorry
    have "?rab =COMPLEX1R1 RotateCOMPLEX2K2(?ab,r)"
      using complex2_th_59 sorry
    then have A7: "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab =HIDDENR1 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 cbi +XCMPLX-0K2 r)+XCMPLX-0K2 ArgCOMPTRIGK1 ?cb)-XCMPLX-0K6 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 abi +XCMPLX-0K2 r)+XCMPLX-0K2 ArgCOMPTRIGK1 ?ab)"
      using A5 A4 complex2_th_59 sorry
    also have "... = (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (cbi -XCMPLX-0K6 abi)"
       sorry
    finally have "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab =HIDDENR1 (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (cbi -XCMPLX-0K6 abi)"
       sorry
    show "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
    proof-
      have cases: "ArgCOMPTRIGK1 (c -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) >=XXREAL-0R2 0NUMBERSK6 or ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "ArgCOMPTRIGK1 (c -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
      proof(rule impI)
        assume "ArgCOMPTRIGK1 (c -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) >=XXREAL-0R2 0NUMBERSK6"
        then have A8: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 ArgCOMPTRIGK1 (c -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b)"
          using complex2_def_4 sorry
        show "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
        proof-
          show "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
          proof-
            have cases: "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab >=XXREAL-0R2 0NUMBERSK6 or ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(c,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) -XCMPLX-0K6 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab >=XXREAL-0R2 0NUMBERSK6"
              then have "angleCOMPLEX2K4(?ra,?rb,?rc) =COMPLEX1R1 ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab"
                using complex2_def_4 sorry
              thus "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
                using A3 A6 A7 A8 complex2_th_2 sorry
            qed
            have case2: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(c,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) -XCMPLX-0K6 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) <XXREAL-0R3 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab <XXREAL-0R3 0NUMBERSK6"
              then have "angleCOMPLEX2K4(?ra,?rb,?rc) =HIDDENR1 ((ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (cbi -XCMPLX-0K6 abi))+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                using A7 complex2_def_4 sorry
              also have "... = (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((cbi -XCMPLX-0K6 abi)+XCMPLX-0K2 \<one>\<^sub>M)"
                 sorry
              finally have "angleCOMPLEX2K4(?ra,?rb,?rc) =HIDDENR1 (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((cbi -XCMPLX-0K6 abi)+XCMPLX-0K2 \<one>\<^sub>M)"
                 sorry
              thus "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
                using A3 A6 A8 complex2_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      have case2: "ArgCOMPTRIGK1 (c -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) <XXREAL-0R3 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
      proof(rule impI)
        assume "ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab <XXREAL-0R3 0NUMBERSK6"
        then have A9: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab)"
          using complex2_def_4 sorry
        show "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
        proof-
          show "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
          proof-
            have cases: "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab >=XXREAL-0R2 0NUMBERSK6 or ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(c,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) -XCMPLX-0K6 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) >=XXREAL-0R2 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab >=XXREAL-0R2 0NUMBERSK6"
              then have "angleCOMPLEX2K4(?ra,?rb,?rc) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 ((cbi -XCMPLX-0K6 abi)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))"
                using A7 complex2_def_4 sorry
              thus "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
                using A3 A6 A9 complex2_th_2 sorry
            qed
            have case2: "ArgCOMPTRIGK1 (RotateCOMPLEX2K2(c,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) -XCMPLX-0K6 ArgCOMPTRIGK1 (RotateCOMPLEX2K2(a,r) -XCMPLX-0K6 RotateCOMPLEX2K2(b,r)) <XXREAL-0R3 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
            proof(rule impI)
              assume "ArgCOMPTRIGK1 ?rcb -XCMPLX-0K6 ArgCOMPTRIGK1 ?rab <XXREAL-0R3 0NUMBERSK6"
              then have "angleCOMPLEX2K4(?ra,?rb,?rc) =HIDDENR1 ((ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (cbi -XCMPLX-0K6 abi))+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                using A7 complex2_def_4 sorry
              also have "... = (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (cbi -XCMPLX-0K6 abi)"
                 sorry
              finally have "angleCOMPLEX2K4(?ra,?rb,?rc) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 ?cb -XCMPLX-0K6 ArgCOMPTRIGK1 ?ab))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))*XCMPLX-0K3 (cbi -XCMPLX-0K6 abi)"
                 sorry
              thus "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 angleCOMPLEX2K4(RotateCOMPLEX2K2(a,r),RotateCOMPLEX2K2(b,r),RotateCOMPLEX2K2(c,r))"
                using A3 A6 A9 complex2_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_79:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,a) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,a) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    have "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) =COMPLEX1R1 0NUMBERSK6"
       sorry
    thus "angleCOMPLEX2K4(a,b,a) =COMPLEX1R1 0NUMBERSK6"
      using complex2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex2_lm_4:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(x,y,z) <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "angleCOMPLEX2K4(x,y,z) <>HIDDENR2 0NUMBERSK6"
    have "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) >XXREAL-0R4 0NUMBERSK6 & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z) or ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 0NUMBERSK6 & (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 0NUMBERSK6 implies angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z))"
    proof-
      show "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) >XXREAL-0R4 0NUMBERSK6 & angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z) or ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 0NUMBERSK6 & (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 0NUMBERSK6 implies angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z))"
      proof-
        have cases: "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) >XXREAL-0R4 0NUMBERSK6 or ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 0NUMBERSK6"
           sorry
        have case1: "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) >XXREAL-0R4 0NUMBERSK6 implies angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
        proof(rule impI)
          assume A2: "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) >XXREAL-0R4 0NUMBERSK6"
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y))) >XXREAL-0R4 0NUMBERSK6"
             sorry
          then have "angleCOMPLEX2K4(x,y,z) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))"
            using complex2_def_4 sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y))"
             sorry
          finally have "angleCOMPLEX2K4(x,y,z) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y))"
             sorry
          thus "angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
            using A2 complex2_def_4 sorry
        qed
        have case2: "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 0NUMBERSK6 implies angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
        proof(rule impI)
          assume A3: "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <=XXREAL-0R1 0NUMBERSK6"
          have "ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) <>HIDDENR2 0NUMBERSK6"
            using A1 complex2_def_4 sorry
          then have A4: "angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))"
            using A3 complex2_def_4 sorry
          have "-XCMPLX-0K4 (-XCMPLX-0K4 (ArgCOMPTRIGK1 (x -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (z -XCMPLX-0K6 y))) <=XXREAL-0R1 0NUMBERSK6"
            using A3 sorry
          then have "angleCOMPLEX2K4(x,y,z) +XCMPLX-0K2 angleCOMPLEX2K4(z,y,x) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y)))+XCMPLX-0K2 (ArgCOMPTRIGK1 (z -XCMPLX-0K6 y) -XCMPLX-0K6 ArgCOMPTRIGK1 (x -XCMPLX-0K6 y))"
            using A4 complex2_def_4 sorry
          also have "... = \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
             sorry
          finally have "angleCOMPLEX2K4(x,y,z) +XCMPLX-0K2 angleCOMPLEX2K4(z,y,x) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
             sorry
          thus "angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "angleCOMPLEX2K4(z,y,x) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(x,y,z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_80:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 iff angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)) & (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    show "angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
    proof(rule impI)
      assume "angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6"
      then have "angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 angleCOMPLEX2K4(a,b,c)"
        using complex2_lm_4 sorry
      thus "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
         sorry
    qed
    assume "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6"
    thus " False "
      using complex2_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_81:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 implies angleCOMPLEX2K4(c,b,a) <>HIDDENR2 0NUMBERSK6"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 implies ( not ( not angleCOMPLEX2K4(c,b,a) <>HIDDENR2 0NUMBERSK6) implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    assume "angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6"
    then have A1: "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_80 sorry
    assume " not ( not angleCOMPLEX2K4(c,b,a) <>HIDDENR2 0NUMBERSK6)"
    thus " False "
      using A1 complex2_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_82:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29 implies angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 PISIN-COSK29"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29 implies angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 PISIN-COSK29"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    assume A1: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29"
    then have "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_80 comptrig_th_5 sorry
    thus "angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 PISIN-COSK29"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_83:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c implies (angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 or angleCOMPLEX2K4(b,c,a) <>HIDDENR2 0NUMBERSK6) or angleCOMPLEX2K4(c,a,b) <>HIDDENR2 0NUMBERSK6"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c implies ( not ( not ((angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 & angleCOMPLEX2K4(b,c,a) <>HIDDENR2 0NUMBERSK6) & angleCOMPLEX2K4(c,a,b) <>HIDDENR2 0NUMBERSK6)) implies  not  True )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 b & a <>HIDDENR2 c"
      and A2: "b <>HIDDENR2 c"
    have A3: "b -XCMPLX-0K6 a <>HIDDENR2 0NUMBERSK6 & a -XCMPLX-0K6 c <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    have "c -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A4: "ArgCOMPTRIGK1 (c -XCMPLX-0K6 b) <XXREAL-0R3 PISIN-COSK29 iff ArgCOMPTRIGK1 (-XCMPLX-0K4 (c -XCMPLX-0K6 b)) >=XXREAL-0R2 PISIN-COSK29"
      using complex2_th_16 sorry
    have A5: "-XCMPLX-0K4 (b -XCMPLX-0K6 a) =COMPLEX1R1 a -XCMPLX-0K6 b & -XCMPLX-0K4 (a -XCMPLX-0K6 c) =COMPLEX1R1 c -XCMPLX-0K6 a"
       sorry
    have A6: "-XCMPLX-0K4 (c -XCMPLX-0K6 a) =COMPLEX1R1 a -XCMPLX-0K6 c"
       sorry
    assume A7: " not ( not ((angleCOMPLEX2K4(a,b,c) <>HIDDENR2 0NUMBERSK6 & angleCOMPLEX2K4(b,c,a) <>HIDDENR2 0NUMBERSK6) & angleCOMPLEX2K4(c,a,b) <>HIDDENR2 0NUMBERSK6))"
    then have A8: "ArgCOMPTRIGK1 (a -XCMPLX-0K6 c) =COMPLEX1R1 ArgCOMPTRIGK1 (b -XCMPLX-0K6 c)"
      using complex2_th_74 sorry
    have "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) =COMPLEX1R1 ArgCOMPTRIGK1 (c -XCMPLX-0K6 a)"
      using A7 complex2_th_74 sorry
    then have "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) =COMPLEX1R1 ArgCOMPTRIGK1 (a -XCMPLX-0K6 c)"
      using A3 A5 A6 complex2_th_64 sorry
    thus " not  True "
      using A7 A8 A4 complex2_th_74 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex2_lm_5:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds ((ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6) & 0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 b) & ArgCOMPTRIGK1 b <XXREAL-0R3 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6) =COMPLEX1R1 PISIN-COSK29 & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a)) & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6 & (ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6 & (0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 b & ArgCOMPTRIGK1 b <XXREAL-0R3 PISIN-COSK29)) implies (angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6) =HIDDENR1 PISIN-COSK29 & (0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a) &  not 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume A1: "ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6"
      and A2: "ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6"
      and A3: "0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 b"
      and A4: "ArgCOMPTRIGK1 b <XXREAL-0R3 PISIN-COSK29"
    have "a =COMPLEX1R1 ReCOMPLEX1K3 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 complex1_th_13 sorry
    then have A5: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6"
      using A2 comptrig_th_35 sorry
    then have A6: "ArgCOMPTRIGK1 a -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 ArgCOMPTRIGK1 a -XCMPLX-0K6 (ArgCOMPTRIGK1 a +XCMPLX-0K2 PISIN-COSK29)"
      using A2 complex2_th_13 complex1_th_4 comptrig_th_5 sorry
    also have "... = -XCMPLX-0K4 PISIN-COSK29"
       sorry
    finally have "ArgCOMPTRIGK1 a -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 -XCMPLX-0K4 PISIN-COSK29"
       sorry
    have "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6"
      using A3 A5 sorry
    then have A7: "angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) =COMPLEX1R1 ArgCOMPTRIGK1 b -XCMPLX-0K6 ArgCOMPTRIGK1 a"
      using complex2_def_4 sorry
    have "ArgCOMPTRIGK1 b inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
      using A3 A4 xxreal_1_th_4 sorry
    then have A8: "ImCOMPLEX1K4 b >XXREAL-0R4 0NUMBERSK6"
      using complex2_th_18 sorry
    then have A9: "ArgCOMPTRIGK1 b -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 b) =HIDDENR1 ArgCOMPTRIGK1 b -XCMPLX-0K6 (ArgCOMPTRIGK1 b +XCMPLX-0K2 PISIN-COSK29)"
      using A4 complex2_th_13 complex1_th_4 sorry
    also have "... = -XCMPLX-0K4 PISIN-COSK29"
       sorry
    finally have "ArgCOMPTRIGK1 b -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 b) =HIDDENR1 -XCMPLX-0K4 PISIN-COSK29"
       sorry
    have A10: "ImCOMPLEX1K4 (a -XCMPLX-0K6 b) =HIDDENR1 ImCOMPLEX1K4 a -REAL-1K5 ImCOMPLEX1K4 b"
      using complex1_th_19 sorry
    also have "... = -REAL-1K1 ImCOMPLEX1K4 b"
      using A1 sorry
    finally have "ImCOMPLEX1K4 (a -XCMPLX-0K6 b) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 b"
       sorry
    then have A11: "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) >XXREAL-0R4 PISIN-COSK29"
      using A8 complex2_th_24 sorry
    then have "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) <=XXREAL-0R1 PISIN-COSK29"
      using A8 A10 complex2_th_17 complex1_th_4 sorry
    then have A12: "-XCMPLX-0K4 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) >=XXREAL-0R2 -XCMPLX-0K4 PISIN-COSK29"
      using xreal_1_th_24 sorry
    have A13: "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) =HIDDENR1 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 (a -XCMPLX-0K6 b))"
       sorry
    also have "... = ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 (ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 PISIN-COSK29)"
      using A8 A10 A11 complex2_th_13 complex1_th_4 sorry
    also have "... = PISIN-COSK29"
       sorry
    finally have "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) =HIDDENR1 PISIN-COSK29"
       sorry
    have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 ArgCOMPTRIGK1 a +XCMPLX-0K2 PISIN-COSK29"
      using A2 A5 complex2_th_13 complex1_th_4 comptrig_th_5 sorry
    also have "... = PISIN-COSK29"
      using A5 sorry
    finally have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 PISIN-COSK29"
       sorry
    then have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) +XCMPLX-0K2 (-XCMPLX-0K4 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a)) >=XXREAL-0R2 (0NUMBERSK6 -XCMPLX-0K6 PISIN-COSK29)+XCMPLX-0K2 PISIN-COSK29"
      using A12 xreal_1_th_7 sorry
    then have A14: "angleCOMPLEX2K4(b,a,0cCOMPLEX1K6) =COMPLEX1R1 ArgCOMPTRIGK1 (0cCOMPLEX1K6 -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a)"
      using complex2_def_4 sorry
    have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6 & (ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6 & (0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 b & ArgCOMPTRIGK1 b <XXREAL-0R3 PISIN-COSK29)) implies ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be ComplexXCMPLX-0M1"
      fix b assume [ty]: "b be ComplexXCMPLX-0M1"
      assume A15: "ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6"
        and A16: "ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6"
        and A17: "0NUMBERSK6 <XXREAL-0R3 ArgCOMPTRIGK1 b & ArgCOMPTRIGK1 b <XXREAL-0R3 PISIN-COSK29"
      have A18: "ReCOMPLEX1K3 b +REAL-1K3 (-REAL-1K1 ReCOMPLEX1K3 a) <XXREAL-0R3 ReCOMPLEX1K3 b +XCMPLX-0K2 0NUMBERSK6"
        using A16 xreal_1_th_8 sorry
      let ?ba = "b -XCMPLX-0K6 a"
      let ?B = "ArgCOMPTRIGK1 b"
      let ?BA = "ArgCOMPTRIGK1 ?ba"
      let ?mb = " |.COMPLEX1K10 b.|"
      let ?mba = " |.COMPLEX1K10 b -XCMPLX-0K6 a .|"
      have A19: "ReCOMPLEX1K3 (b -XCMPLX-0K6 a) =COMPLEX1R1 ReCOMPLEX1K3 b -REAL-1K5 ReCOMPLEX1K3 a"
        using complex1_th_19 sorry
      have "b -XCMPLX-0K6 a =COMPLEX1R1 ?mba *XCMPLX-0K3 (cosSIN-COSK20 ?BA) +XCMPLX-0K2 (?mba *XCMPLX-0K3 (sinSIN-COSK18 ?BA))*XCMPLX-0K3 (<i>COMPLEX1K8) & b -XCMPLX-0K6 a =COMPLEX1R1 ReCOMPLEX1K3 ?ba +XCMPLX-0K2 ImCOMPLEX1K4 ?ba *XCMPLX-0K3 (<i>COMPLEX1K8)"
        using comptrig_th_62 complex1_th_13 sorry
      then have A20: "ImCOMPLEX1K4 ?ba =COMPLEX1R1 ?mba *XCMPLX-0K3 (sinSIN-COSK18 ?BA)"
        using complex1_th_77 sorry
      let ?Rb = "ReCOMPLEX1K3 b"
      let ?Rba = "ReCOMPLEX1K3 ?ba"
      let ?Ib = "ImCOMPLEX1K4 b"
      let ?Iba = "ImCOMPLEX1K4 ?ba"
      have A21: "ImCOMPLEX1K4 (b -XCMPLX-0K6 a) =HIDDENR1 ImCOMPLEX1K4 b -REAL-1K5 ImCOMPLEX1K4 a"
        using complex1_th_19 sorry
      also have "... = ImCOMPLEX1K4 b"
        using A15 sorry
      finally have "ImCOMPLEX1K4 (b -XCMPLX-0K6 a) =HIDDENR1 ImCOMPLEX1K4 b"
         sorry
      then have A22: "?mb =COMPLEX1R1 sqrtSQUARE-1K3 (?Rb ^2SQUARE-1K1 +XCMPLX-0K2 ?Ib ^2SQUARE-1K1) & ?mba =COMPLEX1R1 sqrtSQUARE-1K3 (?Rba ^2SQUARE-1K1 +XCMPLX-0K2 ?Ib ^2SQUARE-1K1)"
        using complex1_def_12 sorry
      have A23: "?Rb ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & ?Ib ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
        using xreal_1_th_63 sorry
      have A24: "?Rba ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 & ?Ib ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
        using xreal_1_th_63 sorry
      have "ArgCOMPTRIGK1 b inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,PISIN-COSK29 .["
        using A17 xxreal_1_th_4 sorry
      then have A25: "ImCOMPLEX1K4 b >XXREAL-0R4 0NUMBERSK6"
        using complex2_th_18 sorry
      then have A26: "?mb >=XXREAL-0R2 0NUMBERSK6"
        using complex1_th_4 complex1_th_47 sorry
      have A27: "?mba >=XXREAL-0R2 0NUMBERSK6"
        using A25 A21 complex1_th_4 complex1_th_47 sorry
      have A28: "sinSIN-COSK18 ?BA >XXREAL-0R4 0NUMBERSK6"
        using A25 A21 comptrig_th_45 sorry
      have A29: "?mb <>HIDDENR2 0NUMBERSK6"
        using A25 complex1_th_4 complex1_th_47 sorry
      have "b =COMPLEX1R1 ?mb *XCMPLX-0K3 (cosSIN-COSK20 ?B) +XCMPLX-0K2 (?mb *XCMPLX-0K3 (sinSIN-COSK18 ?B))*XCMPLX-0K3 (<i>COMPLEX1K8) & b =COMPLEX1R1 ReCOMPLEX1K3 b +XCMPLX-0K2 ImCOMPLEX1K4 b *XCMPLX-0K3 (<i>COMPLEX1K8)"
        using comptrig_th_62 complex1_th_13 sorry
      then have "ImCOMPLEX1K4 b =COMPLEX1R1 ?mb *XCMPLX-0K3 (sinSIN-COSK18 ?B)"
        using complex1_th_77 sorry
      then have A30: "?mba /XCMPLX-0K7 ?mb =COMPLEX1R1 (sinSIN-COSK18 ?B)/XCMPLX-0K7 (sinSIN-COSK18 ?BA)"
        using A21 A20 A29 A28 xcmplx_1_th_94 sorry
      show "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
      proof-
        have cases: "(0NUMBERSK6 <XXREAL-0R3 ReCOMPLEX1K3 ?ba or 0NUMBERSK6 =COMPLEX1R1 ?Rba) or 0NUMBERSK6 >XXREAL-0R4 ReCOMPLEX1K3 ?ba"
           sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 ReCOMPLEX1K3 (b -XCMPLX-0K6 a) implies ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A31: "0NUMBERSK6 <XXREAL-0R3 ReCOMPLEX1K3 ?ba"
          then have "?Rb ^2SQUARE-1K1 >XXREAL-0R4 ?Rba ^2SQUARE-1K1"
            using A19 A18 square_1_th_16 sorry
          then have "?Rb ^2SQUARE-1K1 +XCMPLX-0K2 ?Ib ^2SQUARE-1K1 >XXREAL-0R4 ?Rba ^2SQUARE-1K1 +XCMPLX-0K2 ?Ib ^2SQUARE-1K1"
            using xreal_1_th_8 sorry
          then have "?mb >XXREAL-0R4 ?mba"
            using A22 A24 square_1_th_27 sorry
          then have "?mba /XCMPLX-0K7 ?mb <XXREAL-0R3 \<one>\<^sub>M"
            using A27 xreal_1_th_189 sorry
          then have "((sinSIN-COSK18 ?B)/XCMPLX-0K7 (sinSIN-COSK18 ?BA))*XCMPLX-0K3 (sinSIN-COSK18 ?BA) <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 ?BA)"
            using A28 A30 xreal_1_th_68 sorry
          then have A32: "sinSIN-COSK18 ?B <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 ?BA)"
            using A28 xcmplx_1_th_87 sorry
          have "?B inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .[ & ?BA inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
            using A25 A21 A19 A18 A31 comptrig_th_41 sorry
          then have "?BA >XXREAL-0R4 ?B"
            using A32 complex2_th_6 sorry
          then have "?BA +XCMPLX-0K2 (-XCMPLX-0K4 ?B) >XXREAL-0R4 ?B +XCMPLX-0K2 (-XCMPLX-0K4 ?B)"
            using xreal_1_th_8 sorry
          thus "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
             sorry
        qed
        have case2: "0NUMBERSK6 =COMPLEX1R1 ReCOMPLEX1K3 (b -XCMPLX-0K6 a) implies ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A33: "0NUMBERSK6 =COMPLEX1R1 ?Rba"
          then have "?ba =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ?Iba *XCMPLX-0K3 (<i>COMPLEX1K8)"
            using complex1_th_13 sorry
          then have A34: "?BA =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
            using A25 A21 comptrig_th_37 sorry
          have "?B inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
            using A16 A25 A19 A33 comptrig_th_41 sorry
          then have "?B <XXREAL-0R3 ?BA"
            using A34 xxreal_1_th_4 sorry
          then have "?B +XCMPLX-0K2 (-XCMPLX-0K4 ?B) <XXREAL-0R3 ?BA +XCMPLX-0K2 (-XCMPLX-0K4 ?B)"
            using xreal_1_th_8 sorry
          thus "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
             sorry
        qed
        have case3: "0NUMBERSK6 >XXREAL-0R4 ReCOMPLEX1K3 (b -XCMPLX-0K6 a) implies ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A35: "0NUMBERSK6 >XXREAL-0R4 ReCOMPLEX1K3 ?ba"
          show "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
          proof-
            have " not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
            proof-
              show " not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
              proof-
                have cases: "(0NUMBERSK6 <XXREAL-0R3 ReCOMPLEX1K3 b or 0NUMBERSK6 =COMPLEX1R1 ReCOMPLEX1K3 b) or 0NUMBERSK6 >XXREAL-0R4 ReCOMPLEX1K3 b"
                   sorry
                have case1: "0NUMBERSK6 <XXREAL-0R3 ReCOMPLEX1K3 b implies  not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
                proof(rule impI)
                  assume "0NUMBERSK6 <XXREAL-0R3 ReCOMPLEX1K3 b"
                  then have "?B inHIDDENR3 ].RCOMP-1K2 0NUMBERSK6,(PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M .["
                    using A25 comptrig_th_41 sorry
                  then have A36: "?B <XXREAL-0R3 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                    using xxreal_1_th_4 sorry
                  have "?BA inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
                    using A25 A21 A35 comptrig_th_42 sorry
                  then have "?BA >XXREAL-0R4 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                    using xxreal_1_th_4 sorry
                  then have "?BA >XXREAL-0R4 ?B"
                    using A36 xxreal_0_th_2 sorry
                  then have "?B +XCMPLX-0K2 (-XCMPLX-0K4 ?B) <XXREAL-0R3 ?BA +XCMPLX-0K2 (-XCMPLX-0K4 ?B)"
                    using xreal_1_th_8 sorry
                  thus " not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
                     sorry
                qed
                have case2: "0NUMBERSK6 =COMPLEX1R1 ReCOMPLEX1K3 b implies  not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
                proof(rule impI)
                  assume "0NUMBERSK6 =COMPLEX1R1 ReCOMPLEX1K3 b"
                  then have "b =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 ?Ib *XCMPLX-0K3 (<i>COMPLEX1K8)"
                    using complex1_th_13 sorry
                  then have A37: "?B =COMPLEX1R1 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M"
                    using A25 comptrig_th_37 sorry
                  have "?BA inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
                    using A25 A21 A35 comptrig_th_42 sorry
                  then have "?B <XXREAL-0R3 ?BA"
                    using A37 xxreal_1_th_4 sorry
                  then have "?B +XCMPLX-0K2 (-XCMPLX-0K4 ?B) <XXREAL-0R3 ?BA +XCMPLX-0K2 (-XCMPLX-0K4 ?B)"
                    using xreal_1_th_8 sorry
                  thus " not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
                     sorry
                qed
                have case3: "0NUMBERSK6 >XXREAL-0R4 ReCOMPLEX1K3 b implies  not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
                proof(rule impI)
                  assume A38: "0NUMBERSK6 >XXREAL-0R4 ReCOMPLEX1K3 b"
                  then have "?Rb ^2SQUARE-1K1 <XXREAL-0R3 ?Rba ^2SQUARE-1K1"
                    using A19 A18 square_1_th_44 sorry
                  then have "?Rb ^2SQUARE-1K1 +XCMPLX-0K2 ?Ib ^2SQUARE-1K1 <XXREAL-0R3 ?Rba ^2SQUARE-1K1 +XCMPLX-0K2 ?Ib ^2SQUARE-1K1"
                    using xreal_1_th_8 sorry
                  then have "?mb <XXREAL-0R3 ?mba"
                    using A22 A23 square_1_th_27 sorry
                  then have "?mba /XCMPLX-0K7 ?mb >XXREAL-0R4 \<one>\<^sub>M"
                    using A26 A29 xreal_1_th_187 sorry
                  then have "((sinSIN-COSK18 ?B)/XCMPLX-0K7 (sinSIN-COSK18 ?BA))*XCMPLX-0K3 (sinSIN-COSK18 ?BA) >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 ?BA)"
                    using A28 A30 xreal_1_th_68 sorry
                  then have A39: "sinSIN-COSK18 ?B >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 (sinSIN-COSK18 ?BA)"
                    using A28 xcmplx_1_th_87 sorry
                  have A40: "?B inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
                    using A25 A38 comptrig_th_42 sorry
                  have "?BA inHIDDENR3 ].RCOMP-1K2 (PISIN-COSK29)/XCMPLX-0K7 \<two>\<^sub>M,PISIN-COSK29 .["
                    using A25 A21 A35 comptrig_th_42 sorry
                  then have "?BA >XXREAL-0R4 ?B"
                    using A40 A39 complex2_th_7 sorry
                  then have "?BA +XCMPLX-0K2 (-XCMPLX-0K4 ?B) >XXREAL-0R4 ?B +XCMPLX-0K2 (-XCMPLX-0K4 ?B)"
                    using xreal_1_th_8 sorry
                  thus " not ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 sorry
              qed
            qed
            thus " ?thesis "
               sorry
          qed
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed "sorry"
    then have "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 A3 A4 sorry
    then have "ArgCOMPTRIGK1 (-XCMPLX-0K4 (a -XCMPLX-0K6 b)) -XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have "(ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 PISIN-COSK29)-XCMPLX-0K6 ArgCOMPTRIGK1 b >XXREAL-0R4 0NUMBERSK6"
      using A8 A10 A11 complex2_th_13 complex1_th_4 sorry
    then have A41: "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 (ArgCOMPTRIGK1 b +XCMPLX-0K2 PISIN-COSK29) >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 b) >XXREAL-0R4 0NUMBERSK6"
      using A4 A8 complex2_th_13 complex1_th_4 sorry
    then have "angleCOMPLEX2K4(0cCOMPLEX1K6,b,a) =COMPLEX1R1 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (0cCOMPLEX1K6 -XCMPLX-0K6 b)"
      using complex2_def_4 sorry
    then have "(angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6) =HIDDENR1 (((ArgCOMPTRIGK1 b -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 b))-XCMPLX-0K6 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b))+XCMPLX-0K2 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a) -XCMPLX-0K6 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a))"
      using A7 A14 sorry
    also have "... = PISIN-COSK29"
      using A9 A6 A13 sorry
    finally show "(angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6) =HIDDENR1 PISIN-COSK29"
       sorry
    have "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (0cCOMPLEX1K6 -XCMPLX-0K6 b) >XXREAL-0R4 0NUMBERSK6"
      using A4 A8 A41 complex2_th_13 complex1_th_4 sorry
    thus "0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(0cCOMPLEX1K6,b,a)"
      using complex2_def_4 sorry
    have A42: "ArgCOMPTRIGK1 a >=XXREAL-0R2 0NUMBERSK6"
      using comptrig_th_34 sorry
    have "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b)"
      using comptrig_th_34 sorry
    then have A43: "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_20 sorry
    have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) -XCMPLX-0K6 (ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 PISIN-COSK29) =COMPLEX1R1 ArgCOMPTRIGK1 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b))"
      using A6 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,a,0cCOMPLEX1K6)"
      using A14 A13 A43 A42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_84:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds ((a <>HIDDENR2 b & b <>HIDDENR2 c) & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(a,b,c)) & angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,c,a)) & 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(c,a,b)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds a <>HIDDENR2 b & (b <>HIDDENR2 c & (0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 PISIN-COSK29)) implies (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 & (0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,c,a) &  not 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(c,a,b))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 b"
      and A2: "b <>HIDDENR2 c"
      and A3: "0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(a,b,c)"
      and A4: "angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 PISIN-COSK29"
    have A5: "c -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    let ?r = "-XCMPLX-0K4 ArgCOMPTRIGK1 (a +XCMPLX-0K2 (-XCMPLX-0K4 b))"
    let ?A = "RotateCOMPLEX2K2(a +XCMPLX-0K2 (-XCMPLX-0K4 b),?r)"
    let ?B = "RotateCOMPLEX2K2(c +XCMPLX-0K2 (-XCMPLX-0K4 b),?r)"
    have A6: "RotateCOMPLEX2K2(0cCOMPLEX1K6,?r) =COMPLEX1R1 0cCOMPLEX1K6"
      using complex2_th_52 sorry
    have A7: "c +XCMPLX-0K2 (-XCMPLX-0K4 b) <>HIDDENR2 a +XCMPLX-0K2 (-XCMPLX-0K4 b)"
      using A3 complex2_th_79 sorry
    have A8: "angleCOMPLEX2K4(b,c,a) =HIDDENR1 angleCOMPLEX2K4(b +XCMPLX-0K2 (-XCMPLX-0K4 b),c +XCMPLX-0K2 (-XCMPLX-0K4 b),a +XCMPLX-0K2 (-XCMPLX-0K4 b))"
      using complex2_th_72 sorry
    also have "... = angleCOMPLEX2K4(0cCOMPLEX1K6,?B,?A)"
      using A6 A7 A5 complex2_th_78 sorry
    finally have "angleCOMPLEX2K4(b,c,a) =HIDDENR1 angleCOMPLEX2K4(0cCOMPLEX1K6,?B,?A)"
       sorry
    have A9: "angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),0cCOMPLEX1K6,c +XCMPLX-0K2 (-XCMPLX-0K4 b)) =HIDDENR1 angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),b +XCMPLX-0K2 (-XCMPLX-0K4 b),c +XCMPLX-0K2 (-XCMPLX-0K4 b))"
       sorry
    also have "... = angleCOMPLEX2K4(a,b,c)"
      using complex2_th_72 sorry
    finally have "angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),0cCOMPLEX1K6,c +XCMPLX-0K2 (-XCMPLX-0K4 b)) =HIDDENR1 angleCOMPLEX2K4(a,b,c)"
       sorry
    have A10: "a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have A11: "angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),0cCOMPLEX1K6,c +XCMPLX-0K2 (-XCMPLX-0K4 b)) =COMPLEX1R1 angleCOMPLEX2K4(?A,0cCOMPLEX1K6,?B)"
      using A6 A5 complex2_th_78 sorry
    have "a +XCMPLX-0K2 (-XCMPLX-0K4 b) <>HIDDENR2 0cCOMPLEX1K6"
      using A1 sorry
    then have " |.COMPLEX1K10 a +XCMPLX-0K2 (-XCMPLX-0K4 b) .| >XXREAL-0R4 0NUMBERSK6"
      using complex1_th_47 sorry
    then have A12: "ImCOMPLEX1K4 ?A =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 ?A >XXREAL-0R4 0NUMBERSK6"
      using complex1_th_12 sin_cos_th_31 sorry
    then have A13: "ArgCOMPTRIGK1 ?A =COMPLEX1R1 0cCOMPLEX1K6"
      using complex2_th_21 sorry
    then have "ArgCOMPTRIGK1 (?B -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (?A -XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6"
      using comptrig_th_34 sorry
    then have A14: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 ArgCOMPTRIGK1 ?B"
      using A9 A11 A13 complex2_def_4 sorry
    have A15: "angleCOMPLEX2K4(c,a,b) =HIDDENR1 angleCOMPLEX2K4(c +XCMPLX-0K2 (-XCMPLX-0K4 b),a +XCMPLX-0K2 (-XCMPLX-0K4 b),b +XCMPLX-0K2 (-XCMPLX-0K4 b))"
      using complex2_th_72 sorry
    also have "... = angleCOMPLEX2K4(?B,?A,0cCOMPLEX1K6)"
      using A6 A10 A7 complex2_th_78 sorry
    finally have "angleCOMPLEX2K4(c,a,b) =HIDDENR1 angleCOMPLEX2K4(?B,?A,0cCOMPLEX1K6)"
       sorry
    thus "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
      using A3 A4 A9 A11 A12 A14 A8 complex2_lm_5 sorry
    show "0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(b,c,a)"
      using A3 A4 A12 A14 A8 complex2_lm_5 sorry
    show " not 0NUMBERSK6 <XXREAL-0R3 angleCOMPLEX2K4(c,a,b)"
      using A3 A4 A12 A14 A15 complex2_lm_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_85:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & b <>HIDDENR2 c) & angleCOMPLEX2K4(a,b,c) >XXREAL-0R4 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & angleCOMPLEX2K4(b,c,a) >XXREAL-0R4 PISIN-COSK29) & angleCOMPLEX2K4(c,a,b) >XXREAL-0R4 PISIN-COSK29"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & b <>HIDDENR2 c) & angleCOMPLEX2K4(a,b,c) >XXREAL-0R4 PISIN-COSK29 implies (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =HIDDENR1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & ((angleCOMPLEX2K4(b,c,a) <=XXREAL-0R1 PISIN-COSK29 implies  False ) & (angleCOMPLEX2K4(c,a,b) <=XXREAL-0R1 PISIN-COSK29 implies  False ))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 b & b <>HIDDENR2 c"
      and A2: "angleCOMPLEX2K4(a,b,c) >XXREAL-0R4 PISIN-COSK29"
    have A3: "angleCOMPLEX2K4(c,b,a) <XXREAL-0R3 PISIN-COSK29"
    proof-
      have " not ( not angleCOMPLEX2K4(c,b,a) <XXREAL-0R3 PISIN-COSK29) implies  False "
      proof(rule impI)
        assume " not ( not angleCOMPLEX2K4(c,b,a) <XXREAL-0R3 PISIN-COSK29)"
        then have "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) >XXREAL-0R4 PISIN-COSK29 +XCMPLX-0K2 PISIN-COSK29"
          using A2 xreal_1_th_8 sorry
        thus " False "
          using A2 complex2_th_80 comptrig_th_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A4: "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(c,b,a) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 0NUMBERSK6"
      using A2 complex2_th_80 comptrig_th_5 sorry
    then have A5: "angleCOMPLEX2K4(c,b,a) <>HIDDENR2 0NUMBERSK6"
      using complex2_th_70 sorry
    have A6: "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(c,b,a)"
      using complex2_th_70 sorry
    then have "angleCOMPLEX2K4(b,a,c) >XXREAL-0R4 0NUMBERSK6"
      using A1 A5 A3 complex2_th_84 sorry
    then have A7: "angleCOMPLEX2K4(c,a,b) +XCMPLX-0K2 angleCOMPLEX2K4(b,a,c) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 0NUMBERSK6"
      using complex2_th_80 sorry
    have "angleCOMPLEX2K4(a,c,b) >XXREAL-0R4 0NUMBERSK6"
      using A1 A6 A5 A3 complex2_th_84 sorry
    then have "angleCOMPLEX2K4(b,c,a) +XCMPLX-0K2 angleCOMPLEX2K4(a,c,b) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 0NUMBERSK6"
      using complex2_th_80 sorry
    then have "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 ((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))-XCMPLX-0K6 ((angleCOMPLEX2K4(c,b,a) +XCMPLX-0K2 angleCOMPLEX2K4(b,a,c))+XCMPLX-0K2 angleCOMPLEX2K4(a,c,b))"
      using A4 A7 sorry
    then have A8: "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =HIDDENR1 (((\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))+XCMPLX-0K2 PISIN-COSK29)+XCMPLX-0K2 PISIN-COSK29)-XCMPLX-0K6 PISIN-COSK29"
      using A1 A6 A5 A3 complex2_th_84 sorry
    also have "... = \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
       sorry
    finally show "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =HIDDENR1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
       sorry
    have A9: "angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_70 sorry
    have "angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using complex2_th_70 sorry
    then have A10: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))+XCMPLX-0K2 PISIN-COSK29 =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      using A9 xreal_1_th_8 sorry
    have A11: "(\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 PISIN-COSK29)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
       sorry
    show "angleCOMPLEX2K4(b,c,a) <=XXREAL-0R1 PISIN-COSK29 implies  False "
    proof(rule impI)
      assume "angleCOMPLEX2K4(b,c,a) <=XXREAL-0R1 PISIN-COSK29"
      then have A12: "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 PISIN-COSK29"
        using A9 xreal_1_th_8 sorry
      have "angleCOMPLEX2K4(c,a,b) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
        using complex2_th_70 sorry
      thus " False "
        using A8 A11 A12 xreal_1_th_8 sorry
    qed
    assume "angleCOMPLEX2K4(c,a,b) <=XXREAL-0R1 PISIN-COSK29"
    thus " False "
      using A8 A10 xreal_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma complex2_lm_6:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6) & ArgCOMPTRIGK1 b =COMPLEX1R1 PISIN-COSK29 implies ((angleCOMPLEX2K4(a,0NUMBERSK6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0NUMBERSK6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0NUMBERSK6) =COMPLEX1R1 PISIN-COSK29 & 0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(0NUMBERSK6,b,a)) & 0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(b,a,0NUMBERSK6)"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6 & (ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6 & ArgCOMPTRIGK1 b =COMPLEX1R1 PISIN-COSK29) implies (angleCOMPLEX2K4(a,0NUMBERSK6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0NUMBERSK6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0NUMBERSK6) =HIDDENR1 PISIN-COSK29 & (0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(0NUMBERSK6,b,a) & 0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(b,a,0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    assume A1: "ImCOMPLEX1K4 a =COMPLEX1R1 0NUMBERSK6"
      and A2: "ReCOMPLEX1K3 a >XXREAL-0R4 0NUMBERSK6"
      and A3: "ArgCOMPTRIGK1 b =COMPLEX1R1 PISIN-COSK29"
    have A4: "ImCOMPLEX1K4 (a -XCMPLX-0K6 b) =HIDDENR1 ImCOMPLEX1K4 a -REAL-1K5 ImCOMPLEX1K4 b"
      using complex1_th_19 sorry
    also have "... = -REAL-1K1 ImCOMPLEX1K4 b"
      using A1 sorry
    finally have "ImCOMPLEX1K4 (a -XCMPLX-0K6 b) =HIDDENR1 -REAL-1K1 ImCOMPLEX1K4 b"
       sorry
    have A5: "ReCOMPLEX1K3 b +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ReCOMPLEX1K3 a"
      using A2 A3 complex2_th_22 sorry
    then have "ReCOMPLEX1K3 a -REAL-1K5 ReCOMPLEX1K3 b >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_20 sorry
    then have A6: "ReCOMPLEX1K3 (a -XCMPLX-0K6 b) >XXREAL-0R4 0NUMBERSK6"
      using complex1_th_19 sorry
    have "a =COMPLEX1R1 ReCOMPLEX1K3 a +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 complex1_th_13 sorry
    then have A7: "ArgCOMPTRIGK1 a =COMPLEX1R1 0NUMBERSK6"
      using A2 comptrig_th_35 sorry
    then have A8: "ArgCOMPTRIGK1 (b -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (a -XCMPLX-0K6 0cCOMPLEX1K6) >XXREAL-0R4 0NUMBERSK6"
      using A3 comptrig_th_5 sorry
    have "-REAL-1K1 (-REAL-1K1 (ReCOMPLEX1K3 a -REAL-1K5 ReCOMPLEX1K3 b)) >XXREAL-0R4 0NUMBERSK6"
      using A5 xreal_1_th_20 sorry
    then have "ReCOMPLEX1K3 b -REAL-1K5 ReCOMPLEX1K3 a <XXREAL-0R3 0NUMBERSK6"
       sorry
    then have A9: "ReCOMPLEX1K3 (b -XCMPLX-0K6 a) <XXREAL-0R3 0NUMBERSK6"
      using complex1_th_19 sorry
    have A10: "ImCOMPLEX1K4 (b -XCMPLX-0K6 a) =HIDDENR1 ImCOMPLEX1K4 b -REAL-1K5 ImCOMPLEX1K4 a"
      using complex1_th_19 sorry
    also have "... = 0NUMBERSK6"
      using A1 A3 complex2_th_22 sorry
    finally have "ImCOMPLEX1K4 (b -XCMPLX-0K6 a) =HIDDENR1 0NUMBERSK6"
       sorry
    then have A11: "-XCMPLX-0K4 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) =COMPLEX1R1 -XCMPLX-0K4 PISIN-COSK29"
      using A9 complex2_th_22 sorry
    have A12: "ArgCOMPTRIGK1 (b -XCMPLX-0K6 a) =COMPLEX1R1 PISIN-COSK29"
      using A9 A10 complex2_th_22 sorry
    have A13: "ArgCOMPTRIGK1 (-XCMPLX-0K4 b) =COMPLEX1R1 ArgCOMPTRIGK1 b -XCMPLX-0K6 PISIN-COSK29"
      using A3 complex2_lm_1 complex2_th_13 comptrig_th_5 sorry
    have A14: "ImCOMPLEX1K4 b =COMPLEX1R1 0NUMBERSK6"
      using A3 complex2_th_22 sorry
    then have A15: "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) =COMPLEX1R1 0NUMBERSK6"
      using A4 A6 complex2_th_21 sorry
    have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 ArgCOMPTRIGK1 a +XCMPLX-0K2 PISIN-COSK29"
      using A2 A7 complex2_th_13 complex1_th_4 comptrig_th_5 sorry
    also have "... = PISIN-COSK29"
      using A7 sorry
    finally have "ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 PISIN-COSK29"
       sorry
    then have A16: "angleCOMPLEX2K4(b,a,0cCOMPLEX1K6) =COMPLEX1R1 ArgCOMPTRIGK1 (0cCOMPLEX1K6 -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a)"
      using A11 complex2_def_4 sorry
    have A17: "ArgCOMPTRIGK1 a -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 ArgCOMPTRIGK1 a -XCMPLX-0K6 (ArgCOMPTRIGK1 a +XCMPLX-0K2 PISIN-COSK29)"
      using A2 A7 complex2_th_13 complex1_th_4 comptrig_th_5 sorry
    also have "... = -XCMPLX-0K4 PISIN-COSK29"
       sorry
    finally have "ArgCOMPTRIGK1 a -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 a) =HIDDENR1 -XCMPLX-0K4 PISIN-COSK29"
       sorry
    have A18: "ArgCOMPTRIGK1 (-XCMPLX-0K4 b) =COMPLEX1R1 ArgCOMPTRIGK1 b -XCMPLX-0K6 PISIN-COSK29"
      using A3 complex2_lm_1 complex2_th_13 comptrig_th_5 sorry
    then have A19: "ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (0cCOMPLEX1K6 -XCMPLX-0K6 b) =COMPLEX1R1 0NUMBERSK6"
      using A3 A14 A4 A6 complex2_th_21 sorry
    then have "angleCOMPLEX2K4(0cCOMPLEX1K6,b,a) =COMPLEX1R1 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 b)"
      using complex2_def_4 sorry
    then have A20: "(angleCOMPLEX2K4(a,0NUMBERSK6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0NUMBERSK6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0NUMBERSK6) =HIDDENR1 ((ArgCOMPTRIGK1 b -XCMPLX-0K6 ArgCOMPTRIGK1 a)+XCMPLX-0K2 (ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 b)))+XCMPLX-0K2 (ArgCOMPTRIGK1 (0NUMBERSK6 -XCMPLX-0K6 a) -XCMPLX-0K6 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a))"
      using A8 A16 complex2_def_4 sorry
    also have "... = (((ArgCOMPTRIGK1 b -XCMPLX-0K6 ArgCOMPTRIGK1 (-XCMPLX-0K4 b))-XCMPLX-0K6 ArgCOMPTRIGK1 a)+XCMPLX-0K2 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b))+XCMPLX-0K2 (ArgCOMPTRIGK1 (-XCMPLX-0K4 a) -XCMPLX-0K6 ArgCOMPTRIGK1 (b -XCMPLX-0K6 a))"
       sorry
    also have "... = PISIN-COSK29"
      using A15 A12 A13 A17 sorry
    finally show "(angleCOMPLEX2K4(a,0NUMBERSK6,b) +XCMPLX-0K2 angleCOMPLEX2K4(0NUMBERSK6,b,a))+XCMPLX-0K2 angleCOMPLEX2K4(b,a,0NUMBERSK6) =HIDDENR1 PISIN-COSK29"
       sorry
    have "(ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) +XCMPLX-0K2 PISIN-COSK29)-XCMPLX-0K6 ArgCOMPTRIGK1 b =COMPLEX1R1 0NUMBERSK6"
      using A3 A14 A4 A6 complex2_th_21 sorry
    then have A21: "angleCOMPLEX2K4(0cCOMPLEX1K6,b,a) =COMPLEX1R1 ArgCOMPTRIGK1 (a -XCMPLX-0K6 b) -XCMPLX-0K6 ArgCOMPTRIGK1 (0cCOMPLEX1K6 -XCMPLX-0K6 b)"
      using A18 complex2_def_4 sorry
    show "0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(0NUMBERSK6,b,a)"
      using A19 complex2_def_4 sorry
    have "angleCOMPLEX2K4(a,0cCOMPLEX1K6,b) =COMPLEX1R1 ArgCOMPTRIGK1 b -XCMPLX-0K6 ArgCOMPTRIGK1 a"
      using A8 complex2_def_4 sorry
    thus "0NUMBERSK6 =COMPLEX1R1 angleCOMPLEX2K4(b,a,0NUMBERSK6)"
      using A3 A7 A19 A21 A20 xcmplx_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_86:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (a <>HIDDENR2 b & b <>HIDDENR2 c) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29 implies angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds a <>HIDDENR2 b & (b <>HIDDENR2 c & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29) implies angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 b"
      and A2: "b <>HIDDENR2 c"
      and A3: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29"
    have A4: "c -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    let ?r = "-XCMPLX-0K4 ArgCOMPTRIGK1 (a +XCMPLX-0K2 (-XCMPLX-0K4 b))"
    let ?A = "RotateCOMPLEX2K2(a +XCMPLX-0K2 (-XCMPLX-0K4 b),?r)"
    let ?B = "RotateCOMPLEX2K2(c +XCMPLX-0K2 (-XCMPLX-0K4 b),?r)"
    have A5: "RotateCOMPLEX2K2(0cCOMPLEX1K6,?r) =COMPLEX1R1 0cCOMPLEX1K6"
      using complex2_th_52 sorry
    have A6: "angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),0cCOMPLEX1K6,c +XCMPLX-0K2 (-XCMPLX-0K4 b)) =HIDDENR1 angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),b +XCMPLX-0K2 (-XCMPLX-0K4 b),c +XCMPLX-0K2 (-XCMPLX-0K4 b))"
       sorry
    also have "... = angleCOMPLEX2K4(a,b,c)"
      using complex2_th_72 sorry
    finally have "angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),0cCOMPLEX1K6,c +XCMPLX-0K2 (-XCMPLX-0K4 b)) =HIDDENR1 angleCOMPLEX2K4(a,b,c)"
       sorry
    have A7: "c +XCMPLX-0K2 (-XCMPLX-0K4 b) <>HIDDENR2 a +XCMPLX-0K2 (-XCMPLX-0K4 b)"
      using A3 complex2_th_79 comptrig_th_5 sorry
    have A8: "a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    then have A9: "angleCOMPLEX2K4(a +XCMPLX-0K2 (-XCMPLX-0K4 b),0cCOMPLEX1K6,c +XCMPLX-0K2 (-XCMPLX-0K4 b)) =COMPLEX1R1 angleCOMPLEX2K4(?A,0cCOMPLEX1K6,?B)"
      using A5 A4 complex2_th_78 sorry
    have "a +XCMPLX-0K2 (-XCMPLX-0K4 b) <>HIDDENR2 0cCOMPLEX1K6"
      using A1 sorry
    then have " |.COMPLEX1K10 a +XCMPLX-0K2 (-XCMPLX-0K4 b) .| >XXREAL-0R4 0NUMBERSK6"
      using complex1_th_47 sorry
    then have A10: "ImCOMPLEX1K4 ?A =COMPLEX1R1 0NUMBERSK6 & ReCOMPLEX1K3 ?A >XXREAL-0R4 0NUMBERSK6"
      using complex1_th_12 sin_cos_th_31 sorry
    then have A11: "ArgCOMPTRIGK1 ?A =COMPLEX1R1 0cCOMPLEX1K6"
      using complex2_th_21 sorry
    then have "ArgCOMPTRIGK1 (?B -XCMPLX-0K6 0cCOMPLEX1K6) -XCMPLX-0K6 ArgCOMPTRIGK1 (?A -XCMPLX-0K6 0cCOMPLEX1K6) >=XXREAL-0R2 0NUMBERSK6"
      using comptrig_th_34 sorry
    then have A12: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 ArgCOMPTRIGK1 ?B"
      using A6 A9 A11 complex2_def_4 sorry
    have "angleCOMPLEX2K4(b,c,a) =HIDDENR1 angleCOMPLEX2K4(b +XCMPLX-0K2 (-XCMPLX-0K4 b),c +XCMPLX-0K2 (-XCMPLX-0K4 b),a +XCMPLX-0K2 (-XCMPLX-0K4 b))"
      using complex2_th_72 sorry
    also have "... = angleCOMPLEX2K4(0cCOMPLEX1K6,?B,?A)"
      using A5 A7 A4 complex2_th_78 sorry
    finally have "angleCOMPLEX2K4(b,c,a) =HIDDENR1 angleCOMPLEX2K4(0cCOMPLEX1K6,?B,?A)"
       sorry
    thus "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6"
      using A3 A10 A12 complex2_lm_6 sorry
    have "angleCOMPLEX2K4(c,a,b) =HIDDENR1 angleCOMPLEX2K4(c +XCMPLX-0K2 (-XCMPLX-0K4 b),a +XCMPLX-0K2 (-XCMPLX-0K4 b),b +XCMPLX-0K2 (-XCMPLX-0K4 b))"
      using complex2_th_72 sorry
    also have "... = angleCOMPLEX2K4(?B,?A,0cCOMPLEX1K6)"
      using A5 A8 A7 complex2_th_78 sorry
    finally have "angleCOMPLEX2K4(c,a,b) =HIDDENR1 angleCOMPLEX2K4(?B,?A,0cCOMPLEX1K6)"
       sorry
    thus "angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
      using A3 A10 A12 complex2_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_87:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds ((a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds a <>HIDDENR2 b & (a <>HIDDENR2 c & (b <>HIDDENR2 c & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6)) implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    assume A1: "a <>HIDDENR2 b"
      and A2: "a <>HIDDENR2 c"
      and A3: "b <>HIDDENR2 c"
      and A4: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6"
    show " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
    proof-
      have cases: "angleCOMPLEX2K4(b,c,a) <>HIDDENR2 0NUMBERSK6 or angleCOMPLEX2K4(c,a,b) <>HIDDENR2 0NUMBERSK6"
        using A1 A2 A3 A4 complex2_th_83 sorry
      have case1: "angleCOMPLEX2K4(b,c,a) <>HIDDENR2 0NUMBERSK6 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
      proof(rule impI)
        assume A5: "angleCOMPLEX2K4(b,c,a) <>HIDDENR2 0NUMBERSK6"
        have A6: "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(b,c,a)"
          using complex2_th_70 sorry
        show " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
        proof-
          show " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
          proof-
            have cases: "(angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 PISIN-COSK29 or angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29) or angleCOMPLEX2K4(b,c,a) >XXREAL-0R4 PISIN-COSK29"
              using xxreal_0_th_1 sorry
            have case1: "angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
            proof(rule impI)
              assume "angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 PISIN-COSK29"
              thus " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
                using A2 A3 A4 A5 A6 complex2_th_84 sorry
            qed
            have case2: "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
            proof(rule impI)
              assume "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29"
              thus " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
                using A2 A3 complex2_th_86 sorry
            qed
            have case3: "angleCOMPLEX2K4(b,c,a) >XXREAL-0R4 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
            proof(rule impI)
              assume "angleCOMPLEX2K4(b,c,a) >XXREAL-0R4 PISIN-COSK29"
              thus " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
                using A2 A3 A4 complex2_th_85 comptrig_th_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
      qed
      have case2: "angleCOMPLEX2K4(c,a,b) <>HIDDENR2 0NUMBERSK6 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
      proof(rule impI)
        assume A7: "angleCOMPLEX2K4(c,a,b) <>HIDDENR2 0NUMBERSK6"
        have A8: "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(c,a,b)"
          using complex2_th_70 sorry
        show " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
        proof-
          show " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
          proof-
            have cases: "(angleCOMPLEX2K4(c,a,b) <XXREAL-0R3 PISIN-COSK29 or angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) or angleCOMPLEX2K4(c,a,b) >XXREAL-0R4 PISIN-COSK29"
              using xxreal_0_th_1 sorry
            have case1: "angleCOMPLEX2K4(c,a,b) <XXREAL-0R3 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
            proof(rule impI)
              assume "angleCOMPLEX2K4(c,a,b) <XXREAL-0R3 PISIN-COSK29"
              thus " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
                using A1 A2 A4 A7 A8 complex2_th_84 sorry
            qed
            have case2: "angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
            proof(rule impI)
              assume "angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
              thus " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
                using A1 A2 complex2_th_86 sorry
            qed
            have case3: "angleCOMPLEX2K4(c,a,b) >XXREAL-0R4 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
            proof(rule impI)
              assume "angleCOMPLEX2K4(c,a,b) >XXREAL-0R4 PISIN-COSK29"
              thus " not ( not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29) &  not (angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6))"
                using A1 A2 A4 complex2_th_85 comptrig_th_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem complex2_th_88:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) iff (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for c be ComplexXCMPLX-0M1 holds ((angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c) & (a <>HIDDENR2 b & (a <>HIDDENR2 c & b <>HIDDENR2 c) implies  not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix c assume [ty]: "c be ComplexXCMPLX-0M1"
    show "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
    proof(rule impI)
      assume A1: "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
      show "(a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
      proof-
        have cases: "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          using A1 sorry
        have case1: "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 implies (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
        proof(rule impI)
          assume A2: "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
          show "(a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
          proof-
            have " not ((a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c) implies  False "
            proof(rule impI)
              assume A3: " not ((a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c)"
              show " False "
              proof-
                have cases: "(a =COMPLEX1R1 b or a =COMPLEX1R1 c) or b =COMPLEX1R1 c"
                  using A3 sorry
                have case1: "a =COMPLEX1R1 b implies  False "
                proof(rule impI)
                  assume A4: "a =COMPLEX1R1 b"
                  have A5: "angleCOMPLEX2K4(a,c,a) =COMPLEX1R1 0NUMBERSK6"
                    using complex2_th_79 sorry
                  have " not (angleCOMPLEX2K4(a,a,c) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,a) =COMPLEX1R1 0NUMBERSK6)"
                    using A2 A4 complex2_th_79 comptrig_th_5 sorry
                  thus " False "
                    using A2 A4 A5 complex2_th_80 comptrig_th_5 sorry
                qed
                have case2: "a =COMPLEX1R1 c implies  False "
                proof(rule impI)
                  assume A6: "a =COMPLEX1R1 c"
                  have A7: "angleCOMPLEX2K4(a,b,a) =COMPLEX1R1 0NUMBERSK6"
                    using complex2_th_79 sorry
                  have " not (angleCOMPLEX2K4(a,a,b) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(b,a,a) =COMPLEX1R1 0NUMBERSK6)"
                    using A2 A6 complex2_th_79 comptrig_th_5 sorry
                  thus " False "
                    using A2 A6 A7 complex2_th_80 comptrig_th_5 sorry
                qed
                have case3: "b =COMPLEX1R1 c implies  False "
                proof(rule impI)
                  assume A8: "b =COMPLEX1R1 c"
                  have A9: "angleCOMPLEX2K4(b,a,b) =COMPLEX1R1 0NUMBERSK6"
                    using complex2_th_79 sorry
                  have " not (angleCOMPLEX2K4(a,b,b) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(b,b,a) =COMPLEX1R1 0NUMBERSK6)"
                    using A2 A8 complex2_th_79 comptrig_th_5 sorry
                  thus " False "
                    using A2 A8 A9 complex2_th_80 comptrig_th_5 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 sorry
              qed
            qed
            thus " ?thesis "
               sorry
          qed
        qed
        have case2: "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) implies (a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
        proof(rule impI)
          assume A10: "(angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
          have A11: "(\<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M)*XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
            using comptrig_th_5 xreal_1_th_68 sorry
          then have A12: "\<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) <XXREAL-0R3 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
             sorry
          show "(a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c"
          proof-
            have " not ((a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c) implies  False "
            proof(rule impI)
              assume A13: " not ((a <>HIDDENR2 b & a <>HIDDENR2 c) & b <>HIDDENR2 c)"
              show " False "
              proof-
                have cases: "(a =COMPLEX1R1 b or b =COMPLEX1R1 c) or a =COMPLEX1R1 c"
                  using A13 sorry
                have case1: "a =COMPLEX1R1 b implies  False "
                proof(rule impI)
                  assume "a =COMPLEX1R1 b"
                  then have "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6"
                    using complex2_th_79 sorry
                  then have A14: "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                    using complex2_th_70 sorry
                  have "angleCOMPLEX2K4(c,a,b) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                    using complex2_th_70 sorry
                  thus " False "
                    using A10 A12 A14 xreal_1_th_8 sorry
                qed
                have case2: "b =COMPLEX1R1 c implies  False "
                proof(rule impI)
                  assume A15: "b =COMPLEX1R1 c"
                  have "angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) & angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                    using complex2_th_70 sorry
                  then have A16: "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                    using xreal_1_th_8 sorry
                  have "angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
                    using A15 complex2_th_79 sorry
                  thus " False "
                    using A10 A11 A16 sorry
                qed
                have case3: "a =COMPLEX1R1 c implies  False "
                proof(rule impI)
                  assume "a =COMPLEX1R1 c"
                  then have "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6"
                    using complex2_th_79 sorry
                  then have A17: "angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                    using complex2_th_70 sorry
                  have "angleCOMPLEX2K4(c,a,b) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29)"
                    using complex2_th_70 sorry
                  thus " False "
                    using A10 A12 A17 xreal_1_th_8 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 sorry
              qed
            qed
            thus " ?thesis "
               sorry
          qed
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    assume A18: "a <>HIDDENR2 b"
      and A19: "a <>HIDDENR2 c"
      and A20: "b <>HIDDENR2 c"
    show " not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
    proof-
      have cases: "((angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6 or 0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 PISIN-COSK29) or 0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29) or 0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) >XXREAL-0R4 PISIN-COSK29"
        using xxreal_0_th_1 sorry
      have case1: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6 implies  not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
      proof(rule impI)
        assume A21: "angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 0NUMBERSK6"
        have "angleCOMPLEX2K4(b,c,a) +XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
        proof-
          show "angleCOMPLEX2K4(b,c,a) +XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
          proof-
            have cases: "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 or angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
              using A18 A19 A20 A21 complex2_th_87 sorry
            have case1: "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 implies angleCOMPLEX2K4(b,c,a) +XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
            proof(rule impI)
              assume "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
              thus "angleCOMPLEX2K4(b,c,a) +XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
                 sorry
            qed
            have case2: "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6 implies angleCOMPLEX2K4(b,c,a) +XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
            proof(rule impI)
              assume "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 PISIN-COSK29 & angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 0NUMBERSK6"
              thus "angleCOMPLEX2K4(b,c,a) +XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
          using A21 sorry
      qed
      have case2: "0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
      proof(rule impI)
        assume A22: "0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) <XXREAL-0R3 PISIN-COSK29"
        have "0NUMBERSK6 <=XXREAL-0R1 angleCOMPLEX2K4(a,b,c)"
          using complex2_th_70 sorry
        thus " not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
          using A18 A20 A22 complex2_th_84 sorry
      qed
      have case3: "0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
      proof(rule impI)
        assume A23: "0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) =COMPLEX1R1 PISIN-COSK29"
        then have "angleCOMPLEX2K4(b,c,a) =COMPLEX1R1 0NUMBERSK6"
          using A18 A20 complex2_th_86 sorry
        thus " not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
          using A18 A20 A23 complex2_th_86 sorry
      qed
      have case4: "0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) >XXREAL-0R4 PISIN-COSK29 implies  not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
      proof(rule impI)
        assume "0NUMBERSK6 <>HIDDENR2 angleCOMPLEX2K4(a,b,c) & angleCOMPLEX2K4(a,b,c) >XXREAL-0R4 PISIN-COSK29"
        thus " not ( not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 PISIN-COSK29 &  not (angleCOMPLEX2K4(a,b,c) +XCMPLX-0K2 angleCOMPLEX2K4(b,c,a))+XCMPLX-0K2 angleCOMPLEX2K4(c,a,b) =COMPLEX1R1 \<five>\<^sub>M *XCMPLX-0K3 (PISIN-COSK29))"
          using A18 A20 complex2_th_85 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
