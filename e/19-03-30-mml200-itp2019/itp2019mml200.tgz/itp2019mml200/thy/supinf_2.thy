theory supinf_2
  imports funct_3 supinf_1 member_1 card_4 valued_1
   "../mizar_extension/E_number"
begin
(*begin*)
abbreviation(input) SUPINF_2K1("0.SUPINF-2K1" 228) where
  "0.SUPINF-2K1 \<equiv> 0ORDINAL1K5"

abbreviation(input) SUPINF_2K2("0.SUPINF-2K2" 228) where
  "0.SUPINF-2K2 \<equiv> 0ORDINAL1K5"

mtheorem supinf_2_add_1:
"cluster 0ORDINAL1K5 as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "0ORDINAL1K5 be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K3("-SUPINF-2K3  _ " [132]132) where
  "-SUPINF-2K3 x \<equiv> -XXREAL-3K2 x"

mtheorem supinf_2_add_2:
  mlet "x be R-ealSUPINF-1M1"
"cluster -XXREAL-3K2 x as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "-XXREAL-3K2 x be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K4(" _ +SUPINF-2K4  _ " [132,132]132) where
  "x +SUPINF-2K4 y \<equiv> x +XXREAL-3K1 y"

mtheorem supinf_2_add_3:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster x +XXREAL-3K1 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x +XXREAL-3K1 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K5(" _ -SUPINF-2K5  _ " [132,132]132) where
  "x -SUPINF-2K5 y \<equiv> x -XXREAL-3K3 y"

mtheorem supinf_2_add_4:
  mlet "x be R-ealSUPINF-1M1", "y be R-ealSUPINF-1M1"
"cluster x -XXREAL-3K3 y as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "x -XXREAL-3K3 y be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem supinf_2_th_1:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x +XXREAL-3K1 y =HIDDENR1 a +XCMPLX-0K2 b"
  using xxreal_3_def_2 sorry

mtheorem supinf_2_th_2:
" for x be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds x =HIDDENR1 a implies -XXREAL-3K2 x =HIDDENR1 -XCMPLX-0K4 a"
  using xxreal_3_def_3 sorry

mtheorem supinf_2_th_3:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a & y =HIDDENR1 b implies x -XXREAL-3K3 y =HIDDENR1 a -XCMPLX-0K6 b"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds x =HIDDENR1 a implies (y =HIDDENR1 b implies x -XXREAL-3K3 y =HIDDENR1 a -XCMPLX-0K6 b)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "x =HIDDENR1 a"
    assume "y =HIDDENR1 b"
    then have "-XXREAL-3K2 y =HIDDENR1 -XCMPLX-0K4 b"
      using xxreal_3_def_3 sorry
    thus "x -XXREAL-3K3 y =HIDDENR1 a -XCMPLX-0K6 b"
      using A1 xxreal_3_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SUPINF_2K6(" _ +SUPINF-2K6  _ " [132,132]132) where
  "X +SUPINF-2K6 Y \<equiv> X ++MEMBER-1K8 Y"

abbreviation(input) SUPINF_2K7(" _ +SUPINF-2K7  _ " [132,132]132) where
  "X +SUPINF-2K7 Y \<equiv> X ++MEMBER-1K8 Y"

mtheorem supinf_2_add_5:
  mlet "X be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster X ++MEMBER-1K8 Y as-term-is SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "X ++MEMBER-1K8 Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    using membered_th_2 sorry
qed "sorry"

abbreviation(input) SUPINF_2K8("-SUPINF-2K8  _ " [132]132) where
  "-SUPINF-2K8 X \<equiv> --MEMBER-1K4 X"

abbreviation(input) SUPINF_2K9("-SUPINF-2K9  _ " [132]132) where
  "-SUPINF-2K9 X \<equiv> --MEMBER-1K4 X"

mtheorem supinf_2_add_6:
  mlet "X be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster --MEMBER-1K4 X as-term-is SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "--MEMBER-1K4 X be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    using membered_th_2 sorry
qed "sorry"

(*\$CT*)
mtheorem supinf_2_th_5:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for z be R-ealSUPINF-1M1 holds z inTARSKIR2 X iff -SUPINF-2K3 z inTARSKIR2 -SUPINF-2K9 X"
  using member_1_th_1 sorry

mtheorem supinf_2_th_6:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds X c=MEMBEREDR2 Y iff -SUPINF-2K9 X c=MEMBEREDR2 -SUPINF-2K9 Y"
  using member_1_th_3 sorry

mtheorem supinf_2_th_7:
" for z be R-ealSUPINF-1M1 holds z inTARSKIR2 REALNUMBERSK2 iff -SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2"
proof-
  have " for z be R-ealSUPINF-1M1 holds  not (z inTARSKIR2 REALNUMBERSK2 &  not -SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2) &  not (-SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2 &  not z inTARSKIR2 REALNUMBERSK2)"
  proof(rule ballI)
    fix z assume [ty]: "z be R-ealSUPINF-1M1"
    have A1: " for z be R-ealSUPINF-1M1 holds z inTARSKIR2 REALNUMBERSK2 implies -SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be R-ealSUPINF-1M1"
      have A2: "-SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2 or -SUPINF-2K3 z inTARSKIR2 {TARSKIK2 -inftySUPINF-1K2,+inftySUPINF-1K1 }"
        using xboole_0_def_3 sorry
      assume "z inTARSKIR2 REALNUMBERSK2"
      thus "-SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2"
        using A2 tarski_def_2 sorry
    qed "sorry"
    have "-SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2 implies z inTARSKIR2 REALNUMBERSK2"
    proof(rule impI)
      assume "-SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2"
      then have "-SUPINF-2K3 (-SUPINF-2K3 z) inTARSKIR2 REALNUMBERSK2"
        using A1 sorry
      thus "z inTARSKIR2 REALNUMBERSK2"
         sorry
    qed
    thus " not (z inTARSKIR2 REALNUMBERSK2 &  not -SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2) &  not (-SUPINF-2K3 z inTARSKIR2 REALNUMBERSK2 &  not z inTARSKIR2 REALNUMBERSK2)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SUPINF_2K10("infSUPINF-2K10  _ " [228]228) where
  "infSUPINF-2K10 X \<equiv> infXXREAL-2K2 X"

mtheorem supinf_2_add_7:
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster infXXREAL-2K2 X as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "infXXREAL-2K2 X be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

abbreviation(input) SUPINF_2K11("supSUPINF-2K11  _ " [300]300) where
  "supSUPINF-2K11 X \<equiv> supXXREAL-2K1 X"

mtheorem supinf_2_add_8:
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster supXXREAL-2K1 X as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "supXXREAL-2K1 X be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mtheorem supinf_2_th_8:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds supSUPINF-2K11 (X +SUPINF-2K7 Y) <=XXREAL-3R1 supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 X +SUPINF-2K7 Y implies z <=XXREAL-3R1 supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "z inHIDDENR3 X +SUPINF-2K7 Y"
    then obtain x y where
      [ty]:"x be R-ealSUPINF-1M1" "y be R-ealSUPINF-1M1" and 
      A1: "z =HIDDENR1 x +SUPINF-2K4 y"and A2: "x inTARSKIR2 X"and A3: "y inTARSKIR2 Y"
       sorry
    have A4: "y <=XXREAL-3R1 supSUPINF-2K11 Y"
      using A3 xxreal_2_th_4 sorry
    have "x <=XXREAL-3R1 supSUPINF-2K11 X"
      using A2 xxreal_2_th_4 sorry
    thus "z <=XXREAL-3R1 supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y"
      using A1 A4 xxreal_3_th_36 sorry
  qed "sorry"
  then have "supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y be UpperBoundXXREAL-2M1-of X +SUPINF-2K7 Y"
    using xxreal_2_def_1 sorry
  thus "supSUPINF-2K11 (X +SUPINF-2K7 Y) <=XXREAL-3R1 supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y"
    using xxreal_2_def_3 sorry
qed "sorry"

mtheorem supinf_2_th_9:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y <=XXREAL-3R1 infSUPINF-2K10 (X +SUPINF-2K7 Y)"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 X +SUPINF-2K7 Y implies infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y <=XXREAL-3R1 z"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ExtRealXXREAL-0M1"
    assume "z inHIDDENR3 X +SUPINF-2K7 Y"
    then obtain x y where
      [ty]:"x be R-ealSUPINF-1M1" "y be R-ealSUPINF-1M1" and 
      A1: "z =HIDDENR1 x +SUPINF-2K4 y"and A2: "x inTARSKIR2 X"and A3: "y inTARSKIR2 Y"
       sorry
    have A4: "infSUPINF-2K10 Y <=XXREAL-3R1 y"
      using A3 xxreal_2_th_3 sorry
    have "infSUPINF-2K10 X <=XXREAL-3R1 x"
      using A2 xxreal_2_th_3 sorry
    thus "infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y <=XXREAL-3R1 z"
      using A1 A4 xxreal_3_th_36 sorry
  qed "sorry"
  then have "infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y be LowerBoundXXREAL-2M2-of X +SUPINF-2K7 Y"
    using xxreal_2_def_2 sorry
  thus "infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y <=XXREAL-3R1 infSUPINF-2K10 (X +SUPINF-2K7 Y)"
    using xxreal_2_def_4 sorry
qed "sorry"

mtheorem supinf_2_th_10:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds X be bounded-aboveXXREAL-2V4 & Y be bounded-aboveXXREAL-2V4 implies supSUPINF-2K11 (X +SUPINF-2K7 Y) <=XXREAL-3R1 supSUPINF-2K11 X +SUPINF-2K4 supSUPINF-2K11 Y"
  using supinf_2_th_8 sorry

mtheorem supinf_2_th_11:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds X be bounded-belowXXREAL-2V3 & Y be bounded-belowXXREAL-2V3 implies infSUPINF-2K10 X +SUPINF-2K4 infSUPINF-2K10 Y <=XXREAL-3R1 infSUPINF-2K10 (X +SUPINF-2K7 Y)"
  using supinf_2_th_9 sorry

mtheorem supinf_2_th_12:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for a be R-ealSUPINF-1M1 holds a be UpperBoundXXREAL-2M1-of X iff -SUPINF-2K3 a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for a be R-ealSUPINF-1M1 holds (a be UpperBoundXXREAL-2M1-of X implies -SUPINF-2K3 a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X) & (-SUPINF-2K3 a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X implies a be UpperBoundXXREAL-2M1-of X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    show "a be UpperBoundXXREAL-2M1-of X implies -SUPINF-2K3 a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X"
    proof(rule impI)
      assume A1: "a be UpperBoundXXREAL-2M1-of X"
      have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 -SUPINF-2K9 X implies -SUPINF-2K3 a <=XXREAL-3R1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        assume A2: "x inHIDDENR3 -SUPINF-2K9 X"
        have 
          [ty]:"x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
          using xxreal_0_def_1 sorry
        have "-SUPINF-2K3 x inTARSKIR2 -SUPINF-2K9 (-SUPINF-2K9 X)"
          using A2 sorry
        then have "-SUPINF-2K3 a <=XXREAL-3R1 -SUPINF-2K3 (-SUPINF-2K3 x)"
          using xxreal_3_th_38 A1 xxreal_2_def_1 sorry
        thus "-SUPINF-2K3 a <=XXREAL-3R1 x"
           sorry
      qed "sorry"
      thus "-SUPINF-2K3 a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X"
        using xxreal_2_def_2 sorry
    qed
    assume A3: "-SUPINF-2K3 a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-3R1 a"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A4: "x inHIDDENR3 X"
      have 
        [ty]:"x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
        using xxreal_0_def_1 sorry
      have "-SUPINF-2K3 x inTARSKIR2 -SUPINF-2K9 X"
        using A4 sorry
      thus "x <=XXREAL-3R1 a"
        using xxreal_3_th_38 A3 xxreal_2_def_2 sorry
    qed "sorry"
    thus "a be UpperBoundXXREAL-2M1-of X"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_13:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for a be R-ealSUPINF-1M1 holds a be LowerBoundXXREAL-2M2-of X iff -SUPINF-2K3 a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for a be R-ealSUPINF-1M1 holds (a be LowerBoundXXREAL-2M2-of X implies -SUPINF-2K3 a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X) & (-SUPINF-2K3 a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X implies a be LowerBoundXXREAL-2M2-of X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    show "a be LowerBoundXXREAL-2M2-of X implies -SUPINF-2K3 a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X"
    proof(rule impI)
      assume A1: "a be LowerBoundXXREAL-2M2-of X"
      have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 -SUPINF-2K9 X implies x <=XXREAL-3R1 -SUPINF-2K3 a"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        assume A2: "x inHIDDENR3 -SUPINF-2K9 X"
        have 
          [ty]:"x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
          using xxreal_0_def_1 sorry
        have "-SUPINF-2K3 x inTARSKIR2 -SUPINF-2K9 (-SUPINF-2K9 X)"
          using A2 sorry
        then have "-SUPINF-2K3 (-SUPINF-2K3 x) <=XXREAL-3R1 -SUPINF-2K3 a"
          using xxreal_3_th_38 A1 xxreal_2_def_2 sorry
        thus "x <=XXREAL-3R1 -SUPINF-2K3 a"
           sorry
      qed "sorry"
      thus "-SUPINF-2K3 a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X"
        using xxreal_2_def_1 sorry
    qed
    assume A3: "-SUPINF-2K3 a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies a <=XXREAL-3R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A4: "x inHIDDENR3 X"
      have 
        [ty]:"x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
        using xxreal_0_def_1 sorry
      have "-SUPINF-2K3 x inTARSKIR2 -SUPINF-2K9 X"
        using A4 sorry
      thus "a <=XXREAL-3R1 x"
        using xxreal_3_th_38 A3 xxreal_2_def_1 sorry
    qed "sorry"
    thus "a be LowerBoundXXREAL-2M2-of X"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_14:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds infSUPINF-2K10 (-SUPINF-2K9 X) =XBOOLE-0R4 -SUPINF-2K3 supSUPINF-2K11 X"
proof(rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  let ?a = "infSUPINF-2K10 (-SUPINF-2K9 X)"
  let ?b = "supSUPINF-2K11 X"
  have "?a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X"
    using xxreal_2_def_4 sorry
  then have "-SUPINF-2K3 ?a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 (-SUPINF-2K9 X)"
    using supinf_2_th_13 sorry
  then have A1: "-SUPINF-2K3 (-SUPINF-2K3 ?a) <=XXREAL-3R1 -SUPINF-2K3 ?b"
    using xxreal_3_th_38 xxreal_2_def_3 sorry
  have "?b be UpperBoundXXREAL-2M1-of X"
    using xxreal_2_def_3 sorry
  then have "-SUPINF-2K3 ?b be LowerBoundXXREAL-2M2-of -SUPINF-2K9 X"
    using supinf_2_th_12 sorry
  then have "-SUPINF-2K3 ?b <=XXREAL-3R1 ?a"
    using xxreal_2_def_4 sorry
  thus "infSUPINF-2K10 (-SUPINF-2K9 X) =XBOOLE-0R4 -SUPINF-2K3 supSUPINF-2K11 X"
    using A1 xxreal_0_th_1 sorry
qed "sorry"

mtheorem supinf_2_th_15:
" for X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds supSUPINF-2K11 (-SUPINF-2K9 X) =XBOOLE-0R4 -SUPINF-2K3 infSUPINF-2K10 X"
proof(rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  let ?a = "supSUPINF-2K11 (-SUPINF-2K9 X)"
  let ?b = "infSUPINF-2K10 X"
  have "?a be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X"
    using xxreal_2_def_3 sorry
  then have "-SUPINF-2K3 ?a be LowerBoundXXREAL-2M2-of -SUPINF-2K9 (-SUPINF-2K9 X)"
    using supinf_2_th_12 sorry
  then have A1: "-SUPINF-2K3 ?b <=XXREAL-3R1 -SUPINF-2K3 (-SUPINF-2K3 ?a)"
    using xxreal_3_th_38 xxreal_2_def_4 sorry
  have "?b be LowerBoundXXREAL-2M2-of X"
    using xxreal_2_def_4 sorry
  then have "-SUPINF-2K3 ?b be UpperBoundXXREAL-2M1-of -SUPINF-2K9 X"
    using supinf_2_th_13 sorry
  then have "?a <=XXREAL-3R1 -SUPINF-2K3 ?b"
    using xxreal_2_def_3 sorry
  thus "supSUPINF-2K11 (-SUPINF-2K9 X) =XBOOLE-0R4 -SUPINF-2K3 infSUPINF-2K10 X"
    using A1 xxreal_0_th_1 sorry
qed "sorry"

syntax SUPINF_2K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("rngSUPINF-2K12\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228)
translations "rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F" \<rightharpoonup> "rngRELAT-1K2 F"

mtheorem supinf_2_add_9:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "F be FunctionFUNCT-2M1-of(X,Y)"
"cluster rngRELAT-1K2 F as-term-is  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "rngRELAT-1K2 F be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  proof-
    let ?x = "the ElementSUBSET-1M1-of X"
    have "F .FUNCT-2K3\<^bsub>(X,Y)\<^esub> ?x inTARSKIR2 rngRELSET-1K2\<^bsub>(Y)\<^esub> F"
      using funct_2_th_4 sorry
    thus "rngRELAT-1K2 F be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
      using xboole_1_th_1 sorry
  qed
qed "sorry"

mdef supinf_2_def_1 ("supSUPINF-2K13\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,300]300 ) where
  mlet "D be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of D", "F be PartFuncPARTFUN1M1-of(X,Y)"
"func supSUPINF-2K13\<^bsub>(D,X,Y)\<^esub> F \<rightarrow> ElementSUBSET-1M1-of ExtREALXXREAL-0K3 equals
  supSUPINF-2K11 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F)"
proof-
  (*coherence*)
    show "supSUPINF-2K11 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F) be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
       sorry
qed "sorry"

mdef supinf_2_def_2 ("infSUPINF-2K14\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228 ) where
  mlet "D be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of D", "F be PartFuncPARTFUN1M1-of(X,Y)"
"func infSUPINF-2K14\<^bsub>(D,X,Y)\<^esub> F \<rightarrow> ElementSUBSET-1M1-of ExtREALXXREAL-0K3 equals
  infSUPINF-2K10 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F)"
proof-
  (*coherence*)
    show "infSUPINF-2K10 (rngRELSET-1K2\<^bsub>(Y)\<^esub> F) be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
       sorry
qed "sorry"

abbreviation(input) SUPINF_2K15(" _ .SUPINF-2K15  _ " [200,200]200) where
  "F .SUPINF-2K15 x \<equiv> F .FUNCT-1K1 x"

mtheorem supinf_2_add_10:
  mlet "F be ext-real-valuedVALUED-0V6\<bar>FunctionFUNCT-1M1", "x be setHIDDENM2"
"cluster F .FUNCT-1K1 x as-term-is R-ealSUPINF-1M1"
proof
(*coherence*)
  show "F .FUNCT-1K1 x be R-ealSUPINF-1M1"
    using xxreal_0_def_1 sorry
qed "sorry"

mdef supinf_2_def_3 (" _ +SUPINF-2K16\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "F be FunctionFUNCT-2M1-of(X,Y)", "G be FunctionFUNCT-2M1-of(X,Z)"
"func F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G \<rightarrow> FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) st  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
    proof-
      have " ex tVar1 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) st  for x be ElementSUBSET-1M1-of X holds tVar1 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
      proof-
        let ?F = "\<lambda>Lamb1. F .SUPINF-2K15 Lamb1 +SUPINF-2K4 G .SUPINF-2K15 Lamb1"
        have A1: " for x be ElementSUBSET-1M1-of X holds ?F(x) inTARSKIR2 Y +SUPINF-2K7 Z"
        proof-
          have " for x be ElementSUBSET-1M1-of X holds F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x inTARSKIR2 Y +SUPINF-2K7 Z"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
            have A2: "G .SUPINF-2K15 x inTARSKIR2 Z"
              using funct_2_th_5 sorry
            have "F .SUPINF-2K15 x inTARSKIR2 Y"
              using funct_2_th_5 sorry
            thus "F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x inTARSKIR2 Y +SUPINF-2K7 Z"
              using A2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex H be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) st  for x be ElementSUBSET-1M1-of X holds H .SUPINF-2K15 x =XBOOLE-0R4 ?F(x)"
          using funct_2_sch_8 A1 sorry
        then obtain H where
          [ty]:"H be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z)" and 
          A3: " for x be ElementSUBSET-1M1-of X holds H .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
           sorry
        show " ex tVar1 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) st  for x be ElementSUBSET-1M1-of X holds tVar1 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
        proof(rule bexI[of _ "H"])
          show " for x be ElementSUBSET-1M1-of X holds H .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
            using A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) holds  for it2 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) holds ( for x be ElementSUBSET-1M1-of X holds it1 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x) & ( for x be ElementSUBSET-1M1-of X holds it2 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) holds  for H2 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z) holds ( for x be ElementSUBSET-1M1-of X holds H1 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x) & ( for x be ElementSUBSET-1M1-of X holds H2 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x) implies H1 =HIDDENR1 H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z)"
        fix H2 assume [ty]: "H2 be FunctionFUNCT-2M1-of(X,Y +SUPINF-2K7 Z)"
        assume A4: " for x be ElementSUBSET-1M1-of X holds H1 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
          and A5: " for x be ElementSUBSET-1M1-of X holds H2 .SUPINF-2K15 x =XBOOLE-0R4 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies H1 .FUNCT-1K1 x =XBOOLE-0R4 H2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have 
            [ty]:"x be ElementSUBSET-1M1-of X"
             sorry
          have "H1 .SUPINF-2K15 x =HIDDENR1 F .SUPINF-2K15 x +SUPINF-2K4 G .SUPINF-2K15 x"
            using A4 sorry
          also have "... = H2 .SUPINF-2K15 x"
            using A5 sorry
          finally have "H1 .SUPINF-2K15 x =HIDDENR1 H2 .SUPINF-2K15 x"
             sorry
          thus "H1 .FUNCT-1K1 x =XBOOLE-0R4 H2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "H1 =HIDDENR1 H2"
          using funct_2_th_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem supinf_2_th_16:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds rngSUPINF-2K12\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) c=MEMBEREDR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
  fix G assume [ty]: "G be FunctionFUNCT-2M1-of(X,Z)"
  have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G).FUNCT-1K1 x inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 X"
    then have 
      [ty]:"x be ElementSUBSET-1M1-of X"
       sorry
    obtain a b where 
      [ty]:"a be R-ealSUPINF-1M1" and aDef:"a = F .SUPINF-2K15 x" and
      [ty]:"b be R-ealSUPINF-1M1" and bDef:"b = G .SUPINF-2K15 x"
       sorry
    have A2: "a inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
      using funct_2_th_4 sorry
    have A3: "b inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G"
      using funct_2_th_4 sorry
    have "(F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G).SUPINF-2K15 x =XBOOLE-0R4 a +SUPINF-2K4 b"
      using supinf_2_def_3 sorry
    thus "(F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G).FUNCT-1K1 x inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G"
      using A2 A3 sorry
  qed "sorry"
  have "domRELSET-1K1\<^bsub>(X)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) =XBOOLE-0R4 X"
    using funct_2_def_1 sorry
  then have "F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G be FunctionFUNCT-2M1-of(X,rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G)"
    using A1 funct_2_th_3 sorry
  thus "rngSUPINF-2K12\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) c=MEMBEREDR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G"
    using relat_1_def_19 sorry
qed "sorry"

mtheorem supinf_2_th_17:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) <=XXREAL-3R1 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> G"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
  fix G assume [ty]: "G be FunctionFUNCT-2M1-of(X,Z)"
  have A1: "supSUPINF-2K11 (rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G) <=XXREAL-3R1 supSUPINF-2K11 (rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F) +SUPINF-2K4 supSUPINF-2K11 (rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G)"
    using supinf_2_th_8 sorry
  have "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) <=XXREAL-3R1 supSUPINF-2K11 (rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G)"
    using supinf_2_th_16 xxreal_2_th_59 sorry
  thus "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G) <=XXREAL-3R1 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> G"
    using A1 xxreal_0_th_2 sorry
qed "sorry"

mtheorem supinf_2_th_18:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for G be FunctionFUNCT-2M1-of(X,Z) holds infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> G <=XXREAL-3R1 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
  fix G assume [ty]: "G be FunctionFUNCT-2M1-of(X,Z)"
  have A1: "infSUPINF-2K10 (rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F) +SUPINF-2K4 infSUPINF-2K10 (rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G) <=XXREAL-3R1 infSUPINF-2K10 (rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G)"
    using supinf_2_th_9 sorry
  have "infSUPINF-2K10 (rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F +SUPINF-2K7 rngSUPINF-2K12\<^bsub>(X,Z)\<^esub> G) <=XXREAL-3R1 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G)"
    using supinf_2_th_16 xxreal_2_th_60 sorry
  thus "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> G <=XXREAL-3R1 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> G)"
    using A1 xxreal_0_th_2 sorry
qed "sorry"

mdef supinf_2_def_4 ("-SUPINF-2K17\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3", "F be FunctionFUNCT-2M1-of(X,Y)"
"func -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F \<rightarrow> FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) st  for x be ElementSUBSET-1M1-of X holds it .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
    proof-
      have " ex tVar2 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) st  for x be ElementSUBSET-1M1-of X holds tVar2 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
      proof-
        let ?F = "\<lambda>Lamb1. -SUPINF-2K3 F .SUPINF-2K15 Lamb1"
        have A1: " for x be ElementSUBSET-1M1-of X holds ?F(x) inTARSKIR2 -SUPINF-2K9 Y"
        proof-
          have " for x be ElementSUBSET-1M1-of X holds -SUPINF-2K3 F .SUPINF-2K15 x inTARSKIR2 -SUPINF-2K9 Y"
          proof(rule ballI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
            have "F .SUPINF-2K15 x inTARSKIR2 Y"
              using funct_2_th_5 sorry
            thus "-SUPINF-2K3 F .SUPINF-2K15 x inTARSKIR2 -SUPINF-2K9 Y"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex H be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) st  for x be ElementSUBSET-1M1-of X holds H .SUPINF-2K15 x =XBOOLE-0R4 ?F(x)"
          using funct_2_sch_8 A1 sorry
        then obtain H where
          [ty]:"H be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y)" and 
          A2: " for x be ElementSUBSET-1M1-of X holds H .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
           sorry
        show " ex tVar2 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) st  for x be ElementSUBSET-1M1-of X holds tVar2 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
        proof(rule bexI[of _ "H"])
          show " for x be ElementSUBSET-1M1-of X holds H .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) holds  for it2 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) holds ( for x be ElementSUBSET-1M1-of X holds it1 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x) & ( for x be ElementSUBSET-1M1-of X holds it2 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) holds  for H2 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y) holds ( for x be ElementSUBSET-1M1-of X holds H1 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x) & ( for x be ElementSUBSET-1M1-of X holds H2 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x) implies H1 =HIDDENR1 H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y)"
        fix H2 assume [ty]: "H2 be FunctionFUNCT-2M1-of(X,-SUPINF-2K9 Y)"
        assume A3: " for x be ElementSUBSET-1M1-of X holds H1 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
          and A4: " for x be ElementSUBSET-1M1-of X holds H2 .SUPINF-2K15 x =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 x"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies H1 .FUNCT-1K1 x =XBOOLE-0R4 H2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have 
            [ty]:"x be ElementSUBSET-1M1-of X"
             sorry
          have "H1 .SUPINF-2K15 x =HIDDENR1 -SUPINF-2K3 F .SUPINF-2K15 x"
            using A3 sorry
          also have "... = H2 .SUPINF-2K15 x"
            using A4 sorry
          finally have "H1 .SUPINF-2K15 x =HIDDENR1 H2 .SUPINF-2K15 x"
             sorry
          thus "H1 .FUNCT-1K1 x =XBOOLE-0R4 H2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "H1 =HIDDENR1 H2"
          using funct_2_th_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem supinf_2_th_19:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =MEMBEREDR8 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
proof(rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
  have "rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) c=MEMBEREDR2 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F & -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F c=TARSKIR1 rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F)"
  proof(rule conjMI)
    show "rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) c=MEMBEREDR2 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) implies y inHIDDENR3 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> F =XBOOLE-0R4 X"
          using funct_2_def_1 sorry
        assume A2: "y inHIDDENR3 rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F)"
        then have 
          [ty]:"y be R-ealSUPINF-1M1"
           sorry
        have "domRELSET-1K1\<^bsub>(X)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =XBOOLE-0R4 X"
          using funct_2_def_1 sorry
        then obtain a where
          [ty]:"a be objectHIDDENM1" and 
          A3: "a inHIDDENR3 X"and A4: "y =XBOOLE-0R4 (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F).FUNCT-1K1 a"
          using A2 funct_1_def_3 sorry
        have 
          [ty]:"a be ElementSUBSET-1M1-of X"
          using A3 sorry
        have "y =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 a"
          using A4 supinf_2_def_4 sorry
        then have "-SUPINF-2K3 y inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
          using A1 funct_1_def_3 sorry
        then have "-SUPINF-2K3 (-SUPINF-2K3 y) inTARSKIR2 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
           sorry
        thus "y inHIDDENR3 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
           sorry
      qed "sorry"
      thus "rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) c=MEMBEREDR2 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
        using tarski_def_3 sorry
    qed
    have " for y be objectHIDDENM1 holds y inHIDDENR3 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F implies y inHIDDENR3 rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A5: "y inHIDDENR3 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
      then have 
        [ty]:"y be R-ealSUPINF-1M1"
         sorry
      have A6: "-SUPINF-2K3 y inTARSKIR2 -SUPINF-2K9 (-SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F)"
        using A5 sorry
      have "domRELSET-1K1\<^bsub>(X)\<^esub> F =XBOOLE-0R4 X"
        using funct_2_def_1 sorry
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A7: "a inHIDDENR3 X"and A8: "-SUPINF-2K3 y =XBOOLE-0R4 F .FUNCT-1K1 a"
        using A6 funct_1_def_3 sorry
      have 
        [ty]:"a be ElementSUBSET-1M1-of X"
        using A7 sorry
      have "y =XBOOLE-0R4 -SUPINF-2K3 F .SUPINF-2K15 a"
        using A8 sorry
      then have A9: "y =XBOOLE-0R4 (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F).SUPINF-2K15 a"
        using supinf_2_def_4 sorry
      have "domRELSET-1K1\<^bsub>(X)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =XBOOLE-0R4 X"
        using funct_2_def_1 sorry
      thus "y inHIDDENR3 rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F)"
        using A9 funct_1_def_3 sorry
    qed "sorry"
    thus "-SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F c=TARSKIR1 rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F)"
      using tarski_def_3 sorry
  qed
  thus "rngSUPINF-2K12\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =MEMBEREDR8 -SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem supinf_2_th_20:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =XBOOLE-0R4 -SUPINF-2K3 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =XBOOLE-0R4 -SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =HIDDENR1 -SUPINF-2K3 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =HIDDENR1 -SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    have "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =HIDDENR1 infSUPINF-2K10 (-SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F)"
      using supinf_2_th_19 sorry
    also have "... = -SUPINF-2K3 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
      using supinf_2_th_14 sorry
    finally show "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =HIDDENR1 -SUPINF-2K3 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
       sorry
    have "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =HIDDENR1 supSUPINF-2K11 (-SUPINF-2K9 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F)"
      using supinf_2_th_19 sorry
    also have "... = -SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
      using supinf_2_th_15 sorry
    finally show "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) =HIDDENR1 -SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef supinf_2_def_5 ("bounded-aboveSUPINF-2V1\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"attr bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y) means
  (\<lambda>F. supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <XXREAL-0R3 +inftySUPINF-1K1)"..

mdef supinf_2_def_6 ("bounded-belowSUPINF-2V2\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"attr bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y) means
  (\<lambda>F. -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F)"..

mdef supinf_2_def_7 ("boundedSUPINF-2V3\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"attr boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y) means
  (\<lambda>F. F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>)"..

mtheorem supinf_2_cl_1:
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> also-is bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(X,Y) holds it be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> implies it be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>"
     sorry
qed "sorry"

mtheorem supinf_2_cl_2:
  mlet "X be setHIDDENM2", "Y be SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
"cluster bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> also-is boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> for FunctionFUNCT-2M1-of(X,Y)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(X,Y) holds it be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>\<bar>bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> implies it be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub>"
     sorry
qed "sorry"

mtheorem supinf_2_th_21:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> iff supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <XXREAL-0R3 +inftySUPINF-1K1 & -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
  using supinf_2_def_5 supinf_2_def_6 sorry

mtheorem supinf_2_th_22:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> iff -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-belowSUPINF-2V2\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds (F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> implies -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-belowSUPINF-2V2\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>) & (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-belowSUPINF-2V2\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> implies F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    show "F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> implies -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-belowSUPINF-2V2\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
    proof(rule impI)
      assume "F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>"
      then have A1: "-SUPINF-2K3 +inftySUPINF-1K1 <XXREAL-0R3 -SUPINF-2K3 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
        using xxreal_3_th_38 sorry
      have "-SUPINF-2K3 +inftySUPINF-1K1 =XBOOLE-0R4 -inftySUPINF-1K2"
        using xxreal_3_def_3 sorry
      thus "-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-belowSUPINF-2V2\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
        using A1 supinf_2_th_20 sorry
    qed
    assume "-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-belowSUPINF-2V2\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
    then have "-SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,-SUPINF-2K9 Y)\<^esub> (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F) <XXREAL-0R3 -SUPINF-2K3 -inftySUPINF-1K2"
      using xxreal_3_th_38 sorry
    then have "-SUPINF-2K3 (-SUPINF-2K3 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F) <XXREAL-0R3 -SUPINF-2K3 -inftySUPINF-1K2"
      using supinf_2_th_20 sorry
    thus "F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>"
      using xxreal_3_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_23:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> iff -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-aboveSUPINF-2V1\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds (F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> implies -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-aboveSUPINF-2V1\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>) & (-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-aboveSUPINF-2V1\<^bsub>(X,-SUPINF-2K9 Y)\<^esub> implies F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    show "F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> implies -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-aboveSUPINF-2V1\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
    proof(rule impI)
      assume "F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>"
      then have "-SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <XXREAL-0R3 -SUPINF-2K3 -inftySUPINF-1K2"
        using xxreal_3_th_38 sorry
      thus "-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-aboveSUPINF-2V1\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
        using supinf_2_th_20 xxreal_3_th_5 sorry
    qed
    assume "-SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be bounded-aboveSUPINF-2V1\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
    then have "-SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <XXREAL-0R3 +inftySUPINF-1K1"
      using supinf_2_th_20 sorry
    then have "-SUPINF-2K3 +inftySUPINF-1K1 <XXREAL-0R3 -SUPINF-2K3 (-SUPINF-2K3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F)"
      using xxreal_3_th_38 sorry
    thus "F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>"
      using xxreal_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_24:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds F be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> iff -SUPINF-2K17\<^bsub>(X,Y)\<^esub> F be boundedSUPINF-2V3\<^bsub>(X,-SUPINF-2K9 Y)\<^esub>"
  using supinf_2_th_22 supinf_2_th_23 sorry

mtheorem supinf_2_th_25:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds -inftySUPINF-1K2 <=XXREAL-3R1 F .SUPINF-2K15 x & F .SUPINF-2K15 x <=XXREAL-3R1 +inftySUPINF-1K1"
  using xxreal_0_th_4 xxreal_0_th_5 sorry

mtheorem supinf_2_th_26:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds Y c=MEMBEREDR2 REALNUMBERSK2 implies -inftySUPINF-1K2 <XXREAL-0R3 F .SUPINF-2K15 x & F .SUPINF-2K15 x <XXREAL-0R3 +inftySUPINF-1K1"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds Y c=MEMBEREDR2 REALNUMBERSK2 implies  not -inftySUPINF-1K2 <XXREAL-0R3 F .SUPINF-2K15 x &  not F .SUPINF-2K15 x <XXREAL-0R3 +inftySUPINF-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have A1: "-inftySUPINF-1K2 <=XXREAL-3R1 F .SUPINF-2K15 x"
      using xxreal_0_th_5 sorry
    assume "Y c=MEMBEREDR2 REALNUMBERSK2"
    thus " not -inftySUPINF-1K2 <XXREAL-0R3 F .SUPINF-2K15 x &  not F .SUPINF-2K15 x <XXREAL-0R3 +inftySUPINF-1K1"
      using A1 xxreal_0_th_1 xxreal_0_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_27:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <=XXREAL-3R1 F .SUPINF-2K15 x & F .SUPINF-2K15 x <=XXREAL-3R1 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
  have "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> F"
    using funct_2_def_1 sorry
  then have "F .SUPINF-2K15 x inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
    using funct_1_def_3 sorry
  thus "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F <=XXREAL-3R1 F .SUPINF-2K15 x & F .SUPINF-2K15 x <=XXREAL-3R1 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F"
    using xxreal_2_th_3 xxreal_2_th_4 sorry
qed "sorry"

mtheorem supinf_2_th_28:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> iff supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> implies supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2) & (supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2 implies F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "Y c=MEMBEREDR2 REALNUMBERSK2"
    show "F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> implies supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2"
    proof(rule impI)
      let ?x = "the ElementSUBSET-1M1-of X"
      have "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> F"
        using funct_2_def_1 sorry
      then have A2: "F .SUPINF-2K15 ?x inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
        using funct_1_def_3 sorry
      have "rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F c=MEMBEREDR2 Y"
        using relat_1_def_19 sorry
      then have "F .SUPINF-2K15 ?x inTARSKIR2 Y"
        using A2 sorry
      then have A3: " not supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F =XBOOLE-0R4 -inftySUPINF-1K2"
        using A1 supinf_2_th_27 xxreal_0_th_12 sorry
      assume a4: "F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>"
      have "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2 or supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 {TARSKIK2 -inftySUPINF-1K2,+inftySUPINF-1K1 }"
        using xboole_0_def_3 sorry
      thus "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2"
        using a4 A3 tarski_def_2 sorry
    qed
    assume "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2"
    thus "F be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>"
      using xxreal_0_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_29:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> iff infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> implies infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2) & (infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2 implies F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "Y c=MEMBEREDR2 REALNUMBERSK2"
    show "F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> implies infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2"
    proof(rule impI)
      let ?x = "the ElementSUBSET-1M1-of X"
      have "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> F"
        using funct_2_def_1 sorry
      then have A2: "F .SUPINF-2K15 ?x inTARSKIR2 rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F"
        using funct_1_def_3 sorry
      have "rngSUPINF-2K12\<^bsub>(X,Y)\<^esub> F c=MEMBEREDR2 Y"
        using relat_1_def_19 sorry
      then have "F .SUPINF-2K15 ?x inTARSKIR2 Y"
        using A2 sorry
      then have A3: " not infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F =XBOOLE-0R4 +inftySUPINF-1K1"
        using A1 supinf_2_th_27 xxreal_0_th_9 sorry
      assume a4: "F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>"
      have "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2 or infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 {TARSKIK2 -inftySUPINF-1K2,+inftySUPINF-1K1 }"
        using xboole_0_def_3 sorry
      thus "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2"
        using a4 A3 tarski_def_2 sorry
    qed
    assume "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2"
    thus "F be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>"
      using xxreal_0_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_30:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F be FunctionFUNCT-2M1-of(X,Y) holds Y c=MEMBEREDR2 REALNUMBERSK2 implies (F be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> iff infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2 & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F inTARSKIR2 REALNUMBERSK2)"
  using supinf_2_th_28 supinf_2_th_29 sorry

mtheorem supinf_2_th_31:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F1 be FunctionFUNCT-2M1-of(X,Y) holds  for F2 be FunctionFUNCT-2M1-of(X,Z) holds F1 be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub> & F2 be bounded-aboveSUPINF-2V1\<^bsub>(X,Z)\<^esub> implies F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be bounded-aboveSUPINF-2V1\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix F1 assume [ty]: "F1 be FunctionFUNCT-2M1-of(X,Y)"
  fix F2 assume [ty]: "F2 be FunctionFUNCT-2M1-of(X,Z)"
  assume A1: "F1 be bounded-aboveSUPINF-2V1\<^bsub>(X,Y)\<^esub>"
    and A2: "F2 be bounded-aboveSUPINF-2V1\<^bsub>(X,Z)\<^esub>"
  have A4: "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2 & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2 implies supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 <XXREAL-0R3 +inftySUPINF-1K1"
  proof-
    have "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2 & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2 implies  not supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 <XXREAL-0R3 +inftySUPINF-1K1"
    proof(rule impMI ,rule impI)
      obtain a b where 
        [ty]:"a be R-ealSUPINF-1M1" and aDef:"a = supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1" and
        [ty]:"b be R-ealSUPINF-1M1" and bDef:"b = supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
         sorry
      assume A5: "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2"
        and A6: "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2"
      have 
        [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and
        [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2"
        using A5 A6 sorry
      have "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 =XBOOLE-0R4 a +REAL-1K3 b"
        using xxreal_3_def_2 sorry
      thus " not supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 <XXREAL-0R3 +inftySUPINF-1K1"
        using xxreal_0_th_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  have A7: "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2 & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 =XBOOLE-0R4 -inftySUPINF-1K2 implies supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 <XXREAL-0R3 +inftySUPINF-1K1"
    using xxreal_0_th_7 xxreal_3_def_2 sorry
  have A8: "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 =XBOOLE-0R4 -inftySUPINF-1K2 & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 =XBOOLE-0R4 -inftySUPINF-1K2 implies supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 <XXREAL-0R3 +inftySUPINF-1K1"
    using xxreal_0_th_7 xxreal_3_def_2 sorry
  have A9: "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 =XBOOLE-0R4 -inftySUPINF-1K2 & supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2 implies supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 <XXREAL-0R3 +inftySUPINF-1K1"
    using xxreal_0_th_7 xxreal_3_def_2 sorry
  have "supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) <XXREAL-0R3 +inftySUPINF-1K1"
  proof-
    have " not supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) <XXREAL-0R3 +inftySUPINF-1K1 implies  not  True "
    proof(rule impI)
      assume " not supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) <XXREAL-0R3 +inftySUPINF-1K1"
      then have " not supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) <=XXREAL-3R1 +inftySUPINF-1K1 or supSUPINF-2K13\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) =XBOOLE-0R4 +inftySUPINF-1K1"
        using xxreal_0_th_1 sorry
      thus " not  True "
        using A1 A2 A4 A7 A9 A8 supinf_2_th_17 xxreal_0_th_4 xxreal_3_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  thus "F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be bounded-aboveSUPINF-2V1\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
     sorry
qed "sorry"

mtheorem supinf_2_th_32:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F1 be FunctionFUNCT-2M1-of(X,Y) holds  for F2 be FunctionFUNCT-2M1-of(X,Z) holds F1 be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub> & F2 be bounded-belowSUPINF-2V2\<^bsub>(X,Z)\<^esub> implies F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be bounded-belowSUPINF-2V2\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  fix F1 assume [ty]: "F1 be FunctionFUNCT-2M1-of(X,Y)"
  fix F2 assume [ty]: "F2 be FunctionFUNCT-2M1-of(X,Z)"
  assume A1: "F1 be bounded-belowSUPINF-2V2\<^bsub>(X,Y)\<^esub>"
    and A2: "F2 be bounded-belowSUPINF-2V2\<^bsub>(X,Z)\<^esub>"
  have A4: "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2 & infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2 implies -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
  proof-
    have "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2 & infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2 implies  not -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
    proof(rule impMI ,rule impI)
      obtain a b where 
        [ty]:"a be R-ealSUPINF-1M1" and aDef:"a = infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1" and
        [ty]:"b be R-ealSUPINF-1M1" and bDef:"b = infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
         sorry
      assume A5: "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2"
        and A6: "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2"
      have 
        [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and
        [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2"
        using A5 A6 sorry
      have "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 =XBOOLE-0R4 a +REAL-1K3 b"
        using xxreal_3_def_2 sorry
      thus " not -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
        using xxreal_0_th_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  have A7: "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 inTARSKIR2 REALNUMBERSK2 & infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 =XBOOLE-0R4 +inftySUPINF-1K1 implies -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
    using xxreal_0_th_7 xxreal_3_def_2 sorry
  have A8: "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 =XBOOLE-0R4 +inftySUPINF-1K1 & infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 =XBOOLE-0R4 +inftySUPINF-1K1 implies -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
    using xxreal_0_th_7 xxreal_3_def_2 sorry
  have A9: "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 =XBOOLE-0R4 +inftySUPINF-1K1 & infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2 inTARSKIR2 REALNUMBERSK2 implies -inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y)\<^esub> F1 +SUPINF-2K4 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Z)\<^esub> F2"
    using xxreal_0_th_7 xxreal_3_def_2 sorry
  have "-inftySUPINF-1K2 <XXREAL-0R3 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2)"
  proof-
    have "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) <=XXREAL-3R1 -inftySUPINF-1K2 implies  not  True "
    proof(rule impI)
      assume "infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) <=XXREAL-3R1 -inftySUPINF-1K2"
      then have " not -inftySUPINF-1K2 <=XXREAL-3R1 infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) or infSUPINF-2K14\<^bsub>(ExtREALXXREAL-0K3,X,Y +SUPINF-2K7 Z)\<^esub> (F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2) =XBOOLE-0R4 -inftySUPINF-1K2"
        using xxreal_0_th_1 sorry
      thus " not  True "
        using A1 A2 A4 A7 A9 A8 supinf_2_th_18 xxreal_0_th_6 xxreal_3_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  thus "F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be bounded-belowSUPINF-2V2\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
     sorry
qed "sorry"

mtheorem supinf_2_th_33:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for Z be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for F1 be FunctionFUNCT-2M1-of(X,Y) holds  for F2 be FunctionFUNCT-2M1-of(X,Z) holds F1 be boundedSUPINF-2V3\<^bsub>(X,Y)\<^esub> & F2 be boundedSUPINF-2V3\<^bsub>(X,Z)\<^esub> implies F1 +SUPINF-2K16\<^bsub>(X,Y,Z)\<^esub> F2 be boundedSUPINF-2V3\<^bsub>(X,Y +SUPINF-2K7 Z)\<^esub>"
  using supinf_2_th_32 supinf_2_th_31 sorry

mtheorem supinf_2_th_34:
"((idPARTFUN1K6 NATNUMBERSK1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 & idPARTFUN1K6 NATNUMBERSK1 be one-to-oneFUNCT-1V2) & NATNUMBERSK1 =MEMBEREDR12 rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> (idPARTFUN1K6 NATNUMBERSK1)) & rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> (idPARTFUN1K6 NATNUMBERSK1) be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof-
  have "NATNUMBERSK1 c=MEMBEREDR6 ExtREALXXREAL-0K3"
    using numbers_th_19 numbers_th_31 sorry
  then obtain F where 
    [ty]:"F be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and FDef:"F = idPARTFUN1K6 NATNUMBERSK1"
    using funct_2_th_7 sorry
  have "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F c=MEMBEREDR2 ExtREALXXREAL-0K3"
     sorry
  thus "((idPARTFUN1K6 NATNUMBERSK1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 & idPARTFUN1K6 NATNUMBERSK1 be one-to-oneFUNCT-1V2) & NATNUMBERSK1 =MEMBEREDR12 rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> (idPARTFUN1K6 NATNUMBERSK1)) & rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> (idPARTFUN1K6 NATNUMBERSK1) be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
     sorry
qed

syntax SUPINF_2V4 :: " Set \<Rightarrow> Ty" ("countableSUPINF-2V4\<^bsub>'( _ ')\<^esub>" [0]70)
translations "countableSUPINF-2V4\<^bsub>(D)\<^esub>" \<rightharpoonup> "countableCARD-3V4"

mtheorem supinf_2_def_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "IT be SubsetSUBSET-1M2-of D"
"redefine attr countableSUPINF-2V4\<^bsub>(D)\<^esub> for SubsetSUBSET-1M2-of D means
  (\<lambda>IT. IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F))"
proof
(*compatibility*)
  show " for IT be SubsetSUBSET-1M2-of D holds IT be countableSUPINF-2V4\<^bsub>(D)\<^esub> iff IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F)"
  proof(rule ballI)
    fix IT assume [ty]: "IT be SubsetSUBSET-1M2-of D"
    show "IT be countableSUPINF-2V4\<^bsub>(D)\<^esub> iff IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F)"
    proof-
      have "(IT be countableCARD-3V4 implies IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F)) & (IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F) implies IT be countableCARD-3V4)"
      proof(rule conjMI,rule impI)
        show "IT be countableCARD-3V4 implies IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F)"
        proof-
          have "IT be countableCARD-3V4 &  not IT be emptyXBOOLE-0V1 implies ( ex tVar3 be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> tVar3)"
          proof(rule impMI ,rule impI)
            assume A1: "IT be countableCARD-3V4"
              and A2: " not IT be emptyXBOOLE-0V1"
            obtain f where
              [ty]:"f be FunctionFUNCT-1M1" and 
              A3: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A4: "IT c=TARSKIR1 rngFUNCT-1K2 f"
              using A1 card_3_th_93 sorry
            obtain x where
              [ty]:"x be ElementSUBSET-1M1-of D" and 
              A5: "x inTARSKIR2 IT"
              using A2 sorry
            let ?F = "f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
            have A6: "rngFUNCT-1K2 ?F =XBOOLE-0R4 IT & domRELAT-1K1 ?F =XBOOLE-0R4 NATNUMBERSK1"
            proof-
              have "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 IT & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 NATNUMBERSK1"
              proof-
                have A7: "f \<inverse>FUNCT-1K6 IT c=TARSKIR1 NATNUMBERSK1"
                  using A3 relat_1_th_132 sorry
                have A8: "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) =XBOOLE-0R4 NATNUMBERSK1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 IT"
                  using A3 relat_1_th_61 sorry
                show "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 IT & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 NATNUMBERSK1"
                proof-
                  have cases: "NATNUMBERSK1 =XBOOLE-0R4 f \<inverse>FUNCT-1K6 IT or NATNUMBERSK1 <>HIDDENR2 f \<inverse>FUNCT-1K6 IT"
                     sorry
                  have case1: "NATNUMBERSK1 =XBOOLE-0R4 f \<inverse>FUNCT-1K6 IT implies rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 IT & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 NATNUMBERSK1"
                  proof(rule impI,rule conjMI)
                    assume A9: "NATNUMBERSK1 =XBOOLE-0R4 f \<inverse>FUNCT-1K6 IT"
                    then have A10: "NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT =XBOOLE-0R4 {}XBOOLE-0K1"
                      using xboole_1_th_37 sorry
                    then have "domRELSET-1K1\<^bsub>(NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT)\<^esub> (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x) =XBOOLE-0R4 {}XBOOLE-0K1"
                       sorry
                    then have "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT)\<^esub> (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
                       sorry
                    then have "?F =RELAT-1R1 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT \\/XBOOLE-0K2 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
                      using funct_4_th_31 sorry
                    then have "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) \\/XBOOLE-0K2 rngRELSET-1K2\<^bsub>(D)\<^esub> (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
                      using relat_1_th_12 sorry
                    also have "... = rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) \\/XBOOLE-0K2 {}XBOOLE-0K1"
                      using A10 sorry
                    also have "... = f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 IT"
                      using relat_1_th_115 sorry
                    also have "... = IT"
                      using A4 funct_1_th_77 sorry
                    finally show "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 IT"
                       sorry
                    have "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) \\/XBOOLE-0K2 domRELSET-1K1\<^bsub>(NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT)\<^esub> (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
                      using funct_4_def_1 sorry
                    also have "... = domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) \\/XBOOLE-0K2 {}XBOOLE-0K1"
                      using A10 sorry
                    also have "... = NATNUMBERSK1"
                      using A3 A9 sorry
                    finally show "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 NATNUMBERSK1"
                       sorry
                  qed
                  have case2: "NATNUMBERSK1 <>HIDDENR2 f \<inverse>FUNCT-1K6 IT implies rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 IT & domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 NATNUMBERSK1"
                  proof(rule impI,rule conjMI)
                    assume "NATNUMBERSK1 <>HIDDENR2 f \<inverse>FUNCT-1K6 IT"
                    then have A11: "NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT be  non emptyXBOOLE-0V1"
                      using A7 xboole_1_th_37 sorry
                    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT)\<^esub> (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x) =MEMBEREDR12 NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT"
                      using funcop_1_th_13 sorry
                    then have "?F =RELAT-1R1 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT \\/XBOOLE-0K2 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
                      using A8 funct_4_th_31 xboole_1_th_89 sorry
                    then have "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) \\/XBOOLE-0K2 rngRELSET-1K2\<^bsub>(D)\<^esub> (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
                      using relat_1_th_12 sorry
                    also have "... = rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) \\/XBOOLE-0K2 {TARSKIK1 x}"
                      using A11 funcop_1_th_8 sorry
                    also have "... = f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 IT \\/XBOOLE-0K2 {TARSKIK1 x}"
                      using relat_1_th_115 sorry
                    also have "... = IT \\/XBOOLE-0K2 {TARSKIK1 x}"
                      using A4 funct_1_th_77 sorry
                    also have "... = IT"
                      using A5 zfmisc_1_th_40 sorry
                    finally show "rngFUNCT-1K2 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 IT"
                       sorry
                    have "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT) \\/XBOOLE-0K2 domRELSET-1K1\<^bsub>(NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT)\<^esub> (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)"
                      using funct_4_def_1 sorry
                    also have "... = NATNUMBERSK1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 IT \\/XBOOLE-0K2 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT)"
                      using A8 funcop_1_th_13 sorry
                    also have "... = NATNUMBERSK1"
                      using xboole_1_th_51 sorry
                    finally show "domRELAT-1K1 (f  |RELAT-1K8 f \<inverse>FUNCT-1K6 IT +*FUNCT-4K1 (NATNUMBERSK1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 IT -->FUNCOP-1K8\<^bsub>(D)\<^esub> x)) =HIDDENR1 NATNUMBERSK1"
                       sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain F where 
              [ty]:"F be sequenceNAT-1M2-of D" and FDef:"F = ?F"
              using funct_2_def_1 relset_1_th_4 sorry
            show " ex tVar3 be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> tVar3"
            proof(rule bexI[of _ "F"])
              show "IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F"
                using A6 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        assume A12: "IT be emptyXBOOLE-0V1 or ( ex F be sequenceNAT-1M2-of D st IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F)"
        show "IT be countableCARD-3V4"
        proof-
          have cases: "IT be emptyXBOOLE-0V1 or  not IT be emptyXBOOLE-0V1"
             sorry
          have case1: "IT be emptyXBOOLE-0V1 implies IT be countableCARD-3V4"
          proof(rule impI)
            assume "IT be emptyXBOOLE-0V1"
            thus "IT be countableCARD-3V4"
              using card_4_th_1 sorry
          qed
          have case2: " not IT be emptyXBOOLE-0V1 implies IT be countableCARD-3V4"
          proof(rule impI)
            assume " not IT be emptyXBOOLE-0V1"
            then obtain F where
              [ty]:"F be sequenceNAT-1M2-of D" and 
              A13: "IT =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(D)\<^esub> F"
              using A12 sorry
            have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =MEMBEREDR12 NATNUMBERSK1"
              using funct_2_def_1 sorry
            thus "IT be countableCARD-3V4"
              using A13 card_3_th_93 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem supinf_2_cl_3:
"cluster countableCARD-3V4 for  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*existence*)
  show " ex it be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st it be countableCARD-3V4"
  proof-
    have " ex tVar4 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st tVar4 be countableCARD-3V4"
    proof-
      let ?F = "the sequenceNAT-1M2-of ExtREALXXREAL-0K3"
      obtain A where 
        [ty]:"A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3" and ADef:"A = rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> ?F"
         sorry
      show " ex tVar4 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st tVar4 be countableCARD-3V4"
      proof(rule bexI[of _ "A"])
        have "A be  non emptyXBOOLE-0V1 implies  not ( for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  not A =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F)"
        proof(rule impI)
          assume "A be  non emptyXBOOLE-0V1"
          show " not ( for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  not A =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F)"
             sorry
        qed
        thus "A be countableCARD-3V4"
          using supinf_2_def_8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef supinf_2_def_9 ("nonnegativeSUPINF-2V5" 70 ) where
"attr nonnegativeSUPINF-2V5 for setHIDDENM2 means
  (\<lambda>IT.  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 IT implies 0.SUPINF-2K2 <=XXREAL-3R1 x)"..

mtheorem supinf_2_cl_4:
"cluster nonnegativeSUPINF-2V5 for countableCARD-3V4\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*existence*)
  show " ex it be countableCARD-3V4\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st it be nonnegativeSUPINF-2V5"
  proof-
    have " ex tVar5 be countableCARD-3V4\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st tVar5 be nonnegativeSUPINF-2V5"
    proof-
      obtain N where 
        [ty]:"N be countableCARD-3V4\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3" and NDef:"N = NATNUMBERSK1"
        using supinf_2_def_8 supinf_2_th_34 sorry
      show " ex tVar5 be countableCARD-3V4\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 st tVar5 be nonnegativeSUPINF-2V5"
      proof(rule bexI[of _ "N"])
        have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 N implies 0.SUPINF-2K2 <=XXREAL-3R1 x"
        proof-
          show " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 N implies 0.SUPINF-2K2 <=XXREAL-3R1 x"
             sorry
        qed
        thus "N be nonnegativeSUPINF-2V5"
          using supinf_2_def_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CD*)
abbreviation(input) SUPINF_2K18("rngSUPINF-2K18  _ " [228]228) where
  "rngSUPINF-2K18 F \<equiv> rngRELAT-1K2 F"

mtheorem supinf_2_add_11:
  mlet "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
"cluster rngRELAT-1K2 F as-term-is  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
proof
(*coherence*)
  show "rngRELAT-1K2 F be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
  proof-
    have "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F c=MEMBEREDR2 ExtREALXXREAL-0K3"
       sorry
    thus "rngRELAT-1K2 F be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
       sorry
  qed
qed "sorry"

mdef supinf_2_def_11 ("SerSUPINF-2K19  _ " [300]300 ) where
  mlet "N be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
"func SerSUPINF-2K19 N \<rightarrow> sequenceNAT-1M2-of ExtREALXXREAL-0K3 means
  \<lambda>it. it .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it .SUPINF-2K15 n implies it .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st it .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it .SUPINF-2K15 n implies it .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have " ex tVar7 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st tVar7 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds  not (y =XBOOLE-0R4 tVar7 .SUPINF-2K15 n &  not tVar7 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)))"
      proof-
        let ?D = "rngSUPINF-2K18 N"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for s be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s =XBOOLE-0R4 Lamb1 & a =XBOOLE-0R4 Lamb2) & b =XBOOLE-0R4 Lamb3 implies b =XBOOLE-0R4 a +SUPINF-2K4 N .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M)"
        obtain A where 
          [ty]:"A be R-ealSUPINF-1M1" and ADef:"A = N .SUPINF-2K15 (0NUMBERSK6)"
           sorry
        have A1: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds  ex y be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st ?P(n,x,y)"
        proof-
          have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds  ex tVar6 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st  for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for s be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s =XBOOLE-0R4 n & a =XBOOLE-0R4 x) & b =XBOOLE-0R4 tVar6 implies b =XBOOLE-0R4 a +SUPINF-2K4 N .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            fix x assume [ty]: "x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
            obtain y where 
              [ty]:"y be R-ealSUPINF-1M1" and yDef:"y = x +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
               sorry
            show " ex tVar6 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st  for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for s be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s =XBOOLE-0R4 n & a =XBOOLE-0R4 x) & b =XBOOLE-0R4 tVar6 implies b =XBOOLE-0R4 a +SUPINF-2K4 N .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M)"
            proof(rule bexI[of _ "y"])
              show " for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for s be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s =XBOOLE-0R4 n & a =XBOOLE-0R4 x) & b =XBOOLE-0R4 y implies b =XBOOLE-0R4 a +SUPINF-2K4 N .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M)"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain F where
          [ty]:"F be sequenceNAT-1M2-of ExtREALXXREAL-0K3" and 
          A2: "F .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 A & ( for n be NatNAT-1M1 holds ?P(n,F .SUPINF-2K15 n,F .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)))"
          using recdef_1_sch_2 A1 sorry
        show " ex tVar7 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 st tVar7 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds  not (y =XBOOLE-0R4 tVar7 .SUPINF-2K15 n &  not tVar7 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)))"
        proof(rule bexI[of _ "F"],rule conjMI,rule ballI)
          show "F .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6)"
            using A2 sorry
          fix n assume [ty]: "n be NatNAT-1M1"
          have 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "?P(n,F .SUPINF-2K15 n,F .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))"
            using A2 sorry
          thus " for y be R-ealSUPINF-1M1 holds  not (y =XBOOLE-0R4 F .SUPINF-2K15 n &  not F .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for it2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds (it1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it1 .SUPINF-2K15 n implies it1 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))) & (it2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 it2 .SUPINF-2K15 n implies it2 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
    proof-
      have " for S1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for S2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds S1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & (( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 S1 .SUPINF-2K15 n implies S1 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)) & (S2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6) & ( for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 S2 .SUPINF-2K15 n implies S2 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)))) implies S1 =HIDDENR1 S2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix S1 assume [ty]: "S1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
        fix S2 assume [ty]: "S2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
        assume A3: "S1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6)"
          and A4: " for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 S1 .SUPINF-2K15 n implies S1 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
          and A5: "S2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 N .SUPINF-2K15 (0NUMBERSK6)"
          and A6: " for n be NatNAT-1M1 holds  for y be R-ealSUPINF-1M1 holds y =XBOOLE-0R4 S2 .SUPINF-2K15 n implies S2 .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 N .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M)"
        let ?P = "\<lambda>Lamb1. S1 .FUNCT-1K1 Lamb1 =XBOOLE-0R4 S2 .FUNCT-1K1 Lamb1"
        have " for n be objectHIDDENM1 holds n inHIDDENR3 NATNUMBERSK1 implies ?P(n)"
        proof-
          have " for n be objectHIDDENM1 holds n inHIDDENR3 NATNUMBERSK1 implies S1 .FUNCT-1K1 n =XBOOLE-0R4 S2 .FUNCT-1K1 n"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be objectHIDDENM1"
            assume A7: "n inHIDDENR3 NATNUMBERSK1"
            then have 
              [ty]:"n be ElementSUBSET-1M1-of REALNUMBERSK2"
              using numbers_th_19 sorry
            have 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A7 sorry
            have A8: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have " for k be NatNAT-1M1 holds S1 .SUPINF-2K15 k =XBOOLE-0R4 S2 .SUPINF-2K15 k implies S1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 S2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
              proof(rule ballI,rule impI)
                fix k assume [ty]: "k be NatNAT-1M1"
                obtain y2 where 
                  [ty]:"y2 be R-ealSUPINF-1M1" and y2Def:"y2 = S2 .SUPINF-2K15 k"
                   sorry
                assume "S1 .SUPINF-2K15 k =XBOOLE-0R4 S2 .SUPINF-2K15 k"
                then have "S1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 y2 +SUPINF-2K4 N .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A4 sorry
                also have "... = S2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
                  using A6 sorry
                finally show "S1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 S2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have A9: "?P(0NUMBERSK6)"
              using A3 A5 sorry
            have " for k be NatNAT-1M1 holds ?P(k)"
              using nat_1_sch_2 A9 A8 sorry
            then have "S1 .SUPINF-2K15 n =XBOOLE-0R4 S2 .SUPINF-2K15 n"
               sorry
            thus "S1 .FUNCT-1K1 n =XBOOLE-0R4 S2 .FUNCT-1K1 n"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "S1 =HIDDENR1 S2"
          using funct_2_th_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

(*\$CT 4*)
mdef supinf_2_def_12 ("nonnegativeSUPINF-2V6" 70 ) where
"attr nonnegativeSUPINF-2V6 for RelationRELAT-1M1 means
  (\<lambda>R. rngRELAT-1K2 R be nonnegativeSUPINF-2V5)"..

mdef supinf_2_def_13 ("SUMSUPINF-2K20  _ " [164]164 ) where
  mlet "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
"func SUMSUPINF-2K20 F \<rightarrow> R-ealSUPINF-1M1 equals
  supSUPINF-2K11 (rngSUPINF-2K18 SerSUPINF-2K19 F)"
proof-
  (*coherence*)
    show "supSUPINF-2K11 (rngSUPINF-2K18 SerSUPINF-2K19 F) be R-ealSUPINF-1M1"
       sorry
qed "sorry"

mtheorem supinf_2_th_39:
" for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds F be nonnegativeSUPINF-2V6 iff ( for n be ElementSUBSET-1M1-of X holds 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n)"
proof-
  have " for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds (F be nonnegativeSUPINF-2V6 implies ( for n be ElementSUBSET-1M1-of X holds 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n)) & (( for n be ElementSUBSET-1M1-of X holds 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n) implies F be nonnegativeSUPINF-2V6)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3)"
    show "F be nonnegativeSUPINF-2V6 implies ( for n be ElementSUBSET-1M1-of X holds 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n)"
    proof(rule impI,rule ballI)
      assume "F be nonnegativeSUPINF-2V6"
      then have A1: "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F be nonnegativeSUPINF-2V5"
         sorry
      fix n assume [ty]: "n be ElementSUBSET-1M1-of X"
      show "0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n"
      proof-
        have cases: "n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> F or  not n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> F"
           sorry
        have case1: "n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n"
        proof(rule impI)
          assume "n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> F"
          then have "F .SUPINF-2K15 n inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
            using funct_1_def_3 sorry
          thus "0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n"
            using A1 sorry
        qed
        have case2: " not n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n"
        proof(rule impI)
          assume " not n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> F"
          thus "0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n"
            using funct_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    assume A2: " for n be ElementSUBSET-1M1-of X holds 0.SUPINF-2K2 <=XXREAL-3R1 F .SUPINF-2K15 n"
    have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F & y =HIDDENR1 F .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      thus "0.SUPINF-2K2 <=XXREAL-3R1 y"
        using A2 sorry
    qed "sorry"
    thus "F be nonnegativeSUPINF-2V6"
      using supinf_2_def_9 supinf_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_40:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for n be NatNAT-1M1 holds F be nonnegativeSUPINF-2V6 implies SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) & 0.SUPINF-2K2 <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A0: "F be nonnegativeSUPINF-2V6"
  let ?FF = "SerSUPINF-2K19 F"
  let ?P = "\<lambda>Lamb1. ?FF .SUPINF-2K15 Lamb1 <=XXREAL-3R1 ?FF .SUPINF-2K15 (Lamb1 +NAT-1K1 \<one>\<^sub>M) & 0.SUPINF-2K2 <=XXREAL-3R1 ?FF .SUPINF-2K15 Lamb1"
  obtain y where 
    [ty]:"y be R-ealSUPINF-1M1" and yDef:"y = ?FF .SUPINF-2K15 (0NUMBERSK6)"
     sorry
  have A1: "?FF .SUPINF-2K15 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 F .SUPINF-2K15 \<one>\<^sub>M"
    using supinf_2_def_11 sorry
  have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for k be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 k <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) & 0.SUPINF-2K2 <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 k implies SerSUPINF-2K19 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & 0.SUPINF-2K2 <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impMI ,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A3: "?FF .SUPINF-2K15 k <=XXREAL-3R1 ?FF .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
        and A4: "0.SUPINF-2K2 <=XXREAL-3R1 ?FF .SUPINF-2K15 k"
      have "?FF .SUPINF-2K15 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?FF .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) +SUPINF-2K4 F .SUPINF-2K15 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using supinf_2_def_11 sorry
      thus "SerSUPINF-2K19 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) & 0.SUPINF-2K2 <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
        using A3 A4 supinf_2_th_39 A0 xxreal_3_th_39 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "?FF .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 F .SUPINF-2K15 (0NUMBERSK6)"
    using supinf_2_def_11 sorry
  then have A6: "?P(0NUMBERSK6)"
    using A1 xxreal_3_th_39 A0 supinf_2_th_39 sorry
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A6 A2 sorry
  thus "SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +NAT-1K1 \<one>\<^sub>M) & 0.SUPINF-2K2 <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
     sorry
qed "sorry"

mtheorem supinf_2_th_41:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 m))"
proof(rule ballI,rule impI,rule ballI,rule ballI)
  fix F assume [ty]: "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  assume A0: "F be nonnegativeSUPINF-2V6"
  fix n assume [ty]: "n be NatNAT-1M1"
  fix m assume [ty]: "m be NatNAT-1M1"
  let ?P = "\<lambda>Lamb1. SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 Lamb1)"
  have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for k be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 k) implies SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have "SerSUPINF-2K19 F .SUPINF-2K15 (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 SerSUPINF-2K19 F .SUPINF-2K15 ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)"
         sorry
      then have A2: "SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 k) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
        using supinf_2_th_40 A0 sorry
      assume "SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 k)"
      thus "SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))"
        using A2 xxreal_0_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A3: "?P(0NUMBERSK6)"
     sorry
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A3 A1 sorry
  thus "SerSUPINF-2K19 F .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 m)"
     sorry
qed "sorry"

mtheorem supinf_2_th_42:
" for F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n) implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds SerSUPINF-2K19 F1 .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 n)"
proof(rule ballI,rule ballI,rule impI,rule ballI)
  fix F1 assume [ty]: "F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  fix F2 assume [ty]: "F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  let ?P = "\<lambda>Lamb1. SerSUPINF-2K19 F1 .SUPINF-2K15 Lamb1 <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 Lamb1"
  assume A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n"
  fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
  have A3: "SerSUPINF-2K19 F2 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 F2 .SUPINF-2K15 (0NUMBERSK6)"
    using supinf_2_def_11 sorry
  have A5: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for k be NatNAT-1M1 holds SerSUPINF-2K19 F1 .SUPINF-2K15 k <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 k implies SerSUPINF-2K19 F1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A6: "SerSUPINF-2K19 F1 .SUPINF-2K15 k <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 k"
      have A7: "F1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-3R1 F2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
        using A1 sorry
      have A8: "SerSUPINF-2K19 F2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 SerSUPINF-2K19 F2 .SUPINF-2K15 k +SUPINF-2K4 F2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
        using supinf_2_def_11 sorry
      have "SerSUPINF-2K19 F1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 SerSUPINF-2K19 F1 .SUPINF-2K15 k +SUPINF-2K4 F1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
        using supinf_2_def_11 sorry
      thus "SerSUPINF-2K19 F1 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
        using A6 A8 A7 xxreal_3_th_36 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "SerSUPINF-2K19 F1 .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 F1 .SUPINF-2K15 (0NUMBERSK6)"
    using supinf_2_def_11 sorry
  then have A9: "?P(0NUMBERSK6)"
    using A1 A3 sorry
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A9 A5 sorry
  thus "SerSUPINF-2K19 F1 .SUPINF-2K15 n <=XXREAL-3R1 SerSUPINF-2K19 F2 .SUPINF-2K15 n"
     sorry
qed "sorry"

mtheorem supinf_2_th_43:
" for F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n) implies SUMSUPINF-2K20 F1 <=XXREAL-3R1 SUMSUPINF-2K20 F2"
proof(rule ballI,rule ballI,rule impI)
  fix F1 assume [ty]: "F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  fix F2 assume [ty]: "F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  assume A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F1 implies ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F2 & x <=XXREAL-3R1 y)"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F1 implies ( ex tVar8 be ExtRealXXREAL-0M1 st tVar8 inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F2 & x <=XXREAL-3R1 tVar8)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> SerSUPINF-2K19 F1 =MEMBEREDR12 NATNUMBERSK1"
        using funct_2_def_1 sorry
      assume "x inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F1"
      then obtain n where
        [ty]:"n be objectHIDDENM1" and 
        A3: "n inHIDDENR3 NATNUMBERSK1"and A4: "x =HIDDENR1 SerSUPINF-2K19 F1 .FUNCT-1K1 n"
        using A2 funct_1_def_3 sorry
      have 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A3 sorry
      obtain y where 
        [ty]:"y be R-ealSUPINF-1M1" and yDef:"y = SerSUPINF-2K19 F2 .SUPINF-2K15 n"
         sorry
      show " ex tVar8 be ExtRealXXREAL-0M1 st tVar8 inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F2 & x <=XXREAL-3R1 tVar8"
      proof(rule bexI[of _ "y"])
        have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> SerSUPINF-2K19 F2 =MEMBEREDR12 NATNUMBERSK1"
          using funct_2_def_1 sorry
        thus "y inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F2 & x <=XXREAL-3R1 y"
          using A1 A4 supinf_2_th_42 funct_1_def_3 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "SUMSUPINF-2K20 F1 <=XXREAL-3R1 SUMSUPINF-2K20 F2"
    using xxreal_2_th_63 sorry
qed "sorry"

(*\$CT*)
mtheorem supinf_2_th_45:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies (( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st F .SUPINF-2K15 n =XBOOLE-0R4 +inftySUPINF-1K1) implies SUMSUPINF-2K20 F =XBOOLE-0R4 +inftySUPINF-1K1)"
proof(rule ballI,rule impI,rule impI)
  fix F assume [ty]: "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  assume A1: "F be nonnegativeSUPINF-2V6"
  assume Given: " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st F .SUPINF-2K15 n =XBOOLE-0R4 +inftySUPINF-1K1"
  then obtain n where
    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
    A2: "F .SUPINF-2K15 n =XBOOLE-0R4 +inftySUPINF-1K1"
     sorry
  have A3: "( ex k be NatNAT-1M1 st n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M) implies SUMSUPINF-2K20 F =XBOOLE-0R4 +inftySUPINF-1K1"
  proof(rule impI)
    assume Given: " ex k be NatNAT-1M1 st n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: "n =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
       sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    obtain y where 
      [ty]:"y be R-ealSUPINF-1M1" and yDef:"y = SerSUPINF-2K19 F .SUPINF-2K15 k"
       sorry
    obtain x where 
      [ty]:"x be R-ealSUPINF-1M1" and xDef:"x = SerSUPINF-2K19 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A5: "SerSUPINF-2K19 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 F .SUPINF-2K15 (k +NAT-1K1 \<one>\<^sub>M)"
      using supinf_2_def_11 sorry
    have "SerSUPINF-2K19 F .SUPINF-2K15 k <>HIDDENR2 -inftySUPINF-1K2"
      using A1 supinf_2_th_40 xxreal_0_th_6 sorry
    then have A6: "x =XBOOLE-0R4 +inftySUPINF-1K1"
      using A2 A4 A5 xxreal_3_def_2 sorry
    then have "x be UpperBoundXXREAL-2M1-of rngSUPINF-2K18 SerSUPINF-2K19 F"
      using xxreal_2_th_41 sorry
    thus "SUMSUPINF-2K20 F =XBOOLE-0R4 +inftySUPINF-1K1"
      using A6 funct_2_th_4 xxreal_2_th_55 sorry
  qed
  have "n =XBOOLE-0R4 0NUMBERSK6 implies SUMSUPINF-2K20 F =XBOOLE-0R4 +inftySUPINF-1K1"
  proof(rule impI)
    obtain x where 
      [ty]:"x be R-ealSUPINF-1M1" and xDef:"x = SerSUPINF-2K19 F .SUPINF-2K15 (0NUMBERSK6)"
       sorry
    assume "n =XBOOLE-0R4 0NUMBERSK6"
    then have A7: "SerSUPINF-2K19 F .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 +inftySUPINF-1K1"
      using A2 supinf_2_def_11 sorry
    then have "x be UpperBoundXXREAL-2M1-of rngSUPINF-2K18 SerSUPINF-2K19 F"
      using xxreal_2_th_41 sorry
    thus "SUMSUPINF-2K20 F =XBOOLE-0R4 +inftySUPINF-1K1"
      using A7 funct_2_th_4 xxreal_2_th_55 sorry
  qed
  thus "SUMSUPINF-2K20 F =XBOOLE-0R4 +inftySUPINF-1K1"
    using A3 nat_1_th_6 sorry
qed "sorry"

mdef supinf_2_def_14 ("summableSUPINF-2V7" 70 ) where
"attr summableSUPINF-2V7 for sequenceNAT-1M2-of ExtREALXXREAL-0K3 means
  (\<lambda>F. SUMSUPINF-2K20 F inTARSKIR2 REALNUMBERSK2)"..

mtheorem supinf_2_th_46:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies (( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st F .SUPINF-2K15 n =XBOOLE-0R4 +inftySUPINF-1K1) implies  not F be summableSUPINF-2V7)"
  using supinf_2_th_45 sorry

mtheorem supinf_2_th_47:
" for F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F1 be nonnegativeSUPINF-2V6 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n) implies (F2 be summableSUPINF-2V7 implies F1 be summableSUPINF-2V7)"
proof-
  have " for F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds  for F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F1 be nonnegativeSUPINF-2V6 implies (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n) implies (F2 be summableSUPINF-2V7 implies F1 be summableSUPINF-2V7))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix F1 assume [ty]: "F1 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
    fix F2 assume [ty]: "F2 be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
    assume "F1 be nonnegativeSUPINF-2V6"
    then have A1: "0.SUPINF-2K2 <=XXREAL-3R1 SerSUPINF-2K19 F1 .SUPINF-2K15 (0NUMBERSK6)"
      using supinf_2_th_40 sorry
    have "SerSUPINF-2K19 F1 .SUPINF-2K15 (0NUMBERSK6) <=XXREAL-3R1 supSUPINF-2K11 (rngSUPINF-2K18 SerSUPINF-2K19 F1)"
      using funct_2_th_4 xxreal_2_th_4 sorry
    then have A2: "SUMSUPINF-2K20 F1 <>HIDDENR2 -inftySUPINF-1K2"
      using A1 xxreal_0_th_6 sorry
    assume A3: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F1 .SUPINF-2K15 n <=XXREAL-3R1 F2 .SUPINF-2K15 n"
    assume "F2 be summableSUPINF-2V7"
    then have A4: " not SUMSUPINF-2K20 F1 =XBOOLE-0R4 +inftySUPINF-1K1"
      using A3 supinf_2_th_43 xxreal_0_th_9 sorry
    have "SUMSUPINF-2K20 F1 inTARSKIR2 REALNUMBERSK2 or SUMSUPINF-2K20 F1 inTARSKIR2 {TARSKIK2 -inftySUPINF-1K2,+inftySUPINF-1K1 }"
      using xboole_0_def_3 sorry
    thus "F1 be summableSUPINF-2V7"
      using A4 A2 tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_48:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies ( for n be NatNAT-1M1 holds ( for r be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 r implies F .SUPINF-2K15 r =XBOOLE-0R4 0.SUPINF-2K2) implies SUMSUPINF-2K20 F =XBOOLE-0R4 SerSUPINF-2K19 F .SUPINF-2K15 n)"
proof(rule ballI,rule impI,rule ballI,rule impI)
  fix F assume [ty]: "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
  assume A1: "F be nonnegativeSUPINF-2V6"
  fix n assume [ty]: "n be NatNAT-1M1"
  obtain n9 where 
    [ty]:"n9 be ElementSUBSET-1M1-of NATNUMBERSK1" and n9Def:"n9 = n"
    using ordinal1_def_12 sorry
  assume A2: " for r be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 r implies F .SUPINF-2K15 r =XBOOLE-0R4 0.SUPINF-2K2"
  have A3: " for r be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 r implies SerSUPINF-2K19 F .SUPINF-2K15 r <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
  proof(rule ballI,rule impI)
    let ?P = "\<lambda>Lamb1. SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 Lamb1) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
    fix r assume [ty]: "r be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume "n <=XXREAL-3R1 r"
    then have A4: " ex m be NatNAT-1M1 st r =XBOOLE-0R4 n +XCMPLX-0K2 m"
      using nat_1_th_10 sorry
    have A5: " for s be NatNAT-1M1 holds ?P(s) implies ?P(s +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for s be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 s) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n implies SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 (s +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
      proof(rule ballI,rule impI)
        fix s assume [ty]: "s be NatNAT-1M1"
        obtain s9 where 
          [ty]:"s9 be ElementSUBSET-1M1-of NATNUMBERSK1" and s9Def:"s9 = s"
          using ordinal1_def_12 sorry
        obtain y where 
          [ty]:"y be R-ealSUPINF-1M1" and yDef:"y = SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 s)"
           sorry
        have "n9 +NAT-1K1 (s9 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (n9 +NAT-1K1 s9)+NAT-1K1 \<one>\<^sub>M"
           sorry
        then have A6: "SerSUPINF-2K19 F .SUPINF-2K15 (n9 +NAT-1K1 (s9 +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 y +SUPINF-2K4 F .SUPINF-2K15 (n9 +NAT-1K1 (s9 +NAT-1K1 \<one>\<^sub>M))"
          using supinf_2_def_11 sorry
        have "n +NAT-1K1 0NUMBERSK6 <=XXREAL-3R1 n +NAT-1K1 (s +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_7 sorry
        then have A7: "F .SUPINF-2K15 (n9 +NAT-1K1 (s9 +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 0.SUPINF-2K2"
          using A2 sorry
        assume "SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 s) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
        thus "SerSUPINF-2K19 F .SUPINF-2K15 (n +XCMPLX-0K2 (s +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
          using A6 A7 xxreal_3_th_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: "?P(0NUMBERSK6)"
       sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A8 A5 sorry
    thus "SerSUPINF-2K19 F .SUPINF-2K15 r <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
      using A4 sorry
  qed "sorry"
  have A9: " for r be ElementSUBSET-1M1-of NATNUMBERSK1 holds r <=XXREAL-3R1 n implies SerSUPINF-2K19 F .SUPINF-2K15 r <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
  proof(rule ballI,rule impI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume "r <=XXREAL-3R1 n"
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A10: "n =XBOOLE-0R4 r +XCMPLX-0K2 m"
      using nat_1_th_10 sorry
    have 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    show "SerSUPINF-2K19 F .SUPINF-2K15 r <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
      using A1 supinf_2_th_41 A10 sorry
  qed "sorry"
  have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F implies y <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have A11: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> SerSUPINF-2K19 F =MEMBEREDR12 NATNUMBERSK1"
      using funct_2_def_1 sorry
    assume "y inHIDDENR3 rngSUPINF-2K18 SerSUPINF-2K19 F"
    then obtain m where
      [ty]:"m be objectHIDDENM1" and 
      A12: "m inHIDDENR3 NATNUMBERSK1"and A13: "y =HIDDENR1 SerSUPINF-2K19 F .FUNCT-1K1 m"
      using A11 funct_1_def_3 sorry
    have 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A12 sorry
    have "m <=XXREAL-3R1 n or n <=XXREAL-3R1 m"
       sorry
    thus "y <=XXREAL-3R1 SerSUPINF-2K19 F .SUPINF-2K15 n"
      using A3 A9 A13 sorry
  qed "sorry"
  then have A14: "SerSUPINF-2K19 F .SUPINF-2K15 n be UpperBoundXXREAL-2M1-of rngSUPINF-2K18 SerSUPINF-2K19 F"
    using xxreal_2_def_1 sorry
  have "SerSUPINF-2K19 F .SUPINF-2K15 n9 inTARSKIR2 rngSUPINF-2K18 SerSUPINF-2K19 F"
    using funct_2_th_4 sorry
  thus "SUMSUPINF-2K20 F =XBOOLE-0R4 SerSUPINF-2K19 F .SUPINF-2K15 n"
    using A14 xxreal_2_th_55 sorry
qed "sorry"

mtheorem supinf_2_th_49:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2) implies ( for n be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2)"
proof-
  have " for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2) implies ( for s be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2)"
  proof(rule ballI,rule impI)
    fix F assume [ty]: "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
    let ?P = "\<lambda>Lamb1. SerSUPINF-2K19 F .SUPINF-2K15 Lamb1 inTARSKIR2 REALNUMBERSK2"
    assume A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2"
    have A2: " for s be NatNAT-1M1 holds ?P(s) implies ?P(s +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for s be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2 implies SerSUPINF-2K19 F .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 REALNUMBERSK2"
      proof(rule ballI,rule impI)
        fix s assume [ty]: "s be NatNAT-1M1"
        obtain b where 
          [ty]:"b be ElementSUBSET-1M1-of REALNUMBERSK2" and bDef:"b = F .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        obtain y where 
          [ty]:"y be R-ealSUPINF-1M1" and yDef:"y = SerSUPINF-2K19 F .SUPINF-2K15 s"
           sorry
        assume "SerSUPINF-2K19 F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
        then obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of REALNUMBERSK2" and aDef:"a = y"
           sorry
        have A3: "y +SUPINF-2K4 F .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a +REAL-1K3 b"
          using xxreal_3_def_2 sorry
        have "SerSUPINF-2K19 F .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 y +SUPINF-2K4 F .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M)"
          using supinf_2_def_11 sorry
        thus "SerSUPINF-2K19 F .SUPINF-2K15 (s +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 REALNUMBERSK2"
          using A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "SerSUPINF-2K19 F .SUPINF-2K15 (0NUMBERSK6) =XBOOLE-0R4 F .SUPINF-2K15 (0NUMBERSK6)"
      using supinf_2_def_11 sorry
    then have A4: "?P(0NUMBERSK6)"
      using A1 sorry
    show " for s be NatNAT-1M1 holds SerSUPINF-2K19 F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
      using nat_1_sch_2 A4 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_50:
" for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 & ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 k implies F .SUPINF-2K15 k =XBOOLE-0R4 0.SUPINF-2K2) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-3R1 n implies F .SUPINF-2K15 k <>HIDDENR2 +inftySUPINF-1K1)) implies F be summableSUPINF-2V7"
proof-
  have " for F be sequenceNAT-1M2-of ExtREALXXREAL-0K3 holds F be nonnegativeSUPINF-2V6 implies (( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 k implies F .SUPINF-2K15 k =XBOOLE-0R4 0.SUPINF-2K2) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-3R1 n implies F .SUPINF-2K15 k <>HIDDENR2 +inftySUPINF-1K1)) implies F be summableSUPINF-2V7)"
  proof(rule ballI,rule impI,rule impI)
    fix F assume [ty]: "F be sequenceNAT-1M2-of ExtREALXXREAL-0K3"
    assume A1: "F be nonnegativeSUPINF-2V6"
    assume Given: " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 k implies F .SUPINF-2K15 k =XBOOLE-0R4 0.SUPINF-2K2) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-3R1 n implies F .SUPINF-2K15 k <>HIDDENR2 +inftySUPINF-1K1)"
    then obtain n where
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A2: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-3R1 k implies F .SUPINF-2K15 k =XBOOLE-0R4 0.SUPINF-2K2"and A3: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-3R1 n implies F .SUPINF-2K15 k <>HIDDENR2 +inftySUPINF-1K1"
       sorry
    have " for s be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
    proof(rule ballI)
      fix s assume [ty]: "s be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A4: "s <=XXREAL-3R1 n implies F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
      proof(rule impI)
        have A5: "F .SUPINF-2K15 s <>HIDDENR2 -inftySUPINF-1K2"
          using xxreal_0_th_6 A1 supinf_2_th_39 sorry
        assume "s <=XXREAL-3R1 n"
        then have A6: " not F .SUPINF-2K15 s =XBOOLE-0R4 +inftySUPINF-1K1"
          using A3 sorry
        have "F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2 or F .SUPINF-2K15 s inTARSKIR2 {TARSKIK2 -inftySUPINF-1K2,+inftySUPINF-1K1 }"
          using xboole_0_def_3 sorry
        thus "F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
          using A6 A5 tarski_def_2 sorry
      qed
      have "n <=XXREAL-3R1 s implies F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
      proof(rule impI)
        assume "n <=XXREAL-3R1 s"
        then have "F .SUPINF-2K15 s =XBOOLE-0R4 0.SUPINF-2K2"
          using A2 sorry
        thus "F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
          using xreal_0_def_1 sorry
      qed
      thus "F .SUPINF-2K15 s inTARSKIR2 REALNUMBERSK2"
        using A4 sorry
    qed "sorry"
    then have "SerSUPINF-2K19 F .SUPINF-2K15 n inTARSKIR2 REALNUMBERSK2"
      using supinf_2_th_49 sorry
    thus "F be summableSUPINF-2V7"
      using A1 A2 supinf_2_th_48 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_51:
" for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds F be nonnegativeSUPINF-2V6 iff ( for n be objectHIDDENM1 holds 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n)"
proof-
  have " for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds (F be nonnegativeSUPINF-2V6 implies ( for n be objectHIDDENM1 holds 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n)) & (( for n be objectHIDDENM1 holds 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n) implies F be nonnegativeSUPINF-2V6)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3)"
    show "F be nonnegativeSUPINF-2V6 implies ( for n be objectHIDDENM1 holds 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n)"
    proof(rule impI,rule ballI)
      assume "F be nonnegativeSUPINF-2V6"
      then have A1: "rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F be nonnegativeSUPINF-2V5"
         sorry
      fix n assume [ty]: "n be objectHIDDENM1"
      show "0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n"
      proof-
        have cases: "n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F or  not n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F"
           sorry
        have case1: "n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n"
        proof(rule impI)
          assume "n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F"
          then have "F .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
            using funct_1_def_3 sorry
          thus "0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n"
            using A1 sorry
        qed
        have case2: " not n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n"
        proof(rule impI)
          assume " not n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F"
          thus "0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n"
            using funct_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    assume A2: " for n be objectHIDDENM1 holds 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n"
    have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F & y =HIDDENR1 F .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      thus "0.SUPINF-2K2 <=XXREAL-3R1 y"
        using A2 sorry
    qed "sorry"
    thus "F be nonnegativeSUPINF-2V6"
      using supinf_2_def_9 supinf_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem supinf_2_th_52:
" for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3) holds ( for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n) implies F be nonnegativeSUPINF-2V6"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(X,ExtREALXXREAL-0K3)"
  assume A1: " for n be objectHIDDENM1 holds n inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 F .FUNCT-1K1 n"
  have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F implies 0.SUPINF-2K2 <=XXREAL-3R1 y"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(ExtREALXXREAL-0K3)\<^esub> F"
    then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> F & y =HIDDENR1 F .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    thus "0.SUPINF-2K2 <=XXREAL-3R1 y"
      using A1 sorry
  qed "sorry"
  thus "F be nonnegativeSUPINF-2V6"
    using supinf_2_def_9 supinf_2_def_12 sorry
qed "sorry"

mdef supinf_2_def_15 ("1.SUPINF-2K21" 164 ) where
"func 1.SUPINF-2K21 \<rightarrow> R-ealSUPINF-1M1 equals
  \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<one>\<^sub>M be R-ealSUPINF-1M1"
      using xxreal_0_def_1 sorry
qed "sorry"

end
