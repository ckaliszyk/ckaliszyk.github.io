theory subset_1
  imports zfmisc_1
begin
(*begin*)
reserve E, X, Y, x, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10 for "setHIDDENM2"
mtheorem subset_1_cl_1:
  mlet "X be setHIDDENM2"
"cluster boolZFMISC-1K1 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "boolZFMISC-1K1 X be  non emptyXBOOLE-0V1"
    using zfmisc_1_def_1 sorry
qed "sorry"

mtheorem subset_1_cl_2:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"cluster {ENUMSET1K1 x1,x2,x3 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K1 x1,x2,x3 } be  non emptyXBOOLE-0V1"
    using enumset1_def_1 sorry
qed "sorry"

mtheorem subset_1_cl_3:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster {ENUMSET1K2 x1,x2,x3,x4 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K2 x1,x2,x3,x4 } be  non emptyXBOOLE-0V1"
    using enumset1_def_2 sorry
qed "sorry"

mtheorem subset_1_cl_4:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"cluster {ENUMSET1K3 x1,x2,x3,x4,x5 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K3 x1,x2,x3,x4,x5 } be  non emptyXBOOLE-0V1"
    using enumset1_def_3 sorry
qed "sorry"

mtheorem subset_1_cl_5:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1"
"cluster {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } be  non emptyXBOOLE-0V1"
    using enumset1_def_4 sorry
qed "sorry"

mtheorem subset_1_cl_6:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1"
"cluster {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } be  non emptyXBOOLE-0V1"
    using enumset1_def_5 sorry
qed "sorry"

mtheorem subset_1_cl_7:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1", "x8 be objectHIDDENM1"
"cluster {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } be  non emptyXBOOLE-0V1"
    using enumset1_def_6 sorry
qed "sorry"

mtheorem subset_1_cl_8:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1", "x8 be objectHIDDENM1", "x9 be objectHIDDENM1"
"cluster {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } be  non emptyXBOOLE-0V1"
    using enumset1_def_7 sorry
qed "sorry"

mtheorem subset_1_cl_9:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1", "x8 be objectHIDDENM1", "x9 be objectHIDDENM1", "x10 be objectHIDDENM1"
"cluster {ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } be  non emptyXBOOLE-0V1"
    using enumset1_def_8 sorry
qed "sorry"

mdef subset_1_def_1 ("ElementSUBSET-1M1-of  _ " [70]70 ) where
  mlet "X be setHIDDENM2"
"mode ElementSUBSET-1M1-of X \<rightarrow> setHIDDENM2 means
  (\<lambda>it. it inTARSKIR2 X if X be  non emptyXBOOLE-0V1 otherwise \<lambda>it. it be emptyXBOOLE-0V1)"
proof-
  (*existence*)
    show "(X be  non emptyXBOOLE-0V1 implies ( ex it be setHIDDENM2 st it inTARSKIR2 X)) & ( not X be  non emptyXBOOLE-0V1 implies ( ex it be setHIDDENM2 st it be emptyXBOOLE-0V1))"
    proof-
      have "(X be  non emptyXBOOLE-0V1 implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X)) &  not (X be emptyXBOOLE-0V1 & ( for VarFor1 be setHIDDENM2 holds  not VarFor1 be emptyXBOOLE-0V1))"
      proof(rule conjMI)
        show "X be  non emptyXBOOLE-0V1 implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 X)"
        proof-
          have "X be  non emptyXBOOLE-0V1 implies ( ex tVar1 be setHIDDENM2 st tVar1 inTARSKIR2 X)"
          proof(rule impI)
            assume "X be  non emptyXBOOLE-0V1"
            then obtain Y where
              [ty]:"Y be objectHIDDENM1" and 
              A1: "Y inHIDDENR3 X"
               sorry
            have 
              [ty]:"Y be setHIDDENM2"
              using tarski_th_1 sorry
            show " ex tVar1 be setHIDDENM2 st tVar1 inTARSKIR2 X"
            proof(rule bexI[of _ "Y"])
              show "Y inTARSKIR2 X"
                using A1 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show " not (X be emptyXBOOLE-0V1 & ( for VarFor1 be setHIDDENM2 holds  not VarFor1 be emptyXBOOLE-0V1))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem SUBSET_1M1sethood:
  mlet "X be setHIDDENM2"
"cluster sethood of ElementSUBSET-1M1-of X"
proof
(*sethood*)
  show " ex cover be setHIDDENM2 st  for it be ElementSUBSET-1M1-of X holds it inHIDDENR3 cover"
  proof-
    have "(X be  non emptyXBOOLE-0V1 implies ( ex cover be setHIDDENM2 st  for it be setHIDDENM2 holds it inTARSKIR2 X implies it inHIDDENR3 cover)) & ( not X be  non emptyXBOOLE-0V1 implies ( ex cover be setHIDDENM2 st  for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it inHIDDENR3 cover))"
    proof-
      have "X be  non emptyXBOOLE-0V1 & ( ex tVar2 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (VarFor1 inTARSKIR2 tVar2 &  not VarFor1 inHIDDENR3 tVar2)) or X be emptyXBOOLE-0V1 & (X be emptyXBOOLE-0V1 implies ( ex tVar3 be setHIDDENM2 st  for y be setHIDDENM2 holds  not (y be emptyXBOOLE-0V1 &  not y inHIDDENR3 tVar3)))"
      proof-
        show "X be  non emptyXBOOLE-0V1 & ( ex tVar2 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (VarFor1 inTARSKIR2 tVar2 &  not VarFor1 inHIDDENR3 tVar2)) or X be emptyXBOOLE-0V1 & (X be emptyXBOOLE-0V1 implies ( ex tVar3 be setHIDDENM2 st  for y be setHIDDENM2 holds  not (y be emptyXBOOLE-0V1 &  not y inHIDDENR3 tVar3)))"
        proof-
          have cases: "X be  non emptyXBOOLE-0V1 or X be emptyXBOOLE-0V1"
             sorry
          have case1: "X be  non emptyXBOOLE-0V1 implies ( ex tVar2 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (VarFor1 inTARSKIR2 tVar2 &  not VarFor1 inHIDDENR3 tVar2))"
          proof(rule impI)
            assume "X be  non emptyXBOOLE-0V1"
            show " ex tVar2 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (VarFor1 inTARSKIR2 tVar2 &  not VarFor1 inHIDDENR3 tVar2)"
            proof(rule bexI[of _ "X"])
              show " for VarFor1 be setHIDDENM2 holds  not (VarFor1 inTARSKIR2 X &  not VarFor1 inHIDDENR3 X)"
                 sorry
            qed "sorry"
          qed
          have case2: "X be emptyXBOOLE-0V1 implies ( ex tVar3 be setHIDDENM2 st  for y be setHIDDENM2 holds  not (y be emptyXBOOLE-0V1 &  not y inHIDDENR3 tVar3))"
          proof(rule impI)
            assume "X be emptyXBOOLE-0V1"
            show " ex tVar3 be setHIDDENM2 st  for y be setHIDDENM2 holds  not (y be emptyXBOOLE-0V1 &  not y inHIDDENR3 tVar3)"
            proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"],rule ballI)
              fix y assume [ty]: "y be setHIDDENM2"
              show " not (y be emptyXBOOLE-0V1 &  not y inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 })"
                using tarski_def_1 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using subset_1_def_1 sorry
  qed
qed "sorry"

abbreviation(input) SUBSET_1M2("SubsetSUBSET-1M2-of  _ " [70]70) where
  "SubsetSUBSET-1M2-of X \<equiv> ElementSUBSET-1M1-of boolZFMISC-1K1 X"

mtheorem subset_1_cl_10:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of X"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of X st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be SubsetSUBSET-1M2-of X holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "X inTARSKIR2 boolZFMISC-1K1 X"
        using zfmisc_1_def_1 sorry
      then have "X be SubsetSUBSET-1M2-of X"
        using subset_1_def_1 sorry
      thus " not ( for VarFor1 be SubsetSUBSET-1M2-of X holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem subset_1_cl_11:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K2 X1,X2 :] as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "[:ZFMISC-1K2 X1,X2 :] be  non emptyXBOOLE-0V1"
  proof-
    have " not [:ZFMISC-1K2 X1,X2 :] be emptyXBOOLE-0V1"
    proof-
      obtain x2 where
        [ty]:"x2 be objectHIDDENM1" and 
        A1: "x2 inHIDDENR3 X2"
        using xboole_0_def_1 sorry
      obtain x1 where
        [ty]:"x1 be objectHIDDENM1" and 
        A2: "x1 inHIDDENR3 X1"
        using xboole_0_def_1 sorry
      have "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"
        using A2 A1 zfmisc_1_def_2 sorry
      thus " not [:ZFMISC-1K2 X1,X2 :] be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem subset_1_cl_12:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K3 X1,X2,X3 :] as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "[:ZFMISC-1K3 X1,X2,X3 :] be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem subset_1_cl_13:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K4 X1,X2,X3,X4 :] as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "[:ZFMISC-1K4 X1,X2,X3,X4 :] be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

syntax SUBSET_1M3 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("ElementSUBSET-1M3\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "ElementSUBSET-1M3\<^bsub>(D)\<^esub>-of X" \<rightharpoonup> "ElementSUBSET-1M1-of X"

mtheorem subset_1_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of D"
"cluster note-that ElementSUBSET-1M1-of D for ElementSUBSET-1M1-of X"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of X holds it be ElementSUBSET-1M1-of D"
  proof-
    have " for x be ElementSUBSET-1M1-of X holds x be ElementSUBSET-1M1-of D"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
      have "X inTARSKIR2 boolZFMISC-1K1 D"
        using subset_1_def_1 sorry
      then have A1: "X c=TARSKIR1 D"
        using zfmisc_1_def_1 sorry
      have "x inTARSKIR2 X"
        using subset_1_def_1 sorry
      then have "x inTARSKIR2 D"
        using A1 sorry
      thus "x be ElementSUBSET-1M1-of D"
        using subset_1_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mlemma subset_1_lm_1:
" for E be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of E holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 E"
proof-
  have " for E be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of E holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 E"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of E"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 X"
    have "X inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have "X c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    thus "x inHIDDENR3 E"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_cl_14:
  mlet "E be setHIDDENM2"
"cluster emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of E"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of E st it be emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be SubsetSUBSET-1M2-of E holds  not VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{}XBOOLE-0K1 c=TARSKIR1 E"
         sorry
      then have "{}XBOOLE-0K1 inTARSKIR2 boolZFMISC-1K1 E"
        using zfmisc_1_def_1 sorry
      then have "{}XBOOLE-0K1 be SubsetSUBSET-1M2-of E"
        using subset_1_def_1 sorry
      thus " not ( for VarFor1 be SubsetSUBSET-1M2-of E holds  not VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef subset_1_def_2 ("{}SUBSET-1K1  _ " [228]228 ) where
  mlet "E be setHIDDENM2"
"func {}SUBSET-1K1 E \<rightarrow> SubsetSUBSET-1M2-of E equals
  {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "{}XBOOLE-0K1 be SubsetSUBSET-1M2-of E"
    proof-
      have "{}XBOOLE-0K1 c=TARSKIR1 E"
         sorry
      then have "{}XBOOLE-0K1 inTARSKIR2 boolZFMISC-1K1 E"
        using zfmisc_1_def_1 sorry
      thus "{}XBOOLE-0K1 be SubsetSUBSET-1M2-of E"
        using subset_1_def_1 sorry
    qed
qed "sorry"

mdef subset_1_def_3 ("[#]SUBSET-1K2  _ " [228]228 ) where
  mlet "E be setHIDDENM2"
"func [#]SUBSET-1K2 E \<rightarrow> SubsetSUBSET-1M2-of E equals
  E"
proof-
  (*coherence*)
    show "E be SubsetSUBSET-1M2-of E"
    proof-
      have "E inTARSKIR2 boolZFMISC-1K1 E"
        using zfmisc_1_def_1 sorry
      thus "E be SubsetSUBSET-1M2-of E"
        using subset_1_def_1 sorry
    qed
qed "sorry"

mtheorem subset_1_cl_15:
  mlet "E be setHIDDENM2"
"cluster {}SUBSET-1K1 E as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{}SUBSET-1K1 E be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem subset_1_th_1:
" for X be setHIDDENM2 holds {}XBOOLE-0K1 be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds {}XBOOLE-0K1 be SubsetSUBSET-1M2-of X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "{}SUBSET-1K1 X =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    thus "{}XBOOLE-0K1 be SubsetSUBSET-1M2-of X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve A, B, C for "SubsetSUBSET-1M2-of E"
mtheorem subset_1_th_2:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A implies x inTARSKIR2 B) implies A c=TARSKIR1 B"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A implies x inTARSKIR2 B) implies A c=TARSKIR1 B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume A1: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A implies x inTARSKIR2 B"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 A"
      have 
        [ty]:"x be setHIDDENM2"
        using tarski_th_1 sorry
      have "x inTARSKIR2 E"
        using subset_1_lm_1 A2 sorry
      then have "x be ElementSUBSET-1M1-of E"
        using subset_1_def_1 sorry
      thus "x inHIDDENR3 B"
        using A1 A2 sorry
    qed "sorry"
    thus "A c=TARSKIR1 B"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_3:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B) implies A =XBOOLE-0R4 B"
  using subset_1_th_2 sorry

mtheorem subset_1_th_4:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be ElementSUBSET-1M1-of E st x inTARSKIR2 A)"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be ElementSUBSET-1M1-of E holds  not x inTARSKIR2 A)"
  proof(rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    assume "A <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 A"
      using xboole_0_def_1 sorry
    have 
      [ty]:"x be setHIDDENM2"
      using tarski_th_1 sorry
    have "x inTARSKIR2 E"
      using A1 subset_1_lm_1 sorry
    then have "x be ElementSUBSET-1M1-of E"
      using subset_1_def_1 sorry
    thus " not ( for x be ElementSUBSET-1M1-of E holds  not x inTARSKIR2 A)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef subset_1_def_4 (" _ `SUBSET-1K3\<^bsub>'( _ ')\<^esub>" [250,0]250 ) where
  mlet "E be setHIDDENM2", "A be SubsetSUBSET-1M2-of E"
"func A `SUBSET-1K3\<^bsub>(E)\<^esub> \<rightarrow> SubsetSUBSET-1M2-of E equals
  E \\XBOOLE-0K4 A"
proof-
  (*coherence*)
    show "E \\XBOOLE-0K4 A be SubsetSUBSET-1M2-of E"
    proof-
      have "E \\XBOOLE-0K4 A c=TARSKIR1 E"
        using xboole_1_th_36 sorry
      then have "E \\XBOOLE-0K4 A inTARSKIR2 boolZFMISC-1K1 E"
        using zfmisc_1_def_1 sorry
      thus "E \\XBOOLE-0K4 A be SubsetSUBSET-1M2-of E"
        using subset_1_def_1 sorry
    qed
qed "sorry"

mtheorem SUBSET_1K3_involutiveness:
  mlet "E be setHIDDENM2"
" for A be SubsetSUBSET-1M2-of E holds (A `SUBSET-1K3\<^bsub>(E)\<^esub>)`SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A"
proof-
  have " for it be SubsetSUBSET-1M2-of E holds  for A be SubsetSUBSET-1M2-of E holds it =HIDDENR1 A `SUBSET-1K3\<^bsub>(E)\<^esub> implies A =HIDDENR1 it `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof-
    have " for it be SubsetSUBSET-1M2-of E holds  for A be SubsetSUBSET-1M2-of E holds it =HIDDENR1 E \\XBOOLE-0K4 A implies A =HIDDENR1 E \\XBOOLE-0K4 it"
    proof-
      have " for S be SubsetSUBSET-1M2-of E holds  for T be SubsetSUBSET-1M2-of E holds S =XBOOLE-0R4 E \\XBOOLE-0K4 T implies T =HIDDENR1 E \\XBOOLE-0K4 S"
      proof(rule ballI,rule ballI,rule impI)
        fix S assume [ty]: "S be SubsetSUBSET-1M2-of E"
        fix T assume [ty]: "T be SubsetSUBSET-1M2-of E"
        assume A1: "S =XBOOLE-0R4 E \\XBOOLE-0K4 T"
        have "T inTARSKIR2 boolZFMISC-1K1 E"
          using subset_1_def_1 sorry
        then have "T c=TARSKIR1 E"
          using zfmisc_1_def_1 sorry
        then have "T =HIDDENR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 E /\\XBOOLE-0K3 T"
          using xboole_1_th_28 sorry
        also have "... = (E \\XBOOLE-0K4 E)\\/XBOOLE-0K2 E /\\XBOOLE-0K3 T"
          using xboole_1_th_37 sorry
        also have "... = E \\XBOOLE-0K4 S"
          using A1 xboole_1_th_52 sorry
        finally show "T =HIDDENR1 E \\XBOOLE-0K4 S"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using subset_1_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

syntax SUBSET_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\'/SUBSET-1K4\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B" \<rightharpoonup> "A \\/XBOOLE-0K2 B"

mtheorem subset_1_add_2:
  mlet "E be setHIDDENM2", "A be SubsetSUBSET-1M2-of E", "B be SubsetSUBSET-1M2-of E"
"cluster A \\/XBOOLE-0K2 B as-term-is SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show "A \\/XBOOLE-0K2 B be SubsetSUBSET-1M2-of E"
  proof-
    have "B inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have A2: "B c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    have "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have "A c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    then have "A \\/XBOOLE-0K2 B c=TARSKIR1 E"
      using A2 xboole_1_th_8 sorry
    then have "A \\/XBOOLE-0K2 B inTARSKIR2 boolZFMISC-1K1 E"
      using zfmisc_1_def_1 sorry
    thus "A \\/XBOOLE-0K2 B be SubsetSUBSET-1M2-of E"
      using subset_1_def_1 sorry
  qed
qed "sorry"

syntax SUBSET_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\+'\\SUBSET-1K5\<^bsub>'( _ ')\<^esub>  _ " [130,0,130]130)
translations "A \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> B" \<rightharpoonup> "A \\+\\XBOOLE-0K5 B"

mtheorem subset_1_add_3:
  mlet "E be setHIDDENM2", "A be SubsetSUBSET-1M2-of E", "B be SubsetSUBSET-1M2-of E"
"cluster A \\+\\XBOOLE-0K5 B as-term-is SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show "A \\+\\XBOOLE-0K5 B be SubsetSUBSET-1M2-of E"
  proof-
    have "B inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have "B \\XBOOLE-0K4 A c=TARSKIR1 B & B c=TARSKIR1 E"
      using xboole_1_th_36 zfmisc_1_def_1 sorry
    then have A3: "B \\XBOOLE-0K4 A c=TARSKIR1 E"
       sorry
    have "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have "A \\XBOOLE-0K4 B c=TARSKIR1 A & A c=TARSKIR1 E"
      using xboole_1_th_36 zfmisc_1_def_1 sorry
    then have "A \\XBOOLE-0K4 B c=TARSKIR1 E"
       sorry
    then have "(A \\XBOOLE-0K4 B)\\/XBOOLE-0K2 (B \\XBOOLE-0K4 A) c=TARSKIR1 E"
      using A3 xboole_1_th_8 sorry
    then have "A \\+\\XBOOLE-0K5 B inTARSKIR2 boolZFMISC-1K1 E"
      using zfmisc_1_def_1 sorry
    thus "A \\+\\XBOOLE-0K5 B be SubsetSUBSET-1M2-of E"
      using subset_1_def_1 sorry
  qed
qed "sorry"

abbreviation(input) SUBSET_1K6(" _ '\\SUBSET-1K6  _ " [132,132]132) where
  "X \\SUBSET-1K6 Y \<equiv> X \\XBOOLE-0K4 Y"

mtheorem subset_1_add_4:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster X \\XBOOLE-0K4 Y as-term-is SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show "X \\XBOOLE-0K4 Y be SubsetSUBSET-1M2-of X"
  proof-
    have "X \\XBOOLE-0K4 Y c=TARSKIR1 X"
      using xboole_1_th_36 sorry
    then have "X \\XBOOLE-0K4 Y inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "X \\XBOOLE-0K4 Y be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed
qed "sorry"

syntax SUBSET_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\SUBSET-1K7\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "A \\SUBSET-1K7\<^bsub>(E)\<^esub> X" \<rightharpoonup> "A \\XBOOLE-0K4 X"

mtheorem subset_1_add_5:
  mlet "E be setHIDDENM2", "A be SubsetSUBSET-1M2-of E", "X be setHIDDENM2"
"cluster A \\XBOOLE-0K4 X as-term-is SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show "A \\XBOOLE-0K4 X be SubsetSUBSET-1M2-of E"
  proof-
    have "A \\SUBSET-1K6 X be SubsetSUBSET-1M2-of E"
    proof-
      have "A inTARSKIR2 boolZFMISC-1K1 E"
        using subset_1_def_1 sorry
      then have "A \\SUBSET-1K6 X c=TARSKIR1 A & A c=TARSKIR1 E"
        using xboole_1_th_36 zfmisc_1_def_1 sorry
      then have "A \\SUBSET-1K6 X c=TARSKIR1 E"
         sorry
      then have "A \\SUBSET-1K6 X inTARSKIR2 boolZFMISC-1K1 E"
        using zfmisc_1_def_1 sorry
      thus "A \\SUBSET-1K6 X be SubsetSUBSET-1M2-of E"
        using subset_1_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax SUBSET_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\SUBSET-1K8\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "A /\\SUBSET-1K8\<^bsub>(E)\<^esub> X" \<rightharpoonup> "A /\\XBOOLE-0K3 X"

mtheorem subset_1_add_6:
  mlet "E be setHIDDENM2", "A be SubsetSUBSET-1M2-of E", "X be setHIDDENM2"
"cluster A /\\XBOOLE-0K3 X as-term-is SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show "A /\\XBOOLE-0K3 X be SubsetSUBSET-1M2-of E"
  proof-
    have "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have "A /\\XBOOLE-0K3 X c=TARSKIR1 A & A c=TARSKIR1 E"
      using xboole_1_th_17 zfmisc_1_def_1 sorry
    then have "A /\\XBOOLE-0K3 X c=TARSKIR1 E"
       sorry
    then have "A /\\XBOOLE-0K3 X inTARSKIR2 boolZFMISC-1K1 E"
      using zfmisc_1_def_1 sorry
    thus "A /\\XBOOLE-0K3 X be SubsetSUBSET-1M2-of E"
      using subset_1_def_1 sorry
  qed
qed "sorry"

syntax SUBSET_1K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/'\\SUBSET-1K9\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "X /\\SUBSET-1K9\<^bsub>(E)\<^esub> A" \<rightharpoonup> "X /\\XBOOLE-0K3 A"

mtheorem subset_1_add_7:
  mlet "E be setHIDDENM2", "X be setHIDDENM2", "A be SubsetSUBSET-1M2-of E"
"cluster X /\\XBOOLE-0K3 A as-term-is SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show "X /\\XBOOLE-0K3 A be SubsetSUBSET-1M2-of E"
  proof-
    have "A /\\SUBSET-1K8\<^bsub>(E)\<^esub> X be SubsetSUBSET-1M2-of E"
       sorry
    thus "X /\\XBOOLE-0K3 A be SubsetSUBSET-1M2-of E"
       sorry
  qed
qed "sorry"

mtheorem subset_1_th_5:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B or x inTARSKIR2 C) implies A =XBOOLE-0R4 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B or x inTARSKIR2 C) implies A =XBOOLE-0R4 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix C assume [ty]: "C be SubsetSUBSET-1M2-of E"
    assume A1: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B or x inTARSKIR2 C"
    have Cut344: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A implies x inTARSKIR2 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
      assume "x inTARSKIR2 A"
      then have "x inTARSKIR2 B or x inTARSKIR2 C"
        using A1 sorry
      thus "x inTARSKIR2 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C"
        using xboole_0_def_3 sorry
    qed "sorry"
    have "A c=TARSKIR1 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C & B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
    proof(rule conjMI)
      show "A c=TARSKIR1 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C"
        using subset_1_th_2 Cut344 sorry
      have " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C implies x inTARSKIR2 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
        assume "x inTARSKIR2 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C"
        then have "x inTARSKIR2 B or x inTARSKIR2 C"
          using xboole_0_def_3 sorry
        thus "x inTARSKIR2 A"
          using A1 sorry
      qed "sorry"
      thus "B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
        using subset_1_th_2 sorry
    qed
    thus "A =XBOOLE-0R4 B \\/SUBSET-1K4\<^bsub>(E)\<^esub> C"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_6:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B & x inTARSKIR2 C) implies A =XBOOLE-0R4 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B & x inTARSKIR2 C) implies A =XBOOLE-0R4 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix C assume [ty]: "C be SubsetSUBSET-1M2-of E"
    assume A1: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B & x inTARSKIR2 C"
    have Cut366: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A implies x inTARSKIR2 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
      assume "x inTARSKIR2 A"
      then have "x inTARSKIR2 B & x inTARSKIR2 C"
        using A1 sorry
      thus "x inTARSKIR2 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C"
        using xboole_0_def_4 sorry
    qed "sorry"
    have "A c=TARSKIR1 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C & B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
    proof(rule conjMI)
      show "A c=TARSKIR1 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C"
        using subset_1_th_2 Cut366 sorry
      have " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C implies x inTARSKIR2 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
        assume "x inTARSKIR2 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C"
        then have "x inTARSKIR2 B & x inTARSKIR2 C"
          using xboole_0_def_4 sorry
        thus "x inTARSKIR2 A"
          using A1 sorry
      qed "sorry"
      thus "B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
        using subset_1_th_2 sorry
    qed
    thus "A =XBOOLE-0R4 B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_7:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B &  not x inTARSKIR2 C) implies A =XBOOLE-0R4 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B &  not x inTARSKIR2 C) implies A =XBOOLE-0R4 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix C assume [ty]: "C be SubsetSUBSET-1M2-of E"
    assume A1: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff x inTARSKIR2 B &  not x inTARSKIR2 C"
    have Cut388: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A implies x inTARSKIR2 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
      assume "x inTARSKIR2 A"
      then have "x inTARSKIR2 B &  not x inTARSKIR2 C"
        using A1 sorry
      thus "x inTARSKIR2 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C"
        using xboole_0_def_5 sorry
    qed "sorry"
    have "A c=TARSKIR1 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C & B \\SUBSET-1K7\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
    proof(rule conjMI)
      show "A c=TARSKIR1 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C"
        using subset_1_th_2 Cut388 sorry
      have " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C implies x inTARSKIR2 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
        assume "x inTARSKIR2 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C"
        then have "x inTARSKIR2 B &  not x inTARSKIR2 C"
          using xboole_0_def_5 sorry
        thus "x inTARSKIR2 A"
          using A1 sorry
      qed "sorry"
      thus "B \\SUBSET-1K7\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
        using subset_1_th_2 sorry
    qed
    thus "A =XBOOLE-0R4 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_8:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not (x inTARSKIR2 B iff x inTARSKIR2 C)) implies A =XBOOLE-0R4 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not (x inTARSKIR2 B iff x inTARSKIR2 C)) implies A =XBOOLE-0R4 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix C assume [ty]: "C be SubsetSUBSET-1M2-of E"
    assume A1: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not (x inTARSKIR2 B iff x inTARSKIR2 C)"
    have Cut410: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A implies x inTARSKIR2 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
      assume "x inTARSKIR2 A"
      then have "x inTARSKIR2 B &  not x inTARSKIR2 C or x inTARSKIR2 C &  not x inTARSKIR2 B"
        using A1 sorry
      then have "x inTARSKIR2 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C or x inTARSKIR2 C \\SUBSET-1K7\<^bsub>(E)\<^esub> B"
        using xboole_0_def_5 sorry
      thus "x inTARSKIR2 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C"
        using xboole_0_def_3 sorry
    qed "sorry"
    have "A c=TARSKIR1 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C & B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
    proof(rule conjMI)
      show "A c=TARSKIR1 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C"
        using subset_1_th_2 Cut410 sorry
      have " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C implies x inTARSKIR2 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
        assume "x inTARSKIR2 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C"
        then have "x inTARSKIR2 B \\SUBSET-1K7\<^bsub>(E)\<^esub> C or x inTARSKIR2 C \\SUBSET-1K7\<^bsub>(E)\<^esub> B"
          using xboole_0_def_3 sorry
        then have "x inTARSKIR2 B &  not x inTARSKIR2 C or x inTARSKIR2 C &  not x inTARSKIR2 B"
          using xboole_0_def_5 sorry
        thus "x inTARSKIR2 A"
          using A1 sorry
      qed "sorry"
      thus "B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C c=TARSKIR1 A"
        using subset_1_th_2 sorry
    qed
    thus "A =XBOOLE-0R4 B \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> C"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_9:
" for E be setHIDDENM2 holds [#]SUBSET-1K2 E =XBOOLE-0R4 ({}SUBSET-1K1 E)`SUBSET-1K3\<^bsub>(E)\<^esub>"
   sorry

mtheorem subset_1_th_10:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 [#]SUBSET-1K2 E"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 [#]SUBSET-1K2 E"
  proof(rule ballI,rule ballI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    have "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have "A c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    thus "A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 [#]SUBSET-1K2 E"
      using xboole_1_th_45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_11:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A \\/SUBSET-1K4\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =XBOOLE-0R4 [#]SUBSET-1K2 E"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A \\/SUBSET-1K4\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =XBOOLE-0R4 [#]SUBSET-1K2 E"
  proof(rule ballI,rule ballI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    have "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have "A c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    thus "A \\/SUBSET-1K4\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =XBOOLE-0R4 [#]SUBSET-1K2 E"
      using xboole_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_12:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A c=TARSKIR1 B iff B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds (A c=TARSKIR1 B implies B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>) &  not (B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub> &  not A c=TARSKIR1 B)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    show "A c=TARSKIR1 B implies B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using xboole_1_th_34 sorry
    have A1: "E \\SUBSET-1K6 B `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 (B `SUBSET-1K3\<^bsub>(E)\<^esub>)`SUBSET-1K3\<^bsub>(E)\<^esub>"
       sorry
    also have "... = B"
       sorry
    finally have "E \\SUBSET-1K6 B `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 B"
       sorry
    have "E \\SUBSET-1K6 A `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 (A `SUBSET-1K3\<^bsub>(E)\<^esub>)`SUBSET-1K3\<^bsub>(E)\<^esub>"
       sorry
    also have "... = A"
       sorry
    finally have "E \\SUBSET-1K6 A `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A"
       sorry
    thus " not (B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub> &  not A c=TARSKIR1 B)"
      using A1 xboole_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_13:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A \\SUBSET-1K7\<^bsub>(E)\<^esub> B =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A \\SUBSET-1K7\<^bsub>(E)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    have "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have A1: "A c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    have "A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A /\\SUBSET-1K8\<^bsub>(E)\<^esub> E \\SUBSET-1K7\<^bsub>(E)\<^esub> B"
      using xboole_1_th_49 sorry
    also have "... = A \\SUBSET-1K7\<^bsub>(E)\<^esub> B"
      using A1 xboole_1_th_28 sorry
    finally show "A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A \\SUBSET-1K7\<^bsub>(E)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_14:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 A `SUBSET-1K3\<^bsub>(E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> B"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A `SUBSET-1K3\<^bsub>(E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    have "B inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have A1: "B c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    have "(A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 (E \\SUBSET-1K6 A)\\/SUBSET-1K4\<^bsub>(E)\<^esub> E /\\SUBSET-1K9\<^bsub>(E)\<^esub> B"
      using xboole_1_th_52 sorry
    also have "... = A `SUBSET-1K3\<^bsub>(E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> B"
      using A1 xboole_1_th_28 sorry
    finally show "(A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A `SUBSET-1K3\<^bsub>(E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_15:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds (A \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds (A \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    have "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    then have A1: "A c=TARSKIR1 E"
      using zfmisc_1_def_1 sorry
    have "(A \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 (E \\SUBSET-1K6 (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B))\\/SUBSET-1K4\<^bsub>(E)\<^esub> (E /\\SUBSET-1K9\<^bsub>(E)\<^esub> A)/\\SUBSET-1K9\<^bsub>(E)\<^esub> B"
      using xboole_1_th_102 sorry
    also have "... = A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B \\/SUBSET-1K4\<^bsub>(E)\<^esub> (E \\SUBSET-1K6 (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B))"
      using A1 xboole_1_th_28 sorry
    also have "... = A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using xboole_1_th_53 sorry
    finally show "(A \\+\\SUBSET-1K5\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_16:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies B c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies B c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
    then have "(B `SUBSET-1K3\<^bsub>(E)\<^esub>)`SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using subset_1_th_12 sorry
    thus "B c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_17:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 B implies B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 B implies B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume "A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 B"
    then have "B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 (A `SUBSET-1K3\<^bsub>(E)\<^esub>)`SUBSET-1K3\<^bsub>(E)\<^esub>"
      using subset_1_th_12 sorry
    thus "B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_18:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub> iff A =XBOOLE-0R4 {}SUBSET-1K1 E"
  using xboole_1_th_38 sorry

mtheorem subset_1_th_19:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A iff A =XBOOLE-0R4 [#]SUBSET-1K2 E"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds (A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A implies A =XBOOLE-0R4 [#]SUBSET-1K2 E) &  not (A =XBOOLE-0R4 [#]SUBSET-1K2 E &  not A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    show "A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A implies A =XBOOLE-0R4 [#]SUBSET-1K2 E"
    proof-
      have "A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A implies A =HIDDENR1 [#]SUBSET-1K2 E"
      proof(rule impI)
        assume "A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
        then have "A =HIDDENR1 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>"
          using xboole_1_th_12 sorry
        also have "... = [#]SUBSET-1K2 E"
          using subset_1_th_10 sorry
        finally show "A =HIDDENR1 [#]SUBSET-1K2 E"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not (A =XBOOLE-0R4 [#]SUBSET-1K2 E &  not A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A)"
      using xboole_1_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_20:
" for E be setHIDDENM2 holds  for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds X c=TARSKIR1 A & X c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub> implies X =XBOOLE-0R4 {}XBOOLE-0K1"
  using xboole_1_th_67 xboole_1_th_79 sorry

mtheorem subset_1_th_21:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
  using subset_1_th_12 xboole_1_th_7 sorry

mtheorem subset_1_th_22:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)`SUBSET-1K3\<^bsub>(E)\<^esub>"
  using subset_1_th_12 xboole_1_th_17 sorry

mtheorem subset_1_th_23:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A missesXBOOLE-0R1 B iff A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds (A missesXBOOLE-0R1 B implies A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>) & (A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies (A meetsXBOOLE-0R5 B implies  not  True ))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    show "A missesXBOOLE-0R1 B implies A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
    proof(rule impI)
      assume A1: "A missesXBOOLE-0R1 B"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 A"
        then have A3: " not x inHIDDENR3 B"
          using A1 xboole_0_th_3 sorry
        have "x inHIDDENR3 E"
          using A2 subset_1_lm_1 sorry
        thus "x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
          using A3 xboole_0_def_5 sorry
      qed "sorry"
      thus "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
        using tarski_def_3 sorry
    qed
    assume A4: "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
    assume "A meetsXBOOLE-0R5 B"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A5: "x inHIDDENR3 A"and A6: "x inHIDDENR3 B"
      using xboole_0_th_3 sorry
    have "x inHIDDENR3 E \\SUBSET-1K6 B"
      using A4 A5 sorry
    thus " not  True "
      using A6 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_24:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub> iff A c=TARSKIR1 B"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  not (A missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub> &  not A c=TARSKIR1 B) &  not (A c=TARSKIR1 B &  not A missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    have "(B `SUBSET-1K3\<^bsub>(E)\<^esub>)`SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 B"
       sorry
    thus " not (A missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub> &  not A c=TARSKIR1 B) &  not (A c=TARSKIR1 B &  not A missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
      using subset_1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_25:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A missesXBOOLE-0R1 B & A `SUBSET-1K3\<^bsub>(E)\<^esub> missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A missesXBOOLE-0R1 B & A `SUBSET-1K3\<^bsub>(E)\<^esub> missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume A1: "A missesXBOOLE-0R1 B"
      and A2: "A `SUBSET-1K3\<^bsub>(E)\<^esub> missesXBOOLE-0R1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
    have A3: "A inTARSKIR2 boolZFMISC-1K1 E"
      using subset_1_def_1 sorry
    have "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub> & B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
    proof(rule conjMI)
      show "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 A"
          then have A5: " not x inHIDDENR3 B"
            using A1 xboole_0_th_3 sorry
          have "A c=TARSKIR1 E"
            using A3 zfmisc_1_def_1 sorry
          then have "x inHIDDENR3 E"
            using A4 sorry
          thus "x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
            using A5 xboole_0_def_5 sorry
        qed "sorry"
        thus "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies x inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A6: "x inHIDDENR3 A `SUBSET-1K3\<^bsub>(E)\<^esub> implies  not x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
          using A2 xboole_0_th_3 sorry
        assume A7: "x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
        then have "x inHIDDENR3 E"
          using xboole_0_def_5 sorry
        thus "x inHIDDENR3 A"
          using A7 A6 xboole_0_def_5 sorry
      qed "sorry"
      thus "B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
        using tarski_def_3 sorry
    qed
    thus "A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_26:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds A c=TARSKIR1 B & C missesXBOOLE-0R1 B implies A c=TARSKIR1 C `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for C be SubsetSUBSET-1M2-of E holds A c=TARSKIR1 B & C missesXBOOLE-0R1 B implies A c=TARSKIR1 C `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix C assume [ty]: "C be SubsetSUBSET-1M2-of E"
    assume "A c=TARSKIR1 B & C missesXBOOLE-0R1 B"
    then have "A missesXBOOLE-0R1 C"
      using xboole_1_th_63 sorry
    thus "A c=TARSKIR1 C `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using subset_1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_27:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for a be ElementSUBSET-1M1-of A holds a inTARSKIR2 B) implies A c=TARSKIR1 B"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for a be ElementSUBSET-1M1-of A holds a inTARSKIR2 B) implies A c=TARSKIR1 B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume A1: " for a be ElementSUBSET-1M1-of A holds a inTARSKIR2 B"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 A implies a inHIDDENR3 B"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A2: "a inHIDDENR3 A"
      have 
        [ty]:"a be setHIDDENM2"
        using tarski_th_1 sorry
      have "a be ElementSUBSET-1M1-of A"
        using subset_1_def_1 A2 sorry
      thus "a inHIDDENR3 B"
        using A1 sorry
    qed "sorry"
    thus "A c=TARSKIR1 B"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_28:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A) implies E =XBOOLE-0R4 A"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A) implies E =XBOOLE-0R4 A"
  proof(rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    assume A1: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A"
    have "E c=TARSKIR1 A & A c=TARSKIR1 E"
    proof(rule conjMI)
      show "E c=TARSKIR1 A"
      proof-
        have " for a be objectHIDDENM1 holds a inHIDDENR3 E implies a inHIDDENR3 A"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume A2: "a inHIDDENR3 E"
          have 
            [ty]:"a be setHIDDENM2"
            using tarski_th_1 sorry
          have "a be ElementSUBSET-1M1-of E"
            using subset_1_def_1 A2 sorry
          thus "a inHIDDENR3 A"
            using A1 sorry
        qed "sorry"
        thus "E c=TARSKIR1 A"
          using tarski_def_3 sorry
      qed
      have "A inTARSKIR2 boolZFMISC-1K1 E"
        using subset_1_def_1 sorry
      thus "A c=TARSKIR1 E"
        using zfmisc_1_def_1 sorry
    qed
    thus "E =XBOOLE-0R4 A"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_29:
" for E be setHIDDENM2 holds E <>HIDDENR2 {}XBOOLE-0K1 implies ( for B be SubsetSUBSET-1M2-of E holds  for x be ElementSUBSET-1M1-of E holds  not x inTARSKIR2 B implies x inTARSKIR2 B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
proof-
  have " for E be setHIDDENM2 holds E <>HIDDENR2 {}XBOOLE-0K1 implies ( for B be SubsetSUBSET-1M2-of E holds  for x be ElementSUBSET-1M1-of E holds  not x inTARSKIR2 B implies x inTARSKIR2 B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    assume A1: "E <>HIDDENR2 {}XBOOLE-0K1"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
    assume A2: " not x inTARSKIR2 B"
    have "x inTARSKIR2 E"
      using A1 subset_1_def_1 sorry
    thus "x inTARSKIR2 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using A2 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_30:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not x inTARSKIR2 B) implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not x inTARSKIR2 B) implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume A1: " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not x inTARSKIR2 B"
    have "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub> & B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
    proof(rule conjMI)
      show "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A2: "x inHIDDENR3 A"
          have 
            [ty]:"x be setHIDDENM2"
            using tarski_th_1 sorry
          have "A inTARSKIR2 boolZFMISC-1K1 E"
            using subset_1_def_1 sorry
          then have "A c=TARSKIR1 E"
            using zfmisc_1_def_1 sorry
          then have "x inTARSKIR2 E"
            using A2 sorry
          then have "x be ElementSUBSET-1M1-of E"
            using subset_1_def_1 sorry
          then have A3: " not x inTARSKIR2 B"
            using A1 A2 sorry
          have "x inTARSKIR2 E"
            using A2 subset_1_lm_1 sorry
          thus "x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
            using A3 xboole_0_def_5 sorry
        qed "sorry"
        thus "A c=TARSKIR1 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies x inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
        have 
          [ty]:"x be setHIDDENM2"
          using tarski_th_1 sorry
        have "B `SUBSET-1K3\<^bsub>(E)\<^esub> inTARSKIR2 boolZFMISC-1K1 E"
          using subset_1_def_1 sorry
        then have "B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 E"
          using zfmisc_1_def_1 sorry
        then have "x inTARSKIR2 E"
          using A4 sorry
        then have 
          [ty]:"x be ElementSUBSET-1M1-of E"
          using subset_1_def_1 sorry
        have " not x inTARSKIR2 B"
          using A4 xboole_0_def_5 sorry
        thus "x inHIDDENR3 A"
          using A1 sorry
      qed "sorry"
      thus "B `SUBSET-1K3\<^bsub>(E)\<^esub> c=TARSKIR1 A"
        using tarski_def_3 sorry
    qed
    thus "A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_31:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds  not x inTARSKIR2 A iff x inTARSKIR2 B) implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds  not x inTARSKIR2 A iff x inTARSKIR2 B) implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume " for x be ElementSUBSET-1M1-of E holds  not x inTARSKIR2 A iff x inTARSKIR2 B"
    then have " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not x inTARSKIR2 B"
       sorry
    thus "A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using subset_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_32:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds  not (x inTARSKIR2 A iff x inTARSKIR2 B)) implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds ( for x be ElementSUBSET-1M1-of E holds  not (x inTARSKIR2 A iff x inTARSKIR2 B)) implies A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume " for x be ElementSUBSET-1M1-of E holds  not (x inTARSKIR2 A iff x inTARSKIR2 B)"
    then have " for x be ElementSUBSET-1M1-of E holds x inTARSKIR2 A iff  not x inTARSKIR2 B"
       sorry
    thus "A =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using subset_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x1, x2, x3, x4, x5, x6, x7, x8 for "ElementSUBSET-1M1-of X"
mtheorem subset_1_th_33:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {TARSKIK1 x1} be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {TARSKIK1 x1} be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "x1 inTARSKIR2 X"
      using subset_1_def_1 sorry
    have "{TARSKIK1 x1} c=TARSKIR1 X"
      using A1 tarski_def_1 sorry
    then have "{TARSKIK1 x1} inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{TARSKIK1 x1} be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_34:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {TARSKIK2 x1,x2 } be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {TARSKIK2 x1,x2 } be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then have A1: "x1 inTARSKIR2 X & x2 inTARSKIR2 X"
      using subset_1_def_1 sorry
    have "{TARSKIK2 x1,x2 } c=TARSKIR1 X"
      using A1 tarski_def_2 sorry
    then have "{TARSKIK2 x1,x2 } inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{TARSKIK2 x1,x2 } be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_35:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K1 x1,x2,x3 } be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K1 x1,x2,x3 } be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    fix x3 assume [ty]: "x3 be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "x3 inTARSKIR2 X"
      using subset_1_def_1 sorry
    have A3: "x1 inTARSKIR2 X & x2 inTARSKIR2 X"
      using A1 subset_1_def_1 sorry
    have "{ENUMSET1K1 x1,x2,x3 } c=TARSKIR1 X"
      using A3 A2 enumset1_def_1 sorry
    then have "{ENUMSET1K1 x1,x2,x3 } inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{ENUMSET1K1 x1,x2,x3 } be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_36:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K2 x1,x2,x3,x4 } be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K2 x1,x2,x3,x4 } be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    fix x3 assume [ty]: "x3 be ElementSUBSET-1M1-of X"
    fix x4 assume [ty]: "x4 be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "x3 inTARSKIR2 X & x4 inTARSKIR2 X"
      using subset_1_def_1 sorry
    have A3: "x1 inTARSKIR2 X & x2 inTARSKIR2 X"
      using A1 subset_1_def_1 sorry
    have "{ENUMSET1K2 x1,x2,x3,x4 } c=TARSKIR1 X"
      using A3 A2 enumset1_def_2 sorry
    then have "{ENUMSET1K2 x1,x2,x3,x4 } inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{ENUMSET1K2 x1,x2,x3,x4 } be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_37:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K3 x1,x2,x3,x4,x5 } be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K3 x1,x2,x3,x4,x5 } be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    fix x3 assume [ty]: "x3 be ElementSUBSET-1M1-of X"
    fix x4 assume [ty]: "x4 be ElementSUBSET-1M1-of X"
    fix x5 assume [ty]: "x5 be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "{ENUMSET1K3 x1,x2,x3,x4,x5 } c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 } implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A2: "x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 } implies (((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5"
          using enumset1_def_3 sorry
        assume "x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
        thus "x inHIDDENR3 X"
          using A1 A2 subset_1_def_1 sorry
      qed "sorry"
      thus "{ENUMSET1K3 x1,x2,x3,x4,x5 } c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    then have "{ENUMSET1K3 x1,x2,x3,x4,x5 } inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{ENUMSET1K3 x1,x2,x3,x4,x5 } be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_38:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds  for x6 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds  for x6 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    fix x3 assume [ty]: "x3 be ElementSUBSET-1M1-of X"
    fix x4 assume [ty]: "x4 be ElementSUBSET-1M1-of X"
    fix x5 assume [ty]: "x5 be ElementSUBSET-1M1-of X"
    fix x6 assume [ty]: "x6 be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A2: "x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } implies ((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6"
          using enumset1_def_4 sorry
        assume "x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
        thus "x inHIDDENR3 X"
          using A1 A2 subset_1_def_1 sorry
      qed "sorry"
      thus "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    then have "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_39:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds  for x6 be ElementSUBSET-1M1-of X holds  for x7 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds  for x6 be ElementSUBSET-1M1-of X holds  for x7 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    fix x3 assume [ty]: "x3 be ElementSUBSET-1M1-of X"
    fix x4 assume [ty]: "x4 be ElementSUBSET-1M1-of X"
    fix x5 assume [ty]: "x5 be ElementSUBSET-1M1-of X"
    fix x6 assume [ty]: "x6 be ElementSUBSET-1M1-of X"
    fix x7 assume [ty]: "x7 be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A2: "x inHIDDENR3 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } implies (((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7"
          using enumset1_def_5 sorry
        assume "x inHIDDENR3 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 }"
        thus "x inHIDDENR3 X"
          using A1 A2 subset_1_def_1 sorry
      qed "sorry"
      thus "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    then have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_40:
" for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds  for x6 be ElementSUBSET-1M1-of X holds  for x7 be ElementSUBSET-1M1-of X holds  for x8 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds  for x3 be ElementSUBSET-1M1-of X holds  for x4 be ElementSUBSET-1M1-of X holds  for x5 be ElementSUBSET-1M1-of X holds  for x6 be ElementSUBSET-1M1-of X holds  for x7 be ElementSUBSET-1M1-of X holds  for x8 be ElementSUBSET-1M1-of X holds X <>HIDDENR2 {}XBOOLE-0K1 implies {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    fix x3 assume [ty]: "x3 be ElementSUBSET-1M1-of X"
    fix x4 assume [ty]: "x4 be ElementSUBSET-1M1-of X"
    fix x5 assume [ty]: "x5 be ElementSUBSET-1M1-of X"
    fix x6 assume [ty]: "x6 be ElementSUBSET-1M1-of X"
    fix x7 assume [ty]: "x7 be ElementSUBSET-1M1-of X"
    fix x8 assume [ty]: "x8 be ElementSUBSET-1M1-of X"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A2: "x inHIDDENR3 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } implies ((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8"
          using enumset1_def_6 sorry
        assume "x inHIDDENR3 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 }"
        thus "x inHIDDENR3 X"
          using A1 A2 subset_1_def_1 sorry
      qed "sorry"
      thus "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    then have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_41:
" for X be setHIDDENM2 holds  for x be setHIDDENM2 holds x inTARSKIR2 X implies {TARSKIK1 x} be SubsetSUBSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds  for x be setHIDDENM2 holds x inTARSKIR2 X implies {TARSKIK1 x} be SubsetSUBSET-1M2-of X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    assume "x inTARSKIR2 X"
    then have "{TARSKIK1 x} c=TARSKIR1 X"
      using zfmisc_1_th_31 sorry
    then have "{TARSKIK1 x} inTARSKIR2 boolZFMISC-1K1 X"
      using zfmisc_1_def_1 sorry
    thus "{TARSKIK1 x} be SubsetSUBSET-1M2-of X"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem subset_1_sch_1:
  fixes Af0 Pp1 
  assumes
[ty]: "Af0 be setHIDDENM2"
  shows " ex X be SubsetSUBSET-1M2-of Af0 st  for x be setHIDDENM2 holds x inTARSKIR2 X iff x inTARSKIR2 Af0 & Pp1(x)"
  proof-
    have " ex tVar4 be SubsetSUBSET-1M2-of Af0 st  for x be setHIDDENM2 holds  not (x inTARSKIR2 tVar4 &  not (x inTARSKIR2 Af0 & Pp1(x))) &  not ((x inTARSKIR2 Af0 & Pp1(x)) &  not x inTARSKIR2 tVar4)"
    proof-
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Af0 & Pp1(x)"
        using xboole_0_sch_1 sorry
      have "X c=TARSKIR1 Af0"
        using A1 sorry
      then have "X inTARSKIR2 boolZFMISC-1K1 Af0"
        using zfmisc_1_def_1 sorry
      then have 
        [ty]:"X be SubsetSUBSET-1M2-of Af0"
        using subset_1_def_1 sorry
      show " ex tVar4 be SubsetSUBSET-1M2-of Af0 st  for x be setHIDDENM2 holds  not (x inTARSKIR2 tVar4 &  not (x inTARSKIR2 Af0 & Pp1(x))) &  not ((x inTARSKIR2 Af0 & Pp1(x)) &  not x inTARSKIR2 tVar4)"
      proof(rule bexI[of _ "X"])
        show " for x be setHIDDENM2 holds  not (x inTARSKIR2 X &  not (x inTARSKIR2 Af0 & Pp1(x))) &  not ((x inTARSKIR2 Af0 & Pp1(x)) &  not x inTARSKIR2 X)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem subset_1_sch_2:
  fixes Xf0 X1f0 X2f0 Pp1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "X1f0 be SubsetSUBSET-1M2-of Xf0" and
  [ty]: "X2f0 be SubsetSUBSET-1M2-of Xf0" and
   A1: " for y be ElementSUBSET-1M1-of Xf0 holds y inTARSKIR2 X1f0 iff Pp1(y)" and
   A2: " for y be ElementSUBSET-1M1-of Xf0 holds y inTARSKIR2 X2f0 iff Pp1(y)"
  shows "X1f0 =XBOOLE-0R4 X2f0"
  proof-
    have " for x be ElementSUBSET-1M1-of Xf0 holds x inTARSKIR2 X1f0 iff x inTARSKIR2 X2f0"
      using A1 A2 sorry
    thus "X1f0 =XBOOLE-0R4 X2f0"
      using subset_1_th_2 sorry
  qed

abbreviation(input) SUBSET_1R1(" _ missesSUBSET-1R1  _ " [50,50]50) where
  "X missesSUBSET-1R1 Y \<equiv> X missesXBOOLE-0R1 Y"

mtheorem SUBSET_1R1_irreflexivity:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not Y missesSUBSET-1R1 Y"
   sorry

abbreviation(input) SUBSET_1R2(" _ meetsSUBSET-1R2  _ " [50,50]50) where
  "X meetsSUBSET-1R2 Y \<equiv> X missesXBOOLE-0R1 Y"

mtheorem SUBSET_1R2_reflexivity:
" for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds Y meetsSUBSET-1R2 Y"
   sorry

(*\$CD*)
(*begin*)
mlemma subset_1_lm_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y) implies X be SubsetSUBSET-1M2-of Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y) implies X be SubsetSUBSET-1M2-of Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y"
    then have "X c=TARSKIR1 Y"
       sorry
    then have "X inTARSKIR2 boolZFMISC-1K1 Y"
      using zfmisc_1_def_1 sorry
    thus "X be SubsetSUBSET-1M2-of Y"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma subset_1_lm_3:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for x be objectHIDDENM1 holds x inHIDDENR3 A implies x be ElementSUBSET-1M1-of E"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for x be objectHIDDENM1 holds x inHIDDENR3 A implies x be ElementSUBSET-1M1-of E"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 A"
    have 
      [ty]:"x be setHIDDENM2"
      using tarski_th_1 sorry
    have "x inTARSKIR2 E"
      using subset_1_lm_1 A1 sorry
    thus "x be ElementSUBSET-1M1-of E"
      using subset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem subset_1_sch_3:
  fixes Af0 Pp1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows " ex B be SubsetSUBSET-1M2-of Af0 st  for x be ElementSUBSET-1M1-of Af0 holds x inTARSKIR2 B iff Pp1(x)"
  proof-
    have " ex tVar5 be SubsetSUBSET-1M2-of Af0 st  for x be ElementSUBSET-1M1-of Af0 holds  not (x inTARSKIR2 tVar5 &  not Pp1(x)) &  not (Pp1(x) &  not x inTARSKIR2 tVar5)"
    proof-
      obtain B where
        [ty]:"B be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 B iff x inHIDDENR3 Af0 & Pp1(x)"
        using xboole_0_sch_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 B implies x inHIDDENR3 Af0"
        using A1 sorry
      then have 
        [ty]:"B be SubsetSUBSET-1M2-of Af0"
        using subset_1_lm_2 sorry
      show " ex tVar5 be SubsetSUBSET-1M2-of Af0 st  for x be ElementSUBSET-1M1-of Af0 holds  not (x inTARSKIR2 tVar5 &  not Pp1(x)) &  not (Pp1(x) &  not x inTARSKIR2 tVar5)"
      proof(rule bexI[of _ "B"],rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Af0"
        have "x inTARSKIR2 Af0"
          using subset_1_def_1 sorry
        thus " not (x inTARSKIR2 B &  not Pp1(x)) &  not (Pp1(x) &  not x inTARSKIR2 B)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem subset_1_sch_4:
  fixes Af0 F1f0 F2f0 Pp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "F1f0 be SubsetSUBSET-1M2-of Af0" and
  [ty]: "F2f0 be SubsetSUBSET-1M2-of Af0" and
   A1: " for X be ElementSUBSET-1M1-of Af0 holds X inTARSKIR2 F1f0 iff Pp1(X)" and
   A2: " for X be ElementSUBSET-1M1-of Af0 holds X inTARSKIR2 F2f0 iff Pp1(X)"
  shows "F1f0 =XBOOLE-0R4 F2f0"
  proof-
    have "F1f0 c=TARSKIR1 F2f0 & F2f0 c=TARSKIR1 F1f0"
    proof(rule conjMI)
      show "F1f0 c=TARSKIR1 F2f0"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 F1f0 implies x inHIDDENR3 F2f0"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 F1f0"
          then obtain X where 
            [ty]:"X be ElementSUBSET-1M1-of Af0" and XDef:"X = x"
            using subset_1_lm_3 sorry
          have "Pp1(X)"
            using A1 A3 sorry
          thus "x inHIDDENR3 F2f0"
            using A2 sorry
        qed "sorry"
        thus "F1f0 c=TARSKIR1 F2f0"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F2f0 implies x inHIDDENR3 F1f0"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 F2f0"
        then obtain X where 
          [ty]:"X be ElementSUBSET-1M1-of Af0" and XDef:"X = x"
          using subset_1_lm_3 sorry
        have "Pp1(X)"
          using A2 A4 sorry
        thus "x inHIDDENR3 F1f0"
          using A1 sorry
      qed "sorry"
      thus "F2f0 c=TARSKIR1 F1f0"
        using tarski_def_3 sorry
    qed
    thus "F1f0 =XBOOLE-0R4 F2f0"
      using xboole_0_def_10 sorry
  qed

mtheorem subset_1_th_42:
" for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A `SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies A =XBOOLE-0R4 B"
proof-
  have " for E be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A `SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub> implies A =HIDDENR1 B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    assume "A `SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 B `SUBSET-1K3\<^bsub>(E)\<^esub>"
    then have "A =HIDDENR1 (B `SUBSET-1K3\<^bsub>(E)\<^esub>)`SUBSET-1K3\<^bsub>(E)\<^esub>"
       sorry
    also have "... = B"
       sorry
    finally show "A =HIDDENR1 B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_cl_16:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be emptyXBOOLE-0V1"
  proof-
    have " for Y be SubsetSUBSET-1M2-of X holds Y be emptyXBOOLE-0V1"
    proof(rule ballI)
      fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
      have "Y inTARSKIR2 boolZFMISC-1K1 X"
        using subset_1_def_1 sorry
      then have "Y c=TARSKIR1 X"
        using zfmisc_1_def_1 sorry
      thus "Y be emptyXBOOLE-0V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef subset_1_def_6 ("properSUBSET-1V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "E be setHIDDENM2"
"attr properSUBSET-1V1\<^bsub>(E)\<^esub> for SubsetSUBSET-1M2-of E means
  (\<lambda>A. A <>HIDDENR2 E)"..

mtheorem subset_1_cl_17:
  mlet "E be setHIDDENM2"
"cluster [#]SUBSET-1K2 E as-term-is  non properSUBSET-1V1\<^bsub>(E)\<^esub>"
proof
(*coherence*)
  show "[#]SUBSET-1K2 E be  non properSUBSET-1V1\<^bsub>(E)\<^esub>"
     sorry
qed "sorry"

mtheorem subset_1_cl_18:
  mlet "E be setHIDDENM2"
"cluster  non properSUBSET-1V1\<^bsub>(E)\<^esub> for SubsetSUBSET-1M2-of E"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of E st it be  non properSUBSET-1V1\<^bsub>(E)\<^esub>"
  proof-
    have " ex tVar6 be SubsetSUBSET-1M2-of E st  not tVar6 be properSUBSET-1V1\<^bsub>(E)\<^esub>"
    proof-
      show " ex tVar6 be SubsetSUBSET-1M2-of E st  not tVar6 be properSUBSET-1V1\<^bsub>(E)\<^esub>"
      proof(rule bexI[of _ "[#]SUBSET-1K2 E"])
        show " not [#]SUBSET-1K2 E be properSUBSET-1V1\<^bsub>(E)\<^esub>"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem subset_1_cl_19:
  mlet "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non properSUBSET-1V1\<^bsub>(E)\<^esub> also-is  non emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of E holds it be  non properSUBSET-1V1\<^bsub>(E)\<^esub> implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem subset_1_cl_20:
  mlet "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster emptyXBOOLE-0V1 also-is properSUBSET-1V1\<^bsub>(E)\<^esub> for SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of E holds it be emptyXBOOLE-0V1 implies it be properSUBSET-1V1\<^bsub>(E)\<^esub>"
     sorry
qed "sorry"

mtheorem subset_1_cl_21:
  mlet "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster properSUBSET-1V1\<^bsub>(E)\<^esub> for SubsetSUBSET-1M2-of E"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of E st it be properSUBSET-1V1\<^bsub>(E)\<^esub>"
  proof-
    have " ex tVar7 be SubsetSUBSET-1M2-of E st tVar7 be properSUBSET-1V1\<^bsub>(E)\<^esub>"
    proof-
      show " ex tVar7 be SubsetSUBSET-1M2-of E st tVar7 be properSUBSET-1V1\<^bsub>(E)\<^esub>"
      proof(rule bexI[of _ "{}SUBSET-1K1 E"])
        have "{}SUBSET-1K1 E <>HIDDENR2 E"
        proof-
          show "{}SUBSET-1K1 E <>HIDDENR2 E"
             sorry
        qed
        thus "{}SUBSET-1K1 E be properSUBSET-1V1\<^bsub>(E)\<^esub>"
          using subset_1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem subset_1_cl_22:
  mlet "E be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non properSUBSET-1V1\<^bsub>(E)\<^esub> for SubsetSUBSET-1M2-of E"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of E holds it be  non properSUBSET-1V1\<^bsub>(E)\<^esub>"
     sorry
qed "sorry"

mtheorem subset_1_th_43:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be setHIDDENM2 holds  for z be setHIDDENM2 holds z inTARSKIR2 A & A c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies ( ex x be ElementSUBSET-1M1-of X st  ex y be ElementSUBSET-1M1-of Y st z =HIDDENR1 [TARSKIK4 x,y ])"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for A be setHIDDENM2 holds  for z be setHIDDENM2 holds z inTARSKIR2 A & A c=TARSKIR1 [:ZFMISC-1K2 X,Y :] implies ( ex tVar8 be ElementSUBSET-1M1-of X st  ex tVar9 be ElementSUBSET-1M1-of Y st z =HIDDENR1 [TARSKIK4 tVar8,tVar9 ])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    assume "z inTARSKIR2 A & A c=TARSKIR1 [:ZFMISC-1K2 X,Y :]"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"and A2: "y inHIDDENR3 Y"and A3: "z =HIDDENR1 [TARSKIK4 x,y ]"
      using zfmisc_1_th_84 sorry
    have 
      [ty]:"x be setHIDDENM2" and
      [ty]:"y be setHIDDENM2"
      using tarski_th_1 sorry
    have 
      [ty]:"y be ElementSUBSET-1M1-of Y"
      using A2 subset_1_def_1 sorry
    have 
      [ty]:"x be ElementSUBSET-1M1-of X"
      using A1 subset_1_def_1 sorry
    show " ex tVar8 be ElementSUBSET-1M1-of X st  ex tVar9 be ElementSUBSET-1M1-of Y st z =HIDDENR1 [TARSKIK4 tVar8,tVar9 ]"
    proof(rule bexI[of _ "x"])
      show " ex tVar9 be ElementSUBSET-1M1-of Y st z =HIDDENR1 [TARSKIK4 x,tVar9 ]"
      proof(rule bexI[of _ "y"])
        show "z =HIDDENR1 [TARSKIK4 x,y ]"
          using A3 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_44:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X holds  for B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X holds A c<XBOOLE-0R2 B implies ( ex p be ElementSUBSET-1M1-of X st p inTARSKIR2 B & A c=TARSKIR1 B \\SUBSET-1K7\<^bsub>(X)\<^esub> {TARSKIK1 p})"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X holds  for B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X holds A c<XBOOLE-0R2 B implies ( ex tVar10 be ElementSUBSET-1M1-of X st tVar10 inTARSKIR2 B & A c=TARSKIR1 B \\SUBSET-1K7\<^bsub>(X)\<^esub> {TARSKIK1 tVar10})"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X"
    assume A1: "A c<XBOOLE-0R2 B"
    then obtain p where
      [ty]:"p be ElementSUBSET-1M1-of X" and 
      A2: "p inTARSKIR2 B \\SUBSET-1K7\<^bsub>(X)\<^esub> A"
      using subset_1_th_4 xboole_1_th_105 sorry
    have A3: " not p inTARSKIR2 A"
      using A2 xboole_0_def_5 sorry
    show " ex tVar10 be ElementSUBSET-1M1-of X st tVar10 inTARSKIR2 B & A c=TARSKIR1 B \\SUBSET-1K7\<^bsub>(X)\<^esub> {TARSKIK1 tVar10}"
    proof(rule bexI[of _ "p"])
      show "p inTARSKIR2 B & A c=TARSKIR1 B \\SUBSET-1K7\<^bsub>(X)\<^esub> {TARSKIK1 p}"
        using A1 A2 A3 xboole_0_def_5 zfmisc_1_th_34 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SUBSET_1V2("trivialSUBSET-1V2" 70) where
  "trivialSUBSET-1V2 \<equiv> trivialZFMISC-1V1"

mtheorem subset_1_def_7:
  mlet "X be setHIDDENM2"
"redefine attr trivialSUBSET-1V2 for setHIDDENM2 means
  (\<lambda>X.  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 y)"
proof
(*compatibility*)
  show " for X be setHIDDENM2 holds X be trivialSUBSET-1V2 iff ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 y)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    show "X be trivialSUBSET-1V2 iff ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 y)"
    proof-
      have "(X be trivialZFMISC-1V1 implies ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 y)) & (( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 y) implies X be trivialZFMISC-1V1)"
      proof(rule conjMI,rule impI)
        show "X be trivialZFMISC-1V1 implies ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 y)"
        proof(rule impI,rule ballI,rule ballI)
          assume A1: "X be trivialZFMISC-1V1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of X"
          show "x =XBOOLE-0R4 y"
          proof-
            have cases: "X be  non emptyXBOOLE-0V1 or X be emptyXBOOLE-0V1"
               sorry
            have case1: "X be  non emptyXBOOLE-0V1 implies x =XBOOLE-0R4 y"
            proof(rule impI)
              assume "X be  non emptyXBOOLE-0V1"
              then have "x inTARSKIR2 X & y inTARSKIR2 X"
                using subset_1_def_1 sorry
              thus "x =XBOOLE-0R4 y"
                using A1 sorry
            qed
            have case2: "X be emptyXBOOLE-0V1 implies x =XBOOLE-0R4 y"
            proof(rule impI)
              assume "X be emptyXBOOLE-0V1"
              then have "x =XBOOLE-0R4 {}XBOOLE-0K1 & y =XBOOLE-0R4 {}XBOOLE-0K1"
                using subset_1_def_1 sorry
              thus "x =XBOOLE-0R4 y"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        assume A2: " for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 y"
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 X implies x =HIDDENR1 y"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A3: "x inHIDDENR3 X & y inHIDDENR3 X"
          have 
            [ty]:"x be setHIDDENM2" and
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          have "x be ElementSUBSET-1M1-of X & y be ElementSUBSET-1M1-of X"
            using subset_1_def_1 A3 sorry
          thus "x =HIDDENR1 y"
            using A2 sorry
        qed "sorry"
        thus "X be trivialZFMISC-1V1"
          using zfmisc_1_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem subset_1_cl_23:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>trivialSUBSET-1V2 for SubsetSUBSET-1M2-of X"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of X st it be  non emptyXBOOLE-0V1\<bar>trivialSUBSET-1V2"
  proof-
    have " ex tVar11 be SubsetSUBSET-1M2-of X st tVar11 be  non emptyXBOOLE-0V1 & tVar11 be trivialSUBSET-1V2"
    proof-
      have "the ElementSUBSET-1M1-of X inTARSKIR2 X"
        using subset_1_def_1 sorry
      then have "{TARSKIK1 the ElementSUBSET-1M1-of X } c=TARSKIR1 X"
        using zfmisc_1_th_31 sorry
      then have "{TARSKIK1 the ElementSUBSET-1M1-of X } inTARSKIR2 boolZFMISC-1K1 X"
        using zfmisc_1_def_1 sorry
      then obtain A where 
        [ty]:"A be SubsetSUBSET-1M2-of X" and ADef:"A = {TARSKIK1 the ElementSUBSET-1M1-of X }"
        using subset_1_def_1 sorry
      show " ex tVar11 be SubsetSUBSET-1M2-of X st tVar11 be  non emptyXBOOLE-0V1 & tVar11 be trivialSUBSET-1V2"
      proof(rule bexI[of _ "A"],rule conjMI)
        show "A be  non emptyXBOOLE-0V1"
           sorry
        have " for x be ElementSUBSET-1M1-of A holds  for y be ElementSUBSET-1M1-of A holds x =XBOOLE-0R4 y"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of A"
          have "x inTARSKIR2 A & y inTARSKIR2 A"
            using subset_1_def_1 sorry
          then have "x =XBOOLE-0R4 the ElementSUBSET-1M1-of X & y =XBOOLE-0R4 the ElementSUBSET-1M1-of X"
            using tarski_def_1 sorry
          thus "x =XBOOLE-0R4 y"
             sorry
        qed "sorry"
        thus "A be trivialSUBSET-1V2"
          using subset_1_def_7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem subset_1_cl_24:
  mlet "X be trivialSUBSET-1V2\<bar>setHIDDENM2"
"cluster note-that trivialSUBSET-1V2 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be trivialSUBSET-1V2"
  proof-
    have " for Y be SubsetSUBSET-1M2-of X holds Y be trivialSUBSET-1V2"
    proof(rule ballI)
      fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
      have " for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds x =XBOOLE-0R4 y"
      proof(rule ballI,rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Y"
        fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
        show "x =XBOOLE-0R4 y"
        proof-
          have cases: "Y be  non emptyXBOOLE-0V1 or Y be emptyXBOOLE-0V1"
             sorry
          have case1: "Y be  non emptyXBOOLE-0V1 implies x =XBOOLE-0R4 y"
          proof(rule impI)
            assume "Y be  non emptyXBOOLE-0V1"
            then have "x inTARSKIR2 Y & y inTARSKIR2 Y"
              using subset_1_def_1 sorry
            then have "x inTARSKIR2 X & y inTARSKIR2 X"
              using subset_1_lm_1 sorry
            thus "x =XBOOLE-0R4 y"
              using zfmisc_1_def_10 sorry
          qed
          have case2: "Y be emptyXBOOLE-0V1 implies x =XBOOLE-0R4 y"
          proof(rule impI)
            assume "Y be emptyXBOOLE-0V1"
            then have "x =XBOOLE-0R4 {}XBOOLE-0K1 & y =XBOOLE-0R4 {}XBOOLE-0K1"
              using subset_1_def_1 sorry
            thus "x =XBOOLE-0R4 y"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "Y be trivialSUBSET-1V2"
        using subset_1_def_7 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem subset_1_cl_25:
  mlet "X be  non trivialSUBSET-1V2\<bar>setHIDDENM2"
"cluster  non trivialSUBSET-1V2 for SubsetSUBSET-1M2-of X"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of X st it be  non trivialSUBSET-1V2"
  proof-
    have " ex tVar12 be SubsetSUBSET-1M2-of X st  not tVar12 be trivialSUBSET-1V2"
    proof-
      show " ex tVar12 be SubsetSUBSET-1M2-of X st  not tVar12 be trivialSUBSET-1V2"
      proof(rule bexI[of _ "[#]SUBSET-1K2 X"])
        show " not [#]SUBSET-1K2 X be trivialSUBSET-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem subset_1_th_45:
" for D be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of D holds A be  non trivialSUBSET-1V2 implies ( ex d1 be ElementSUBSET-1M1-of D st  ex d2 be ElementSUBSET-1M1-of D st (d1 inTARSKIR2 A & d2 inTARSKIR2 A) & d1 <>HIDDENR2 d2)"
proof-
  have " for D be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of D holds A be  non trivialSUBSET-1V2 implies ( ex tVar13 be ElementSUBSET-1M1-of D st  ex tVar14 be ElementSUBSET-1M1-of D st (tVar13 inTARSKIR2 A & tVar14 inTARSKIR2 A) & tVar13 <>HIDDENR2 tVar14)"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of D"
    assume "A be  non trivialSUBSET-1V2"
    then obtain d1 d2 where
      [ty]:"d1 be objectHIDDENM1" "d2 be objectHIDDENM1" and 
      A1: "d1 inHIDDENR3 A & d2 inHIDDENR3 A"and A2: "d1 <>HIDDENR2 d2"
       sorry
    have 
      [ty]:"d1 be setHIDDENM2" and
      [ty]:"d2 be setHIDDENM2"
      using tarski_th_1 sorry
    have "d1 inTARSKIR2 D & d2 inTARSKIR2 D"
      using A1 subset_1_lm_1 sorry
    then have 
      [ty]:"d1 be ElementSUBSET-1M1-of D" and
      [ty]:"d2 be ElementSUBSET-1M1-of D"
      using subset_1_def_1 sorry
    show " ex tVar13 be ElementSUBSET-1M1-of D st  ex tVar14 be ElementSUBSET-1M1-of D st (tVar13 inTARSKIR2 A & tVar14 inTARSKIR2 A) & tVar13 <>HIDDENR2 tVar14"
    proof(rule bexI[of _ "d1"])
      show " ex tVar14 be ElementSUBSET-1M1-of D st (d1 inTARSKIR2 A & tVar14 inTARSKIR2 A) & d1 <>HIDDENR2 tVar14"
      proof(rule bexI[of _ "d2"])
        show "(d1 inTARSKIR2 A & d2 inTARSKIR2 A) & d1 <>HIDDENR2 d2"
          using A1 A2 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_46:
" for X be trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex x be ElementSUBSET-1M1-of X st X =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for X be trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex tVar15 be ElementSUBSET-1M1-of X st X =XBOOLE-0R4 {TARSKIK1 tVar15}"
  proof(rule ballI)
    fix X assume [ty]: "X be trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "X =XBOOLE-0R4 {TARSKIK1 x}"
      using zfmisc_1_th_131 sorry
    have 
      [ty]:"x be setHIDDENM2"
      using tarski_th_1 sorry
    have "x inTARSKIR2 X"
      using A1 tarski_def_1 sorry
    then have 
      [ty]:"x be ElementSUBSET-1M1-of X"
      using subset_1_def_1 sorry
    show " ex tVar15 be ElementSUBSET-1M1-of X st X =XBOOLE-0R4 {TARSKIK1 tVar15}"
    proof(rule bexI[of _ "x"])
      show "X =XBOOLE-0R4 {TARSKIK1 x}"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_47:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X holds A be trivialSUBSET-1V2 implies ( ex x be ElementSUBSET-1M1-of X st A =XBOOLE-0R4 {TARSKIK1 x})"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X holds A be trivialSUBSET-1V2 implies  not ( for x be ElementSUBSET-1M1-of X holds  not A =XBOOLE-0R4 {TARSKIK1 x})"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X"
    assume "A be trivialSUBSET-1V2"
    then have " ex s be ElementSUBSET-1M3\<^bsub>(X)\<^esub>-of A st A =XBOOLE-0R4 {TARSKIK1 s}"
      using subset_1_th_46 sorry
    thus " not ( for x be ElementSUBSET-1M1-of X holds  not A =XBOOLE-0R4 {TARSKIK1 x})"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_48:
" for X be  non trivialSUBSET-1V2\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds  ex y be objectHIDDENM1 st y inHIDDENR3 X & x <>HIDDENR2 y"
proof-
  have " for X be  non trivialSUBSET-1V2\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds  not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not x <>HIDDENR2 y))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non trivialSUBSET-1V2\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    obtain d1 d2 where
      [ty]:"d1 be objectHIDDENM1" "d2 be objectHIDDENM1" and 
      A1: "d1 inHIDDENR3 X & d2 inHIDDENR3 X"and A2: "d1 <>HIDDENR2 d2"
      using zfmisc_1_def_10 sorry
    have "x <>HIDDENR2 d1 or x <>HIDDENR2 d2"
      using A2 sorry
    thus " not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 X &  not x <>HIDDENR2 y))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x for "objectHIDDENM1"
mdef subset_1_def_8 ("InSUBSET-1K10'( _ , _ ')" [0,0]164 ) where
  mlet "x be objectHIDDENM1", "X be setHIDDENM2"
"assume x inHIDDENR3 X func InSUBSET-1K10(x,X) \<rightarrow> ElementSUBSET-1M1-of X equals
  x"
proof-
  (*coherence*)
    show "x inHIDDENR3 X implies x be ElementSUBSET-1M1-of X"
    proof(rule impI)
      assume Assume: "x inHIDDENR3 X"
      have A1: "x inHIDDENR3 X"
        using Assume sorry
      show "x be ElementSUBSET-1M1-of X"
      proof-
        have 
          [ty]:"x be setHIDDENM2"
          using tarski_th_1 sorry
        have "x inTARSKIR2 X"
          using A1 sorry
        thus "x be ElementSUBSET-1M1-of X"
          using subset_1_def_1 sorry
      qed
    qed
qed "sorry"

mtheorem subset_1_reduce_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of X"
"reduce InSUBSET-1K10(x,X) to x"
proof
(*reducibility*)
  show "InSUBSET-1K10(x,X) =HIDDENR1 x"
  proof-
    have "x inTARSKIR2 X"
      using subset_1_def_1 sorry
    thus "InSUBSET-1K10(x,X) =HIDDENR1 x"
      using subset_1_def_8 sorry
  qed
qed "sorry"

mtheorem subset_1_th_49:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y implies InSUBSET-1K10(x,X) =XBOOLE-0R4 InSUBSET-1K10(x,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y implies InSUBSET-1K10(x,X) =HIDDENR1 InSUBSET-1K10(x,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
    then have A2: "x inHIDDENR3 Y"
      using xboole_0_def_4 sorry
    have "x inHIDDENR3 X"
      using A1 xboole_0_def_4 sorry
    then have "InSUBSET-1K10(x,X) =HIDDENR1 x"
      using subset_1_def_8 sorry
    also have "... = InSUBSET-1K10(x,Y)"
      using A2 subset_1_def_8 sorry
    finally show "InSUBSET-1K10(x,X) =HIDDENR1 InSUBSET-1K10(x,Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_50:
" for X be  non trivialSUBSET-1V2\<bar>setHIDDENM2 holds  for p be setHIDDENM2 holds  ex q be ElementSUBSET-1M1-of X st q <>HIDDENR2 p"
proof-
  have " for X be  non trivialSUBSET-1V2\<bar>setHIDDENM2 holds  for p be setHIDDENM2 holds  ex tVar16 be ElementSUBSET-1M1-of X st  not tVar16 <>HIDDENR2 p"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non trivialSUBSET-1V2\<bar>setHIDDENM2"
    fix p assume [ty]: "p be setHIDDENM2"
    have "X \\SUBSET-1K6 {TARSKIK1 p} be  non emptyXBOOLE-0V1"
      using zfmisc_1_th_139 sorry
    then obtain q where
      [ty]:"q be objectHIDDENM1" and 
      A1: "q inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 p}"
       sorry
    have 
      [ty]:"q be setHIDDENM2"
      using tarski_th_1 sorry
    have "X \\SUBSET-1K6 {TARSKIK1 p} c=TARSKIR1 X"
      using xboole_1_th_36 sorry
    then have "q inTARSKIR2 X"
      using A1 sorry
    then have 
      [ty]:"q be ElementSUBSET-1M1-of X"
      using subset_1_def_1 sorry
    show " ex tVar16 be ElementSUBSET-1M1-of X st  not tVar16 <>HIDDENR2 p"
    proof(rule bexI[of _ "q"])
      show " not q <>HIDDENR2 p"
        using A1 zfmisc_1_th_56 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem subset_1_th_51:
" for T be  non trivialSUBSET-1V2\<bar>setHIDDENM2 holds  for X be  non trivialSUBSET-1V2\<bar>SubsetSUBSET-1M2-of T holds  for p be setHIDDENM2 holds  ex q be ElementSUBSET-1M1-of T st q inTARSKIR2 X & q <>HIDDENR2 p"
proof-
  have " for T be  non trivialSUBSET-1V2\<bar>setHIDDENM2 holds  for X be  non trivialSUBSET-1V2\<bar>SubsetSUBSET-1M2-of T holds  for p be setHIDDENM2 holds  ex tVar17 be ElementSUBSET-1M1-of T st tVar17 inTARSKIR2 X &  not tVar17 <>HIDDENR2 p"
  proof(rule ballI,rule ballI,rule ballI)
    fix T assume [ty]: "T be  non trivialSUBSET-1V2\<bar>setHIDDENM2"
    fix X assume [ty]: "X be  non trivialSUBSET-1V2\<bar>SubsetSUBSET-1M2-of T"
    fix p assume [ty]: "p be setHIDDENM2"
    have "X \\SUBSET-1K7\<^bsub>(T)\<^esub> {TARSKIK1 p} be  non emptyXBOOLE-0V1"
      using zfmisc_1_th_139 sorry
    then obtain q where
      [ty]:"q be objectHIDDENM1" and 
      A1: "q inHIDDENR3 X \\SUBSET-1K7\<^bsub>(T)\<^esub> {TARSKIK1 p}"
       sorry
    have 
      [ty]:"q be setHIDDENM2"
      using tarski_th_1 sorry
    have "q inTARSKIR2 T"
      using A1 subset_1_lm_1 sorry
    then have 
      [ty]:"q be ElementSUBSET-1M1-of T"
      using subset_1_def_1 sorry
    show " ex tVar17 be ElementSUBSET-1M1-of T st tVar17 inTARSKIR2 X &  not tVar17 <>HIDDENR2 p"
    proof(rule bexI[of _ "q"])
      show "q inTARSKIR2 X &  not q <>HIDDENR2 p"
        using A1 zfmisc_1_th_56 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem subset_1_sch_5:
  fixes Af0 af0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "af0 be ElementSUBSET-1M1-of Af0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows "unionTARSKIK3 ({Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} }) =XBOOLE-0R4 Ff1(af0)"
  proof-
    let ?X = "{Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} }"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Ff1(af0) iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 ?X)"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 Ff1(af0) implies ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} })) & (( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} }) implies x inHIDDENR3 Ff1(af0))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 Ff1(af0) implies ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} })"
        proof-
          have "x inHIDDENR3 Ff1(af0) implies ( ex tVar18 be setHIDDENM2 st x inHIDDENR3 tVar18 & tVar18 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} })"
          proof(rule impI)
            assume A1: "x inHIDDENR3 Ff1(af0)"
            show " ex tVar18 be setHIDDENM2 st x inHIDDENR3 tVar18 & tVar18 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} }"
            proof(rule bexI[of _ "Ff1(af0)"],rule conjMI)
              show "x inHIDDENR3 Ff1(af0)"
                using A1 sorry
              have "af0 inTARSKIR2 {TARSKIK1 af0}"
                using tarski_def_1 sorry
              thus "Ff1(af0) inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} }"
                 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 ?X"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A2: "x inHIDDENR3 Y"and A3: "Y inTARSKIR2 ?X"
           sorry
        have " ex j be ElementSUBSET-1M1-of Af0 st Y =XBOOLE-0R4 Ff1(j) & j inTARSKIR2 {TARSKIK1 af0}"
          using A3 sorry
        thus "x inHIDDENR3 Ff1(af0)"
          using A2 tarski_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "unionTARSKIK3 ({Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK1 af0} }) =XBOOLE-0R4 Ff1(af0)"
      using tarski_def_4 sorry
  qed

theorem subset_1_sch_6:
  fixes Af0 af0 bf0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "af0 be ElementSUBSET-1M1-of Af0" and
  [ty]: "bf0 be ElementSUBSET-1M1-of Af0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows "unionTARSKIK3 ({Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }) =XBOOLE-0R4 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0)"
  proof-
    let ?X = "{Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0) iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 ?X)"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0) implies ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } })) & (( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }) implies x inHIDDENR3 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0) implies ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } })"
        proof-
          have "x inHIDDENR3 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0) implies ( ex tVar19 be setHIDDENM2 st x inHIDDENR3 tVar19 & tVar19 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } })"
          proof(rule impI)
            assume Cut1268: "x inHIDDENR3 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0)"
            show " ex tVar19 be setHIDDENM2 st x inHIDDENR3 tVar19 & tVar19 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }"
            proof-
              have cases: "x inHIDDENR3 Ff1(af0) or x inHIDDENR3 Ff1(bf0)"
                using xboole_0_def_3 Cut1268 sorry
              have case1: "x inHIDDENR3 Ff1(af0) implies ( ex tVar19 be setHIDDENM2 st x inHIDDENR3 tVar19 & tVar19 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } })"
              proof(rule impI)
                assume A1: "x inHIDDENR3 Ff1(af0)"
                show " ex tVar19 be setHIDDENM2 st x inHIDDENR3 tVar19 & tVar19 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }"
                proof(rule bexI[of _ "Ff1(af0)"],rule conjMI)
                  show "x inHIDDENR3 Ff1(af0)"
                    using A1 sorry
                  have "af0 inTARSKIR2 {TARSKIK2 af0,bf0 }"
                    using tarski_def_2 sorry
                  thus "Ff1(af0) inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }"
                     sorry
                qed "sorry"
              qed
              have case2: "x inHIDDENR3 Ff1(bf0) implies ( ex tVar20 be setHIDDENM2 st x inHIDDENR3 tVar20 & tVar20 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } })"
              proof(rule impI)
                assume A2: "x inHIDDENR3 Ff1(bf0)"
                show " ex tVar20 be setHIDDENM2 st x inHIDDENR3 tVar20 & tVar20 inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }"
                proof(rule bexI[of _ "Ff1(bf0)"],rule conjMI)
                  show "x inHIDDENR3 Ff1(bf0)"
                    using A2 sorry
                  have "bf0 inTARSKIR2 {TARSKIK2 af0,bf0 }"
                    using tarski_def_2 sorry
                  thus "Ff1(bf0) inTARSKIR2 {Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }"
                     sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inTARSKIR2 ?X"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A3: "x inHIDDENR3 Y"and A4: "Y inTARSKIR2 ?X"
           sorry
        obtain j where
          [ty]:"j be ElementSUBSET-1M1-of Af0" and 
          A5: "Y =XBOOLE-0R4 Ff1(j)"and A6: "j inTARSKIR2 {TARSKIK2 af0,bf0 }"
          using A4 sorry
        have "j =XBOOLE-0R4 af0 & x inHIDDENR3 Ff1(af0) or j =XBOOLE-0R4 bf0 & (j =XBOOLE-0R4 bf0 implies x inHIDDENR3 Ff1(bf0))"
        proof-
          show "j =XBOOLE-0R4 af0 & x inHIDDENR3 Ff1(af0) or j =XBOOLE-0R4 bf0 & (j =XBOOLE-0R4 bf0 implies x inHIDDENR3 Ff1(bf0))"
          proof-
            have cases: "j =XBOOLE-0R4 af0 or j =XBOOLE-0R4 bf0"
              using A6 tarski_def_2 sorry
            have case1: "j =XBOOLE-0R4 af0 implies x inHIDDENR3 Ff1(af0)"
            proof(rule impI)
              assume "j =XBOOLE-0R4 af0"
              thus "x inHIDDENR3 Ff1(af0)"
                using A3 A5 sorry
            qed
            have case2: "j =XBOOLE-0R4 bf0 implies x inHIDDENR3 Ff1(bf0)"
            proof(rule impI)
              assume "j =XBOOLE-0R4 bf0"
              thus "x inHIDDENR3 Ff1(bf0)"
                using A3 A5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0)"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "unionTARSKIK3 ({Ff1(j) where j be ElementSUBSET-1M1-of Af0 : j inTARSKIR2 {TARSKIK2 af0,bf0 } }) =XBOOLE-0R4 Ff1(af0) \\/XBOOLE-0K2 Ff1(bf0)"
      using tarski_def_4 sorry
  qed

end
