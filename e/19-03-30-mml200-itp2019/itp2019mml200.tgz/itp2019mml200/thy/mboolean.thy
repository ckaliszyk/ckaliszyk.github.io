theory mboolean
  imports setfam_1 pre_circ
begin
(*begin*)
reserve x, y for "objectHIDDENM1"
reserve I for "setHIDDENM2"
reserve A, B, X, Y for "ManySortedSetPBOOLEM1-of I"
mdef mboolean_def_1 ("boolMBOOLEANK1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"func boolMBOOLEANK1\<^bsub>(I)\<^esub> A \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
    proof-
      have " ex X be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
      proof-
        let ?V = "\<lambda>Lamb1. boolZFMISC-1K1 (A .FUNCT-1K1 Lamb1)"
        show " ex X be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
          using pboole_sch_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
    proof-
      have " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
        fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
        assume A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
          and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
            using A1 sorry
          also have "... = Y .FUNCT-1K1 i"
            using A2 A3 sorry
          finally show "X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem mboolean_cl_1:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> A as-term-is non-emptyRELAT-1V2"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> A be non-emptyRELAT-1V2"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "boolZFMISC-1K1 (A .FUNCT-1K1 i) be  non emptyXBOOLE-0V1"
         sorry
      thus " not boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be emptyXBOOLE-0V1"
        using A1 mboolean_def_1 sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> A be non-emptyRELAT-1V2"
      using pboole_def_13 sorry
  qed
qed "sorry"

mlemma mboolean_lm_1:
" for i be setHIDDENM2 holds  for I be setHIDDENM2 holds  for X be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds i inTARSKIR2 I implies domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =XBOOLE-0R4 I"
proof-
  have " for i be setHIDDENM2 holds  for I be setHIDDENM2 holds  for X be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds i inTARSKIR2 I implies domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =HIDDENR1 I"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be setHIDDENM2"
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    assume A1: "i inTARSKIR2 I"
    have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =HIDDENR1 domRELAT-1K1 M \\/XBOOLE-0K2 domRELAT-1K1 (i .-->FUNCOP-1K17 X)"
      using funct_4_def_1 sorry
    also have "... = I \\/XBOOLE-0K2 domRELAT-1K1 (i .-->FUNCOP-1K17 X)"
      using partfun1_def_2 sorry
    also have "... = I \\/XBOOLE-0K2 {TARSKIK1 i}"
      using funcop_1_th_13 sorry
    also have "... = I"
      using A1 zfmisc_1_th_40 sorry
    finally show "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X)) =HIDDENR1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma mboolean_lm_2:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A1: "i inTARSKIR2 I"
    then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ((A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i)"
      using mboolean_def_1 sorry
    also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
      using A1 pboole_def_4 sorry
    finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma mboolean_lm_3:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A1: "i inTARSKIR2 I"
    then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ((A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i)"
      using mboolean_def_1 sorry
    also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
      using A1 pboole_def_5 sorry
    finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma mboolean_lm_4:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A1: "i inTARSKIR2 I"
    then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ((A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B).FUNCT-1K1 i)"
      using mboolean_def_1 sorry
    also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
      using A1 pboole_def_6 sorry
    finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma mboolean_lm_5:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A1: "i inTARSKIR2 I"
    then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ((A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B).FUNCT-1K1 i)"
      using mboolean_def_1 sorry
    also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
      using A1 pboole_th_4 sorry
    finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_1:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y iff ( for A be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> X iff A c=PBOOLER2\<^bsub>(I)\<^esub> Y)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y implies ( for A be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> X iff A c=PBOOLER2\<^bsub>(I)\<^esub> Y)) & (( for A be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> X iff A c=PBOOLER2\<^bsub>(I)\<^esub> Y) implies X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    show "X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y implies ( for A be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> X iff A c=PBOOLER2\<^bsub>(I)\<^esub> Y)"
    proof-
      have "X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y implies ( for A be ManySortedSetPBOOLEM1-of I holds (A inPBOOLER1\<^bsub>(I)\<^esub> X implies A c=PBOOLER2\<^bsub>(I)\<^esub> Y) & (A c=PBOOLER2\<^bsub>(I)\<^esub> Y implies A inPBOOLER1\<^bsub>(I)\<^esub> X))"
      proof(rule impI,rule ballI,rule conjMI,rule impI)
        assume A1: "X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y"
        fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
        show "A inPBOOLER1\<^bsub>(I)\<^esub> X implies A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
        proof(rule impI)
          assume A2: "A inPBOOLER1\<^bsub>(I)\<^esub> X"
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume A3: "i inHIDDENR3 I"
            then have A4: "A .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
              using A2 sorry
            have "X .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (Y .FUNCT-1K1 i)"
              using A1 A3 mboolean_def_1 sorry
            thus "A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
              using A4 sorry
          qed "sorry"
          thus "A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
            using pboole_def_2 sorry
        qed
        assume A5: "A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A6: "i inHIDDENR3 I"
          then have A7: "A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
            using A5 sorry
          have "X .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (Y .FUNCT-1K1 i)"
            using A1 A6 mboolean_def_1 sorry
          thus "A .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            using A7 sorry
        qed "sorry"
        thus "A inPBOOLER1\<^bsub>(I)\<^esub> X"
          using pboole_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: " for A be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> X iff A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 boolMBOOLEANK1\<^bsub>(I)\<^esub> Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A9: "i inHIDDENR3 I"
      have "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> Y"
        using pboole_th_43 sorry
      then have A10: "EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> X"
        using A8 sorry
      have " for A9 be setHIDDENM2 holds A9 inTARSKIR2 X .FUNCT-1K1 i iff A9 c=TARSKIR1 Y .FUNCT-1K1 i"
      proof-
        have " for A9 be setHIDDENM2 holds (A9 inTARSKIR2 X .FUNCT-1K1 i implies A9 c=TARSKIR1 Y .FUNCT-1K1 i) & (A9 c=TARSKIR1 Y .FUNCT-1K1 i implies A9 inTARSKIR2 X .FUNCT-1K1 i)"
        proof(rule ballI,rule conjMI,rule impI)
          fix A9 assume [ty]: "A9 be setHIDDENM2"
          have A11: "domRELAT-1K1 (i .-->FUNCOP-1K17 A9) =XBOOLE-0R4 {TARSKIK1 i}"
            using funcop_1_th_13 sorry
          have "domRELAT-1K1 (EmptyMSPBOOLEK1 I +*FUNCT-4K1 (i .-->FUNCOP-1K17 A9)) =XBOOLE-0R4 I"
            using A9 mboolean_lm_1 sorry
          then obtain K where 
            [ty]:"K be ManySortedSetPBOOLEM1-of I" and KDef:"K = EmptyMSPBOOLEK1 I +*FUNCT-4K1 (i .-->FUNCOP-1K17 A9)"
            using partfun1_def_2 relat_1_def_18 sorry
          have "i inHIDDENR3 {TARSKIK1 i}"
            using tarski_def_1 sorry
          then have A12: "K .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 A9).FUNCT-1K1 i"
            using A11 funct_4_th_13 sorry
          also have "... = A9"
            using funcop_1_th_72 sorry
          finally have "K .FUNCT-1K1 i =HIDDENR1 A9"
             sorry
          show "A9 inTARSKIR2 X .FUNCT-1K1 i implies A9 c=TARSKIR1 Y .FUNCT-1K1 i"
          proof(rule impI)
            assume A13: "A9 inTARSKIR2 X .FUNCT-1K1 i"
            have "K inPBOOLER1\<^bsub>(I)\<^esub> X"
            proof-
              have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j"
              proof(rule ballI,rule impI)
                fix j assume [ty]: "j be objectHIDDENM1"
                assume A14: "j inHIDDENR3 I"
                have "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j)"
                proof-
                  show "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j)"
                  proof-
                    have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                       sorry
                    have case1: "j =HIDDENR1 i implies K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j"
                    proof(rule impI)
                      assume "j =HIDDENR1 i"
                      thus "K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j"
                        using A12 A13 sorry
                    qed
                    have case2: "j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j"
                    proof(rule impI)
                      assume "j <>HIDDENR2 i"
                      then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 A9)"
                        using A11 tarski_def_1 sorry
                      then have "K .FUNCT-1K1 j =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 j"
                        using funct_4_th_11 sorry
                      thus "K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j"
                        using A10 A14 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "K .FUNCT-1K1 j inTARSKIR2 X .FUNCT-1K1 j"
                   sorry
              qed "sorry"
              thus "K inPBOOLER1\<^bsub>(I)\<^esub> X"
                using pboole_def_1 sorry
            qed
            then have "K c=PBOOLER2\<^bsub>(I)\<^esub> Y"
              using A8 sorry
            thus "A9 c=TARSKIR1 Y .FUNCT-1K1 i"
              using A9 A12 sorry
          qed
          assume A15: "A9 c=TARSKIR1 Y .FUNCT-1K1 i"
          have "K c=PBOOLER2\<^bsub>(I)\<^esub> Y"
          proof-
            have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j"
            proof(rule ballI,rule impI)
              fix j assume [ty]: "j be objectHIDDENM1"
              assume A16: "j inHIDDENR3 I"
              have "j =HIDDENR1 i & K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j)"
              proof-
                show "j =HIDDENR1 i & K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j)"
                proof-
                  have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                     sorry
                  have case1: "j =HIDDENR1 i implies K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j"
                  proof(rule impI)
                    assume "j =HIDDENR1 i"
                    thus "K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j"
                      using A12 A15 sorry
                  qed
                  have case2: "j <>HIDDENR2 i implies K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j"
                  proof(rule impI)
                    assume "j <>HIDDENR2 i"
                    then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 A9)"
                      using A11 tarski_def_1 sorry
                    then have A17: "K .FUNCT-1K1 j =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 j"
                      using funct_4_th_11 sorry
                    have "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> Y"
                      using pboole_th_43 sorry
                    thus "K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j"
                      using A16 A17 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "K .FUNCT-1K1 j c=TARSKIR1 Y .FUNCT-1K1 j"
                 sorry
            qed "sorry"
            thus "K c=PBOOLER2\<^bsub>(I)\<^esub> Y"
              using pboole_def_2 sorry
          qed
          then have "K inPBOOLER1\<^bsub>(I)\<^esub> X"
            using A8 sorry
          thus "A9 inTARSKIR2 X .FUNCT-1K1 i"
            using A9 A12 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "X .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (Y .FUNCT-1K1 i)"
        using zfmisc_1_def_1 sorry
      thus "X .FUNCT-1K1 i =XBOOLE-0R4 boolMBOOLEANK1\<^bsub>(I)\<^esub> Y .FUNCT-1K1 i"
        using A9 mboolean_def_1 sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_2:
" for I be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for I be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 (I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (EmptyMSPBOOLEK1 I .FUNCT-1K1 i)"
        using mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 ({}XBOOLE-0K1)"
        using pboole_th_5 sorry
      also have "... = {TARSKIK1 {}XBOOLE-0K1 }"
        using zfmisc_1_th_1 sorry
      finally have "boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 (I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }).FUNCT-1K1 i"
        using A1 funcop_1_th_7 sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_3:
" for I be setHIDDENM2 holds  for x be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 boolZFMISC-1K1 x"
proof-
  have " for I be setHIDDENM2 holds  for x be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 boolZFMISC-1K1 x"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 boolZFMISC-1K1 x).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ((I -->FUNCOP-1K7 x).FUNCT-1K1 i)"
        using mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 x"
        using A1 funcop_1_th_7 sorry
      also have "... = (I -->FUNCOP-1K7 boolZFMISC-1K1 x).FUNCT-1K1 i"
        using A1 funcop_1_th_7 sorry
      finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 boolZFMISC-1K1 x).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 boolZFMISC-1K1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_4:
" for x be objectHIDDENM1 holds  for I be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
proof-
  have " for x be objectHIDDENM1 holds  for I be setHIDDENM2 holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix I assume [ty]: "I be setHIDDENM2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ((I -->FUNCOP-1K7 {TARSKIK1 x}).FUNCT-1K1 i)"
        using mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 {TARSKIK1 x}"
        using A1 funcop_1_th_7 sorry
      also have "... = {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
        using zfmisc_1_th_24 sorry
      also have "... = (I -->FUNCOP-1K7 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }).FUNCT-1K1 i"
        using A1 funcop_1_th_7 sorry
      finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 {}XBOOLE-0K1,{TARSKIK1 x} }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_5:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies EmptyMSPBOOLEK1 I .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      have "EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
        using pboole_th_5 sorry
      thus "EmptyMSPBOOLEK1 I .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using xboole_1_th_2 sorry
    qed "sorry"
    thus "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_6:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B implies boolMBOOLEANK1\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B implies boolMBOOLEANK1\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "A c=PBOOLER2\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "A .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A1 sorry
      have "boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i) & boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (B .FUNCT-1K1 i)"
        using A2 mboolean_def_1 sorry
      thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A3 zfmisc_1_th_67 sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_7:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have A2: "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
        using mboolean_lm_2 sorry
      have "(boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =HIDDENR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i \\/XBOOLE-0K2 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i) \\/XBOOLE-0K2 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A1 mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i) \\/XBOOLE-0K2 boolZFMISC-1K1 (B .FUNCT-1K1 i)"
        using A1 mboolean_def_1 sorry
      finally have "(boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i) \\/XBOOLE-0K2 boolZFMISC-1K1 (B .FUNCT-1K1 i)"
         sorry
      thus "(boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
        using A2 zfmisc_1_th_69 sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B)"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_8:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) implies ( for i be setHIDDENM2 holds i inTARSKIR2 I implies (A .FUNCT-1K1 i,B .FUNCT-1K1 i)are-c=-comparableXBOOLE-0R3)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) implies ( for i be setHIDDENM2 holds i inTARSKIR2 I implies (A .FUNCT-1K1 i,B .FUNCT-1K1 i)are-c=-comparableXBOOLE-0R3)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B)"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A2: "i inTARSKIR2 I"
    have "boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i) =HIDDENR1 (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
      using A1 A2 mboolean_lm_2 sorry
    also have "... = boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i \\/XBOOLE-0K2 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
      using A2 pboole_def_4 sorry
    also have "... = boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i \\/XBOOLE-0K2 boolZFMISC-1K1 (B .FUNCT-1K1 i)"
      using A2 mboolean_def_1 sorry
    also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i) \\/XBOOLE-0K2 boolZFMISC-1K1 (B .FUNCT-1K1 i)"
      using A2 mboolean_def_1 sorry
    finally have "boolZFMISC-1K1 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i) =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i) \\/XBOOLE-0K2 boolZFMISC-1K1 (B .FUNCT-1K1 i)"
       sorry
    thus "(A .FUNCT-1K1 i,B .FUNCT-1K1 i)are-c=-comparableXBOOLE-0R3"
      using zfmisc_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_9:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
        using mboolean_lm_3 sorry
      also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i) /\\XBOOLE-0K3 boolZFMISC-1K1 (B .FUNCT-1K1 i)"
        using zfmisc_1_th_71 sorry
      also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i) /\\XBOOLE-0K3 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A1 mboolean_def_1 sorry
      also have "... = boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i /\\XBOOLE-0K3 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A1 mboolean_def_1 sorry
      also have "... = (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      finally show "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_10:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i c=TARSKIR1 ((I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have A2: "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
        using mboolean_lm_4 sorry
      have "((I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)).FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }).FUNCT-1K1 i \\/XBOOLE-0K2 (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A1 funcop_1_th_7 sorry
      also have "... = {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i \\XBOOLE-0K4 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i)"
        using A1 pboole_def_6 sorry
      also have "... = {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 (A .FUNCT-1K1 i) \\XBOOLE-0K4 boolMBOOLEANK1\<^bsub>(I)\<^esub> B .FUNCT-1K1 i)"
        using A1 mboolean_def_1 sorry
      also have "... = {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 (A .FUNCT-1K1 i) \\XBOOLE-0K4 boolZFMISC-1K1 (B .FUNCT-1K1 i))"
        using A1 mboolean_def_1 sorry
      finally have "((I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)).FUNCT-1K1 i =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 } \\/XBOOLE-0K2 (boolZFMISC-1K1 (A .FUNCT-1K1 i) \\XBOOLE-0K4 boolZFMISC-1K1 (B .FUNCT-1K1 i))"
         sorry
      thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i c=TARSKIR1 ((I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)).FUNCT-1K1 i"
        using A2 zfmisc_1_th_72 sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 })(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> B)"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_11:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B iff X c=PBOOLER2\<^bsub>(I)\<^esub> A & X missesPBOOLER5\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds (X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B implies X c=PBOOLER2\<^bsub>(I)\<^esub> A & X missesPBOOLER5\<^bsub>(I)\<^esub> B) & (X c=PBOOLER2\<^bsub>(I)\<^esub> A & X missesPBOOLER5\<^bsub>(I)\<^esub> B implies X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B implies X c=PBOOLER2\<^bsub>(I)\<^esub> A & X missesPBOOLER5\<^bsub>(I)\<^esub> B"
    proof(rule impI,rule conjMI)
      assume "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B"
      then have A1: "X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B)"
        using mboolean_th_1 sorry
      show "X c=PBOOLER2\<^bsub>(I)\<^esub> A"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A2: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i inTARSKIR2 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
            using A1 sorry
          then have "X .FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
            using A2 mboolean_lm_4 sorry
          thus "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
            using xboole_1_th_106 sorry
        qed "sorry"
        thus "X c=PBOOLER2\<^bsub>(I)\<^esub> A"
          using pboole_def_2 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i missesXBOOLE-0R1 B .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i inTARSKIR2 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
          using A1 sorry
        then have "X .FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i)"
          using A3 mboolean_lm_4 sorry
        thus "X .FUNCT-1K1 i missesXBOOLE-0R1 B .FUNCT-1K1 i"
          using xboole_1_th_106 sorry
      qed "sorry"
      thus "X missesPBOOLER5\<^bsub>(I)\<^esub> B"
        using pboole_def_8 sorry
    qed
    assume A4: "X c=PBOOLER2\<^bsub>(I)\<^esub> A & X missesPBOOLER5\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A5: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i & X .FUNCT-1K1 i missesXBOOLE-0R1 B .FUNCT-1K1 i"
        using A4 sorry
      then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i"
        using xboole_1_th_86 sorry
      thus "X .FUNCT-1K1 i c=TARSKIR1 (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A5 pboole_def_6 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_12:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A)).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have A2: "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
        using mboolean_lm_5 sorry
      have "(boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A)).FUNCT-1K1 i =HIDDENR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i \\/XBOOLE-0K2 boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i) \\/XBOOLE-0K2 boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i"
        using A1 mboolean_lm_4 sorry
      also have "... = boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i) \\/XBOOLE-0K2 boolZFMISC-1K1 (B .FUNCT-1K1 i \\XBOOLE-0K4 A .FUNCT-1K1 i)"
        using A1 mboolean_lm_4 sorry
      finally have "(boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A)).FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (A .FUNCT-1K1 i \\XBOOLE-0K4 B .FUNCT-1K1 i) \\/XBOOLE-0K2 boolZFMISC-1K1 (B .FUNCT-1K1 i \\XBOOLE-0K4 A .FUNCT-1K1 i)"
         sorry
      thus "(boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A)).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
        using A2 zfmisc_1_th_73 sorry
    qed "sorry"
    thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (B (\\)PBOOLEK4\<^bsub>(I)\<^esub> A) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B)"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_13:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B iff X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B & X missesPBOOLER5\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds (X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B implies X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B & X missesPBOOLER5\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) & (X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B & X missesPBOOLER5\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B implies X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B implies X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B & X missesPBOOLER5\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B"
    proof(rule impI,rule conjMI)
      assume "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B"
      then have A1: "X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B)"
        using mboolean_th_1 sorry
      show "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A2: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i inTARSKIR2 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
            using A1 sorry
          then have "X .FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
            using A2 mboolean_lm_5 sorry
          then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i"
            using xboole_1_th_107 sorry
          thus "X .FUNCT-1K1 i c=TARSKIR1 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
            using A2 pboole_def_4 sorry
        qed "sorry"
        thus "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
          using pboole_def_2 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i missesXBOOLE-0R1 (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i inTARSKIR2 boolMBOOLEANK1\<^bsub>(I)\<^esub> (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
          using A1 sorry
        then have "X .FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i)"
          using A3 mboolean_lm_5 sorry
        then have "X .FUNCT-1K1 i missesXBOOLE-0R1 A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i"
          using xboole_1_th_107 sorry
        thus "X .FUNCT-1K1 i missesXBOOLE-0R1 (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
          using A3 pboole_def_5 sorry
      qed "sorry"
      thus "X missesPBOOLER5\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B"
        using pboole_def_8 sorry
    qed
    assume A4: "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
      and A5: "X missesPBOOLER5\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A6: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i missesXBOOLE-0R1 (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A5 sorry
      then have A7: "X .FUNCT-1K1 i missesXBOOLE-0R1 A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i"
        using A6 pboole_def_5 sorry
      have "X .FUNCT-1K1 i c=TARSKIR1 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A4 A6 sorry
      then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i"
        using A6 pboole_def_4 sorry
      then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i \\+\\XBOOLE-0K5 B .FUNCT-1K1 i"
        using A7 xboole_1_th_107 sorry
      thus "X .FUNCT-1K1 i c=TARSKIR1 (A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A6 pboole_th_4 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_14:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A or Y c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A or Y c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> A or Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
    show "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
    proof-
      have cases: "X c=PBOOLER2\<^bsub>(I)\<^esub> A or Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
        using A1 sorry
      have case1: "X c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
      proof(rule impI)
        assume A2: "X c=PBOOLER2\<^bsub>(I)\<^esub> A"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
            using A2 sorry
          then have "X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
            using xboole_1_th_108 sorry
          thus "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
            using A3 pboole_def_5 sorry
        qed "sorry"
        thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
          using pboole_def_2 sorry
      qed
      have case2: "Y c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
      proof(rule impI)
        assume A4: "Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A5: "i inHIDDENR3 I"
          then have "Y .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
            using A4 sorry
          then have "X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
            using xboole_1_th_108 sorry
          thus "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
            using A5 pboole_def_5 sorry
        qed "sorry"
        thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
          using pboole_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_15:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> A"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using A1 sorry
      then have "X .FUNCT-1K1 i \\XBOOLE-0K4 Y .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using xboole_1_th_109 sorry
      thus "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using A2 pboole_def_6 sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_16:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A & Y c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A & Y c=PBOOLER2\<^bsub>(I)\<^esub> A implies X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> A & Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i & Y .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using A1 sorry
      then have "X .FUNCT-1K1 i \\+\\XBOOLE-0K5 Y .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using xboole_1_th_110 sorry
      then have "X .FUNCT-1K1 i \\+\\XBOOLE-0K5 Y .FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
         sorry
      then have "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
        using A2 pboole_th_4 sorry
      thus "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_17:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y))"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y))"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)) .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have A2: "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        using pboole_def_16 sorry
      have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) .FUNCT-1K1 i)"
        using A1 mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 (boolZFMISC-1K1 (X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i))"
        using A1 mboolean_lm_2 sorry
      finally have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (boolZFMISC-1K1 (X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i))"
         sorry
      thus "([|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |]).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)) .FUNCT-1K1 i"
        using A2 zfmisc_1_th_86 sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y))"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_18:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> A iff X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds (X c=PBOOLER2\<^bsub>(I)\<^esub> A implies X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A) & (X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> A)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "X c=PBOOLER2\<^bsub>(I)\<^esub> A implies X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
    proof(rule impI)
      assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> A"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i inTARSKIR2 boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
          using A1 sorry
        then have "X .FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
           sorry
        thus "X .FUNCT-1K1 i inTARSKIR2 boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
          using A2 mboolean_def_1 sorry
      qed "sorry"
      thus "X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
        using pboole_def_1 sorry
    qed
    assume A3: "X inPBOOLER1\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> A"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i inTARSKIR2 boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
        using A3 sorry
      then have "X .FUNCT-1K1 i inTARSKIR2 boolZFMISC-1K1 (A .FUNCT-1K1 i)"
        using A4 mboolean_def_1 sorry
      thus "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_19:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds (Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |])"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds (Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |])"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ((Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B)).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]) .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have A2: "((Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B)).FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
        using pboole_def_17 sorry
      have "boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i)"
        using A1 mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 ([:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :])"
        using A1 pboole_def_16 sorry
      finally have "boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 ([:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :])"
         sorry
      thus "((Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B)).FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]) .FUNCT-1K1 i"
        using A2 fraenkel_th_2 sorry
    qed "sorry"
    thus "(Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |])"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef mboolean_def_2 ("unionMBOOLEANK2\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"func unionMBOOLEANK2\<^bsub>(I)\<^esub> A \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
    proof-
      have " ex X be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
      proof-
        let ?V = "\<lambda>Lamb1. unionTARSKIK3 (A .FUNCT-1K1 Lamb1)"
        show " ex X be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
          using pboole_sch_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
    proof-
      have " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
        fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
        assume A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
          and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i)"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "X .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (A .FUNCT-1K1 i)"
            using A1 sorry
          also have "... = Y .FUNCT-1K1 i"
            using A2 A3 sorry
          finally show "X .FUNCT-1K1 i =HIDDENR1 Y .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem mboolean_cl_2:
  mlet "I be setHIDDENM2"
"cluster unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I as-term-is empty-yieldingRELAT-1V3"
proof
(*coherence*)
  show "unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      have A1: "unionTARSKIK3 (EmptyMSPBOOLEK1 I .FUNCT-1K1 i) be emptyXBOOLE-0V1"
        using pboole_th_5 zfmisc_1_th_2 sorry
      assume "i inHIDDENR3 I"
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i be emptyXBOOLE-0V1"
        using A1 mboolean_def_2 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3"
      using pboole_def_12 sorry
  qed
qed "sorry"

mlemma mboolean_lm_6:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A1: "i inTARSKIR2 I"
    then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ((A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i)"
      using mboolean_def_2 sorry
    also have "... = unionTARSKIK3 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
      using A1 pboole_def_4 sorry
    finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma mboolean_lm_7:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for i be setHIDDENM2 holds i inTARSKIR2 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be setHIDDENM2"
    assume A1: "i inTARSKIR2 I"
    then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ((A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i)"
      using mboolean_def_2 sorry
    also have "... = unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
      using A1 pboole_def_5 sorry
    finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_20:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X iff ( ex Y be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> Y & Y inPBOOLER1\<^bsub>(I)\<^esub> X)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds (A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X implies ( ex Y be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> Y & Y inPBOOLER1\<^bsub>(I)\<^esub> X)) & (( ex Y be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> Y & Y inPBOOLER1\<^bsub>(I)\<^esub> X) implies A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X implies ( ex Y be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> Y & Y inPBOOLER1\<^bsub>(I)\<^esub> X)"
    proof-
      have "A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X implies ( ex tVar2 be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> tVar2 & tVar2 inPBOOLER1\<^bsub>(I)\<^esub> X)"
      proof(rule impI)
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex B be setHIDDENM2 st (B =HIDDENR1 Lamb2 & A .FUNCT-1K1 Lamb1 inTARSKIR2 B) & Lamb2 inHIDDENR3 X .FUNCT-1K1 Lamb1"
        assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X"
        have A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Y be objectHIDDENM1 st ?P(i,Y))"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar1 be objectHIDDENM1 st  ex Bc be setHIDDENM2 st (Bc =HIDDENR1 tVar1 & A .FUNCT-1K1 i inTARSKIR2 Bc) & tVar1 inHIDDENR3 X .FUNCT-1K1 i)"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume A3: "i inHIDDENR3 I"
            then have "A .FUNCT-1K1 i inTARSKIR2 unionMBOOLEANK2\<^bsub>(I)\<^esub> X .FUNCT-1K1 i"
              using A1 sorry
            then have "A .FUNCT-1K1 i inTARSKIR2 unionTARSKIK3 (X .FUNCT-1K1 i)"
              using A3 mboolean_def_2 sorry
            then obtain B where
              [ty]:"B be setHIDDENM2" and 
              A4: "A .FUNCT-1K1 i inTARSKIR2 B & B inTARSKIR2 X .FUNCT-1K1 i"
              using tarski_def_4 sorry
            show " ex tVar1 be objectHIDDENM1 st  ex Bc be setHIDDENM2 st (Bc =HIDDENR1 tVar1 & A .FUNCT-1K1 i inTARSKIR2 Bc) & tVar1 inHIDDENR3 X .FUNCT-1K1 i"
            proof(rule bexI[of _ "B"])
              show " ex Bc be setHIDDENM2 st (Bc =HIDDENR1 B & A .FUNCT-1K1 i inTARSKIR2 Bc) & B inHIDDENR3 X .FUNCT-1K1 i"
                using A4 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain K where
          [ty]:"K be ManySortedSetPBOOLEM1-of I" and 
          A5: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?P(i,K .FUNCT-1K1 i)"
          using pboole_sch_3 A2 sorry
        show " ex tVar2 be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> tVar2 & tVar2 inPBOOLER1\<^bsub>(I)\<^esub> X"
        proof(rule bexI[of _ "K"],rule conjMI)
          show "A inPBOOLER1\<^bsub>(I)\<^esub> K"
          proof-
            have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i inTARSKIR2 K .FUNCT-1K1 i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be objectHIDDENM1"
              assume "i inHIDDENR3 I"
              then have "?P(i,K .FUNCT-1K1 i)"
                using A5 sorry
              thus "A .FUNCT-1K1 i inTARSKIR2 K .FUNCT-1K1 i"
                 sorry
            qed "sorry"
            thus "A inPBOOLER1\<^bsub>(I)\<^esub> K"
              using pboole_def_1 sorry
          qed
          show "K inPBOOLER1\<^bsub>(I)\<^esub> X"
          proof-
            have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies K .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be objectHIDDENM1"
              assume "i inHIDDENR3 I"
              then have "?P(i,K .FUNCT-1K1 i)"
                using A5 sorry
              thus "K .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
                 sorry
            qed "sorry"
            thus "K inPBOOLER1\<^bsub>(I)\<^esub> X"
              using pboole_def_1 sorry
          qed
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex Y be ManySortedSetPBOOLEM1-of I st A inPBOOLER1\<^bsub>(I)\<^esub> Y & Y inPBOOLER1\<^bsub>(I)\<^esub> X"
    then obtain Y where
      [ty]:"Y be ManySortedSetPBOOLEM1-of I" and 
      A6: "A inPBOOLER1\<^bsub>(I)\<^esub> Y & Y inPBOOLER1\<^bsub>(I)\<^esub> X"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i inTARSKIR2 unionMBOOLEANK2\<^bsub>(I)\<^esub> X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A7: "i inHIDDENR3 I"
      then have "A .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i & Y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        using A6 sorry
      then have "A .FUNCT-1K1 i inTARSKIR2 unionTARSKIK3 (X .FUNCT-1K1 i)"
        using tarski_def_4 sorry
      thus "A .FUNCT-1K1 i inTARSKIR2 unionMBOOLEANK2\<^bsub>(I)\<^esub> X .FUNCT-1K1 i"
        using A7 mboolean_def_2 sorry
    qed "sorry"
    thus "A inPBOOLER1\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> X"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_21:
" for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (EmptyMSPBOOLEK1 I .FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = {}XBOOLE-0K1"
        using pboole_th_5 zfmisc_1_th_2 sorry
      also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_22:
" for I be setHIDDENM2 holds  for x be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 unionTARSKIK3 x"
proof-
  have " for I be setHIDDENM2 holds  for x be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 unionTARSKIK3 x"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 unionTARSKIK3 x).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ((I -->FUNCOP-1K7 x).FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = unionTARSKIK3 x"
        using A1 funcop_1_th_7 sorry
      also have "... = (I -->FUNCOP-1K7 unionTARSKIK3 x).FUNCT-1K1 i"
        using A1 funcop_1_th_7 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 unionTARSKIK3 x).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 x) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 unionTARSKIK3 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_23:
" for x be objectHIDDENM1 holds  for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 x"
proof-
  have " for x be objectHIDDENM1 holds  for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 x"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix I assume [ty]: "I be setHIDDENM2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 x).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ((I -->FUNCOP-1K7 {TARSKIK1 x}).FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = unionTARSKIK3 {TARSKIK1 x}"
        using A1 funcop_1_th_7 sorry
      also have "... = x"
        using zfmisc_1_th_25 sorry
      also have "... = (I -->FUNCOP-1K7 x).FUNCT-1K1 i"
        using A1 funcop_1_th_7 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 x).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK1 x}) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_24:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for I be setHIDDENM2 holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix I assume [ty]: "I be setHIDDENM2"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 {TARSKIK2 x,y }).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 ((I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }).FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = unionTARSKIK3 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }"
        using A1 funcop_1_th_7 sorry
      also have "... = {TARSKIK2 x,y }"
        using zfmisc_1_th_26 sorry
      also have "... = (I -->FUNCOP-1K7 {TARSKIK2 x,y }).FUNCT-1K1 i"
        using A1 funcop_1_th_7 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }) .FUNCT-1K1 i =HIDDENR1 (I -->FUNCOP-1K7 {TARSKIK2 x,y }).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (I -->FUNCOP-1K7 {TARSKIK2 {TARSKIK1 x},{TARSKIK1 y} }) =PBOOLER7\<^bsub>(I)\<^esub> I -->FUNCOP-1K7 {TARSKIK2 x,y }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_25:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: "X inPBOOLER1\<^bsub>(I)\<^esub> A"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
        using A1 sorry
      then have "X .FUNCT-1K1 i c=TARSKIR1 unionTARSKIK3 (A .FUNCT-1K1 i)"
        using zfmisc_1_th_74 sorry
      thus "X .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
        using A2 mboolean_def_2 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_26:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "A c=PBOOLER2\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "A .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A1 sorry
      then have "unionTARSKIK3 (A .FUNCT-1K1 i) c=TARSKIR1 unionTARSKIK3 (B .FUNCT-1K1 i)"
        using zfmisc_1_th_77 sorry
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i c=TARSKIR1 unionTARSKIK3 (B .FUNCT-1K1 i)"
        using A2 mboolean_def_2 sorry
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A2 mboolean_def_2 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_27:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
        using mboolean_lm_6 sorry
      also have "... = unionTARSKIK3 (A .FUNCT-1K1 i) \\/XBOOLE-0K2 unionTARSKIK3 (B .FUNCT-1K1 i)"
        using zfmisc_1_th_78 sorry
      also have "... = unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i \\/XBOOLE-0K2 unionTARSKIK3 (B .FUNCT-1K1 i)"
        using A1 mboolean_def_2 sorry
      also have "... = unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i \\/XBOOLE-0K2 unionMBOOLEANK2\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A1 mboolean_def_2 sorry
      also have "... = (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =HIDDENR1 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_28:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i c=TARSKIR1 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have A2: "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i)"
        using mboolean_lm_7 sorry
      have "(unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =HIDDENR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i /\\XBOOLE-0K3 unionMBOOLEANK2\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = unionTARSKIK3 (A .FUNCT-1K1 i) /\\XBOOLE-0K3 unionMBOOLEANK2\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A1 mboolean_def_2 sorry
      also have "... = unionTARSKIK3 (A .FUNCT-1K1 i) /\\XBOOLE-0K3 unionTARSKIK3 (B .FUNCT-1K1 i)"
        using A1 mboolean_def_2 sorry
      finally have "(unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (A .FUNCT-1K1 i) /\\XBOOLE-0K3 unionTARSKIK3 (B .FUNCT-1K1 i)"
         sorry
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i c=TARSKIR1 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A2 zfmisc_1_th_79 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_29:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A) =PBOOLER7\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A) =PBOOLER7\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i =HIDDENR1 unionTARSKIK3 (boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i)"
        using mboolean_def_2 sorry
      also have "... = unionTARSKIK3 (boolZFMISC-1K1 (A .FUNCT-1K1 i))"
        using A1 mboolean_def_1 sorry
      also have "... = A .FUNCT-1K1 i"
        using zfmisc_1_th_81 sorry
      finally show "unionMBOOLEANK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (boolMBOOLEANK1\<^bsub>(I)\<^esub> A) =PBOOLER7\<^bsub>(I)\<^esub> A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_30:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A)"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i)"
        using mboolean_def_1 sorry
      also have "... = boolZFMISC-1K1 (unionTARSKIK3 (A .FUNCT-1K1 i))"
        using A1 mboolean_def_2 sorry
      finally have "boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i =HIDDENR1 boolZFMISC-1K1 (unionTARSKIK3 (A .FUNCT-1K1 i))"
         sorry
      thus "A .FUNCT-1K1 i c=TARSKIR1 boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A) .FUNCT-1K1 i"
        using zfmisc_1_th_82 sorry
    qed "sorry"
    thus "A c=PBOOLER2\<^bsub>(I)\<^esub> boolMBOOLEANK1\<^bsub>(I)\<^esub> (unionMBOOLEANK2\<^bsub>(I)\<^esub> A)"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_31:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A & X inPBOOLER1\<^bsub>(I)\<^esub> Y implies X c=PBOOLER2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A & X inPBOOLER1\<^bsub>(I)\<^esub> Y implies X c=PBOOLER2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "unionMBOOLEANK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> A"
      and A2: "X inPBOOLER1\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> Y .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using A1 sorry
      then have A4: "unionTARSKIK3 (Y .FUNCT-1K1 i) c=TARSKIR1 A .FUNCT-1K1 i"
        using A3 mboolean_def_2 sorry
      have "X .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
        using A2 A3 sorry
      thus "X .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using A4 setfam_1_th_41 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_32:
" for I be setHIDDENM2 holds  for Z be ManySortedSetPBOOLEM1-of I holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Z) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for Z be ManySortedSetPBOOLEM1-of I holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Z) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: " for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      have " for X9 be setHIDDENM2 holds X9 inTARSKIR2 A .FUNCT-1K1 i implies X9 c=TARSKIR1 Z .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        obtain M where
          [ty]:"M be ManySortedSetPBOOLEM1-of I" and 
          A3: "M inPBOOLER1\<^bsub>(I)\<^esub> A"
          using pboole_th_134 sorry
        fix X9 assume [ty]: "X9 be setHIDDENM2"
        assume A4: "X9 inTARSKIR2 A .FUNCT-1K1 i"
        have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)) =XBOOLE-0R4 I"
          using A2 mboolean_lm_1 sorry
        then obtain K where 
          [ty]:"K be ManySortedSetPBOOLEM1-of I" and KDef:"K = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)"
          using partfun1_def_2 relat_1_def_18 sorry
        have A5: "domRELAT-1K1 (i .-->FUNCOP-1K17 X9) =XBOOLE-0R4 {TARSKIK1 i}"
          using funcop_1_th_13 sorry
        have "i inHIDDENR3 {TARSKIK1 i}"
          using tarski_def_1 sorry
        then have A6: "K .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 X9).FUNCT-1K1 i"
          using A5 funct_4_th_13 sorry
        also have "... = X9"
          using funcop_1_th_72 sorry
        finally have "K .FUNCT-1K1 i =HIDDENR1 X9"
           sorry
        have "K inPBOOLER1\<^bsub>(I)\<^esub> A"
        proof-
          have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
          proof(rule ballI,rule impI)
            fix j assume [ty]: "j be objectHIDDENM1"
            assume A7: "j inHIDDENR3 I"
            have "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j)"
            proof-
              show "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j)"
              proof-
                have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                   sorry
                have case1: "j =HIDDENR1 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j =HIDDENR1 i"
                  thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A4 A6 sorry
                qed
                have case2: "j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j <>HIDDENR2 i"
                  then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 X9)"
                    using A5 tarski_def_1 sorry
                  then have "K .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                    using funct_4_th_11 sorry
                  thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A3 A7 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
               sorry
          qed "sorry"
          thus "K inPBOOLER1\<^bsub>(I)\<^esub> A"
            using pboole_def_1 sorry
        qed
        then have "K c=PBOOLER2\<^bsub>(I)\<^esub> Z"
          using A1 sorry
        thus "X9 c=TARSKIR1 Z .FUNCT-1K1 i"
          using A2 A6 sorry
      qed "sorry"
      then have "unionTARSKIK3 (A .FUNCT-1K1 i) c=TARSKIR1 Z .FUNCT-1K1 i"
        using zfmisc_1_th_76 sorry
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
        using A2 mboolean_def_2 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_33:
" for I be setHIDDENM2 holds  for B be ManySortedSetPBOOLEM1-of I holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for B be ManySortedSetPBOOLEM1-of I holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: " for X be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      have " for X9 be setHIDDENM2 holds X9 inTARSKIR2 A .FUNCT-1K1 i implies X9 missesXBOOLE-0R1 B .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        obtain M where
          [ty]:"M be ManySortedSetPBOOLEM1-of I" and 
          A3: "M inPBOOLER1\<^bsub>(I)\<^esub> A"
          using pboole_th_134 sorry
        fix X9 assume [ty]: "X9 be setHIDDENM2"
        assume A4: "X9 inTARSKIR2 A .FUNCT-1K1 i"
        have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)) =XBOOLE-0R4 I"
          using A2 mboolean_lm_1 sorry
        then obtain K where 
          [ty]:"K be ManySortedSetPBOOLEM1-of I" and KDef:"K = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)"
          using partfun1_def_2 relat_1_def_18 sorry
        have A5: "domRELAT-1K1 (i .-->FUNCOP-1K17 X9) =XBOOLE-0R4 {TARSKIK1 i}"
          using funcop_1_th_13 sorry
        have "i inHIDDENR3 {TARSKIK1 i}"
          using tarski_def_1 sorry
        then have A6: "K .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 X9).FUNCT-1K1 i"
          using A5 funct_4_th_13 sorry
        also have "... = X9"
          using funcop_1_th_72 sorry
        finally have "K .FUNCT-1K1 i =HIDDENR1 X9"
           sorry
        have "K inPBOOLER1\<^bsub>(I)\<^esub> A"
        proof-
          have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
          proof(rule ballI,rule impI)
            fix j assume [ty]: "j be objectHIDDENM1"
            assume A7: "j inHIDDENR3 I"
            have "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j)"
            proof-
              show "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j)"
              proof-
                have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                   sorry
                have case1: "j =HIDDENR1 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j =HIDDENR1 i"
                  thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A4 A6 sorry
                qed
                have case2: "j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j <>HIDDENR2 i"
                  then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 X9)"
                    using A5 tarski_def_1 sorry
                  then have "K .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                    using funct_4_th_11 sorry
                  thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A3 A7 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
               sorry
          qed "sorry"
          thus "K inPBOOLER1\<^bsub>(I)\<^esub> A"
            using pboole_def_1 sorry
        qed
        then have "K (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
          using A1 sorry
        then have "K .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
          using A2 pboole_def_5 sorry
        then have "X9 /\\XBOOLE-0K3 B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
          using A6 pboole_th_5 sorry
        thus "X9 missesXBOOLE-0R1 B .FUNCT-1K1 i"
          using xboole_0_def_7 sorry
      qed "sorry"
      then have "unionTARSKIK3 (A .FUNCT-1K1 i) missesXBOOLE-0R1 B .FUNCT-1K1 i"
        using zfmisc_1_th_80 sorry
      then have "unionTARSKIK3 (A .FUNCT-1K1 i) /\\XBOOLE-0K3 B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_0_def_7 sorry
      then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
        using A2 mboolean_def_2 sorry
      then have "(unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
        using A2 pboole_def_5 sorry
      thus "(unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_34:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B be non-emptyRELAT-1V2 & ( for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X <>HIDDENR2 Y & X inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) & Y inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B be non-emptyRELAT-1V2 implies (( for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X <>HIDDENR2 Y & X inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) & Y inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B be non-emptyRELAT-1V2"
    assume A2: " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X <>HIDDENR2 Y & X inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) & Y inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      have " for X9 be setHIDDENM2 holds  for Y9 be setHIDDENM2 holds (X9 <>HIDDENR2 Y9 & X9 inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i) & Y9 inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i implies X9 missesXBOOLE-0R1 Y9"
      proof-
        have " for X9 be setHIDDENM2 holds  for Y9 be setHIDDENM2 holds X9 <>HIDDENR2 Y9 & (X9 inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i & Y9 inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i) implies X9 missesXBOOLE-0R1 Y9"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          obtain M where
            [ty]:"M be ManySortedSetPBOOLEM1-of I" and 
            A4: "M inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
            using A1 pboole_th_134 sorry
          have A5: "i inHIDDENR3 {TARSKIK1 i}"
            using tarski_def_1 sorry
          fix X9 assume [ty]: "X9 be setHIDDENM2"
          fix Y9 assume [ty]: "Y9 be setHIDDENM2"
          assume A6: "X9 <>HIDDENR2 Y9"
            and A7: "X9 inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i"
            and A8: "Y9 inTARSKIR2 A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i"
          have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)) =XBOOLE-0R4 I & domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 Y9)) =XBOOLE-0R4 I"
            using A3 mboolean_lm_1 sorry
          then obtain Kx Ky where 
            [ty]:"Kx be ManySortedSetPBOOLEM1-of I" and KxDef:"Kx = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)" and
            [ty]:"Ky be ManySortedSetPBOOLEM1-of I" and KyDef:"Ky = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 Y9)"
            using partfun1_def_2 relat_1_def_18 sorry
          have A9: "domRELAT-1K1 (i .-->FUNCOP-1K17 Y9) =XBOOLE-0R4 {TARSKIK1 i}"
            using funcop_1_th_13 sorry
          then have A10: "Ky .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 Y9).FUNCT-1K1 i"
            using A5 funct_4_th_13 sorry
          also have "... = Y9"
            using funcop_1_th_72 sorry
          finally have "Ky .FUNCT-1K1 i =HIDDENR1 Y9"
             sorry
          have A11: "Ky inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
          proof-
            have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
            proof(rule ballI,rule impI)
              fix j assume [ty]: "j be objectHIDDENM1"
              assume A12: "j inHIDDENR3 I"
              have "Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
              proof-
                show "Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                proof-
                  have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                     sorry
                  have case1: "j =HIDDENR1 i implies Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                  proof(rule impI)
                    assume "j =HIDDENR1 i"
                    thus "Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                      using A8 A10 A12 pboole_def_4 sorry
                  qed
                  have case2: "j <>HIDDENR2 i implies Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                  proof(rule impI)
                    assume "j <>HIDDENR2 i"
                    then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 Y9)"
                      using A9 tarski_def_1 sorry
                    then have "Ky .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                      using funct_4_th_11 sorry
                    thus "Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                      using A4 A12 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "Ky .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                 sorry
            qed "sorry"
            thus "Ky inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
              using pboole_def_1 sorry
          qed
          have A13: "domRELAT-1K1 (i .-->FUNCOP-1K17 X9) =XBOOLE-0R4 {TARSKIK1 i}"
            using funcop_1_th_13 sorry
          then have A14: "Kx .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 X9).FUNCT-1K1 i"
            using A5 funct_4_th_13 sorry
          also have "... = X9"
            using funcop_1_th_72 sorry
          finally have "Kx .FUNCT-1K1 i =HIDDENR1 X9"
             sorry
          have "Kx inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
          proof-
            have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
            proof(rule ballI,rule impI)
              fix j assume [ty]: "j be objectHIDDENM1"
              assume A15: "j inHIDDENR3 I"
              have "j =HIDDENR1 i & Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j)"
              proof-
                show "j =HIDDENR1 i & Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j)"
                proof-
                  have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                     sorry
                  have case1: "j =HIDDENR1 i implies Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                  proof(rule impI)
                    assume "j =HIDDENR1 i"
                    thus "Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                      using A7 A14 A15 pboole_def_4 sorry
                  qed
                  have case2: "j <>HIDDENR2 i implies Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                  proof(rule impI)
                    assume "j <>HIDDENR2 i"
                    then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 X9)"
                      using A13 tarski_def_1 sorry
                    then have "Kx .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                      using funct_4_th_11 sorry
                    thus "Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                      using A4 A15 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "Kx .FUNCT-1K1 j inTARSKIR2 (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 j"
                 sorry
            qed "sorry"
            thus "Kx inPBOOLER1\<^bsub>(I)\<^esub> A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B"
              using pboole_def_1 sorry
          qed
          then have "Kx (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Ky =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
            using A2 A6 A14 A10 A11 sorry
          then have "(Kx (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Ky).FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
            using pboole_th_5 sorry
          then have "X9 /\\XBOOLE-0K3 Y9 =XBOOLE-0R4 {}XBOOLE-0K1"
            using A3 A14 A10 pboole_def_5 sorry
          thus "X9 missesXBOOLE-0R1 Y9"
            using xboole_0_def_7 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i) =XBOOLE-0R4 unionTARSKIK3 (A .FUNCT-1K1 i) /\\XBOOLE-0K3 unionTARSKIK3 (B .FUNCT-1K1 i)"
        using zfmisc_1_th_83 sorry
      then have "unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i) =XBOOLE-0R4 unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i /\\XBOOLE-0K3 unionTARSKIK3 (B .FUNCT-1K1 i)"
        using A3 mboolean_def_2 sorry
      then have "unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i) =XBOOLE-0R4 unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i /\\XBOOLE-0K3 unionMBOOLEANK2\<^bsub>(I)\<^esub> B .FUNCT-1K1 i"
        using A3 mboolean_def_2 sorry
      then have "unionTARSKIK3 (A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i) =XBOOLE-0R4 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A3 pboole_def_5 sorry
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i =XBOOLE-0R4 (unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i"
        using A3 mboolean_lm_7 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B) =PBOOLER7\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_35:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) & ( for Y be ManySortedSetPBOOLEM1-of I holds Y inPBOOLER1\<^bsub>(I)\<^esub> B implies Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) & ( for Y be ManySortedSetPBOOLEM1-of I holds Y inPBOOLER1\<^bsub>(I)\<^esub> B implies Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B)"
      and A2: " for Y be ManySortedSetPBOOLEM1-of I holds Y inPBOOLER1\<^bsub>(I)\<^esub> B implies Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      have A4: " for Y9 be setHIDDENM2 holds Y9 inTARSKIR2 B .FUNCT-1K1 i implies Y9 missesXBOOLE-0R1 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        obtain M where
          [ty]:"M be ManySortedSetPBOOLEM1-of I" and 
          A5: "M inPBOOLER1\<^bsub>(I)\<^esub> B"
          using pboole_th_134 sorry
        fix Y9 assume [ty]: "Y9 be setHIDDENM2"
        assume A6: "Y9 inTARSKIR2 B .FUNCT-1K1 i"
        have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 Y9)) =XBOOLE-0R4 I"
          using A3 mboolean_lm_1 sorry
        then obtain K where 
          [ty]:"K be ManySortedSetPBOOLEM1-of I" and KDef:"K = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 Y9)"
          using partfun1_def_2 relat_1_def_18 sorry
        have A7: "domRELAT-1K1 (i .-->FUNCOP-1K17 Y9) =XBOOLE-0R4 {TARSKIK1 i}"
          using funcop_1_th_13 sorry
        have "i inHIDDENR3 {TARSKIK1 i}"
          using tarski_def_1 sorry
        then have A8: "K .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 Y9).FUNCT-1K1 i"
          using A7 funct_4_th_13 sorry
        also have "... = Y9"
          using funcop_1_th_72 sorry
        finally have "K .FUNCT-1K1 i =HIDDENR1 Y9"
           sorry
        have "K inPBOOLER1\<^bsub>(I)\<^esub> B"
        proof-
          have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j"
          proof(rule ballI,rule impI)
            fix j assume [ty]: "j be objectHIDDENM1"
            assume A9: "j inHIDDENR3 I"
            have "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j)"
            proof-
              show "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j)"
              proof-
                have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                   sorry
                have case1: "j =HIDDENR1 i implies K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j =HIDDENR1 i"
                  thus "K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j"
                    using A6 A8 sorry
                qed
                have case2: "j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j <>HIDDENR2 i"
                  then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 Y9)"
                    using A7 tarski_def_1 sorry
                  then have "K .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                    using funct_4_th_11 sorry
                  thus "K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j"
                    using A5 A9 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "K .FUNCT-1K1 j inTARSKIR2 B .FUNCT-1K1 j"
               sorry
          qed "sorry"
          thus "K inPBOOLER1\<^bsub>(I)\<^esub> B"
            using pboole_def_1 sorry
        qed
        then have "K (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
          using A2 sorry
        then have "(K (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
          using pboole_th_5 sorry
        then have "Y9 /\\XBOOLE-0K3 X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
          using A3 A8 pboole_def_5 sorry
        thus "Y9 missesXBOOLE-0R1 X .FUNCT-1K1 i"
          using xboole_0_def_7 sorry
      qed "sorry"
      have "X .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B) .FUNCT-1K1 i"
        using A1 A3 sorry
      then have "X .FUNCT-1K1 i c=TARSKIR1 unionTARSKIK3 (A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i)"
        using A3 mboolean_lm_6 sorry
      then have "X .FUNCT-1K1 i c=TARSKIR1 unionTARSKIK3 (A .FUNCT-1K1 i)"
        using A4 setfam_1_th_42 sorry
      thus "X .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i"
        using A3 mboolean_def_2 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mboolean_th_36:
" for I be setHIDDENM2 holds  for A be finite-yieldingFINSET-1V3\<bar>non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A & Y inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y or Y c=PBOOLER2\<^bsub>(I)\<^esub> X) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A inPBOOLER1\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be finite-yieldingFINSET-1V3\<bar>non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A & Y inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y or Y c=PBOOLER2\<^bsub>(I)\<^esub> X) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A inPBOOLER1\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be finite-yieldingFINSET-1V3\<bar>non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X inPBOOLER1\<^bsub>(I)\<^esub> A & Y inPBOOLER1\<^bsub>(I)\<^esub> A implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y or Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "i inHIDDENR3 domRELAT-1K1 A"
        using partfun1_def_2 sorry
      then have "A .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 A"
        using funct_1_th_3 sorry
      then have A3: "A .FUNCT-1K1 i be finiteFINSET-1V1"
        using finset_1_def_2 sorry
      have A4: " for X9 be setHIDDENM2 holds  for Y9 be setHIDDENM2 holds X9 inTARSKIR2 A .FUNCT-1K1 i & Y9 inTARSKIR2 A .FUNCT-1K1 i implies X9 c=TARSKIR1 Y9 or Y9 c=TARSKIR1 X9"
      proof-
        have " for X9 be setHIDDENM2 holds  for Y9 be setHIDDENM2 holds X9 inTARSKIR2 A .FUNCT-1K1 i & Y9 inTARSKIR2 A .FUNCT-1K1 i implies ( not X9 c=TARSKIR1 Y9 implies Y9 c=TARSKIR1 X9)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
          fix X9 assume [ty]: "X9 be setHIDDENM2"
          fix Y9 assume [ty]: "Y9 be setHIDDENM2"
          assume A5: "X9 inTARSKIR2 A .FUNCT-1K1 i"
            and A6: "Y9 inTARSKIR2 A .FUNCT-1K1 i"
          obtain M where
            [ty]:"M be ManySortedSetPBOOLEM1-of I" and 
            A7: "M inPBOOLER1\<^bsub>(I)\<^esub> A"
            using pboole_th_134 sorry
          have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 Y9)) =XBOOLE-0R4 I & domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)) =XBOOLE-0R4 I"
            using A2 mboolean_lm_1 sorry
          then obtain K1 K2 where 
            [ty]:"K1 be ManySortedSetPBOOLEM1-of I" and K1Def:"K1 = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)" and
            [ty]:"K2 be ManySortedSetPBOOLEM1-of I" and K2Def:"K2 = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 Y9)"
            using partfun1_def_2 relat_1_def_18 sorry
          assume A8: " not X9 c=TARSKIR1 Y9"
          have A9: "i inHIDDENR3 {TARSKIK1 i}"
            using tarski_def_1 sorry
          have A10: "domRELAT-1K1 (i .-->FUNCOP-1K17 Y9) =XBOOLE-0R4 {TARSKIK1 i}"
            using funcop_1_th_13 sorry
          then have A11: "K2 .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 Y9).FUNCT-1K1 i"
            using A9 funct_4_th_13 sorry
          also have "... = Y9"
            using funcop_1_th_72 sorry
          finally have "K2 .FUNCT-1K1 i =HIDDENR1 Y9"
             sorry
          have A12: "K2 inPBOOLER1\<^bsub>(I)\<^esub> A"
          proof-
            have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K2 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
            proof(rule ballI,rule impI)
              fix j assume [ty]: "j be objectHIDDENM1"
              assume A13: "j inHIDDENR3 I"
              show "K2 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
              proof-
                have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                   sorry
                have case1: "j =HIDDENR1 i implies K2 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j =HIDDENR1 i"
                  thus "K2 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A6 A11 sorry
                qed
                have case2: "j <>HIDDENR2 i implies K2 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j <>HIDDENR2 i"
                  then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 Y9)"
                    using A10 tarski_def_1 sorry
                  then have "K2 .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                    using funct_4_th_11 sorry
                  thus "K2 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A7 A13 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "K2 inPBOOLER1\<^bsub>(I)\<^esub> A"
              using pboole_def_1 sorry
          qed
          have A14: "domRELAT-1K1 (i .-->FUNCOP-1K17 X9) =XBOOLE-0R4 {TARSKIK1 i}"
            using funcop_1_th_13 sorry
          then have A15: "K1 .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 X9).FUNCT-1K1 i"
            using A9 funct_4_th_13 sorry
          also have "... = X9"
            using funcop_1_th_72 sorry
          finally have "K1 .FUNCT-1K1 i =HIDDENR1 X9"
             sorry
          have "K1 inPBOOLER1\<^bsub>(I)\<^esub> A"
          proof-
            have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K1 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
            proof(rule ballI,rule impI)
              fix j assume [ty]: "j be objectHIDDENM1"
              assume A16: "j inHIDDENR3 I"
              show "K1 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
              proof-
                have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                   sorry
                have case1: "j =HIDDENR1 i implies K1 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j =HIDDENR1 i"
                  thus "K1 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A5 A15 sorry
                qed
                have case2: "j <>HIDDENR2 i implies K1 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j <>HIDDENR2 i"
                  then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 X9)"
                    using A14 tarski_def_1 sorry
                  then have "K1 .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                    using funct_4_th_11 sorry
                  thus "K1 .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A7 A16 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "K1 inPBOOLER1\<^bsub>(I)\<^esub> A"
              using pboole_def_1 sorry
          qed
          then have "K1 c=PBOOLER2\<^bsub>(I)\<^esub> K2 or K2 c=PBOOLER2\<^bsub>(I)\<^esub> K1"
            using A1 A12 sorry
          thus "Y9 c=TARSKIR1 X9"
            using A2 A8 A15 A11 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "A .FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
        using A2 pboole_def_13 sorry
      then have "unionTARSKIK3 (A .FUNCT-1K1 i) inTARSKIR2 A .FUNCT-1K1 i"
        using A3 A4 card_2_th_62 sorry
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
        using A2 mboolean_def_2 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A inPBOOLER1\<^bsub>(I)\<^esub> A"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
