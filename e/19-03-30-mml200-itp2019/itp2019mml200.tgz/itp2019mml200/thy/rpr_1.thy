theory rpr_1
  imports real_1 finseq_1 membered
   "../mizar_extension/E_number"
begin
(*begin*)
reserve E for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve a for "ElementSUBSET-1M1-of E"
reserve A, B for "SubsetSUBSET-1M2-of E"
reserve Y for "setHIDDENM2"
reserve p for "FinSequenceFINSEQ-1M1"
mtheorem rpr_1_th_1:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of E holds e be SingletonCARD-1M2-of E iff ( for Y be setHIDDENM2 holds Y c=TARSKIR1 e iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 e)"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of E holds (e be SingletonCARD-1M2-of E implies ( for Y be setHIDDENM2 holds Y c=TARSKIR1 e iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 e)) & (( for Y be setHIDDENM2 holds Y c=TARSKIR1 e iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 e) implies e be SingletonCARD-1M2-of E)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of E"
    show "e be SingletonCARD-1M2-of E implies ( for Y be setHIDDENM2 holds Y c=TARSKIR1 e iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 e)"
    proof-
      have "e be SingletonCARD-1M2-of E implies ( for Y be setHIDDENM2 holds  not ((Y c=TARSKIR1 e &  not Y =XBOOLE-0R4 {}XBOOLE-0K1) &  not Y =XBOOLE-0R4 e) &  not ( not ( not Y =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 e) &  not Y c=TARSKIR1 e))"
      proof(rule impI,rule ballI)
        assume A1: "e be SingletonCARD-1M2-of E"
        fix Y assume [ty]: "Y be setHIDDENM2"
        have " ex x be objectHIDDENM1 st e =XBOOLE-0R4 {TARSKIK1 x}"
          using A1 zfmisc_1_th_131 sorry
        thus " not ((Y c=TARSKIR1 e &  not Y =XBOOLE-0R4 {}XBOOLE-0K1) &  not Y =XBOOLE-0R4 e) &  not ( not ( not Y =XBOOLE-0R4 {}XBOOLE-0K1 &  not Y =XBOOLE-0R4 e) &  not Y c=TARSKIR1 e)"
          using zfmisc_1_th_33 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A2: " for Y be setHIDDENM2 holds Y c=TARSKIR1 e iff Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y =XBOOLE-0R4 e"
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A3: "x inHIDDENR3 e"
      using xboole_0_def_1 sorry
    have "{TARSKIK1 x} c=TARSKIR1 e"
      using A3 zfmisc_1_th_31 sorry
    thus "e be SingletonCARD-1M2-of E"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_cl_1:
  mlet "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for SingletonCARD-1M2-of E"
proof
(*coherence*)
  show " for it be SingletonCARD-1M2-of E holds it be finiteFINSET-1V1"
     sorry
qed "sorry"

reserve e, e1, e2 for "SingletonCARD-1M2-of E"
mtheorem rpr_1_th_2:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for e be SingletonCARD-1M2-of E holds e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B & A <>HIDDENR2 B implies A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e or A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for e be SingletonCARD-1M2-of E holds e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B & A <>HIDDENR2 B implies  not ( not (A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e) &  not (A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix e assume [ty]: "e be SingletonCARD-1M2-of E"
    assume A1: "e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B"
      and A2: "A <>HIDDENR2 B"
    have "A c=TARSKIR1 e"
      using A1 xboole_1_th_7 sorry
    then have A3: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A =XBOOLE-0R4 e"
      using rpr_1_th_1 sorry
    have "B c=TARSKIR1 e"
      using A1 xboole_1_th_7 sorry
    thus " not ( not (A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e) &  not (A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1))"
      using A2 A3 rpr_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_3:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for e be SingletonCARD-1M2-of E holds e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B implies (A =XBOOLE-0R4 e & B =XBOOLE-0R4 e or A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1) or A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds  for e be SingletonCARD-1M2-of E holds e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B implies  not (( not (A =XBOOLE-0R4 e & B =XBOOLE-0R4 e) &  not (A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1)) &  not (A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    fix e assume [ty]: "e be SingletonCARD-1M2-of E"
    assume A1: "e =XBOOLE-0R4 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B"
    then have "A c=TARSKIR1 e & B c=TARSKIR1 e"
      using xboole_1_th_7 sorry
    then have "((A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e or A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1) or A =XBOOLE-0R4 e & B =XBOOLE-0R4 e) or A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 {}XBOOLE-0K1"
      using rpr_1_th_1 sorry
    thus " not (( not (A =XBOOLE-0R4 e & B =XBOOLE-0R4 e) &  not (A =XBOOLE-0R4 e & B =XBOOLE-0R4 {}XBOOLE-0K1)) &  not (A =XBOOLE-0R4 {}XBOOLE-0K1 & B =XBOOLE-0R4 e))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_4:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be ElementSUBSET-1M1-of E holds {DOMAIN-1K6\<^bsub>(E)\<^esub> a} be SingletonCARD-1M2-of E"
   sorry

mtheorem rpr_1_th_5:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e1 be SingletonCARD-1M2-of E holds  for e2 be SingletonCARD-1M2-of E holds e1 c=TARSKIR1 e2 implies e1 =XBOOLE-0R4 e2"
  using rpr_1_th_1 sorry

mtheorem rpr_1_th_6:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  ex a be ElementSUBSET-1M1-of E st a inTARSKIR2 E & e =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a}"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  not ( for a be ElementSUBSET-1M1-of E holds  not (a inTARSKIR2 E & e =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a}))"
  proof(rule ballI,rule ballI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be SingletonCARD-1M2-of E"
    let ?x = "the ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of e"
    have "{DOMAIN-1K6\<^bsub>(e)\<^esub> ?x} =XBOOLE-0R4 e"
      using rpr_1_th_1 sorry
    thus " not ( for a be ElementSUBSET-1M1-of E holds  not (a inTARSKIR2 E & e =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a}))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_7:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex e be SingletonCARD-1M2-of E st e be SingletonCARD-1M2-of E"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex tVar1 be SingletonCARD-1M2-of E st tVar1 be SingletonCARD-1M2-of E"
  proof(rule ballI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    show " ex tVar1 be SingletonCARD-1M2-of E st tVar1 be SingletonCARD-1M2-of E"
    proof(rule bexI[of _ "{DOMAIN-1K6\<^bsub>(E)\<^esub> the ElementSUBSET-1M1-of E }"])
      show "{DOMAIN-1K6\<^bsub>(E)\<^esub> the ElementSUBSET-1M1-of E } be SingletonCARD-1M2-of E"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_8:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  ex p be FinSequenceFINSEQ-1M1 st (p be FinSequenceFINSEQ-1M3-of E & rngFUNCT-1K2 p =XBOOLE-0R4 e) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  not ( for p be FinSequenceFINSEQ-1M1 holds  not ((p be FinSequenceFINSEQ-1M3-of E & rngFUNCT-1K2 p =XBOOLE-0R4 e) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be SingletonCARD-1M2-of E"
    obtain a where
      [ty]:"a be ElementSUBSET-1M1-of E" and 
      "a inTARSKIR2 E"and A1: "e =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a}"
      using rpr_1_th_6 sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(E)\<^esub> a*>) =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a} & lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(E)\<^esub> a*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_39 sorry
    thus " not ( for p be FinSequenceFINSEQ-1M1 holds  not ((p be FinSequenceFINSEQ-1M3-of E & rngFUNCT-1K2 p =XBOOLE-0R4 e) & lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RPR_1M1("EventRPR-1M1-of  _ " [70]70) where
  "EventRPR-1M1-of E \<equiv> SubsetSUBSET-1M2-of E"

mtheorem rpr_1_th_9:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  for A be EventRPR-1M1-of E holds e missesXBOOLE-0R1 A or e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 e"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  for A be EventRPR-1M1-of E holds  not ( not e missesXBOOLE-0R1 A &  not e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 e)"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be SingletonCARD-1M2-of E"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    have "e /\\SUBSET-1K8\<^bsub>(E)\<^esub> E =XBOOLE-0R4 e & A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> =XBOOLE-0R4 [#]SUBSET-1K2 E"
      using subset_1_th_10 xboole_1_th_28 sorry
    then have "e =XBOOLE-0R4 e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A \\/SUBSET-1K4\<^bsub>(E)\<^esub> e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using xboole_1_th_23 sorry
    then have "e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A c=TARSKIR1 e"
      using xboole_1_th_7 sorry
    then have "e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 or e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 e"
      using rpr_1_th_1 sorry
    thus " not ( not e missesXBOOLE-0R1 A &  not e /\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 e)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_10:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds A <>HIDDENR2 {}XBOOLE-0K1 implies ( ex e be SingletonCARD-1M2-of E st e c=TARSKIR1 A)"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds A <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for e be SingletonCARD-1M2-of E holds  not e c=TARSKIR1 A)"
  proof(rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    let ?x = "the ElementSUBSET-1M1-of A"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where 
      [ty]:"x be ElementSUBSET-1M1-of E" and xDef:"x = ?x"
      using tarski_def_3 sorry
    have "{DOMAIN-1K6\<^bsub>(E)\<^esub> x} c=TARSKIR1 A"
      using A1 zfmisc_1_th_31 sorry
    thus " not ( for e be SingletonCARD-1M2-of E holds  not e c=TARSKIR1 A)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_11:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  for A be EventRPR-1M1-of E holds e c=TARSKIR1 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> implies e c=TARSKIR1 A or e c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds  for A be EventRPR-1M1-of E holds e c=TARSKIR1 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> implies  not ( not e c=TARSKIR1 A &  not e c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be SingletonCARD-1M2-of E"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    have " ex a be ElementSUBSET-1M1-of E st a inTARSKIR2 E & e =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a}"
      using rpr_1_th_6 sorry
    then obtain a where
      [ty]:"a be ElementSUBSET-1M1-of E" and 
      A1: "e =XBOOLE-0R4 {DOMAIN-1K6\<^bsub>(E)\<^esub> a}"
       sorry
    assume "e c=TARSKIR1 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>"
    then have "a inTARSKIR2 A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using A1 zfmisc_1_th_31 sorry
    then have "a inTARSKIR2 A or a inTARSKIR2 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using xboole_0_def_3 sorry
    thus " not ( not e c=TARSKIR1 A &  not e c=TARSKIR1 A `SUBSET-1K3\<^bsub>(E)\<^esub>)"
      using A1 zfmisc_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_12:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e1 be SingletonCARD-1M2-of E holds  for e2 be SingletonCARD-1M2-of E holds e1 =XBOOLE-0R4 e2 or e1 missesSUBSET-1R1 e2"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e1 be SingletonCARD-1M2-of E holds  for e2 be SingletonCARD-1M2-of E holds  not ( not e1 =XBOOLE-0R4 e2 &  not e1 missesSUBSET-1R1 e2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e1 assume [ty]: "e1 be SingletonCARD-1M2-of E"
    fix e2 assume [ty]: "e2 be SingletonCARD-1M2-of E"
    have "e1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> e2 c=TARSKIR1 e1"
      using xboole_1_th_17 sorry
    then have "e1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> e2 =XBOOLE-0R4 {}XBOOLE-0K1 or e1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> e2 =XBOOLE-0R4 e1"
      using rpr_1_th_1 sorry
    then have "e1 c=TARSKIR1 e2 or e1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> e2 =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_1_th_17 sorry
    thus " not ( not e1 =XBOOLE-0R4 e2 &  not e1 missesSUBSET-1R1 e2)"
      using rpr_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_13:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B missesXBOOLE-0R1 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of E holds  for B be SubsetSUBSET-1M2-of E holds A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B missesXBOOLE-0R1 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of E"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of E"
    have "A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B missesXBOOLE-0R1 A \\SUBSET-1K7\<^bsub>(E)\<^esub> B"
      using xboole_1_th_89 sorry
    thus "A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B missesXBOOLE-0R1 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using subset_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rpr_1_lm_1:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds 0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 E"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not 0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 E"
  proof(rule ballI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have "cardCARD-1K4 {DOMAIN-1K6\<^bsub>(E)\<^esub> the ElementSUBSET-1M1-of E } <=XXREAL-0R1 cardCARD-1K4 E"
      using nat_1_th_43 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 E"
      using card_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rpr_1_def_1 ("probRPR-1K1\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2", "A be EventRPR-1M1-of E"
"func probRPR-1K1\<^bsub>(E)\<^esub> A \<rightarrow> RealXREAL-0M1 equals
  cardCARD-1K4 A /XCMPLX-0K7 cardCARD-1K4 E"
proof-
  (*coherence*)
    show "cardCARD-1K4 A /XCMPLX-0K7 cardCARD-1K4 E be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rpr_1_th_14:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be SingletonCARD-1M2-of E holds probRPR-1K1\<^bsub>(E)\<^esub> e =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 cardCARD-1K4 E"
  using card_1_def_7 sorry

mtheorem rpr_1_th_15:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds probRPR-1K1\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =HIDDENR1 \<one>\<^sub>M"
  using xcmplx_1_th_60 sorry

mtheorem rpr_1_th_16:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B implies probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 0NUMBERSK6"
  using card_1_th_27 sorry

mtheorem rpr_1_th_17:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A <=XXREAL-0R1 \<one>\<^sub>M"
proof(rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  have "0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 E"
    using rpr_1_lm_1 sorry
  then have "cardCARD-1K4 A *XCMPLX-0K3 (cardCARD-1K4 E)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 cardCARD-1K4 E *XCMPLX-0K3 (cardCARD-1K4 E)\<inverse>XCMPLX-0K5"
    using nat_1_th_43 xreal_1_th_64 sorry
  then have "cardCARD-1K4 A /XCMPLX-0K7 cardCARD-1K4 E <=XXREAL-0R1 cardCARD-1K4 E *XCMPLX-0K3 (cardCARD-1K4 E)\<inverse>XCMPLX-0K5"
    using xcmplx_0_def_9 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =HIDDENR1 cardCARD-1K4 E /XCMPLX-0K7 cardCARD-1K4 E & probRPR-1K1\<^bsub>(E)\<^esub> A <=XXREAL-0R1 cardCARD-1K4 E /XCMPLX-0K7 cardCARD-1K4 E"
    using xcmplx_0_def_9 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A <=XXREAL-0R1 \<one>\<^sub>M"
    using xcmplx_1_th_60 sorry
qed "sorry"

mtheorem rpr_1_th_18:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds 0NUMBERSK6 <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> A"
proof(rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  have "0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 E & 0NUMBERSK6 <=XXREAL-0R1 cardCARD-1K4 A"
    using rpr_1_lm_1 card_1_th_27 sorry
  thus "0NUMBERSK6 <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> A"
     sorry
qed "sorry"

mtheorem rpr_1_th_19:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A c=TARSKIR1 B implies probRPR-1K1\<^bsub>(E)\<^esub> A <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> B"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "A c=TARSKIR1 B"
  have "0NUMBERSK6 <XXREAL-0R3 cardCARD-1K4 E"
    using rpr_1_lm_1 sorry
  then have "cardCARD-1K4 A *XCMPLX-0K3 (cardCARD-1K4 E)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 cardCARD-1K4 B *XCMPLX-0K3 (cardCARD-1K4 E)\<inverse>XCMPLX-0K5"
    using A1 nat_1_th_43 xreal_1_th_64 sorry
  then have "cardCARD-1K4 A /XCMPLX-0K7 cardCARD-1K4 E <=XXREAL-0R1 cardCARD-1K4 B *XCMPLX-0K3 (cardCARD-1K4 E)\<inverse>XCMPLX-0K5"
    using xcmplx_0_def_9 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using xcmplx_0_def_9 sorry
qed "sorry"

mtheorem rpr_1_th_20:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
proof(rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  let ?q = "(cardCARD-1K4 E)\<inverse>XCMPLX-0K5"
  let ?p = "cardCARD-1K4 E"
  have "cardCARD-1K4 (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =XBOOLE-0R4 (cardCARD-1K4 A +XCMPLX-0K2 cardCARD-1K4 B)-XCMPLX-0K6 cardCARD-1K4 (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using card_2_th_45 sorry
  then have "cardCARD-1K4 (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) *XCMPLX-0K3 ?q =XBOOLE-0R4 cardCARD-1K4 A *XCMPLX-0K3 ?q +XCMPLX-0K2 (cardCARD-1K4 B *XCMPLX-0K3 ?q -XCMPLX-0K6 cardCARD-1K4 (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) *XCMPLX-0K3 ?q)"
     sorry
  then have "cardCARD-1K4 (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) /XCMPLX-0K7 ?p =XBOOLE-0R4 (cardCARD-1K4 A *XCMPLX-0K3 ?q +XCMPLX-0K2 cardCARD-1K4 B *XCMPLX-0K3 ?q)-XCMPLX-0K6 cardCARD-1K4 (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) *XCMPLX-0K3 ?q"
    using xcmplx_0_def_9 sorry
  then have "cardCARD-1K4 (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) /XCMPLX-0K7 ?p =XBOOLE-0R4 (cardCARD-1K4 A /XCMPLX-0K7 ?p +XCMPLX-0K2 cardCARD-1K4 B *XCMPLX-0K3 ?q)-XCMPLX-0K6 cardCARD-1K4 (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) *XCMPLX-0K3 ?q"
    using xcmplx_0_def_9 sorry
  then have "cardCARD-1K4 (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) /XCMPLX-0K7 ?p =XBOOLE-0R4 (cardCARD-1K4 A /XCMPLX-0K7 ?p +XCMPLX-0K2 cardCARD-1K4 B /XCMPLX-0K7 ?p)-XCMPLX-0K6 cardCARD-1K4 (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) *XCMPLX-0K3 ?q"
    using xcmplx_0_def_9 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using xcmplx_0_def_9 sorry
qed "sorry"

mtheorem rpr_1_th_21:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B implies probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume "A missesXBOOLE-0R1 B"
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 0NUMBERSK6"
    using rpr_1_th_16 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)-XCMPLX-0K6 0NUMBERSK6"
    using rpr_1_th_20 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B"
     sorry
qed "sorry"

mtheorem rpr_1_th_22:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> & probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A"
proof(rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  have "A missesXBOOLE-0R1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
    using subset_1_th_24 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>"
    using rpr_1_th_21 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>"
    using subset_1_th_10 sorry
  then have "\<one>\<^sub>M =XBOOLE-0R4 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>"
    using xcmplx_1_th_60 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> & probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A"
     sorry
qed "sorry"

mtheorem rpr_1_th_23:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
proof(rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> ((A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using xboole_1_th_51 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_21 xboole_1_th_89 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
     sorry
qed "sorry"

mtheorem rpr_1_th_24:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds B c=TARSKIR1 A implies probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume "B c=TARSKIR1 A"
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using xboole_1_th_28 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using rpr_1_th_23 sorry
qed "sorry"

mtheorem rpr_1_th_25:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B"
proof(rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_20 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using rpr_1_th_18 xreal_1_th_43 sorry
qed "sorry"

mtheorem rpr_1_th_26:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
proof(rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "A =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E)"
    using xboole_1_th_21 sorry
  then have "A =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E"
    using subset_1_th_11 sorry
  then have A1: "A =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(E)\<^esub> (B \\/SUBSET-1K4\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
    using subset_1_th_10 sorry
  have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B \\/SUBSET-1K4\<^bsub>(E)\<^esub> A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
    using rpr_1_th_13 rpr_1_th_21 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
    using A1 xboole_1_th_23 sorry
qed "sorry"

mtheorem rpr_1_th_27:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A)"
proof(rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A)) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)"
    using xboole_1_th_39 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A)"
    using rpr_1_th_21 xboole_1_th_79 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A)"
     sorry
qed "sorry"

mtheorem rpr_1_th_28:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =XBOOLE-0R4 probRPR-1K1\<^bsub>(E)\<^esub> B +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> A)"
proof(rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>) & probRPR-1K1\<^bsub>(E)\<^esub> B =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>)"
    using rpr_1_th_26 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =XBOOLE-0R4 probRPR-1K1\<^bsub>(E)\<^esub> B +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> A)"
     sorry
qed "sorry"

mtheorem rpr_1_th_29:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds  for C be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  fix C assume [ty]: "C be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> (A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
    using rpr_1_th_20 sorry
  also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
    using rpr_1_th_20 sorry
  also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)+XCMPLX-0K2 (-XCMPLX-0K4 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)))-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C \\/SUBSET-1K4\<^bsub>(E)\<^esub> B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
    using xboole_1_th_23 sorry
  also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)+XCMPLX-0K2 (-XCMPLX-0K4 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)))-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)/\\SUBSET-1K9\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)))"
    using rpr_1_th_20 sorry
  also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)+XCMPLX-0K2 (-XCMPLX-0K4 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)))-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> (C /\\SUBSET-1K9\<^bsub>(E)\<^esub> (C /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))))"
    using xboole_1_th_16 sorry
  also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)+XCMPLX-0K2 (-XCMPLX-0K4 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)))-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> ((C /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)/\\SUBSET-1K9\<^bsub>(E)\<^esub> B)))"
    using xboole_1_th_16 sorry
  also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)+XCMPLX-0K2 (-XCMPLX-0K4 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)))-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))-XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C))"
    using xboole_1_th_16 sorry
  also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)+XCMPLX-0K2 (-XCMPLX-0K4 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
     sorry
  finally have "probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)+XCMPLX-0K2 (-XCMPLX-0K4 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
     sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
     sorry
qed "sorry"

mtheorem rpr_1_th_30:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds  for C be EventRPR-1M1-of E holds (A missesXBOOLE-0R1 B & A missesXBOOLE-0R1 C) & B missesXBOOLE-0R1 C implies probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds  for C be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B & (A missesXBOOLE-0R1 C & B missesXBOOLE-0R1 C) implies probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    fix B assume [ty]: "B be EventRPR-1M1-of E"
    fix C assume [ty]: "C be EventRPR-1M1-of E"
    assume A1: "A missesXBOOLE-0R1 B"
      and A2: "A missesXBOOLE-0R1 C"
      and A3: "B missesXBOOLE-0R1 C"
    have A4: "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)) =HIDDENR1 0NUMBERSK6"
      using A1 rpr_1_th_16 xboole_1_th_74 sorry
    have "probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
      using rpr_1_th_29 sorry
    also have "... = (((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)))+XCMPLX-0K2 0NUMBERSK6"
      using A4 xboole_1_th_16 sorry
    also have "... = ((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))+XCMPLX-0K2 0NUMBERSK6)"
      using A3 rpr_1_th_16 sorry
    also have "... = ((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 0NUMBERSK6)"
      using A2 rpr_1_th_16 sorry
    also have "... = ((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 0NUMBERSK6"
      using A1 rpr_1_th_16 sorry
    finally have "probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 ((probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C)-XCMPLX-0K6 0NUMBERSK6"
       sorry
    thus "probRPR-1K1\<^bsub>(E)\<^esub> ((A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B)\\/SUBSET-1K4\<^bsub>(E)\<^esub> C) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> B)+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> C"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_31:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)"
proof(rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using rpr_1_th_19 xboole_1_th_17 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using xreal_1_th_13 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> (A \\SUBSET-1K7\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_23 sorry
qed "sorry"

mdef rpr_1_def_2 ("probRPR-1K2\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2", "B be EventRPR-1M1-of E", "A be EventRPR-1M1-of E"
"func probRPR-1K2\<^bsub>(E)\<^esub>(A,B) \<rightarrow> RealXREAL-0M1 equals
  (probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
proof-
  (*coherence*)
    show "(probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rpr_1_th_32:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K2\<^bsub>(E)\<^esub>(A,[#]SUBSET-1K2 E) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A"
proof(rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =HIDDENR1 \<one>\<^sub>M"
    using xcmplx_1_th_60 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,[#]SUBSET-1K2 E) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A"
    using xboole_1_th_28 sorry
qed "sorry"

mtheorem rpr_1_th_33:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds probRPR-1K2\<^bsub>(E)\<^esub>([#]SUBSET-1K2 E,[#]SUBSET-1K2 E) =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  have "probRPR-1K1\<^bsub>(E)\<^esub> [#]SUBSET-1K2 E =HIDDENR1 \<one>\<^sub>M"
    using xcmplx_1_th_60 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>([#]SUBSET-1K2 E,[#]SUBSET-1K2 E) =HIDDENR1 \<one>\<^sub>M"
     sorry
qed "sorry"

mtheorem rpr_1_th_34:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) <=XXREAL-0R1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
  have "A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B c=TARSKIR1 B"
    using xboole_1_th_17 sorry
  then have "(probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (probRPR-1K1\<^bsub>(E)\<^esub> B)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)\<inverse>XCMPLX-0K5"
    using A1 rpr_1_th_19 xreal_1_th_64 sorry
  then have "(probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M"
    using A1 xcmplx_0_def_7 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) <=XXREAL-0R1 \<one>\<^sub>M"
    using xcmplx_0_def_9 sorry
qed "sorry"

mtheorem rpr_1_th_35:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies 0NUMBERSK6 <=XXREAL-0R1 probRPR-1K2\<^bsub>(E)\<^esub>(A,B)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
  have "0NUMBERSK6 <=XXREAL-0R1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_18 sorry
  thus "0NUMBERSK6 <=XXREAL-0R1 probRPR-1K2\<^bsub>(E)\<^esub>(A,B)"
    using A1 sorry
qed "sorry"

mtheorem rpr_1_th_36:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =XBOOLE-0R4 (probRPR-1K1\<^bsub>(E)\<^esub> B -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_23 sorry
  then have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> B -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
     sorry
  then have A1: "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> B)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B) -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using xcmplx_1_th_120 sorry
  assume "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using A1 xcmplx_1_th_60 sorry
qed "sorry"

mtheorem rpr_1_th_37:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & A c=TARSKIR1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
    and A2: "A c=TARSKIR1 B"
  have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A))/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using A1 rpr_1_th_36 sorry
  then have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> B -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using A2 rpr_1_th_24 sorry
  then have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 ((probRPR-1K1\<^bsub>(E)\<^esub> B)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B) -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B))"
    using xcmplx_1_th_120 sorry
  then have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B))"
    using A1 xcmplx_1_th_60 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
     sorry
qed "sorry"

mtheorem rpr_1_th_38:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume "A missesXBOOLE-0R1 B"
  then have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_16 sorry
  also have "... = (0NUMBERSK6)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)\<inverse>XCMPLX-0K5"
     sorry
  finally have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)\<inverse>XCMPLX-0K5"
     sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 0NUMBERSK6"
     sorry
qed "sorry"

mtheorem rpr_1_th_39:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B,A)) =XBOOLE-0R4 (probRPR-1K1\<^bsub>(E)\<^esub> B)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B))"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A"
    and A2: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
  have "(probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B,A)) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using A1 xcmplx_1_th_87 sorry
  thus "(probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B,A)) =XBOOLE-0R4 (probRPR-1K1\<^bsub>(E)\<^esub> B)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B))"
    using A2 xcmplx_1_th_87 sorry
qed "sorry"

mtheorem rpr_1_th_40:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) & probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A,B)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
  have "(A \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>)/\\SUBSET-1K9\<^bsub>(E)\<^esub> B =XBOOLE-0R4 [#]SUBSET-1K2 E /\\SUBSET-1K9\<^bsub>(E)\<^esub> B & [#]SUBSET-1K2 E /\\SUBSET-1K9\<^bsub>(E)\<^esub> B =XBOOLE-0R4 B"
    using subset_1_th_10 xboole_1_th_28 sorry
  then have "A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B \\/SUBSET-1K4\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B =XBOOLE-0R4 B"
    using xboole_1_th_23 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using rpr_1_th_13 rpr_1_th_21 sorry
  then have "(probRPR-1K2\<^bsub>(E)\<^esub>(A,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using A1 xcmplx_1_th_87 sorry
  then have "(probRPR-1K2\<^bsub>(E)\<^esub>(A,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using A1 xcmplx_1_th_87 sorry
  then have "((probRPR-1K2\<^bsub>(E)\<^esub>(A,B) +XCMPLX-0K2 probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)\<inverse>XCMPLX-0K5 =XBOOLE-0R4 \<one>\<^sub>M"
    using A1 xcmplx_0_def_7 sorry
  then have "(probRPR-1K2\<^bsub>(E)\<^esub>(A,B) +XCMPLX-0K2 probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B))*XCMPLX-0K3 ((probRPR-1K1\<^bsub>(E)\<^esub> B)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)\<inverse>XCMPLX-0K5) =XBOOLE-0R4 \<one>\<^sub>M"
     sorry
  then have "(probRPR-1K2\<^bsub>(E)\<^esub>(A,B) +XCMPLX-0K2 probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B))*XCMPLX-0K3 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
    using A1 xcmplx_0_def_7 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) & probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A,B)"
     sorry
qed "sorry"

mtheorem rpr_1_th_41:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & B c=TARSKIR1 A implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
    and A2: "B c=TARSKIR1 A"
  have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> B"
    using A2 xboole_1_th_28 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 \<one>\<^sub>M"
    using A1 xcmplx_1_th_60 sorry
qed "sorry"

mtheorem rpr_1_th_42:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B implies probRPR-1K2\<^bsub>(E)\<^esub>([#]SUBSET-1K2 E,B) =HIDDENR1 \<one>\<^sub>M"
  using rpr_1_th_41 sorry

mtheorem rpr_1_th_43:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,A) =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  have "A `SUBSET-1K3\<^bsub>(E)\<^esub> missesXBOOLE-0R1 A"
    using subset_1_th_24 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> A) =HIDDENR1 0NUMBERSK6"
    using rpr_1_th_16 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,A) =HIDDENR1 0NUMBERSK6"
     sorry
qed "sorry"

mtheorem rpr_1_th_44:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds probRPR-1K2\<^bsub>(E)\<^esub>(A,A `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule ballI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  have "A missesXBOOLE-0R1 A `SUBSET-1K3\<^bsub>(E)\<^esub>"
    using subset_1_th_24 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 0NUMBERSK6"
    using rpr_1_th_16 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,A `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 0NUMBERSK6"
     sorry
qed "sorry"

mtheorem rpr_1_th_45:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
    and A2: "A missesXBOOLE-0R1 B"
  have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 0NUMBERSK6"
    using A2 rpr_1_th_38 sorry
  then have "\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) =XBOOLE-0R4 0NUMBERSK6"
    using A1 rpr_1_th_40 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B) =HIDDENR1 \<one>\<^sub>M"
     sorry
qed "sorry"

mtheorem rpr_1_th_46:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M) & A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & (probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M & A missesXBOOLE-0R1 B) implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    fix B assume [ty]: "B be EventRPR-1M1-of E"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A"
      and A2: "probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "A missesXBOOLE-0R1 B"
    have "probRPR-1K1\<^bsub>(E)\<^esub> B -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 xreal_1_th_9 sorry
    then have "0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 (-XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B))"
       sorry
    then have A4: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using rpr_1_th_22 sorry
    then have "(probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B `SUBSET-1K3\<^bsub>(E)\<^esub>,A)) =XBOOLE-0R4 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>))"
      using A1 rpr_1_th_39 sorry
    then have "(probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 \<one>\<^sub>M =XBOOLE-0R4 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>))"
      using A1 A3 rpr_1_th_45 sorry
    then have "(probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)\<inverse>XCMPLX-0K5 =XBOOLE-0R4 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>))*XCMPLX-0K3 ((probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)\<inverse>XCMPLX-0K5)"
       sorry
    then have A5: "(probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)\<inverse>XCMPLX-0K5 =XBOOLE-0R4 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>))*XCMPLX-0K3 \<one>\<^sub>M"
      using A4 xcmplx_0_def_7 sorry
    have "probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B"
      using rpr_1_th_22 sorry
    thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
      using A5 xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_47:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M) & A missesXBOOLE-0R1 B implies probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A & (probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M & A missesXBOOLE-0R1 B) implies probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    fix B assume [ty]: "B be EventRPR-1M1-of E"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> A"
      and A2: "probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "A missesXBOOLE-0R1 B"
    have A4: "probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub> =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B"
      using rpr_1_th_22 sorry
    have "probRPR-1K1\<^bsub>(E)\<^esub> B -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 xreal_1_th_9 sorry
    then have "0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 (-XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B))"
       sorry
    then have "probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
      using A4 rpr_1_th_40 sorry
    thus "probRPR-1K2\<^bsub>(E)\<^esub>(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B `SUBSET-1K3\<^bsub>(E)\<^esub>) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> A)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B)"
      using A1 A2 A3 rpr_1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_48:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds  for C be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C) & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> C implies probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B,C)))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> C)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  fix C assume [ty]: "C be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C)"
    and A2: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> C"
  have A3: "probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C) =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(B,C))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> C)"
    using A2 xcmplx_1_th_87 sorry
  have "probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))"
    using xboole_1_th_16 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C) =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))"
    using A1 xcmplx_1_th_87 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> ((A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)/\\SUBSET-1K9\<^bsub>(E)\<^esub> C) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B /\\SUBSET-1K9\<^bsub>(E)\<^esub> C))*XCMPLX-0K3 (probRPR-1K2\<^bsub>(E)\<^esub>(B,C)))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> C)"
    using A3 sorry
qed "sorry"

mtheorem rpr_1_th_49:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
    and A2: "probRPR-1K1\<^bsub>(E)\<^esub> B <XXREAL-0R3 \<one>\<^sub>M"
  have "probRPR-1K1\<^bsub>(E)\<^esub> B -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
    using A2 xreal_1_th_9 sorry
  then have "0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 (-XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B))"
     sorry
  then have A3: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>"
    using rpr_1_th_22 sorry
  have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
    using rpr_1_th_26 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
    using A1 xcmplx_1_th_87 sorry
  thus "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B `SUBSET-1K3\<^bsub>(E)\<^esub>))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B `SUBSET-1K3\<^bsub>(E)\<^esub>)"
    using A3 xcmplx_1_th_87 sorry
qed "sorry"

mtheorem rpr_1_th_50:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds ((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2 implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2)"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & (0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2 & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E & B1 missesXBOOLE-0R1 B2)) implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    fix B1 assume [ty]: "B1 be EventRPR-1M1-of E"
    fix B2 assume [ty]: "B2 be EventRPR-1M1-of E"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1"
      and A2: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2"
      and A3: "B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E"
      and A4: "B1 missesXBOOLE-0R1 B2"
    have A5: "B2 \\SUBSET-1K7\<^bsub>(E)\<^esub> B1 =XBOOLE-0R4 E \\SUBSET-1K6 B1"
      using A3 xboole_1_th_40 sorry
    then have "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using A2 A4 xboole_1_th_83 sorry
    then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B1"
      using rpr_1_th_22 sorry
    then have A6: "\<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> B1) <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_44 sorry
    have "B2 =XBOOLE-0R4 B1 `SUBSET-1K3\<^bsub>(E)\<^esub>"
      using A4 A5 xboole_1_th_83 sorry
    thus "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2)"
      using A1 A6 rpr_1_th_49 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_51:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds  for B3 be EventRPR-1M1-of E holds (((((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3 implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3)"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds  for B3 be EventRPR-1M1-of E holds  not ((((((( not 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 &  not 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) &  not 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3) &  not probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    fix B1 assume [ty]: "B1 be EventRPR-1M1-of E"
    fix B2 assume [ty]: "B2 be EventRPR-1M1-of E"
    fix B3 assume [ty]: "B3 be EventRPR-1M1-of E"
    have "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & (0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2 & (0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3 & ((B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E & (B1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 {}XBOOLE-0K1 & (B1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 {}XBOOLE-0K1 & B2 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 {}XBOOLE-0K1))))) implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3)"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
      assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1"
        and A2: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2"
        and A3: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3"
        and A4: "(B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E"
        and A5: "B1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 {}XBOOLE-0K1"
        and A6: "B1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 {}XBOOLE-0K1"
        and A7: "B2 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 {}XBOOLE-0K1"
      have "B1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 B2 /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3"
        using A6 sorry
      then have "(B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)/\\SUBSET-1K9\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 {}XBOOLE-0K1"
        using A7 xboole_1_th_23 sorry
      then have A8: "B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 missesXBOOLE-0R1 B3"
         sorry
      have "((B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3)/\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 A"
        using A4 xboole_1_th_28 sorry
      then have "(B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)/\\SUBSET-1K9\<^bsub>(E)\<^esub> A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 /\\SUBSET-1K9\<^bsub>(E)\<^esub> A =XBOOLE-0R4 A"
        using xboole_1_th_23 sorry
      then have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> ((B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)/\\SUBSET-1K9\<^bsub>(E)\<^esub> A) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B3 /\\SUBSET-1K9\<^bsub>(E)\<^esub> A)"
        using A8 rpr_1_th_21 xboole_1_th_76 sorry
      then have A9: "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (B1 /\\SUBSET-1K9\<^bsub>(E)\<^esub> A \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 /\\SUBSET-1K9\<^bsub>(E)\<^esub> A) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (B3 /\\SUBSET-1K9\<^bsub>(E)\<^esub> A)"
        using xboole_1_th_23 sorry
      have "B1 missesXBOOLE-0R1 B2"
        using A5 sorry
      then have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3)"
        using A9 rpr_1_th_21 xboole_1_th_76 sorry
      then have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3)"
        using A1 xcmplx_1_th_87 sorry
      then have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B3)"
        using A2 xcmplx_1_th_87 sorry
      thus "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3)"
        using A3 xcmplx_1_th_87 sorry
    qed
    thus " not ((((((( not 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 &  not 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) &  not 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3) &  not probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_52:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds ((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2 implies probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & ((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2 & B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) implies probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    fix B1 assume [ty]: "B1 be EventRPR-1M1-of E"
    fix B2 assume [ty]: "B2 be EventRPR-1M1-of E"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1"
      and A2: "(0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2 & B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2"
    have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2)"
      using A1 A2 rpr_1_th_50 sorry
    thus "probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))"
      using A1 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rpr_1_th_53:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds  for B3 be EventRPR-1M1-of E holds (((((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2) & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3 implies probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 (((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3))"
proof-
  have " for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B1 be EventRPR-1M1-of E holds  for B2 be EventRPR-1M1-of E holds  for B3 be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1 & (((((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3) implies probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 (((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be EventRPR-1M1-of E"
    fix B1 assume [ty]: "B1 be EventRPR-1M1-of E"
    fix B2 assume [ty]: "B2 be EventRPR-1M1-of E"
    fix B3 assume [ty]: "B3 be EventRPR-1M1-of E"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B1"
      and A2: "((((0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B2 & 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B3) & (B1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> B2)\\/SUBSET-1K4\<^bsub>(E)\<^esub> B3 =XBOOLE-0R4 E) & B1 missesXBOOLE-0R1 B2) & B1 missesXBOOLE-0R1 B3) & B2 missesXBOOLE-0R1 B3"
    have "probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3)"
      using A1 A2 rpr_1_th_51 sorry
    thus "probRPR-1K2\<^bsub>(E)\<^esub>(B1,A) =HIDDENR1 ((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1))/XCMPLX-0K7 (((probRPR-1K2\<^bsub>(E)\<^esub>(A,B1))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B1) +XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B2))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B2))+XCMPLX-0K2 (probRPR-1K2\<^bsub>(E)\<^esub>(A,B3))*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B3))"
      using A1 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rpr_1_def_3 ("'( _ , _ ')are-independentRPR-1R1\<^bsub>'( _ ')\<^esub>" [0,0,0]50 ) where
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2", "A be EventRPR-1M1-of E", "B be EventRPR-1M1-of E"
"pred (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> means
  probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)"..

mtheorem RPR_1R1_symmetry:
  mlet "E be finiteFINSET-1V1\<bar>setHIDDENM2"
" for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies (B,A)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
proof-
  have " for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) implies probRPR-1K1\<^bsub>(E)\<^esub> (B /\\SUBSET-1K9\<^bsub>(E)\<^esub> A) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> B)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> A)"
     sorry
  thus " ?thesis "
    using rpr_1_def_3 sorry
qed

mtheorem rpr_1_th_54:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds 0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B & (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 probRPR-1K1\<^bsub>(E)\<^esub> B"
    and A2: "(A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
  have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using A2 sorry
  then have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 ((probRPR-1K1\<^bsub>(E)\<^esub> B)/XCMPLX-0K7 (probRPR-1K1\<^bsub>(E)\<^esub> B))"
    using xcmplx_1_th_74 sorry
  then have "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 \<one>\<^sub>M"
    using A1 xcmplx_1_th_60 sorry
  thus "probRPR-1K2\<^bsub>(E)\<^esub>(A,B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> A"
     sorry
qed "sorry"

mtheorem rpr_1_th_55:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds probRPR-1K1\<^bsub>(E)\<^esub> B =HIDDENR1 0NUMBERSK6 implies (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  assume A1: "probRPR-1K1\<^bsub>(E)\<^esub> B =HIDDENR1 0NUMBERSK6"
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) <=XXREAL-0R1 0NUMBERSK6"
    using rpr_1_th_19 xboole_1_th_17 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 0NUMBERSK6"
    using rpr_1_th_18 sorry
  thus "(A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
    using A1 sorry
qed "sorry"

mtheorem rpr_1_th_56:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies (A `SUBSET-1K3\<^bsub>(E)\<^esub>,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix E assume [ty]: "E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be EventRPR-1M1-of E"
  fix B assume [ty]: "B be EventRPR-1M1-of E"
  have "probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> (B \\SUBSET-1K7\<^bsub>(E)\<^esub> A)"
    using subset_1_th_13 sorry
  then have A1: "probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 probRPR-1K1\<^bsub>(E)\<^esub> B -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> (A /\\SUBSET-1K9\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_23 sorry
  assume "(A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B) -XCMPLX-0K6 (probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using A1 sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 probRPR-1K1\<^bsub>(E)\<^esub> A)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
     sorry
  then have "probRPR-1K1\<^bsub>(E)\<^esub> (A `SUBSET-1K3\<^bsub>(E)\<^esub> /\\SUBSET-1K9\<^bsub>(E)\<^esub> B) =HIDDENR1 (probRPR-1K1\<^bsub>(E)\<^esub> A `SUBSET-1K3\<^bsub>(E)\<^esub>)*XCMPLX-0K3 (probRPR-1K1\<^bsub>(E)\<^esub> B)"
    using rpr_1_th_22 sorry
  thus "(A `SUBSET-1K3\<^bsub>(E)\<^esub>,B)are-independentRPR-1R1\<^bsub>(E)\<^esub>"
     sorry
qed "sorry"

mtheorem rpr_1_th_57:
" for E be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be EventRPR-1M1-of E holds  for B be EventRPR-1M1-of E holds A missesXBOOLE-0R1 B & (A,B)are-independentRPR-1R1\<^bsub>(E)\<^esub> implies probRPR-1K1\<^bsub>(E)\<^esub> A =HIDDENR1 0NUMBERSK6 or probRPR-1K1\<^bsub>(E)\<^esub> B =HIDDENR1 0NUMBERSK6"
  using rpr_1_th_16 xcmplx_1_th_6 sorry

end
