theory power
  imports prepower abian
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, e for "RealXREAL-0M1"
reserve m, n, m1, m2 for "NatNAT-1M1"
reserve k, l for "IntegerINT-1M1"
reserve p for "RationalRAT-1M1"
mtheorem power_th_1:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be evenABIANV3 implies (-XCMPLX-0K4 a) |^NEWTONK1 n =COMPLEX1R1 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  not (n be evenABIANV3 &  not (-XCMPLX-0K4 a) |^NEWTONK1 n =COMPLEX1R1 a  |^NEWTONK1 n)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "( ex m be NatNAT-1M1 st n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m) implies (-XCMPLX-0K4 a) |^NEWTONK1 n =HIDDENR1 a  |^NEWTONK1 n"
    proof(rule impI)
      assume Given: " ex m be NatNAT-1M1 st n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m"
      then obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A1: "n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m"
         sorry
      have "(-XCMPLX-0K4 a) |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 a) |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 m"
        using A1 newton_th_9 sorry
      also have "... = ((-XCMPLX-0K4 a) |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (-XCMPLX-0K4 a) |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 m"
        using newton_th_8 sorry
      also have "... = (((-XCMPLX-0K4 a) |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))*XCMPLX-0K3 (-XCMPLX-0K4 a) |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 m"
        using newton_th_6 sorry
      also have "... = (((-XCMPLX-0K4 a) |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))*XCMPLX-0K3 ((-XCMPLX-0K4 a) |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))) |^NEWTONK1 m"
        using newton_th_6 sorry
      also have "... = (((-XCMPLX-0K4 a)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))*XCMPLX-0K3 ((-XCMPLX-0K4 a) |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))) |^NEWTONK1 m"
        using prepower_def_1 sorry
      also have "... = (((-XCMPLX-0K4 a)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))*XCMPLX-0K3 ((-XCMPLX-0K4 a)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))) |^NEWTONK1 m"
        using prepower_def_1 sorry
      also have "... = (((-XCMPLX-0K4 a)GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (-XCMPLX-0K4 a))*XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 a))) |^NEWTONK1 m"
        using prepower_th_3 sorry
      also have "... = ((\<one>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 a))*XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 a))) |^NEWTONK1 m"
        using prepower_th_3 sorry
      also have "... = (a *XCMPLX-0K3 a) |^NEWTONK1 m"
         sorry
      also have "... = ((a GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 a)) |^NEWTONK1 m"
        using prepower_th_3 sorry
      also have "... = ((a GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 a)*XCMPLX-0K3 (a GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 a)) |^NEWTONK1 m"
        using prepower_th_3 sorry
      also have "... = ((a GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 a)*XCMPLX-0K3 (a  |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 a)) |^NEWTONK1 m"
        using prepower_def_1 sorry
      also have "... = ((a  |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 a)*XCMPLX-0K3 (a  |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 a)) |^NEWTONK1 m"
        using prepower_def_1 sorry
      also have "... = ((a  |^NEWTONK1 (0NUMBERSK6) *XCMPLX-0K3 a)*XCMPLX-0K3 a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 m"
        using newton_th_6 sorry
      also have "... = (a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 m"
        using newton_th_6 sorry
      also have "... = (a  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 m"
        using newton_th_8 sorry
      also have "... = a  |^NEWTONK1 n"
        using A1 newton_th_9 sorry
      finally show "(-XCMPLX-0K4 a) |^NEWTONK1 n =HIDDENR1 a  |^NEWTONK1 n"
         sorry
    qed
    thus " not (n be evenABIANV3 &  not (-XCMPLX-0K4 a) |^NEWTONK1 n =COMPLEX1R1 a  |^NEWTONK1 n)"
      using abian_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_2:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be oddABIANV2 implies (-XCMPLX-0K4 a) |^NEWTONK1 n =COMPLEX1R1 -XCMPLX-0K4 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be oddABIANV2 implies (-XCMPLX-0K4 a) |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "n be oddABIANV2"
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A1: "n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m +NAT-1K1 \<one>\<^sub>M"
      using abian_th_9 sorry
    have "(-XCMPLX-0K4 a) |^NEWTONK1 n =HIDDENR1 (-XCMPLX-0K4 a) |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 m) *XCMPLX-0K3 (-XCMPLX-0K4 a)"
      using A1 newton_th_6 sorry
    also have "... = a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 m) *XCMPLX-0K3 (-XCMPLX-0K4 a)"
      using power_th_1 sorry
    also have "... = -XCMPLX-0K4 a  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 m) *XCMPLX-0K3 a"
       sorry
    also have "... = -XCMPLX-0K4 a  |^NEWTONK1 n"
      using A1 newton_th_6 sorry
    finally show "(-XCMPLX-0K4 a) |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 a  |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_3:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 or n be evenABIANV3 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 or n be evenABIANV3 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6 or n be evenABIANV3"
    have A2: " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI,rule ballI,rule impI)
      fix a assume [ty]: "a be RealXREAL-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A3: "a >=XXREAL-0R2 0NUMBERSK6"
      have "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
      proof-
        show "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
        proof-
          have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
            using A3 sorry
          have case1: "a >XXREAL-0R4 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
          proof(rule impI)
            assume "a >XXREAL-0R4 0NUMBERSK6"
            thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
              using prepower_th_6 sorry
          qed
          have case2: "a =COMPLEX1R1 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
          proof(rule impI)
            assume A4: "a =COMPLEX1R1 0NUMBERSK6"
            have "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
            proof-
              show "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
              proof-
                have cases: "n =COMPLEX1R1 0NUMBERSK6 or ( ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M)"
                  using nat_1_th_6 sorry
                have case1: "n =COMPLEX1R1 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
                proof(rule impI)
                  assume A5: "n =COMPLEX1R1 0NUMBERSK6"
                  have "a  |^NEWTONK1 n =HIDDENR1 a GeoSeqPREPOWERK1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
                    using prepower_def_1 sorry
                  also have "... = \<one>\<^sub>M"
                    using A5 prepower_th_3 sorry
                  finally have "a  |^NEWTONK1 n =HIDDENR1 \<one>\<^sub>M"
                     sorry
                  thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
                     sorry
                qed
                have case2: "( ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M) implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
                proof(rule impI)
                  assume " ex m be NatNAT-1M1 st n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M"
                  then obtain m where
                    [ty]:"m be NatNAT-1M1" and 
                    A6: "n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  have "a  |^NEWTONK1 n =HIDDENR1 a  |^NEWTONK1 m *XCMPLX-0K3 a"
                    using A6 newton_th_6 sorry
                  also have "... = 0NUMBERSK6"
                    using A4 sorry
                  finally have "a  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6"
                     sorry
                  thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
         sorry
    qed "sorry"
    have "n be evenABIANV3 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
    proof(rule impI)
      assume A7: "n be evenABIANV3"
      have "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
      proof-
        show "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
        proof-
          have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
          proof(rule impI)
            assume "a >=XXREAL-0R2 0NUMBERSK6"
            thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
              using A2 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
          proof(rule impI)
            assume "a <XXREAL-0R3 0NUMBERSK6"
            then have "(-XCMPLX-0K4 a) |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
              using A2 sorry
            thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
              using A7 power_th_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
         sorry
    qed
    thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef power_def_1 (" _ -rootPOWERK1  _ " [300,300]300 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "a be RealXREAL-0M1"
"func n -rootPOWERK1 a \<rightarrow> RealXREAL-0M1 equals
  n -RootPREPOWERK2 a if a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M,
  -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a) if a <XXREAL-0R3 0NUMBERSK6 & n be oddABIANV2"
proof-
  (*consistency*)
    show " for it be RealXREAL-0M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & (a <XXREAL-0R3 0NUMBERSK6 & n be oddABIANV2) implies (it =HIDDENR1 n -RootPREPOWERK2 a iff it =HIDDENR1 -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a))"
       sorry
  (*coherence*)
    show "(a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a be RealXREAL-0M1) & (a <XXREAL-0R3 0NUMBERSK6 & n be oddABIANV2 implies -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a) be RealXREAL-0M1)"
       sorry
qed "sorry"

mtheorem power_th_4:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2 implies n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2 implies n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2"
    have A2: "n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
    proof(rule impMI ,rule impI)
      assume A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
        and A4: "a >=XXREAL-0R2 0NUMBERSK6"
      have A5: "n -rootPOWERK1 a =COMPLEX1R1 n -RootPREPOWERK2 a"
        using A3 A4 power_def_1 sorry
      have "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
      proof-
        show "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
        proof-
          have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
            using A4 sorry
          have case1: "a >XXREAL-0R4 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
          proof(rule impI)
            assume "a >XXREAL-0R4 0NUMBERSK6"
            thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
              using prepower_th_6 sorry
          qed
          have case2: "a =COMPLEX1R1 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
          proof(rule impI)
            assume "a =COMPLEX1R1 0NUMBERSK6"
            thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      then have "n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 n -RootPREPOWERK2 (a  |^NEWTONK1 n)"
        using A3 power_def_1 sorry
      thus "n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
        using A3 A4 A5 prepower_th_19 sorry
    qed
    have "n be oddABIANV2 implies n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
    proof(rule impI)
      assume A6: "n be oddABIANV2"
      then have A7: " ex m be NatNAT-1M1 st n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m +NAT-1K1 \<one>\<^sub>M"
        using abian_th_9 sorry
      have A8: "n >=XXREAL-0R2 \<one>\<^sub>M"
        using A6 abian_th_12 sorry
      have "n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
      proof-
        show "n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
        proof-
          have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
          proof(rule impI)
            assume "a >=XXREAL-0R2 0NUMBERSK6"
            thus "n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
              using A2 A8 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 a  |^NEWTONK1 n =HIDDENR1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =HIDDENR1 a"
          proof(rule impI,rule conjMI)
            assume A9: "a <XXREAL-0R3 0NUMBERSK6"
            then have A10: "-XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6"
              using xreal_1_th_58 sorry
            have "n -rootPOWERK1 a  |^NEWTONK1 n =HIDDENR1 (-XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a)) |^NEWTONK1 n"
              using A7 A9 power_def_1 sorry
            also have "... = -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a)  |^NEWTONK1 n"
              using A7 power_th_2 sorry
            also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)"
              using A8 A9 prepower_th_19 sorry
            also have "... = a"
               sorry
            finally show "n -rootPOWERK1 a  |^NEWTONK1 n =HIDDENR1 a"
               sorry
            have "(-XCMPLX-0K4 a) |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
              using A10 prepower_th_6 sorry
            then have "-XCMPLX-0K4 a  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
              using A7 power_th_2 sorry
            then have "a  |^NEWTONK1 n <XXREAL-0R3 0NUMBERSK6"
               sorry
            then have "n -rootPOWERK1 (a  |^NEWTONK1 n) =HIDDENR1 -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a  |^NEWTONK1 n)"
              using A7 power_def_1 sorry
            also have "... = -XCMPLX-0K4 n -RootPREPOWERK2 ((-XCMPLX-0K4 a) |^NEWTONK1 n)"
              using A7 power_th_2 sorry
            also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)"
              using A8 A9 prepower_th_19 sorry
            also have "... = a"
               sorry
            finally show "n -rootPOWERK1 (a  |^NEWTONK1 n) =HIDDENR1 a"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
         sorry
    qed
    thus "n -rootPOWERK1 a  |^NEWTONK1 n =COMPLEX1R1 a & n -rootPOWERK1 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_5:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
    then have "n -rootPOWERK1 (0NUMBERSK6) =HIDDENR1 n -RootPREPOWERK2 (0NUMBERSK6)"
      using power_def_1 sorry
    also have "... = 0NUMBERSK6"
      using A1 prepower_def_2 sorry
    finally show "n -rootPOWERK1 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_6:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
    then have "n -rootPOWERK1 \<one>\<^sub>M =HIDDENR1 n -RootPREPOWERK2 \<one>\<^sub>M"
      using power_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using A1 prepower_th_20 sorry
    finally show "n -rootPOWERK1 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_7:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have "n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
    proof-
      show "n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
      proof-
        have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
          using A1 sorry
        have case1: "a >XXREAL-0R4 0NUMBERSK6 implies n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
        proof(rule impI)
          assume A3: "a >XXREAL-0R4 0NUMBERSK6"
          have "n -rootPOWERK1 a =COMPLEX1R1 n -RootPREPOWERK2 a"
            using A1 A2 power_def_1 sorry
          thus "n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
            using A2 A3 prepower_def_2 sorry
        qed
        have case2: "a =COMPLEX1R1 0NUMBERSK6 implies n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
        proof(rule impI)
          assume A4: "a =COMPLEX1R1 0NUMBERSK6"
          have "n -rootPOWERK1 a =HIDDENR1 n -RootPREPOWERK2 a"
            using A1 A2 power_def_1 sorry
          also have "... = 0NUMBERSK6"
            using A2 A4 prepower_def_2 sorry
          finally have "n -rootPOWERK1 a =HIDDENR1 0NUMBERSK6"
             sorry
          thus "n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "n -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_8:
" for n be NatNAT-1M1 holds n be oddABIANV2 implies n -rootPOWERK1 (-XCMPLX-0K4 \<one>\<^sub>M) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n be oddABIANV2 implies n -rootPOWERK1 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n be oddABIANV2"
    then have A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      using abian_th_12 sorry
    have "n -rootPOWERK1 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M))"
      using A1 power_def_1 sorry
    also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
      using A2 prepower_th_20 sorry
    finally show "n -rootPOWERK1 (-XCMPLX-0K4 \<one>\<^sub>M) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_9:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M -rootPOWERK1 a =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds \<one>\<^sub>M -rootPOWERK1 a =COMPLEX1R1 a"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "\<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 a"
    proof-
      show "\<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 a"
      proof-
        have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies \<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 a"
        proof(rule impI)
          assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
          then have "\<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 \<one>\<^sub>M -RootPREPOWERK2 a"
            using power_def_1 sorry
          also have "... = a"
            using A1 prepower_th_21 sorry
          finally show "\<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 a"
             sorry
        qed
        have case2: "a <XXREAL-0R3 0NUMBERSK6 implies \<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 a"
        proof(rule impI)
          assume A2: "a <XXREAL-0R3 0NUMBERSK6"
          have "\<one>\<^sub>M =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M"
             sorry
          then have "\<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M -RootPREPOWERK2 (-XCMPLX-0K4 a)"
            using A2 power_def_1 sorry
          also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)"
            using A2 prepower_th_21 sorry
          also have "... = a"
             sorry
          finally show "\<one>\<^sub>M -rootPOWERK1 a =HIDDENR1 a"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "\<one>\<^sub>M -rootPOWERK1 a =COMPLEX1R1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_10:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be oddABIANV2 implies n -rootPOWERK1 a =COMPLEX1R1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n be oddABIANV2 implies n -rootPOWERK1 a =COMPLEX1R1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n be oddABIANV2"
    then have A2: " ex m be NatNAT-1M1 st n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m +NAT-1K1 \<one>\<^sub>M"
      using abian_th_9 sorry
    have A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 abian_th_12 sorry
    have "n -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
    proof-
      show "n -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
      proof-
        have cases: "(a <XXREAL-0R3 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6) or a >XXREAL-0R4 0NUMBERSK6"
           sorry
        have case1: "a <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
        proof(rule impI)
          assume A4: "a <XXREAL-0R3 0NUMBERSK6"
          then have "n -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a)"
            using A2 power_def_1 sorry
          also have "... = -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
            using A3 A4 power_def_1 sorry
          finally show "n -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
             sorry
        qed
        have case2: "a =COMPLEX1R1 0NUMBERSK6 implies n -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
        proof(rule impI)
          assume A5: "a =COMPLEX1R1 0NUMBERSK6"
          then have "n -rootPOWERK1 a =HIDDENR1 0NUMBERSK6"
            using A3 power_th_5 sorry
          also have "... = -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
            using A3 A5 power_th_5 sorry
          finally show "n -rootPOWERK1 a =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
             sorry
        qed
        have case3: "a >XXREAL-0R4 0NUMBERSK6 implies -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) =HIDDENR1 n -rootPOWERK1 a"
        proof(rule impI)
          assume A6: "a >XXREAL-0R4 0NUMBERSK6"
          then have "-XCMPLX-0K4 a <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
            using xreal_1_th_24 sorry
          then have "-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 (-XCMPLX-0K4 a)))"
            using A2 power_def_1 sorry
          also have "... = n -rootPOWERK1 a"
            using A3 A6 power_def_1 sorry
          finally show "-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) =HIDDENR1 n -rootPOWERK1 a"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "n -rootPOWERK1 a =COMPLEX1R1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6) & b >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6) & b >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "(n >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 0NUMBERSK6) & b >=XXREAL-0R2 0NUMBERSK6 or n be oddABIANV2"
    have A2: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & (a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be RealXREAL-0M1"
      fix b assume [ty]: "b be RealXREAL-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
        and A4: "a >=XXREAL-0R2 0NUMBERSK6"
        and A5: "b >=XXREAL-0R2 0NUMBERSK6"
      have "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -RootPREPOWERK2 (a *XCMPLX-0K3 b)"
        using A3 A4 A5 power_def_1 sorry
      also have "... = n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
        using A3 A4 A5 prepower_th_22 sorry
      also have "... = n -rootPOWERK1 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
        using A3 A4 power_def_1 sorry
      also have "... = n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
        using A3 A5 power_def_1 sorry
      finally show "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
         sorry
    qed "sorry"
    have "n be oddABIANV2 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
    proof(rule impI)
      assume A6: "n be oddABIANV2"
      then have A7: "n >=XXREAL-0R2 \<one>\<^sub>M"
        using abian_th_12 sorry
      have "n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
      proof-
        show "n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
        proof-
          have cases: "((a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) or a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) or a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6"
             sorry
          have case1: "a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
          proof(rule impI)
            assume "a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6"
            thus "n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
              using A2 A7 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
          proof(rule impI)
            assume A8: "a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6"
            then have "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -RootPREPOWERK2 ((-XCMPLX-0K4 a)*XCMPLX-0K3 (-XCMPLX-0K4 b))"
              using A7 power_def_1 sorry
            also have "... = (-XCMPLX-0K4 (-XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a)))*XCMPLX-0K3 n -RootPREPOWERK2 (-XCMPLX-0K4 b)"
              using A7 A8 prepower_th_22 sorry
            also have "... = (-XCMPLX-0K4 n -rootPOWERK1 a)*XCMPLX-0K3 (-XCMPLX-0K4 (-XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 b)))"
              using A6 A8 power_def_1 sorry
            also have "... = (-XCMPLX-0K4 n -rootPOWERK1 a)*XCMPLX-0K3 (-XCMPLX-0K4 n -rootPOWERK1 b)"
              using A6 A8 power_def_1 sorry
            also have "... = n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
               sorry
            finally show "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
               sorry
          qed
          have case3: "a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
          proof(rule impI)
            assume A9: "a >=XXREAL-0R2 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6"
            have "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a *XCMPLX-0K3 b)"
              using A6 power_th_10 sorry
            also have "... = -XCMPLX-0K4 n -rootPOWERK1 (a *XCMPLX-0K3 (-XCMPLX-0K4 b))"
               sorry
            also have "... = -XCMPLX-0K4 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 (-XCMPLX-0K4 b)"
              using A2 A7 A9 sorry
            also have "... = n -rootPOWERK1 a *XCMPLX-0K3 (-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b))"
               sorry
            also have "... = n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
              using A6 power_th_10 sorry
            finally show "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
               sorry
          qed
          have case4: "a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
          proof(rule impI)
            assume A10: "a <XXREAL-0R3 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6"
            have "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a *XCMPLX-0K3 b)"
              using A6 power_th_10 sorry
            also have "... = -XCMPLX-0K4 n -rootPOWERK1 ((-XCMPLX-0K4 a)*XCMPLX-0K3 b)"
               sorry
            also have "... = -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) *XCMPLX-0K3 n -rootPOWERK1 b"
              using A2 A7 A10 sorry
            also have "... = (-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a))*XCMPLX-0K3 n -rootPOWERK1 b"
               sorry
            also have "... = n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
              using A6 power_th_10 sorry
            finally show "n -rootPOWERK1 (a *XCMPLX-0K3 b) =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      thus "n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
         sorry
    qed
    thus "n -rootPOWERK1 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 b"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_12:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M or a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M or a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M or a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2"
    have A2: " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
    proof(rule ballI,rule ballI,rule impI)
      fix a assume [ty]: "a be RealXREAL-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A3: "a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M"
      then have "n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =HIDDENR1 n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a)"
        using power_def_1 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a"
        using A3 prepower_th_23 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
        using A3 power_def_1 sorry
      finally show "n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
         sorry
    qed "sorry"
    have "a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
    proof(rule impMI ,rule impI)
      assume A4: "a <>HIDDENR2 0NUMBERSK6"
        and A5: "n be oddABIANV2"
      have A6: "n >=XXREAL-0R2 \<one>\<^sub>M"
        using A5 abian_th_12 sorry
      have "n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
      proof-
        show "n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
        proof-
          have cases: "a >XXREAL-0R4 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
            using A4 sorry
          have case1: "a >XXREAL-0R4 0NUMBERSK6 implies n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
          proof(rule impI)
            assume "a >XXREAL-0R4 0NUMBERSK6"
            thus "n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
              using A2 A6 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a =HIDDENR1 n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a)"
          proof(rule impI)
            assume "a <XXREAL-0R3 0NUMBERSK6"
            then have A7: "-XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6"
              using xreal_1_th_58 sorry
            have "\<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a))"
              using A5 power_th_10 sorry
            also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 (-XCMPLX-0K4 a)"
              using xcmplx_1_th_188 sorry
            also have "... = -XCMPLX-0K4 n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 (-XCMPLX-0K4 a))"
              using A2 A6 A7 sorry
            also have "... = -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)"
              using xcmplx_1_th_188 sorry
            also have "... = n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a)"
              using A5 power_th_10 sorry
            finally show "\<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a =HIDDENR1 n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
         sorry
    qed
    thus "n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 a"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_13:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M or b <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (a /XCMPLX-0K7 b) =COMPLEX1R1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M or b <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (a /XCMPLX-0K7 b) =COMPLEX1R1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "(a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M or b <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2"
    have "n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
    proof-
      show "n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
      proof-
        have cases: "(a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M or b <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2"
          using A1 sorry
        have case1: "(a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
        proof(rule impI)
          assume A2: "(a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M"
          then have "n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -RootPREPOWERK2 (a /XCMPLX-0K7 b)"
            using power_def_1 sorry
          also have "... = n -RootPREPOWERK2 a /XCMPLX-0K7 n -RootPREPOWERK2 b"
            using A2 prepower_th_24 sorry
          also have "... = n -rootPOWERK1 a /XCMPLX-0K7 n -RootPREPOWERK2 b"
            using A2 power_def_1 sorry
          also have "... = n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
            using A2 power_def_1 sorry
          finally show "n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
             sorry
        qed
        have case2: "b <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2 implies n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
        proof(rule impI)
          assume A3: "b <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2"
          have "n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -rootPOWERK1 (a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b))"
             sorry
          also have "... = n -rootPOWERK1 a *XCMPLX-0K3 n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 b)"
            using A3 power_th_11 sorry
          also have "... = n -rootPOWERK1 a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 n -rootPOWERK1 b)"
            using A3 power_th_12 sorry
          also have "... = n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
             sorry
          finally show "n -rootPOWERK1 (a /XCMPLX-0K7 b) =HIDDENR1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "n -rootPOWERK1 (a /XCMPLX-0K7 b) =COMPLEX1R1 n -rootPOWERK1 a /XCMPLX-0K7 n -rootPOWERK1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_14:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2 implies n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2 implies n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "(a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2"
    have A2: " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (n >=XXREAL-0R2 \<one>\<^sub>M & m >=XXREAL-0R2 \<one>\<^sub>M) implies n -rootPOWERK1 (m -rootPOWERK1 a) =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be RealXREAL-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume A3: "a >=XXREAL-0R2 0NUMBERSK6"
        and A4: "n >=XXREAL-0R2 \<one>\<^sub>M"
        and A5: "m >=XXREAL-0R2 \<one>\<^sub>M"
      have A6: "n *XCMPLX-0K3 m >=XXREAL-0R2 \<one>\<^sub>M"
        using A4 A5 xreal_1_th_159 sorry
      have "m -rootPOWERK1 a >=XXREAL-0R2 0NUMBERSK6"
        using A3 A5 power_th_7 sorry
      then have A7: "m -RootPREPOWERK2 a >=XXREAL-0R2 0NUMBERSK6"
        using A3 A5 power_def_1 sorry
      have "n -rootPOWERK1 (m -rootPOWERK1 a) =HIDDENR1 n -rootPOWERK1 (m -RootPREPOWERK2 a)"
        using A3 A5 power_def_1 sorry
      also have "... = n -RootPREPOWERK2 (m -RootPREPOWERK2 a)"
        using A4 A7 power_def_1 sorry
      also have "... = (n *XCMPLX-0K3 m)-RootPREPOWERK2 a"
        using A3 A4 A5 prepower_th_25 sorry
      also have "... = (n *XCMPLX-0K3 m)-rootPOWERK1 a"
        using A3 A6 power_def_1 sorry
      finally show "n -rootPOWERK1 (m -rootPOWERK1 a) =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
         sorry
    qed "sorry"
    have "n be oddABIANV2 implies (m be oddABIANV2 implies n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a)"
    proof(rule impI,rule impI)
      assume "n be oddABIANV2"
      then obtain m1 where
        [ty]:"m1 be NatNAT-1M1" and 
        A8: "n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M"
        using abian_th_9 sorry
      assume "m be oddABIANV2"
      then obtain m2 where
        [ty]:"m2 be NatNAT-1M1" and 
        A9: "m =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
        using abian_th_9 sorry
      have A10: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using A8 xreal_1_th_6 sorry
      have A11: "m >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using A9 xreal_1_th_6 sorry
      then have A12: "n *XCMPLX-0K3 m >=XXREAL-0R2 \<one>\<^sub>M"
        using A10 xreal_1_th_159 sorry
      have A13: "n *XCMPLX-0K3 m =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((m1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 m2) +XCMPLX-0K2 m1)+XCMPLX-0K2 m2) +NAT-1K1 \<one>\<^sub>M"
        using A8 A9 sorry
      have "n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
      proof-
        show "n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
        proof-
          have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
          proof(rule impI)
            assume "a >=XXREAL-0R2 0NUMBERSK6"
            thus "n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
              using A2 A10 A11 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 (m -rootPOWERK1 a) =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
          proof(rule impI)
            assume A14: "a <XXREAL-0R3 0NUMBERSK6"
            then have "m -rootPOWERK1 (-XCMPLX-0K4 a) >=XXREAL-0R2 0NUMBERSK6"
              using A11 power_th_7 sorry
            then have A15: "m -RootPREPOWERK2 (-XCMPLX-0K4 a) >=XXREAL-0R2 0NUMBERSK6"
              using A11 A14 power_def_1 sorry
            have "n -rootPOWERK1 (m -rootPOWERK1 a) =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 m -RootPREPOWERK2 (-XCMPLX-0K4 a))"
              using A9 A14 power_def_1 sorry
            also have "... = -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 (-XCMPLX-0K4 m -RootPREPOWERK2 (-XCMPLX-0K4 a)))"
              using A8 power_th_10 sorry
            also have "... = -XCMPLX-0K4 n -RootPREPOWERK2 (m -RootPREPOWERK2 (-XCMPLX-0K4 a))"
              using A10 A15 power_def_1 sorry
            also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (-XCMPLX-0K4 a)"
              using A10 A11 A14 prepower_th_25 sorry
            also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 m)-rootPOWERK1 (-XCMPLX-0K4 a)"
              using A12 A14 power_def_1 sorry
            also have "... = (n *XCMPLX-0K3 m)-rootPOWERK1 a"
              using A13 power_th_10 sorry
            finally show "n -rootPOWERK1 (m -rootPOWERK1 a) =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
         sorry
    qed
    thus "n -rootPOWERK1 (m -rootPOWERK1 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 a"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_15:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2 implies n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
proof-
  have " for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2 implies n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "(a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2 & m be oddABIANV2"
    have A2: " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (n >=XXREAL-0R2 \<one>\<^sub>M & m >=XXREAL-0R2 \<one>\<^sub>M) implies n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix a assume [ty]: "a be RealXREAL-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume A3: "a >=XXREAL-0R2 0NUMBERSK6"
        and A4: "n >=XXREAL-0R2 \<one>\<^sub>M"
        and A5: "m >=XXREAL-0R2 \<one>\<^sub>M"
      have A6: "n *XCMPLX-0K3 m >=XXREAL-0R2 \<one>\<^sub>M & a  |^NEWTONK1 (n +XCMPLX-0K2 m) >=XXREAL-0R2 0NUMBERSK6"
        using A3 A4 A5 power_th_3 xreal_1_th_159 sorry
      have "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 m -RootPREPOWERK2 a"
        using A3 A5 power_def_1 sorry
      also have "... = n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a"
        using A3 A4 power_def_1 sorry
      also have "... = (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
        using A3 A4 A5 prepower_th_26 sorry
      also have "... = (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
        using A6 power_def_1 sorry
      finally show "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
         sorry
    qed "sorry"
    have "n be oddABIANV2 implies (m be oddABIANV2 implies n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m)))"
    proof(rule impI,rule impI)
      assume "n be oddABIANV2"
      then obtain m1 where
        [ty]:"m1 be NatNAT-1M1" and 
        A7: "n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m1 +NAT-1K1 \<one>\<^sub>M"
        using abian_th_9 sorry
      assume "m be oddABIANV2"
      then obtain m2 where
        [ty]:"m2 be NatNAT-1M1" and 
        A8: "m =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m2 +NAT-1K1 \<one>\<^sub>M"
        using abian_th_9 sorry
      have A9: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M & m >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using A7 A8 xreal_1_th_6 sorry
      then have A10: "n *XCMPLX-0K3 m >=XXREAL-0R2 \<one>\<^sub>M"
        using xreal_1_th_159 sorry
      have A11: "n +XCMPLX-0K2 m =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 (m1 +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 m2))"
        using A7 A8 sorry
      have "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
      proof-
        show "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
        proof-
          have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
          proof(rule impI)
            assume "a >=XXREAL-0R2 0NUMBERSK6"
            thus "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
              using A2 A9 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
          proof(rule impI)
            assume A12: "a <XXREAL-0R3 0NUMBERSK6"
            have A13: "a  |^NEWTONK1 (n +XCMPLX-0K2 m) >=XXREAL-0R2 0NUMBERSK6"
              using A11 power_th_3 sorry
            have "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =HIDDENR1 n -rootPOWERK1 a *XCMPLX-0K3 (-XCMPLX-0K4 m -RootPREPOWERK2 (-XCMPLX-0K4 a))"
              using A8 A12 power_def_1 sorry
            also have "... = (-XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a))*XCMPLX-0K3 (-XCMPLX-0K4 m -RootPREPOWERK2 (-XCMPLX-0K4 a))"
              using A7 A12 power_def_1 sorry
            also have "... = n -RootPREPOWERK2 (-XCMPLX-0K4 a) *XCMPLX-0K3 m -RootPREPOWERK2 (-XCMPLX-0K4 a)"
               sorry
            also have "... = (n *XCMPLX-0K3 m)-RootPREPOWERK2 ((-XCMPLX-0K4 a) |^NEWTONK1 (n +XCMPLX-0K2 m))"
              using A9 A12 prepower_th_26 sorry
            also have "... = (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
              using A11 power_th_1 sorry
            also have "... = (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
              using A10 A13 power_def_1 sorry
            finally show "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =HIDDENR1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
         sorry
    qed
    thus "n -rootPOWERK1 a *XCMPLX-0K3 m -rootPOWERK1 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-rootPOWERK1 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_16:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <=XXREAL-0R1 b & (0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2) implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <=XXREAL-0R1 b & (0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2) implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a <=XXREAL-0R1 b"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2"
    have A3: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M) & a <=XXREAL-0R1 b implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be RealXREAL-0M1"
      fix b assume [ty]: "b be RealXREAL-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A4: "0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M"
        and A5: "a <=XXREAL-0R1 b"
      have "n -RootPREPOWERK2 a <=XXREAL-0R1 n -RootPREPOWERK2 b"
        using A4 A5 prepower_th_27 sorry
      then have "n -RootPREPOWERK2 a <=XXREAL-0R1 n -rootPOWERK1 b"
        using A4 A5 power_def_1 sorry
      thus "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
        using A4 power_def_1 sorry
    qed "sorry"
    have "n be oddABIANV2 implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
    proof(rule impI)
      assume A6: "n be oddABIANV2"
      then have A7: "n >=XXREAL-0R2 \<one>\<^sub>M"
        using abian_th_12 sorry
      have "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
      proof-
        show "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
        proof-
          have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
          proof(rule impI)
            assume "a >=XXREAL-0R2 0NUMBERSK6"
            thus "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
              using A1 A3 A7 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
          proof(rule impI)
            assume A8: "a <XXREAL-0R3 0NUMBERSK6"
            have "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
            proof-
              show "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
              proof-
                have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
                   sorry
                have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
                proof(rule impI)
                  assume "b >=XXREAL-0R2 0NUMBERSK6"
                  then have A9: "n -rootPOWERK1 b >=XXREAL-0R2 0NUMBERSK6"
                    using A7 power_th_7 sorry
                  have "n -rootPOWERK1 (-XCMPLX-0K4 a) >=XXREAL-0R2 0NUMBERSK6"
                    using A7 A8 power_th_7 sorry
                  then have "-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
                     sorry
                  thus "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
                    using A6 A9 power_th_10 sorry
                qed
                have case2: "b <XXREAL-0R3 0NUMBERSK6 implies n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
                proof(rule impI)
                  assume A10: "b <XXREAL-0R3 0NUMBERSK6"
                  have "-XCMPLX-0K4 a >=XXREAL-0R2 -XCMPLX-0K4 b"
                    using A1 xreal_1_th_24 sorry
                  then have "n -rootPOWERK1 (-XCMPLX-0K4 a) >=XXREAL-0R2 n -rootPOWERK1 (-XCMPLX-0K4 b)"
                    using A3 A7 A10 sorry
                  then have "-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) <=XXREAL-0R1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b)"
                    using xreal_1_th_24 sorry
                  then have "n -rootPOWERK1 a <=XXREAL-0R1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b)"
                    using A6 power_th_10 sorry
                  thus "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
                    using A6 power_th_10 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
         sorry
    qed
    thus "n -rootPOWERK1 a <=XXREAL-0R1 n -rootPOWERK1 b"
      using A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_17:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <XXREAL-0R3 b & (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2) implies n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <XXREAL-0R3 b & (0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2) implies  not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a <XXREAL-0R3 b"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M or n be oddABIANV2"
    have A3: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M) & a <XXREAL-0R3 b implies n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix a assume [ty]: "a be RealXREAL-0M1"
      fix b assume [ty]: "b be RealXREAL-0M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A4: "0NUMBERSK6 <=XXREAL-0R1 a & n >=XXREAL-0R2 \<one>\<^sub>M"
        and A5: "a <XXREAL-0R3 b"
      have "n -RootPREPOWERK2 a <XXREAL-0R3 n -RootPREPOWERK2 b"
        using A4 A5 prepower_th_28 sorry
      then have "n -RootPREPOWERK2 a <XXREAL-0R3 n -rootPOWERK1 b"
        using A4 A5 power_def_1 sorry
      thus "n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
        using A4 power_def_1 sorry
    qed "sorry"
    have "n be oddABIANV2 implies  not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
    proof(rule impI)
      assume A6: "n be oddABIANV2"
      then have A7: "n >=XXREAL-0R2 \<one>\<^sub>M"
        using abian_th_12 sorry
      have " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
      proof-
        show " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
        proof-
          have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies  not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
          proof(rule impI)
            assume "a >=XXREAL-0R2 0NUMBERSK6"
            thus " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
              using A1 A3 A7 sorry
          qed
          have case2: "a <XXREAL-0R3 0NUMBERSK6 implies  not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
          proof(rule impI)
            assume A8: "a <XXREAL-0R3 0NUMBERSK6"
            then have A9: "-XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6"
              using xreal_1_th_58 sorry
            have " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
            proof-
              show " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
              proof-
                have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
                   sorry
                have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies  not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
                proof(rule impI)
                  assume "b >=XXREAL-0R2 0NUMBERSK6"
                  then have A10: "n -rootPOWERK1 b >=XXREAL-0R2 0NUMBERSK6"
                    using A7 power_th_7 sorry
                  have "n -RootPREPOWERK2 (-XCMPLX-0K4 a) >XXREAL-0R4 0NUMBERSK6"
                    using A7 A9 prepower_def_2 sorry
                  then have "-XCMPLX-0K4 n -RootPREPOWERK2 (-XCMPLX-0K4 a) <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
                    using xreal_1_th_24 sorry
                  thus " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
                    using A6 A8 A10 power_def_1 sorry
                qed
                have case2: "b <XXREAL-0R3 0NUMBERSK6 implies  not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
                proof(rule impI)
                  assume A11: "b <XXREAL-0R3 0NUMBERSK6"
                  have "-XCMPLX-0K4 a >XXREAL-0R4 -XCMPLX-0K4 b"
                    using A1 xreal_1_th_24 sorry
                  then have "n -rootPOWERK1 (-XCMPLX-0K4 a) >XXREAL-0R4 n -rootPOWERK1 (-XCMPLX-0K4 b)"
                    using A3 A7 A11 sorry
                  then have "-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) <XXREAL-0R3 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b)"
                    using xreal_1_th_24 sorry
                  then have "n -rootPOWERK1 a <XXREAL-0R3 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b)"
                    using A6 power_th_10 sorry
                  thus " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
                    using A6 power_th_10 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
         sorry
    qed
    thus " not n -rootPOWERK1 a <XXREAL-0R3 n -rootPOWERK1 b"
      using A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_18:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -rootPOWERK1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -rootPOWERK1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have "n -RootPREPOWERK2 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -RootPREPOWERK2 a"
      using A1 A2 prepower_th_29 sorry
    thus "n -rootPOWERK1 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -rootPOWERK1 a"
      using A2 power_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_19:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & n be oddABIANV2 implies n -rootPOWERK1 a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & a <=XXREAL-0R1 n -rootPOWERK1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & n be oddABIANV2 implies n -rootPOWERK1 a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & a <=XXREAL-0R1 n -rootPOWERK1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      and A2: "n be oddABIANV2"
    have A3: "n >=XXREAL-0R2 \<one>\<^sub>M & -XCMPLX-0K4 a >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A2 abian_th_12 xreal_1_th_25 sorry
    then have A4: "n -rootPOWERK1 (-XCMPLX-0K4 a) >=XXREAL-0R2 \<one>\<^sub>M"
      using power_th_18 sorry
    have A5: "-XCMPLX-0K4 a >=XXREAL-0R2 n -rootPOWERK1 (-XCMPLX-0K4 a)"
      using A3 power_th_18 sorry
    have A6: "-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      using A4 xreal_1_th_24 sorry
    have "a <=XXREAL-0R1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
      using A5 xreal_1_th_25 sorry
    thus "n -rootPOWERK1 a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & a <=XXREAL-0R1 n -rootPOWERK1 a"
      using A2 A6 power_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_20:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M) & n >=XXREAL-0R2 \<one>\<^sub>M implies a <=XXREAL-0R1 n -rootPOWERK1 a & n -rootPOWERK1 a <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (a <XXREAL-0R3 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M) implies a <=XXREAL-0R1 n -rootPOWERK1 a &  not n -rootPOWERK1 a <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have "a <=XXREAL-0R1 n -RootPREPOWERK2 a & n -RootPREPOWERK2 a <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 A3 prepower_th_30 sorry
    thus "a <=XXREAL-0R1 n -rootPOWERK1 a &  not n -rootPOWERK1 a <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A3 power_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_21:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & a <=XXREAL-0R1 0NUMBERSK6) & n be oddABIANV2 implies a >=XXREAL-0R2 n -rootPOWERK1 a & n -rootPOWERK1 a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & a <=XXREAL-0R1 0NUMBERSK6 implies (n be oddABIANV2 implies a >=XXREAL-0R2 n -rootPOWERK1 a &  not n -rootPOWERK1 a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      and A2: "a <=XXREAL-0R1 0NUMBERSK6"
    assume "n be oddABIANV2"
    then have A3: " ex m be NatNAT-1M1 st n =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 m +NAT-1K1 \<one>\<^sub>M"
      using abian_th_9 sorry
    then have A4: "n >=XXREAL-0R2 \<one>\<^sub>M & -XCMPLX-0K4 a <XXREAL-0R3 \<one>\<^sub>M"
      using A1 abian_th_12 xreal_1_th_25 sorry
    then have A5: "n -rootPOWERK1 (-XCMPLX-0K4 a) <XXREAL-0R3 \<one>\<^sub>M"
      using A2 power_th_20 sorry
    have A6: "-XCMPLX-0K4 a <=XXREAL-0R1 n -rootPOWERK1 (-XCMPLX-0K4 a)"
      using A2 A4 power_th_20 sorry
    have A7: "-XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a) >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      using A5 xreal_1_th_24 sorry
    have "a >=XXREAL-0R2 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 a)"
      using A6 xreal_1_th_26 sorry
    thus "a >=XXREAL-0R2 n -rootPOWERK1 a &  not n -rootPOWERK1 a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      using A3 A7 power_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_22:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M"
    then have "n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
      using prepower_th_31 sorry
    thus "n -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
      using A1 power_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_23:
" for s be Real-SequenceSEQ-1M1 holds  for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
  fix a assume [ty]: "a be RealXREAL-0M1"
  assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    and A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 a"
  have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n -RootPREPOWERK2 a"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
    then have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n -rootPOWERK1 a"
      using A2 sorry
    also have "... = n -RootPREPOWERK2 a"
      using A1 A3 power_def_1 sorry
    finally show "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 n -RootPREPOWERK2 a"
       sorry
  qed "sorry"
  thus "s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
    using A1 prepower_th_33 sorry
qed "sorry"

mdef power_def_2 (" _ to-powerPOWERK2  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
" func a to-powerPOWERK2 b \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. it =COMPLEX1R1 a #RPREPOWERK6 b if a >XXREAL-0R4 0NUMBERSK6,
  \<lambda>it. it =COMPLEX1R1 0NUMBERSK6 if a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6,
  \<lambda>it.  ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k if b be IntegerINT-1M1"
proof-
  (*consistency*)
    show " for it be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & (a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) implies (it =COMPLEX1R1 a #RPREPOWERK6 b iff it =COMPLEX1R1 0NUMBERSK6)) & (a >XXREAL-0R4 0NUMBERSK6 & b be IntegerINT-1M1 implies (it =COMPLEX1R1 a #RPREPOWERK6 b iff ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k)))) & ((a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & b be IntegerINT-1M1 implies (it =COMPLEX1R1 0NUMBERSK6 iff ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k)))"
    proof-
      have " for IT be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a =COMPLEX1R1 0NUMBERSK6) & b >XXREAL-0R4 0NUMBERSK6 implies (IT =COMPLEX1R1 a #RPREPOWERK6 b iff IT =COMPLEX1R1 0NUMBERSK6)) & ((a >XXREAL-0R4 0NUMBERSK6 & b be IntegerINT-1M1 implies (IT =COMPLEX1R1 a #RPREPOWERK6 b iff ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))) &  not (((a =COMPLEX1R1 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6) & b be IntegerINT-1M1) &  not ( not (IT =COMPLEX1R1 0NUMBERSK6 & ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))) &  not ( not ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k)) &  not IT =COMPLEX1R1 0NUMBERSK6))))"
      proof(rule ballI,rule conjMI,rule conjMI)
        fix IT assume [ty]: "IT be RealXREAL-0M1"
        show "(a >XXREAL-0R4 0NUMBERSK6 & a =COMPLEX1R1 0NUMBERSK6) & b >XXREAL-0R4 0NUMBERSK6 implies (IT =COMPLEX1R1 a #RPREPOWERK6 b iff IT =COMPLEX1R1 0NUMBERSK6)"
           sorry
        show "a >XXREAL-0R4 0NUMBERSK6 & b be IntegerINT-1M1 implies (IT =COMPLEX1R1 a #RPREPOWERK6 b iff ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))"
        proof-
          have "a >XXREAL-0R4 0NUMBERSK6 implies (b be IntegerINT-1M1 implies  not (IT =COMPLEX1R1 a #RPREPOWERK6 b & ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))) &  not ( not ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k)) &  not IT =COMPLEX1R1 a #RPREPOWERK6 b))"
          proof(rule impI,rule impI)
            assume A1: "a >XXREAL-0R4 0NUMBERSK6"
            assume "b be IntegerINT-1M1"
            then have 
              [ty]:"b be IntegerINT-1M1"
               sorry
            have "a #RPREPOWERK6 b =HIDDENR1 a #QPREPOWERK4 b"
              using A1 prepower_th_74 sorry
            also have "... = a #ZPREPOWERK3 b"
              using A1 prepower_th_99 sorry
            finally have "a #RPREPOWERK6 b =HIDDENR1 a #ZPREPOWERK3 b"
               sorry
            thus " not (IT =COMPLEX1R1 a #RPREPOWERK6 b & ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))) &  not ( not ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k)) &  not IT =COMPLEX1R1 a #RPREPOWERK6 b)"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "(a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & b be IntegerINT-1M1 implies (IT =COMPLEX1R1 0NUMBERSK6 iff ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))"
        proof-
          have "a =COMPLEX1R1 0NUMBERSK6 implies (b >XXREAL-0R4 0NUMBERSK6 & b be IntegerINT-1M1 implies  not (IT =COMPLEX1R1 0NUMBERSK6 & ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))) &  not ( not ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k)) &  not IT =COMPLEX1R1 0NUMBERSK6))"
          proof(rule impI,rule impMI ,rule impI)
            assume A2: "a =COMPLEX1R1 0NUMBERSK6"
            assume A3: "b >XXREAL-0R4 0NUMBERSK6"
              and A4: "b be IntegerINT-1M1"
            have "b inHIDDENR3 NATNUMBERSK1"
              using A3 A4 int_1_th_3 sorry
            then have 
              [ty]:"b be NatNAT-1M1"
               sorry
            have "a #ZPREPOWERK3 b =HIDDENR1 a  |^NEWTONK1 b"
              using prepower_th_36 sorry
            also have "... = 0NUMBERSK6"
              using A2 A3 nat_1_th_14 newton_th_11 sorry
            finally have "a #ZPREPOWERK3 b =HIDDENR1 0NUMBERSK6"
               sorry
            thus " not (IT =COMPLEX1R1 0NUMBERSK6 & ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))) &  not ( not ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k)) &  not IT =COMPLEX1R1 0NUMBERSK6)"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not (((a =COMPLEX1R1 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6) & b be IntegerINT-1M1) &  not ( not (IT =COMPLEX1R1 0NUMBERSK6 & ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k))) &  not ( not ( for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & IT =COMPLEX1R1 a #ZPREPOWERK3 k)) &  not IT =COMPLEX1R1 0NUMBERSK6)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  (*existence*)
    show "(a >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 a #RPREPOWERK6 b)) & ((a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 0NUMBERSK6)) & (b be IntegerINT-1M1 implies ( ex it be RealXREAL-0M1 st  ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it =COMPLEX1R1 a #ZPREPOWERK3 k)))"
    proof-
      have "( not ( not a >XXREAL-0R4 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 a #RPREPOWERK6 b)) &  not ((a =COMPLEX1R1 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6) & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 0NUMBERSK6))) &  not (b be IntegerINT-1M1 & ( for VarFor1 be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & VarFor1 =COMPLEX1R1 a #ZPREPOWERK3 k)))"
      proof-
        have "b be IntegerINT-1M1 implies ( ex c be setHIDDENM2 st  ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & c =COMPLEX1R1 a #ZPREPOWERK3 k)"
        proof(rule impI)
          assume "b be IntegerINT-1M1"
          then obtain k where 
            [ty]:"k be IntegerINT-1M1" and kDef:"k = b"
             sorry
          obtain c where 
            [ty]:"c be setHIDDENM2" and cDef:"c = a #ZPREPOWERK3 k"
             sorry
          show " ex c be setHIDDENM2 st  ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & c =COMPLEX1R1 a #ZPREPOWERK3 k"
          proof(rule bexI[of _ "c"])
            show " ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & c =COMPLEX1R1 a #ZPREPOWERK3 k"
               sorry
          qed "sorry"
        qed
        thus "( not ( not a >XXREAL-0R4 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 a #RPREPOWERK6 b)) &  not ((a =COMPLEX1R1 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6) & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 0NUMBERSK6))) &  not (b be IntegerINT-1M1 & ( for VarFor1 be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  not (k =COMPLEX1R1 b & VarFor1 =COMPLEX1R1 a #ZPREPOWERK3 k)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 implies (it1 =COMPLEX1R1 a #RPREPOWERK6 b & it2 =COMPLEX1R1 a #RPREPOWERK6 b implies it1 =HIDDENR1 it2)) & ((a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2)) & (b be IntegerINT-1M1 implies (( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it1 =COMPLEX1R1 a #ZPREPOWERK3 k) & ( ex k be IntegerINT-1M1 st k =COMPLEX1R1 b & it2 =COMPLEX1R1 a #ZPREPOWERK3 k) implies it1 =HIDDENR1 it2)))"
       sorry
qed "sorry"

mtheorem power_th_24:
" for a be RealXREAL-0M1 holds a to-powerPOWERK2 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds a to-powerPOWERK2 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a to-powerPOWERK2 (0NUMBERSK6) =HIDDENR1 a #ZPREPOWERK3 (0NUMBERSK6)"
      using power_def_2 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_34 sorry
    finally show "a to-powerPOWERK2 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_25:
" for a be RealXREAL-0M1 holds a to-powerPOWERK2 \<one>\<^sub>M =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds a to-powerPOWERK2 \<one>\<^sub>M =HIDDENR1 a"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a to-powerPOWERK2 \<one>\<^sub>M =HIDDENR1 a #ZPREPOWERK3 \<one>\<^sub>M"
      using power_def_2 sorry
    also have "... = a"
      using prepower_th_35 sorry
    finally show "a to-powerPOWERK2 \<one>\<^sub>M =HIDDENR1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_26:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M to-powerPOWERK2 a =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds \<one>\<^sub>M to-powerPOWERK2 a =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have A1: "\<one>\<^sub>M #RPREPOWERK6 a <>HIDDENR2 0NUMBERSK6"
      using prepower_th_81 sorry
    have "\<one>\<^sub>M to-powerPOWERK2 a =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M)#RPREPOWERK6 a"
      using power_def_2 sorry
    also have "... = \<one>\<^sub>M #RPREPOWERK6 a /XCMPLX-0K7 \<one>\<^sub>M #RPREPOWERK6 a"
      using prepower_th_80 sorry
    also have "... = \<one>\<^sub>M"
      using A1 xcmplx_1_th_60 sorry
    finally show "\<one>\<^sub>M to-powerPOWERK2 a =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (b +XCMPLX-0K2 c) =COMPLEX1R1 a to-powerPOWERK2 b *XCMPLX-0K3 a to-powerPOWERK2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (b +XCMPLX-0K2 c) =COMPLEX1R1 a to-powerPOWERK2 b *XCMPLX-0K3 a to-powerPOWERK2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "a #RPREPOWERK6 (b +XCMPLX-0K2 c) =COMPLEX1R1 a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 c"
      using prepower_th_75 sorry
    then have "a #RPREPOWERK6 (b +XCMPLX-0K2 c) =COMPLEX1R1 a #RPREPOWERK6 b *XCMPLX-0K3 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
    then have "a #RPREPOWERK6 (b +XCMPLX-0K2 c) =COMPLEX1R1 a to-powerPOWERK2 b *XCMPLX-0K3 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
    thus "a to-powerPOWERK2 (b +XCMPLX-0K2 c) =COMPLEX1R1 a to-powerPOWERK2 b *XCMPLX-0K3 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_28:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a to-powerPOWERK2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a to-powerPOWERK2 c"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "a #RPREPOWERK6 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
      using prepower_th_76 sorry
    then have "a #RPREPOWERK6 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
    thus "a to-powerPOWERK2 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (b -XCMPLX-0K6 c) =COMPLEX1R1 a to-powerPOWERK2 b /XCMPLX-0K7 a to-powerPOWERK2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (b -XCMPLX-0K6 c) =COMPLEX1R1 a to-powerPOWERK2 b /XCMPLX-0K7 a to-powerPOWERK2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "a #RPREPOWERK6 (b -XCMPLX-0K6 c) =COMPLEX1R1 a #RPREPOWERK6 b /XCMPLX-0K7 a #RPREPOWERK6 c"
      using prepower_th_77 sorry
    then have "a #RPREPOWERK6 (b -XCMPLX-0K6 c) =COMPLEX1R1 a #RPREPOWERK6 b /XCMPLX-0K7 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
    then have "a #RPREPOWERK6 (b -XCMPLX-0K6 c) =COMPLEX1R1 a to-powerPOWERK2 b /XCMPLX-0K7 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
    thus "a to-powerPOWERK2 (b -XCMPLX-0K6 c) =COMPLEX1R1 a to-powerPOWERK2 b /XCMPLX-0K7 a to-powerPOWERK2 c"
      using A1 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_30:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c *XCMPLX-0K3 b to-powerPOWERK2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c *XCMPLX-0K3 b to-powerPOWERK2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have A3: "a *XCMPLX-0K3 b >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 xreal_1_th_129 sorry
    have "(a *XCMPLX-0K3 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c *XCMPLX-0K3 b #RPREPOWERK6 c"
      using A1 A2 prepower_th_78 sorry
    then have "(a *XCMPLX-0K3 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c *XCMPLX-0K3 b to-powerPOWERK2 c"
      using A2 power_def_2 sorry
    then have "(a *XCMPLX-0K3 b)#RPREPOWERK6 c =COMPLEX1R1 a to-powerPOWERK2 c *XCMPLX-0K3 b to-powerPOWERK2 c"
      using A1 power_def_2 sorry
    thus "(a *XCMPLX-0K3 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c *XCMPLX-0K3 b to-powerPOWERK2 c"
      using A3 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_31:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c /XCMPLX-0K7 b to-powerPOWERK2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c /XCMPLX-0K7 b to-powerPOWERK2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have A3: "a /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 xreal_1_th_139 sorry
    have "(a /XCMPLX-0K7 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c /XCMPLX-0K7 b #RPREPOWERK6 c"
      using A1 A2 prepower_th_80 sorry
    then have "(a /XCMPLX-0K7 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c /XCMPLX-0K7 b to-powerPOWERK2 c"
      using A2 power_def_2 sorry
    then have "(a /XCMPLX-0K7 b)#RPREPOWERK6 c =COMPLEX1R1 a to-powerPOWERK2 c /XCMPLX-0K7 b to-powerPOWERK2 c"
      using A1 power_def_2 sorry
    thus "(a /XCMPLX-0K7 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 c /XCMPLX-0K7 b to-powerPOWERK2 c"
      using A3 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_32:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 b =COMPLEX1R1 a to-powerPOWERK2 (-XCMPLX-0K4 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 b =HIDDENR1 a to-powerPOWERK2 (-XCMPLX-0K4 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 b =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 b"
      using power_def_2 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 b"
      using A1 prepower_th_79 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 a to-powerPOWERK2 b"
      using A1 power_def_2 sorry
    also have "... = a to-powerPOWERK2 (-XCMPLX-0K4 b)"
      using A1 power_th_28 sorry
    finally show "(\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 b =HIDDENR1 a to-powerPOWERK2 (-XCMPLX-0K4 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_33:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a to-powerPOWERK2 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 c)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a to-powerPOWERK2 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have A2: "a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
      using prepower_th_81 sorry
    have "(a #RPREPOWERK6 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 c)"
      using A1 prepower_th_91 sorry
    then have "(a #RPREPOWERK6 b)#RPREPOWERK6 c =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 c)"
      using A1 power_def_2 sorry
    then have "(a #RPREPOWERK6 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 c)"
      using A2 power_def_2 sorry
    thus "(a to-powerPOWERK2 b)to-powerPOWERK2 c =COMPLEX1R1 a to-powerPOWERK2 (b *XCMPLX-0K3 c)"
      using A1 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_34:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 b >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies  not a to-powerPOWERK2 b >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
      using prepower_th_81 sorry
    thus " not a to-powerPOWERK2 b >XXREAL-0R4 0NUMBERSK6"
      using A1 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_35:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 b >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6 implies  not a to-powerPOWERK2 b >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have "a #RPREPOWERK6 b >XXREAL-0R4 \<one>\<^sub>M"
      using A1 A2 prepower_th_86 sorry
    thus " not a to-powerPOWERK2 b >XXREAL-0R4 \<one>\<^sub>M"
      using A1 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_36:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b <XXREAL-0R3 0NUMBERSK6 implies a to-powerPOWERK2 b <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b <XXREAL-0R3 0NUMBERSK6 implies  not a to-powerPOWERK2 b <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "b <XXREAL-0R3 0NUMBERSK6"
    have "a #RPREPOWERK6 b <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 prepower_th_88 sorry
    thus " not a to-powerPOWERK2 b <XXREAL-0R3 \<one>\<^sub>M"
      using A1 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_37:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 b) & c >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 c <XXREAL-0R3 b to-powerPOWERK2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <XXREAL-0R3 b & c >XXREAL-0R4 0NUMBERSK6) implies  not a to-powerPOWERK2 c <XXREAL-0R3 b to-powerPOWERK2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 b"
      and A3: "c >XXREAL-0R4 0NUMBERSK6"
    have A4: "a to-powerPOWERK2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 power_th_34 sorry
    have A5: "a to-powerPOWERK2 c <>HIDDENR2 0NUMBERSK6"
      using A1 power_th_34 sorry
    have "a /XCMPLX-0K7 a <XXREAL-0R3 b /XCMPLX-0K7 a"
      using A1 A2 xreal_1_th_74 sorry
    then have "\<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 a"
      using A1 xcmplx_1_th_60 sorry
    then have "(b /XCMPLX-0K7 a)to-powerPOWERK2 c >XXREAL-0R4 \<one>\<^sub>M"
      using A3 power_th_35 sorry
    then have "b to-powerPOWERK2 c /XCMPLX-0K7 a to-powerPOWERK2 c >XXREAL-0R4 \<one>\<^sub>M"
      using A1 A2 power_th_31 sorry
    then have "(b to-powerPOWERK2 c /XCMPLX-0K7 a to-powerPOWERK2 c)*XCMPLX-0K3 a to-powerPOWERK2 c >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 a to-powerPOWERK2 c"
      using A4 xreal_1_th_68 sorry
    thus " not a to-powerPOWERK2 c <XXREAL-0R3 b to-powerPOWERK2 c"
      using A5 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_38:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 b) & c <XXREAL-0R3 0NUMBERSK6 implies a to-powerPOWERK2 c >XXREAL-0R4 b to-powerPOWERK2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <XXREAL-0R3 b & c <XXREAL-0R3 0NUMBERSK6) implies  not a to-powerPOWERK2 c >XXREAL-0R4 b to-powerPOWERK2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 b"
      and A3: "c <XXREAL-0R3 0NUMBERSK6"
    have A4: "a to-powerPOWERK2 c >XXREAL-0R4 0NUMBERSK6"
      using A1 power_th_34 sorry
    have A5: "a to-powerPOWERK2 c <>HIDDENR2 0NUMBERSK6"
      using A1 power_th_34 sorry
    have "a /XCMPLX-0K7 a <XXREAL-0R3 b /XCMPLX-0K7 a"
      using A1 A2 xreal_1_th_74 sorry
    then have "\<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 a"
      using A1 xcmplx_1_th_60 sorry
    then have "(b /XCMPLX-0K7 a)to-powerPOWERK2 c <XXREAL-0R3 \<one>\<^sub>M"
      using A3 power_th_36 sorry
    then have "b to-powerPOWERK2 c /XCMPLX-0K7 a to-powerPOWERK2 c <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 power_th_31 sorry
    then have "(b to-powerPOWERK2 c /XCMPLX-0K7 a to-powerPOWERK2 c)*XCMPLX-0K3 a to-powerPOWERK2 c <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 a to-powerPOWERK2 c"
      using A4 xreal_1_th_68 sorry
    thus " not a to-powerPOWERK2 c >XXREAL-0R4 b to-powerPOWERK2 c"
      using A5 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_39:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 b & c >XXREAL-0R4 \<one>\<^sub>M implies c to-powerPOWERK2 a <XXREAL-0R3 c to-powerPOWERK2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 b & c >XXREAL-0R4 \<one>\<^sub>M implies  not c to-powerPOWERK2 a <XXREAL-0R3 c to-powerPOWERK2 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
      and A2: "c >XXREAL-0R4 \<one>\<^sub>M"
    have A3: "c to-powerPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
      using A2 power_th_34 sorry
    have A4: "c to-powerPOWERK2 a <>HIDDENR2 0NUMBERSK6"
      using A2 power_th_34 sorry
    have "b -XCMPLX-0K6 a >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_50 sorry
    then have "c to-powerPOWERK2 (b -XCMPLX-0K6 a) >XXREAL-0R4 \<one>\<^sub>M"
      using A2 power_th_35 sorry
    then have "c to-powerPOWERK2 b /XCMPLX-0K7 c to-powerPOWERK2 a >XXREAL-0R4 \<one>\<^sub>M"
      using A2 power_th_29 sorry
    then have "(c to-powerPOWERK2 b /XCMPLX-0K7 c to-powerPOWERK2 a)*XCMPLX-0K3 c to-powerPOWERK2 a >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 c to-powerPOWERK2 a"
      using A3 xreal_1_th_68 sorry
    thus " not c to-powerPOWERK2 a <XXREAL-0R3 c to-powerPOWERK2 b"
      using A4 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_40:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <XXREAL-0R3 b & c >XXREAL-0R4 0NUMBERSK6) & c <XXREAL-0R3 \<one>\<^sub>M implies c to-powerPOWERK2 a >XXREAL-0R4 c to-powerPOWERK2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 b & (c >XXREAL-0R4 0NUMBERSK6 & c <XXREAL-0R3 \<one>\<^sub>M) implies  not c to-powerPOWERK2 a >XXREAL-0R4 c to-powerPOWERK2 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
      and A2: "c >XXREAL-0R4 0NUMBERSK6"
      and A3: "c <XXREAL-0R3 \<one>\<^sub>M"
    have A4: "(\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
      using A2 power_th_34 sorry
    have A5: "(\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a <>HIDDENR2 0NUMBERSK6"
      using A2 power_th_34 sorry
    have A6: "c to-powerPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
      using A2 power_th_34 sorry
    have "c /XCMPLX-0K7 c <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 c"
      using A2 A3 xreal_1_th_74 sorry
    then have A7: "\<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 c"
      using A2 xcmplx_1_th_60 sorry
    have "b -XCMPLX-0K6 a >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_50 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 (b -XCMPLX-0K6 a) >XXREAL-0R4 \<one>\<^sub>M"
      using A7 power_th_35 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 b /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a >XXREAL-0R4 \<one>\<^sub>M"
      using A2 power_th_29 sorry
    then have "((\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 b /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a"
      using A4 xreal_1_th_68 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 b >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a"
      using A5 xcmplx_1_th_87 sorry
    then have "\<one>\<^sub>M to-powerPOWERK2 b /XCMPLX-0K7 c to-powerPOWERK2 b >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a"
      using A2 power_th_31 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 c to-powerPOWERK2 b >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 c)to-powerPOWERK2 a"
      using power_th_26 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 c to-powerPOWERK2 b >XXREAL-0R4 \<one>\<^sub>M to-powerPOWERK2 a /XCMPLX-0K7 c to-powerPOWERK2 a"
      using A2 power_th_31 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 c to-powerPOWERK2 b >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 c to-powerPOWERK2 a"
      using power_th_26 sorry
    thus " not c to-powerPOWERK2 a >XXREAL-0R4 c to-powerPOWERK2 b"
      using A6 xreal_1_th_91 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_ident_1:
  mlet "a be RealXREAL-0M1", "n be NatNAT-1M1"
"identify a to-powerPOWERK2 n with a  |^NEWTONK1 n"
proof
(*compatibility*)
  show "a to-powerPOWERK2 n =HIDDENR1 a  |^NEWTONK1 n"
  proof-
    have "a to-powerPOWERK2 n =HIDDENR1 a #ZPREPOWERK3 n"
      using power_def_2 sorry
    also have "... = a  |^NEWTONK1 n"
      using prepower_th_36 sorry
    finally show "a to-powerPOWERK2 n =HIDDENR1 a  |^NEWTONK1 n"
       sorry
  qed
qed "sorry"

mtheorem power_th_41:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a to-powerPOWERK2 n =COMPLEX1R1 a  |^NEWTONK1 n"
   sorry

mtheorem power_th_42:
" for k be IntegerINT-1M1 holds k <>HIDDENR2 0NUMBERSK6 implies (0NUMBERSK6)to-powerPOWERK2 k =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for k be IntegerINT-1M1 holds  not ( not k <>HIDDENR2 0NUMBERSK6 &  not (0NUMBERSK6)to-powerPOWERK2 k =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI)
    fix k assume [ty]: "k be IntegerINT-1M1"
    have "(0NUMBERSK6)to-powerPOWERK2 k =COMPLEX1R1 (0NUMBERSK6)#ZPREPOWERK3 k"
      using power_def_2 sorry
    thus " not ( not k <>HIDDENR2 0NUMBERSK6 &  not (0NUMBERSK6)to-powerPOWERK2 k =COMPLEX1R1 0NUMBERSK6)"
      using prepower_th_100 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_43:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a to-powerPOWERK2 k =COMPLEX1R1 a #ZPREPOWERK3 k"
  using power_def_2 sorry

mtheorem power_th_44:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 p =COMPLEX1R1 a #QPREPOWERK4 p"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 p =HIDDENR1 a #QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "a to-powerPOWERK2 p =HIDDENR1 a #RPREPOWERK6 p"
      using power_def_2 sorry
    also have "... = a #QPREPOWERK4 p"
      using A1 prepower_th_74 sorry
    finally show "a to-powerPOWERK2 p =HIDDENR1 a #QPREPOWERK4 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_45:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =COMPLEX1R1 n -rootPOWERK1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =COMPLEX1R1 n -rootPOWERK1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    obtain p where 
      [ty]:"p be RationalRAT-1M1" and pDef:"p = n \<inverse>XCMPLX-0K5"
       sorry
    have "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 n -RootPREPOWERK2 a"
    proof-
      show "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 n -RootPREPOWERK2 a"
      proof-
        have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
          using A1 sorry
        have case1: "a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 n -RootPREPOWERK2 a"
        proof(rule impI)
          assume "a >XXREAL-0R4 0NUMBERSK6"
          then have "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 a #QPREPOWERK4 p"
            using power_th_44 sorry
          also have "... = n -RootPREPOWERK2 a"
            using A2 prepower_th_50 sorry
          finally show "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 n -RootPREPOWERK2 a"
             sorry
        qed
        have case2: "a =COMPLEX1R1 0NUMBERSK6 implies a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 n -RootPREPOWERK2 a"
        proof(rule impI)
          assume A3: "a =COMPLEX1R1 0NUMBERSK6"
          then have "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 0NUMBERSK6"
            using A2 power_def_2 sorry
          also have "... = n -RootPREPOWERK2 a"
            using A2 A3 prepower_def_2 sorry
          finally show "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =HIDDENR1 n -RootPREPOWERK2 a"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 n) =COMPLEX1R1 n -rootPOWERK1 a"
      using A1 A2 power_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_46:
" for a be RealXREAL-0M1 holds a to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds a to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 a ^2SQUARE-1K1"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a ^2SQUARE-1K1"
    proof-
      show "a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a ^2SQUARE-1K1"
      proof-
        have cases: "(a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6) or a <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a ^2SQUARE-1K1"
        proof(rule impI)
          assume A1: "a >XXREAL-0R4 0NUMBERSK6"
          have "a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a to-powerPOWERK2 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
             sorry
          also have "... = a to-powerPOWERK2 \<one>\<^sub>M *XCMPLX-0K3 a to-powerPOWERK2 \<one>\<^sub>M"
            using A1 power_th_27 sorry
          also have "... = a to-powerPOWERK2 \<one>\<^sub>M *XCMPLX-0K3 a"
             sorry
          also have "... = a ^2SQUARE-1K1"
             sorry
          finally show "a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a ^2SQUARE-1K1"
             sorry
        qed
        have case2: "a =COMPLEX1R1 0NUMBERSK6 implies a to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 a ^2SQUARE-1K1"
        proof(rule impI)
          assume "a =COMPLEX1R1 0NUMBERSK6"
          thus "a to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 a ^2SQUARE-1K1"
            using power_def_2 sorry
        qed
        have case3: "a <XXREAL-0R3 0NUMBERSK6 implies a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a ^2SQUARE-1K1"
        proof(rule impI)
          assume A2: "a <XXREAL-0R3 0NUMBERSK6"
          obtain l where 
            [ty]:"l be IntegerINT-1M1" and lDef:"l = \<one>\<^sub>M"
             sorry
          have "a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a #ZPREPOWERK3 (l +XCMPLX-0K2 l)"
            using power_def_2 sorry
          also have "... = a #ZPREPOWERK3 l *XCMPLX-0K3 a #ZPREPOWERK3 l"
            using A2 prepower_th_44 sorry
          also have "... = a *XCMPLX-0K3 a #ZPREPOWERK3 l"
            using prepower_th_35 sorry
          also have "... = a ^2SQUARE-1K1"
            using prepower_th_35 sorry
          finally show "a to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 a ^2SQUARE-1K1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "a to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 a ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_47:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds k be evenABIANV1 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  not (k be evenABIANV1 &  not (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    have "( ex l be IntegerINT-1M1 st k =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 l) implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k"
    proof(rule impI)
      assume Given: " ex l be IntegerINT-1M1 st k =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 l"
      then obtain l where
        [ty]:"l be IntegerINT-1M1" and 
        A1: "k =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 l"
         sorry
      show "(-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k"
      proof-
        have cases: "(a =COMPLEX1R1 0NUMBERSK6 or a >XXREAL-0R4 0NUMBERSK6) or a <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "a =COMPLEX1R1 0NUMBERSK6 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k"
        proof(rule impI)
          assume "a =COMPLEX1R1 0NUMBERSK6"
          thus "(-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k"
             sorry
        qed
        have case2: "a >XXREAL-0R4 0NUMBERSK6 implies a to-powerPOWERK2 k =HIDDENR1 (-XCMPLX-0K4 a)to-powerPOWERK2 k"
        proof(rule impI)
          assume "a >XXREAL-0R4 0NUMBERSK6"
          then have "a to-powerPOWERK2 k =HIDDENR1 (a to-powerPOWERK2 \<two>\<^sub>M)to-powerPOWERK2 l"
            using A1 power_th_33 sorry
          also have "... = a ^2SQUARE-1K1 to-powerPOWERK2 l"
            using power_th_46 sorry
          also have "... = (-XCMPLX-0K4 a)^2SQUARE-1K1 to-powerPOWERK2 l"
             sorry
          also have "... = ((-XCMPLX-0K4 a)to-powerPOWERK2 \<two>\<^sub>M)to-powerPOWERK2 l"
            using power_th_46 sorry
          also have "... = ((-XCMPLX-0K4 a)#ZPREPOWERK3 \<two>\<^sub>M)to-powerPOWERK2 l"
            using power_def_2 sorry
          also have "... = ((-XCMPLX-0K4 a)#ZPREPOWERK3 \<two>\<^sub>M)#ZPREPOWERK3 l"
            using power_def_2 sorry
          also have "... = (-XCMPLX-0K4 a)#ZPREPOWERK3 (\<two>\<^sub>M *XCMPLX-0K3 l)"
            using prepower_th_45 sorry
          also have "... = (-XCMPLX-0K4 a)to-powerPOWERK2 k"
            using A1 power_def_2 sorry
          finally show "a to-powerPOWERK2 k =HIDDENR1 (-XCMPLX-0K4 a)to-powerPOWERK2 k"
             sorry
        qed
        have case3: "a <XXREAL-0R3 0NUMBERSK6 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =HIDDENR1 a to-powerPOWERK2 k"
        proof(rule impI)
          assume "a <XXREAL-0R3 0NUMBERSK6"
          then have "-XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_58 sorry
          then have "(-XCMPLX-0K4 a)to-powerPOWERK2 k =HIDDENR1 ((-XCMPLX-0K4 a)to-powerPOWERK2 \<two>\<^sub>M)to-powerPOWERK2 l"
            using A1 power_th_33 sorry
          also have "... = (-XCMPLX-0K4 a)^2SQUARE-1K1 to-powerPOWERK2 l"
            using power_th_46 sorry
          also have "... = a ^2SQUARE-1K1 to-powerPOWERK2 l"
             sorry
          also have "... = (a to-powerPOWERK2 \<two>\<^sub>M)to-powerPOWERK2 l"
            using power_th_46 sorry
          also have "... = (a #ZPREPOWERK3 \<two>\<^sub>M)to-powerPOWERK2 l"
            using power_def_2 sorry
          also have "... = (a #ZPREPOWERK3 \<two>\<^sub>M)#ZPREPOWERK3 l"
            using power_def_2 sorry
          also have "... = a #ZPREPOWERK3 (\<two>\<^sub>M *XCMPLX-0K3 l)"
            using prepower_th_45 sorry
          also have "... = a to-powerPOWERK2 k"
            using A1 power_def_2 sorry
          finally show "(-XCMPLX-0K4 a)to-powerPOWERK2 k =HIDDENR1 a to-powerPOWERK2 k"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus " not (k be evenABIANV1 &  not (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 a to-powerPOWERK2 k)"
      using int_1_def_3 abian_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_48:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds k be oddABIANV2 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds k be oddABIANV2 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    assume A1: "k be oddABIANV2"
    then obtain l where
      [ty]:"l be IntegerINT-1M1" and 
      A2: "k =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M"
      using abian_th_1 sorry
    show "(-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
    proof-
      have cases: "(a =COMPLEX1R1 0NUMBERSK6 or a >XXREAL-0R4 0NUMBERSK6) or a <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "a =COMPLEX1R1 0NUMBERSK6 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
      proof(rule impI)
        assume A3: "a =COMPLEX1R1 0NUMBERSK6"
        have "k <>HIDDENR2 0NUMBERSK6"
          using A1 sorry
        then have "a to-powerPOWERK2 k =COMPLEX1R1 0NUMBERSK6"
          using A3 power_th_42 sorry
        thus "(-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
          using A3 sorry
      qed
      have case2: "a >XXREAL-0R4 0NUMBERSK6 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
      proof(rule impI)
        assume A4: "a >XXREAL-0R4 0NUMBERSK6"
        then have A5: "-XCMPLX-0K4 a <>HIDDENR2 -XCMPLX-0K4 0NUMBERSK6"
           sorry
        have "a to-powerPOWERK2 k =HIDDENR1 a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 a to-powerPOWERK2 \<one>\<^sub>M"
          using A2 A4 power_th_27 sorry
        also have "... = a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 a"
           sorry
        also have "... = (-XCMPLX-0K4 a)to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 a"
          using power_th_47 sorry
        also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 (-XCMPLX-0K4 a)"
           sorry
        also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)#ZPREPOWERK3 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 (-XCMPLX-0K4 a)"
          using power_def_2 sorry
        also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)#ZPREPOWERK3 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 (-XCMPLX-0K4 a)#ZPREPOWERK3 \<one>\<^sub>M"
          using prepower_th_35 sorry
        also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)#ZPREPOWERK3 k"
          using A2 A5 prepower_th_44 sorry
        also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 a)to-powerPOWERK2 k"
          using power_def_2 sorry
        finally have "a to-powerPOWERK2 k =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 a)to-powerPOWERK2 k"
           sorry
        thus "(-XCMPLX-0K4 a)to-powerPOWERK2 k =COMPLEX1R1 -XCMPLX-0K4 a to-powerPOWERK2 k"
           sorry
      qed
      have case3: "a <XXREAL-0R3 0NUMBERSK6 implies (-XCMPLX-0K4 a)to-powerPOWERK2 k =HIDDENR1 -XCMPLX-0K4 a to-powerPOWERK2 k"
      proof(rule impI)
        assume A6: "a <XXREAL-0R3 0NUMBERSK6"
        then have "-XCMPLX-0K4 a >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_th_58 sorry
        then have "(-XCMPLX-0K4 a)to-powerPOWERK2 k =HIDDENR1 (-XCMPLX-0K4 a)to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 (-XCMPLX-0K4 a)to-powerPOWERK2 \<one>\<^sub>M"
          using A2 power_th_27 sorry
        also have "... = (-XCMPLX-0K4 a)to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 (-XCMPLX-0K4 a)"
           sorry
        also have "... = a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 (-XCMPLX-0K4 a)"
          using power_th_47 sorry
        also have "... = -XCMPLX-0K4 a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 a"
           sorry
        also have "... = -XCMPLX-0K4 a #ZPREPOWERK3 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 a"
          using power_def_2 sorry
        also have "... = -XCMPLX-0K4 a #ZPREPOWERK3 (\<two>\<^sub>M *XCMPLX-0K3 l) *XCMPLX-0K3 a #ZPREPOWERK3 \<one>\<^sub>M"
          using prepower_th_35 sorry
        also have "... = -XCMPLX-0K4 a #ZPREPOWERK3 k"
          using A2 A6 prepower_th_44 sorry
        also have "... = -XCMPLX-0K4 a to-powerPOWERK2 k"
          using power_def_2 sorry
        finally show "(-XCMPLX-0K4 a)to-powerPOWERK2 k =HIDDENR1 -XCMPLX-0K4 a to-powerPOWERK2 k"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_49:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a implies (\<one>\<^sub>M +XCMPLX-0K2 a)to-powerPOWERK2 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 a"
  using prepower_th_16 sorry

mtheorem power_th_50:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & c <>HIDDENR2 d implies a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
proof-
  have " for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & c <>HIDDENR2 d) implies  not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <>HIDDENR2 \<one>\<^sub>M"
      and A3: "c <>HIDDENR2 d"
    have " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
    proof-
      show " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
      proof-
        have cases: "c <XXREAL-0R3 d or c >XXREAL-0R4 d"
          using A3 xxreal_0_th_1 sorry
        have case1: "c <XXREAL-0R3 d implies  not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
        proof(rule impI)
          assume A4: "c <XXREAL-0R3 d"
          have " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
          proof-
            show " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
            proof-
              have cases: "a <XXREAL-0R3 \<one>\<^sub>M or a >XXREAL-0R4 \<one>\<^sub>M"
                using A2 xxreal_0_th_1 sorry
              have case1: "a <XXREAL-0R3 \<one>\<^sub>M implies  not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
              proof(rule impI)
                assume "a <XXREAL-0R3 \<one>\<^sub>M"
                thus " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
                  using A1 A4 power_th_40 sorry
              qed
              have case2: "a >XXREAL-0R4 \<one>\<^sub>M implies  not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
              proof(rule impI)
                assume "a >XXREAL-0R4 \<one>\<^sub>M"
                thus " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
                  using A4 power_th_39 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
             sorry
        qed
        have case2: "c >XXREAL-0R4 d implies  not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
        proof(rule impI)
          assume A5: "c >XXREAL-0R4 d"
          have " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
          proof-
            show " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
            proof-
              have cases: "a <XXREAL-0R3 \<one>\<^sub>M or a >XXREAL-0R4 \<one>\<^sub>M"
                using A2 xxreal_0_th_1 sorry
              have case1: "a <XXREAL-0R3 \<one>\<^sub>M implies  not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
              proof(rule impI)
                assume "a <XXREAL-0R3 \<one>\<^sub>M"
                thus " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
                  using A1 A5 power_th_40 sorry
              qed
              have case2: "a >XXREAL-0R4 \<one>\<^sub>M implies  not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
              proof(rule impI)
                assume "a >XXREAL-0R4 \<one>\<^sub>M"
                thus " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
                  using A5 power_th_39 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not a to-powerPOWERK2 c <>HIDDENR2 a to-powerPOWERK2 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef power_def_3 ("logPOWERK3'( _ , _ ')" [0,0]300 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"assume a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) func logPOWERK3(a,b) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. a to-powerPOWERK2 it =COMPLEX1R1 b"
proof-
  (*existence*)
    show "a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) implies ( ex it be RealXREAL-0M1 st a to-powerPOWERK2 it =COMPLEX1R1 b)"
    proof(rule impI)
      assume Assume: "a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6)"
      have A1: "a >XXREAL-0R4 0NUMBERSK6"
        using Assume sorry
      have A2: "a <>HIDDENR2 \<one>\<^sub>M"
        using Assume sorry
      have A3: "b >XXREAL-0R4 0NUMBERSK6"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st a to-powerPOWERK2 it =COMPLEX1R1 b"
      proof-
        have " not ( for VarFor1 be RealXREAL-0M1 holds  not a to-powerPOWERK2 VarFor1 =COMPLEX1R1 b)"
        proof-
          obtain a1 b1 where 
            [ty]:"a1 be RealXREAL-0M1" and a1Def:"a1 = a" and
            [ty]:"b1 be RealXREAL-0M1" and b1Def:"b1 = b"
             sorry
          let ?X = "{c where c be RealXREAL-0M1 : a to-powerPOWERK2 c <=XXREAL-0R1 b }"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 ?X implies x inHIDDENR3 REALNUMBERSK2"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {c where c be RealXREAL-0M1 : a to-powerPOWERK2 c <=XXREAL-0R1 b } implies x inHIDDENR3 REALNUMBERSK2"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ?X"
              then have " ex c be RealXREAL-0M1 st x =HIDDENR1 c & a to-powerPOWERK2 c <=XXREAL-0R1 b"
                 sorry
              thus "x inHIDDENR3 REALNUMBERSK2"
                using xreal_0_def_1 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          then obtain X where 
            [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = ?X"
            using tarski_def_3 sorry
          have A4: " ex d be RealXREAL-0M1 st d inHIDDENR3 X"
          proof-
            have " ex tVar2 be RealXREAL-0M1 st tVar2 inHIDDENR3 X"
            proof-
              have A5: " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6 implies ( ex d be RealXREAL-0M1 st a to-powerPOWERK2 d <=XXREAL-0R1 b)"
              proof(rule ballI,rule ballI,rule impMI ,rule impI)
                fix a assume [ty]: "a be RealXREAL-0M1"
                fix b assume [ty]: "b be RealXREAL-0M1"
                assume A6: "a >XXREAL-0R4 \<one>\<^sub>M"
                  and A7: "b >XXREAL-0R4 0NUMBERSK6"
                obtain a1 b1 where 
                  [ty]:"a1 be RealXREAL-0M1" and a1Def:"a1 = a" and
                  [ty]:"b1 be RealXREAL-0M1" and b1Def:"b1 = b"
                   sorry
                let ?e = "a1 -XCMPLX-0K6 \<one>\<^sub>M"
                obtain n where
                  [ty]:"n be NatNAT-1M1" and 
                  A8: "n >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 (b *XCMPLX-0K3 ?e)"
                  using seq_4_th_3 sorry
                have "?e >XXREAL-0R4 0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M"
                  using A6 xreal_1_th_9 sorry
                then have A9: "(\<one>\<^sub>M +XCMPLX-0K2 ?e)to-powerPOWERK2 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 ?e"
                  using prepower_th_16 sorry
                have "\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 ?e >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 n *XCMPLX-0K3 ?e"
                  using xreal_1_th_6 sorry
                then have A10: "(\<one>\<^sub>M +XCMPLX-0K2 ?e)to-powerPOWERK2 n >=XXREAL-0R2 n *XCMPLX-0K3 ?e"
                  using A9 xxreal_0_th_2 sorry
                have A11: "?e >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                  using A6 xreal_1_th_9 sorry
                then have "n *XCMPLX-0K3 ?e >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 (b *XCMPLX-0K3 ?e))*XCMPLX-0K3 ?e"
                  using A8 xreal_1_th_68 sorry
                then have "n *XCMPLX-0K3 ?e >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 b"
                  using A11 xcmplx_1_th_92 sorry
                then have "a to-powerPOWERK2 n >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 b"
                  using A10 xxreal_0_th_2 sorry
                then have "\<one>\<^sub>M /XCMPLX-0K7 a to-powerPOWERK2 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 b)"
                  using A7 xreal_1_th_85 sorry
                then have "a1 to-powerPOWERK2 (-XCMPLX-0K4 n) <=XXREAL-0R1 b1"
                  using A6 power_th_28 sorry
                thus " ex d be RealXREAL-0M1 st a to-powerPOWERK2 d <=XXREAL-0R1 b"
                   sorry
              qed "sorry"
              have " ex d be RealXREAL-0M1 st a to-powerPOWERK2 d <=XXREAL-0R1 b"
              proof-
                show " ex d be RealXREAL-0M1 st a to-powerPOWERK2 d <=XXREAL-0R1 b"
                proof-
                  have cases: "a >XXREAL-0R4 \<one>\<^sub>M or a <XXREAL-0R3 \<one>\<^sub>M"
                    using A2 xxreal_0_th_1 sorry
                  have case1: "a >XXREAL-0R4 \<one>\<^sub>M implies ( ex d be RealXREAL-0M1 st a to-powerPOWERK2 d <=XXREAL-0R1 b)"
                  proof(rule impI)
                    assume "a >XXREAL-0R4 \<one>\<^sub>M"
                    thus " ex d be RealXREAL-0M1 st a to-powerPOWERK2 d <=XXREAL-0R1 b"
                      using A3 A5 sorry
                  qed
                  have case2: "a <XXREAL-0R3 \<one>\<^sub>M implies ( ex e be RealXREAL-0M1 st a to-powerPOWERK2 e <=XXREAL-0R1 b)"
                  proof(rule impI)
                    assume "a <XXREAL-0R3 \<one>\<^sub>M"
                    then have "\<one>\<^sub>M /XCMPLX-0K7 a >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
                      using A1 xreal_1_th_88 sorry
                    then obtain d where
                      [ty]:"d be RealXREAL-0M1" and 
                      A12: "(\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 d <=XXREAL-0R1 b"
                      using A3 A5 sorry
                    have "a1 to-powerPOWERK2 (-XCMPLX-0K4 d) <=XXREAL-0R1 b1"
                      using A1 A12 power_th_32 sorry
                    thus " ex e be RealXREAL-0M1 st a to-powerPOWERK2 e <=XXREAL-0R1 b"
                       sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              then obtain d where
                [ty]:"d be RealXREAL-0M1" and 
                A13: "a to-powerPOWERK2 d <=XXREAL-0R1 b"
                 sorry
              show " ex tVar2 be RealXREAL-0M1 st tVar2 inHIDDENR3 X"
              proof(rule bexI[of _ "d"])
                show "d inHIDDENR3 X"
                  using A13 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          have " ex d be objectHIDDENM1 st b =COMPLEX1R1 a to-powerPOWERK2 d"
          proof-
            show " ex d be objectHIDDENM1 st b =COMPLEX1R1 a to-powerPOWERK2 d"
            proof-
              have cases: "a >XXREAL-0R4 \<one>\<^sub>M or a <XXREAL-0R3 \<one>\<^sub>M"
                using A2 xxreal_0_th_1 sorry
              have case1: "a >XXREAL-0R4 \<one>\<^sub>M implies ( ex d be objectHIDDENM1 st b =COMPLEX1R1 a to-powerPOWERK2 d)"
              proof(rule impI)
                assume A14: "a >XXREAL-0R4 \<one>\<^sub>M"
                have A15: "X be bounded-aboveXXREAL-2V4"
                proof-
                  obtain n where
                    [ty]:"n be NatNAT-1M1" and 
                    A16: "n >XXREAL-0R4 (b1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (a1 -XCMPLX-0K6 \<one>\<^sub>M)"
                    using seq_4_th_3 sorry
                  have "a -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                    using A14 xreal_1_th_9 sorry
                  then have "n *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 b -XCMPLX-0K6 \<one>\<^sub>M"
                    using A16 xreal_1_th_77 sorry
                  then have A17: "\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M +XCMPLX-0K2 (b -XCMPLX-0K6 \<one>\<^sub>M)"
                    using xreal_1_th_6 sorry
                  have "a -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M"
                    using A1 xreal_1_th_9 sorry
                  then have "(\<one>\<^sub>M +XCMPLX-0K2 (a1 -XCMPLX-0K6 \<one>\<^sub>M))to-powerPOWERK2 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (a1 -XCMPLX-0K6 \<one>\<^sub>M)"
                    using prepower_th_16 sorry
                  then have A18: "a to-powerPOWERK2 n >XXREAL-0R4 b"
                    using A17 xxreal_0_th_2 sorry
                  have " for c be ExtRealXXREAL-0M1 holds c inHIDDENR3 X implies c <=XXREAL-0R1 n"
                  proof(rule ballI,rule impI)
                    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
                    assume "c inHIDDENR3 X"
                    then obtain d where
                      [ty]:"d be RealXREAL-0M1" and 
                      A19: "d =HIDDENR1 c & a to-powerPOWERK2 d <=XXREAL-0R1 b"
                       sorry
                    have "a1 to-powerPOWERK2 d <=XXREAL-0R1 a1 to-powerPOWERK2 n"
                      using A18 A19 xxreal_0_th_2 sorry
                    thus "c <=XXREAL-0R1 n"
                      using A14 power_th_39 A19 sorry
                  qed "sorry"
                  then have "n be UpperBoundXXREAL-2M1-of X"
                    using xxreal_2_def_1 sorry
                  thus "X be bounded-aboveXXREAL-2V4"
                    using bexI[of _ "n"] xxreal_2_def_10 sorry
                qed
                obtain d where 
                  [ty]:"d be objectHIDDENM1" and dDef:"d = upper-boundSEQ-4K2 X"
                   sorry
                show " ex d be objectHIDDENM1 st b =COMPLEX1R1 a to-powerPOWERK2 d"
                proof(rule bexI[of _ "d"])
                  have A20: " not b <XXREAL-0R3 a to-powerPOWERK2 d"
                  proof-
                    have "a to-powerPOWERK2 d >XXREAL-0R4 b implies  False "
                    proof(rule impI)
                      assume "a to-powerPOWERK2 d >XXREAL-0R4 b"
                      then obtain e where
                        [ty]:"e be RealXREAL-0M1" and 
                        A21: "b <XXREAL-0R3 e"and A22: "e <XXREAL-0R3 a to-powerPOWERK2 d"
                        using xreal_1_th_5 sorry
                      have 
                        [ty]:"e be RealXREAL-0M1"
                         sorry
                      obtain n where
                        [ty]:"n be NatNAT-1M1" and 
                        A23: "n >XXREAL-0R4 (a1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (e /XCMPLX-0K7 b1 -XCMPLX-0K6 \<one>\<^sub>M)"
                        using seq_4_th_3 sorry
                      obtain m where 
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = maxXXREAL-0K5(\<one>\<^sub>M,n)"
                        using ordinal1_def_12 sorry
                      have "n <=XXREAL-0R1 m"
                        using xxreal_0_th_25 sorry
                      then have A24: "(a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 m"
                        using A23 xxreal_0_th_2 sorry
                      have "e /XCMPLX-0K7 b >XXREAL-0R4 \<one>\<^sub>M"
                        using A3 A21 xreal_1_th_187 sorry
                      then have "e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                        using xreal_1_th_9 sorry
                      then have A25: "a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 m *XCMPLX-0K3 (e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M)"
                        using A24 xreal_1_th_77 sorry
                      have A26: "\<one>\<^sub>M <=XXREAL-0R1 m"
                        using xxreal_0_th_25 sorry
                      then have "(a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m <XXREAL-0R3 e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M"
                        using A25 xreal_1_th_83 sorry
                      then have A27: "(a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 (e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                        using xreal_1_th_6 sorry
                      have "m -rootPOWERK1 a1 -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m"
                        using A1 power_th_22 xxreal_0_th_25 sorry
                      then have "(m -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m +XCMPLX-0K2 \<one>\<^sub>M"
                        using xreal_1_th_6 sorry
                      then have "m -rootPOWERK1 a <=XXREAL-0R1 e /XCMPLX-0K7 b"
                        using A27 xxreal_0_th_2 sorry
                      then have "a1 to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 e /XCMPLX-0K7 b1"
                        using A1 power_th_45 xxreal_0_th_25 sorry
                      then have A28: "a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) *XCMPLX-0K3 b <=XXREAL-0R1 e"
                        using A3 xreal_1_th_83 sorry
                      obtain c where
                        [ty]:"c be RealXREAL-0M1" and 
                        A29: "c inHIDDENR3 X"and A30: "d -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 m <XXREAL-0R3 c"
                        using A4 A15 A26 seq_4_def_1 sorry
                      have 
                        [ty]:"c be RealXREAL-0M1"
                         sorry
                      have A31: " ex g be RealXREAL-0M1 st g =COMPLEX1R1 c & a to-powerPOWERK2 g <=XXREAL-0R1 b"
                        using A29 sorry
                      have "a1 to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) >=XXREAL-0R2 0NUMBERSK6"
                        using A1 power_th_34 sorry
                      then have "a to-powerPOWERK2 c *XCMPLX-0K3 a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) *XCMPLX-0K3 b"
                        using A31 xreal_1_th_64 sorry
                      then have "a to-powerPOWERK2 c *XCMPLX-0K3 a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 e"
                        using A28 xxreal_0_th_2 sorry
                      then have A32: "a1 to-powerPOWERK2 (c +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 e"
                        using A1 power_th_27 sorry
                      have "d <XXREAL-0R3 c +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m"
                        using A30 xreal_1_th_19 sorry
                      then have "a1 to-powerPOWERK2 d <=XXREAL-0R1 a1 to-powerPOWERK2 (c +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m)"
                        using A14 power_th_39 sorry
                      thus " False "
                        using A22 A32 xxreal_0_th_2 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  have " not a to-powerPOWERK2 d <XXREAL-0R3 b"
                  proof-
                    have "a to-powerPOWERK2 d <XXREAL-0R3 b implies  False "
                    proof(rule impI)
                      assume "a to-powerPOWERK2 d <XXREAL-0R3 b"
                      then obtain e where
                        [ty]:"e be RealXREAL-0M1" and 
                        A33: "a to-powerPOWERK2 d <XXREAL-0R3 e"and A34: "e <XXREAL-0R3 b"
                        using xreal_1_th_5 sorry
                      have 
                        [ty]:"e be RealXREAL-0M1"
                         sorry
                      have A35: "a1 to-powerPOWERK2 d >XXREAL-0R4 0NUMBERSK6"
                        using A1 power_th_34 sorry
                      then have "b /XCMPLX-0K7 e >XXREAL-0R4 \<one>\<^sub>M"
                        using A33 A34 xreal_1_th_187 sorry
                      then have A36: "b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                        using xreal_1_th_9 sorry
                      let ?F = "\<lambda>Lamb1. Lamb1 -rootPOWERK1 a"
                      obtain s where
                        [ty]:"s be Real-SequenceSEQ-1M1" and 
                        A37: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
                        using seq_1_sch_1 sorry
                      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 a1"
                        using A37 sorry
                      then have "s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
                        using A1 power_th_23 sorry
                      then obtain n where
                        [ty]:"n be NatNAT-1M1" and 
                        A38: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A36 seq_2_def_7 sorry
                      obtain m where 
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = maxXXREAL-0K5(\<one>\<^sub>M,n)"
                        using ordinal1_def_12 sorry
                      have " |.COMPLEX1K10 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A38 xxreal_0_th_25 sorry
                      then have A39: " |.COMPLEX1K10 m -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A37 sorry
                      have "m -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1  |.COMPLEX1K10 m -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M .|"
                        using absvalue_th_4 sorry
                      then have "m -rootPOWERK1 a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A39 xxreal_0_th_2 sorry
                      then have "m -rootPOWERK1 a <XXREAL-0R3 b /XCMPLX-0K7 e"
                        using xreal_1_th_9 sorry
                      then have "a1 to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 b1 /XCMPLX-0K7 e"
                        using A1 power_th_45 xxreal_0_th_25 sorry
                      then have "a to-powerPOWERK2 d *XCMPLX-0K3 a to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 (b /XCMPLX-0K7 e)*XCMPLX-0K3 a to-powerPOWERK2 d"
                        using A35 xreal_1_th_68 sorry
                      then have A40: "a to-powerPOWERK2 (d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 (b *XCMPLX-0K3 a to-powerPOWERK2 d)/XCMPLX-0K7 e"
                        using A1 power_th_27 sorry
                      have "a to-powerPOWERK2 d /XCMPLX-0K7 e <XXREAL-0R3 \<one>\<^sub>M"
                        using A33 A35 xreal_1_th_189 sorry
                      then have "(a to-powerPOWERK2 d /XCMPLX-0K7 e)*XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 b"
                        using A3 xreal_1_th_68 sorry
                      then have "a to-powerPOWERK2 (d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 b"
                        using A40 xxreal_0_th_2 sorry
                      then have "d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m inHIDDENR3 X"
                         sorry
                      then have "m >=XXREAL-0R2 \<one>\<^sub>M & d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m <=XXREAL-0R1 d"
                        using A15 seq_4_def_1 xxreal_0_th_25 sorry
                      thus " False "
                        using xreal_1_th_29 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  thus "b =COMPLEX1R1 a to-powerPOWERK2 d"
                    using A20 xxreal_0_th_1 sorry
                qed "sorry"
              qed
              have case2: "a <XXREAL-0R3 \<one>\<^sub>M implies ( ex d be objectHIDDENM1 st b =COMPLEX1R1 a to-powerPOWERK2 d)"
              proof(rule impI)
                assume A41: "a <XXREAL-0R3 \<one>\<^sub>M"
                have A42: "X be bounded-belowXXREAL-2V3"
                proof-
                  obtain n where
                    [ty]:"n be NatNAT-1M1" and 
                    A43: "n >XXREAL-0R4 (b1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a1 -XCMPLX-0K6 \<one>\<^sub>M)"
                    using seq_4_th_3 sorry
                  have "\<one>\<^sub>M /XCMPLX-0K7 a >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
                    using A1 A41 xreal_1_th_88 sorry
                  then have "\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                    using xreal_1_th_9 sorry
                  then have "n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 b -XCMPLX-0K6 \<one>\<^sub>M"
                    using A43 xreal_1_th_77 sorry
                  then have A44: "\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M +XCMPLX-0K2 (b -XCMPLX-0K6 \<one>\<^sub>M)"
                    using xreal_1_th_6 sorry
                  have "\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M"
                    using A1 xreal_1_th_9 sorry
                  then have "(\<one>\<^sub>M +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a1 -XCMPLX-0K6 \<one>\<^sub>M))to-powerPOWERK2 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a1 -XCMPLX-0K6 \<one>\<^sub>M)"
                    using prepower_th_16 sorry
                  then have "(\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 n >XXREAL-0R4 b"
                    using A44 xxreal_0_th_2 sorry
                  then have A45: "a1 to-powerPOWERK2 (-XCMPLX-0K4 n) >XXREAL-0R4 b1"
                    using A1 power_th_32 sorry
                  have " for c be ExtRealXXREAL-0M1 holds c inHIDDENR3 X implies c >=XXREAL-0R2 -XCMPLX-0K4 n"
                  proof(rule ballI,rule impI)
                    fix c assume [ty]: "c be ExtRealXXREAL-0M1"
                    assume "c inHIDDENR3 X"
                    then obtain d where
                      [ty]:"d be RealXREAL-0M1" and 
                      A46: "d =HIDDENR1 c & a to-powerPOWERK2 d <=XXREAL-0R1 b"
                       sorry
                    have "a1 to-powerPOWERK2 d <=XXREAL-0R1 a1 to-powerPOWERK2 (-XCMPLX-0K4 n)"
                      using A45 A46 xxreal_0_th_2 sorry
                    thus "c >=XXREAL-0R2 -XCMPLX-0K4 n"
                      using A1 A41 power_th_40 A46 sorry
                  qed "sorry"
                  then have "-XCMPLX-0K4 n be LowerBoundXXREAL-2M2-of X"
                    using xxreal_2_def_2 sorry
                  thus "X be bounded-belowXXREAL-2V3"
                    using bexI[of _ "-XCMPLX-0K4 n"] xxreal_2_def_9 sorry
                qed
                obtain d where 
                  [ty]:"d be objectHIDDENM1" and dDef:"d = lower-boundSEQ-4K3 X"
                   sorry
                show " ex d be objectHIDDENM1 st b =COMPLEX1R1 a to-powerPOWERK2 d"
                proof(rule bexI[of _ "d"])
                  have A47: " not b <XXREAL-0R3 a to-powerPOWERK2 d"
                  proof-
                    have "a to-powerPOWERK2 d >XXREAL-0R4 b implies  False "
                    proof(rule impI)
                      assume "a to-powerPOWERK2 d >XXREAL-0R4 b"
                      then obtain e where
                        [ty]:"e be RealXREAL-0M1" and 
                        A48: "b <XXREAL-0R3 e"and A49: "e <XXREAL-0R3 a to-powerPOWERK2 d"
                        using xreal_1_th_5 sorry
                      have 
                        [ty]:"e be RealXREAL-0M1"
                         sorry
                      obtain n where
                        [ty]:"n be NatNAT-1M1" and 
                        A50: "n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 a1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (e /XCMPLX-0K7 b1 -XCMPLX-0K6 \<one>\<^sub>M)"
                        using seq_4_th_3 sorry
                      obtain m where 
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = maxXXREAL-0K5(\<one>\<^sub>M,n)"
                        using ordinal1_def_12 sorry
                      have "n <=XXREAL-0R1 m"
                        using xxreal_0_th_25 sorry
                      then have A51: "(\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 m"
                        using A50 xxreal_0_th_2 sorry
                      have "e /XCMPLX-0K7 b >XXREAL-0R4 \<one>\<^sub>M"
                        using A3 A48 xreal_1_th_187 sorry
                      then have "e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                        using xreal_1_th_9 sorry
                      then have A52: "\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 m *XCMPLX-0K3 (e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M)"
                        using A51 xreal_1_th_77 sorry
                      have A53: "\<one>\<^sub>M <=XXREAL-0R1 m"
                        using xxreal_0_th_25 sorry
                      then have "(\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m <XXREAL-0R3 e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M"
                        using A52 xreal_1_th_83 sorry
                      then have A54: "(\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 (e /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
                        using xreal_1_th_6 sorry
                      have "m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a1) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (\<one>\<^sub>M /XCMPLX-0K7 a1 -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m"
                        using A1 power_th_22 xxreal_0_th_25 sorry
                      then have "(m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 (\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 m +XCMPLX-0K2 \<one>\<^sub>M"
                        using xreal_1_th_6 sorry
                      then have "m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) <=XXREAL-0R1 e /XCMPLX-0K7 b"
                        using A54 xxreal_0_th_2 sorry
                      then have "(\<one>\<^sub>M /XCMPLX-0K7 a1)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 e /XCMPLX-0K7 b1"
                        using A1 power_th_45 xxreal_0_th_25 sorry
                      then have "(\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) *XCMPLX-0K3 b <=XXREAL-0R1 e"
                        using A3 xreal_1_th_83 sorry
                      then have A55: "a1 to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 m) *XCMPLX-0K3 b1 <=XXREAL-0R1 e"
                        using A1 power_th_32 sorry
                      obtain c where
                        [ty]:"c be RealXREAL-0M1" and 
                        A56: "c inHIDDENR3 X"and A57: "c <XXREAL-0R3 d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 m"
                        using A4 A42 A53 seq_4_def_2 sorry
                      have 
                        [ty]:"c be RealXREAL-0M1"
                         sorry
                      have A58: " ex g be RealXREAL-0M1 st g =COMPLEX1R1 c & a to-powerPOWERK2 g <=XXREAL-0R1 b"
                        using A56 sorry
                      have "a1 to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 m) >=XXREAL-0R2 0NUMBERSK6"
                        using A1 power_th_34 sorry
                      then have "a to-powerPOWERK2 c *XCMPLX-0K3 a to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 a to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 m) *XCMPLX-0K3 b"
                        using A58 xreal_1_th_64 sorry
                      then have "a to-powerPOWERK2 c *XCMPLX-0K3 a to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 m) <=XXREAL-0R1 e"
                        using A55 xxreal_0_th_2 sorry
                      then have A59: "a1 to-powerPOWERK2 (c +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 m)) <=XXREAL-0R1 e"
                        using A1 power_th_27 sorry
                      have "d >XXREAL-0R4 c -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 m"
                        using A57 xreal_1_th_19 sorry
                      then have "a1 to-powerPOWERK2 d <=XXREAL-0R1 a1 to-powerPOWERK2 (c -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 m)"
                        using A1 A41 power_th_40 sorry
                      thus " False "
                        using A49 A59 xxreal_0_th_2 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  have " not a to-powerPOWERK2 d <XXREAL-0R3 b"
                  proof-
                    have "a to-powerPOWERK2 d <XXREAL-0R3 b implies  False "
                    proof(rule impI)
                      assume "a to-powerPOWERK2 d <XXREAL-0R3 b"
                      then obtain e where
                        [ty]:"e be RealXREAL-0M1" and 
                        A60: "a to-powerPOWERK2 d <XXREAL-0R3 e"and A61: "e <XXREAL-0R3 b"
                        using xreal_1_th_5 sorry
                      have 
                        [ty]:"e be RealXREAL-0M1"
                         sorry
                      have A62: "a1 to-powerPOWERK2 d >XXREAL-0R4 0NUMBERSK6"
                        using A1 power_th_34 sorry
                      then have "b /XCMPLX-0K7 e >XXREAL-0R4 \<one>\<^sub>M"
                        using A60 A61 xreal_1_th_187 sorry
                      then have A63: "b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                        using xreal_1_th_9 sorry
                      let ?F = "\<lambda>Lamb1. Lamb1 -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a)"
                      obtain s where
                        [ty]:"s be Real-SequenceSEQ-1M1" and 
                        A64: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
                        using seq_1_sch_1 sorry
                      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a1)"
                        using A64 sorry
                      then have "s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
                        using A1 power_th_23 sorry
                      then obtain n where
                        [ty]:"n be NatNAT-1M1" and 
                        A65: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A63 seq_2_def_7 sorry
                      obtain m where 
                        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = maxXXREAL-0K5(\<one>\<^sub>M,n)"
                        using ordinal1_def_12 sorry
                      have " |.COMPLEX1K10 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A65 xxreal_0_th_25 sorry
                      then have A66: " |.COMPLEX1K10 m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A64 sorry
                      have "m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1  |.COMPLEX1K10 m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M .|"
                        using absvalue_th_4 sorry
                      then have "m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 e -XCMPLX-0K6 \<one>\<^sub>M"
                        using A66 xxreal_0_th_2 sorry
                      then have "m -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 a) <XXREAL-0R3 b /XCMPLX-0K7 e"
                        using xreal_1_th_9 sorry
                      then have "(\<one>\<^sub>M /XCMPLX-0K7 a1)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 b1 /XCMPLX-0K7 e"
                        using A1 power_th_45 xxreal_0_th_25 sorry
                      then have "a to-powerPOWERK2 d *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)to-powerPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 (b /XCMPLX-0K7 e)*XCMPLX-0K3 a to-powerPOWERK2 d"
                        using A62 xreal_1_th_68 sorry
                      then have "a1 to-powerPOWERK2 d *XCMPLX-0K3 a1 to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 (b1 /XCMPLX-0K7 e)*XCMPLX-0K3 a1 to-powerPOWERK2 d"
                        using A1 power_th_32 sorry
                      then have A67: "a to-powerPOWERK2 (d -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 (b *XCMPLX-0K3 a to-powerPOWERK2 d)/XCMPLX-0K7 e"
                        using A1 power_th_27 sorry
                      have "a to-powerPOWERK2 d /XCMPLX-0K7 e <XXREAL-0R3 \<one>\<^sub>M"
                        using A60 A62 xreal_1_th_189 sorry
                      then have "(a to-powerPOWERK2 d /XCMPLX-0K7 e)*XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 b"
                        using A3 xreal_1_th_68 sorry
                      then have "a to-powerPOWERK2 (d -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 m) <XXREAL-0R3 b"
                        using A67 xxreal_0_th_2 sorry
                      then have "d -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 m inHIDDENR3 X"
                         sorry
                      then have "m >=XXREAL-0R2 \<one>\<^sub>M & d -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 m >=XXREAL-0R2 d"
                        using A42 seq_4_def_2 xxreal_0_th_25 sorry
                      thus " False "
                        using xreal_1_th_44 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  thus "b =COMPLEX1R1 a to-powerPOWERK2 d"
                    using A47 xxreal_0_th_1 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( for VarFor1 be RealXREAL-0M1 holds  not a to-powerPOWERK2 VarFor1 =COMPLEX1R1 b)"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds a to-powerPOWERK2 it1 =COMPLEX1R1 b & a to-powerPOWERK2 it2 =COMPLEX1R1 b implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6)"
      have A1: "a >XXREAL-0R4 0NUMBERSK6"
        using Assume sorry
      have A2: "a <>HIDDENR2 \<one>\<^sub>M"
        using Assume sorry
      have A3: "b >XXREAL-0R4 0NUMBERSK6"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds a to-powerPOWERK2 it1 =COMPLEX1R1 b & a to-powerPOWERK2 it2 =COMPLEX1R1 b implies it1 =HIDDENR1 it2"
        using A1 A2 power_th_50 sorry
    qed
qed "sorry"

mtheorem power_th_51:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M implies logPOWERK3(a,\<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M implies logPOWERK3(a,\<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M"
    have "a to-powerPOWERK2 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
      using power_th_24 sorry
    thus "logPOWERK3(a,\<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
      using A1 power_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_52:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M implies logPOWERK3(a,a) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M implies logPOWERK3(a,a) =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M"
    have "a to-powerPOWERK2 \<one>\<^sub>M =COMPLEX1R1 a"
       sorry
    thus "logPOWERK3(a,a) =COMPLEX1R1 \<one>\<^sub>M"
      using A1 power_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,b) +XCMPLX-0K2 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b *XCMPLX-0K3 c)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & (b >XXREAL-0R4 0NUMBERSK6 & c >XXREAL-0R4 0NUMBERSK6)) implies logPOWERK3(a,b) +XCMPLX-0K2 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b *XCMPLX-0K3 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <>HIDDENR2 \<one>\<^sub>M"
      and A3: "b >XXREAL-0R4 0NUMBERSK6"
      and A4: "c >XXREAL-0R4 0NUMBERSK6"
    have A5: "a to-powerPOWERK2 (logPOWERK3(a,b) +XCMPLX-0K2 logPOWERK3(a,c)) =HIDDENR1 a to-powerPOWERK2 logPOWERK3(a,b) *XCMPLX-0K3 a to-powerPOWERK2 logPOWERK3(a,c)"
      using A1 power_th_27 sorry
    also have "... = b *XCMPLX-0K3 a to-powerPOWERK2 logPOWERK3(a,c)"
      using A1 A2 A3 power_def_3 sorry
    also have "... = b *XCMPLX-0K3 c"
      using A1 A2 A4 power_def_3 sorry
    finally have "a to-powerPOWERK2 (logPOWERK3(a,b) +XCMPLX-0K2 logPOWERK3(a,c)) =HIDDENR1 b *XCMPLX-0K3 c"
       sorry
    have "b *XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6"
      using A3 A4 xreal_1_th_129 sorry
    thus "logPOWERK3(a,b) +XCMPLX-0K2 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b *XCMPLX-0K3 c)"
      using A1 A2 A5 power_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_54:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,b) -XCMPLX-0K6 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b /XCMPLX-0K7 c)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & (b >XXREAL-0R4 0NUMBERSK6 & c >XXREAL-0R4 0NUMBERSK6)) implies logPOWERK3(a,b) -XCMPLX-0K6 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b /XCMPLX-0K7 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <>HIDDENR2 \<one>\<^sub>M"
      and A3: "b >XXREAL-0R4 0NUMBERSK6"
      and A4: "c >XXREAL-0R4 0NUMBERSK6"
    have A5: "a to-powerPOWERK2 (logPOWERK3(a,b) -XCMPLX-0K6 logPOWERK3(a,c)) =HIDDENR1 a to-powerPOWERK2 logPOWERK3(a,b) /XCMPLX-0K7 a to-powerPOWERK2 logPOWERK3(a,c)"
      using A1 power_th_29 sorry
    also have "... = b /XCMPLX-0K7 a to-powerPOWERK2 logPOWERK3(a,c)"
      using A1 A2 A3 power_def_3 sorry
    also have "... = b /XCMPLX-0K7 c"
      using A1 A2 A4 power_def_3 sorry
    finally have "a to-powerPOWERK2 (logPOWERK3(a,b) -XCMPLX-0K6 logPOWERK3(a,c)) =HIDDENR1 b /XCMPLX-0K7 c"
       sorry
    have "b /XCMPLX-0K7 c >XXREAL-0R4 0NUMBERSK6"
      using A3 A4 xreal_1_th_139 sorry
    thus "logPOWERK3(a,b) -XCMPLX-0K6 logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b /XCMPLX-0K7 c)"
      using A1 A2 A5 power_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_55:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,b to-powerPOWERK2 c) =COMPLEX1R1 c *XCMPLX-0K3 logPOWERK3(a,b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) implies logPOWERK3(a,b to-powerPOWERK2 c) =COMPLEX1R1 c *XCMPLX-0K3 logPOWERK3(a,b)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <>HIDDENR2 \<one>\<^sub>M"
      and A3: "b >XXREAL-0R4 0NUMBERSK6"
    have A4: "b to-powerPOWERK2 c >XXREAL-0R4 0NUMBERSK6"
      using A3 power_th_34 sorry
    have "a to-powerPOWERK2 (c *XCMPLX-0K3 logPOWERK3(a,b)) =HIDDENR1 (a to-powerPOWERK2 logPOWERK3(a,b))to-powerPOWERK2 c"
      using A1 power_th_33 sorry
    also have "... = b to-powerPOWERK2 c"
      using A1 A2 A3 power_def_3 sorry
    finally have "a to-powerPOWERK2 (c *XCMPLX-0K3 logPOWERK3(a,b)) =HIDDENR1 b to-powerPOWERK2 c"
       sorry
    thus "logPOWERK3(a,b to-powerPOWERK2 c) =COMPLEX1R1 c *XCMPLX-0K3 logPOWERK3(a,b)"
      using A1 A2 A4 power_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_56:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & b <>HIDDENR2 \<one>\<^sub>M) & c >XXREAL-0R4 0NUMBERSK6 implies logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b) *XCMPLX-0K3 logPOWERK3(b,c)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <>HIDDENR2 \<one>\<^sub>M & (b >XXREAL-0R4 0NUMBERSK6 & (b <>HIDDENR2 \<one>\<^sub>M & c >XXREAL-0R4 0NUMBERSK6))) implies logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b) *XCMPLX-0K3 logPOWERK3(b,c)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <>HIDDENR2 \<one>\<^sub>M"
      and A3: "b >XXREAL-0R4 0NUMBERSK6"
      and A4: "b <>HIDDENR2 \<one>\<^sub>M"
      and A5: "c >XXREAL-0R4 0NUMBERSK6"
    have "a to-powerPOWERK2 (logPOWERK3(a,b) *XCMPLX-0K3 logPOWERK3(b,c)) =HIDDENR1 (a to-powerPOWERK2 logPOWERK3(a,b))to-powerPOWERK2 logPOWERK3(b,c)"
      using A1 power_th_33 sorry
    also have "... = b to-powerPOWERK2 logPOWERK3(b,c)"
      using A1 A2 A3 power_def_3 sorry
    also have "... = c"
      using A3 A4 A5 power_def_3 sorry
    finally have "a to-powerPOWERK2 (logPOWERK3(a,b) *XCMPLX-0K3 logPOWERK3(b,c)) =HIDDENR1 c"
       sorry
    thus "logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b) *XCMPLX-0K3 logPOWERK3(b,c)"
      using A1 A2 A5 power_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_57:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 b implies logPOWERK3(a,c) >XXREAL-0R4 logPOWERK3(a,b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & (b >XXREAL-0R4 0NUMBERSK6 & (c >XXREAL-0R4 b & logPOWERK3(a,c) <=XXREAL-0R1 logPOWERK3(a,b))) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
      and A3: "c >XXREAL-0R4 b"
      and A4: "logPOWERK3(a,c) <=XXREAL-0R1 logPOWERK3(a,b)"
    have A5: "a to-powerPOWERK2 logPOWERK3(a,b) =COMPLEX1R1 b"
      using A1 A2 power_def_3 sorry
    have A6: "a to-powerPOWERK2 logPOWERK3(a,c) =COMPLEX1R1 c"
      using A1 A2 A3 power_def_3 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "logPOWERK3(a,c) <XXREAL-0R3 logPOWERK3(a,b) or logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b)"
          using A4 xxreal_0_th_1 sorry
        have case1: "logPOWERK3(a,c) <XXREAL-0R3 logPOWERK3(a,b) implies  False "
        proof(rule impI)
          assume "logPOWERK3(a,c) <XXREAL-0R3 logPOWERK3(a,b)"
          thus " False "
            using A1 A3 A5 A6 power_th_39 sorry
        qed
        have case2: "logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b) implies  False "
        proof(rule impI)
          assume "logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b)"
          thus " False "
            using A1 A2 A3 A6 power_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_58:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M) & b >XXREAL-0R4 0NUMBERSK6) & c >XXREAL-0R4 b implies logPOWERK3(a,c) <XXREAL-0R3 logPOWERK3(a,b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M) & (b >XXREAL-0R4 0NUMBERSK6 & (c >XXREAL-0R4 b & logPOWERK3(a,c) >=XXREAL-0R2 logPOWERK3(a,b))) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
      and A3: "c >XXREAL-0R4 b"
      and A4: "logPOWERK3(a,c) >=XXREAL-0R2 logPOWERK3(a,b)"
    have A5: "a to-powerPOWERK2 logPOWERK3(a,b) =COMPLEX1R1 b"
      using A1 A2 power_def_3 sorry
    have A6: "a to-powerPOWERK2 logPOWERK3(a,c) =COMPLEX1R1 c"
      using A1 A2 A3 power_def_3 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: "logPOWERK3(a,c) >XXREAL-0R4 logPOWERK3(a,b) or logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b)"
          using A4 xxreal_0_th_1 sorry
        have case1: "logPOWERK3(a,c) >XXREAL-0R4 logPOWERK3(a,b) implies  False "
        proof(rule impI)
          assume "logPOWERK3(a,c) >XXREAL-0R4 logPOWERK3(a,b)"
          thus " False "
            using A1 A3 A5 A6 power_th_40 sorry
        qed
        have case2: "logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b) implies  False "
        proof(rule impI)
          assume "logPOWERK3(a,c) =COMPLEX1R1 logPOWERK3(a,b)"
          thus " False "
            using A1 A2 A3 A6 power_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem power_th_59:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies s be convergentSEQ-2V5"
proof(rule ballI,rule impI)
  fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
  assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
  have " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A2: "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    have A3: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A1 sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M"
      using A1 sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))"
      using xcmplx_1_th_60 sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))"
      using xcmplx_1_th_76 sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 \<one>\<^sub>M)"
       sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      using power_th_27 sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      using power_th_31 sorry
    finally have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A4: "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((\<one>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
      using xcmplx_1_th_113 sorry
    also have "... = ((((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<one>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
      using xcmplx_1_th_113 sorry
    also have "... = (((n +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
      using xcmplx_1_th_84 sorry
    also have "... = (((((n *XCMPLX-0K3 n +XCMPLX-0K2 n *XCMPLX-0K3 \<two>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+NAT-1K1 \<three>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
       sorry
    also have "... = ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
       sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
      using xcmplx_1_th_6 xcmplx_1_th_60 sorry
    finally have "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
       sorry
    have "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    then have "(n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
      using xreal_1_th_161 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)) <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_212 sorry
    then have "-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)) >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      using xreal_1_th_24 sorry
    then have "(\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))"
      using prepower_th_16 sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
       sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 (((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
      using xcmplx_1_th_83 sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))to-powerPOWERK2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
      using xcmplx_1_th_60 sorry
    then have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))"
      using A3 A4 xreal_1_th_64 sorry
    then have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 ((\<one>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))"
      using xcmplx_1_th_113 sorry
    then have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((\<one>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))"
      using xcmplx_1_th_127 sorry
    then have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
      using xcmplx_1_th_76 sorry
    then have A5: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
      using xcmplx_1_th_6 xcmplx_1_th_60 sorry
    have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 sorry
    thus "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A5 xreal_1_th_191 sorry
  qed "sorry"
  then have A6: "s be non-decreasingSEQM-3V8"
    using seqm_3_def_8 sorry
  have " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A7: "\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_129 sorry
    have A8: "\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
       sorry
    have A9: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 ((\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      using A1 sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 \<two>\<^sub>M"
      using power_th_33 sorry
    finally have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 \<two>\<^sub>M"
       sorry
    have "\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using A7 xreal_1_th_6 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_212 sorry
    then have A10: "-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      using xreal_1_th_24 sorry
    then have A11: "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    have A12: "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))))to-powerPOWERK2 (-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M))"
      using power_th_32 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((\<one>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))))to-powerPOWERK2 (-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M))"
      using A8 xcmplx_1_th_113 sorry
    also have "... = (((\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M))"
      using xcmplx_1_th_77 sorry
    also have "... = ((\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M))"
      using xcmplx_1_th_60 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
      using A11 power_th_28 sorry
    finally have "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have "(\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))"
      using A10 prepower_th_16 sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
       sorry
    then have A13: "(\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (\<one>\<^sub>M *NAT-1K2 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
      using xcmplx_1_th_127 sorry
    have "(\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 n)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies  False "
    proof(rule impI)
      assume "(\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 n)/XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
      then have "(\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 n)*XCMPLX-0K3 \<two>\<^sub>M <XXREAL-0R3 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<one>\<^sub>M"
        using xreal_1_th_102 sorry
      then have "\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((-XCMPLX-0K4 n)+XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 n)) <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
         sorry
      thus " False "
        using xreal_1_th_6 sorry
    qed
    then have "(\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
      using A13 xxreal_0_th_2 sorry
    then have A14: "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using A12 xreal_1_th_85 sorry
    have "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    then have "((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M))^2SQUARE-1K1 <=XXREAL-0R1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using A14 xreal_1_th_66 sorry
    then have A15: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using A9 power_th_46 sorry
    have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
      using A6 seqm_3_th_5 sorry
    then have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using A15 xxreal_0_th_2 sorry
    thus "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using xxreal_0_th_2 sorry
  qed "sorry"
  then have "s be bounded-aboveSEQ-2V3"
    using seq_2_def_3 sorry
  thus "s be convergentSEQ-2V5"
    using A6 sorry
qed "sorry"

mdef power_def_4 ("number-ePOWERK4" 164 ) where
"func number-ePOWERK4 \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it =COMPLEX1R1 limSEQ-2K1 s"
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it =COMPLEX1R1 limSEQ-2K1 s"
    proof-
      have " ex tVar7 be RealXREAL-0M1 st  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies tVar7 =COMPLEX1R1 limSEQ-2K1 s"
      proof-
        let ?F = "\<lambda>Lamb1. (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A1: " for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
          using seq_1_sch_1 sorry
        show " ex tVar7 be RealXREAL-0M1 st  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies tVar7 =COMPLEX1R1 limSEQ-2K1 s"
        proof(rule bexI[of _ "limSEQ-2K1 s1"],rule ballI,rule impI)
          fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
          assume A2: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
              using A1 sorry
            also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using A2 sorry
            finally show "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
          qed "sorry"
          thus "limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s"
            using funct_2_th_63 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it1 =COMPLEX1R1 limSEQ-2K1 s) & ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies it2 =COMPLEX1R1 limSEQ-2K1 s) implies it1 =HIDDENR1 it2"
    proof-
      have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies a =COMPLEX1R1 limSEQ-2K1 s) & ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies b =COMPLEX1R1 limSEQ-2K1 s) implies a =HIDDENR1 b"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        assume A3: " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies a =COMPLEX1R1 limSEQ-2K1 s"
          and A4: " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)) implies b =COMPLEX1R1 limSEQ-2K1 s"
        let ?F = "\<lambda>Lamb1. (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M))to-powerPOWERK2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A5: " for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
          using seq_1_sch_1 sorry
        have A6: " for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
          using A5 sorry
        have "limSEQ-2K1 s1 =COMPLEX1R1 a"
          using A3 A6 sorry
        thus "a =HIDDENR1 b"
          using A4 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem power_th_60:
"\<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M =COMPLEX1R1 \<four>\<^sub>M"
proof-
  have "\<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 \<four>\<^sub>M"
  proof-
    have "\<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M ^2SQUARE-1K1"
      using power_th_46 sorry
    also have "... = \<four>\<^sub>M"
       sorry
    finally show "\<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 \<four>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem power_th_61:
"\<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M =COMPLEX1R1 \<eight>\<^sub>M"
proof-
  have "\<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M =HIDDENR1 \<eight>\<^sub>M"
  proof-
    have "\<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = \<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M to-powerPOWERK2 \<one>\<^sub>M"
      using power_th_27 sorry
    also have "... = \<four>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using power_th_60 sorry
    also have "... = \<eight>\<^sub>M"
       sorry
    finally show "\<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M =HIDDENR1 \<eight>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem power_th_62:
"\<two>\<^sub>M to-powerPOWERK2 \<four>\<^sub>M =COMPLEX1R1 \<one>\<six>\<^sub>M"
proof-
  have "\<two>\<^sub>M to-powerPOWERK2 \<four>\<^sub>M =HIDDENR1 \<one>\<six>\<^sub>M"
  proof-
    have "\<two>\<^sub>M to-powerPOWERK2 \<four>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M)"
       sorry
    also have "... = \<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M"
      using power_th_27 sorry
    also have "... = \<one>\<six>\<^sub>M"
      using power_th_60 sorry
    finally show "\<two>\<^sub>M to-powerPOWERK2 \<four>\<^sub>M =HIDDENR1 \<one>\<six>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem power_th_63:
"\<two>\<^sub>M to-powerPOWERK2 \<five>\<^sub>M =COMPLEX1R1 \<three>\<two>\<^sub>M"
proof-
  have "\<two>\<^sub>M to-powerPOWERK2 \<five>\<^sub>M =HIDDENR1 \<three>\<two>\<^sub>M"
  proof-
    have "\<two>\<^sub>M to-powerPOWERK2 \<five>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 (\<three>\<^sub>M +NAT-1K1 \<two>\<^sub>M)"
       sorry
    also have "... = \<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M"
      using power_th_27 sorry
    also have "... = \<three>\<two>\<^sub>M"
      using power_th_60 power_th_61 sorry
    finally show "\<two>\<^sub>M to-powerPOWERK2 \<five>\<^sub>M =HIDDENR1 \<three>\<two>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem power_th_64:
"\<two>\<^sub>M to-powerPOWERK2 \<six>\<^sub>M =COMPLEX1R1 \<six>\<four>\<^sub>M"
proof-
  have "\<two>\<^sub>M to-powerPOWERK2 \<six>\<^sub>M =HIDDENR1 \<six>\<four>\<^sub>M"
  proof-
    have "\<two>\<^sub>M to-powerPOWERK2 \<six>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 (\<three>\<^sub>M +NAT-1K1 \<three>\<^sub>M)"
       sorry
    also have "... = \<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M"
      using power_th_27 sorry
    also have "... = \<six>\<four>\<^sub>M"
      using power_th_61 sorry
    finally show "\<two>\<^sub>M to-powerPOWERK2 \<six>\<^sub>M =HIDDENR1 \<six>\<four>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

end
