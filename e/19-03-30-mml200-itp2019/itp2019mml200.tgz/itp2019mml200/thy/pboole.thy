theory pboole
  imports funct_4 classes1
begin
(*begin*)
reserve i, j, e, u for "objectHIDDENM1"
mtheorem pboole_th_1:
" for f be FunctionFUNCT-1M1 holds f be non-emptyFUNCT-1V4 implies rngFUNCT-1K2 f be with-non-empty-elementsSETFAM-1V1"
   sorry

mtheorem pboole_th_2:
" for f be FunctionFUNCT-1M1 holds f be empty-yieldingFUNCT-1V3 iff f =FUNCT-1R1 {}XBOOLE-0K1 or rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be empty-yieldingFUNCT-1V3 & f <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }) & (f =FUNCT-1R1 {}XBOOLE-0K1 or rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } implies ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be emptyXBOOLE-0V1))"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be empty-yieldingFUNCT-1V3 & f <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    proof(rule impMI ,rule impI)
      assume A1: "f be empty-yieldingFUNCT-1V3"
        and A2: "f <>HIDDENR2 {}XBOOLE-0K1"
      show "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      proof-
        have "( for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 f implies i inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }) & {TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 rngFUNCT-1K2 f"
        proof(rule conjMI)
          show " for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 f implies i inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
            using A1 sorry
          let ?e = "the ElementSUBSET-1M1-of domRELAT-1K1 f"
          have " for i be objectHIDDENM1 holds i inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies i inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
            then have A3: "i =HIDDENR1 {}XBOOLE-0K1"
              using tarski_def_1 sorry
            have A4: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
              using A2 sorry
            have "f .FUNCT-1K1 ?e be emptyXBOOLE-0V1"
              using A1 sorry
            thus "i inHIDDENR3 rngFUNCT-1K2 f"
              using A4 A3 funct_1_def_3 sorry
          qed "sorry"
          thus "{TARSKIK1 {}XBOOLE-0K1 } c=TARSKIR1 rngFUNCT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_3 xboole_0_def_10 sorry
      qed
    qed
    assume A5: "f =FUNCT-1R1 {}XBOOLE-0K1 or rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
    show " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof-
      have cases: "f =FUNCT-1R1 {}XBOOLE-0K1 or rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        using A5 sorry
      have case1: "f =FUNCT-1R1 {}XBOOLE-0K1 implies f be empty-yieldingFUNCT-1V3"
      proof(rule impI)
        assume Cut67: "f =FUNCT-1R1 {}XBOOLE-0K1"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be emptyXBOOLE-0V1"
        proof-
          show " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be emptyXBOOLE-0V1"
            using Cut67 sorry
        qed
        thus "f be empty-yieldingFUNCT-1V3"
          using funct_1_def_8 sorry
      qed
      have case2: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 } implies f be empty-yieldingFUNCT-1V3"
      proof(rule impI)
        assume A6: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be emptyXBOOLE-0V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
          thus "f .FUNCT-1K1 i be emptyXBOOLE-0V1"
            using A6 tarski_def_1 sorry
        qed "sorry"
        thus "f be empty-yieldingFUNCT-1V3"
          using funct_1_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve I for "setHIDDENM2"
mtheorem pboole_cl_1:
  mlet "I be setHIDDENM2"
"cluster totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 st it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
  proof-
    have " ex tVar1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 st tVar1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
    proof-
      show " ex tVar1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 st tVar1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
      proof(rule bexI[of _ "I -->FUNCOP-1K7 {}XBOOLE-0K1"])
        show "I -->FUNCOP-1K7 {}XBOOLE-0K1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax PBOOLEM1 :: " Set \<Rightarrow> Ty" ("ManySortedSetPBOOLEM1-of  _ " [70]70)
translations "ManySortedSetPBOOLEM1-of I" \<rightharpoonup> "totalPARTFUN1V1\<^bsub>(I)\<^esub>\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"

reserve x, X, Y, Z, V for "ManySortedSetPBOOLEM1-of I"
theorem pboole_sch_1:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: " for e be objectHIDDENM1 holds e inHIDDENR3 Af0 implies Ff1(e) <>HIDDENR2 {}XBOOLE-0K1"
  shows " ex f be ManySortedSetPBOOLEM1-of Af0 st  for e be objectHIDDENM1 holds e inHIDDENR3 Af0 implies f .FUNCT-1K1 e inTARSKIR2 Ff1(e)"
  proof-
    have " ex tVar3 be ManySortedSetPBOOLEM1-of Af0 st  for e be objectHIDDENM1 holds  not (e inHIDDENR3 Af0 &  not tVar3 .FUNCT-1K1 e inTARSKIR2 Ff1(e))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 Ff1(Lamb1)"
      have A2: " for e be objectHIDDENM1 holds e inHIDDENR3 Af0 implies ( ex fe be objectHIDDENM1 st fe inHIDDENR3 Ff1(e))"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        let ?fe = "the ElementSUBSET-1M1-of Ff1(e)"
        assume A3: "e inHIDDENR3 Af0"
        obtain fe where 
          [ty]:"fe be objectHIDDENM1" and feDef:"fe = ?fe"
           sorry
        show " ex fe be objectHIDDENM1 st fe inHIDDENR3 Ff1(e)"
        proof(rule bexI[of _ "fe"])
          have "Ff1(e) <>HIDDENR2 {}XBOOLE-0K1"
            using A1 A3 sorry
          thus "fe inHIDDENR3 Ff1(e)"
             sorry
        qed "sorry"
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A4: "domRELAT-1K1 f =XBOOLE-0R4 Af0"and A5: " for e be objectHIDDENM1 holds e inHIDDENR3 Af0 implies ?P(e,f .FUNCT-1K1 e)"
        using classes1_sch_1 A2 sorry
      have 
        [ty]:"f be ManySortedSetPBOOLEM1-of Af0"
        using A4 partfun1_def_2 relat_1_def_18 sorry
      show " ex tVar3 be ManySortedSetPBOOLEM1-of Af0 st  for e be objectHIDDENM1 holds  not (e inHIDDENR3 Af0 &  not tVar3 .FUNCT-1K1 e inTARSKIR2 Ff1(e))"
      proof(rule bexI[of _ "f"])
        show " for e be objectHIDDENM1 holds  not (e inHIDDENR3 Af0 &  not f .FUNCT-1K1 e inTARSKIR2 Ff1(e))"
          using A5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef pboole_def_1 (" _ inPBOOLER1\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"pred X inPBOOLER1\<^bsub>(I)\<^esub> Y means
   for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"..

mdef pboole_def_2 (" _ c=PBOOLER2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"pred X c=PBOOLER2\<^bsub>(I)\<^esub> Y means
   for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"..

mtheorem PBOOLER2_reflexivity:
  mlet "I be setHIDDENM2"
" for Y be ManySortedSetPBOOLEM1-of I holds Y c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for Y be ManySortedSetPBOOLEM1-of I holds  for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
     sorry
  thus " ?thesis "
    using pboole_def_2 sorry
qed

abbreviation(input) PBOOLER3(" _ inPBOOLER3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "X inPBOOLER3\<^bsub>(I)\<^esub> Y \<equiv> X inPBOOLER1\<^bsub>(I)\<^esub> Y"

mtheorem PBOOLER3_asymmetry:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
" for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X inPBOOLER3\<^bsub>(I)\<^esub> Y implies  not Y inPBOOLER3\<^bsub>(I)\<^esub> X"
proof-
  have " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  not (X inPBOOLER3\<^bsub>(I)\<^esub> Y & Y inPBOOLER3\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i) implies  not Y inPBOOLER3\<^bsub>(I)\<^esub> X"
    proof(rule impI)
      assume A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
      have " not ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i)"
      proof-
        have "( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i) implies  not  True "
        proof(rule impI)
          assume A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          obtain i where
            [ty]:"i be objectHIDDENM1" and 
            A3: "i inHIDDENR3 I"
            using xboole_0_def_1 sorry
          have "X .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
            using A1 A3 sorry
          thus " not  True "
            using A2 A3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not Y inPBOOLER3\<^bsub>(I)\<^esub> X"
         sorry
    qed
    thus " not (X inPBOOLER3\<^bsub>(I)\<^esub> Y & Y inPBOOLER3\<^bsub>(I)\<^esub> X)"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem pboole_sch_2:
  fixes If0 Af0 Pp2 
  assumes
[ty]: "If0 be setHIDDENM2" and
  [ty]: "Af0 be ManySortedSetPBOOLEM1-of If0"
  shows " ex X be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( for e be objectHIDDENM1 holds e inHIDDENR3 X .FUNCT-1K1 i iff e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e))"
  proof-
    have " ex tVar4 be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 tVar4 .FUNCT-1K1 i &  not (e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e))) &  not ((e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e)) &  not e inHIDDENR3 tVar4 .FUNCT-1K1 i))"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st A =HIDDENR1 Lamb2 & ( for e be objectHIDDENM1 holds e inHIDDENR3 A iff e inHIDDENR3 Af0 .FUNCT-1K1 Lamb1 & Pp2(Lamb1,e))"
      have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( ex u be objectHIDDENM1 st  ex A be setHIDDENM2 st A =HIDDENR1 u & ( for e be objectHIDDENM1 holds e inHIDDENR3 A iff e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e)))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 If0"
        let ?Q = "\<lambda>Lamb1. Pp2(i,Lamb1)"
        have " ex u be setHIDDENM2 st  for e be objectHIDDENM1 holds e inHIDDENR3 u iff e inHIDDENR3 Af0 .FUNCT-1K1 i & ?Q(e)"
          using xboole_0_sch_1 sorry
        thus " ex u be objectHIDDENM1 st  ex A be setHIDDENM2 st A =HIDDENR1 u & ( for e be objectHIDDENM1 holds e inHIDDENR3 A iff e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e))"
           sorry
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "domRELAT-1K1 f =XBOOLE-0R4 If0"and A3: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ?R(i,f .FUNCT-1K1 i)"
        using classes1_sch_1 A1 sorry
      have 
        [ty]:"f be ManySortedSetPBOOLEM1-of If0"
        using A2 partfun1_def_2 relat_1_def_18 sorry
      show " ex tVar4 be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( for e be objectHIDDENM1 holds  not (e inHIDDENR3 tVar4 .FUNCT-1K1 i &  not (e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e))) &  not ((e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e)) &  not e inHIDDENR3 tVar4 .FUNCT-1K1 i))"
      proof(rule bexI[of _ "f"],rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 If0"
        then have "?R(i,f .FUNCT-1K1 i)"
          using A3 sorry
        thus " for e be objectHIDDENM1 holds  not (e inHIDDENR3 f .FUNCT-1K1 i &  not (e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e))) &  not ((e inHIDDENR3 Af0 .FUNCT-1K1 i & Pp2(i,e)) &  not e inHIDDENR3 f .FUNCT-1K1 i)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem pboole_th_3:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i) implies X =FUNCT-1R1 Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  not (( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i)) &  not X =FUNCT-1R1 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "domRELAT-1K1 X =XBOOLE-0R4 I & domRELAT-1K1 Y =XBOOLE-0R4 I"
      using partfun1_def_2 sorry
    thus " not (( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i)) &  not X =FUNCT-1R1 Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef pboole_def_3 ("EmptyMSPBOOLEK1  _ " [350]350 ) where
  mlet "I be setHIDDENM2"
"func EmptyMSPBOOLEK1 I \<rightarrow> ManySortedSetPBOOLEM1-of I equals
  I -->FUNCOP-1K7 {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "I -->FUNCOP-1K7 {}XBOOLE-0K1 be ManySortedSetPBOOLEM1-of I"
       sorry
qed "sorry"

mdef pboole_def_4 (" _ '('\\'/')PBOOLEK2\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"func X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
    proof-
      have " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i)))"
      proof-
        let ?F = "\<lambda>Lamb1. X .FUNCT-1K1 Lamb1 \\/XBOOLE-0K2 Y .FUNCT-1K1 Lamb1"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A1: "domRELAT-1K1 f =XBOOLE-0R4 I"and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i =XBOOLE-0R4 ?F(i)"
          using funct_1_sch_3 sorry
        have "f be ManySortedSetPBOOLEM1-of I"
          using A1 partfun1_def_2 relat_1_def_18 sorry
        thus " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i)))"
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be ManySortedSetPBOOLEM1-of I holds  for A2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies A2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be ManySortedSetPBOOLEM1-of I"
        fix A2 assume [ty]: "A2 be ManySortedSetPBOOLEM1-of I"
        assume A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
          and A4: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =HIDDENR1 A2 .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A5: "i inHIDDENR3 I"
          then have "A1 .FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
            using A3 sorry
          also have "... = A2 .FUNCT-1K1 i"
            using A4 A5 sorry
          finally show "A1 .FUNCT-1K1 i =HIDDENR1 A2 .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using pboole_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem PBOOLEK2_commutativity:
  mlet "I be setHIDDENM2"
" for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X"
proof-
  have " for it be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds it =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y implies it =HIDDENR1 Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X"
  proof-
    have " for it be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i) implies ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i)"
       sorry
    thus " ?thesis "
      using pboole_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem PBOOLEK2_idempotence:
  mlet "I be setHIDDENM2"
" for Y be ManySortedSetPBOOLEM1-of I holds Y =HIDDENR1 Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
proof-
  have " for Y be ManySortedSetPBOOLEM1-of I holds  for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
     sorry
  thus " ?thesis "
    using pboole_def_4 sorry
qed

mdef pboole_def_5 (" _ '('/'\\')PBOOLEK3\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"func X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
    proof-
      have " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i)))"
      proof-
        let ?F = "\<lambda>Lamb1. X .FUNCT-1K1 Lamb1 /\\XBOOLE-0K3 Y .FUNCT-1K1 Lamb1"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A6: "domRELAT-1K1 f =XBOOLE-0R4 I"and A7: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i =XBOOLE-0R4 ?F(i)"
          using funct_1_sch_3 sorry
        have "f be ManySortedSetPBOOLEM1-of I"
          using A6 partfun1_def_2 relat_1_def_18 sorry
        thus " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i)))"
          using A7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be ManySortedSetPBOOLEM1-of I holds  for A2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies A2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be ManySortedSetPBOOLEM1-of I"
        fix A2 assume [ty]: "A2 be ManySortedSetPBOOLEM1-of I"
        assume A8: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
          and A9: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =HIDDENR1 A2 .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A10: "i inHIDDENR3 I"
          then have "A1 .FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
            using A8 sorry
          also have "... = A2 .FUNCT-1K1 i"
            using A9 A10 sorry
          finally show "A1 .FUNCT-1K1 i =HIDDENR1 A2 .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using pboole_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem PBOOLEK3_commutativity:
  mlet "I be setHIDDENM2"
" for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X"
proof-
  have " for it be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds it =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y implies it =HIDDENR1 Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X"
  proof-
    have " for it be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i) implies ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i /\\XBOOLE-0K3 X .FUNCT-1K1 i)"
       sorry
    thus " ?thesis "
      using pboole_def_5 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem PBOOLEK3_idempotence:
  mlet "I be setHIDDENM2"
" for Y be ManySortedSetPBOOLEM1-of I holds Y =HIDDENR1 Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for Y be ManySortedSetPBOOLEM1-of I holds  for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
     sorry
  thus " ?thesis "
    using pboole_def_5 sorry
qed

mdef pboole_def_6 (" _ '('\\')PBOOLEK4\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"func X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
    proof-
      have " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)))"
      proof-
        let ?F = "\<lambda>Lamb1. X .FUNCT-1K1 Lamb1 \\SUBSET-1K6 Y .FUNCT-1K1 Lamb1"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A11: "domRELAT-1K1 f =XBOOLE-0R4 I"and A12: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i =XBOOLE-0R4 ?F(i)"
          using funct_1_sch_3 sorry
        have "f be ManySortedSetPBOOLEM1-of I"
          using A11 partfun1_def_2 relat_1_def_18 sorry
        thus " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)))"
          using A12 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be ManySortedSetPBOOLEM1-of I holds  for A2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies A2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be ManySortedSetPBOOLEM1-of I"
        fix A2 assume [ty]: "A2 be ManySortedSetPBOOLEM1-of I"
        assume A13: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
          and A14: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A2 .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A1 .FUNCT-1K1 i =HIDDENR1 A2 .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A15: "i inHIDDENR3 I"
          then have "A1 .FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
            using A13 sorry
          also have "... = A2 .FUNCT-1K1 i"
            using A14 A15 sorry
          finally show "A1 .FUNCT-1K1 i =HIDDENR1 A2 .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using pboole_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef pboole_def_7 (" _ overlapsPBOOLER4\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"pred X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y means
   for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i meetsXBOOLE-0R5 Y .FUNCT-1K1 i"..

mtheorem PBOOLER4_symmetry:
  mlet "I be setHIDDENM2"
" for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y implies Y overlapsPBOOLER4\<^bsub>(I)\<^esub> X"
proof-
  have " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i meetsXBOOLE-0R5 Y .FUNCT-1K1 i) implies ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i meetsXBOOLE-0R5 X .FUNCT-1K1 i)"
     sorry
  thus " ?thesis "
    using pboole_def_7 sorry
qed

mdef pboole_def_8 (" _ missesPBOOLER5\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"pred X missesPBOOLER5\<^bsub>(I)\<^esub> Y means
   for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i missesXBOOLE-0R1 Y .FUNCT-1K1 i"..

mtheorem PBOOLER5_symmetry:
  mlet "I be setHIDDENM2"
" for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X missesPBOOLER5\<^bsub>(I)\<^esub> Y implies Y missesPBOOLER5\<^bsub>(I)\<^esub> X"
proof-
  have " for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i missesXBOOLE-0R1 Y .FUNCT-1K1 i) implies ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i missesXBOOLE-0R1 X .FUNCT-1K1 i)"
     sorry
  thus " ?thesis "
    using pboole_def_8 sorry
qed

syntax PBOOLER6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ meetsPBOOLER6\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "X meetsPBOOLER6\<^bsub>(I)\<^esub> Y" \<rightharpoonup> " not X missesPBOOLER5\<^bsub>(I)\<^esub> Y"

mdef pboole_def_9 (" _ '('\\+'\\')PBOOLEK5\<^bsub>'( _ ')\<^esub>  _ " [130,0,130]130 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"func X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y \<rightarrow> ManySortedSetPBOOLEM1-of I equals
  (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
proof-
  (*coherence*)
    show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X) be ManySortedSetPBOOLEM1-of I"
       sorry
qed "sorry"

mtheorem PBOOLEK5_commutativity:
  mlet "I be setHIDDENM2"
" for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y =HIDDENR1 Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X"
proof-
  have " for it be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds it =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y implies it =HIDDENR1 Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X"
  proof-
    have " for it be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds it =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X) implies it =HIDDENR1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)"
       sorry
    thus " ?thesis "
      using pboole_def_9 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_4:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\+\\XBOOLE-0K5 Y .FUNCT-1K1 i"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\+\\XBOOLE-0K5 Y .FUNCT-1K1 i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be objectHIDDENM1"
    assume A1: "i inHIDDENR3 I"
    have "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\/XBOOLE-0K2 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
      using A1 pboole_def_4 sorry
    also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)\\/XBOOLE-0K2 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
      using A1 pboole_def_6 sorry
    also have "... = X .FUNCT-1K1 i \\+\\XBOOLE-0K5 Y .FUNCT-1K1 i"
      using A1 pboole_def_6 sorry
    finally show "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\+\\XBOOLE-0K5 Y .FUNCT-1K1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_5:
" for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix i assume [ty]: "i be objectHIDDENM1"
    show "EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
    proof-
      have cases: "i inHIDDENR3 I or  not i inHIDDENR3 I"
         sorry
      have case1: "i inHIDDENR3 I implies EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
      proof(rule impI)
        assume "i inHIDDENR3 I"
        thus "EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
          using funcop_1_th_7 sorry
      qed
      have case2: " not i inHIDDENR3 I implies EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
      proof(rule impI)
        assume " not i inHIDDENR3 I"
        then have " not i inHIDDENR3 domRELAT-1K1 EmptyMSPBOOLEK1 I"
          using funcop_1_th_13 sorry
        thus "EmptyMSPBOOLEK1 I .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
          using funct_1_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_6:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1) implies X =FUNCT-1R1 EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1) implies X =FUNCT-1R1 EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
        using A1 sorry
      also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
      finally show "X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X =FUNCT-1R1 EmptyMSPBOOLEK1 I"
      using pboole_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_7:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X or x inPBOOLER1\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X or x inPBOOLER1\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X or x inPBOOLER1\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i or x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
        using A1 sorry
      then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
        using xboole_0_def_3 sorry
      thus "x .FUNCT-1K1 i inTARSKIR2 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_8:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y iff x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (x inPBOOLER1\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y) & (x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    show "x inPBOOLER1\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y"
    proof(rule impI,rule conjMI)
      assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      show "x inPBOOLER1\<^bsub>(I)\<^esub> X"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A2: "i inHIDDENR3 I"
          then have "x .FUNCT-1K1 i inTARSKIR2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
            using A1 sorry
          then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
            using A2 pboole_def_5 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
            using xboole_0_def_4 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
          using pboole_def_1 sorry
      qed
      show "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A3: "i inHIDDENR3 I"
          then have "x .FUNCT-1K1 i inTARSKIR2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
            using A1 sorry
          then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
            using A3 pboole_def_5 sorry
          thus "x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
            using xboole_0_def_4 sorry
        qed "sorry"
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
          using pboole_def_1 sorry
      qed
    qed
    assume A4: "x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A5: "i inHIDDENR3 I"
      then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i & x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
        using A4 sorry
      then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
        using xboole_0_def_4 sorry
      thus "x .FUNCT-1K1 i inTARSKIR2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        using A5 pboole_def_5 sorry
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_9:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X & X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X & X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X & X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i & X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A1 sorry
      thus "x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_10:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not X .FUNCT-1K1 i meetsXBOOLE-0R5 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i & x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
        using A1 sorry
      thus " not X .FUNCT-1K1 i meetsXBOOLE-0R5 Y .FUNCT-1K1 i"
        using xboole_0_th_3 sorry
    qed "sorry"
    thus "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
      using pboole_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_11:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y implies ( ex x be ManySortedSetPBOOLEM1-of I st x inPBOOLER1\<^bsub>(I)\<^esub> X & x inPBOOLER1\<^bsub>(I)\<^esub> Y)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y implies ( ex tVar5 be ManySortedSetPBOOLEM1-of I st tVar5 inPBOOLER1\<^bsub>(I)\<^esub> X & tVar5 inPBOOLER1\<^bsub>(I)\<^esub> Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    let ?F = "\<lambda>Lamb1. X .FUNCT-1K1 Lamb1 /\\XBOOLE-0K3 Y .FUNCT-1K1 Lamb1"
    assume A1: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
    have A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?F(i) <>HIDDENR2 {}XBOOLE-0K1"
      using xboole_0_def_7 A1 sorry
    obtain x where
      [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
      A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 ?F(i)"
      using pboole_sch_1 A2 sorry
    show " ex tVar5 be ManySortedSetPBOOLEM1-of I st tVar5 inPBOOLER1\<^bsub>(I)\<^esub> X & tVar5 inPBOOLER1\<^bsub>(I)\<^esub> Y"
    proof(rule bexI[of _ "x"],rule conjMI)
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
          using A3 sorry
        thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using xboole_0_def_4 sorry
      qed "sorry"
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
         sorry
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
          using A3 sorry
        thus "x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
          using xboole_0_def_4 sorry
      qed "sorry"
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_12:
" for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
    show "x inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        then have "x .FUNCT-1K1 i inTARSKIR2 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
          using A1 sorry
        then have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
          using A2 pboole_def_6 sorry
        thus "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
           sorry
      qed "sorry"
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        using pboole_def_1 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mlemma pboole_lm_1:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> X implies X =FUNCT-1R1 Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> X implies X =FUNCT-1R1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume "X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
    then have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
       sorry
    thus "X =FUNCT-1R1 Y"
      using pboole_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax PBOOLER7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ =PBOOLER7\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "X =PBOOLER7\<^bsub>(I)\<^esub> Y" \<rightharpoonup> "X =HIDDENR1 Y"

mtheorem pboole_def_10:
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"redefine pred X =PBOOLER7\<^bsub>(I)\<^esub> Y means
   for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
proof
(*compatibility*)
  show "X =PBOOLER7\<^bsub>(I)\<^esub> Y iff ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i)"
    using pboole_th_3 sorry
qed "sorry"

mtheorem pboole_th_13:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      and A2: "Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      have " for e be objectHIDDENM1 holds e inHIDDENR3 X .FUNCT-1K1 i implies e inHIDDENR3 Z .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume A4: "e inHIDDENR3 X .FUNCT-1K1 i"
        have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
          using A1 A3 sorry
        then have A5: "e inHIDDENR3 Y .FUNCT-1K1 i"
          using A4 sorry
        have "Y .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
          using A2 A3 sorry
        thus "e inHIDDENR3 Z .FUNCT-1K1 i"
          using A5 sorry
      qed "sorry"
      thus "X .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
        using tarski_def_3 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_14:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have " for e be objectHIDDENM1 holds e inHIDDENR3 X .FUNCT-1K1 i implies e inHIDDENR3 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 X .FUNCT-1K1 i"
        then have "e inHIDDENR3 X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i"
          using xboole_0_def_3 sorry
        thus "e inHIDDENR3 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
          using A1 pboole_def_4 sorry
      qed "sorry"
      thus "X .FUNCT-1K1 i c=TARSKIR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        using tarski_def_3 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_15:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have " for e be objectHIDDENM1 holds e inHIDDENR3 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i implies e inHIDDENR3 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        then have "e inHIDDENR3 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
          using A1 pboole_def_5 sorry
        thus "e inHIDDENR3 X .FUNCT-1K1 i"
          using xboole_0_def_4 sorry
      qed "sorry"
      thus "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
        using tarski_def_3 sorry
    qed "sorry"
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_16:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Z & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Z & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Z & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i & Y .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
        using A1 sorry
      then have "X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
        using xboole_1_th_8 sorry
      thus "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
    qed "sorry"
    thus "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_17:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Z c=PBOOLER2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Z c=PBOOLER2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "Z c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Z .FUNCT-1K1 i c=TARSKIR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "Z .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i & Z .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A1 sorry
      then have "Z .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
        using xboole_1_th_19 sorry
      thus "Z .FUNCT-1K1 i c=TARSKIR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
    qed "sorry"
    thus "Z c=PBOOLER2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_18:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have A2: "Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using pboole_th_14 sorry
    have "Y c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using pboole_th_14 sorry
    then have "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_13 sorry
    thus "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using A2 pboole_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_19:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have A2: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using pboole_th_15 sorry
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_15 sorry
    then have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_13 sorry
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using A2 pboole_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_20:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix V assume [ty]: "V be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      and A2: "Z c=PBOOLER2\<^bsub>(I)\<^esub> V"
    have "V c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V"
      using pboole_th_14 sorry
    then have A3: "Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V"
      using A2 pboole_th_13 sorry
    have "Y c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V"
      using pboole_th_14 sorry
    then have "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V"
      using A1 pboole_th_13 sorry
    thus "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V"
      using A3 pboole_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_21:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix V assume [ty]: "V be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      and A2: "Z c=PBOOLER2\<^bsub>(I)\<^esub> V"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using pboole_th_15 sorry
    then have A3: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> V"
      using A2 pboole_th_13 sorry
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_15 sorry
    then have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_13 sorry
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
      using A3 pboole_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_22:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    then have A1: "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_th_16 sorry
    have "Y c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_14 sorry
    thus "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Y"
      using A1 pboole_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_23:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have A2: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_15 sorry
    have "X c=PBOOLER2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_17 sorry
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
      using A2 pboole_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_24:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X & X c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using pboole_th_14 pboole_th_15 sorry
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using pboole_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_25:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "X .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
        using A1 sorry
      have "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\/XBOOLE-0K2 (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
      also have "... = X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      also have "... = (X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i)/\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using A3 xboole_1_th_30 sorry
      also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using A2 pboole_def_4 sorry
      also have "... = ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      finally show "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_26:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z iff (Y c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> X) & ( for V be ManySortedSetPBOOLEM1-of I holds Y c=PBOOLER2\<^bsub>(I)\<^esub> V & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X c=PBOOLER2\<^bsub>(I)\<^esub> V)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X =PBOOLER7\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z implies (Y c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> X) & ( for V be ManySortedSetPBOOLEM1-of I holds Y c=PBOOLER2\<^bsub>(I)\<^esub> V & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X c=PBOOLER2\<^bsub>(I)\<^esub> V)) & ((Y c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> X) & ( for V be ManySortedSetPBOOLEM1-of I holds Y c=PBOOLER2\<^bsub>(I)\<^esub> V & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X c=PBOOLER2\<^bsub>(I)\<^esub> V) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    show "X =PBOOLER7\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z implies (Y c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> X) & ( for V be ManySortedSetPBOOLEM1-of I holds Y c=PBOOLER2\<^bsub>(I)\<^esub> V & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X c=PBOOLER2\<^bsub>(I)\<^esub> V)"
      using pboole_th_14 pboole_th_16 sorry
    assume A1: "Y c=PBOOLER2\<^bsub>(I)\<^esub> X & Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
      and A2: " for V be ManySortedSetPBOOLEM1-of I holds Y c=PBOOLER2\<^bsub>(I)\<^esub> V & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X c=PBOOLER2\<^bsub>(I)\<^esub> V"
    have "Y c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z & Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using pboole_th_14 sorry
    then have A3: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using A2 sorry
    have "Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using A1 pboole_th_16 sorry
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using A3 pboole_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_27:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z iff (X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z) & ( for V be ManySortedSetPBOOLEM1-of I holds V c=PBOOLER2\<^bsub>(I)\<^esub> Y & V c=PBOOLER2\<^bsub>(I)\<^esub> Z implies V c=PBOOLER2\<^bsub>(I)\<^esub> X)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z implies (X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z) & ( for V be ManySortedSetPBOOLEM1-of I holds V c=PBOOLER2\<^bsub>(I)\<^esub> Y & V c=PBOOLER2\<^bsub>(I)\<^esub> Z implies V c=PBOOLER2\<^bsub>(I)\<^esub> X)) & ((X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z) & ( for V be ManySortedSetPBOOLEM1-of I holds V c=PBOOLER2\<^bsub>(I)\<^esub> Y & V c=PBOOLER2\<^bsub>(I)\<^esub> Z implies V c=PBOOLER2\<^bsub>(I)\<^esub> X) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    show "X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z implies (X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z) & ( for V be ManySortedSetPBOOLEM1-of I holds V c=PBOOLER2\<^bsub>(I)\<^esub> Y & V c=PBOOLER2\<^bsub>(I)\<^esub> Z implies V c=PBOOLER2\<^bsub>(I)\<^esub> X)"
      using pboole_th_15 pboole_th_17 sorry
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      and A2: " for V be ManySortedSetPBOOLEM1-of I holds V c=PBOOLER2\<^bsub>(I)\<^esub> Y & V c=PBOOLER2\<^bsub>(I)\<^esub> Z implies V c=PBOOLER2\<^bsub>(I)\<^esub> X"
    have A3: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_17 sorry
    have "Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Z implies Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using A2 sorry
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using A3 pboole_lm_1 pboole_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_28:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\/XBOOLE-0K2 Z .FUNCT-1K1 i"
        using pboole_def_4 sorry
      also have "... = (X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i)\\/XBOOLE-0K2 Z .FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = X .FUNCT-1K1 i \\/XBOOLE-0K2 (Y .FUNCT-1K1 i \\/XBOOLE-0K2 Z .FUNCT-1K1 i)"
        using xboole_1_th_4 sorry
      also have "... = X .FUNCT-1K1 i \\/XBOOLE-0K2 (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_29:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using pboole_def_5 sorry
      also have "... = (X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i)/\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = X .FUNCT-1K1 i /\\XBOOLE-0K3 (Y .FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i)"
        using xboole_1_th_16 sorry
      also have "... = X .FUNCT-1K1 i /\\XBOOLE-0K3 (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      finally show "((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_30:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =PBOOLER7\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_14 sorry
    then have A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
      using pboole_th_17 sorry
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_15 sorry
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =PBOOLER7\<^bsub>(I)\<^esub> X"
      using A1 pboole_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_31:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_15 sorry
    then have A1: "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_16 sorry
    have "X c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_14 sorry
    thus "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
      using A1 pboole_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_32:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i /\\XBOOLE-0K3 (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using pboole_def_5 sorry
      also have "... = X .FUNCT-1K1 i /\\XBOOLE-0K3 (Y .FUNCT-1K1 i \\/XBOOLE-0K2 Z .FUNCT-1K1 i)"
        using A1 pboole_def_4 sorry
      also have "... = X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using xboole_1_th_23 sorry
      also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\/XBOOLE-0K2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\/XBOOLE-0K2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_33:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_31 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_28 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_32 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_30 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_th_32 sorry
    finally show "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_34:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X"
    then have "X =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_th_32 sorry
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using pboole_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_35:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X implies Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X implies Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X"
    then have "X =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_33 sorry
    thus "Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_36:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =HIDDENR1 ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =HIDDENR1 ((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
      using pboole_th_33 sorry
    also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
      using pboole_th_28 sorry
    also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
      using pboole_th_31 sorry
    also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_28 sorry
    also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_31 sorry
    also have "... = ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_33 sorry
    also have "... = ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))"
      using pboole_th_33 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (((Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))"
      using pboole_th_29 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)))"
      using pboole_th_29 sorry
    also have "... = ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
      using pboole_th_29 sorry
    finally show "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =HIDDENR1 ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_37:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  not (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z &  not X c=PBOOLER2\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "X c=PBOOLER2\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_14 sorry
    thus " not (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z &  not X c=PBOOLER2\<^bsub>(I)\<^esub> Z)"
      using pboole_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_38:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  not (X c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z &  not X c=PBOOLER2\<^bsub>(I)\<^esub> Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_th_15 sorry
    thus " not (X c=PBOOLER2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z &  not X c=PBOOLER2\<^bsub>(I)\<^esub> Y)"
      using pboole_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_39:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))"
      using pboole_th_28 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_th_28 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_th_28 sorry
    finally show "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_40:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z))"
      using pboole_th_29 sorry
    also have "... = X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_29 sorry
    also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_29 sorry
    finally show "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_41:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_28 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
       sorry
    finally show "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_42:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y) =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y) =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_29 sorry
    also have "... = X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
       sorry
    finally show "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y) =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem pboole_th_43:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies EmptyMSPBOOLEK1 I .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have " for e be objectHIDDENM1 holds e inHIDDENR3 EmptyMSPBOOLEK1 I .FUNCT-1K1 i implies e inHIDDENR3 X .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        assume "e inHIDDENR3 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        thus "e inHIDDENR3 X .FUNCT-1K1 i"
          using A1 funcop_1_th_7 sorry
      qed "sorry"
      thus "EmptyMSPBOOLEK1 I .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
        using tarski_def_3 sorry
    qed "sorry"
    thus "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_44:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume "X c=PBOOLER2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    then have "X c=PBOOLER2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I & EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_43 sorry
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_45:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z) & Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_17 pboole_th_44 sorry

mtheorem pboole_th_46:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_44 pboole_th_19 sorry

mtheorem pboole_th_47:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> X & EmptyMSPBOOLEK1 I (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X"
  using pboole_th_22 pboole_th_43 sorry

mtheorem pboole_th_48:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_44 pboole_th_14 sorry

mtheorem pboole_th_49:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_23 pboole_th_43 sorry

mtheorem pboole_th_50:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z & X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z & X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      and A2: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X"
      using A1 pboole_th_23 sorry
    then have "Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> X"
      using A2 pboole_th_32 sorry
    then have "Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X"
      using pboole_th_22 pboole_th_43 sorry
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_51:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds Y c=PBOOLER2\<^bsub>(I)\<^esub> X & X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_23 sorry

(*begin*)
mtheorem pboole_th_52:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I iff X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y) & (X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    show "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    proof(rule impI)
      assume A1: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
          using pboole_def_6 sorry
        also have "... = {}XBOOLE-0K1"
          using A1 pboole_th_5 sorry
        finally have "X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
           sorry
        thus "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
          using xboole_1_th_37 sorry
      qed "sorry"
      thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
         sorry
    qed
    assume A2: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have A4: "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A2 sorry
      have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
        using A3 pboole_def_6 sorry
      also have "... = {}XBOOLE-0K1"
        using A4 xboole_1_th_37 sorry
      finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
         sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_53:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i c=TARSKIR1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i & (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i"
        using pboole_def_6 sorry
      have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A1 A2 sorry
      thus "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i c=TARSKIR1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A3 xboole_1_th_33 sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_54:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "(Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =XBOOLE-0R4 Z .FUNCT-1K1 i \\SUBSET-1K6 X .FUNCT-1K1 i & (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 Z .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
        using pboole_def_6 sorry
      have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using A1 A2 sorry
      thus "(Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
        using A3 xboole_1_th_34 sorry
    qed "sorry"
    thus "Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_55:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> V c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> V c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix V assume [ty]: "V be ManySortedSetPBOOLEM1-of I"
    assume "X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V"
    then have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> V c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> V & Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> V c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_th_53 pboole_th_54 sorry
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> V c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_56:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
         sorry
      thus "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i c=TARSKIR1 X .FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_57:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
        using A1 sorry
      then have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i \\SUBSET-1K6 X .FUNCT-1K1 i"
        using A2 pboole_def_6 sorry
      then have "X .FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
        using xboole_1_th_38 sorry
      also have "... = EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_th_5 sorry
      finally show "X .FUNCT-1K1 i =HIDDENR1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_58:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_52 sorry

mtheorem pboole_th_59:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\SUBSET-1K6 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using pboole_def_6 sorry
      also have "... = X .FUNCT-1K1 i \\SUBSET-1K6 {}XBOOLE-0K1"
        using pboole_th_5 sorry
      also have "... = X .FUNCT-1K1 i"
         sorry
      finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> X"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_60:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_43 pboole_th_52 sorry

mtheorem pboole_th_61:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y) =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_14 pboole_th_52 sorry

mtheorem pboole_th_62:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i /\\XBOOLE-0K3 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using pboole_def_5 sorry
      also have "... = X .FUNCT-1K1 i /\\SUBSET-1K9\<^bsub>(Y .FUNCT-1K1 i)\<^esub> (Y .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i)"
        using A1 pboole_def_6 sorry
      also have "... = X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i"
        using xboole_1_th_49 sorry
      also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      finally show "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_63:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 EmptyMSPBOOLEK1 I &  True "
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have A1: "Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_th_15 sorry
    have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_62 sorry
    also have "... = EmptyMSPBOOLEK1 I"
      using A1 pboole_th_52 sorry
    finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 EmptyMSPBOOLEK1 I"
       sorry
    show " True "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_64:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\SUBSET-1K6 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using pboole_def_6 sorry
      also have "... = X .FUNCT-1K1 i \\SUBSET-1K6 (Y .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i)"
        using A1 pboole_def_6 sorry
      also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)\\/XBOOLE-0K2 X .FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using xboole_1_th_52 sorry
      also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)\\/XBOOLE-0K2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\/XBOOLE-0K2 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_65:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)"
      using pboole_th_64 sorry
    also have "... = X (\\)PBOOLEK4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_52 sorry
    also have "... = X"
      using pboole_th_59 sorry
    finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_66:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Y =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have "Y =HIDDENR1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X"
      using pboole_th_65 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using A1 pboole_th_23 sorry
    finally show "Y =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_67:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X) =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X) =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X) =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using pboole_th_31 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X))"
      using pboole_th_28 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_65 sorry
    finally show "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X) =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_68:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y) =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y) =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_64 sorry
    also have "... = EmptyMSPBOOLEK1 I (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_52 sorry
    also have "... = X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_22 pboole_th_43 sorry
    finally show "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y) =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_69:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i \\SUBSET-1K6 (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using pboole_def_6 sorry
      also have "... = X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i /\\XBOOLE-0K3 Z .FUNCT-1K1 i"
        using A1 pboole_def_5 sorry
      also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)\\/SUBSET-1K4\<^bsub>(X .FUNCT-1K1 i)\<^esub> (X .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i)"
        using xboole_1_th_54 sorry
      also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)\\/XBOOLE-0K2 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\/XBOOLE-0K2 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_70:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)"
      using pboole_th_69 sorry
    also have "... = EmptyMSPBOOLEK1 I (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)"
      using pboole_th_52 sorry
    also have "... = X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_22 pboole_th_43 sorry
    finally show "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_71:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I iff X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X) &  not (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X &  not X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    show "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X"
    proof(rule impI)
      assume A1: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
        using pboole_th_70 sorry
      also have "... = X"
        using A1 pboole_th_59 sorry
      finally show "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X"
         sorry
    qed
    show " not (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X &  not X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I)"
      using pboole_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_72:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i"
        using pboole_def_6 sorry
      also have "... = (X .FUNCT-1K1 i \\/XBOOLE-0K2 Y .FUNCT-1K1 i)\\SUBSET-1K6 Z .FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i)\\/XBOOLE-0K2 (Y .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i)"
        using xboole_1_th_42 sorry
      also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i)\\/XBOOLE-0K2 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i \\/XBOOLE-0K2 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      finally show "((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_73:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then have "((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i"
        using pboole_def_6 sorry
      also have "... = (X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i)\\SUBSET-1K7\<^bsub>(X .FUNCT-1K1 i)\<^esub> Z .FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      also have "... = X .FUNCT-1K1 i \\SUBSET-1K6 (Y .FUNCT-1K1 i \\/XBOOLE-0K2 Z .FUNCT-1K1 i)"
        using xboole_1_th_41 sorry
      also have "... = X .FUNCT-1K1 i \\SUBSET-1K6 (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 pboole_def_4 sorry
      also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      finally show "((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_74:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have A1: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_56 sorry
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_62 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)"
      using pboole_th_68 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y))"
      using pboole_th_73 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
      using pboole_th_64 sorry
    also have "... = EmptyMSPBOOLEK1 I (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
      using A1 pboole_th_52 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_th_22 pboole_th_43 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
      using pboole_th_67 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_32 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) (\\/)PBOOLEK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_63 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using pboole_th_22 pboole_th_43 sorry
    finally show "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_75:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)"
      using pboole_th_72 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_52 sorry
    also have "... = X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_22 pboole_th_43 sorry
    finally show "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_76:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z & X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z & X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
    then have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_53 sorry
    then have A2: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_75 sorry
    have "Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using pboole_th_56 sorry
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using A2 pboole_th_13 sorry
    have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_53 sorry
    then have A3: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_th_75 sorry
    have "Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_th_56 sorry
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using A3 pboole_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_77:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)"
      using pboole_th_72 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)"
      using pboole_th_70 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using pboole_th_70 sorry
    finally show "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_78:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
      using pboole_th_73 sorry
    also have "... = X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
       sorry
    finally show "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_79:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_th_73 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_th_56 pboole_th_23 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using pboole_th_62 sorry
    finally show "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z) =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_80:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X implies X =HIDDENR1 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
    then have "X =HIDDENR1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X"
      using pboole_th_65 sorry
    also have "... = Y"
      using pboole_th_65 sorry
    finally show "X =HIDDENR1 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_81:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have A1: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_15 sorry
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using pboole_th_69 sorry
    also have "... = EmptyMSPBOOLEK1 I (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using A1 pboole_th_52 sorry
    also have "... = X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_th_22 pboole_th_43 sorry
    finally have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
       sorry
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_82:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_th_15 sorry
    then have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y) c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_20 sorry
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      using pboole_th_65 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_83:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y"
  using pboole_th_14 sorry

mtheorem pboole_th_84:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =HIDDENR1 X"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    have "X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =HIDDENR1 X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (EmptyMSPBOOLEK1 I (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using pboole_th_59 sorry
    also have "... = X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_60 sorry
    also have "... = X"
      using pboole_th_22 pboole_th_43 sorry
    finally show "X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I =HIDDENR1 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_85:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  using pboole_th_52 sorry

mtheorem pboole_th_86:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_65 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
      using pboole_th_28 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_31 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X)"
      using pboole_th_65 sorry
    also have "... = (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_28 sorry
    finally show "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_87:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using pboole_th_70 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)"
      using pboole_th_70 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_72 sorry
    finally show "X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_88:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =HIDDENR1 ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using pboole_th_72 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)"
      using pboole_th_73 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))"
      using pboole_th_73 sorry
    finally show "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_89:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z) =PBOOLER7\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z) =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z) =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_87 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)"
      using pboole_th_64 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_29 sorry
    finally show "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z) =HIDDENR1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_90:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    let ?S1 = "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
    let ?S2 = "Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)"
    let ?S3 = "Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
    let ?S4 = "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
    have "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z =HIDDENR1 (((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)))"
      using pboole_th_72 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)))"
      using pboole_th_73 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)))"
      using pboole_th_73 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y))"
      using pboole_th_77 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)))"
      using pboole_th_64 sorry
    also have "... = (((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y))"
      using pboole_th_28 sorry
    also have "... = (((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y))"
      using pboole_th_28 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)))"
      using pboole_th_28 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)))"
      using pboole_th_29 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)))"
      using pboole_th_64 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)))"
      using pboole_th_77 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X))"
      using pboole_th_73 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> ((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (((Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Z (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X))"
      using pboole_th_73 sorry
    also have "... = X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z)"
      using pboole_th_72 sorry
    finally show "(X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_91:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z & Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
  using pboole_th_16 sorry

mtheorem pboole_th_92:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)"
       sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X"
      using pboole_th_28 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X"
      using pboole_th_67 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
      using pboole_th_28 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X))"
      using pboole_th_67 sorry
    also have "... = ((X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using pboole_th_28 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using pboole_th_64 sorry
    also have "... = X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
      using pboole_th_78 sorry
    finally show "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_93:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have A1: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_56 sorry
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y)"
      using pboole_th_68 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y))(\\/)PBOOLEK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_22 pboole_th_43 sorry
    also have "... = X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_52 sorry
    finally show "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_94:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have A1: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> X"
      using pboole_th_15 sorry
    have "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_70 sorry
    also have "... = (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)(\\/)PBOOLEK2\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_22 pboole_th_43 sorry
    also have "... = X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_52 sorry
    finally show "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_95:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =PBOOLER7\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X"
      using pboole_th_14 sorry
    have "Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =HIDDENR1 (Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
      using pboole_th_75 sorry
    also have "... = EmptyMSPBOOLEK1 I (\\/)PBOOLEK2\<^bsub>(I)\<^esub> ((Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X)(\\)PBOOLEK4\<^bsub>(I)\<^esub> X)"
      using pboole_th_22 pboole_th_43 sorry
    also have "... = X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_52 sorry
    finally show "Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_96:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
      using pboole_th_92 sorry
    also have "... = X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y)"
      using pboole_th_94 sorry
    also have "... = (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using pboole_th_90 sorry
    finally show "X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_97:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_93 sorry
    also have "... = X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> (Y (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)"
      using pboole_th_95 sorry
    also have "... = (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
      using pboole_th_90 sorry
    finally show "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =HIDDENR1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y)(\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem pboole_th_98:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y or X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y or X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y or X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
    show "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
    proof-
      have cases: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y or X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
        using A1 sorry
      have case1: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      proof(rule impI)
        assume "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
        then obtain x where
          [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
          A2: "x inPBOOLER1\<^bsub>(I)\<^esub> X"and A3: "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
          using pboole_th_11 sorry
        have "x inPBOOLER1\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
          using A3 pboole_th_7 sorry
        thus "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
          using A2 pboole_th_10 sorry
      qed
      have case2: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
      proof(rule impI)
        assume "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
        then obtain x where
          [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
          A4: "x inPBOOLER1\<^bsub>(I)\<^esub> X"and A5: "x inPBOOLER1\<^bsub>(I)\<^esub> Z"
          using pboole_th_11 sorry
        have "x inPBOOLER1\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
          using A5 pboole_th_7 sorry
        thus "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Z"
          using A4 pboole_th_10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_99:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
      and A2: "Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    obtain x where
      [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
      A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"and A4: "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_11 sorry
    have "x inPBOOLER1\<^bsub>(I)\<^esub> Z"
      using A2 A4 pboole_th_9 sorry
    thus "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
      using A3 pboole_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_100:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z implies Z overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z implies Z overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
      and A2: "X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    obtain x where
      [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
      A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"and A4: "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_11 sorry
    have "x inPBOOLER1\<^bsub>(I)\<^esub> Z"
      using A2 A3 pboole_th_9 sorry
    thus "Z overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
      using A4 pboole_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_101:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds (X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V) & X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z implies Y overlapsPBOOLER4\<^bsub>(I)\<^esub> V"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Z c=PBOOLER2\<^bsub>(I)\<^esub> V implies (X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z implies Y overlapsPBOOLER4\<^bsub>(I)\<^esub> V)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix V assume [ty]: "V be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      and A2: "Z c=PBOOLER2\<^bsub>(I)\<^esub> V"
    assume "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
    then have "Y overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_100 sorry
    thus "Y overlapsPBOOLER4\<^bsub>(I)\<^esub> V"
      using A2 pboole_th_99 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_102:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y & X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y & X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
    then obtain x where
      [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
      A1: "x inPBOOLER1\<^bsub>(I)\<^esub> X"and A2: "x inPBOOLER1\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_11 sorry
    have "x inPBOOLER1\<^bsub>(I)\<^esub> Y & x inPBOOLER1\<^bsub>(I)\<^esub> Z"
      using A2 pboole_th_8 sorry
    thus "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y & X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_103:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z & X c=PBOOLER2\<^bsub>(I)\<^esub> V implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z & X c=PBOOLER2\<^bsub>(I)\<^esub> V implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix V assume [ty]: "V be ManySortedSetPBOOLEM1-of I"
    assume A1: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
      and A2: "X c=PBOOLER2\<^bsub>(I)\<^esub> V"
    obtain x where
      [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
      A3: "x inPBOOLER1\<^bsub>(I)\<^esub> X"and A4: "x inPBOOLER1\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_11 sorry
    have "x inPBOOLER1\<^bsub>(I)\<^esub> V"
      using A2 A3 pboole_th_9 sorry
    then have "x inPBOOLER1\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
      using A4 pboole_th_8 sorry
    thus "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Z (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
      using A3 pboole_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_104:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z implies X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
  using pboole_th_56 pboole_th_99 sorry

mtheorem pboole_th_105:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  not Y overlapsPBOOLER4\<^bsub>(I)\<^esub> Z implies  not X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y overlapsPBOOLER4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  not Y overlapsPBOOLER4\<^bsub>(I)\<^esub> Z implies  not X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y overlapsPBOOLER4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: " not Y overlapsPBOOLER4\<^bsub>(I)\<^esub> Z"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Y & X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z c=PBOOLER2\<^bsub>(I)\<^esub> Z"
      using pboole_th_15 sorry
    thus " not X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y overlapsPBOOLER4\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using A1 pboole_th_101 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_106:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z implies Y overlapsPBOOLER4\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z implies Y overlapsPBOOLER4\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not Y .FUNCT-1K1 i meetsXBOOLE-0R5 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i meetsXBOOLE-0R5 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A1 sorry
      then have "X .FUNCT-1K1 i meetsXBOOLE-0R5 Y .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i"
        using A2 pboole_def_6 sorry
      then have "Y .FUNCT-1K1 i meetsXBOOLE-0R5 X .FUNCT-1K1 i \\SUBSET-1K6 Z .FUNCT-1K1 i"
        using xboole_1_th_81 sorry
      thus " not Y .FUNCT-1K1 i meetsXBOOLE-0R5 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z).FUNCT-1K1 i"
        using A2 pboole_def_6 sorry
    qed "sorry"
    thus "Y overlapsPBOOLER4\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Z"
      using pboole_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_107:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X meetsPBOOLER6\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies X meetsPBOOLER6\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X meetsPBOOLER6\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> Z implies  not X meetsPBOOLER6\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X meetsPBOOLER6\<^bsub>(I)\<^esub> Y"
      and A2: "Y c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A3: "i inHIDDENR3 I"and A4: "X .FUNCT-1K1 i meetsXBOOLE-0R5 Y .FUNCT-1K1 i"
      using A1 sorry
    have Cut1463: "Y .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
      using A2 A3 sorry
    have "i inHIDDENR3 I &  not X .FUNCT-1K1 i missesXBOOLE-0R1 Z .FUNCT-1K1 i"
    proof-
      show "i inHIDDENR3 I &  not X .FUNCT-1K1 i missesXBOOLE-0R1 Z .FUNCT-1K1 i"
        using A3 A4 xboole_1_th_63 Cut1463 sorry
    qed
    thus " not X meetsPBOOLER6\<^bsub>(I)\<^esub> Z"
      using bexI[of _ "i"] pboole_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_108:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i missesXBOOLE-0R1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
        using pboole_def_6 sorry
      thus "Y .FUNCT-1K1 i missesXBOOLE-0R1 (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        using xboole_1_th_79 sorry
    qed "sorry"
    thus "Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_109:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y c=PBOOLER2\<^bsub>(I)\<^esub> Y & X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> Y"
      using pboole_th_15 pboole_th_108 sorry
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_107 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_110:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i missesXBOOLE-0R1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i & (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\+\\XBOOLE-0K5 Y .FUNCT-1K1 i"
        using pboole_def_5 pboole_th_4 sorry
      thus "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i missesXBOOLE-0R1 (X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i"
        using xboole_1_th_103 sorry
    qed "sorry"
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> X (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_111:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X missesPBOOLER5\<^bsub>(I)\<^esub> Y implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X missesPBOOLER5\<^bsub>(I)\<^esub> Y implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X missesPBOOLER5\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "X .FUNCT-1K1 i missesXBOOLE-0R1 Y .FUNCT-1K1 i"
        using A1 sorry
      have "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 X .FUNCT-1K1 i /\\XBOOLE-0K3 Y .FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      also have "... = {}XBOOLE-0K1"
        using A3 sorry
      finally show "(X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =HIDDENR1 {}XBOOLE-0K1"
         sorry
    qed "sorry"
    thus "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_112:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X <>HIDDENR2 EmptyMSPBOOLEK1 I implies X meetsPBOOLER6\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  not ( not X <>HIDDENR2 EmptyMSPBOOLEK1 I & X meetsPBOOLER6\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    have "X =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X"
       sorry
    thus " not ( not X <>HIDDENR2 EmptyMSPBOOLEK1 I & X meetsPBOOLER6\<^bsub>(I)\<^esub> X)"
      using pboole_th_111 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_113:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds (X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z) & Y missesPBOOLER5\<^bsub>(I)\<^esub> Z implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z implies (Y missesPBOOLER5\<^bsub>(I)\<^esub> Z implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> Z"
    assume "Y missesPBOOLER5\<^bsub>(I)\<^esub> Z"
    then have "Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_111 sorry
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using A1 pboole_th_17 pboole_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_114:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y & X missesPBOOLER5\<^bsub>(I)\<^esub> Z) & Y missesPBOOLER5\<^bsub>(I)\<^esub> V implies X =PBOOLER7\<^bsub>(I)\<^esub> V & Y =PBOOLER7\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for V be ManySortedSetPBOOLEM1-of I holds Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y implies (X missesPBOOLER5\<^bsub>(I)\<^esub> Z & Y missesPBOOLER5\<^bsub>(I)\<^esub> V implies X =HIDDENR1 V & Y =HIDDENR1 Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix V assume [ty]: "V be ManySortedSetPBOOLEM1-of I"
    assume A1: "Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V =PBOOLER7\<^bsub>(I)\<^esub> X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y"
    assume "X missesPBOOLER5\<^bsub>(I)\<^esub> Z & Y missesPBOOLER5\<^bsub>(I)\<^esub> V"
    then have A2: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I & Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_111 sorry
    have "X =HIDDENR1 X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V)"
      using pboole_th_23 A1 pboole_th_14 sorry
    also have "... = X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
      using pboole_th_32 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
      using A2 pboole_th_32 sorry
    also have "... = V"
      using A1 pboole_th_14 pboole_th_23 sorry
    finally show "X =HIDDENR1 V"
       sorry
    have "Y =HIDDENR1 Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> (Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> V)"
      using pboole_th_23 A1 pboole_th_14 sorry
    also have "... = Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> V"
      using pboole_th_32 sorry
    also have "... = (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using A2 pboole_th_32 sorry
    also have "... = Z"
      using A1 pboole_th_14 pboole_th_23 sorry
    finally show "Y =HIDDENR1 Z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_115:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X missesPBOOLER5\<^bsub>(I)\<^esub> Y implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X missesPBOOLER5\<^bsub>(I)\<^esub> Y implies X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X missesPBOOLER5\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i"
        using pboole_def_6 sorry
      have "X .FUNCT-1K1 i missesXBOOLE-0R1 Y .FUNCT-1K1 i"
        using A1 A2 sorry
      thus "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i"
        using A3 xboole_1_th_83 sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
      using pboole_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_116:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X missesPBOOLER5\<^bsub>(I)\<^esub> Y implies (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  not (X missesPBOOLER5\<^bsub>(I)\<^esub> Y &  not (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X)"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have "(X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y"
      using pboole_th_75 sorry
    thus " not (X missesPBOOLER5\<^bsub>(I)\<^esub> Y &  not (X (\\/)PBOOLEK2\<^bsub>(I)\<^esub> Y)(\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X)"
      using pboole_th_115 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_117:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X implies X missesPBOOLER5\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X implies X missesPBOOLER5\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> X"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i missesXBOOLE-0R1 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i"
        using A1 pboole_def_6 sorry
      thus "X .FUNCT-1K1 i missesXBOOLE-0R1 Y .FUNCT-1K1 i"
        using xboole_1_th_83 sorry
    qed "sorry"
    thus "X missesPBOOLER5\<^bsub>(I)\<^esub> Y"
      using pboole_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_118:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i missesXBOOLE-0R1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 X .FUNCT-1K1 i \\SUBSET-1K6 Y .FUNCT-1K1 i & (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i \\SUBSET-1K6 X .FUNCT-1K1 i"
        using pboole_def_6 sorry
      thus "(X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i missesXBOOLE-0R1 (Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X).FUNCT-1K1 i"
        using xboole_1_th_82 sorry
    qed "sorry"
    thus "X (\\)PBOOLEK4\<^bsub>(I)\<^esub> Y missesPBOOLER5\<^bsub>(I)\<^esub> Y (\\)PBOOLEK4\<^bsub>(I)\<^esub> X"
      using pboole_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef pboole_def_11 (" _ [=PBOOLER8\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"pred X [=PBOOLER8\<^bsub>(I)\<^esub> Y means
   for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> Y"..

mtheorem PBOOLER8_reflexivity:
  mlet "I be setHIDDENM2"
" for Y be ManySortedSetPBOOLEM1-of I holds Y [=PBOOLER8\<^bsub>(I)\<^esub> Y"
proof-
  have " for Y be ManySortedSetPBOOLEM1-of I holds  for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> Y implies x inPBOOLER1\<^bsub>(I)\<^esub> Y"
     sorry
  thus " ?thesis "
    using pboole_def_11 sorry
qed

mtheorem pboole_th_119:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X [=PBOOLER8\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X [=PBOOLER8\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
      assume A2: "x inPBOOLER1\<^bsub>(I)\<^esub> X"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        then have A4: "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
          using A1 sorry
        have "x .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i"
          using A2 A3 sorry
        thus "x .FUNCT-1K1 i inTARSKIR2 Y .FUNCT-1K1 i"
          using A4 sorry
      qed "sorry"
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> Y"
        using pboole_def_1 sorry
    qed "sorry"
    thus "X [=PBOOLER8\<^bsub>(I)\<^esub> Y"
      using pboole_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_120:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X [=PBOOLER8\<^bsub>(I)\<^esub> Y & Y [=PBOOLER8\<^bsub>(I)\<^esub> Z implies X [=PBOOLER8\<^bsub>(I)\<^esub> Z"
   sorry

(*begin*)
mtheorem pboole_th_121:
"EmptyMSPBOOLEK1 ({}XBOOLE-0K1) inPBOOLER1\<^bsub>({}XBOOLE-0K1)\<^esub> EmptyMSPBOOLEK1 ({}XBOOLE-0K1)"
   sorry

mtheorem pboole_th_122:
" for X be ManySortedSetPBOOLEM1-of {}XBOOLE-0K1 holds X =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

reserve I for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve x, X, Y for "ManySortedSetPBOOLEM1-of I"
mtheorem pboole_th_123:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y implies X meetsPBOOLER6\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y implies  not X meetsPBOOLER6\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    let ?i = "the ElementSUBSET-1M1-of I"
    assume "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
    then have "X .FUNCT-1K1 ?i meetsXBOOLE-0R5 Y .FUNCT-1K1 ?i"
       sorry
    thus " not X meetsPBOOLER6\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_124:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not ( ex x be ManySortedSetPBOOLEM1-of I st x inPBOOLER3\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I)"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ( ex x be ManySortedSetPBOOLEM1-of I st x inPBOOLER3\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) implies  False "
  proof(rule ballI,rule impI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?i = "the ElementSUBSET-1M1-of I"
    assume Given: " ex x be ManySortedSetPBOOLEM1-of I st x inPBOOLER3\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    then obtain x where
      [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
      A1: "x inPBOOLER3\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
    have "x .FUNCT-1K1 ?i inTARSKIR2 EmptyMSPBOOLEK1 I .FUNCT-1K1 ?i"
      using A1 sorry
    thus " False "
      using funcop_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_125:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ManySortedSetPBOOLEM1-of I holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds x inPBOOLER3\<^bsub>(I)\<^esub> X & x inPBOOLER3\<^bsub>(I)\<^esub> Y implies X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y <>HIDDENR2 EmptyMSPBOOLEK1 I"
  using pboole_th_8 pboole_th_124 sorry

mtheorem pboole_th_126:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  not X overlapsPBOOLER4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    assume "X overlapsPBOOLER4\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    then have " ex x be ManySortedSetPBOOLEM1-of I st x inPBOOLER3\<^bsub>(I)\<^esub> X & x inPBOOLER3\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
      using pboole_th_11 sorry
    thus " False "
      using pboole_th_124 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_127:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies  not X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies (X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    assume "X overlapsPBOOLER4\<^bsub>(I)\<^esub> Y"
    then obtain x where
      [ty]:"x be ManySortedSetPBOOLEM1-of I" and 
      A2: "x inPBOOLER3\<^bsub>(I)\<^esub> X & x inPBOOLER3\<^bsub>(I)\<^esub> Y"
      using pboole_th_11 sorry
    have "x inPBOOLER3\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Y"
      using A2 pboole_th_8 sorry
    thus " False "
      using A1 pboole_th_124 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_128:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X overlapsPBOOLER4\<^bsub>(I)\<^esub> X implies X <>HIDDENR2 EmptyMSPBOOLEK1 I"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  not (X overlapsPBOOLER4\<^bsub>(I)\<^esub> X & X <>HIDDENR2 EmptyMSPBOOLEK1 I)"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    have "X =PBOOLER7\<^bsub>(I)\<^esub> X (/\\)PBOOLEK3\<^bsub>(I)\<^esub> X"
       sorry
    thus " not (X overlapsPBOOLER4\<^bsub>(I)\<^esub> X & X <>HIDDENR2 EmptyMSPBOOLEK1 I)"
      using pboole_th_127 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve I for "setHIDDENM2"
reserve x, X, Y, Z for "ManySortedSetPBOOLEM1-of I"
syntax PBOOLEV1 :: " Set \<Rightarrow> Ty" ("empty-yieldingPBOOLEV1\<^bsub>'( _ ')\<^esub>" [0]70)
translations "empty-yieldingPBOOLEV1\<^bsub>(I)\<^esub>" \<rightharpoonup> "empty-yieldingRELAT-1V3"

mtheorem pboole_def_12:
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I"
"redefine attr empty-yieldingPBOOLEV1\<^bsub>(I)\<^esub> for ManySortedSetPBOOLEM1-of I means
  (\<lambda>X.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be emptyXBOOLE-0V1)"
proof
(*compatibility*)
  show " for X be ManySortedSetPBOOLEM1-of I holds X be empty-yieldingPBOOLEV1\<^bsub>(I)\<^esub> iff ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be emptyXBOOLE-0V1)"
  proof(rule ballI)
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "X be empty-yieldingPBOOLEV1\<^bsub>(I)\<^esub> iff ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be emptyXBOOLE-0V1)"
    proof-
      have " not (X be empty-yieldingRELAT-1V3 &  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not X .FUNCT-1K1 i be emptyXBOOLE-0V1))) &  not (( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not X .FUNCT-1K1 i be emptyXBOOLE-0V1)) &  not X be empty-yieldingRELAT-1V3)"
      proof-
        have "domRELAT-1K1 X =XBOOLE-0R4 I"
          using partfun1_def_2 sorry
        thus " not (X be empty-yieldingRELAT-1V3 &  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not X .FUNCT-1K1 i be emptyXBOOLE-0V1))) &  not (( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not X .FUNCT-1K1 i be emptyXBOOLE-0V1)) &  not X be empty-yieldingRELAT-1V3)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

syntax PBOOLEV2 :: " Set \<Rightarrow> Ty" ("non-emptyPBOOLEV2\<^bsub>'( _ ')\<^esub>" [0]70)
translations "non-emptyPBOOLEV2\<^bsub>(I)\<^esub>" \<rightharpoonup> "non-emptyRELAT-1V2"

mtheorem pboole_def_13:
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I"
"redefine attr non-emptyPBOOLEV2\<^bsub>(I)\<^esub> for ManySortedSetPBOOLEM1-of I means
  (\<lambda>X.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be  non emptyXBOOLE-0V1)"
proof
(*compatibility*)
  show " for X be ManySortedSetPBOOLEM1-of I holds X be non-emptyPBOOLEV2\<^bsub>(I)\<^esub> iff ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be  non emptyXBOOLE-0V1)"
  proof(rule ballI)
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "X be non-emptyPBOOLEV2\<^bsub>(I)\<^esub> iff ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be  non emptyXBOOLE-0V1)"
    proof-
      have " not (X be non-emptyRELAT-1V2 &  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & X .FUNCT-1K1 i be emptyXBOOLE-0V1))) &  not (( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & X .FUNCT-1K1 i be emptyXBOOLE-0V1)) &  not X be non-emptyRELAT-1V2)"
      proof-
        have "domRELAT-1K1 X =XBOOLE-0R4 I"
          using partfun1_def_2 sorry
        thus " not (X be non-emptyRELAT-1V2 &  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & X .FUNCT-1K1 i be emptyXBOOLE-0V1))) &  not (( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & X .FUNCT-1K1 i be emptyXBOOLE-0V1)) &  not X be non-emptyRELAT-1V2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem pboole_cl_2:
  mlet "I be setHIDDENM2"
"cluster empty-yieldingRELAT-1V3 for ManySortedSetPBOOLEM1-of I"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of I st it be empty-yieldingRELAT-1V3"
  proof-
    have " ex tVar7 be ManySortedSetPBOOLEM1-of I st tVar7 be empty-yieldingRELAT-1V3"
    proof-
      show " ex tVar7 be ManySortedSetPBOOLEM1-of I st tVar7 be empty-yieldingRELAT-1V3"
      proof(rule bexI[of _ "EmptyMSPBOOLEK1 I"])
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies EmptyMSPBOOLEK1 I .FUNCT-1K1 i be emptyXBOOLE-0V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          show "EmptyMSPBOOLEK1 I .FUNCT-1K1 i be emptyXBOOLE-0V1"
            using pboole_th_5 sorry
        qed "sorry"
        thus "EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3"
          using pboole_def_12 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pboole_cl_3:
  mlet "I be setHIDDENM2"
"cluster non-emptyRELAT-1V2 for ManySortedSetPBOOLEM1-of I"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of I st it be non-emptyRELAT-1V2"
  proof-
    have " ex tVar8 be ManySortedSetPBOOLEM1-of I st tVar8 be non-emptyRELAT-1V2"
    proof-
      let ?e = "the setHIDDENM2"
      obtain M where 
        [ty]:"M be ManySortedSetPBOOLEM1-of I" and MDef:"M = I -->FUNCOP-1K7 {TARSKIK1 ?e}"
         sorry
      show " ex tVar8 be ManySortedSetPBOOLEM1-of I st tVar8 be non-emptyRELAT-1V2"
      proof(rule bexI[of _ "M"])
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not M .FUNCT-1K1 i be emptyXBOOLE-0V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          thus " not M .FUNCT-1K1 i be emptyXBOOLE-0V1"
            using funcop_1_th_7 sorry
        qed "sorry"
        thus "M be non-emptyRELAT-1V2"
          using pboole_def_13 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pboole_cl_4:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster non-emptyRELAT-1V2 also-is  non empty-yieldingRELAT-1V3 for ManySortedSetPBOOLEM1-of I"
proof
(*coherence*)
  show " for it be ManySortedSetPBOOLEM1-of I holds it be non-emptyRELAT-1V2 implies it be  non empty-yieldingRELAT-1V3"
  proof-
    have " for M be ManySortedSetPBOOLEM1-of I holds M be non-emptyRELAT-1V2 implies  not M be empty-yieldingRELAT-1V3"
    proof(rule ballI,rule impI)
      let ?i = "the ElementSUBSET-1M1-of I"
      fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
      assume A1: "M be non-emptyRELAT-1V2"
      have "the ElementSUBSET-1M1-of I inTARSKIR2 I &  not M .FUNCT-1K1 (the ElementSUBSET-1M1-of I) be emptyXBOOLE-0V1"
      proof(rule conjMI)
        show "the ElementSUBSET-1M1-of I inTARSKIR2 I"
           sorry
        show " not M .FUNCT-1K1 (the ElementSUBSET-1M1-of I) be emptyXBOOLE-0V1"
          using A1 sorry
      qed
      thus " not M be empty-yieldingRELAT-1V3"
        using bexI[of _ "?i"] pboole_def_12 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pboole_cl_5:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster empty-yieldingRELAT-1V3 also-is  non non-emptyRELAT-1V2 for ManySortedSetPBOOLEM1-of I"
proof
(*coherence*)
  show " for it be ManySortedSetPBOOLEM1-of I holds it be empty-yieldingRELAT-1V3 implies it be  non non-emptyRELAT-1V2"
     sorry
qed "sorry"

mtheorem pboole_th_129:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds X be empty-yieldingRELAT-1V3 iff X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds (X be empty-yieldingRELAT-1V3 implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I) & (X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies X be empty-yieldingRELAT-1V3)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    show "X be empty-yieldingRELAT-1V3 implies X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    proof(rule impI)
      assume "X be empty-yieldingRELAT-1V3"
      then have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      thus "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
        using pboole_th_6 sorry
    qed
    assume A1: "X =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      show "X .FUNCT-1K1 i be emptyXBOOLE-0V1"
        using A1 pboole_th_5 sorry
    qed "sorry"
    thus "X be empty-yieldingRELAT-1V3"
      using pboole_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_130:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds Y be empty-yieldingRELAT-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X be empty-yieldingRELAT-1V3"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds Y be empty-yieldingRELAT-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies X be empty-yieldingRELAT-1V3"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "Y be empty-yieldingRELAT-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i & Y .FUNCT-1K1 i be emptyXBOOLE-0V1"
        using A1 sorry
      thus "X .FUNCT-1K1 i be emptyXBOOLE-0V1"
         sorry
    qed "sorry"
    thus "X be empty-yieldingRELAT-1V3"
      using pboole_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_131:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 & X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Y be non-emptyRELAT-1V2"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 & X c=PBOOLER2\<^bsub>(I)\<^esub> Y implies Y be non-emptyRELAT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X be non-emptyRELAT-1V2 & X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not Y .FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i & X .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
        using A1 sorry
      thus " not Y .FUNCT-1K1 i be emptyXBOOLE-0V1"
         sorry
    qed "sorry"
    thus "Y be non-emptyRELAT-1V2"
      using pboole_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_132:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 & X [=PBOOLER8\<^bsub>(I)\<^esub> Y implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 & X [=PBOOLER8\<^bsub>(I)\<^esub> Y implies X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X be non-emptyRELAT-1V2"
      and A2: "X [=PBOOLER8\<^bsub>(I)\<^esub> Y"
    let ?F = "\<lambda>Lamb1. X .FUNCT-1K1 Lamb1"
    have A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?F(i) <>HIDDENR2 {}XBOOLE-0K1"
      using A1 sorry
    obtain f where
      [ty]:"f be ManySortedSetPBOOLEM1-of I" and 
      A4: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i inTARSKIR2 ?F(i)"
      using pboole_sch_1 A3 sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A5: "i inHIDDENR3 I"
      have " for e be objectHIDDENM1 holds e inHIDDENR3 X .FUNCT-1K1 i implies e inHIDDENR3 Y .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        let ?G = "\<lambda>Lamb1. IFEQFUNCOP-1K14(i,Lamb1,e,f .FUNCT-1K1 Lamb1)"
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A6: "domRELAT-1K1 g =XBOOLE-0R4 I"and A7: " for u be objectHIDDENM1 holds u inHIDDENR3 I implies g .FUNCT-1K1 u =HIDDENR1 ?G(u)"
          using funct_1_sch_3 sorry
        have 
          [ty]:"g be ManySortedSetPBOOLEM1-of I"
          using A6 partfun1_def_2 relat_1_def_18 sorry
        have A8: "g .FUNCT-1K1 i =HIDDENR1 IFEQFUNCOP-1K14(i,i,e,f .FUNCT-1K1 i)"
          using A5 A7 sorry
        also have "... = e"
          using funcop_1_def_8 sorry
        finally have "g .FUNCT-1K1 i =HIDDENR1 e"
           sorry
        assume A9: "e inHIDDENR3 X .FUNCT-1K1 i"
        have "g inPBOOLER1\<^bsub>(I)\<^esub> X"
        proof-
          have " for u be objectHIDDENM1 holds u inHIDDENR3 I implies g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
          proof(rule ballI,rule impI)
            fix u assume [ty]: "u be objectHIDDENM1"
            assume A10: "u inHIDDENR3 I"
            show "g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
            proof-
              have cases: "u =HIDDENR1 i or u <>HIDDENR2 i"
                 sorry
              have case1: "u =HIDDENR1 i implies g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
              proof(rule impI)
                assume "u =HIDDENR1 i"
                thus "g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
                  using A8 A9 sorry
              qed
              have case2: "u <>HIDDENR2 i implies g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
              proof(rule impI)
                assume A11: "u <>HIDDENR2 i"
                have "g .FUNCT-1K1 u =HIDDENR1 IFEQFUNCOP-1K14(i,u,e,f .FUNCT-1K1 u)"
                  using A7 A10 sorry
                also have "... = f .FUNCT-1K1 u"
                  using A11 funcop_1_def_8 sorry
                finally have "g .FUNCT-1K1 u =HIDDENR1 f .FUNCT-1K1 u"
                   sorry
                thus "g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
                  using A4 A10 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus "g inPBOOLER1\<^bsub>(I)\<^esub> X"
            using pboole_def_1 sorry
        qed
        then have "g inPBOOLER1\<^bsub>(I)\<^esub> Y"
          using A2 sorry
        thus "e inHIDDENR3 Y .FUNCT-1K1 i"
          using A5 A8 sorry
      qed "sorry"
      thus "X .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        using tarski_def_3 sorry
    qed "sorry"
    thus "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_133:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 & X [=PBOOLER8\<^bsub>(I)\<^esub> Y implies Y be non-emptyRELAT-1V2"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X be non-emptyRELAT-1V2 implies (X [=PBOOLER8\<^bsub>(I)\<^esub> Y implies Y be non-emptyRELAT-1V2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    assume A1: "X be non-emptyRELAT-1V2"
    assume "X [=PBOOLER8\<^bsub>(I)\<^esub> Y"
    then have "X c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      using A1 pboole_th_132 sorry
    thus "Y be non-emptyRELAT-1V2"
      using A1 pboole_th_131 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve X for "non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
mtheorem pboole_th_134:
" for I be setHIDDENM2 holds  for X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  ex x be ManySortedSetPBOOLEM1-of I st x inPBOOLER1\<^bsub>(I)\<^esub> X"
proof-
  have " for I be setHIDDENM2 holds  for X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  ex tVar10 be ManySortedSetPBOOLEM1-of I st tVar10 inPBOOLER1\<^bsub>(I)\<^esub> X"
  proof(rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    let ?F = "\<lambda>Lamb1. X .FUNCT-1K1 Lamb1"
    have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?F(i) <>HIDDENR2 {}XBOOLE-0K1"
      using pboole_def_13 sorry
    obtain f where
      [ty]:"f be ManySortedSetPBOOLEM1-of I" and 
      A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i inTARSKIR2 ?F(i)"
      using pboole_sch_1 A1 sorry
    show " ex tVar10 be ManySortedSetPBOOLEM1-of I st tVar10 inPBOOLER1\<^bsub>(I)\<^esub> X"
    proof(rule bexI[of _ "f"])
      have " for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not f .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i)"
      proof(rule ballI)
        fix i assume [ty]: "i be objectHIDDENM1"
        show " not (i inHIDDENR3 I &  not f .FUNCT-1K1 i inTARSKIR2 X .FUNCT-1K1 i)"
          using A2 sorry
      qed "sorry"
      thus "f inPBOOLER1\<^bsub>(I)\<^esub> X"
        using pboole_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_135:
" for I be setHIDDENM2 holds  for Y be ManySortedSetPBOOLEM1-of I holds  for X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> Y) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
proof-
  have " for I be setHIDDENM2 holds  for Y be ManySortedSetPBOOLEM1-of I holds  for X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> Y) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    let ?F = "\<lambda>Lamb1. X .FUNCT-1K1 Lamb1"
    have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?F(i) <>HIDDENR2 {}XBOOLE-0K1"
      using pboole_def_13 sorry
    obtain f where
      [ty]:"f be ManySortedSetPBOOLEM1-of I" and 
      A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i inTARSKIR2 ?F(i)"
      using pboole_sch_1 A1 sorry
    assume A3: " for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> Y"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      have " for e be objectHIDDENM1 holds (e inHIDDENR3 X .FUNCT-1K1 i implies e inHIDDENR3 Y .FUNCT-1K1 i) & (e inHIDDENR3 Y .FUNCT-1K1 i implies e inHIDDENR3 X .FUNCT-1K1 i)"
      proof(rule ballI,rule conjMI,rule impI)
        fix e assume [ty]: "e be objectHIDDENM1"
        let ?G = "\<lambda>Lamb1. IFEQFUNCOP-1K14(i,Lamb1,e,f .FUNCT-1K1 Lamb1)"
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A5: "domRELAT-1K1 g =XBOOLE-0R4 I"and A6: " for u be objectHIDDENM1 holds u inHIDDENR3 I implies g .FUNCT-1K1 u =HIDDENR1 ?G(u)"
          using funct_1_sch_3 sorry
        have 
          [ty]:"g be ManySortedSetPBOOLEM1-of I"
          using A5 partfun1_def_2 relat_1_def_18 sorry
        have A7: "g .FUNCT-1K1 i =HIDDENR1 IFEQFUNCOP-1K14(i,i,e,f .FUNCT-1K1 i)"
          using A4 A6 sorry
        also have "... = e"
          using funcop_1_def_8 sorry
        finally have "g .FUNCT-1K1 i =HIDDENR1 e"
           sorry
        show "e inHIDDENR3 X .FUNCT-1K1 i implies e inHIDDENR3 Y .FUNCT-1K1 i"
        proof(rule impI)
          assume A8: "e inHIDDENR3 X .FUNCT-1K1 i"
          have "g inPBOOLER1\<^bsub>(I)\<^esub> X"
          proof-
            have " for u be objectHIDDENM1 holds u inHIDDENR3 I implies g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
            proof(rule ballI,rule impI)
              fix u assume [ty]: "u be objectHIDDENM1"
              assume A9: "u inHIDDENR3 I"
              show "g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
              proof-
                have cases: "u =HIDDENR1 i or u <>HIDDENR2 i"
                   sorry
                have case1: "u =HIDDENR1 i implies g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
                proof(rule impI)
                  assume "u =HIDDENR1 i"
                  thus "g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
                    using A7 A8 sorry
                qed
                have case2: "u <>HIDDENR2 i implies g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
                proof(rule impI)
                  assume A10: "u <>HIDDENR2 i"
                  have "g .FUNCT-1K1 u =HIDDENR1 IFEQFUNCOP-1K14(i,u,e,f .FUNCT-1K1 u)"
                    using A6 A9 sorry
                  also have "... = f .FUNCT-1K1 u"
                    using A10 funcop_1_def_8 sorry
                  finally have "g .FUNCT-1K1 u =HIDDENR1 f .FUNCT-1K1 u"
                     sorry
                  thus "g .FUNCT-1K1 u inTARSKIR2 X .FUNCT-1K1 u"
                    using A2 A9 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed "sorry"
            thus "g inPBOOLER1\<^bsub>(I)\<^esub> X"
              using pboole_def_1 sorry
          qed
          then have "g inPBOOLER1\<^bsub>(I)\<^esub> Y"
            using A3 sorry
          thus "e inHIDDENR3 Y .FUNCT-1K1 i"
            using A4 A7 sorry
        qed
        assume A11: "e inHIDDENR3 Y .FUNCT-1K1 i"
        have "g inPBOOLER1\<^bsub>(I)\<^esub> Y"
        proof-
          have " for u be objectHIDDENM1 holds u inHIDDENR3 I implies g .FUNCT-1K1 u inTARSKIR2 Y .FUNCT-1K1 u"
          proof(rule ballI,rule impI)
            fix u assume [ty]: "u be objectHIDDENM1"
            assume A12: "u inHIDDENR3 I"
            show "g .FUNCT-1K1 u inTARSKIR2 Y .FUNCT-1K1 u"
            proof-
              have cases: "u =HIDDENR1 i or u <>HIDDENR2 i"
                 sorry
              have case1: "u =HIDDENR1 i implies g .FUNCT-1K1 u inTARSKIR2 Y .FUNCT-1K1 u"
              proof(rule impI)
                assume "u =HIDDENR1 i"
                thus "g .FUNCT-1K1 u inTARSKIR2 Y .FUNCT-1K1 u"
                  using A7 A11 sorry
              qed
              have case2: "u <>HIDDENR2 i implies g .FUNCT-1K1 u inTARSKIR2 Y .FUNCT-1K1 u"
              proof(rule impI)
                assume A13: "u <>HIDDENR2 i"
                have "f inPBOOLER1\<^bsub>(I)\<^esub> X"
                  using A2 sorry
                then have A14: "f inPBOOLER1\<^bsub>(I)\<^esub> Y"
                  using A3 sorry
                have "g .FUNCT-1K1 u =HIDDENR1 IFEQFUNCOP-1K14(i,u,e,f .FUNCT-1K1 u)"
                  using A6 A12 sorry
                also have "... = f .FUNCT-1K1 u"
                  using A13 funcop_1_def_8 sorry
                finally have "g .FUNCT-1K1 u =HIDDENR1 f .FUNCT-1K1 u"
                   sorry
                thus "g .FUNCT-1K1 u inTARSKIR2 Y .FUNCT-1K1 u"
                  using A12 A14 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus "g inPBOOLER1\<^bsub>(I)\<^esub> Y"
            using pboole_def_1 sorry
        qed
        then have "g inPBOOLER1\<^bsub>(I)\<^esub> X"
          using A3 sorry
        thus "e inHIDDENR3 X .FUNCT-1K1 i"
          using A4 A7 sorry
      qed "sorry"
      thus "X .FUNCT-1K1 i =XBOOLE-0R4 Y .FUNCT-1K1 i"
        using tarski_th_2 sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_136:
" for I be setHIDDENM2 holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> Y & x inPBOOLER1\<^bsub>(I)\<^esub> Z) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
proof-
  have " for I be setHIDDENM2 holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds  for X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds ( for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> Y & x inPBOOLER1\<^bsub>(I)\<^esub> Z) implies X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix X assume [ty]: "X be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: " for x be ManySortedSetPBOOLEM1-of I holds x inPBOOLER1\<^bsub>(I)\<^esub> X iff x inPBOOLER1\<^bsub>(I)\<^esub> Y & x inPBOOLER1\<^bsub>(I)\<^esub> Z"
    have " for x be ManySortedSetPBOOLEM1-of I holds (x inPBOOLER1\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z) & (x inPBOOLER1\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z implies x inPBOOLER1\<^bsub>(I)\<^esub> X)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be ManySortedSetPBOOLEM1-of I"
      show "x inPBOOLER1\<^bsub>(I)\<^esub> X implies x inPBOOLER1\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      proof(rule impI)
        assume "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        then have "x inPBOOLER1\<^bsub>(I)\<^esub> Y & x inPBOOLER1\<^bsub>(I)\<^esub> Z"
          using A1 sorry
        thus "x inPBOOLER1\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
          using pboole_th_8 sorry
      qed
      assume "x inPBOOLER1\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      then have "x inPBOOLER1\<^bsub>(I)\<^esub> Y & x inPBOOLER1\<^bsub>(I)\<^esub> Z"
        using pboole_th_8 sorry
      thus "x inPBOOLER1\<^bsub>(I)\<^esub> X"
        using A1 sorry
    qed "sorry"
    thus "X =PBOOLER7\<^bsub>(I)\<^esub> Y (/\\)PBOOLEK3\<^bsub>(I)\<^esub> Z"
      using pboole_th_135 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
theorem pboole_sch_3:
  fixes If0 Pp2 
  assumes
[ty]: "If0 be setHIDDENM2" and
   A1: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( ex j be objectHIDDENM1 st Pp2(i,j))"
  shows " ex f be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies Pp2(i,f .FUNCT-1K1 i)"
  proof-
    have " ex tVar11 be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 &  not Pp2(i,tVar11 .FUNCT-1K1 i))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A2: "domRELAT-1K1 f =XBOOLE-0R4 If0"and A3: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies Pp2(i,f .FUNCT-1K1 i)"
        using classes1_sch_1 A1 sorry
      have 
        [ty]:"f be ManySortedSetPBOOLEM1-of If0"
        using A2 partfun1_def_2 relat_1_def_18 sorry
      show " ex tVar11 be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 &  not Pp2(i,tVar11 .FUNCT-1K1 i))"
      proof(rule bexI[of _ "f"])
        show " for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 &  not Pp2(i,f .FUNCT-1K1 i))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem pboole_sch_4:
  fixes If0 Ff1 
  assumes
[ty]: "If0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex f be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies f .FUNCT-1K1 i =HIDDENR1 Ff1(i)"
  proof-
    have " ex tVar12 be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 &  not tVar12 .FUNCT-1K1 i =HIDDENR1 Ff1(i))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 If0"and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies f .FUNCT-1K1 i =HIDDENR1 Ff1(i)"
        using funct_1_sch_3 sorry
      have 
        [ty]:"f be ManySortedSetPBOOLEM1-of If0"
        using A1 partfun1_def_2 relat_1_def_18 sorry
      show " ex tVar12 be ManySortedSetPBOOLEM1-of If0 st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 &  not tVar12 .FUNCT-1K1 i =HIDDENR1 Ff1(i))"
      proof(rule bexI[of _ "f"])
        show " for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 &  not f .FUNCT-1K1 i =HIDDENR1 Ff1(i))"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem pboole_cl_6:
  mlet "I be setHIDDENM2"
"cluster Function-yieldingFUNCOP-1V1 for ManySortedSetPBOOLEM1-of I"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of I st it be Function-yieldingFUNCOP-1V1"
  proof-
    have " ex tVar13 be ManySortedSetPBOOLEM1-of I st tVar13 be Function-yieldingFUNCOP-1V1"
    proof-
      let ?f = "the FunctionFUNCT-1M1"
      obtain F where 
        [ty]:"F be ManySortedSetPBOOLEM1-of I" and FDef:"F = I -->FUNCOP-1K7 ?f"
         sorry
      show " ex tVar13 be ManySortedSetPBOOLEM1-of I st tVar13 be Function-yieldingFUNCOP-1V1"
      proof(rule bexI[of _ "F"])
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x be setHIDDENM2"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 F"
          show "F .FUNCT-1K1 x be setHIDDENM2"
             sorry
        qed "sorry"
        thus "F be Function-yieldingFUNCOP-1V1"
          using funcop_1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax PBOOLEM2 :: " Set \<Rightarrow> Ty" ("ManySortedFunctionPBOOLEM2-of  _ " [70]70)
translations "ManySortedFunctionPBOOLEM2-of I" \<rightharpoonup> "Function-yieldingFUNCOP-1V1\<bar>ManySortedSetPBOOLEM1-of I"

mtheorem pboole_th_137:
" for I be setHIDDENM2 holds  not ( ex M be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I st {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 M)"
proof-
  have " for I be setHIDDENM2 holds  for M be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 M implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    have A1: "domRELAT-1K1 M =XBOOLE-0R4 I"
      using partfun1_def_2 sorry
    assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 M"
    then have " ex i be objectHIDDENM1 st i inHIDDENR3 I & M .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 funct_1_def_3 sorry
    thus " False "
      using pboole_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) PBOOLEM3("ComponentPBOOLEM3-of  _ " [70]70) where
  "ComponentPBOOLEM3-of M \<equiv> ElementSUBSET-1M1-of rngFUNCT-1K2 M"

mtheorem pboole_th_138:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for A be ComponentPBOOLEM3-of M holds  ex i be objectHIDDENM1 st i inHIDDENR3 I & A =XBOOLE-0R4 M .FUNCT-1K1 i"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for A be ComponentPBOOLEM3-of M holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & A =XBOOLE-0R4 M .FUNCT-1K1 i))"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix A assume [ty]: "A be ComponentPBOOLEM3-of M"
    have A1: "domRELAT-1K1 M =XBOOLE-0R4 I"
      using partfun1_def_2 sorry
    then have "rngFUNCT-1K2 M <>HIDDENR2 {}XBOOLE-0K1"
      using relat_1_th_42 sorry
    thus " not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & A =XBOOLE-0R4 M .FUNCT-1K1 i))"
      using A1 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_139:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i be ComponentPBOOLEM3-of M"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i be ComponentPBOOLEM3-of M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix i assume [ty]: "i be objectHIDDENM1"
    assume A1: "i inHIDDENR3 I"
    have "domRELAT-1K1 M =XBOOLE-0R4 I"
      using partfun1_def_2 sorry
    thus "M .FUNCT-1K1 i be ComponentPBOOLEM3-of M"
      using A1 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef pboole_def_14 ("ElementPBOOLEM4\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70 ) where
  mlet "I be setHIDDENM2", "B be ManySortedSetPBOOLEM1-of I"
"mode ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B \<rightarrow> ManySortedSetPBOOLEM1-of I means
  (\<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i be ElementSUBSET-1M1-of B .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
    proof-
      have " ex f be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
      proof-
        let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 be ElementSUBSET-1M1-of B .FUNCT-1K1 Lamb1"
        have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?Q(i,j))"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar14 be objectHIDDENM1 st tVar14 be ElementSUBSET-1M1-of B .FUNCT-1K1 i)"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 I"
            let ?j = "the ElementSUBSET-1M1-of B .FUNCT-1K1 i"
            obtain j where 
              [ty]:"j be setHIDDENM2" and jDef:"j = ?j"
               sorry
            show " ex tVar14 be objectHIDDENM1 st tVar14 be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
            proof(rule bexI[of _ "j"])
              show "j be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " ex f be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
          using pboole_sch_3 A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

(*begin*)
mdef pboole_def_15 ("ManySortedFunctionPBOOLEM5\<^bsub>'( _ ')\<^esub>-of'( _ , _ ')" [0,0,0]70 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"mode ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B) \<rightarrow> ManySortedSetPBOOLEM1-of I means
  (\<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i))"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
    proof-
      have " ex tVar16 be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies tVar16 .FUNCT-1K1 i be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 be FunctionFUNCT-2M1-of(A .FUNCT-1K1 Lamb1,B .FUNCT-1K1 Lamb1)"
        have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?P(i,j))"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar15 be objectHIDDENM1 st tVar15 be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i))"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 I"
            let ?j = "the FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
            obtain j where 
              [ty]:"j be setHIDDENM2" and jDef:"j = ?j"
               sorry
            show " ex tVar15 be objectHIDDENM1 st tVar15 be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
            proof(rule bexI[of _ "j"])
              show "j be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be ManySortedSetPBOOLEM1-of I" and 
          A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?P(i,f .FUNCT-1K1 i)"
          using pboole_sch_3 A1 sorry
        have "f be Function-yieldingFUNCOP-1V1"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be setHIDDENM2"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 domRELAT-1K1 f"
            then have "i inHIDDENR3 I"
              using partfun1_def_2 sorry
            thus "f .FUNCT-1K1 i be setHIDDENM2"
              using A2 sorry
          qed "sorry"
          thus "f be Function-yieldingFUNCOP-1V1"
            using funcop_1_def_6 sorry
        qed
        then have 
          [ty]:"f be ManySortedFunctionPBOOLEM2-of I"
           sorry
        show " ex tVar16 be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies tVar16 .FUNCT-1K1 i be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
        proof(rule bexI[of _ "f"],rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          thus "f .FUNCT-1K1 i be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem pboole_cl_7:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"cluster note-that Function-yieldingFUNCOP-1V1 for ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B)"
proof
(*coherence*)
  show " for it be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B) holds it be Function-yieldingFUNCOP-1V1"
  proof-
    have " for f be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B) holds f be Function-yieldingFUNCOP-1V1"
    proof(rule ballI)
      fix f assume [ty]: "f be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B)"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 i be setHIDDENM2"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 domRELAT-1K1 f"
        then have "i inHIDDENR3 I"
          using partfun1_def_2 sorry
        thus "f .FUNCT-1K1 i be setHIDDENM2"
          using pboole_def_15 sorry
      qed "sorry"
      thus "f be Function-yieldingFUNCOP-1V1"
        using funcop_1_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pboole_cl_8:
  mlet "I be setHIDDENM2", "J be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "O be FunctionFUNCT-2M1-of(I,J)", "F be ManySortedSetPBOOLEM1-of J"
"cluster F *FUNCT-1K3 O as-term-is totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 F *FUNCT-1K3 O implies it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
  proof-
    have " for VarFor1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 F *FUNCT-1K3 O &  not VarFor1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>)"
    proof-
      have A1: "domRELAT-1K1 F =XBOOLE-0R4 J"
        using partfun1_def_2 sorry
      have "rngFUNCT-1K2 O c=TARSKIR1 J & domRELAT-1K1 O =XBOOLE-0R4 I"
        using funct_2_def_1 relat_1_def_19 sorry
      then have "domRELAT-1K1 (F *FUNCT-1K3 O) =XBOOLE-0R4 I"
        using A1 relat_1_th_27 sorry
      thus " for VarFor1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 F *FUNCT-1K3 O &  not VarFor1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

theorem pboole_sch_5:
  fixes Df0 Ff1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex X be ManySortedSetPBOOLEM1-of Df0 st  for d be ElementSUBSET-1M1-of Df0 holds X .FUNCT-1K1 d =HIDDENR1 Ff1(d)"
  proof-
    have " not ( for X be ManySortedSetPBOOLEM1-of Df0 holds  not ( for d be ElementSUBSET-1M1-of Df0 holds X .FUNCT-1K1 d =HIDDENR1 Ff1(d)))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Df0"and A2: " for d be ElementSUBSET-1M1-of Df0 holds f .FUNCT-1K1 d =HIDDENR1 Ff1(d)"
        using funct_1_sch_4 sorry
      have "f be ManySortedSetPBOOLEM1-of Df0"
        using A1 partfun1_def_2 relat_1_def_18 sorry
      thus " not ( for X be ManySortedSetPBOOLEM1-of Df0 holds  not ( for d be ElementSUBSET-1M1-of Df0 holds X .FUNCT-1K1 d =HIDDENR1 Ff1(d)))"
        using A2 sorry
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem pboole_cl_9:
  mlet "J be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of J", "j be ElementSUBSET-1M1-of J"
"cluster B .FUNCT-1K1 j as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "B .FUNCT-1K1 j be  non emptyXBOOLE-0V1"
    using pboole_def_13 sorry
qed "sorry"

reserve X, Y for "ManySortedSetPBOOLEM1-of I"
mdef pboole_def_16 ("[|PBOOLEK6\<^bsub>'( _ ')\<^esub> _ , _ |]" [0,0,0]164 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"func [|PBOOLEK6\<^bsub>(I)\<^esub> X,Y |] \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
    proof-
      have " ex tVar17 be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not tVar17 .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :])"
      proof-
        let ?F = "\<lambda>Lamb1. [:ZFMISC-1K2 X .FUNCT-1K1 Lamb1,Y .FUNCT-1K1 Lamb1 :]"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A1: "domRELAT-1K1 f =XBOOLE-0R4 I & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i =XBOOLE-0R4 ?F(i))"
          using funct_1_sch_3 sorry
        have 
          [ty]:"f be ManySortedSetPBOOLEM1-of I"
          using A1 partfun1_def_2 relat_1_def_18 sorry
        show " ex tVar17 be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not tVar17 .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :])"
        proof(rule bexI[of _ "f"])
          show " for i be objectHIDDENM1 holds  not (i inHIDDENR3 I &  not f .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :])"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]) implies it1 =HIDDENR1 it2"
    proof-
      have " for f be ManySortedSetPBOOLEM1-of I holds  for g be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies g .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]) implies f =HIDDENR1 g"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f assume [ty]: "f be ManySortedSetPBOOLEM1-of I"
        fix g assume [ty]: "g be ManySortedSetPBOOLEM1-of I"
        assume A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies f .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
          and A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies g .FUNCT-1K1 i =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 i,Y .FUNCT-1K1 i :]"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 I implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A4: "x inHIDDENR3 I"
          then have "f .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 X .FUNCT-1K1 x,Y .FUNCT-1K1 x :]"
            using A2 sorry
          thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
            using A3 A4 sorry
        qed "sorry"
        thus "f =HIDDENR1 g"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef pboole_def_17 ("'(Funcs')PBOOLEK7\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "I be setHIDDENM2", "X be ManySortedSetPBOOLEM1-of I", "Y be ManySortedSetPBOOLEM1-of I"
"func (Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(X,Y) \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
    proof-
      let ?F = "\<lambda>Lamb1. FuncsFUNCT-2K1(X .FUNCT-1K1 Lamb1,Y .FUNCT-1K1 Lamb1)"
      show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies it .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
      proof-
        have " ex M be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
        proof-
          show " ex M be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
            using pboole_sch_4 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. FuncsFUNCT-2K1(X .FUNCT-1K1 Lamb1,Y .FUNCT-1K1 Lamb1)"
      show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
      proof-
        have " for F1 be ManySortedSetPBOOLEM1-of I holds  for F2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies F1 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies F2 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)) implies F1 =HIDDENR1 F2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix F1 assume [ty]: "F1 be ManySortedSetPBOOLEM1-of I"
          fix F2 assume [ty]: "F2 be ManySortedSetPBOOLEM1-of I"
          assume A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies F1 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
            and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies F2 .FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies F1 .FUNCT-1K1 i =HIDDENR1 F2 .FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume A3: "i inHIDDENR3 I"
            then have "F1 .FUNCT-1K1 i =HIDDENR1 FuncsFUNCT-2K1(X .FUNCT-1K1 i,Y .FUNCT-1K1 i)"
              using A1 sorry
            also have "... = F2 .FUNCT-1K1 i"
              using A2 A3 sorry
            finally show "F1 .FUNCT-1K1 i =HIDDENR1 F2 .FUNCT-1K1 i"
               sorry
          qed "sorry"
          thus "F1 =HIDDENR1 F2"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef pboole_def_18 ("ManySortedSubsetPBOOLEM6\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"mode ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M \<rightarrow> ManySortedSetPBOOLEM1-of I means
  (\<lambda>it. it c=PBOOLER2\<^bsub>(I)\<^esub> M)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st it c=PBOOLER2\<^bsub>(I)\<^esub> M"
       sorry
qed "sorry"

mtheorem pboole_cl_10:
  mlet "I be setHIDDENM2", "M be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
"cluster non-emptyRELAT-1V2 for ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M st it be non-emptyRELAT-1V2"
  proof-
    have " ex tVar18 be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M st tVar18 be non-emptyRELAT-1V2"
    proof-
      obtain N where 
        [ty]:"N be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M" and NDef:"N = M"
        using pboole_def_18 sorry
      show " ex tVar18 be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M st tVar18 be non-emptyRELAT-1V2"
      proof(rule bexI[of _ "N"])
        show "N be non-emptyRELAT-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef pboole_def_19 (" _ **PBOOLEK8  _ " [164,164]164 ) where
  mlet "F be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1", "G be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
"func G **PBOOLEK8 F \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i)"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i))))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 G .FUNCT-1K1 Lamb1 *FUNCT-1K3 F .FUNCT-1K1 Lamb1"
        have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G implies ( ex u be objectHIDDENM1 st ?P(i,u))"
           sorry
        have " ex H be FunctionFUNCT-1M1 st domRELAT-1K1 H =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G implies ?P(i,H .FUNCT-1K1 i))"
          using classes1_sch_1 A1 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
    proof-
      have " for H1 be FunctionFUNCT-1M1 holds  for H2 be FunctionFUNCT-1M1 holds domRELAT-1K1 H1 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & (( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 H1 implies H1 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i) & (domRELAT-1K1 H2 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G & ( for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 H2 implies H2 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i))) implies H1 =HIDDENR1 H2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix H1 assume [ty]: "H1 be FunctionFUNCT-1M1"
        fix H2 assume [ty]: "H2 be FunctionFUNCT-1M1"
        assume A2: "domRELAT-1K1 H1 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G"
          and A3: " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 H1 implies H1 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i"
          and A4: "domRELAT-1K1 H2 =XBOOLE-0R4 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G"
          and A5: " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 H2 implies H2 .FUNCT-1K1 i =XBOOLE-0R4 G .FUNCT-1K1 i *FUNCT-1K3 F .FUNCT-1K1 i"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G implies H1 .FUNCT-1K1 i =XBOOLE-0R4 H2 .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          obtain f where 
            [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F .FUNCT-1K1 i"
             sorry
          obtain g where 
            [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = G .FUNCT-1K1 i"
             sorry
          assume A6: "i inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G"
          then have "H1 .FUNCT-1K1 i =XBOOLE-0R4 g *FUNCT-1K3 f"
            using A2 A3 sorry
          thus "H1 .FUNCT-1K1 i =XBOOLE-0R4 H2 .FUNCT-1K1 i"
            using A4 A5 A6 sorry
        qed "sorry"
        thus "H1 =HIDDENR1 H2"
          using A2 A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem pboole_cl_11:
  mlet "F be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1", "G be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
"cluster G **PBOOLEK8 F as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "G **PBOOLEK8 F be Function-yieldingFUNCOP-1V1"
  proof-
    let ?H = "G **PBOOLEK8 F"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (G **PBOOLEK8 F) implies (G **PBOOLEK8 F).FUNCT-1K1 x be setHIDDENM2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      obtain f where 
        [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F .FUNCT-1K1 x"
         sorry
      obtain g where 
        [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = G .FUNCT-1K1 x"
         sorry
      assume "x inHIDDENR3 domRELAT-1K1 ?H"
      then have "?H .FUNCT-1K1 x =XBOOLE-0R4 g *FUNCT-1K3 f"
        using pboole_def_19 sorry
      thus "(G **PBOOLEK8 F).FUNCT-1K1 x be setHIDDENM2"
         sorry
    qed "sorry"
    thus "G **PBOOLEK8 F be Function-yieldingFUNCOP-1V1"
      using funcop_1_def_6 sorry
  qed
qed "sorry"

mdef pboole_def_20 (" _ .:.:PBOOLEK9\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "F be ManySortedFunctionPBOOLEM2-of I"
"func F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be setHIDDENM2 holds i inTARSKIR2 I implies it .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be setHIDDENM2 holds i inTARSKIR2 I implies it .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)"
    proof-
      have " ex tVar19 be ManySortedSetPBOOLEM1-of I st  for i be setHIDDENM2 holds  not (i inTARSKIR2 I &  not tVar19 .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 (F .FUNCT-1K1 Lamb1).:FUNCT-1K5 (A .FUNCT-1K1 Lamb1)"
        have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex u be objectHIDDENM1 st ?P(i,u))"
           sorry
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A2: "domRELAT-1K1 g =XBOOLE-0R4 I & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?P(i,g .FUNCT-1K1 i))"
          using classes1_sch_1 A1 sorry
        have 
          [ty]:"g be ManySortedSetPBOOLEM1-of I"
          using A2 partfun1_def_2 relat_1_def_18 sorry
        show " ex tVar19 be ManySortedSetPBOOLEM1-of I st  for i be setHIDDENM2 holds  not (i inTARSKIR2 I &  not tVar19 .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i))"
        proof(rule bexI[of _ "g"])
          show " for i be setHIDDENM2 holds  not (i inTARSKIR2 I &  not g .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i))"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be setHIDDENM2 holds i inTARSKIR2 I implies it1 .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)) & ( for i be setHIDDENM2 holds i inTARSKIR2 I implies it2 .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
    proof-
      have " for B be ManySortedSetPBOOLEM1-of I holds  for B1 be ManySortedSetPBOOLEM1-of I holds ( for i be setHIDDENM2 holds i inTARSKIR2 I implies B .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)) & ( for i be setHIDDENM2 holds i inTARSKIR2 I implies B1 .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)) implies B =HIDDENR1 B1"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
        fix B1 assume [ty]: "B1 be ManySortedSetPBOOLEM1-of I"
        assume A3: " for i be setHIDDENM2 holds i inTARSKIR2 I implies B .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)"
          and A4: " for i be setHIDDENM2 holds i inTARSKIR2 I implies B1 .FUNCT-1K1 i =XBOOLE-0R4 (F .FUNCT-1K1 i).:FUNCT-1K5 (A .FUNCT-1K1 i)"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies B .FUNCT-1K1 i =XBOOLE-0R4 B1 .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          obtain f where 
            [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F .FUNCT-1K1 i"
             sorry
          assume A5: "i inHIDDENR3 I"
          then have "B .FUNCT-1K1 i =XBOOLE-0R4 f .:FUNCT-1K5 (A .FUNCT-1K1 i)"
            using A3 sorry
          thus "B .FUNCT-1K1 i =XBOOLE-0R4 B1 .FUNCT-1K1 i"
            using A4 A5 sorry
        qed "sorry"
        thus "B =HIDDENR1 B1"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem pboole_cl_12:
  mlet "I be setHIDDENM2"
"cluster EmptyMSPBOOLEK1 I as-term-is empty-yieldingRELAT-1V3"
proof
(*coherence*)
  show "EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3"
    using funcop_1_th_13 sorry
qed "sorry"

theorem pboole_sch_6:
  fixes If0 Pp2 
  assumes
[ty]: "If0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: " for i be ElementSUBSET-1M1-of If0 holds  ex j be objectHIDDENM1 st Pp2(i,j)"
  shows " ex f be ManySortedSetPBOOLEM1-of If0 st  for i be ElementSUBSET-1M1-of If0 holds Pp2(i,f .FUNCT-1K1 i)"
  proof-
    have " ex tVar20 be ManySortedSetPBOOLEM1-of If0 st  for i be ElementSUBSET-1M1-of If0 holds Pp2(i,tVar20 .FUNCT-1K1 i)"
    proof-
      have A2: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( ex j be objectHIDDENM1 st Pp2(i,j))"
        using A1 sorry
      obtain f where
        [ty]:"f be ManySortedSetPBOOLEM1-of If0" and 
        A3: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies Pp2(i,f .FUNCT-1K1 i)"
        using pboole_sch_3 A2 sorry
      show " ex tVar20 be ManySortedSetPBOOLEM1-of If0 st  for i be ElementSUBSET-1M1-of If0 holds Pp2(i,tVar20 .FUNCT-1K1 i)"
      proof(rule bexI[of _ "f"],rule ballI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of If0"
        show "Pp2(i,f .FUNCT-1K1 i)"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem pboole_cl_13:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster non-emptyRELAT-1V2 also-is  non empty-yieldingRELAT-1V3 for ManySortedSetPBOOLEM1-of A"
proof
(*coherence*)
  show " for it be ManySortedSetPBOOLEM1-of A holds it be non-emptyRELAT-1V2 implies it be  non empty-yieldingRELAT-1V3"
     sorry
qed "sorry"

mtheorem pboole_cl_14:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non emptyXBOOLE-0V1 for ManySortedSetPBOOLEM1-of X"
proof
(*coherence*)
  show " for it be ManySortedSetPBOOLEM1-of X holds it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem pboole_th_140:
" for F be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds  for G be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds  for H be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1 holds (H **PBOOLEK8 G)**PBOOLEK8 F =FUNCT-1R1 H **PBOOLEK8 (G **PBOOLEK8 F)"
proof(rule ballI,rule ballI,rule ballI)
  fix F assume [ty]: "F be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
  fix G assume [ty]: "G be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
  fix H assume [ty]: "H be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1"
  let ?f = "(H **PBOOLEK8 G)**PBOOLEK8 F"
  let ?g = "H **PBOOLEK8 (G **PBOOLEK8 F)"
  have "domRELAT-1K1 ((H **PBOOLEK8 G)**PBOOLEK8 F) =HIDDENR1 domRELAT-1K1 (H **PBOOLEK8 (G **PBOOLEK8 F)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((H **PBOOLEK8 G)**PBOOLEK8 F) implies ((H **PBOOLEK8 G)**PBOOLEK8 F).FUNCT-1K1 x =HIDDENR1 (H **PBOOLEK8 (G **PBOOLEK8 F)).FUNCT-1K1 x)"
  proof(rule conjMI,rule ballI,rule impI)
    have A1: "domRELAT-1K1 ?f =HIDDENR1 domRELAT-1K1 (H **PBOOLEK8 G) /\\XBOOLE-0K3 domRELAT-1K1 F"
      using pboole_def_19 sorry
    also have "... = (domRELAT-1K1 H /\\XBOOLE-0K3 domRELAT-1K1 G)/\\XBOOLE-0K3 domRELAT-1K1 F"
      using pboole_def_19 sorry
    finally have "domRELAT-1K1 ?f =HIDDENR1 (domRELAT-1K1 H /\\XBOOLE-0K3 domRELAT-1K1 G)/\\XBOOLE-0K3 domRELAT-1K1 F"
       sorry
    then have A2: "domRELAT-1K1 ?f =XBOOLE-0R4 domRELAT-1K1 H /\\XBOOLE-0K3 (domRELAT-1K1 G /\\XBOOLE-0K3 domRELAT-1K1 F)"
      using xboole_1_th_16 sorry
    then have A3: "domRELAT-1K1 ((H **PBOOLEK8 G)**PBOOLEK8 F) =HIDDENR1 domRELAT-1K1 H /\\XBOOLE-0K3 domRELAT-1K1 (G **PBOOLEK8 F)"
      using pboole_def_19 sorry
    also have "... = domRELAT-1K1 (H **PBOOLEK8 (G **PBOOLEK8 F))"
      using pboole_def_19 sorry
    finally show "domRELAT-1K1 ((H **PBOOLEK8 G)**PBOOLEK8 F) =HIDDENR1 domRELAT-1K1 (H **PBOOLEK8 (G **PBOOLEK8 F))"
       sorry
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A4: "x inHIDDENR3 domRELAT-1K1 ?f"
    then have "x inHIDDENR3 domRELAT-1K1 H /\\XBOOLE-0K3 domRELAT-1K1 G"
      using A1 xboole_0_def_4 sorry
    then have A5: "x inHIDDENR3 domRELAT-1K1 (H **PBOOLEK8 G)"
      using pboole_def_19 sorry
    have "x inHIDDENR3 domRELAT-1K1 G /\\XBOOLE-0K3 domRELAT-1K1 F"
      using A2 A4 xboole_0_def_4 sorry
    then have A6: "x inHIDDENR3 domRELAT-1K1 (G **PBOOLEK8 F)"
      using pboole_def_19 sorry
    have "((H **PBOOLEK8 G)**PBOOLEK8 F).FUNCT-1K1 x =HIDDENR1 (H **PBOOLEK8 G).FUNCT-1K1 x *FUNCT-1K3 F .FUNCT-1K1 x"
      using A4 pboole_def_19 sorry
    also have "... = (H .FUNCT-1K1 x *FUNCT-1K3 G .FUNCT-1K1 x)*FUNCT-1K3 F .FUNCT-1K1 x"
      using A5 pboole_def_19 sorry
    also have "... = H .FUNCT-1K1 x *FUNCT-1K3 (G .FUNCT-1K1 x *FUNCT-1K3 F .FUNCT-1K1 x)"
      using relat_1_th_36 sorry
    also have "... = H .FUNCT-1K1 x *FUNCT-1K3 (G **PBOOLEK8 F).FUNCT-1K1 x"
      using A6 pboole_def_19 sorry
    also have "... = (H **PBOOLEK8 (G **PBOOLEK8 F)).FUNCT-1K1 x"
      using A3 A4 pboole_def_19 sorry
    finally show "((H **PBOOLEK8 G)**PBOOLEK8 F).FUNCT-1K1 x =HIDDENR1 (H **PBOOLEK8 (G **PBOOLEK8 F)).FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus "(H **PBOOLEK8 G)**PBOOLEK8 F =FUNCT-1R1 H **PBOOLEK8 (G **PBOOLEK8 F)"
     sorry
qed "sorry"

mtheorem pboole_cl_15:
  mlet "I be setHIDDENM2", "f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
"cluster totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1 st it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
  proof-
    have " ex tVar21 be I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1 st tVar21 be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
    proof-
      let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1"
      have A1: " for e be objectHIDDENM1 holds e inHIDDENR3 I implies ?F(e) <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      obtain g where
        [ty]:"g be ManySortedSetPBOOLEM1-of I" and 
        A2: " for e be objectHIDDENM1 holds e inHIDDENR3 I implies g .FUNCT-1K1 e inTARSKIR2 ?F(e)"
        using pboole_sch_1 A1 sorry
      have "g be f -compatibleFUNCT-1V7"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 g"
          then have "x inHIDDENR3 I"
            using partfun1_def_2 sorry
          thus "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
            using A2 sorry
        qed "sorry"
        thus "g be f -compatibleFUNCT-1V7"
          using funct_1_def_14 sorry
      qed
      then have 
        [ty]:"g be I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1"
         sorry
      show " ex tVar21 be I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1 st tVar21 be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
      proof(rule bexI[of _ "g"])
        show "g be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pboole_th_141:
" for I be setHIDDENM2 holds  for f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  ex s be f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I st p c=RELAT-1R2 s"
proof-
  have " for I be setHIDDENM2 holds  for f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  ex tVar22 be f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I st p c=RELAT-1R2 tVar22"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix f assume [ty]: "f be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    fix p assume [ty]: "p be f -compatibleFUNCT-1V7\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    let ?h = "the f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I"
    show " ex tVar22 be f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I st p c=RELAT-1R2 tVar22"
    proof(rule bexI[of _ "?h +*FUNCT-4K1 p"])
      show "p c=RELAT-1R2 (the f -compatibleFUNCT-1V7\<bar>ManySortedSetPBOOLEM1-of I)+*FUNCT-4K1 p"
        using funct_4_th_25 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_142:
" for I be setHIDDENM2 holds  for A be setHIDDENM2 holds  for s be ManySortedSetPBOOLEM1-of I holds  for ss be ManySortedSetPBOOLEM1-of I holds (ss +*FUNCT-4K1 s  |RELAT-1K8 A) |RELAT-1K8 A =FUNCT-1R1 s  |RELAT-1K8 A"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix I assume [ty]: "I be setHIDDENM2"
  fix A assume [ty]: "A be setHIDDENM2"
  fix s assume [ty]: "s be ManySortedSetPBOOLEM1-of I"
  fix ss assume [ty]: "ss be ManySortedSetPBOOLEM1-of I"
  have "domRELAT-1K1 s =HIDDENR1 I"
    using partfun1_def_2 sorry
  also have "... = domRELAT-1K1 ss"
    using partfun1_def_2 sorry
  finally have "domRELAT-1K1 s =HIDDENR1 domRELAT-1K1 ss"
     sorry
  then have "A /\\XBOOLE-0K3 domRELAT-1K1 ss c=TARSKIR1 A /\\XBOOLE-0K3 domRELAT-1K1 s"
     sorry
  thus "(ss +*FUNCT-4K1 s  |RELAT-1K8 A) |RELAT-1K8 A =FUNCT-1R1 s  |RELAT-1K8 A"
    using funct_4_th_88 sorry
qed "sorry"

mtheorem pboole_cl_16:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be setHIDDENM2"
"cluster X -valuedRELAT-1V5 for ManySortedSetPBOOLEM1-of Y"
proof
(*existence*)
  show " ex it be ManySortedSetPBOOLEM1-of Y st it be X -valuedRELAT-1V5"
  proof-
    have " ex M be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 Y,X :]) st M be X -valuedRELAT-1V5"
    proof-
      obtain M where 
        [ty]:"M be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 Y,X :])" and MDef:"M = Y -->FUNCOP-1K8\<^bsub>(X)\<^esub> (the ElementSUBSET-1M1-of X)"
         sorry
      show " ex M be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 Y,X :]) st M be X -valuedRELAT-1V5"
      proof(rule bexI[of _ "M"])
        have A1: "{TARSKIK1 the ElementSUBSET-1M1-of X } c=TARSKIR1 X"
          using zfmisc_1_th_31 sorry
        have Cut2417: "rngFUNCT-1K2 M c=TARSKIR1 {TARSKIK1 the ElementSUBSET-1M1-of X }"
          using funcop_1_th_13 sorry
        have "rngFUNCT-1K2 M c=TARSKIR1 X"
        proof-
          show "rngFUNCT-1K2 M c=TARSKIR1 X"
            using A1 Cut2417 sorry
        qed
        thus "M be X -valuedRELAT-1V5"
          using relat_1_def_19 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem pboole_th_143:
" for I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for M be Y -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of I holds  for x be ElementSUBSET-1M1-of I holds M .FUNCT-1K1 x =XBOOLE-0R4 M /.PARTFUN1K7\<^bsub>(Y)\<^esub> x"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix M assume [ty]: "M be Y -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of I"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of I"
  have "domRELAT-1K1 M =XBOOLE-0R4 I"
    using partfun1_def_2 sorry
  thus "M .FUNCT-1K1 x =XBOOLE-0R4 M /.PARTFUN1K7\<^bsub>(Y)\<^esub> x"
    using partfun1_def_6 sorry
qed "sorry"

mtheorem pboole_th_144:
" for I be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for M be ManySortedSetPBOOLEM1-of I holds (f +*FUNCT-4K1 M) |RELAT-1K8 I =FUNCT-1R1 M"
proof-
  have " for I be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for M be ManySortedSetPBOOLEM1-of I holds (f +*FUNCT-4K1 M) |RELAT-1K8 I =HIDDENR1 M"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    have A1: "domRELAT-1K1 (f  |RELAT-1K8 I) c=TARSKIR1 I"
      using relat_1_th_58 sorry
    have A2: "domRELAT-1K1 M =XBOOLE-0R4 I"
      using partfun1_def_2 sorry
    have "(f +*FUNCT-4K1 M) |RELAT-1K8 I =HIDDENR1 f  |RELAT-1K8 I +*FUNCT-4K1 M  |RELAT-1K8 I"
      using funct_4_th_71 sorry
    also have "... = f  |RELAT-1K8 I +*FUNCT-4K1 M"
       sorry
    also have "... = M"
      using A1 A2 funct_4_th_19 sorry
    finally show "(f +*FUNCT-4K1 M) |RELAT-1K8 I =HIDDENR1 M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_145:
" for I be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be Y -valuedRELAT-1V5\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  ex s be Y -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of I st p c=RELAT-1R2 s"
proof-
  have " for I be setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be Y -valuedRELAT-1V5\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  ex tVar24 be Y -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of I st p c=RELAT-1R2 tVar24"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be Y -valuedRELAT-1V5\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    let ?h = "the Y -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of I"
    show " ex tVar24 be Y -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of I st p c=RELAT-1R2 tVar24"
    proof(rule bexI[of _ "?h +*FUNCT-4K1 p"])
      show "p c=RELAT-1R2 (the Y -valuedRELAT-1V5\<bar>ManySortedSetPBOOLEM1-of I)+*FUNCT-4K1 p"
        using funct_4_th_25 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pboole_th_146:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds X c=PBOOLER2\<^bsub>(I)\<^esub> Y & Y c=PBOOLER2\<^bsub>(I)\<^esub> X implies X =PBOOLER7\<^bsub>(I)\<^esub> Y"
  using pboole_lm_1 sorry

syntax PBOOLER9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ =PBOOLER9\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "A =PBOOLER9\<^bsub>(I)\<^esub> B" \<rightharpoonup> "A =HIDDENR1 B"

mtheorem pboole_def_21:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be ManySortedSetPBOOLEM1-of I"
"redefine pred A =PBOOLER9\<^bsub>(I)\<^esub> B means
   for i be ElementSUBSET-1M1-of I holds A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i"
proof
(*compatibility*)
  show "A =PBOOLER9\<^bsub>(I)\<^esub> B iff ( for i be ElementSUBSET-1M1-of I holds A .FUNCT-1K1 i =XBOOLE-0R4 B .FUNCT-1K1 i)"
     sorry
qed "sorry"

mtheorem pboole_cl_17:
  mlet "X be with-non-empty-elementsSETFAM-1V1\<bar>setHIDDENM2"
"cluster idPARTFUN1K6 X as-term-is non-emptyFUNCT-1V4"
proof
(*coherence*)
  show "idPARTFUN1K6 X be non-emptyFUNCT-1V4"
    using setfam_1_def_8 sorry
qed "sorry"

theorem pboole_sch_7:
  fixes If0 Ff1 
  assumes
[ty]: "If0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex f be ManySortedSetPBOOLEM1-of If0 st  for i be setHIDDENM2 holds i inTARSKIR2 If0 implies f .FUNCT-1K1 i =HIDDENR1 Ff1(i)"
  proof-
    have " ex tVar25 be ManySortedSetPBOOLEM1-of If0 st  for i be setHIDDENM2 holds  not (i inTARSKIR2 If0 &  not tVar25 .FUNCT-1K1 i =HIDDENR1 Ff1(i))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 If0"and A2: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies f .FUNCT-1K1 i =HIDDENR1 Ff1(i)"
        using funct_1_sch_3 sorry
      have 
        [ty]:"f be ManySortedSetPBOOLEM1-of If0"
        using A1 partfun1_def_2 relat_1_def_18 sorry
      show " ex tVar25 be ManySortedSetPBOOLEM1-of If0 st  for i be setHIDDENM2 holds  not (i inTARSKIR2 If0 &  not tVar25 .FUNCT-1K1 i =HIDDENR1 Ff1(i))"
      proof(rule bexI[of _ "f"])
        show " for i be setHIDDENM2 holds  not (i inTARSKIR2 If0 &  not f .FUNCT-1K1 i =HIDDENR1 Ff1(i))"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

end
