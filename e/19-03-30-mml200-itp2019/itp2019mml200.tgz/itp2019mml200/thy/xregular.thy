theory xregular
  imports enumset1 xfamily
begin
(*begin*)
reserve x, y, X1, X2, X3, X4, X5, X6, Y, Y1, Y2, Y3, Y4, Y5, Z, Z1, Z2, Z3, Z4, Z5 for "setHIDDENM2"
reserve X for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mtheorem xregular_th_1:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex Y be setHIDDENM2 st Y inTARSKIR2 X & Y missesXBOOLE-0R1 X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex tVar1 be setHIDDENM2 st tVar1 inTARSKIR2 X & tVar1 missesXBOOLE-0R1 X"
  proof(rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"
      using xboole_0_def_1 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A2: "Y inTARSKIR2 X"and A3: " not ( ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y)"
      using A1 tarski_th_3 sorry
    show " ex tVar1 be setHIDDENM2 st tVar1 inTARSKIR2 X & tVar1 missesXBOOLE-0R1 X"
    proof(rule bexI[of _ "Y"])
      have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y)"
        using A3 sorry
      thus "Y inTARSKIR2 X & Y missesXBOOLE-0R1 X"
        using A2 xboole_0_th_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_2:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex Y be setHIDDENM2 st Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds Y1 inTARSKIR2 Y implies Y1 missesXBOOLE-0R1 X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  not (Y1 inTARSKIR2 Y &  not Y1 missesXBOOLE-0R1 X))))) implies  False "
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1. Lamb1 meetsXBOOLE-0R5 X"
    obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z iff Y inTARSKIR2 unionTARSKIK3 X & ?P(Y)"
      using xfamily_sch_1 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A2: "Y inTARSKIR2 X \\/XBOOLE-0K2 Z"and A3: "Y missesXBOOLE-0R1 X \\/XBOOLE-0K2 Z"
      using xregular_th_1 sorry
    assume A4: " not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  not (Y1 inTARSKIR2 Y &  not Y1 missesXBOOLE-0R1 X)))))"
    have "Y inTARSKIR2 X implies  False "
    proof(rule impI)
      assume A5: "Y inTARSKIR2 X"
      then obtain Y1 where
        [ty]:"Y1 be setHIDDENM2" and 
        A6: "Y1 inTARSKIR2 Y"and A7: " not Y1 missesXBOOLE-0R1 X"
        using A4 sorry
      have "Y1 inTARSKIR2 unionTARSKIK3 X"
        using A5 A6 tarski_def_4 sorry
      then have "Y1 inTARSKIR2 Z"
        using A1 A7 sorry
      then have "Y1 inTARSKIR2 X \\/XBOOLE-0K2 Z"
        using xboole_0_def_3 sorry
      thus " False "
        using A3 A6 xboole_0_th_3 sorry
    qed
    then have "Y inTARSKIR2 Z"
      using A2 xboole_0_def_3 sorry
    then have "Y meetsXBOOLE-0R5 X"
      using A1 sorry
    thus " False "
      using A3 xboole_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_3:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex Y be setHIDDENM2 st Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y implies Y1 missesXBOOLE-0R1 X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  not ((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X))))) implies  False "
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st Y1 inTARSKIR2 Lamb1 & Y1 meetsXBOOLE-0R5 X"
    obtain Z1 where
      [ty]:"Z1 be setHIDDENM2" and 
      A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z1 iff Y inTARSKIR2 unionTARSKIK3 X & ?P(Y)"
      using xfamily_sch_1 sorry
    let ?Q = "\<lambda>Lamb1. Lamb1 meetsXBOOLE-0R5 X"
    obtain Z2 where
      [ty]:"Z2 be setHIDDENM2" and 
      A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z2 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X) & ?Q(Y)"
      using xfamily_sch_1 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A3: "Y inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"and A4: "Y missesXBOOLE-0R1 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
      using xregular_th_1 sorry
    have A5: "Y inTARSKIR2 Z1 implies  False "
    proof(rule impI)
      assume A6: "Y inTARSKIR2 Z1"
      then obtain Y1 where
        [ty]:"Y1 be setHIDDENM2" and 
        A7: "Y1 inTARSKIR2 Y"and A8: "Y1 meetsXBOOLE-0R5 X"
        using A1 sorry
      have "Y inTARSKIR2 unionTARSKIK3 X"
        using A1 A6 sorry
      then have "Y1 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X)"
        using A7 tarski_def_4 sorry
      then have "Y1 inTARSKIR2 Z2"
        using A2 A8 sorry
      then have "Y1 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      thus " False "
        using A4 A7 xboole_0_th_3 sorry
    qed
    assume A9: " not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  not ((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X)))))"
    have A10: "Y inTARSKIR2 X implies  False "
    proof(rule impI)
      assume A11: "Y inTARSKIR2 X"
      then obtain Y1 Y2 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" and 
        A12: "Y1 inTARSKIR2 Y2"and A13: "Y2 inTARSKIR2 Y"and A14: " not Y1 missesXBOOLE-0R1 X"
        using A9 sorry
      have "Y2 inTARSKIR2 unionTARSKIK3 X"
        using A11 A13 tarski_def_4 sorry
      then have "Y2 inTARSKIR2 Z1"
        using A1 A12 A14 sorry
      then have "Y2 inTARSKIR2 X \\/XBOOLE-0K2 Z1"
        using xboole_0_def_3 sorry
      then have "Y2 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      thus " False "
        using A4 A13 xboole_0_th_3 sorry
    qed
    have "Y inTARSKIR2 X \\/XBOOLE-0K2 (Z1 \\/XBOOLE-0K2 Z2)"
      using A3 xboole_1_th_4 sorry
    then have "Y inTARSKIR2 Z1 \\/XBOOLE-0K2 Z2"
      using A10 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 Z2"
      using A5 xboole_0_def_3 sorry
    then have "Y meetsXBOOLE-0R5 X"
      using A2 sorry
    then have "Y meetsXBOOLE-0R5 X \\/XBOOLE-0K2 Z1"
      using xboole_1_th_70 sorry
    thus " False "
      using A4 xboole_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_4:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex Y be setHIDDENM2 st Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds (Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y implies Y1 missesXBOOLE-0R1 X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  not (((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X))))) implies  False "
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st  ex Y2 be setHIDDENM2 st (Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Lamb1) & Y1 meetsXBOOLE-0R5 X"
    obtain Z1 where
      [ty]:"Z1 be setHIDDENM2" and 
      A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z1 iff Y inTARSKIR2 unionTARSKIK3 X & ?P(Y)"
      using xfamily_sch_1 sorry
    let ?R = "\<lambda>Lamb1. Lamb1 meetsXBOOLE-0R5 X"
    let ?Q = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st Y1 inTARSKIR2 Lamb1 & Y1 meetsXBOOLE-0R5 X"
    obtain Z2 where
      [ty]:"Z2 be setHIDDENM2" and 
      A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z2 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X) & ?Q(Y)"
      using xfamily_sch_1 sorry
    obtain Z3 where
      [ty]:"Z3 be setHIDDENM2" and 
      A3: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z3 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X)) & ?R(Y)"
      using xfamily_sch_1 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A4: "Y inTARSKIR2 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"and A5: "Y missesXBOOLE-0R1 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
      using xregular_th_1 sorry
    have A6: "Y inTARSKIR2 Z2 implies  False "
    proof(rule impI)
      assume A7: "Y inTARSKIR2 Z2"
      then obtain Y1 where
        [ty]:"Y1 be setHIDDENM2" and 
        A8: "Y1 inTARSKIR2 Y"and A9: "Y1 meetsXBOOLE-0R5 X"
        using A2 sorry
      have "Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X)"
        using A2 A7 sorry
      then have "Y1 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))"
        using A8 tarski_def_4 sorry
      then have "Y1 inTARSKIR2 Z3"
        using A3 A9 sorry
      then have "Y1 inTARSKIR2 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_0_def_3 sorry
      thus " False "
        using A5 A8 xboole_0_th_3 sorry
    qed
    have A10: "Y inTARSKIR2 Z1 implies  False "
    proof(rule impI)
      assume A11: "Y inTARSKIR2 Z1"
      then obtain Y1 Y2 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" and 
        A12: "Y1 inTARSKIR2 Y2"and A13: "Y2 inTARSKIR2 Y"and A14: "Y1 meetsXBOOLE-0R5 X"
        using A1 sorry
      have "Y inTARSKIR2 unionTARSKIK3 X"
        using A1 A11 sorry
      then have "Y2 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X)"
        using A13 tarski_def_4 sorry
      then have "Y2 inTARSKIR2 Z2"
        using A2 A12 A14 sorry
      then have "Y2 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      then have "Y meetsXBOOLE-0R5 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using A13 xboole_0_th_3 sorry
      thus " False "
        using A5 xboole_1_th_70 sorry
    qed
    let ?V = "((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
    have A15: "?V =HIDDENR1 (X \\/XBOOLE-0K2 (Z1 \\/XBOOLE-0K2 Z2))\\/XBOOLE-0K2 Z3"
      using xboole_1_th_4 sorry
    also have "... = X \\/XBOOLE-0K2 ((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)"
      using xboole_1_th_4 sorry
    finally have "?V =HIDDENR1 X \\/XBOOLE-0K2 ((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)"
       sorry
    assume A16: " not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  not (((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X)))))"
    have "Y inTARSKIR2 X implies  False "
    proof(rule impI)
      assume A17: "Y inTARSKIR2 X"
      then obtain Y1 Y2 Y3 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" "Y3 be setHIDDENM2" and 
        A18: "Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3"and A19: "Y3 inTARSKIR2 Y"and A20: " not Y1 missesXBOOLE-0R1 X"
        using A16 sorry
      have "Y3 inTARSKIR2 unionTARSKIK3 X"
        using A17 A19 tarski_def_4 sorry
      then have "Y3 inTARSKIR2 Z1"
        using A1 A18 A20 sorry
      then have "Y3 inTARSKIR2 X \\/XBOOLE-0K2 Z1"
        using xboole_0_def_3 sorry
      then have "Y3 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      then have "Y3 inTARSKIR2 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_0_def_3 sorry
      thus " False "
        using A5 A19 xboole_0_th_3 sorry
    qed
    then have "Y inTARSKIR2 (Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
      using A15 A4 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 Z1 \\/XBOOLE-0K2 (Z2 \\/XBOOLE-0K2 Z3)"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 Z2 \\/XBOOLE-0K2 Z3"
      using A10 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 Z3"
      using A6 xboole_0_def_3 sorry
    then have "Y meetsXBOOLE-0R5 X"
      using A3 sorry
    thus " False "
      using A15 A5 xboole_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_5:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex Y be setHIDDENM2 st Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds ((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y implies Y1 missesXBOOLE-0R1 X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds  not ((((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X))))) implies  False "
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st  ex Y2 be setHIDDENM2 st  ex Y3 be setHIDDENM2 st ((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Lamb1) & Y1 meetsXBOOLE-0R5 X"
    obtain Z1 where
      [ty]:"Z1 be setHIDDENM2" and 
      A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z1 iff Y inTARSKIR2 unionTARSKIK3 X & ?P(Y)"
      using xfamily_sch_1 sorry
    let ?S = "\<lambda>Lamb1. Lamb1 meetsXBOOLE-0R5 X"
    let ?R = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st Y1 inTARSKIR2 Lamb1 & Y1 meetsXBOOLE-0R5 X"
    let ?Q = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st  ex Y2 be setHIDDENM2 st (Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Lamb1) & Y1 meetsXBOOLE-0R5 X"
    obtain Z2 where
      [ty]:"Z2 be setHIDDENM2" and 
      A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z2 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X) & ?Q(Y)"
      using xfamily_sch_1 sorry
    obtain Z4 where
      [ty]:"Z4 be setHIDDENM2" and 
      A3: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z4 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))) & ?S(Y)"
      using xfamily_sch_1 sorry
    obtain Z3 where
      [ty]:"Z3 be setHIDDENM2" and 
      A4: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z3 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X)) & ?R(Y)"
      using xfamily_sch_1 sorry
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A5: "Y inTARSKIR2 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"and A6: "Y missesXBOOLE-0R1 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
      using xregular_th_1 sorry
    have A7: "Y inTARSKIR2 Z3 implies  False "
    proof(rule impI)
      assume A8: "Y inTARSKIR2 Z3"
      then obtain Y1 where
        [ty]:"Y1 be setHIDDENM2" and 
        A9: "Y1 inTARSKIR2 Y"and A10: "Y1 meetsXBOOLE-0R5 X"
        using A4 sorry
      have "Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))"
        using A4 A8 sorry
      then have "Y1 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X)))"
        using A9 tarski_def_4 sorry
      then have "Y1 inTARSKIR2 Z4"
        using A3 A10 sorry
      then have "Y1 inTARSKIR2 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
        using xboole_0_def_3 sorry
      thus " False "
        using A6 A9 xboole_0_th_3 sorry
    qed
    have A11: "Y inTARSKIR2 Z1 implies  False "
    proof(rule impI)
      assume A12: "Y inTARSKIR2 Z1"
      then obtain Y1 Y2 Y3 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" "Y3 be setHIDDENM2" and 
        A13: "Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3"and A14: "Y3 inTARSKIR2 Y"and A15: "Y1 meetsXBOOLE-0R5 X"
        using A1 sorry
      have "Y inTARSKIR2 unionTARSKIK3 X"
        using A1 A12 sorry
      then have "Y3 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X)"
        using A14 tarski_def_4 sorry
      then have "Y3 inTARSKIR2 Z2"
        using A2 A13 A15 sorry
      then have "Y3 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      then have "Y meetsXBOOLE-0R5 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using A14 xboole_0_th_3 sorry
      then have "Y meetsXBOOLE-0R5 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_1_th_70 sorry
      thus " False "
        using A6 xboole_1_th_70 sorry
    qed
    have A16: "(((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4 =HIDDENR1 ((X \\/XBOOLE-0K2 (Z1 \\/XBOOLE-0K2 Z2))\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
      using xboole_1_th_4 sorry
    also have "... = (X \\/XBOOLE-0K2 ((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3))\\/XBOOLE-0K2 Z4"
      using xboole_1_th_4 sorry
    also have "... = X \\/XBOOLE-0K2 (((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)"
      using xboole_1_th_4 sorry
    finally have "(((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4 =HIDDENR1 X \\/XBOOLE-0K2 (((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)"
       sorry
    have A17: "Y inTARSKIR2 Z2 implies  False "
    proof(rule impI)
      assume A18: "Y inTARSKIR2 Z2"
      then obtain Y1 Y2 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" and 
        A19: "Y1 inTARSKIR2 Y2"and A20: "Y2 inTARSKIR2 Y"and A21: "Y1 meetsXBOOLE-0R5 X"
        using A2 sorry
      have "Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X)"
        using A2 A18 sorry
      then have "Y2 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))"
        using A20 tarski_def_4 sorry
      then have "Y2 inTARSKIR2 Z3"
        using A4 A19 A21 sorry
      then have "Y2 inTARSKIR2 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_0_def_3 sorry
      then have "Y meetsXBOOLE-0R5 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using A20 xboole_0_th_3 sorry
      thus " False "
        using A6 xboole_1_th_70 sorry
    qed
    assume A22: " not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds  not ((((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X)))))"
    have "Y inTARSKIR2 X implies  False "
    proof(rule impI)
      assume A23: "Y inTARSKIR2 X"
      then obtain Y1 Y2 Y3 Y4 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" "Y3 be setHIDDENM2" "Y4 be setHIDDENM2" and 
        A24: "(Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4"and A25: "Y4 inTARSKIR2 Y"and A26: " not Y1 missesXBOOLE-0R1 X"
        using A22 sorry
      have "Y4 inTARSKIR2 unionTARSKIK3 X"
        using A23 A25 tarski_def_4 sorry
      then have "Y4 inTARSKIR2 Z1"
        using A1 A24 A26 sorry
      then have "Y4 inTARSKIR2 X \\/XBOOLE-0K2 Z1"
        using xboole_0_def_3 sorry
      then have "Y4 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      then have "Y4 inTARSKIR2 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_0_def_3 sorry
      then have "Y4 inTARSKIR2 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
        using xboole_0_def_3 sorry
      thus " False "
        using A6 A25 xboole_0_th_3 sorry
    qed
    then have "Y inTARSKIR2 ((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
      using A16 A5 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 (Z1 \\/XBOOLE-0K2 (Z2 \\/XBOOLE-0K2 Z3))\\/XBOOLE-0K2 Z4"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 Z1 \\/XBOOLE-0K2 ((Z2 \\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 (Z2 \\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
      using A11 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 Z2 \\/XBOOLE-0K2 (Z3 \\/XBOOLE-0K2 Z4)"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 Z3 \\/XBOOLE-0K2 Z4"
      using A17 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 Z4"
      using A7 xboole_0_def_3 sorry
    then have "Y meetsXBOOLE-0R5 X"
      using A3 sorry
    thus " False "
      using A16 A6 xboole_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_6:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex Y be setHIDDENM2 st Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds  for Y5 be setHIDDENM2 holds (((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y5) & Y5 inTARSKIR2 Y implies Y1 missesXBOOLE-0R1 X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds  for Y5 be setHIDDENM2 holds  not (((((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y5) & Y5 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X))))) implies  False "
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st  ex Y2 be setHIDDENM2 st  ex Y3 be setHIDDENM2 st  ex Y4 be setHIDDENM2 st (((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Lamb1) & Y1 meetsXBOOLE-0R5 X"
    obtain Z1 where
      [ty]:"Z1 be setHIDDENM2" and 
      A1: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z1 iff Y inTARSKIR2 unionTARSKIK3 X & ?P(Y)"
      using xfamily_sch_1 sorry
    let ?T = "\<lambda>Lamb1. Lamb1 meetsXBOOLE-0R5 X"
    let ?S = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st Y1 inTARSKIR2 Lamb1 & Y1 meetsXBOOLE-0R5 X"
    let ?R = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st  ex Y2 be setHIDDENM2 st (Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Lamb1) & Y1 meetsXBOOLE-0R5 X"
    let ?Q = "\<lambda>Lamb1.  ex Y1 be setHIDDENM2 st  ex Y2 be setHIDDENM2 st  ex Y3 be setHIDDENM2 st ((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Lamb1) & Y1 meetsXBOOLE-0R5 X"
    obtain Z2 where
      [ty]:"Z2 be setHIDDENM2" and 
      A2: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z2 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X) & ?Q(Y)"
      using xfamily_sch_1 sorry
    obtain Z5 where
      [ty]:"Z5 be setHIDDENM2" and 
      A3: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z5 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X)))) & ?T(Y)"
      using xfamily_sch_1 sorry
    obtain Z3 where
      [ty]:"Z3 be setHIDDENM2" and 
      A4: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z3 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X)) & ?R(Y)"
      using xfamily_sch_1 sorry
    obtain Z4 where
      [ty]:"Z4 be setHIDDENM2" and 
      A5: " for Y be setHIDDENM2 holds Y inTARSKIR2 Z4 iff Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))) & ?S(Y)"
      using xfamily_sch_1 sorry
    let ?V = "((((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5"
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A6: "Y inTARSKIR2 ?V"and A7: "Y missesXBOOLE-0R1 ?V"
      using xregular_th_1 sorry
    have A8: "?V =HIDDENR1 (((X \\/XBOOLE-0K2 (Z1 \\/XBOOLE-0K2 Z2))\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5"
      using xboole_1_th_4 sorry
    also have "... = ((X \\/XBOOLE-0K2 ((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3))\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5"
      using xboole_1_th_4 sorry
    also have "... = (X \\/XBOOLE-0K2 (((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4))\\/XBOOLE-0K2 Z5"
      using xboole_1_th_4 sorry
    also have "... = X \\/XBOOLE-0K2 ((((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5)"
      using xboole_1_th_4 sorry
    finally have "?V =HIDDENR1 X \\/XBOOLE-0K2 ((((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5)"
       sorry
    have A9: "Y inTARSKIR2 Z1 implies  False "
    proof(rule impI)
      assume A10: "Y inTARSKIR2 Z1"
      then obtain Y1 Y2 Y3 Y4 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" "Y3 be setHIDDENM2" "Y4 be setHIDDENM2" and 
        A11: "(Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4"and A12: "Y4 inTARSKIR2 Y"and A13: "Y1 meetsXBOOLE-0R5 X"
        using A1 sorry
      have "Y inTARSKIR2 unionTARSKIK3 X"
        using A1 A10 sorry
      then have "Y4 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X)"
        using A12 tarski_def_4 sorry
      then have "Y4 inTARSKIR2 Z2"
        using A2 A11 A13 sorry
      then have "Y4 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      then have "Y meetsXBOOLE-0R5 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using A12 xboole_0_th_3 sorry
      then have "Y meetsXBOOLE-0R5 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_1_th_70 sorry
      then have "Y meetsXBOOLE-0R5 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
        using xboole_1_th_70 sorry
      thus " False "
        using A7 xboole_1_th_70 sorry
    qed
    have A14: "Y inTARSKIR2 Z2 implies  False "
    proof(rule impI)
      assume A15: "Y inTARSKIR2 Z2"
      then obtain Y1 Y2 Y3 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" "Y3 be setHIDDENM2" and 
        A16: "Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3"and A17: "Y3 inTARSKIR2 Y"and A18: "Y1 meetsXBOOLE-0R5 X"
        using A2 sorry
      have "Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 X)"
        using A2 A15 sorry
      then have "Y3 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))"
        using A17 tarski_def_4 sorry
      then have "Y3 inTARSKIR2 Z3"
        using A4 A16 A18 sorry
      then have "Y3 inTARSKIR2 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_0_def_3 sorry
      then have "Y3 inTARSKIR2 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
        using xboole_0_def_3 sorry
      then have "Y3 inTARSKIR2 ?V"
        using xboole_0_def_3 sorry
      thus " False "
        using A7 A17 xboole_0_th_3 sorry
    qed
    have A19: "Y inTARSKIR2 Z3 implies  False "
    proof(rule impI)
      assume A20: "Y inTARSKIR2 Z3"
      then obtain Y1 Y2 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" and 
        A21: "Y1 inTARSKIR2 Y2"and A22: "Y2 inTARSKIR2 Y"and A23: "Y1 meetsXBOOLE-0R5 X"
        using A4 sorry
      have "Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))"
        using A4 A20 sorry
      then have "Y2 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X)))"
        using A22 tarski_def_4 sorry
      then have "Y2 inTARSKIR2 Z4"
        using A5 A21 A23 sorry
      then have "Y2 inTARSKIR2 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
        using xboole_0_def_3 sorry
      then have "Y2 inTARSKIR2 ?V"
        using xboole_0_def_3 sorry
      thus " False "
        using A7 A22 xboole_0_th_3 sorry
    qed
    have A24: "Y inTARSKIR2 Z4 implies  False "
    proof(rule impI)
      assume A25: "Y inTARSKIR2 Z4"
      then obtain Y1 where
        [ty]:"Y1 be setHIDDENM2" and 
        A26: "Y1 inTARSKIR2 Y"and A27: "Y1 meetsXBOOLE-0R5 X"
        using A5 sorry
      have "Y inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X)))"
        using A5 A25 sorry
      then have "Y1 inTARSKIR2 unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 (unionTARSKIK3 X))))"
        using A26 tarski_def_4 sorry
      then have "Y1 inTARSKIR2 Z5"
        using A3 A27 sorry
      then have "Y1 inTARSKIR2 ?V"
        using xboole_0_def_3 sorry
      thus " False "
        using A7 A26 xboole_0_th_3 sorry
    qed
    assume A28: " not ( not ( for Y be setHIDDENM2 holds  not (Y inTARSKIR2 X & ( for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds  for Y5 be setHIDDENM2 holds  not (((((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y5) & Y5 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X)))))"
    have "Y inTARSKIR2 X implies  False "
    proof(rule impI)
      assume A29: "Y inTARSKIR2 X"
      then obtain Y1 Y2 Y3 Y4 Y5 where
        [ty]:"Y1 be setHIDDENM2" "Y2 be setHIDDENM2" "Y3 be setHIDDENM2" "Y4 be setHIDDENM2" "Y5 be setHIDDENM2" and 
        A30: "((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y5"and A31: "Y5 inTARSKIR2 Y"and A32: " not Y1 missesXBOOLE-0R1 X"
        using A28 sorry
      have "Y5 inTARSKIR2 unionTARSKIK3 X"
        using A29 A31 tarski_def_4 sorry
      then have "Y5 inTARSKIR2 Z1"
        using A1 A30 A32 sorry
      then have "Y5 inTARSKIR2 X \\/XBOOLE-0K2 Z1"
        using xboole_0_def_3 sorry
      then have "Y5 inTARSKIR2 (X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2"
        using xboole_0_def_3 sorry
      then have "Y5 inTARSKIR2 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using xboole_0_def_3 sorry
      then have "Y meetsXBOOLE-0R5 ((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3"
        using A31 xboole_0_th_3 sorry
      then have "Y meetsXBOOLE-0R5 (((X \\/XBOOLE-0K2 Z1)\\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4"
        using xboole_1_th_70 sorry
      thus " False "
        using A7 xboole_1_th_70 sorry
    qed
    then have "Y inTARSKIR2 (((Z1 \\/XBOOLE-0K2 Z2)\\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5"
      using A8 A6 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 ((Z1 \\/XBOOLE-0K2 (Z2 \\/XBOOLE-0K2 Z3))\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 (Z1 \\/XBOOLE-0K2 ((Z2 \\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4))\\/XBOOLE-0K2 Z5"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 Z1 \\/XBOOLE-0K2 (((Z2 \\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5)"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 ((Z2 \\/XBOOLE-0K2 Z3)\\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5"
      using A9 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 (Z2 \\/XBOOLE-0K2 (Z3 \\/XBOOLE-0K2 Z4))\\/XBOOLE-0K2 Z5"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 Z2 \\/XBOOLE-0K2 ((Z3 \\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5)"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 (Z3 \\/XBOOLE-0K2 Z4)\\/XBOOLE-0K2 Z5"
      using A14 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 Z3 \\/XBOOLE-0K2 (Z4 \\/XBOOLE-0K2 Z5)"
      using xboole_1_th_4 sorry
    then have "Y inTARSKIR2 Z4 \\/XBOOLE-0K2 Z5"
      using A19 xboole_0_def_3 sorry
    then have "Y inTARSKIR2 Z5"
      using A24 xboole_0_def_3 sorry
    then have "Y meetsXBOOLE-0R5 X"
      using A3 sorry
    thus " False "
      using A8 A7 xboole_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_7:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  not ((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X1)"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  not ((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    have A1: "X2 inTARSKIR2 {ENUMSET1K1 X1,X2,X3 } & X3 inTARSKIR2 {ENUMSET1K1 X1,X2,X3 }"
      using enumset1_def_1 sorry
    have A2: "X1 inTARSKIR2 {ENUMSET1K1 X1,X2,X3 }"
      using enumset1_def_1 sorry
    then obtain T where
      [ty]:"T be setHIDDENM2" and 
      A3: "T inTARSKIR2 {ENUMSET1K1 X1,X2,X3 }"and A4: "{ENUMSET1K1 X1,X2,X3 } missesXBOOLE-0R1 T"
      using xregular_th_1 sorry
    have "(T =XBOOLE-0R4 X1 or T =XBOOLE-0R4 X2) or T =XBOOLE-0R4 X3"
      using A3 enumset1_def_1 sorry
    thus " not ((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X1)"
      using A2 A1 A4 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_8:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  not (((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X4) & X4 inTARSKIR2 X1)"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  not (((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X4) & X4 inTARSKIR2 X1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    have A1: "X2 inTARSKIR2 {ENUMSET1K2 X1,X2,X3,X4 } & X3 inTARSKIR2 {ENUMSET1K2 X1,X2,X3,X4 }"
      using enumset1_def_2 sorry
    have A2: "X4 inTARSKIR2 {ENUMSET1K2 X1,X2,X3,X4 }"
      using enumset1_def_2 sorry
    have A3: "X1 inTARSKIR2 {ENUMSET1K2 X1,X2,X3,X4 }"
      using enumset1_def_2 sorry
    then obtain T where
      [ty]:"T be setHIDDENM2" and 
      A4: "T inTARSKIR2 {ENUMSET1K2 X1,X2,X3,X4 }"and A5: "{ENUMSET1K2 X1,X2,X3,X4 } missesXBOOLE-0R1 T"
      using xregular_th_1 sorry
    have "((T =XBOOLE-0R4 X1 or T =XBOOLE-0R4 X2) or T =XBOOLE-0R4 X3) or T =XBOOLE-0R4 X4"
      using A4 enumset1_def_2 sorry
    thus " not (((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X4) & X4 inTARSKIR2 X1)"
      using A3 A1 A2 A5 xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_9:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for X5 be setHIDDENM2 holds  not ((((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X4) & X4 inTARSKIR2 X5) & X5 inTARSKIR2 X1)"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for X5 be setHIDDENM2 holds X1 inTARSKIR2 X2 & (X2 inTARSKIR2 X3 & (X3 inTARSKIR2 X4 & (X4 inTARSKIR2 X5 & X5 inTARSKIR2 X1))) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    fix X5 assume [ty]: "X5 be setHIDDENM2"
    assume A1: "X1 inTARSKIR2 X2"
      and A2: "X2 inTARSKIR2 X3"
      and A3: "X3 inTARSKIR2 X4"
      and A4: "X4 inTARSKIR2 X5"
      and A5: "X5 inTARSKIR2 X1"
    let ?Z = "{ENUMSET1K3 X1,X2,X3,X4,X5 }"
    have A6: " for Y be setHIDDENM2 holds Y inTARSKIR2 ?Z implies ?Z meetsXBOOLE-0R5 Y"
    proof-
      have " for Y be setHIDDENM2 holds Y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } implies  not {ENUMSET1K3 X1,X2,X3,X4,X5 } meetsXBOOLE-0R5 Y"
      proof(rule ballI,rule impI)
        fix Y assume [ty]: "Y be setHIDDENM2"
        assume A7: "Y inTARSKIR2 ?Z"
        have " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
        proof-
          show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
          proof-
            have cases: "(((Y =XBOOLE-0R4 X1 or Y =XBOOLE-0R4 X2) or Y =XBOOLE-0R4 X3) or Y =XBOOLE-0R4 X4) or Y =XBOOLE-0R4 X5"
              using A7 enumset1_def_3 sorry
            have case1: "Y =XBOOLE-0R4 X1 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A8: "Y =XBOOLE-0R4 X1"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X5"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
                  using A5 A8 enumset1_def_3 sorry
              qed "sorry"
            qed
            have case2: "Y =XBOOLE-0R4 X2 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A9: "Y =XBOOLE-0R4 X2"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X1"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
                  using A1 A9 enumset1_def_3 sorry
              qed "sorry"
            qed
            have case3: "Y =XBOOLE-0R4 X3 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A10: "Y =XBOOLE-0R4 X3"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X2"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
                  using A2 A10 enumset1_def_3 sorry
              qed "sorry"
            qed
            have case4: "Y =XBOOLE-0R4 X4 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A11: "Y =XBOOLE-0R4 X4"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X3"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
                  using A3 A11 enumset1_def_3 sorry
              qed "sorry"
            qed
            have case5: "Y =XBOOLE-0R4 X5 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A12: "Y =XBOOLE-0R4 X5"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X4"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 } & y inTARSKIR2 Y"
                  using A4 A12 enumset1_def_3 sorry
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 case5 sorry
          qed
        qed
        thus " not {ENUMSET1K3 X1,X2,X3,X4,X5 } meetsXBOOLE-0R5 Y"
          using xboole_0_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "X1 inTARSKIR2 {ENUMSET1K3 X1,X2,X3,X4,X5 }"
      using enumset1_def_3 sorry
    thus " False "
      using A6 xregular_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xregular_th_10:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for X5 be setHIDDENM2 holds  for X6 be setHIDDENM2 holds  not (((((X1 inTARSKIR2 X2 & X2 inTARSKIR2 X3) & X3 inTARSKIR2 X4) & X4 inTARSKIR2 X5) & X5 inTARSKIR2 X6) & X6 inTARSKIR2 X1)"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for X5 be setHIDDENM2 holds  for X6 be setHIDDENM2 holds X1 inTARSKIR2 X2 & (X2 inTARSKIR2 X3 & (X3 inTARSKIR2 X4 & (X4 inTARSKIR2 X5 & (X5 inTARSKIR2 X6 & X6 inTARSKIR2 X1)))) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    fix X5 assume [ty]: "X5 be setHIDDENM2"
    fix X6 assume [ty]: "X6 be setHIDDENM2"
    assume A1: "X1 inTARSKIR2 X2"
      and A2: "X2 inTARSKIR2 X3"
      and A3: "X3 inTARSKIR2 X4"
      and A4: "X4 inTARSKIR2 X5"
      and A5: "X5 inTARSKIR2 X6"
      and A6: "X6 inTARSKIR2 X1"
    let ?Z = "{ENUMSET1K4 X1,X2,X3,X4,X5,X6 }"
    have A7: " for Y be setHIDDENM2 holds Y inTARSKIR2 ?Z implies ?Z meetsXBOOLE-0R5 Y"
    proof-
      have " for Y be setHIDDENM2 holds Y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } implies  not {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } meetsXBOOLE-0R5 Y"
      proof(rule ballI,rule impI)
        fix Y assume [ty]: "Y be setHIDDENM2"
        assume A8: "Y inTARSKIR2 ?Z"
        have " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
        proof-
          show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
          proof-
            have cases: "((((Y =XBOOLE-0R4 X1 or Y =XBOOLE-0R4 X2) or Y =XBOOLE-0R4 X3) or Y =XBOOLE-0R4 X4) or Y =XBOOLE-0R4 X5) or Y =XBOOLE-0R4 X6"
              using A8 enumset1_def_4 sorry
            have case1: "Y =XBOOLE-0R4 X1 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A9: "Y =XBOOLE-0R4 X1"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X6"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
                  using A6 A9 enumset1_def_4 sorry
              qed "sorry"
            qed
            have case2: "Y =XBOOLE-0R4 X2 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A10: "Y =XBOOLE-0R4 X2"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X1"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
                  using A1 A10 enumset1_def_4 sorry
              qed "sorry"
            qed
            have case3: "Y =XBOOLE-0R4 X3 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A11: "Y =XBOOLE-0R4 X3"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X2"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
                  using A2 A11 enumset1_def_4 sorry
              qed "sorry"
            qed
            have case4: "Y =XBOOLE-0R4 X4 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A12: "Y =XBOOLE-0R4 X4"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X3"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
                  using A3 A12 enumset1_def_4 sorry
              qed "sorry"
            qed
            have case5: "Y =XBOOLE-0R4 X5 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A13: "Y =XBOOLE-0R4 X5"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X4"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
                  using A4 A13 enumset1_def_4 sorry
              qed "sorry"
            qed
            have case6: "Y =XBOOLE-0R4 X6 implies ( ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y)"
            proof(rule impI)
              assume A14: "Y =XBOOLE-0R4 X6"
              obtain y where 
                [ty]:"y be setHIDDENM2" and yDef:"y = X5"
                 sorry
              show " ex y be setHIDDENM2 st y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
              proof(rule bexI[of _ "y"])
                show "y inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } & y inTARSKIR2 Y"
                  using A5 A14 enumset1_def_4 sorry
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 case5 case6 sorry
          qed
        qed
        thus " not {ENUMSET1K4 X1,X2,X3,X4,X5,X6 } meetsXBOOLE-0R5 Y"
          using xboole_0_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "X1 inTARSKIR2 {ENUMSET1K4 X1,X2,X3,X4,X5,X6 }"
      using enumset1_def_4 sorry
    thus " False "
      using A7 xregular_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
