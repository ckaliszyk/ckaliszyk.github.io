theory seq_2
  imports seq_1 comseq_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, n1, n2, m for "NatNAT-1M1"
reserve r, r1, r2, p, g1, g2, g for "RealXREAL-0M1"
reserve seq, seq9, seq1 for "Real-SequenceSEQ-1M1"
reserve y for "setHIDDENM2"
mtheorem seq_2_th_1:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds -XCMPLX-0K4 g <XXREAL-0R3 r & r <XXREAL-0R3 g iff  |.COMPLEX1K10 r.| <XXREAL-0R3 g"
proof-
  have " for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds (-XCMPLX-0K4 g <XXREAL-0R3 r & r <XXREAL-0R3 g implies  |.COMPLEX1K10 r.| <XXREAL-0R3 g) & ( |.COMPLEX1K10 r.| <XXREAL-0R3 g implies -XCMPLX-0K4 g <XXREAL-0R3 r &  not r <XXREAL-0R3 g)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    show "-XCMPLX-0K4 g <XXREAL-0R3 r & r <XXREAL-0R3 g implies  |.COMPLEX1K10 r.| <XXREAL-0R3 g"
    proof-
      have "-XCMPLX-0K4 g <XXREAL-0R3 r & r <XXREAL-0R3 g implies  not  |.COMPLEX1K10 r.| <XXREAL-0R3 g"
      proof(rule impMI ,rule impI)
        assume A1: "-XCMPLX-0K4 g <XXREAL-0R3 r"
          and A2: "r <XXREAL-0R3 g"
        have A3: " |.COMPLEX1K10 r.| <=XXREAL-0R1 g"
          using A1 A2 absvalue_th_5 sorry
        have " |.COMPLEX1K10 r.| =COMPLEX1R1 g implies  False "
        proof(rule impI)
          assume A4: " |.COMPLEX1K10 r.| =COMPLEX1R1 g"
          have "r <XXREAL-0R3 0NUMBERSK6 implies  False "
          proof(rule impI)
            assume "r <XXREAL-0R3 0NUMBERSK6"
            then have "g =COMPLEX1R1 -XCMPLX-0K4 r"
              using A4 absvalue_def_1 sorry
            thus " False "
              using A1 sorry
          qed
          thus " False "
            using A2 A4 absvalue_def_1 sorry
        qed
        thus " not  |.COMPLEX1K10 r.| <XXREAL-0R3 g"
          using A3 xxreal_0_th_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: " |.COMPLEX1K10 r.| <XXREAL-0R3 g"
    then have A6: "-XCMPLX-0K4 g <=XXREAL-0R1 r"
      using absvalue_th_5 sorry
    have A7: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r.|"
      using complex1_th_46 sorry
    have A8: "0NUMBERSK6 <XXREAL-0R3 g"
      using A5 complex1_th_46 sorry
    have A9: "-XCMPLX-0K4 g <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
      using A5 A7 sorry
    have "r =COMPLEX1R1 -XCMPLX-0K4 g implies  False "
    proof(rule impI)
      assume "r =COMPLEX1R1 -XCMPLX-0K4 g"
      then have " |.COMPLEX1K10 r.| =HIDDENR1 -XCMPLX-0K4 (-XCMPLX-0K4 g)"
        using A9 absvalue_def_1 sorry
      also have "... = g"
         sorry
      finally have " |.COMPLEX1K10 r.| =HIDDENR1 g"
         sorry
      thus " False "
        using A5 sorry
    qed
    thus "-XCMPLX-0K4 g <XXREAL-0R3 r"
      using A6 xxreal_0_th_1 sorry
    show " not r <XXREAL-0R3 g"
      using A5 A8 absvalue_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_2:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds g <>HIDDENR2 0NUMBERSK6 & r <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 g \<inverse>XCMPLX-0K5 -XCMPLX-0K6 r \<inverse>XCMPLX-0K5 .| =COMPLEX1R1 ( |.COMPLEX1K10 g -XCMPLX-0K6 r .|)/XCMPLX-0K7 (( |.COMPLEX1K10 g.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|))"
proof-
  have " for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds g <>HIDDENR2 0NUMBERSK6 & r <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 g \<inverse>XCMPLX-0K5 -XCMPLX-0K6 r \<inverse>XCMPLX-0K5 .| =HIDDENR1 ( |.COMPLEX1K10 g -XCMPLX-0K6 r .|)/XCMPLX-0K7 (( |.COMPLEX1K10 g.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    assume A1: "g <>HIDDENR2 0NUMBERSK6"
      and A2: "r <>HIDDENR2 0NUMBERSK6"
    have " |.COMPLEX1K10 g \<inverse>XCMPLX-0K5 -XCMPLX-0K6 r \<inverse>XCMPLX-0K5 .| =HIDDENR1  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 g -XCMPLX-0K6 r \<inverse>XCMPLX-0K5 .|"
      using xcmplx_1_th_215 sorry
    also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 g -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 r .|"
      using xcmplx_1_th_215 sorry
    also have "... =  |.COMPLEX1K10 (\<one>\<^sub>M *XCMPLX-0K3 r -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 g)/XCMPLX-0K7 (g *XCMPLX-0K3 r) .|"
      using A1 A2 xcmplx_1_th_130 sorry
    also have "... = ( |.COMPLEX1K10 r -XCMPLX-0K6 g .|)/XCMPLX-0K7 ( |.COMPLEX1K10 g *XCMPLX-0K3 r .|)"
      using complex1_th_67 sorry
    also have "... = ( |.COMPLEX1K10 -XCMPLX-0K4 (g -XCMPLX-0K6 r) .|)/XCMPLX-0K7 (( |.COMPLEX1K10 g.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|))"
      using complex1_th_65 sorry
    also have "... = ( |.COMPLEX1K10 g -XCMPLX-0K6 r .|)/XCMPLX-0K7 (( |.COMPLEX1K10 g.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|))"
      using complex1_th_52 sorry
    finally show " |.COMPLEX1K10 g \<inverse>XCMPLX-0K5 -XCMPLX-0K6 r \<inverse>XCMPLX-0K5 .| =HIDDENR1 ( |.COMPLEX1K10 g -XCMPLX-0K6 r .|)/XCMPLX-0K7 (( |.COMPLEX1K10 g.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_2_def_1 ("bounded-aboveSEQ-2V1" 70 ) where
"attr bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  ex r be RealXREAL-0M1 st  for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 y <XXREAL-0R3 r)"..

mdef seq_2_def_2 ("bounded-belowSEQ-2V2" 70 ) where
"attr bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f.  ex r be RealXREAL-0M1 st  for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies r <XXREAL-0R3 f .FUNCT-1K1 y)"..

abbreviation(input) SEQ_2V3("bounded-aboveSEQ-2V3" 70) where
  "bounded-aboveSEQ-2V3 \<equiv> bounded-aboveSEQ-2V1"

mtheorem seq_2_def_3:
  mlet "seq be Real-SequenceSEQ-1M1"
"redefine attr bounded-aboveSEQ-2V3 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq.  ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r)"
proof
(*compatibility*)
  show " for seq be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 iff ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have A1: "domRELAT-1K1 seq =HIDDENR1 NATNUMBERSK1"
      using seq_1_th_1 sorry
    show "seq be bounded-aboveSEQ-2V3 iff ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r)"
    proof-
      have "(seq be bounded-aboveSEQ-2V1 implies ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r)) & (( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r) implies seq be bounded-aboveSEQ-2V1)"
      proof(rule conjMI,rule impI)
        show "seq be bounded-aboveSEQ-2V1 implies ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r)"
        proof-
          have " not (seq be bounded-aboveSEQ-2V1 & ( for r be RealXREAL-0M1 holds  not ( for n be NatNAT-1M1 holds  not seq .FUNCT-1K1 n <XXREAL-0R3 r)))"
          proof-
            have "( ex r be RealXREAL-0M1 st  for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies seq .FUNCT-1K1 y <XXREAL-0R3 r) implies ( ex tVar1 be RealXREAL-0M1 st  for n be NatNAT-1M1 holds  not seq .FUNCT-1K1 n <XXREAL-0R3 tVar1)"
            proof(rule impI)
              assume Given: " ex r be RealXREAL-0M1 st  for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies seq .FUNCT-1K1 y <XXREAL-0R3 r"
              then obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A2: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies seq .FUNCT-1K1 y <XXREAL-0R3 r"
                 sorry
              show " ex tVar1 be RealXREAL-0M1 st  for n be NatNAT-1M1 holds  not seq .FUNCT-1K1 n <XXREAL-0R3 tVar1"
              proof(rule bexI[of _ "r"],rule ballI)
                fix n assume [ty]: "n be NatNAT-1M1"
                have "n inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                thus " not seq .FUNCT-1K1 n <XXREAL-0R3 r"
                  using A1 A2 sorry
              qed "sorry"
            qed
            thus " not (seq be bounded-aboveSEQ-2V1 & ( for r be RealXREAL-0M1 holds  not ( for n be NatNAT-1M1 holds  not seq .FUNCT-1K1 n <XXREAL-0R3 r)))"
              using seq_2_def_1 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r"
        then obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A3: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r"
           sorry
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies  not seq .FUNCT-1K1 y <XXREAL-0R3 r"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 domRELAT-1K1 seq"
          thus " not seq .FUNCT-1K1 y <XXREAL-0R3 r"
            using A3 sorry
        qed "sorry"
        thus "seq be bounded-aboveSEQ-2V1"
          using bexI[of _ "r"] seq_2_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) SEQ_2V4("bounded-belowSEQ-2V4" 70) where
  "bounded-belowSEQ-2V4 \<equiv> bounded-belowSEQ-2V2"

mtheorem seq_2_def_4:
  mlet "seq be Real-SequenceSEQ-1M1"
"redefine attr bounded-belowSEQ-2V4 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq.  ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n)"
proof
(*compatibility*)
  show " for seq be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 iff ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    have A1: "domRELAT-1K1 seq =HIDDENR1 NATNUMBERSK1"
      using seq_1_th_1 sorry
    show "seq be bounded-belowSEQ-2V4 iff ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n)"
    proof-
      have "(seq be bounded-belowSEQ-2V2 implies ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n)) & (( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n) implies seq be bounded-belowSEQ-2V2)"
      proof(rule conjMI,rule impI)
        show "seq be bounded-belowSEQ-2V2 implies ( ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n)"
        proof-
          have " not (seq be bounded-belowSEQ-2V2 & ( for r be RealXREAL-0M1 holds  not ( for n be NatNAT-1M1 holds  not r <XXREAL-0R3 seq .FUNCT-1K1 n)))"
          proof-
            have "( ex r be RealXREAL-0M1 st  for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies r <XXREAL-0R3 seq .FUNCT-1K1 y) implies ( ex tVar3 be RealXREAL-0M1 st  for n be NatNAT-1M1 holds  not tVar3 <XXREAL-0R3 seq .FUNCT-1K1 n)"
            proof(rule impI)
              assume Given: " ex r be RealXREAL-0M1 st  for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies r <XXREAL-0R3 seq .FUNCT-1K1 y"
              then obtain r where
                [ty]:"r be RealXREAL-0M1" and 
                A4: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies r <XXREAL-0R3 seq .FUNCT-1K1 y"
                 sorry
              show " ex tVar3 be RealXREAL-0M1 st  for n be NatNAT-1M1 holds  not tVar3 <XXREAL-0R3 seq .FUNCT-1K1 n"
              proof(rule bexI[of _ "r"],rule ballI)
                fix n assume [ty]: "n be NatNAT-1M1"
                have "n inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                thus " not r <XXREAL-0R3 seq .FUNCT-1K1 n"
                  using A1 A4 sorry
              qed "sorry"
            qed
            thus " not (seq be bounded-belowSEQ-2V2 & ( for r be RealXREAL-0M1 holds  not ( for n be NatNAT-1M1 holds  not r <XXREAL-0R3 seq .FUNCT-1K1 n)))"
              using seq_2_def_2 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex r be RealXREAL-0M1 st  for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n"
        then obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A5: " for n be NatNAT-1M1 holds r <XXREAL-0R3 seq .FUNCT-1K1 n"
           sorry
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 seq implies  not r <XXREAL-0R3 seq .FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 domRELAT-1K1 seq"
          thus " not r <XXREAL-0R3 seq .FUNCT-1K1 y"
            using A5 sorry
        qed "sorry"
        thus "seq be bounded-belowSEQ-2V2"
          using bexI[of _ "r"] seq_2_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem seq_2_cl_1:
"cluster boundedCOMSEQ-2V1 also-is bounded-aboveSEQ-2V1\<bar>bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it be boundedCOMSEQ-2V1 implies it be bounded-aboveSEQ-2V1\<bar>bounded-belowSEQ-2V2"
  proof-
    have " for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (f be boundedCOMSEQ-2V1 &  not (f be bounded-aboveSEQ-2V1 & f be bounded-belowSEQ-2V2))"
    proof(rule ballI)
      fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
      have "( ex r be RealXREAL-0M1 st  for y be setHIDDENM2 holds y inTARSKIR2 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 r) implies f be bounded-aboveSEQ-2V1 & f be bounded-belowSEQ-2V2"
      proof(rule impI,rule conjMI)
        assume Given: " ex r be RealXREAL-0M1 st  for y be setHIDDENM2 holds y inTARSKIR2 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 r"
        then obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A1: " for y be setHIDDENM2 holds y inTARSKIR2 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 r"
           sorry
        show "f be bounded-aboveSEQ-2V1"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies  not f .FUNCT-1K1 y <XXREAL-0R3 r"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            have A2: "f .FUNCT-1K1 y <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 y.|"
              using absvalue_th_4 sorry
            assume "y inHIDDENR3 domRELAT-1K1 f"
            thus " not f .FUNCT-1K1 y <XXREAL-0R3 r"
              using A1 A2 xxreal_0_th_2 sorry
          qed "sorry"
          thus "f be bounded-aboveSEQ-2V1"
            using bexI[of _ "r"] seq_2_def_1 sorry
        qed
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies  not -XCMPLX-0K4  |.COMPLEX1K10 r.| <XXREAL-0R3 f .FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          have A3: "-XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 y.| <=XXREAL-0R1 f .FUNCT-1K1 y"
            using absvalue_th_4 sorry
          have "r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
            using absvalue_th_4 sorry
          then have A4: "-XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 -XCMPLX-0K4 r"
            using xreal_1_th_24 sorry
          assume "y inHIDDENR3 domRELAT-1K1 f"
          then have " |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 r"
            using A1 sorry
          then have "-XCMPLX-0K4 r <XXREAL-0R3 -XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 y.|"
            using xreal_1_th_24 sorry
          then have "-XCMPLX-0K4  |.COMPLEX1K10 r.| <XXREAL-0R3 -XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 y.|"
            using A4 xxreal_0_th_2 sorry
          thus " not -XCMPLX-0K4  |.COMPLEX1K10 r.| <XXREAL-0R3 f .FUNCT-1K1 y"
            using A3 xxreal_0_th_2 sorry
        qed "sorry"
        thus "f be bounded-belowSEQ-2V2"
          using bexI[of _ "-XCMPLX-0K4  |.COMPLEX1K10 r.|"] seq_2_def_2 sorry
      qed
      thus " not (f be boundedCOMSEQ-2V1 &  not (f be bounded-aboveSEQ-2V1 & f be bounded-belowSEQ-2V2))"
        using comseq_2_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_2_cl_2:
"cluster bounded-aboveSEQ-2V1\<bar>bounded-belowSEQ-2V2 also-is boundedCOMSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it be bounded-aboveSEQ-2V1\<bar>bounded-belowSEQ-2V2 implies it be boundedCOMSEQ-2V1"
  proof-
    have " for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be bounded-aboveSEQ-2V1 implies (f be bounded-belowSEQ-2V2 implies f be boundedCOMSEQ-2V1)"
    proof(rule ballI,rule impI,rule impI)
      fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
      assume "f be bounded-aboveSEQ-2V1"
      then obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A5: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 y <XXREAL-0R3 r1"
         sorry
      assume "f be bounded-belowSEQ-2V2"
      then obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A6: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies r2 <XXREAL-0R3 f .FUNCT-1K1 y"
         sorry
      obtain g where 
        [ty]:"g be setHIDDENM2" and gDef:"g = ( |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|)+XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      have " ex g be setHIDDENM2 st  for y be setHIDDENM2 holds y inTARSKIR2 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 g"
      proof(rule bexI[of _ "g"],rule ballI,rule impI)
        have A7: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
          using complex1_th_46 sorry
        fix y assume [ty]: "y be setHIDDENM2"
        assume A8: "y inTARSKIR2 domRELAT-1K1 f"
        have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
          using absvalue_th_4 sorry
        then have "f .FUNCT-1K1 y <XXREAL-0R3  |.COMPLEX1K10 r1.|"
          using A5 A8 xxreal_0_th_2 sorry
        then have "f .FUNCT-1K1 y +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|"
          using complex1_th_46 xreal_1_th_8 sorry
        then have A9: "f .FUNCT-1K1 y <XXREAL-0R3 g"
          using xreal_1_th_8 sorry
        have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 r2"
          using absvalue_th_4 sorry
        then have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <XXREAL-0R3 f .FUNCT-1K1 y"
          using A6 A8 xxreal_0_th_2 sorry
        then have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)+XCMPLX-0K2 (-XCMPLX-0K4  |.COMPLEX1K10 r2.|) <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 f .FUNCT-1K1 y"
          using A7 xreal_1_th_8 sorry
        then have A10: "((-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r2.|)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 f .FUNCT-1K1 y +XCMPLX-0K2 0NUMBERSK6"
          using xreal_1_th_8 sorry
        have "((-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 -XCMPLX-0K4 g"
           sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 y.| <XXREAL-0R3 g"
          using A9 A10 seq_2_th_1 sorry
      qed "sorry"
      thus "f be boundedCOMSEQ-2V1"
        using comseq_2_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_2_th_3:
" for seq be Real-SequenceSEQ-1M1 holds seq be boundedCOMSEQ-2V1 iff ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be boundedCOMSEQ-2V1 implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r))) & (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r)) implies seq be boundedCOMSEQ-2V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be boundedCOMSEQ-2V1 implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r))"
    proof-
      have "seq be boundedCOMSEQ-2V1 implies ( ex g be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 g & ( for n be NatNAT-1M1 holds  not  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 g))"
      proof(rule impI)
        assume A1: "seq be boundedCOMSEQ-2V1"
        then obtain r1 where
          [ty]:"r1 be RealXREAL-0M1" and 
          A2: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <XXREAL-0R3 r1"
          using seq_2_def_3 sorry
        obtain r2 where
          [ty]:"r2 be RealXREAL-0M1" and 
          A3: " for n be NatNAT-1M1 holds r2 <XXREAL-0R3 seq .FUNCT-1K1 n"
          using A1 seq_2_def_4 sorry
        obtain g where 
          [ty]:"g be setHIDDENM2" and gDef:"g = ( |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex g be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 g & ( for n be NatNAT-1M1 holds  not  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 g)"
        proof(rule bexI[of _ "g"],rule conjMI,rule ballI)
          have A4: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using complex1_th_46 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r2.|"
            using complex1_th_46 sorry
          thus "0NUMBERSK6 <XXREAL-0R3 g"
            using A4 sorry
          fix n assume [ty]: "n be NatNAT-1M1"
          have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 sorry
          then have "seq .FUNCT-1K1 n <XXREAL-0R3  |.COMPLEX1K10 r1.|"
            using A2 xxreal_0_th_2 sorry
          then have "seq .FUNCT-1K1 n +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|"
            using complex1_th_46 xreal_1_th_8 sorry
          then have A5: "seq .FUNCT-1K1 n <XXREAL-0R3 g"
            using xreal_1_th_8 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 r2"
            using absvalue_th_4 sorry
          then have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <XXREAL-0R3 seq .FUNCT-1K1 n"
            using A3 xxreal_0_th_2 sorry
          then have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)+XCMPLX-0K2 (-XCMPLX-0K4  |.COMPLEX1K10 r2.|) <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 seq .FUNCT-1K1 n"
            using A4 xreal_1_th_8 sorry
          then have A6: "((-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r2.|)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 seq .FUNCT-1K1 n +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          have "((-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r2.|)-XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 -XCMPLX-0K4 g"
             sorry
          thus " not  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 g"
            using A5 A6 seq_2_th_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r)"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      "0NUMBERSK6 <XXREAL-0R3 r"and A7: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r"
       sorry
    have " for y be setHIDDENM2 holds y inTARSKIR2 domRELAT-1K1 seq implies  not r <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 y.|"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be setHIDDENM2"
      assume "y inTARSKIR2 domRELAT-1K1 seq"
      then have "y be ElementSUBSET-1M1-of NATNUMBERSK1"
        using funct_2_def_1 sorry
      thus " not r <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 y.|"
        using A7 sorry
    qed "sorry"
    thus "seq be boundedCOMSEQ-2V1"
      using bexI[of _ "r"] comseq_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_4:
" for seq be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds  ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for n be NatNAT-1M1 holds  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r1 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1.  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r1 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 Lamb1 implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1)"
    have A1: "?X(0NUMBERSK6)"
    proof-
      have " ex tVar10 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar10 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 0NUMBERSK6 implies  not  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 tVar10)"
      proof-
        obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r =  |.COMPLEX1K10 seq .FUNCT-1K1 (0NUMBERSK6).| +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex tVar10 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar10 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 0NUMBERSK6 implies  not  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 tVar10)"
        proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
          have "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 (0NUMBERSK6).| +XCMPLX-0K2 \<one>\<^sub>M"
            using complex1_th_46 xreal_1_th_8 sorry
          thus "0NUMBERSK6 <XXREAL-0R3 r"
             sorry
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "m <=XXREAL-0R1 0NUMBERSK6"
          then have "0NUMBERSK6 =COMPLEX1R1 m"
             sorry
          then have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r"
            using xreal_1_th_8 sorry
          thus " not  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r1 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1)) implies ( ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r1 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1))"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume Given: " ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r1 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1)"
        then obtain r1 where
          [ty]:"r1 be RealXREAL-0M1" and 
          A3: "0NUMBERSK6 <XXREAL-0R3 r1"and A4: " for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1"
           sorry
        have A5: " |.COMPLEX1K10 seq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 r1 implies ( ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r))"
        proof(rule impI)
          assume A6: " |.COMPLEX1K10 seq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 r1"
          obtain r where 
            [ty]:"r be setHIDDENM2" and rDef:"r = r1 +XCMPLX-0K2 \<one>\<^sub>M"
             sorry
          show " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r)"
          proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
            show "0NUMBERSK6 <XXREAL-0R3 r"
              using A3 sorry
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A7: "m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
            have A8: "m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
            proof(rule impI)
              assume "m <=XXREAL-0R1 n"
              then have A9: " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1"
                using A4 sorry
              have "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r"
                using xreal_1_th_8 sorry
              thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
                using A9 xxreal_0_th_2 sorry
            qed
            have "m =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
            proof(rule impI)
              assume A10: "m =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
              have "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r"
                using xreal_1_th_8 sorry
              thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
                using A6 A10 xxreal_0_th_2 sorry
            qed
            thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
              using A7 A8 nat_1_th_8 sorry
          qed "sorry"
        qed
        have "r1 <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M).| implies ( ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r))"
        proof(rule impI)
          assume A11: "r1 <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M).|"
          obtain r where 
            [ty]:"r be setHIDDENM2" and rDef:"r =  |.COMPLEX1K10 seq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M).| +XCMPLX-0K2 \<one>\<^sub>M"
             sorry
          show " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r)"
          proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
            have "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 r"
              using complex1_th_46 xreal_1_th_8 sorry
            thus "0NUMBERSK6 <XXREAL-0R3 r"
               sorry
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A12: "m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
            have A13: "m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
            proof(rule impI)
              assume "m <=XXREAL-0R1 n"
              then have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1"
                using A4 sorry
              then have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M).|"
                using A11 xxreal_0_th_2 sorry
              then have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r"
                using xreal_1_th_8 sorry
              thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
                 sorry
            qed
            have "m =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
            proof(rule impI)
              assume "m =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
              then have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r"
                using xreal_1_th_8 sorry
              thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
                 sorry
            qed
            thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
              using A12 A13 nat_1_th_8 sorry
          qed "sorry"
        qed
        thus " ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r1 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1)"
          using A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " for n be NatNAT-1M1 holds  ex r1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r1 & ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1)"
      using nat_1_sch_2 A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CD*)
abbreviation(input) SEQ_2V5("convergentSEQ-2V5" 70) where
  "convergentSEQ-2V5 \<equiv> convergentCOMSEQ-2V3"

mtheorem seq_2_def_6:
  mlet "seq be Real-SequenceSEQ-1M1"
"redefine attr convergentSEQ-2V5 for Real-SequenceSEQ-1M1 means
  (\<lambda>seq.  ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))"
proof
(*compatibility*)
  show " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 iff ( ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be convergentSEQ-2V5 iff ( ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))"
    proof-
      have "(seq be convergentCOMSEQ-2V3 implies ( ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))) & (( ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)) implies seq be convergentCOMSEQ-2V3)"
      proof(rule conjMI,rule impI)
        show "seq be convergentCOMSEQ-2V3 implies ( ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))"
        proof-
          have "seq be convergentCOMSEQ-2V3 implies ( ex tVar14 be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 tVar14 .| <XXREAL-0R3 p)))))"
          proof(rule impI)
            assume "seq be convergentCOMSEQ-2V3"
            then obtain g where
              [ty]:"g be ComplexXCMPLX-0M1" and 
              A1: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
               sorry
            have A2: "ReCOMPLEX1K3 g +XCMPLX-0K2 ImCOMPLEX1K4 g *XCMPLX-0K3 (<i>COMPLEX1K8) =COMPLEX1R1 g"
              using complex1_th_13 sorry
            have " not g be realXREAL-0V1 implies  False "
            proof(rule impI)
              assume A3: " not g be realXREAL-0V1"
              have A4: "ImCOMPLEX1K4 g <>HIDDENR2 0NUMBERSK6"
                using A2 A3 sorry
              let ?p = " |.COMPLEX1K10 ImCOMPLEX1K4 g.|"
              have A5: "?p >XXREAL-0R4 0NUMBERSK6"
                using A4 complex1_th_47 sorry
              have " not ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 ?p)"
              proof-
                have " for n be NatNAT-1M1 holds  ex tVar13 be NatNAT-1M1 st tVar13 <=XXREAL-0R1 tVar13 &  |.COMPLEX1K10 seq .FUNCT-1K1 tVar13 -XCMPLX-0K6 g .| >=XXREAL-0R2  |.COMPLEX1K10 ImCOMPLEX1K4 g.|"
                proof(rule ballI)
                  fix n assume [ty]: "n be NatNAT-1M1"
                  show " ex tVar13 be NatNAT-1M1 st tVar13 <=XXREAL-0R1 tVar13 &  |.COMPLEX1K10 seq .FUNCT-1K1 tVar13 -XCMPLX-0K6 g .| >=XXREAL-0R2  |.COMPLEX1K10 ImCOMPLEX1K4 g.|"
                  proof(rule bexI[of _ "n"],rule conjMI)
                    show "n <=XXREAL-0R1 n"
                       sorry
                    obtain sn where 
                      [ty]:"sn be ElementSUBSET-1M1-of REALNUMBERSK2" and snDef:"sn = seq .FUNCT-1K1 n"
                      using xreal_0_def_1 sorry
                    have A6: "ImCOMPLEX1K4 sn =COMPLEX1R1 0NUMBERSK6"
                      using complex1_def_2 sorry
                    have A7: "ImCOMPLEX1K4 (seq .FUNCT-1K1 n -XCMPLX-0K6 g) =COMPLEX1R1 ImCOMPLEX1K4 (seq .FUNCT-1K1 n) -REAL-1K5 ImCOMPLEX1K4 g"
                      using complex1_th_19 sorry
                    have A8: " |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 g .| =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 (seq .FUNCT-1K1 n -XCMPLX-0K6 g))^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 g)^2SQUARE-1K1)"
                      using A7 A6 sorry
                    have "(ReCOMPLEX1K3 (seq .FUNCT-1K1 n -XCMPLX-0K6 g))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
                      using xreal_1_th_63 sorry
                    then have "sqrtSQUARE-1K3 ((ReCOMPLEX1K3 (seq .FUNCT-1K1 n -XCMPLX-0K6 g))^2SQUARE-1K1 +XCMPLX-0K2 ( |.COMPLEX1K10 ImCOMPLEX1K4 g.|)^2SQUARE-1K1) >=XXREAL-0R2  |.COMPLEX1K10 ImCOMPLEX1K4 g.|"
                      using square_1_th_58 sorry
                    thus " |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 g .| >=XXREAL-0R2  |.COMPLEX1K10 ImCOMPLEX1K4 g.|"
                      using A8 complex1_th_75 sorry
                  qed "sorry"
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              thus " False "
                using A1 A5 sorry
            qed
            then have 
              [ty]:"g be RealXREAL-0M1"
               sorry
            show " ex tVar14 be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 tVar14 .| <XXREAL-0R3 p))))"
            proof(rule bexI[of _ "g"],rule ballI)
              fix p assume [ty]: "p be RealXREAL-0M1"
              have 
                [ty]:"p be RealXREAL-0M1"
                 sorry
              have "0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
                using A1 sorry
              thus " not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))))"
                 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        assume Given: " ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
        then obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A9: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
           sorry
        have "g inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have 
          [ty]:"g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using numbers_th_11 sorry
        have " for VarFor1 be objectHIDDENM1 holds  not ( not VarFor1 <=XXREAL-0R1 0NUMBERSK6 & ( for VarFor2 be setHIDDENM2 holds  not ( for VarFor3 be setHIDDENM2 holds  not (VarFor2 <=XXREAL-0R1 VarFor3 & VarFor1 <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor3 -XCMPLX-0K6 g .|))))"
        proof-
          show " for VarFor1 be objectHIDDENM1 holds  not ( not VarFor1 <=XXREAL-0R1 0NUMBERSK6 & ( for VarFor2 be setHIDDENM2 holds  not ( for VarFor3 be setHIDDENM2 holds  not (VarFor2 <=XXREAL-0R1 VarFor3 & VarFor1 <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor3 -XCMPLX-0K6 g .|))))"
            using A9 sorry
        qed
        thus "seq be convergentCOMSEQ-2V3"
          using bexI[of _ "g"] comseq_2_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mdef seq_2_def_7 ("limSEQ-2K1  _ " [164]164 ) where
  mlet "seq be Real-SequenceSEQ-1M1"
"assume seq be convergentSEQ-2V5 func limSEQ-2K1 seq \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 it .| <XXREAL-0R3 p)"
proof-
  (*existence*)
    show "seq be convergentSEQ-2V5 implies ( ex it be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 it .| <XXREAL-0R3 p))"
    proof(rule impI)
      assume Assume: "seq be convergentSEQ-2V5"
      have A1: "seq be convergentSEQ-2V5"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 it .| <XXREAL-0R3 p)"
        using A1 sorry
    qed
  (*uniqueness*)
    show "seq be convergentSEQ-2V5 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 it1 .| <XXREAL-0R3 p)) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 it2 .| <XXREAL-0R3 p)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "seq be convergentSEQ-2V5"
      have A1: "seq be convergentSEQ-2V5"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 it1 .| <XXREAL-0R3 p)) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 it2 .| <XXREAL-0R3 p)) implies it1 =HIDDENR1 it2"
      proof-
        have "( ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st (( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p))) & g1 <>HIDDENR2 g2) implies  False "
        proof(rule impI)
          assume Given: " ex g1 be RealXREAL-0M1 st  ex g2 be RealXREAL-0M1 st (( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p))) & g1 <>HIDDENR2 g2"
          then obtain g1 g2 where
            [ty]:"g1 be RealXREAL-0M1" "g2 be RealXREAL-0M1" and 
            A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"and A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p)"and A4: "g1 <>HIDDENR2 g2"
             sorry
          have A5: " |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .| =COMPLEX1R1 0NUMBERSK6 implies  False "
          proof(rule impI)
            assume " |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .| =COMPLEX1R1 0NUMBERSK6"
            then have "0NUMBERSK6 +XCMPLX-0K2 g2 =COMPLEX1R1 (g1 -XCMPLX-0K6 g2)+XCMPLX-0K2 g2"
              using absvalue_th_2 sorry
            thus " False "
              using A4 sorry
          qed
          have A6: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|"
            using complex1_th_46 sorry
          then obtain n1 where
            [ty]:"n1 be NatNAT-1M1" and 
            A7: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 ( |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|)/XCMPLX-0K7 \<four>\<^sub>M"
            using A2 A5 sorry
          obtain n2 where
            [ty]:"n2 be NatNAT-1M1" and 
            A8: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 ( |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|)/XCMPLX-0K7 \<four>\<^sub>M"
            using A3 A5 A6 sorry
          have A9: " |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g1 .| <XXREAL-0R3 ( |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|)/XCMPLX-0K7 \<four>\<^sub>M"
            using A7 nat_1_th_12 sorry
          have " |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g2 .| <XXREAL-0R3 ( |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|)/XCMPLX-0K7 \<four>\<^sub>M"
            using A8 nat_1_th_12 sorry
          then have A10: " |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g2 .| +XCMPLX-0K2  |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g1 .| <XXREAL-0R3 ( |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|)/XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 ( |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|)/XCMPLX-0K7 \<four>\<^sub>M"
            using A9 xreal_1_th_8 sorry
          have " |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .| =COMPLEX1R1  |.COMPLEX1K10 (-XCMPLX-0K4 (seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g1))+XCMPLX-0K2 (seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g2) .|"
             sorry
          then have " |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .| <=XXREAL-0R1  |.COMPLEX1K10 -XCMPLX-0K4 (seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g1) .| +XCMPLX-0K2  |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g2 .|"
            using complex1_th_56 sorry
          then have A11: " |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .| <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g1 .| +XCMPLX-0K2  |.COMPLEX1K10 seq .FUNCT-1K1 (n1 +XCMPLX-0K2 n2) -XCMPLX-0K6 g2 .|"
            using complex1_th_52 sorry
          have "( |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 g1 -XCMPLX-0K6 g2 .|"
            using A5 A6 xreal_1_th_216 sorry
          thus " False "
            using A10 A11 xxreal_0_th_2 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

abbreviation(input) SEQ_2V6("boundedSEQ-2V6" 70) where
  "boundedSEQ-2V6 \<equiv> boundedCOMSEQ-2V1"

mtheorem seq_2_def_8:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"redefine attr boundedSEQ-2V6 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  (\<lambda>f. f be bounded-aboveSEQ-2V1\<bar>bounded-belowSEQ-2V2)"
proof
(*compatibility*)
  show " for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be boundedSEQ-2V6 iff f be bounded-aboveSEQ-2V1\<bar>bounded-belowSEQ-2V2"
  proof(rule ballI)
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f be boundedSEQ-2V6 iff f be bounded-aboveSEQ-2V1\<bar>bounded-belowSEQ-2V2"
       sorry
  qed "sorry"
qed "sorry"

mtheorem seq_2_cl_3:
"cluster constantVALUED-0V15 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be constantVALUED-0V15 implies it be convergentSEQ-2V5"
  proof-
    have " for seq be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 implies seq be convergentSEQ-2V5"
    proof(rule ballI,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume "seq be constantVALUED-0V15"
      then obtain r where
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 r"
        using valued_0_def_18 sorry
      obtain g where 
        [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2" and gDef:"g = r"
         sorry
      have " ex g be ElementSUBSET-1M1-of REALNUMBERSK2 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      proof(rule bexI[of _ "g"],rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain n where 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = 0NUMBERSK6"
           sorry
        show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          have " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 r -REAL-1K5 g .|"
            using A1 sorry
          also have "... = 0NUMBERSK6"
            using absvalue_th_2 sorry
          finally have " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1 0NUMBERSK6"
             sorry
          thus " not  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A2 sorry
        qed "sorry"
      qed "sorry"
      thus "seq be convergentSEQ-2V5"
        using seq_2_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_2_th_5:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
      using A1 sorry
    obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p)"
      using A2 sorry
    obtain g where 
      [ty]:"g be setHIDDENM2" and gDef:"g = g1 +XCMPLX-0K2 g2"
       sorry
    have " ex g be setHIDDENM2 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be setHIDDENM2 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A5: "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A6: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using A3 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A7: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using A4 A5 sorry
      obtain k where 
        [ty]:"k be setHIDDENM2" and kDef:"k = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex k be setHIDDENM2 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "k"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A8: "k <=XXREAL-0R1 m"
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A8 xxreal_0_th_2 sorry
        then have A9: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A6 sorry
        have "n2 <=XXREAL-0R1 k"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A8 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A7 sorry
        then have A10: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| +XCMPLX-0K2  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A9 xreal_1_th_8 sorry
        have A11: " |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m +XCMPLX-0K2 seq9 .FUNCT-1K1 m)-XCMPLX-0K6 (g1 +XCMPLX-0K2 g2) .|"
          using seq_1_th_7 sorry
        also have "... =  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)+XCMPLX-0K2 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) .|"
           sorry
        finally have " |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)+XCMPLX-0K2 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) .|"
           sorry
        have " |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)+XCMPLX-0K2 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) .| <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| +XCMPLX-0K2  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .|"
          using complex1_th_56 sorry
        thus " not  |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
          using A10 A11 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
      using seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_cl_4:
  mlet "seq1 be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1", "seq2 be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1"
"cluster seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 seq1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 implies it be convergentSEQ-2V5"
    using seq_2_th_5 sorry
qed "sorry"

mtheorem seq_2_th_6:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =COMPLEX1R1 limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =COMPLEX1R1 limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be setHIDDENM2 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9) .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then have A3: "0NUMBERSK6 <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
         sorry
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using A1 seq_2_def_7 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 A3 seq_2_def_7 sorry
      obtain k where 
        [ty]:"k be setHIDDENM2" and kDef:"k = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex k be setHIDDENM2 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9) .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "k"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A6: "k <=XXREAL-0R1 m"
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A6 xxreal_0_th_2 sorry
        then have A7: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A4 sorry
        have "n2 <=XXREAL-0R1 k"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A6 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A5 sorry
        then have A8: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| +XCMPLX-0K2  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A7 xreal_1_th_8 sorry
        have A9: " |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9) .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m +XCMPLX-0K2 seq9 .FUNCT-1K1 m)-XCMPLX-0K6 (limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9) .|"
          using seq_1_th_7 sorry
        also have "... =  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)+XCMPLX-0K2 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) .|"
           sorry
        finally have " |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9) .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)+XCMPLX-0K2 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) .|"
           sorry
        have " |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)+XCMPLX-0K2 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) .| <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| +XCMPLX-0K2  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .|"
          using complex1_th_56 sorry
        thus " |.COMPLEX1K10 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9) .| <XXREAL-0R3 p"
          using A8 A9 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =COMPLEX1R1 limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq9"
      using A1 A2 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_7:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume "seq be convergentSEQ-2V5"
    then obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A1: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
       sorry
    obtain g where 
      [ty]:"g be setHIDDENM2" and gDef:"g = r *XCMPLX-0K3 g1"
       sorry
    have " ex g be setHIDDENM2 st  for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))))"
    proof(rule bexI[of _ "g"])
      have A2: "r =COMPLEX1R1 0NUMBERSK6 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))"
      proof(rule impI,rule ballI,rule impI)
        assume A3: "r =COMPLEX1R1 0NUMBERSK6"
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A4: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain k where 
          [ty]:"k be NatNAT-1M1" and kDef:"k = 0NUMBERSK6"
           sorry
        show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "k <=XXREAL-0R1 m"
          have " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 (0NUMBERSK6)*XCMPLX-0K3 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .|"
            using A3 seq_1_th_9 sorry
          also have "... = 0NUMBERSK6"
            using absvalue_th_2 sorry
          finally have " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1 0NUMBERSK6"
             sorry
          thus " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A4 sorry
        qed "sorry"
      qed "sorry"
      have "r <>HIDDENR2 0NUMBERSK6 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))"
      proof(rule impI,rule ballI,rule impI)
        assume A5: "r <>HIDDENR2 0NUMBERSK6"
        then have A6: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 r.|"
          using complex1_th_47 sorry
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A7: "0NUMBERSK6 <XXREAL-0R3 p"
        have A8: "0NUMBERSK6 <>HIDDENR2  |.COMPLEX1K10 r.|"
          using A5 complex1_th_47 sorry
        obtain n1 where
          [ty]:"n1 be NatNAT-1M1" and 
          A9: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)"
          using A1 A6 A7 sorry
        obtain k where 
          [ty]:"k be NatNAT-1M1" and kDef:"k = n1"
           sorry
        show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "k <=XXREAL-0R1 m"
          then have A10: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)"
            using A9 sorry
          have A11: " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 r *XCMPLX-0K3 seq .FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 g1 .|"
            using seq_1_th_9 sorry
          also have "... =  |.COMPLEX1K10 r *XCMPLX-0K3 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1) .|"
             sorry
          also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|)"
            using complex1_th_65 sorry
          finally have " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|)"
             sorry
          have "( |.COMPLEX1K10 r.|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)) =HIDDENR1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 (( |.COMPLEX1K10 r.|)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 p)"
            using xcmplx_0_def_9 sorry
          also have "... = (( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 p"
             sorry
          also have "... = \<one>\<^sub>M *XCMPLX-0K3 p"
            using A8 xcmplx_0_def_7 sorry
          also have "... = p"
             sorry
          finally have "( |.COMPLEX1K10 r.|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)) =HIDDENR1 p"
             sorry
          thus " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A6 A10 A11 xreal_1_th_68 sorry
        qed "sorry"
      qed "sorry"
      thus " for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p))))"
        using A2 sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
      using seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_cl_5:
  mlet "r be RealXREAL-0M1", "seq be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1"
"cluster r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq implies it be convergentSEQ-2V5"
    using seq_2_th_7 sorry
qed "sorry"

mtheorem seq_2_th_8:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 r *XCMPLX-0K3 (limSEQ-2K1 seq)"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 r *XCMPLX-0K3 (limSEQ-2K1 seq)"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
    have A2: "r =COMPLEX1R1 0NUMBERSK6 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| <XXREAL-0R3 p))"
    proof(rule impI,rule ballI,rule impI)
      assume A3: "r =COMPLEX1R1 0NUMBERSK6"
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A4: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain k where 
        [ty]:"k be NatNAT-1M1" and kDef:"k = 0NUMBERSK6"
         sorry
      show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "k"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "k <=XXREAL-0R1 m"
        have " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| =HIDDENR1  |.COMPLEX1K10 (0NUMBERSK6)*XCMPLX-0K3 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .|"
          using A3 seq_1_th_9 sorry
        also have "... = 0NUMBERSK6"
          using absvalue_th_2 sorry
        finally have " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| =HIDDENR1 0NUMBERSK6"
           sorry
        thus " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| <XXREAL-0R3 p"
          using A4 sorry
      qed "sorry"
    qed "sorry"
    have "r <>HIDDENR2 0NUMBERSK6 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| <XXREAL-0R3 p))"
    proof(rule impI,rule ballI,rule impI)
      assume A5: "r <>HIDDENR2 0NUMBERSK6"
      then have A6: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 r.|"
        using complex1_th_47 sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A7: "0NUMBERSK6 <XXREAL-0R3 p"
      have A8: "0NUMBERSK6 <>HIDDENR2  |.COMPLEX1K10 r.|"
        using A5 complex1_th_47 sorry
      have "0NUMBERSK6 <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)"
        using A6 A7 sorry
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A9: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)"
        using A1 seq_2_def_7 sorry
      obtain k where 
        [ty]:"k be NatNAT-1M1" and kDef:"k = n1"
         sorry
      show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "k"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "k <=XXREAL-0R1 m"
        then have A10: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)"
          using A9 sorry
        have A11: " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| =HIDDENR1  |.COMPLEX1K10 r *XCMPLX-0K3 seq .FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .|"
          using seq_1_th_9 sorry
        also have "... =  |.COMPLEX1K10 r *XCMPLX-0K3 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq) .|"
           sorry
        also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)"
          using complex1_th_65 sorry
        finally have " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| =HIDDENR1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)"
           sorry
        have "( |.COMPLEX1K10 r.|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)) =HIDDENR1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 (( |.COMPLEX1K10 r.|)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 p)"
          using xcmplx_0_def_9 sorry
        also have "... = (( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 r.|)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 p"
           sorry
        also have "... = \<one>\<^sub>M *XCMPLX-0K3 p"
          using A8 xcmplx_0_def_7 sorry
        also have "... = p"
           sorry
        finally have "( |.COMPLEX1K10 r.|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 r.|)) =HIDDENR1 p"
           sorry
        thus " |.COMPLEX1K10 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 m -XCMPLX-0K6 r *XCMPLX-0K3 (limSEQ-2K1 seq) .| <XXREAL-0R3 p"
          using A6 A10 A11 xreal_1_th_68 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 r *XCMPLX-0K3 (limSEQ-2K1 seq)"
      using A1 A2 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_9:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
   sorry

mtheorem seq_2_cl_6:
  mlet "seq be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1"
"cluster -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq implies it be convergentSEQ-2V5"
     sorry
qed "sorry"

mtheorem seq_2_th_10:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 -XCMPLX-0K4 limSEQ-2K1 seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 -XCMPLX-0K4 limSEQ-2K1 seq"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume "seq be convergentSEQ-2V5"
    then have "limSEQ-2K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (limSEQ-2K1 seq)"
      using seq_2_th_8 sorry
    thus "limSEQ-2K1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 -XCMPLX-0K4 limSEQ-2K1 seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_11:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
    have "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
      using A2 sorry
    thus "seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_cl_7:
  mlet "seq1 be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1", "seq2 be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1"
"cluster seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 implies it be convergentSEQ-2V5"
    using seq_2_th_11 sorry
qed "sorry"

mtheorem seq_2_th_12:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =COMPLEX1R1 limSEQ-2K1 seq -XCMPLX-0K6 limSEQ-2K1 seq9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =HIDDENR1 limSEQ-2K1 seq -XCMPLX-0K6 limSEQ-2K1 seq9"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
    have "limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =HIDDENR1 limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq9)"
      using A1 A2 seq_2_th_6 sorry
    also have "... = limSEQ-2K1 seq +XCMPLX-0K2 (-XCMPLX-0K4 limSEQ-2K1 seq9)"
      using A2 seq_2_th_10 sorry
    also have "... = limSEQ-2K1 seq -XCMPLX-0K6 limSEQ-2K1 seq9"
       sorry
    finally show "limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =HIDDENR1 limSEQ-2K1 seq -XCMPLX-0K6 limSEQ-2K1 seq9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_13:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies seq be boundedSEQ-2V6"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies seq be boundedSEQ-2V6"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume "seq be convergentSEQ-2V5"
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A1: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
       sorry
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A2: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 \<one>\<^sub>M"
      using A1 sorry
    have A3: " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r)"
    proof-
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r =  |.COMPLEX1K10 g.| +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      show " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
        have "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 r"
          using complex1_th_46 xreal_1_th_8 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 r"
           sorry
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n1 <=XXREAL-0R1 m"
        then have A4: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 \<one>\<^sub>M"
          using A2 sorry
        have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| -XCMPLX-0K6  |.COMPLEX1K10 g.| <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .|"
          using complex1_th_59 sorry
        then have A5: " |.COMPLEX1K10 seq .FUNCT-1K1 m.| -XCMPLX-0K6  |.COMPLEX1K10 g.| <XXREAL-0R3 \<one>\<^sub>M"
          using A4 xxreal_0_th_2 sorry
        have "( |.COMPLEX1K10 seq .FUNCT-1K1 m.| -XCMPLX-0K6  |.COMPLEX1K10 g.|)+XCMPLX-0K2  |.COMPLEX1K10 g.| =COMPLEX1R1  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
           sorry
        thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
          using A5 xreal_1_th_6 sorry
      qed "sorry"
    qed
    have " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r)"
    proof-
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A6: "0NUMBERSK6 <XXREAL-0R3 r1"and A7: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1"
        using A3 sorry
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A8: "0NUMBERSK6 <XXREAL-0R3 r2"and A9: " for m be NatNAT-1M1 holds m <=XXREAL-0R1 n1 implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r2"
        using seq_2_th_4 sorry
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r = r1 +XCMPLX-0K2 r2"
         sorry
      show " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "r"],rule conjMI,rule ballI)
        show "0NUMBERSK6 <XXREAL-0R3 r"
          using A6 A8 sorry
        have A10: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r"
          using A8 xreal_1_th_8 sorry
        have A11: "0NUMBERSK6 +XCMPLX-0K2 r2 <XXREAL-0R3 r"
          using A6 xreal_1_th_8 sorry
        fix m assume [ty]: "m be NatNAT-1M1"
        have A12: "n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
        proof(rule impI)
          assume "n1 <=XXREAL-0R1 m"
          then have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r1"
            using A7 sorry
          thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
            using A10 xxreal_0_th_2 sorry
        qed
        have "m <=XXREAL-0R1 n1 implies  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
        proof(rule impI)
          assume "m <=XXREAL-0R1 n1"
          then have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r2"
            using A9 sorry
          thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
            using A11 xxreal_0_th_2 sorry
        qed
        thus " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
          using A12 sorry
      qed "sorry"
    qed
    thus "seq be boundedSEQ-2V6"
      using seq_2_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_cl_8:
"cluster convergentSEQ-2V5 also-is boundedSEQ-2V6 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be convergentSEQ-2V5 implies it be boundedSEQ-2V6"
    using seq_2_th_13 sorry
qed "sorry"

mtheorem seq_2_th_14:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
      using A1 sorry
    obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p)"
      using A2 sorry
    obtain g where 
      [ty]:"g be setHIDDENM2" and gDef:"g = g1 *XCMPLX-0K3 g2"
       sorry
    have " ex g be setHIDDENM2 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A5: "0NUMBERSK6 <XXREAL-0R3 r"and A6: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r"
        using A1 seq_2_th_3 sorry
      have A7: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 g2.|"
        using complex1_th_46 sorry
      have A8: "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 g2.| +XCMPLX-0K2 r"
        using A5 complex1_th_46 xreal_1_th_8 sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A9: "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A10: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)"
        using A3 A8 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A11: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)"
        using A4 A8 A9 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A12: "n <=XXREAL-0R1 m"
        have A13: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
          using complex1_th_46 sorry
        have A14: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .|"
          using complex1_th_46 sorry
        have "n2 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A12 xxreal_0_th_2 sorry
        then have A15: " |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)"
          using A11 sorry
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A12 xxreal_0_th_2 sorry
        then have A16: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .| <=XXREAL-0R1 p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)"
          using A10 sorry
        have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m *XCMPLX-0K3 seq9 .FUNCT-1K1 m -XCMPLX-0K6 (seq .FUNCT-1K1 m *XCMPLX-0K3 g2 -XCMPLX-0K6 seq .FUNCT-1K1 m *XCMPLX-0K3 g2))-XCMPLX-0K6 g1 *XCMPLX-0K3 g2 .|"
          using seq_1_th_8 sorry
        also have "... =  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) +XCMPLX-0K2 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)*XCMPLX-0K3 g2 .|"
           sorry
        finally have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) +XCMPLX-0K2 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)*XCMPLX-0K3 g2 .|"
           sorry
        then have A17: " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) .| +XCMPLX-0K2  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)*XCMPLX-0K3 g2 .|"
          using complex1_th_56 sorry
        have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
          using A6 sorry
        then have "( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2 .|) <XXREAL-0R3 r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r))"
          using A13 A14 A15 xreal_1_th_96 sorry
        then have A18: " |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) .| <XXREAL-0R3 r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r))"
          using complex1_th_65 sorry
        have " |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)*XCMPLX-0K3 g2 .| =COMPLEX1R1 ( |.COMPLEX1K10 g2.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|)"
          using complex1_th_65 sorry
        then have A19: " |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)*XCMPLX-0K3 g2 .| <=XXREAL-0R1 ( |.COMPLEX1K10 g2.|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r))"
          using A7 A16 xreal_1_th_64 sorry
        have "r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)) +XCMPLX-0K2 ( |.COMPLEX1K10 g2.|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)) =HIDDENR1 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r))*XCMPLX-0K3 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)"
           sorry
        also have "... = p"
          using A8 xcmplx_1_th_87 sorry
        finally have "r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)) +XCMPLX-0K2 ( |.COMPLEX1K10 g2.|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 g2.| +XCMPLX-0K2 r)) =HIDDENR1 p"
           sorry
        then have " |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 g2) .| +XCMPLX-0K2  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 g1)*XCMPLX-0K3 g2 .| <XXREAL-0R3 p"
          using A18 A19 xreal_1_th_8 sorry
        thus " not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
          using A17 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9 be convergentSEQ-2V5"
      using seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_cl_9:
  mlet "seq1 be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1", "seq2 be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1"
"cluster seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 implies it be convergentSEQ-2V5"
    using seq_2_th_14 sorry
qed "sorry"

mtheorem seq_2_th_15:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =COMPLEX1R1 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5 implies limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =COMPLEX1R1 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
    obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 r"and A4: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .FUNCT-1K1 n.| <XXREAL-0R3 r"
      using A1 seq_2_th_3 sorry
    have A5: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 limSEQ-2K1 seq9 .|"
      using complex1_th_46 sorry
    have A6: "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r"
      using A3 complex1_th_46 xreal_1_th_8 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then have A7: "0NUMBERSK6 <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)"
        using A6 sorry
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A8: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)"
        using A1 seq_2_def_7 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A9: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)"
        using A2 A7 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A10: "n <=XXREAL-0R1 m"
        have A11: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
          using complex1_th_46 sorry
        have A12: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .|"
          using complex1_th_46 sorry
        have "n2 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A10 xxreal_0_th_2 sorry
        then have A13: " |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .| <XXREAL-0R3 p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)"
          using A9 sorry
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A10 xxreal_0_th_2 sorry
        then have A14: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <=XXREAL-0R1 p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)"
          using A8 sorry
        have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m *XCMPLX-0K3 seq9 .FUNCT-1K1 m -XCMPLX-0K6 (seq .FUNCT-1K1 m *XCMPLX-0K3 (limSEQ-2K1 seq9) -XCMPLX-0K6 seq .FUNCT-1K1 m *XCMPLX-0K3 (limSEQ-2K1 seq9)))-XCMPLX-0K6 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .|"
          using seq_1_th_8 sorry
        also have "... =  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) +XCMPLX-0K2 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .|"
           sorry
        finally have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| =HIDDENR1  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) +XCMPLX-0K2 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .|"
           sorry
        then have A15: " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) .| +XCMPLX-0K2  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .|"
          using complex1_th_56 sorry
        have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 r"
          using A4 sorry
        then have "( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9 .|) <XXREAL-0R3 r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r))"
          using A11 A12 A13 xreal_1_th_96 sorry
        then have A16: " |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) .| <XXREAL-0R3 r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r))"
          using complex1_th_65 sorry
        have " |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| =COMPLEX1R1 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)"
          using complex1_th_65 sorry
        then have A17: " |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| <=XXREAL-0R1 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r))"
          using A5 A14 xreal_1_th_64 sorry
        have "r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)) +XCMPLX-0K2 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)) =HIDDENR1 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r))*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)"
           sorry
        also have "... = p"
          using A6 xcmplx_1_th_87 sorry
        finally have "r *XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)) +XCMPLX-0K2 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .|)*XCMPLX-0K3 (p /XCMPLX-0K7 ( |.COMPLEX1K10 limSEQ-2K1 seq9 .| +XCMPLX-0K2 r)) =HIDDENR1 p"
           sorry
        then have " |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq9) .| +XCMPLX-0K2  |.COMPLEX1K10 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| <XXREAL-0R3 p"
          using A16 A17 xreal_1_th_8 sorry
        thus " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9).FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9) .| <XXREAL-0R3 p"
          using A15 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq9) =COMPLEX1R1 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq9)"
      using A1 A2 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_16:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies (limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|)"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
    have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 limSEQ-2K1 seq .|"
      using A2 complex1_th_47 sorry
    then have "0NUMBERSK6 <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A3: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 seq_2_def_7 sorry
    obtain n where 
      [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
       sorry
    show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
    proof(rule bexI[of _ "n"],rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m"
      then have A4: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
        using A3 sorry
      have A5: " |.COMPLEX1K10 limSEQ-2K1 seq .| -XCMPLX-0K6  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <=XXREAL-0R1  |.COMPLEX1K10 limSEQ-2K1 seq -XCMPLX-0K6 seq .FUNCT-1K1 m .|"
        using complex1_th_59 sorry
      have " |.COMPLEX1K10 limSEQ-2K1 seq -XCMPLX-0K6 seq .FUNCT-1K1 m .| =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq) .|"
         sorry
      also have "... =  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|"
        using complex1_th_52 sorry
      finally have " |.COMPLEX1K10 limSEQ-2K1 seq -XCMPLX-0K6 seq .FUNCT-1K1 m .| =HIDDENR1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|"
         sorry
      then have A6: " |.COMPLEX1K10 limSEQ-2K1 seq .| -XCMPLX-0K6  |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
        using A4 A5 xxreal_0_th_2 sorry
      have A7: "( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.| -XCMPLX-0K6 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
         sorry
      have "( |.COMPLEX1K10 limSEQ-2K1 seq .| -XCMPLX-0K6  |.COMPLEX1K10 seq .FUNCT-1K1 m.|)+XCMPLX-0K2 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.| -XCMPLX-0K6 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
         sorry
      thus " not ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
        using A6 A7 xreal_1_th_6 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_17:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 seq .FUNCT-1K1 n) implies 0NUMBERSK6 <=XXREAL-0R1 limSEQ-2K1 seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 seq .FUNCT-1K1 n) &  not 0NUMBERSK6 <=XXREAL-0R1 limSEQ-2K1 seq) implies  False "
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 seq .FUNCT-1K1 n"
      and A3: " not 0NUMBERSK6 <=XXREAL-0R1 limSEQ-2K1 seq"
    have "0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 limSEQ-2K1 seq"
      using A3 sorry
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A4: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 -XCMPLX-0K4 limSEQ-2K1 seq"
      using A1 seq_2_def_7 sorry
    have " |.COMPLEX1K10 seq .FUNCT-1K1 n1 -XCMPLX-0K6 limSEQ-2K1 seq .| <=XXREAL-0R1 -XCMPLX-0K4 limSEQ-2K1 seq"
      using A4 sorry
    then have "seq .FUNCT-1K1 n1 -XCMPLX-0K6 limSEQ-2K1 seq <=XXREAL-0R1 -XCMPLX-0K4 limSEQ-2K1 seq"
      using absvalue_th_5 sorry
    then have A5: "(seq .FUNCT-1K1 n1 -XCMPLX-0K6 limSEQ-2K1 seq)+XCMPLX-0K2 limSEQ-2K1 seq <=XXREAL-0R1 (-XCMPLX-0K4 limSEQ-2K1 seq)+XCMPLX-0K2 limSEQ-2K1 seq"
      using xreal_1_th_6 sorry
    have "seq .FUNCT-1K1 n1 =COMPLEX1R1 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "seq .FUNCT-1K1 n1 =COMPLEX1R1 0NUMBERSK6"
      then have " |.COMPLEX1K10 seq .FUNCT-1K1 n1 -XCMPLX-0K6 limSEQ-2K1 seq .| =COMPLEX1R1 -XCMPLX-0K4 limSEQ-2K1 seq"
        using A3 absvalue_def_1 sorry
      thus " False "
        using A4 sorry
    qed
    thus " False "
      using A2 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_18:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5) & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n) implies limSEQ-2K1 seq <=XXREAL-0R1 limSEQ-2K1 seq9"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (seq9 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n)) implies limSEQ-2K1 seq <=XXREAL-0R1 limSEQ-2K1 seq9"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
      and A3: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n"
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 (seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n"
        using A3 sorry
      then have A4: "seq .FUNCT-1K1 n -XCMPLX-0K6 seq .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n -XCMPLX-0K6 seq .FUNCT-1K1 n"
        using xreal_1_th_9 sorry
      have "(seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 n =HIDDENR1 seq9 .FUNCT-1K1 n +XCMPLX-0K2 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 n"
        using seq_1_th_7 sorry
      also have "... = seq9 .FUNCT-1K1 n +XCMPLX-0K2 (-XCMPLX-0K4 seq .FUNCT-1K1 n)"
        using seq_1_th_10 sorry
      also have "... = seq9 .FUNCT-1K1 n -XCMPLX-0K6 seq .FUNCT-1K1 n"
         sorry
      finally have "(seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 n =HIDDENR1 seq9 .FUNCT-1K1 n -XCMPLX-0K6 seq .FUNCT-1K1 n"
         sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 (seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq).FUNCT-1K1 n"
        using A4 sorry
    qed "sorry"
    then have A5: "0NUMBERSK6 <=XXREAL-0R1 limSEQ-2K1 (seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq)"
      using A1 A2 seq_2_th_17 sorry
    have "limSEQ-2K1 (seq9 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 limSEQ-2K1 seq9 -XCMPLX-0K6 limSEQ-2K1 seq"
      using A1 A2 seq_2_th_12 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 limSEQ-2K1 seq <=XXREAL-0R1 (limSEQ-2K1 seq9 -XCMPLX-0K6 limSEQ-2K1 seq)+XCMPLX-0K2 limSEQ-2K1 seq"
      using A5 xreal_1_th_6 sorry
    thus "limSEQ-2K1 seq <=XXREAL-0R1 limSEQ-2K1 seq9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_19:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds ((seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5) & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n & seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n)) & limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq9 implies seq1 be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (seq9 be convergentSEQ-2V5 & (( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n & seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n) & limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq9)) implies seq1 be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
      and A3: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n & seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n"
      and A4: "limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq9"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A5: "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A6: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A1 seq_2_def_7 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A7: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A2 A4 A5 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A8: "n <=XXREAL-0R1 m"
        have "n2 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A8 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A7 sorry
        then have A9: "seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <XXREAL-0R3 p"
          using seq_2_th_1 sorry
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A8 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A6 sorry
        then have A10: "-XCMPLX-0K4 p <XXREAL-0R3 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using seq_2_th_1 sorry
        have "seq .FUNCT-1K1 m <=XXREAL-0R1 seq1 .FUNCT-1K1 m"
          using A3 sorry
        then have "seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <=XXREAL-0R1 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using xreal_1_th_9 sorry
        then have A11: "-XCMPLX-0K4 p <XXREAL-0R3 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using A10 xxreal_0_th_2 sorry
        have "seq1 .FUNCT-1K1 m <=XXREAL-0R1 seq9 .FUNCT-1K1 m"
          using A3 sorry
        then have "seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <=XXREAL-0R1 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using xreal_1_th_9 sorry
        then have "seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <XXREAL-0R3 p"
          using A9 xxreal_0_th_2 sorry
        thus " not  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A11 seq_2_th_1 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be convergentSEQ-2V5"
      using bexI[of _ "limSEQ-2K1 seq"] seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_20:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds ((seq be convergentSEQ-2V5 & seq9 be convergentSEQ-2V5) & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n & seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n)) & limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq9 implies limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (seq9 be convergentSEQ-2V5 & (( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n & seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n) & limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq9)) implies limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq9 be convergentSEQ-2V5"
      and A3: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n <=XXREAL-0R1 seq1 .FUNCT-1K1 n & seq1 .FUNCT-1K1 n <=XXREAL-0R1 seq9 .FUNCT-1K1 n"
      and A4: "limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq9"
    have A5: "seq1 be convergentSEQ-2V5"
      using A1 A2 A3 A4 seq_2_th_19 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A6: "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A7: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A1 seq_2_def_7 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A8: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A2 A4 A6 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A9: "n <=XXREAL-0R1 m"
        have "n2 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A9 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A8 sorry
        then have A10: "seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <XXREAL-0R3 p"
          using seq_2_th_1 sorry
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A9 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A7 sorry
        then have A11: "-XCMPLX-0K4 p <XXREAL-0R3 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using seq_2_th_1 sorry
        have "seq .FUNCT-1K1 m <=XXREAL-0R1 seq1 .FUNCT-1K1 m"
          using A3 sorry
        then have "seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <=XXREAL-0R1 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using xreal_1_th_9 sorry
        then have A12: "-XCMPLX-0K4 p <XXREAL-0R3 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using A11 xxreal_0_th_2 sorry
        have "seq1 .FUNCT-1K1 m <=XXREAL-0R1 seq9 .FUNCT-1K1 m"
          using A3 sorry
        then have "seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <=XXREAL-0R1 seq9 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq"
          using xreal_1_th_9 sorry
        then have "seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq <XXREAL-0R3 p"
          using A10 xxreal_0_th_2 sorry
        thus " |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A12 seq_2_th_1 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
      using A5 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_21:
" for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6) & seq be non-zeroORDINAL1V9 implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 & seq be non-zeroORDINAL1V9) implies seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
      and A3: "seq be non-zeroORDINAL1V9"
    have A4: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 limSEQ-2K1 seq .|"
      using A2 complex1_th_47 sorry
    have A5: "0NUMBERSK6 <>HIDDENR2  |.COMPLEX1K10 limSEQ-2K1 seq .|"
      using A2 complex1_th_47 sorry
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A6: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
      using A1 A2 seq_2_th_16 sorry
    have "(0NUMBERSK6)*NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)"
      using A4 sorry
    then have A7: "0NUMBERSK6 <XXREAL-0R3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A8: "0NUMBERSK6 <XXREAL-0R3 p"
      then have "(0NUMBERSK6)*NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M)"
        using A7 sorry
      then obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A9: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M)"
        using A1 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A10: "n <=XXREAL-0R1 m"
        have "n2 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A10 xxreal_0_th_2 sorry
        then have A11: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M)"
          using A9 sorry
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A10 xxreal_0_th_2 sorry
        then have A12: "( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
          using A6 sorry
        have A13: "seq .FUNCT-1K1 m <>HIDDENR2 0NUMBERSK6"
          using A3 seq_1_th_5 sorry
        then have "seq .FUNCT-1K1 m *XCMPLX-0K3 (limSEQ-2K1 seq) <>HIDDENR2 0NUMBERSK6"
          using A2 sorry
        then have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (limSEQ-2K1 seq) .|"
          using complex1_th_47 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)"
          using complex1_th_65 sorry
        then have A14: "( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)) <XXREAL-0R3 (p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))"
          using A11 xreal_1_th_74 sorry
        have A15: "(p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)) =HIDDENR1 (p *XCMPLX-0K3 (\<two>\<^sub>M \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))))*XCMPLX-0K3 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))\<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|))\<inverse>XCMPLX-0K5)"
           sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5))"
          using xcmplx_1_th_204 sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)\<inverse>XCMPLX-0K5))*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5)"
           sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5)"
          using A5 xcmplx_0_def_7 sorry
        also have "... = (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5"
           sorry
        also have "... = (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)"
          using xcmplx_0_def_9 sorry
        finally have "(p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)) =HIDDENR1 (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)"
           sorry
        have A16: " |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .|"
          using valued_1_th_10 sorry
        also have "... = ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))"
          using A2 A13 seq_2_th_2 sorry
        finally have " |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| =HIDDENR1 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))"
           sorry
        have A17: "0NUMBERSK6 <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A4 sorry
        have A18: "0NUMBERSK6 <>HIDDENR2 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A2 complex1_th_47 sorry
        have "(0NUMBERSK6)*NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)"
          using A8 A17 sorry
        then have A19: "(p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|) <XXREAL-0R3 (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)"
          using A12 A17 xreal_1_th_76 sorry
        have "(p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)\<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        also have "... = p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)\<inverse>XCMPLX-0K5)"
           sorry
        also have "... = p *XCMPLX-0K3 \<one>\<^sub>M"
          using A18 xcmplx_0_def_7 sorry
        also have "... = p"
           sorry
        finally have "(p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 p"
           sorry
        thus " not  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| <XXREAL-0R3 p"
          using A14 A15 A16 A19 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
      using bexI[of _ "(limSEQ-2K1 seq)\<inverse>XCMPLX-0K5"] seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_22:
" for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6) & seq be non-zeroORDINAL1V9 implies limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 & seq be non-zeroORDINAL1V9) implies limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
      and A3: "seq be non-zeroORDINAL1V9"
    have A4: "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
      using A1 A2 A3 seq_2_th_21 sorry
    have A5: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 limSEQ-2K1 seq .|"
      using A2 complex1_th_47 sorry
    have A6: "0NUMBERSK6 <>HIDDENR2  |.COMPLEX1K10 limSEQ-2K1 seq .|"
      using A2 complex1_th_47 sorry
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A7: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
      using A1 A2 seq_2_th_16 sorry
    have "(0NUMBERSK6)*NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)"
      using A5 sorry
    then have A8: "0NUMBERSK6 <XXREAL-0R3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A9: "0NUMBERSK6 <XXREAL-0R3 p"
      then have "(0NUMBERSK6)*NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M)"
        using A8 sorry
      then obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A10: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M)"
        using A1 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A11: "n <=XXREAL-0R1 m"
        have "n2 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have "n2 <=XXREAL-0R1 m"
          using A11 xxreal_0_th_2 sorry
        then have A12: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M)"
          using A10 sorry
        have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A11 xxreal_0_th_2 sorry
        then have A13: "( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m.|"
          using A7 sorry
        have A14: "seq .FUNCT-1K1 m <>HIDDENR2 0NUMBERSK6"
          using A3 seq_1_th_5 sorry
        then have "seq .FUNCT-1K1 m *XCMPLX-0K3 (limSEQ-2K1 seq) <>HIDDENR2 0NUMBERSK6"
          using A2 sorry
        then have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 (limSEQ-2K1 seq) .|"
          using complex1_th_47 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)"
          using complex1_th_65 sorry
        then have A15: "( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)) <XXREAL-0R3 (p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))"
          using A12 xreal_1_th_74 sorry
        have A16: "(p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)) =HIDDENR1 (p *XCMPLX-0K3 (\<two>\<^sub>M \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))))*XCMPLX-0K3 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))\<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|))\<inverse>XCMPLX-0K5)"
           sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5))"
          using xcmplx_1_th_204 sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)\<inverse>XCMPLX-0K5))*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5)"
           sorry
        also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M \<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5)"
          using A6 xcmplx_0_def_7 sorry
        also have "... = (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)\<inverse>XCMPLX-0K5"
           sorry
        also have "... = (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)"
          using xcmplx_0_def_9 sorry
        finally have "(p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)) =HIDDENR1 (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)"
           sorry
        have A17: " |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| =HIDDENR1  |.COMPLEX1K10 (seq .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .|"
          using valued_1_th_10 sorry
        also have "... = ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))"
          using A2 A14 seq_2_th_2 sorry
        finally have " |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| =HIDDENR1 ( |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 seq .|)/XCMPLX-0K7 (( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|))"
           sorry
        have A18: "0NUMBERSK6 <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A5 sorry
        have A19: "0NUMBERSK6 <>HIDDENR2 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
          using A2 complex1_th_47 sorry
        have "(0NUMBERSK6)*NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)"
          using A9 A18 sorry
        then have A20: "(p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|) <XXREAL-0R3 (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)"
          using A13 A18 xreal_1_th_76 sorry
        have "(p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 (p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)\<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        also have "... = p *XCMPLX-0K3 ((( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M)\<inverse>XCMPLX-0K5)"
           sorry
        also have "... = p *XCMPLX-0K3 \<one>\<^sub>M"
          using A19 xcmplx_0_def_7 sorry
        also have "... = p"
           sorry
        finally have "(p *XCMPLX-0K3 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M) =HIDDENR1 p"
           sorry
        thus " |.COMPLEX1K10 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5 .| <XXREAL-0R3 p"
          using A15 A16 A17 A20 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5"
      using A4 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_23:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds ((seq9 be convergentSEQ-2V5 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6) & seq be non-zeroORDINAL1V9 implies seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq9 be convergentSEQ-2V5 & (seq be convergentSEQ-2V5 & (limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 & seq be non-zeroORDINAL1V9)) implies seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq9 be convergentSEQ-2V5"
      and A2: "seq be convergentSEQ-2V5"
      and A3: "limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
      and A4: "seq be non-zeroORDINAL1V9"
    have "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
      using A2 A3 A4 seq_2_th_21 sorry
    thus "seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_24:
" for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds ((seq9 be convergentSEQ-2V5 & seq be convergentSEQ-2V5) & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6) & seq be non-zeroORDINAL1V9 implies limSEQ-2K1 (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 (limSEQ-2K1 seq9)/XCMPLX-0K7 (limSEQ-2K1 seq)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq9 be Real-SequenceSEQ-1M1 holds seq9 be convergentSEQ-2V5 & (seq be convergentSEQ-2V5 & (limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 & seq be non-zeroORDINAL1V9)) implies limSEQ-2K1 (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 (limSEQ-2K1 seq9)/XCMPLX-0K7 (limSEQ-2K1 seq)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Real-SequenceSEQ-1M1"
    assume A1: "seq9 be convergentSEQ-2V5"
      and A2: "seq be convergentSEQ-2V5"
      and A3: "limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
      and A4: "seq be non-zeroORDINAL1V9"
    have "seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
      using A2 A3 A4 seq_2_th_21 sorry
    then have "limSEQ-2K1 (seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) =HIDDENR1 (limSEQ-2K1 seq9)*XCMPLX-0K3 (limSEQ-2K1 seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
      using A1 seq_2_th_15 sorry
    also have "... = (limSEQ-2K1 seq9)*XCMPLX-0K3 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5"
      using A2 A3 A4 seq_2_th_22 sorry
    also have "... = (limSEQ-2K1 seq9)/XCMPLX-0K7 (limSEQ-2K1 seq)"
      using xcmplx_0_def_9 sorry
    finally have "limSEQ-2K1 (seq9 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) =HIDDENR1 (limSEQ-2K1 seq9)/XCMPLX-0K7 (limSEQ-2K1 seq)"
       sorry
    thus "limSEQ-2K1 (seq9 /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 (limSEQ-2K1 seq9)/XCMPLX-0K7 (limSEQ-2K1 seq)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_25:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & seq1 be boundedSEQ-2V6) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6 implies seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (seq1 be boundedSEQ-2V6 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) implies seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq1 be boundedSEQ-2V6"
      and A3: "limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
    obtain g1 where 
      [ty]:"g1 be RealXREAL-0M1" and g1Def:"g1 = 0NUMBERSK6"
       sorry
    obtain g where 
      [ty]:"g be RealXREAL-0M1" and gDef:"g = g1"
       sorry
    have " ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A4: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A5: "0NUMBERSK6 <XXREAL-0R3 r"and A6: " for m be NatNAT-1M1 holds  |.COMPLEX1K10 seq1 .FUNCT-1K1 m.| <XXREAL-0R3 r"
        using A2 seq_2_th_3 sorry
      have A7: "0NUMBERSK6 <XXREAL-0R3 p /XCMPLX-0K7 r"
        using A4 A5 sorry
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A8: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p /XCMPLX-0K7 r"
        using A1 A3 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A9: "n <=XXREAL-0R1 m"
        have " |.COMPLEX1K10 seq .FUNCT-1K1 m.| =COMPLEX1R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .|"
           sorry
        then have A10: " |.COMPLEX1K10 seq .FUNCT-1K1 m.| <XXREAL-0R3 p /XCMPLX-0K7 r"
          using A8 A9 sorry
        have A11: " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 seq1 .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .|"
          using seq_1_th_8 sorry
        also have "... = ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|)"
          using complex1_th_65 sorry
        finally have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| =HIDDENR1 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|)"
           sorry
        have " |.COMPLEX1K10 seq1 .FUNCT-1K1 m.| <>HIDDENR2 0NUMBERSK6 implies  not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule impI)
          assume A12: " |.COMPLEX1K10 seq1 .FUNCT-1K1 m.| <>HIDDENR2 0NUMBERSK6"
          have "(p /XCMPLX-0K7 r)*XCMPLX-0K3 r =HIDDENR1 (p *XCMPLX-0K3 r \<inverse>XCMPLX-0K5)*XCMPLX-0K3 r"
            using xcmplx_0_def_9 sorry
          also have "... = p *XCMPLX-0K3 (r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 r)"
             sorry
          also have "... = p *XCMPLX-0K3 \<one>\<^sub>M"
            using A5 xcmplx_0_def_7 sorry
          also have "... = p"
             sorry
          finally have "(p /XCMPLX-0K7 r)*XCMPLX-0K3 r =HIDDENR1 p"
             sorry
          then have A13: "(p /XCMPLX-0K7 r)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|) <XXREAL-0R3 p"
            using A6 A7 xreal_1_th_68 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|"
            using complex1_th_46 sorry
          then have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 (p /XCMPLX-0K7 r)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|)"
            using A10 A11 A12 xreal_1_th_68 sorry
          thus " not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A13 xxreal_0_th_2 sorry
        qed
        thus " not  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
          using A4 A11 sorry
      qed "sorry"
    qed "sorry"
    thus "seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be convergentSEQ-2V5"
      using seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_26:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 & seq1 be boundedSEQ-2V6) & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6 implies limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & (seq1 be boundedSEQ-2V6 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6) implies limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "seq1 be boundedSEQ-2V6"
      and A3: "limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
    have A4: "seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 be convergentSEQ-2V5"
      using A1 A2 A3 seq_2_th_25 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A5: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A6: "0NUMBERSK6 <XXREAL-0R3 r"and A7: " for m be NatNAT-1M1 holds  |.COMPLEX1K10 seq1 .FUNCT-1K1 m.| <XXREAL-0R3 r"
        using A2 seq_2_th_3 sorry
      have A8: "0NUMBERSK6 <XXREAL-0R3 p /XCMPLX-0K7 r"
        using A5 A6 sorry
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A9: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p /XCMPLX-0K7 r"
        using A1 A3 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have A10: " |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p /XCMPLX-0K7 r"
          using A9 sorry
        have A11: " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1  |.COMPLEX1K10 seq .FUNCT-1K1 m *XCMPLX-0K3 seq1 .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .|"
          using seq_1_th_8 sorry
        also have "... = ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|)"
          using complex1_th_65 sorry
        finally have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1 ( |.COMPLEX1K10 seq .FUNCT-1K1 m.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|)"
           sorry
        have " |.COMPLEX1K10 seq1 .FUNCT-1K1 m.| <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
        proof(rule impI)
          assume A12: " |.COMPLEX1K10 seq1 .FUNCT-1K1 m.| <>HIDDENR2 0NUMBERSK6"
          have "(p /XCMPLX-0K7 r)*XCMPLX-0K3 r =HIDDENR1 (p *XCMPLX-0K3 r \<inverse>XCMPLX-0K5)*XCMPLX-0K3 r"
            using xcmplx_0_def_9 sorry
          also have "... = p *XCMPLX-0K3 (r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 r)"
             sorry
          also have "... = p *XCMPLX-0K3 \<one>\<^sub>M"
            using A6 xcmplx_0_def_7 sorry
          finally have "(p /XCMPLX-0K7 r)*XCMPLX-0K3 r =HIDDENR1 p *XCMPLX-0K3 \<one>\<^sub>M"
             sorry
          then have A13: "(p /XCMPLX-0K7 r)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|) <XXREAL-0R3 p"
            using A7 A8 xreal_1_th_68 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|"
            using complex1_th_46 sorry
          then have " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 (p /XCMPLX-0K7 r)*XCMPLX-0K3 ( |.COMPLEX1K10 seq1 .FUNCT-1K1 m.|)"
            using A10 A11 A12 xreal_1_th_68 sorry
          thus " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
            using A13 xxreal_0_th_2 sorry
        qed
        thus " |.COMPLEX1K10 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
          using A5 A11 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 0NUMBERSK6"
      using A4 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve g for "ComplexXCMPLX-0M1"
mtheorem seq_2_cl_10:
  mlet "s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.| as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.| implies it be convergentSEQ-2V5"
  proof-
    have " for VarFor1 be Real-SequenceSEQ-1M1 holds  not (VarFor1 =HIDDENR1  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.| &  not VarFor1 be convergentCOMSEQ-2V3)"
    proof-
      have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.| be convergentSEQ-2V5"
      proof-
        obtain g where
          [ty]:"g be ComplexXCMPLX-0M1" and 
          A1: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
          using comseq_2_def_5 sorry
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar42 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar42 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|).FUNCT-1K1 m -XCMPLX-0K6  |.COMPLEX1K10 g.| .| <XXREAL-0R3 p)"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A3: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A1 A2 sorry
          show " ex tVar42 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar42 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|).FUNCT-1K1 m -XCMPLX-0K6  |.COMPLEX1K10 g.| .| <XXREAL-0R3 p"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume "n <=XXREAL-0R1 m"
            then have " |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
              using A3 sorry
            then have " |.COMPLEX1K10  |.COMPLEX1K10 s .FUNCT-1K1 m.| -XCMPLX-0K6  |.COMPLEX1K10 g.| .| +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 p +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .|"
              using complex1_th_64 xreal_1_th_8 sorry
            then have "( |.COMPLEX1K10  |.COMPLEX1K10 s .FUNCT-1K1 m.| -XCMPLX-0K6  |.COMPLEX1K10 g.| .| +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .|)-XCMPLX-0K6  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .| <XXREAL-0R3 (p +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .|)-XCMPLX-0K6  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 g .|"
              using xreal_1_th_9 sorry
            thus " not  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|).FUNCT-1K1 m -XCMPLX-0K6  |.COMPLEX1K10 g.| .| <XXREAL-0R3 p"
              using valued_1_th_18 sorry
          qed "sorry"
        qed "sorry"
        thus " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.| be convergentSEQ-2V5"
          using bexI[of _ " |.COMPLEX1K10 g.|"] seq_2_def_6 sorry
      qed
      thus " for VarFor1 be Real-SequenceSEQ-1M1 holds  not (VarFor1 =HIDDENR1  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.| &  not VarFor1 be convergentCOMSEQ-2V3)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve s, s1, s9 for "Complex-SequenceCOMSEQ-1M1"
mtheorem seq_2_th_27:
" for s be Complex-SequenceCOMSEQ-1M1 holds s be convergentCOMSEQ-2V3 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
proof-
  have " for s be Complex-SequenceCOMSEQ-1M1 holds s be convergentCOMSEQ-2V3 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Complex-SequenceCOMSEQ-1M1"
    let ?g = "limCOMSEQ-2K3 s"
    assume A1: "s be convergentCOMSEQ-2V3"
    then obtain s1 where 
      [ty]:"s1 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1" and s1Def:"s1 = s"
       sorry
    obtain w where 
      [ty]:"w be Real-SequenceSEQ-1M1" and wDef:"w =  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s1.|"
       sorry
    have A2: "w be convergentSEQ-2V5"
       sorry
    obtain w where 
      [ty]:"w be RealXREAL-0M1" and wDef:"w =  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
       sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|).FUNCT-1K1 m -XCMPLX-0K6 w .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A3: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .| <XXREAL-0R3 p"
        using A1 A3 comseq_2_def_6 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|).FUNCT-1K1 m -XCMPLX-0K6 w .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have " |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .| <XXREAL-0R3 p"
          using A4 sorry
        then have " |.COMPLEX1K10  |.COMPLEX1K10 s .FUNCT-1K1 m.| -XCMPLX-0K6  |.COMPLEX1K10 ?g.| .| +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .| <XXREAL-0R3 p +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .|"
          using complex1_th_64 xreal_1_th_8 sorry
        then have "( |.COMPLEX1K10  |.COMPLEX1K10 s .FUNCT-1K1 m.| -XCMPLX-0K6  |.COMPLEX1K10 ?g.| .| +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .|)-XCMPLX-0K6  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .| <XXREAL-0R3 (p +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .|)-XCMPLX-0K6  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 ?g .|"
          using xreal_1_th_9 sorry
        thus " |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|).FUNCT-1K1 m -XCMPLX-0K6 w .| <XXREAL-0R3 p"
          using valued_1_th_18 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s.|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
      using A2 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_28:
" for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds  for s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 s +XCMPLX-0K2 limCOMSEQ-2K3 s9 .|"
proof-
  have " for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds  for s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 s +XCMPLX-0K2 limCOMSEQ-2K3 s9 .|"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    fix s9 assume [ty]: "s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 (s +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9) .|"
      using seq_2_th_27 sorry
    also have "... =  |.COMPLEX1K10 limCOMSEQ-2K3 s +XCMPLX-0K2 limCOMSEQ-2K3 s9 .|"
      using comseq_2_th_14 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 s +XCMPLX-0K2 limCOMSEQ-2K3 s9 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_29:
" for r be RealXREAL-0M1 holds  for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =COMPLEX1R1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
proof-
  have " for r be RealXREAL-0M1 holds  for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s) .|"
      using seq_2_th_27 sorry
    also have "... =  |.COMPLEX1K10 r *XCMPLX-0K3 (limCOMSEQ-2K3 s) .|"
      using comseq_2_th_18 sorry
    also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
      using complex1_th_65 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_30:
" for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
proof-
  have " for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
  proof(rule ballI)
    fix s assume [ty]: "s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s) .|"
      using seq_2_th_27 sorry
    also have "... =  |.COMPLEX1K10 -XCMPLX-0K4 limCOMSEQ-2K3 s .|"
      using comseq_2_th_22 sorry
    also have "... =  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
      using complex1_th_52 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 s .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_31:
" for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds  for s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =COMPLEX1R1  |.COMPLEX1K10 limCOMSEQ-2K3 s -XCMPLX-0K6 limCOMSEQ-2K3 s9 .|"
proof-
  have " for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds  for s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 s -XCMPLX-0K6 limCOMSEQ-2K3 s9 .|"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    fix s9 assume [ty]: "s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 (s -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9) .|"
      using seq_2_th_27 sorry
    also have "... =  |.COMPLEX1K10 limCOMSEQ-2K3 s -XCMPLX-0K6 limCOMSEQ-2K3 s9 .|"
      using comseq_2_th_26 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 s -XCMPLX-0K6 limCOMSEQ-2K3 s9 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_32:
" for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds  for s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =COMPLEX1R1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)"
proof-
  have " for s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds  for s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    fix s9 assume [ty]: "s9 be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
    have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 (s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9) .|"
      using seq_2_th_27 sorry
    also have "... =  |.COMPLEX1K10 (limCOMSEQ-2K3 s)*XCMPLX-0K3 (limCOMSEQ-2K3 s9) .|"
      using comseq_2_th_30 sorry
    also have "... = ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)"
      using complex1_th_65 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s9 .|) =HIDDENR1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)*XCMPLX-0K3 ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_33:
" for s be Complex-SequenceCOMSEQ-1M1 holds (s be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s <>HIDDENR2 0cCOMPLEX1K6) & s be non-zeroORDINAL1V9 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|) =COMPLEX1R1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)\<inverse>XCMPLX-0K5"
proof-
  have " for s be Complex-SequenceCOMSEQ-1M1 holds (s be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s <>HIDDENR2 0cCOMPLEX1K6) & s be non-zeroORDINAL1V9 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|) =HIDDENR1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Complex-SequenceCOMSEQ-1M1"
    assume A1: "(s be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 s <>HIDDENR2 0cCOMPLEX1K6) & s be non-zeroORDINAL1V9"
    then have "s \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be convergentCOMSEQ-2V3"
      using comseq_2_th_34 sorry
    then have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 s \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .|"
      using seq_2_th_27 sorry
    also have "... =  |.COMPLEX1K10 (limCOMSEQ-2K3 s)\<inverse>XCMPLX-0K5.|"
      using A1 comseq_2_th_35 sorry
    also have "... = ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)\<inverse>XCMPLX-0K5"
      using complex1_th_66 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|) =HIDDENR1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)\<inverse>XCMPLX-0K5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_34:
" for s be Complex-SequenceCOMSEQ-1M1 holds  for s9 be Complex-SequenceCOMSEQ-1M1 holds ((s9 be convergentCOMSEQ-2V3 & s be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s <>HIDDENR2 0cCOMPLEX1K6) & s be non-zeroORDINAL1V9 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s .|) =COMPLEX1R1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)/XCMPLX-0K7 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
proof-
  have " for s be Complex-SequenceCOMSEQ-1M1 holds  for s9 be Complex-SequenceCOMSEQ-1M1 holds ((s9 be convergentCOMSEQ-2V3 & s be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s <>HIDDENR2 0cCOMPLEX1K6) & s be non-zeroORDINAL1V9 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)/XCMPLX-0K7 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
  proof(rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be Complex-SequenceCOMSEQ-1M1"
    fix s9 assume [ty]: "s9 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "((s9 be convergentCOMSEQ-2V3 & s be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 s <>HIDDENR2 0cCOMPLEX1K6) & s be non-zeroORDINAL1V9"
    then have "s9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s be convergentCOMSEQ-2V3"
      using comseq_2_th_38 sorry
    then have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 (s9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s) .|"
      using seq_2_th_27 sorry
    also have "... =  |.COMPLEX1K10 (limCOMSEQ-2K3 s9)/XCMPLX-0K7 (limCOMSEQ-2K3 s) .|"
      using A1 comseq_2_th_39 sorry
    also have "... = ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)/XCMPLX-0K7 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
      using complex1_th_67 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s .|) =HIDDENR1 ( |.COMPLEX1K10 limCOMSEQ-2K3 s9 .|)/XCMPLX-0K7 ( |.COMPLEX1K10 limCOMSEQ-2K3 s .|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_2_th_35:
" for s be Complex-SequenceCOMSEQ-1M1 holds  for s1 be Complex-SequenceCOMSEQ-1M1 holds (s be convergentCOMSEQ-2V3 & s1 be boundedCOMSEQ-2V2) & limCOMSEQ-2K3 s =COMPLEX1R1 0cCOMPLEX1K6 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .|) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for s be Complex-SequenceCOMSEQ-1M1 holds  for s1 be Complex-SequenceCOMSEQ-1M1 holds (s be convergentCOMSEQ-2V3 & s1 be boundedCOMSEQ-2V2) & limCOMSEQ-2K3 s =COMPLEX1R1 0cCOMPLEX1K6 implies limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .|) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be Complex-SequenceCOMSEQ-1M1"
    fix s1 assume [ty]: "s1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "(s be convergentCOMSEQ-2V3 & s1 be boundedCOMSEQ-2V2) & limCOMSEQ-2K3 s =COMPLEX1R1 0cCOMPLEX1K6"
    then have "s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 be convergentCOMSEQ-2V3"
      using comseq_2_th_42 sorry
    then have "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .|) =HIDDENR1  |.COMPLEX1K10 limCOMSEQ-2K3 (s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1) .|"
      using seq_2_th_27 sorry
    also have "... = 0NUMBERSK6"
      using A1 complex1_th_44 comseq_2_th_43 sorry
    finally show "limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> s (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> s1 .|) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
