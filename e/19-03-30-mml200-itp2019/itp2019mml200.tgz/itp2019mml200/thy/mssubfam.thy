theory mssubfam
  imports setfam_1 pzfmisc1 pre_circ
begin
(*begin*)
mtheorem mssubfam_cl_1:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster domsFUNCT-6K1 F as-term-is I -definedRELAT-1V4"
proof
(*coherence*)
  show "domsFUNCT-6K1 F be I -definedRELAT-1V4"
  proof-
    have "domRELAT-1K1 (domsFUNCT-6K1 F) =HIDDENR1 domRELAT-1K1 F"
      using funct_6_th_59 sorry
    also have "... = I"
      using partfun1_def_2 sorry
    finally have "domRELAT-1K1 (domsFUNCT-6K1 F) =HIDDENR1 I"
       sorry
    thus "domsFUNCT-6K1 F be I -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_2:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster rngsFUNCT-6K2 F as-term-is I -definedRELAT-1V4"
proof
(*coherence*)
  show "rngsFUNCT-6K2 F be I -definedRELAT-1V4"
  proof-
    have "domRELAT-1K1 (rngsFUNCT-6K2 F) =HIDDENR1 domRELAT-1K1 F"
      using funct_6_th_60 sorry
    also have "... = I"
      using partfun1_def_2 sorry
    finally have "domRELAT-1K1 (rngsFUNCT-6K2 F) =HIDDENR1 I"
       sorry
    thus "rngsFUNCT-6K2 F be I -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_3:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster domsFUNCT-6K1 F as-term-is totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 domsFUNCT-6K1 F implies it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
  proof-
    have " for VarFor1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 domsFUNCT-6K1 F &  not VarFor1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>)"
    proof-
      have "domRELAT-1K1 (domsFUNCT-6K1 F) =HIDDENR1 domRELAT-1K1 F"
        using funct_6_th_59 sorry
      also have "... = I"
        using partfun1_def_2 sorry
      finally have "domRELAT-1K1 (domsFUNCT-6K1 F) =HIDDENR1 I"
         sorry
      thus " for VarFor1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 domsFUNCT-6K1 F &  not VarFor1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_4:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I"
"cluster rngsFUNCT-6K2 F as-term-is totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 rngsFUNCT-6K2 F implies it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
  proof-
    have " for VarFor1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 rngsFUNCT-6K2 F &  not VarFor1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>)"
    proof-
      have "domRELAT-1K1 (rngsFUNCT-6K2 F) =HIDDENR1 domRELAT-1K1 F"
        using funct_6_th_60 sorry
      also have "... = I"
        using partfun1_def_2 sorry
      finally have "domRELAT-1K1 (rngsFUNCT-6K2 F) =HIDDENR1 I"
         sorry
      thus " for VarFor1 be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 rngsFUNCT-6K2 F &  not VarFor1 be totalPARTFUN1V1\<^bsub>(I)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve I, G, H for "setHIDDENM2"
reserve i, x for "objectHIDDENM1"
reserve A, B, M for "ManySortedSetPBOOLEM1-of I"
reserve sf, sg, sh for "Subset-FamilySETFAM-1M1-of I"
reserve v, w for "SubsetSUBSET-1M2-of I"
reserve F for "ManySortedFunctionPBOOLEM2-of I"
theorem mssubfam_sch_1:
  fixes If0 Af0 Bf0 Pp3 
  assumes
[ty]: "If0 be setHIDDENM2" and
  [ty]: "Af0 be ManySortedSetPBOOLEM1-of If0" and
  [ty]: "Bf0 be ManySortedSetPBOOLEM1-of If0" and
   A1: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Bf0 .FUNCT-1K1 i & Pp3(y,x,i)))"
  shows " ex F be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( ex f be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f =FUNCT-1R1 F .FUNCT-1K1 i & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f .FUNCT-1K1 x,x,i)))"
  proof-
    have " ex tVar4 be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 & ( for f be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) holds  not (f =FUNCT-1R1 tVar4 .FUNCT-1K1 i & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 .FUNCT-1K1 i &  not Pp3(f .FUNCT-1K1 x,x,i))))))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 Lamb1,Bf0 .FUNCT-1K1 Lamb1) st f1 =HIDDENR1 Lamb2 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 Lamb1 implies Pp3(f1 .FUNCT-1K1 x,x,Lamb1))"
      have A2: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ( ex j be objectHIDDENM1 st  ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i)))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 If0"
        show " ex j be objectHIDDENM1 st  ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i))"
        proof-
          have cases: "Bf0 .FUNCT-1K1 i be  non emptyXBOOLE-0V1 or Bf0 .FUNCT-1K1 i be emptyXBOOLE-0V1"
             sorry
          have case1: "Bf0 .FUNCT-1K1 i be  non emptyXBOOLE-0V1 implies ( ex j be objectHIDDENM1 st  ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i)))"
          proof(rule impI)
            assume "Bf0 .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
            then obtain bb where 
              [ty]:"bb be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and bbDef:"bb = Bf0 .FUNCT-1K1 i"
               sorry
            let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2. Pp3(Lamb2,Lamb1,i)"
            have A4: " for e be objectHIDDENM1 holds e inHIDDENR3 Af0 .FUNCT-1K1 i implies ( ex u be objectHIDDENM1 st u inHIDDENR3 bb & ?Z(e,u))"
              using A1 A3 sorry
            obtain ff where
              [ty]:"ff be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,bb)" and 
              A5: " for e be objectHIDDENM1 holds e inHIDDENR3 Af0 .FUNCT-1K1 i implies ?Z(e,ff .FUNCT-1K1 e)"
              using funct_2_sch_1 A4 sorry
            obtain fff where 
              [ty]:"fff be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i)" and fffDef:"fff = ff"
               sorry
            obtain j where 
              [ty]:"j be objectHIDDENM1" and jDef:"j = fff"
               sorry
            show " ex j be objectHIDDENM1 st  ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i))"
            proof(rule bexI[of _ "j"])
              show " ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i))"
                using A5 sorry
            qed "sorry"
          qed
          have case2: "Bf0 .FUNCT-1K1 i be emptyXBOOLE-0V1 implies ( ex j be objectHIDDENM1 st  ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i)))"
          proof(rule impI)
            assume A6: "Bf0 .FUNCT-1K1 i be emptyXBOOLE-0V1"
            have A7: " for x be objectHIDDENM1 holds  not x inHIDDENR3 Af0 .FUNCT-1K1 i"
            proof(rule ballI)
              fix x assume [ty]: "x be objectHIDDENM1"
              have " for y be objectHIDDENM1 holds  not (y inHIDDENR3 Bf0 .FUNCT-1K1 i & Pp3(y,x,i))"
                using A6 sorry
              thus " not x inHIDDENR3 Af0 .FUNCT-1K1 i"
                using A1 A3 sorry
            qed "sorry"
            then have "Af0 .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
              using xboole_0_def_1 sorry
            then obtain fff where 
              [ty]:"fff be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i)" and fffDef:"fff = {}XBOOLE-0K1"
              using relset_1_th_12 sorry
            obtain j where 
              [ty]:"j be objectHIDDENM1" and jDef:"j = fff"
               sorry
            show " ex j be objectHIDDENM1 st  ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i))"
            proof(rule bexI[of _ "j"])
              show " ex f1 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f1 =HIDDENR1 j & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f1 .FUNCT-1K1 x,x,i))"
              proof-
                have " ex tVar3 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st tVar3 =HIDDENR1 j & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 .FUNCT-1K1 i &  not Pp3(tVar3 .FUNCT-1K1 x,x,i)))"
                proof-
                  show " ex tVar3 be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st tVar3 =HIDDENR1 j & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 .FUNCT-1K1 i &  not Pp3(tVar3 .FUNCT-1K1 x,x,i)))"
                  proof(rule bexI[of _ "fff"],rule conjMI)
                    show "fff =HIDDENR1 j"
                       sorry
                    show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 .FUNCT-1K1 i &  not Pp3(fff .FUNCT-1K1 x,x,i))"
                      using A7 sorry
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      obtain F where
        [ty]:"F be ManySortedSetPBOOLEM1-of If0" and 
        A8: " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies ?Q(i,F .FUNCT-1K1 i)"
        using pboole_sch_3 A2 sorry
      have "F be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0)"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 If0 implies F .FUNCT-1K1 i be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i :])"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 If0"
          then have " ex f be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) st f =XBOOLE-0R4 F .FUNCT-1K1 i & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 .FUNCT-1K1 i implies Pp3(f .FUNCT-1K1 x,x,i))"
            using A8 sorry
          thus "F .FUNCT-1K1 i be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i :])"
             sorry
        qed "sorry"
        thus "F be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0)"
          using pboole_def_15 sorry
      qed
      then have 
        [ty]:"F be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0)"
         sorry
      show " ex tVar4 be ManySortedFunctionPBOOLEM5\<^bsub>(If0)\<^esub>-of(Af0,Bf0) st  for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 & ( for f be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) holds  not (f =FUNCT-1R1 tVar4 .FUNCT-1K1 i & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 .FUNCT-1K1 i &  not Pp3(f .FUNCT-1K1 x,x,i))))))"
      proof(rule bexI[of _ "F"])
        show " for i be objectHIDDENM1 holds  not (i inHIDDENR3 If0 & ( for f be FunctionFUNCT-2M1-of(Af0 .FUNCT-1K1 i,Bf0 .FUNCT-1K1 i) holds  not (f =FUNCT-1R1 F .FUNCT-1K1 i & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 .FUNCT-1K1 i &  not Pp3(f .FUNCT-1K1 x,x,i))))))"
          using A8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem mssubfam_th_1:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds sf <>HIDDENR2 {}XBOOLE-0K1 implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 unionSETFAM-1K5\<^bsub>(I)\<^esub> sf"
proof-
  have " for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds sf <>HIDDENR2 {}XBOOLE-0K1 implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 unionSETFAM-1K5\<^bsub>(I)\<^esub> sf"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    assume "sf <>HIDDENR2 {}XBOOLE-0K1"
    then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
      using setfam_1_def_9 sorry
    thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 unionSETFAM-1K5\<^bsub>(I)\<^esub> sf"
      using setfam_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_2:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 G"
proof-
  have " for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 G"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix G assume [ty]: "G be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    assume A1: "G inTARSKIR2 sf"
    then have "meetSETFAM-1K6\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
      using setfam_1_def_9 sorry
    thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 G"
      using A1 setfam_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_3:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds {}XBOOLE-0K1 inTARSKIR2 sf implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds {}XBOOLE-0K1 inTARSKIR2 sf implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    assume A1: "{}XBOOLE-0K1 inTARSKIR2 sf"
    then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
      using setfam_1_def_9 sorry
    thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 setfam_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_4:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for Z be SubsetSUBSET-1M2-of I holds ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies Z c=TARSKIR1 Z1) implies Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
proof-
  have " for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for Z be SubsetSUBSET-1M2-of I holds ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies Z c=TARSKIR1 Z1) implies Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of I"
    assume A1: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies Z c=TARSKIR1 Z1"
    show "Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
    proof-
      have cases: "sf <>HIDDENR2 {}XBOOLE-0K1 or sf =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have case1: "sf <>HIDDENR2 {}XBOOLE-0K1 implies Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
      proof(rule impI)
        assume A2: "sf <>HIDDENR2 {}XBOOLE-0K1"
        then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
          using setfam_1_def_9 sorry
        thus "Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
          using A1 A2 setfam_1_th_5 sorry
      qed
      have case2: "sf =XBOOLE-0R4 {}XBOOLE-0K1 implies Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
      proof(rule impI)
        assume "sf =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 I"
          using setfam_1_def_9 sorry
        thus "Z c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_5:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds sf <>HIDDENR2 {}XBOOLE-0K1 & ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies G c=TARSKIR1 Z1) implies G c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
proof-
  have " for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds sf <>HIDDENR2 {}XBOOLE-0K1 & ( for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies G c=TARSKIR1 Z1) implies G c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix G assume [ty]: "G be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    assume A1: "sf <>HIDDENR2 {}XBOOLE-0K1"
      and A2: " for Z1 be setHIDDENM2 holds Z1 inTARSKIR2 sf implies G c=TARSKIR1 Z1"
    have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
      using A1 setfam_1_def_9 sorry
    thus "G c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf"
      using A1 A2 setfam_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_6:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for H be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf & G c=TARSKIR1 H implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 H"
proof-
  have " for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for H be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf & G c=TARSKIR1 H implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 H"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix G assume [ty]: "G be setHIDDENM2"
    fix H assume [ty]: "H be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    assume A1: "G inTARSKIR2 sf"
      and A2: "G c=TARSKIR1 H"
    have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
      using A1 setfam_1_def_9 sorry
    thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf c=TARSKIR1 H"
      using A1 A2 setfam_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_7:
" for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for H be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf & G missesXBOOLE-0R1 H implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf missesXBOOLE-0R1 H"
proof-
  have " for I be setHIDDENM2 holds  for G be setHIDDENM2 holds  for H be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds G inTARSKIR2 sf & G missesXBOOLE-0R1 H implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf missesXBOOLE-0R1 H"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix G assume [ty]: "G be setHIDDENM2"
    fix H assume [ty]: "H be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    assume A1: "G inTARSKIR2 sf"
      and A2: "G missesXBOOLE-0R1 H"
    have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
      using A1 setfam_1_def_9 sorry
    thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf missesXBOOLE-0R1 H"
      using A1 A2 setfam_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_8:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for sg be Subset-FamilySETFAM-1M1-of I holds  for sh be Subset-FamilySETFAM-1M1-of I holds sh =XBOOLE-0R4 sf \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 I)\<^esub> sg implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
proof-
  have " for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for sg be Subset-FamilySETFAM-1M1-of I holds  for sh be Subset-FamilySETFAM-1M1-of I holds sh =XBOOLE-0R4 sf \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 I)\<^esub> sg implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    fix sg assume [ty]: "sg be Subset-FamilySETFAM-1M1-of I"
    fix sh assume [ty]: "sh be Subset-FamilySETFAM-1M1-of I"
    assume A1: "sh =XBOOLE-0R4 sf \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 I)\<^esub> sg"
    show "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
    proof-
      have cases: "((sf =XBOOLE-0R4 {}XBOOLE-0K1 & sg =XBOOLE-0R4 {}XBOOLE-0K1 or sf <>HIDDENR2 {}XBOOLE-0K1 & sg =XBOOLE-0R4 {}XBOOLE-0K1) or sf =XBOOLE-0R4 {}XBOOLE-0K1 & sg <>HIDDENR2 {}XBOOLE-0K1) or sf <>HIDDENR2 {}XBOOLE-0K1 & sg <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "sf =XBOOLE-0R4 {}XBOOLE-0K1 & sg =XBOOLE-0R4 {}XBOOLE-0K1 implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
      proof(rule impI)
        assume "sf =XBOOLE-0R4 {}XBOOLE-0K1 & sg =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
          using A1 sorry
      qed
      have case2: "sf <>HIDDENR2 {}XBOOLE-0K1 & sg =XBOOLE-0R4 {}XBOOLE-0K1 implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =HIDDENR1 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
      proof(rule impI)
        assume A2: "sf <>HIDDENR2 {}XBOOLE-0K1 & sg =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =HIDDENR1 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
          using A1 setfam_1_def_9 sorry
        also have "... = meetSETFAM-1K6\<^bsub>(I)\<^esub> sf /\\SUBSET-1K8\<^bsub>(I)\<^esub> I"
          using xboole_1_th_28 sorry
        also have "... = (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K8\<^bsub>(I)\<^esub> I"
          using A2 setfam_1_def_9 sorry
        also have "... = (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
          using A2 setfam_1_def_9 sorry
        finally show "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =HIDDENR1 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
           sorry
      qed
      have case3: "sf =XBOOLE-0R4 {}XBOOLE-0K1 & sg <>HIDDENR2 {}XBOOLE-0K1 implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =HIDDENR1 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
      proof(rule impI)
        assume A3: "sf =XBOOLE-0R4 {}XBOOLE-0K1 & sg <>HIDDENR2 {}XBOOLE-0K1"
        then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =HIDDENR1 meetSETFAM-1K6\<^bsub>(I)\<^esub> sg"
          using A1 setfam_1_def_9 sorry
        also have "... = I /\\SUBSET-1K9\<^bsub>(I)\<^esub> meetSETFAM-1K6\<^bsub>(I)\<^esub> sg"
          using xboole_1_th_28 sorry
        also have "... = I /\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
          using A3 setfam_1_def_9 sorry
        also have "... = (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
          using A3 setfam_1_def_9 sorry
        finally show "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =HIDDENR1 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
           sorry
      qed
      have case4: "sf <>HIDDENR2 {}XBOOLE-0K1 & sg <>HIDDENR2 {}XBOOLE-0K1 implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
      proof(rule impI)
        assume A4: "sf <>HIDDENR2 {}XBOOLE-0K1 & sg <>HIDDENR2 {}XBOOLE-0K1"
        then have A5: "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sg"
          using setfam_1_def_9 sorry
        have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sh & IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
          using A1 A4 setfam_1_def_9 sorry
        thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sh =XBOOLE-0R4 (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf)/\\SUBSET-1K9\<^bsub>(I)\<^esub> (IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sg)"
          using A1 A4 A5 setfam_1_th_9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_9:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for v be SubsetSUBSET-1M2-of I holds sf =XBOOLE-0R4 {TARSKIK1 v} implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v"
proof-
  have " for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for v be SubsetSUBSET-1M2-of I holds sf =XBOOLE-0R4 {TARSKIK1 v} implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    fix v assume [ty]: "v be SubsetSUBSET-1M2-of I"
    assume A1: "sf =XBOOLE-0R4 {TARSKIK1 v}"
    then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
      using setfam_1_def_9 sorry
    thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v"
      using A1 setfam_1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_10:
" for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for v be SubsetSUBSET-1M2-of I holds  for w be SubsetSUBSET-1M2-of I holds sf =XBOOLE-0R4 {TARSKIK2 v,w } implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v /\\SUBSET-1K9\<^bsub>(I)\<^esub> w"
proof-
  have " for I be setHIDDENM2 holds  for sf be Subset-FamilySETFAM-1M1-of I holds  for v be SubsetSUBSET-1M2-of I holds  for w be SubsetSUBSET-1M2-of I holds sf =XBOOLE-0R4 {TARSKIK2 v,w } implies IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v /\\SUBSET-1K9\<^bsub>(I)\<^esub> w"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix sf assume [ty]: "sf be Subset-FamilySETFAM-1M1-of I"
    fix v assume [ty]: "v be SubsetSUBSET-1M2-of I"
    fix w assume [ty]: "w be SubsetSUBSET-1M2-of I"
    assume A1: "sf =XBOOLE-0R4 {TARSKIK2 v,w }"
    then have "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(I)\<^esub> sf"
      using setfam_1_def_9 sorry
    thus "IntersectSETFAM-1K8\<^bsub>(I)\<^esub> sf =XBOOLE-0R4 v /\\SUBSET-1K9\<^bsub>(I)\<^esub> w"
      using A1 setfam_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_11:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> B implies A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> B implies A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      thus "A .FUNCT-1K1 i be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
        using A1 sorry
    qed "sorry"
    thus "A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B"
      using pboole_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_12:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B implies A inPBOOLER1\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B implies A inPBOOLER1\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: "A be ElementPBOOLEM4\<^bsub>(I)\<^esub>-of B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i inTARSKIR2 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have A3: "B .FUNCT-1K1 i <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have "A .FUNCT-1K1 i be ElementSUBSET-1M1-of B .FUNCT-1K1 i"
        using A1 A2 pboole_def_14 sorry
      thus "A .FUNCT-1K1 i inTARSKIR2 B .FUNCT-1K1 i"
        using A3 sorry
    qed "sorry"
    thus "A inPBOOLER1\<^bsub>(I)\<^esub> B"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_13:
" for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for f be FunctionFUNCT-1M1 holds i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies rngsFUNCT-6K2 F .FUNCT-1K1 i =XBOOLE-0R4 rngFUNCT-1K2 f"
proof-
  have " for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for f be FunctionFUNCT-1M1 holds i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies rngsFUNCT-6K2 F .FUNCT-1K1 i =XBOOLE-0R4 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix i assume [ty]: "i be objectHIDDENM1"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM2-of I"
    have A1: "domRELAT-1K1 F =XBOOLE-0R4 I"
      using partfun1_def_2 sorry
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i"
    thus "rngsFUNCT-6K2 F .FUNCT-1K1 i =XBOOLE-0R4 rngFUNCT-1K2 f"
      using A1 funct_6_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_14:
" for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for f be FunctionFUNCT-1M1 holds i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies domsFUNCT-6K1 F .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 f"
proof-
  have " for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for f be FunctionFUNCT-1M1 holds i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies domsFUNCT-6K1 F .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix i assume [ty]: "i be objectHIDDENM1"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM2-of I"
    have A1: "domRELAT-1K1 F =XBOOLE-0R4 I"
      using partfun1_def_2 sorry
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "i inHIDDENR3 I & f =FUNCT-1R1 F .FUNCT-1K1 i"
    thus "domsFUNCT-6K1 F .FUNCT-1K1 i =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 funct_6_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_15:
" for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for G be ManySortedFunctionPBOOLEM2-of I holds G **PBOOLEK8 F be ManySortedFunctionPBOOLEM2-of I"
proof-
  have " for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for G be ManySortedFunctionPBOOLEM2-of I holds G **PBOOLEK8 F be ManySortedFunctionPBOOLEM2-of I"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM2-of I"
    fix G assume [ty]: "G be ManySortedFunctionPBOOLEM2-of I"
    have "domRELAT-1K1 (G **PBOOLEK8 F) =HIDDENR1 domRELAT-1K1 F /\\XBOOLE-0K3 domRELAT-1K1 G"
      using pboole_def_19 sorry
    also have "... = I /\\XBOOLE-0K3 domRELAT-1K1 G"
      using partfun1_def_2 sorry
    also have "... = I /\\XBOOLE-0K3 I"
      using partfun1_def_2 sorry
    also have "... = I"
       sorry
    finally have "domRELAT-1K1 (G **PBOOLEK8 F) =HIDDENR1 I"
       sorry
    thus "G **PBOOLEK8 F be ManySortedFunctionPBOOLEM2-of I"
      using partfun1_def_2 relat_1_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_16:
" for I be setHIDDENM2 holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,EmptyMSPBOOLEK1 I) holds F =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,EmptyMSPBOOLEK1 I) holds F =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,EmptyMSPBOOLEK1 I)"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies F .FUNCT-1K1 i =FUNCT-1R1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,EmptyMSPBOOLEK1 I .FUNCT-1K1 i)" and fDef:"f = F .FUNCT-1K1 i"
        using pboole_def_15 sorry
      have "f =FUNCT-1R1 {}XBOOLE-0K1"
         sorry
      thus "F .FUNCT-1K1 i =FUNCT-1R1 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "F =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_17:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM2-of I holds A is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B & F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B) implies domsFUNCT-6K1 F =PBOOLER7\<^bsub>(I)\<^esub> A & rngsFUNCT-6K2 F c=PBOOLER2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM2-of I holds A is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B & F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B) implies domsFUNCT-6K1 F =PBOOLER7\<^bsub>(I)\<^esub> A & rngsFUNCT-6K2 F c=PBOOLER2\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM2-of I"
    assume A1: "A is-transformable-toPZFMISC1R1\<^bsub>(I)\<^esub> B"
      and A2: "F be ManySortedFunctionPBOOLEM5\<^bsub>(I)\<^esub>-of(A,B)"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies domsFUNCT-6K1 F .FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)" and fDef:"f = F .FUNCT-1K1 i"
        using A2 pboole_def_15 sorry
      have A4: "B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1 implies A .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
        using A1 A3 pzfmisc1_def_3 sorry
      have "domsFUNCT-6K1 F .FUNCT-1K1 i =HIDDENR1 domRELAT-1K1 f"
        using A3 mssubfam_th_14 sorry
      also have "... = A .FUNCT-1K1 i"
        using A4 funct_2_def_1 sorry
      finally show "domsFUNCT-6K1 F .FUNCT-1K1 i =HIDDENR1 A .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "domsFUNCT-6K1 F =PBOOLER7\<^bsub>(I)\<^esub> A"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies rngsFUNCT-6K2 F .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A5: "i inHIDDENR3 I"
      then obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(A .FUNCT-1K1 i,B .FUNCT-1K1 i)" and fDef:"f = F .FUNCT-1K1 i"
        using A2 pboole_def_15 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 B .FUNCT-1K1 i"
        using relat_1_def_19 sorry
      thus "rngsFUNCT-6K2 F .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A5 mssubfam_th_13 sorry
    qed "sorry"
    thus "rngsFUNCT-6K2 F c=PBOOLER2\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem mssubfam_cl_5:
  mlet "I be setHIDDENM2"
"cluster empty-yieldingRELAT-1V3 also-is finite-yieldingFINSET-1V3 for ManySortedSetPBOOLEM1-of I"
proof
(*coherence*)
  show " for it be ManySortedSetPBOOLEM1-of I holds it be empty-yieldingRELAT-1V3 implies it be finite-yieldingFINSET-1V3"
  proof-
    have " for A be ManySortedSetPBOOLEM1-of I holds A be empty-yieldingRELAT-1V3 implies A be finite-yieldingFINSET-1V3"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
      assume A1: "A be empty-yieldingRELAT-1V3"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        obtain B where 
          [ty]:"B be emptyXBOOLE-0V1\<bar>setHIDDENM2" and BDef:"B = A .FUNCT-1K1 i"
          using A1 sorry
        have "B be finiteFINSET-1V1"
           sorry
        thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
           sorry
      qed "sorry"
      thus "A be finite-yieldingFINSET-1V3"
        using finset_1_def_5 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_6:
  mlet "I be setHIDDENM2"
"cluster EmptyMSPBOOLEK1 I as-term-is empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
     sorry
qed "sorry"

mtheorem mssubfam_cl_7:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I"
"cluster empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3 for ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A"
proof
(*existence*)
  show " ex it be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A st it be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
  proof-
    have " ex tVar5 be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A st tVar5 be empty-yieldingRELAT-1V3 & tVar5 be finite-yieldingFINSET-1V3"
    proof-
      let ?x = "EmptyMSPBOOLEK1 I"
      have "?x c=PBOOLER2\<^bsub>(I)\<^esub> A"
        using pboole_th_43 sorry
      then obtain x where 
        [ty]:"x be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A" and xDef:"x = ?x"
        using pboole_def_18 sorry
      show " ex tVar5 be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A st tVar5 be empty-yieldingRELAT-1V3 & tVar5 be finite-yieldingFINSET-1V3"
      proof(rule bexI[of _ "x"])
        show "x be empty-yieldingRELAT-1V3 & x be finite-yieldingFINSET-1V3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_th_18:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B & B be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> B & B be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "A c=PBOOLER2\<^bsub>(I)\<^esub> B & B be finite-yieldingFINSET-1V3"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "A .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i & B .FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 sorry
      thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
         sorry
    qed "sorry"
    thus "A be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_cl_8:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster note-that finite-yieldingFINSET-1V3 for ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A"
proof
(*coherence*)
  show " for it be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of A holds it be finite-yieldingFINSET-1V3"
    using pboole_def_18 mssubfam_th_18 sorry
qed "sorry"

mtheorem mssubfam_cl_9:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "A .FUNCT-1K1 i \\/XBOOLE-0K2 B .FUNCT-1K1 i be finiteFINSET-1V1"
         sorry
      thus "(A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B).FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 pboole_def_4 sorry
    qed "sorry"
    thus "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_10:
  mlet "I be setHIDDENM2", "A be ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i be finiteFINSET-1V1"
         sorry
      thus "(A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 pboole_def_5 sorry
    qed "sorry"
    thus "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_11:
  mlet "I be setHIDDENM2", "B be ManySortedSetPBOOLEM1-of I", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
     sorry
qed "sorry"

mtheorem mssubfam_cl_12:
  mlet "I be setHIDDENM2", "B be ManySortedSetPBOOLEM1-of I", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B).FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "A .FUNCT-1K1 i \\SUBSET-1K6 B .FUNCT-1K1 i be finiteFINSET-1V1"
         sorry
      thus "(A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B).FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 pboole_def_6 sorry
    qed "sorry"
    thus "A (\\)PBOOLEK4\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_13:
  mlet "I be setHIDDENM2", "F be ManySortedFunctionPBOOLEM2-of I", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A).FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      obtain f where 
        [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F .FUNCT-1K1 i"
         sorry
      have "f .:FUNCT-1K5 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
         sorry
      thus "(F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A).FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 pboole_def_20 sorry
    qed "sorry"
    thus "F .:.:PBOOLEK9\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_14:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      have "[:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :] be finiteFINSET-1V1"
         sorry
      thus "([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 pboole_def_16 sorry
    qed "sorry"
    thus "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed
qed "sorry"

mtheorem mssubfam_th_19:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds B be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds B be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "B be non-emptyRELAT-1V2"
      and A2: "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      have "([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i be finiteFINSET-1V1"
        using A2 sorry
      then have "[:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :] be finiteFINSET-1V1"
        using A3 pboole_def_16 sorry
      thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 A3 sorry
    qed "sorry"
    thus "A be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_20:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3 implies B be finite-yieldingFINSET-1V3"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A be non-emptyRELAT-1V2 & [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3 implies B be finite-yieldingFINSET-1V3"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A1: "A be non-emptyRELAT-1V2"
      and A2: "[|PBOOLEK6\<^bsub>(I)\<^esub> A,B |] be finite-yieldingFINSET-1V3"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies B .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      have "([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i be finiteFINSET-1V1"
        using A2 sorry
      then have "[:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :] be finiteFINSET-1V1"
        using A3 pboole_def_16 sorry
      thus "B .FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 A3 sorry
    qed "sorry"
    thus "B be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_21:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds A be finite-yieldingFINSET-1V3 iff boolMBOOLEANK1\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds (A be finite-yieldingFINSET-1V3 implies boolMBOOLEANK1\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3) & (boolMBOOLEANK1\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    show "A be finite-yieldingFINSET-1V3 implies boolMBOOLEANK1\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
    proof(rule impI)
      assume A1: "A be finite-yieldingFINSET-1V3"
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be finiteFINSET-1V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        have "A .FUNCT-1K1 i be finiteFINSET-1V1"
          using A1 sorry
        then have "boolSETFAM-1K9 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
           sorry
        thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be finiteFINSET-1V1"
          using A2 mboolean_def_1 sorry
      qed "sorry"
      thus "boolMBOOLEANK1\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
        using finset_1_def_5 sorry
    qed
    assume A3: "boolMBOOLEANK1\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      have "boolMBOOLEANK1\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be finiteFINSET-1V1"
        using A3 sorry
      then have "boolSETFAM-1K9 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
        using A4 mboolean_def_1 sorry
      thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
         sorry
    qed "sorry"
    thus "A be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_cl_15:
  mlet "I be setHIDDENM2", "M be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> M as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> M be finite-yieldingFINSET-1V3"
    using mssubfam_th_21 sorry
qed "sorry"

mtheorem mssubfam_th_22:
" for I be setHIDDENM2 holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds A be finite-yieldingFINSET-1V3 & ( for M be ManySortedSetPBOOLEM1-of I holds M inPBOOLER1\<^bsub>(I)\<^esub> A implies M be finite-yieldingFINSET-1V3) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
proof-
  have " for I be setHIDDENM2 holds  for A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I holds A be finite-yieldingFINSET-1V3 & ( for M be ManySortedSetPBOOLEM1-of I holds M inPBOOLER1\<^bsub>(I)\<^esub> A implies M be finite-yieldingFINSET-1V3) implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be non-emptyRELAT-1V2\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: "A be finite-yieldingFINSET-1V3"
      and A2: " for M be ManySortedSetPBOOLEM1-of I holds M inPBOOLER1\<^bsub>(I)\<^esub> A implies M be finite-yieldingFINSET-1V3"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      have A4: " for X9 be setHIDDENM2 holds X9 inTARSKIR2 A .FUNCT-1K1 i implies X9 be finiteFINSET-1V1"
      proof(rule ballI,rule impI)
        obtain M where
          [ty]:"M be ManySortedSetPBOOLEM1-of I" and 
          A5: "M inPBOOLER1\<^bsub>(I)\<^esub> A"
          using pboole_th_134 sorry
        fix X9 assume [ty]: "X9 be setHIDDENM2"
        assume A6: "X9 inTARSKIR2 A .FUNCT-1K1 i"
        have "domRELAT-1K1 (M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)) =XBOOLE-0R4 I"
          using A3 pzfmisc1_th_1 sorry
        then obtain K where 
          [ty]:"K be ManySortedSetPBOOLEM1-of I" and KDef:"K = M +*FUNCT-4K1 (i .-->FUNCOP-1K17 X9)"
          using partfun1_def_2 relat_1_def_18 sorry
        have A7: "domRELAT-1K1 (i .-->FUNCOP-1K17 X9) =XBOOLE-0R4 {TARSKIK1 i}"
          using funcop_1_th_13 sorry
        have "i inHIDDENR3 {TARSKIK1 i}"
          using tarski_def_1 sorry
        then have A8: "K .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 X9).FUNCT-1K1 i"
          using A7 funct_4_th_13 sorry
        also have "... = X9"
          using funcop_1_th_72 sorry
        finally have "K .FUNCT-1K1 i =HIDDENR1 X9"
           sorry
        have "K inPBOOLER1\<^bsub>(I)\<^esub> A"
        proof-
          have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
          proof(rule ballI,rule impI)
            fix j assume [ty]: "j be objectHIDDENM1"
            assume A9: "j inHIDDENR3 I"
            have "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j)"
            proof-
              show "j =HIDDENR1 i & K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j)"
              proof-
                have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                   sorry
                have case1: "j =HIDDENR1 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j =HIDDENR1 i"
                  thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A6 A8 sorry
                qed
                have case2: "j <>HIDDENR2 i implies K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                proof(rule impI)
                  assume "j <>HIDDENR2 i"
                  then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 X9)"
                    using A7 tarski_def_1 sorry
                  then have "K .FUNCT-1K1 j =XBOOLE-0R4 M .FUNCT-1K1 j"
                    using funct_4_th_11 sorry
                  thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
                    using A5 A9 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "K .FUNCT-1K1 j inTARSKIR2 A .FUNCT-1K1 j"
               sorry
          qed "sorry"
          thus "K inPBOOLER1\<^bsub>(I)\<^esub> A"
            using pboole_def_1 sorry
        qed
        then have "K be finite-yieldingFINSET-1V3"
          using A2 sorry
        thus "X9 be finiteFINSET-1V1"
          using A8 sorry
      qed "sorry"
      have "A .FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 sorry
      then have "unionTARSKIK3 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
        using A4 finset_1_th_7 sorry
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be finiteFINSET-1V1"
        using A3 mboolean_def_2 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_23:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3 & ( for M be ManySortedSetPBOOLEM1-of I holds M inPBOOLER1\<^bsub>(I)\<^esub> A implies M be finite-yieldingFINSET-1V3)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3 implies A be finite-yieldingFINSET-1V3 & ( for M be ManySortedSetPBOOLEM1-of I holds M inPBOOLER1\<^bsub>(I)\<^esub> A implies M be finite-yieldingFINSET-1V3)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    assume A1: "unionMBOOLEANK2\<^bsub>(I)\<^esub> A be finite-yieldingFINSET-1V3"
    show "A be finite-yieldingFINSET-1V3"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A2: "i inHIDDENR3 I"
        have "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be finiteFINSET-1V1"
          using A1 sorry
        then have "unionTARSKIK3 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
          using A2 mboolean_def_2 sorry
        thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
          using finset_1_th_7 sorry
      qed "sorry"
      thus "A be finite-yieldingFINSET-1V3"
        using finset_1_def_5 sorry
    qed
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    assume A3: "M inPBOOLER1\<^bsub>(I)\<^esub> A"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies M .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A4: "i inHIDDENR3 I"
      have "unionMBOOLEANK2\<^bsub>(I)\<^esub> A .FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 sorry
      then have A5: "unionTARSKIK3 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
        using A4 mboolean_def_2 sorry
      have "M .FUNCT-1K1 i inTARSKIR2 A .FUNCT-1K1 i"
        using A3 A4 sorry
      thus "M .FUNCT-1K1 i be finiteFINSET-1V1"
        using A5 finset_1_th_7 sorry
    qed "sorry"
    thus "M be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_24:
" for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds domsFUNCT-6K1 F be finite-yieldingFINSET-1V3 implies rngsFUNCT-6K2 F be finite-yieldingFINSET-1V3"
proof-
  have " for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds domsFUNCT-6K1 F be finite-yieldingFINSET-1V3 implies rngsFUNCT-6K2 F be finite-yieldingFINSET-1V3"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM2-of I"
    assume A1: "domsFUNCT-6K1 F be finite-yieldingFINSET-1V3"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies rngsFUNCT-6K2 F .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      obtain f where 
        [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F .FUNCT-1K1 i"
         sorry
      have "domsFUNCT-6K1 F .FUNCT-1K1 i be finiteFINSET-1V1"
        using A1 sorry
      then have "domRELAT-1K1 f be finiteFINSET-1V1"
        using A2 mssubfam_th_14 sorry
      then have "rngFUNCT-1K2 f be finiteFINSET-1V1"
        using finset_1_th_8 sorry
      thus "rngsFUNCT-6K2 F .FUNCT-1K1 i be finiteFINSET-1V1"
        using A2 mssubfam_th_13 sorry
    qed "sorry"
    thus "rngsFUNCT-6K2 F be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_25:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM2-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F & ( for i be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies f \<inverse>FUNCT-1K6 (A .FUNCT-1K1 i) be finiteFINSET-1V1) implies A be finite-yieldingFINSET-1V3"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for F be ManySortedFunctionPBOOLEM2-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F & ( for i be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies f \<inverse>FUNCT-1K6 (A .FUNCT-1K1 i) be finiteFINSET-1V1) implies A be finite-yieldingFINSET-1V3"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM2-of I"
    assume A1: "A c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F"
      and A2: " for i be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds i inTARSKIR2 I & f =FUNCT-1R1 F .FUNCT-1K1 i implies f \<inverse>FUNCT-1K6 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      obtain f where 
        [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F .FUNCT-1K1 i"
         sorry
      have "rngsFUNCT-6K2 F .FUNCT-1K1 i =XBOOLE-0R4 rngFUNCT-1K2 f"
        using A3 mssubfam_th_13 sorry
      then have A4: "A .FUNCT-1K1 i c=TARSKIR1 rngFUNCT-1K2 f"
        using A1 A3 sorry
      have "f \<inverse>FUNCT-1K6 (A .FUNCT-1K1 i) be finiteFINSET-1V1"
        using A2 A3 sorry
      thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
        using A4 finset_1_th_9 sorry
    qed "sorry"
    thus "A be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_cl_16:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster (Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "(Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) be finite-yieldingFINSET-1V3"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ((Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B)).FUNCT-1K1 i be finiteFINSET-1V1"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have "((Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B)).FUNCT-1K1 i =XBOOLE-0R4 FuncsFUNCT-2K1(A .FUNCT-1K1 i,B .FUNCT-1K1 i) & A .FUNCT-1K1 i be finiteFINSET-1V1"
        using pboole_def_17 sorry
      thus "((Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B)).FUNCT-1K1 i be finiteFINSET-1V1"
        using fraenkel_th_6 sorry
    qed "sorry"
    thus "(Funcs)PBOOLEK7\<^bsub>(I)\<^esub>(A,B) be finite-yieldingFINSET-1V3"
      using finset_1_def_5 sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_17:
  mlet "I be setHIDDENM2", "A be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I", "B be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B as-term-is finite-yieldingFINSET-1V3"
proof
(*coherence*)
  show "A (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> B be finite-yieldingFINSET-1V3"
     sorry
qed "sorry"

reserve X, Y, Z for "ManySortedSetPBOOLEM1-of I"
mtheorem mssubfam_th_26:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X be finite-yieldingFINSET-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] implies ( ex A be ManySortedSetPBOOLEM1-of I st  ex B be ManySortedSetPBOOLEM1-of I st (((A be finite-yieldingFINSET-1V3 & A c=PBOOLER2\<^bsub>(I)\<^esub> Y) & B be finite-yieldingFINSET-1V3) & B c=PBOOLER2\<^bsub>(I)\<^esub> Z) & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |])"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X be finite-yieldingFINSET-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] implies ( ex tVar6 be ManySortedSetPBOOLEM1-of I st  ex tVar7 be ManySortedSetPBOOLEM1-of I st tVar6 be finite-yieldingFINSET-1V3 & (tVar6 c=PBOOLER2\<^bsub>(I)\<^esub> Y & (tVar7 be finite-yieldingFINSET-1V3 & (tVar7 c=PBOOLER2\<^bsub>(I)\<^esub> Z & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> tVar6,tVar7 |]))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X be finite-yieldingFINSET-1V3"
      and A2: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]"
    let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex D be setHIDDENM2 st  ex b be setHIDDENM2 st ((((D =HIDDENR1 Lamb2 & D be finiteFINSET-1V1) & D c=TARSKIR1 Y .FUNCT-1K1 Lamb1) & b be finiteFINSET-1V1) & b c=TARSKIR1 Z .FUNCT-1K1 Lamb1) & X .FUNCT-1K1 Lamb1 c=TARSKIR1 [:ZFMISC-1K2 D,b :]"
    have A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?Q(i,j))"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not ( for j be objectHIDDENM1 holds  not ( ex D be setHIDDENM2 st  ex b be setHIDDENM2 st ((((D =HIDDENR1 j & D be finiteFINSET-1V1) & D c=TARSKIR1 Y .FUNCT-1K1 i) & b be finiteFINSET-1V1) & b c=TARSKIR1 Z .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 D,b :]))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A4: "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
          using A2 sorry
        then have A5: "X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
          using A4 pboole_def_16 sorry
        have "X .FUNCT-1K1 i be finiteFINSET-1V1"
          using A1 sorry
        then obtain A B where
          [ty]:"A be setHIDDENM2" "B be setHIDDENM2" and 
          A6: "(((A be finiteFINSET-1V1 & A c=TARSKIR1 Y .FUNCT-1K1 i) & B be finiteFINSET-1V1) & B c=TARSKIR1 Z .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A,B :]"
          using A5 finset_1_th_13 sorry
        show " not ( for j be objectHIDDENM1 holds  not ( ex D be setHIDDENM2 st  ex b be setHIDDENM2 st ((((D =HIDDENR1 j & D be finiteFINSET-1V1) & D c=TARSKIR1 Y .FUNCT-1K1 i) & b be finiteFINSET-1V1) & b c=TARSKIR1 Z .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 D,b :]))"
          using A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain A where
      [ty]:"A be ManySortedSetPBOOLEM1-of I" and 
      A7: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?Q(i,A .FUNCT-1K1 i)"
      using pboole_sch_3 A3 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex D be setHIDDENM2 st ((((D =HIDDENR1 Lamb2 & A .FUNCT-1K1 Lamb1 be finiteFINSET-1V1) & A .FUNCT-1K1 Lamb1 c=TARSKIR1 Y .FUNCT-1K1 Lamb1) & D be finiteFINSET-1V1) & D c=TARSKIR1 Z .FUNCT-1K1 Lamb1) & X .FUNCT-1K1 Lamb1 c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 Lamb1,D :]"
    have A8: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?P(i,j))"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not ( for j be objectHIDDENM1 holds  not ( ex D be setHIDDENM2 st ((((D =HIDDENR1 j & A .FUNCT-1K1 i be finiteFINSET-1V1) & A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i) & D be finiteFINSET-1V1) & D c=TARSKIR1 Z .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i,D :]))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        then have "?Q(i,A .FUNCT-1K1 i)"
          using A7 sorry
        thus " not ( for j be objectHIDDENM1 holds  not ( ex D be setHIDDENM2 st ((((D =HIDDENR1 j & A .FUNCT-1K1 i be finiteFINSET-1V1) & A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i) & D be finiteFINSET-1V1) & D c=TARSKIR1 Z .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i,D :]))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain B where
      [ty]:"B be ManySortedSetPBOOLEM1-of I" and 
      A9: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?P(i,B .FUNCT-1K1 i)"
      using pboole_sch_3 A8 sorry
    show " ex tVar6 be ManySortedSetPBOOLEM1-of I st  ex tVar7 be ManySortedSetPBOOLEM1-of I st tVar6 be finite-yieldingFINSET-1V3 & (tVar6 c=PBOOLER2\<^bsub>(I)\<^esub> Y & (tVar7 be finite-yieldingFINSET-1V3 & (tVar7 c=PBOOLER2\<^bsub>(I)\<^esub> Z & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> tVar6,tVar7 |])))"
    proof(rule bexI[of _ "A"])
      show " ex tVar7 be ManySortedSetPBOOLEM1-of I st A be finite-yieldingFINSET-1V3 & (A c=PBOOLER2\<^bsub>(I)\<^esub> Y & (tVar7 be finite-yieldingFINSET-1V3 & (tVar7 c=PBOOLER2\<^bsub>(I)\<^esub> Z & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,tVar7 |])))"
      proof(rule bexI[of _ "B"],rule conjMI,rule conjMI,rule conjMI,rule conjMI)
        show "A be finite-yieldingFINSET-1V3"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 I"
            then have "?P(i,B .FUNCT-1K1 i)"
              using A9 sorry
            thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
               sorry
          qed "sorry"
          thus "A be finite-yieldingFINSET-1V3"
            using finset_1_def_5 sorry
        qed
        show "A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 I"
            then have "?P(i,B .FUNCT-1K1 i)"
              using A9 sorry
            thus "A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
               sorry
          qed "sorry"
          thus "A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
            using pboole_def_2 sorry
        qed
        show "B be finite-yieldingFINSET-1V3"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies B .FUNCT-1K1 i be finiteFINSET-1V1"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 I"
            then have "?P(i,B .FUNCT-1K1 i)"
              using A9 sorry
            thus "B .FUNCT-1K1 i be finiteFINSET-1V1"
               sorry
          qed "sorry"
          thus "B be finite-yieldingFINSET-1V3"
            using finset_1_def_5 sorry
        qed
        show "B c=PBOOLER2\<^bsub>(I)\<^esub> Z"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies B .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 I"
            then have "?P(i,B .FUNCT-1K1 i)"
              using A9 sorry
            thus "B .FUNCT-1K1 i c=TARSKIR1 Z .FUNCT-1K1 i"
               sorry
          qed "sorry"
          thus "B c=PBOOLER2\<^bsub>(I)\<^esub> Z"
            using pboole_def_2 sorry
        qed
        show "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume A10: "i inHIDDENR3 I"
            then have "?P(i,B .FUNCT-1K1 i)"
              using A9 sorry
            then have "X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i,B .FUNCT-1K1 i :]"
               sorry
            thus "X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]).FUNCT-1K1 i"
              using A10 pboole_def_16 sorry
          qed "sorry"
          thus "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,B |]"
            using pboole_def_2 sorry
        qed
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_27:
" for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X be finite-yieldingFINSET-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] implies ( ex A be ManySortedSetPBOOLEM1-of I st (A be finite-yieldingFINSET-1V3 & A c=PBOOLER2\<^bsub>(I)\<^esub> Y) & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,Z |])"
proof-
  have " for I be setHIDDENM2 holds  for X be ManySortedSetPBOOLEM1-of I holds  for Y be ManySortedSetPBOOLEM1-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds X be finite-yieldingFINSET-1V3 & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |] implies ( ex tVar9 be ManySortedSetPBOOLEM1-of I st tVar9 be finite-yieldingFINSET-1V3 & (tVar9 c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> tVar9,Z |]))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix X assume [ty]: "X be ManySortedSetPBOOLEM1-of I"
    fix Y assume [ty]: "Y be ManySortedSetPBOOLEM1-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "X be finite-yieldingFINSET-1V3"
      and A2: "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex D be setHIDDENM2 st ((D =HIDDENR1 Lamb2 & D be finiteFINSET-1V1) & D c=TARSKIR1 Y .FUNCT-1K1 Lamb1) & X .FUNCT-1K1 Lamb1 c=TARSKIR1 [:ZFMISC-1K2 D,Z .FUNCT-1K1 Lamb1 :]"
    have A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?P(i,j))"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar8 be objectHIDDENM1 st  ex D be setHIDDENM2 st ((D =HIDDENR1 tVar8 & D be finiteFINSET-1V1) & D c=TARSKIR1 Y .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 D,Z .FUNCT-1K1 i :])"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A4: "i inHIDDENR3 I"
        then have "X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> Y,Z |]).FUNCT-1K1 i"
          using A2 sorry
        then have A5: "X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 Y .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
          using A4 pboole_def_16 sorry
        have "X .FUNCT-1K1 i be finiteFINSET-1V1"
          using A1 sorry
        then obtain A9 where
          [ty]:"A9 be setHIDDENM2" and 
          A6: "(A9 be finiteFINSET-1V1 & A9 c=TARSKIR1 Y .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A9,Z .FUNCT-1K1 i :]"
          using A5 finset_1_th_14 sorry
        show " ex tVar8 be objectHIDDENM1 st  ex D be setHIDDENM2 st ((D =HIDDENR1 tVar8 & D be finiteFINSET-1V1) & D c=TARSKIR1 Y .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 D,Z .FUNCT-1K1 i :]"
        proof(rule bexI[of _ "A9"])
          show " ex D be setHIDDENM2 st ((D =HIDDENR1 A9 & D be finiteFINSET-1V1) & D c=TARSKIR1 Y .FUNCT-1K1 i) & X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 D,Z .FUNCT-1K1 i :]"
            using A6 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain A where
      [ty]:"A be ManySortedSetPBOOLEM1-of I" and 
      A7: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?P(i,A .FUNCT-1K1 i)"
      using pboole_sch_3 A3 sorry
    show " ex tVar9 be ManySortedSetPBOOLEM1-of I st tVar9 be finite-yieldingFINSET-1V3 & (tVar9 c=PBOOLER2\<^bsub>(I)\<^esub> Y & X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> tVar9,Z |])"
    proof(rule bexI[of _ "A"],rule conjMI,rule conjMI)
      show "A be finite-yieldingFINSET-1V3"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i be finiteFINSET-1V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "?P(i,A .FUNCT-1K1 i)"
            using A7 sorry
          thus "A .FUNCT-1K1 i be finiteFINSET-1V1"
             sorry
        qed "sorry"
        thus "A be finite-yieldingFINSET-1V3"
          using finset_1_def_5 sorry
      qed
      show "A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "?P(i,A .FUNCT-1K1 i)"
            using A7 sorry
          thus "A .FUNCT-1K1 i c=TARSKIR1 Y .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "A c=PBOOLER2\<^bsub>(I)\<^esub> Y"
          using pboole_def_2 sorry
      qed
      show "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,Z |]"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,Z |]).FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A8: "i inHIDDENR3 I"
          then have "?P(i,A .FUNCT-1K1 i)"
            using A7 sorry
          then have "X .FUNCT-1K1 i c=TARSKIR1 [:ZFMISC-1K2 A .FUNCT-1K1 i,Z .FUNCT-1K1 i :]"
             sorry
          thus "X .FUNCT-1K1 i c=TARSKIR1 ([|PBOOLEK6\<^bsub>(I)\<^esub> A,Z |]).FUNCT-1K1 i"
            using A8 pboole_def_16 sorry
        qed "sorry"
        thus "X c=PBOOLER2\<^bsub>(I)\<^esub> [|PBOOLEK6\<^bsub>(I)\<^esub> A,Z |]"
          using pboole_def_2 sorry
      qed
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_28:
" for I be setHIDDENM2 holds  for M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I holds ( for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A) implies ( ex m be ManySortedSetPBOOLEM1-of I st m inPBOOLER1\<^bsub>(I)\<^esub> M & ( for K be ManySortedSetPBOOLEM1-of I holds K inPBOOLER1\<^bsub>(I)\<^esub> M implies m c=PBOOLER2\<^bsub>(I)\<^esub> K))"
proof-
  have " for I be setHIDDENM2 holds  for M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I holds ( for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A) implies ( ex tVar11 be ManySortedSetPBOOLEM1-of I st tVar11 inPBOOLER1\<^bsub>(I)\<^esub> M & ( for C be ManySortedSetPBOOLEM1-of I holds C inPBOOLER1\<^bsub>(I)\<^esub> M implies tVar11 c=PBOOLER2\<^bsub>(I)\<^esub> C))"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: " for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A"
    let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex D be setHIDDENM2 st (D =HIDDENR1 Lamb2 & Lamb2 inHIDDENR3 M .FUNCT-1K1 Lamb1) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 Lamb1 implies D c=TARSKIR1 D9)"
    have A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?Q(i,j))"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar10 be objectHIDDENM1 st  ex D be setHIDDENM2 st (D =HIDDENR1 tVar10 & tVar10 inHIDDENR3 M .FUNCT-1K1 i) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies D c=TARSKIR1 D9))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        have "M .FUNCT-1K1 i be c=-linearORDINAL1V6"
        proof-
          obtain c9 where
            [ty]:"c9 be ManySortedSetPBOOLEM1-of I" and 
            A4: "c9 inPBOOLER1\<^bsub>(I)\<^esub> M"
            using pboole_th_134 sorry
          obtain b9 where
            [ty]:"b9 be ManySortedSetPBOOLEM1-of I" and 
            A5: "b9 inPBOOLER1\<^bsub>(I)\<^esub> M"
            using pboole_th_134 sorry
          have " for B9 be setHIDDENM2 holds  for C9 be setHIDDENM2 holds B9 inTARSKIR2 M .FUNCT-1K1 i & C9 inTARSKIR2 M .FUNCT-1K1 i implies (B9,C9)are-c=-comparableXBOOLE-0R3"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix B9 assume [ty]: "B9 be setHIDDENM2"
            fix C9 assume [ty]: "C9 be setHIDDENM2"
            assume A6: "B9 inTARSKIR2 M .FUNCT-1K1 i"
              and A7: "C9 inTARSKIR2 M .FUNCT-1K1 i"
            have A8: "domRELAT-1K1 (i .-->FUNCOP-1K17 B9) =XBOOLE-0R4 {TARSKIK1 i}"
              using funcop_1_th_13 sorry
            let ?qc = "c9 +*FUNCT-4K1 (i .-->FUNCOP-1K17 C9)"
            have "domRELAT-1K1 ?qc =XBOOLE-0R4 I"
              using A3 pzfmisc1_th_1 sorry
            then obtain qc where 
              [ty]:"qc be ManySortedSetPBOOLEM1-of I" and qcDef:"qc = ?qc"
              using partfun1_def_2 relat_1_def_18 sorry
            have A9: "domRELAT-1K1 (i .-->FUNCOP-1K17 C9) =XBOOLE-0R4 {TARSKIK1 i}"
              using funcop_1_th_13 sorry
            have "i inHIDDENR3 {TARSKIK1 i}"
              using tarski_def_1 sorry
            then have A10: "qc .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 C9).FUNCT-1K1 i"
              using A9 funct_4_th_13 sorry
            also have "... = C9"
              using funcop_1_th_72 sorry
            finally have "qc .FUNCT-1K1 i =HIDDENR1 C9"
               sorry
            have A11: "qc inPBOOLER1\<^bsub>(I)\<^esub> M"
            proof-
              have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
              proof(rule ballI,rule impI)
                fix j assume [ty]: "j be objectHIDDENM1"
                assume A12: "j inHIDDENR3 I"
                have "j =HIDDENR1 i & qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                proof-
                  show "j =HIDDENR1 i & qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                  proof-
                    have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                       sorry
                    have case1: "j =HIDDENR1 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                    proof(rule impI)
                      assume "j =HIDDENR1 i"
                      thus "qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                        using A7 A10 sorry
                    qed
                    have case2: "j <>HIDDENR2 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                    proof(rule impI)
                      assume "j <>HIDDENR2 i"
                      then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 C9)"
                        using A9 tarski_def_1 sorry
                      then have "qc .FUNCT-1K1 j =XBOOLE-0R4 c9 .FUNCT-1K1 j"
                        using funct_4_th_11 sorry
                      thus "qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                        using A4 A12 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                   sorry
              qed "sorry"
              thus "qc inPBOOLER1\<^bsub>(I)\<^esub> M"
                using pboole_def_1 sorry
            qed
            let ?qb = "b9 +*FUNCT-4K1 (i .-->FUNCOP-1K17 B9)"
            have "domRELAT-1K1 ?qb =XBOOLE-0R4 I"
              using A3 pzfmisc1_th_1 sorry
            then obtain qb where 
              [ty]:"qb be ManySortedSetPBOOLEM1-of I" and qbDef:"qb = ?qb"
              using partfun1_def_2 relat_1_def_18 sorry
            have " not B9 c=TARSKIR1 C9 implies C9 c=TARSKIR1 B9"
            proof(rule impI)
              assume A13: " not B9 c=TARSKIR1 C9"
              have "i inHIDDENR3 {TARSKIK1 i}"
                using tarski_def_1 sorry
              then have A14: "qb .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 B9).FUNCT-1K1 i"
                using A8 funct_4_th_13 sorry
              also have "... = B9"
                using funcop_1_th_72 sorry
              finally have "qb .FUNCT-1K1 i =HIDDENR1 B9"
                 sorry
              have "qb inPBOOLER1\<^bsub>(I)\<^esub> M"
              proof-
                have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                proof(rule ballI,rule impI)
                  fix j assume [ty]: "j be objectHIDDENM1"
                  assume A15: "j inHIDDENR3 I"
                  have "j =HIDDENR1 i & qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                  proof-
                    show "j =HIDDENR1 i & qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                    proof-
                      have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                         sorry
                      have case1: "j =HIDDENR1 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                      proof(rule impI)
                        assume "j =HIDDENR1 i"
                        thus "qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                          using A6 A14 sorry
                      qed
                      have case2: "j <>HIDDENR2 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                      proof(rule impI)
                        assume "j <>HIDDENR2 i"
                        then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 B9)"
                          using A8 tarski_def_1 sorry
                        then have "qb .FUNCT-1K1 j =XBOOLE-0R4 b9 .FUNCT-1K1 j"
                          using funct_4_th_11 sorry
                        thus "qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                          using A5 A15 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus "qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                     sorry
                qed "sorry"
                thus "qb inPBOOLER1\<^bsub>(I)\<^esub> M"
                  using pboole_def_1 sorry
              qed
              then have "qb c=PBOOLER2\<^bsub>(I)\<^esub> qc or qc c=PBOOLER2\<^bsub>(I)\<^esub> qb"
                using A1 A11 sorry
              thus "C9 c=TARSKIR1 B9"
                using A3 A13 A14 A10 sorry
            qed
            thus "(B9,C9)are-c=-comparableXBOOLE-0R3"
              using xboole_0_def_9 sorry
          qed "sorry"
          thus "M .FUNCT-1K1 i be c=-linearORDINAL1V6"
            using ordinal1_def_8 sorry
        qed
        then obtain m9 where
          [ty]:"m9 be setHIDDENM2" and 
          A16: "m9 inTARSKIR2 M .FUNCT-1K1 i & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies m9 c=TARSKIR1 D9)"
          using A3 finset_1_th_11 sorry
        show " ex tVar10 be objectHIDDENM1 st  ex D be setHIDDENM2 st (D =HIDDENR1 tVar10 & tVar10 inHIDDENR3 M .FUNCT-1K1 i) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies D c=TARSKIR1 D9)"
        proof(rule bexI[of _ "m9"])
          show " ex D be setHIDDENM2 st (D =HIDDENR1 m9 & m9 inHIDDENR3 M .FUNCT-1K1 i) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies D c=TARSKIR1 D9)"
            using A16 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain m where
      [ty]:"m be ManySortedSetPBOOLEM1-of I" and 
      A17: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?Q(i,m .FUNCT-1K1 i)"
      using pboole_sch_3 A2 sorry
    show " ex tVar11 be ManySortedSetPBOOLEM1-of I st tVar11 inPBOOLER1\<^bsub>(I)\<^esub> M & ( for C be ManySortedSetPBOOLEM1-of I holds C inPBOOLER1\<^bsub>(I)\<^esub> M implies tVar11 c=PBOOLER2\<^bsub>(I)\<^esub> C)"
    proof(rule bexI[of _ "m"],rule conjMI)
      show "m inPBOOLER1\<^bsub>(I)\<^esub> M"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies m .FUNCT-1K1 i inTARSKIR2 M .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "?Q(i,m .FUNCT-1K1 i)"
            using A17 sorry
          thus "m .FUNCT-1K1 i inTARSKIR2 M .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "m inPBOOLER1\<^bsub>(I)\<^esub> M"
          using pboole_def_1 sorry
      qed
      show " for C be ManySortedSetPBOOLEM1-of I holds C inPBOOLER1\<^bsub>(I)\<^esub> M implies m c=PBOOLER2\<^bsub>(I)\<^esub> C"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be ManySortedSetPBOOLEM1-of I"
        assume A18: "C inPBOOLER1\<^bsub>(I)\<^esub> M"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies m .FUNCT-1K1 i c=TARSKIR1 C .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A19: "i inHIDDENR3 I"
          then have A20: "C .FUNCT-1K1 i inTARSKIR2 M .FUNCT-1K1 i"
            using A18 sorry
          have "?Q(i,m .FUNCT-1K1 i)"
            using A17 A19 sorry
          thus "m .FUNCT-1K1 i c=TARSKIR1 C .FUNCT-1K1 i"
            using A20 sorry
        qed "sorry"
        thus "m c=PBOOLER2\<^bsub>(I)\<^esub> C"
          using pboole_def_2 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_29:
" for I be setHIDDENM2 holds  for M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I holds ( for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A) implies ( ex m be ManySortedSetPBOOLEM1-of I st m inPBOOLER1\<^bsub>(I)\<^esub> M & ( for K be ManySortedSetPBOOLEM1-of I holds K inPBOOLER1\<^bsub>(I)\<^esub> M implies K c=PBOOLER2\<^bsub>(I)\<^esub> m))"
proof-
  have " for I be setHIDDENM2 holds  for M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I holds ( for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A) implies ( ex tVar13 be ManySortedSetPBOOLEM1-of I st tVar13 inPBOOLER1\<^bsub>(I)\<^esub> M & ( for K be ManySortedSetPBOOLEM1-of I holds K inPBOOLER1\<^bsub>(I)\<^esub> M implies K c=PBOOLER2\<^bsub>(I)\<^esub> tVar13))"
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
    assume A1: " for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> M implies A c=PBOOLER2\<^bsub>(I)\<^esub> B or B c=PBOOLER2\<^bsub>(I)\<^esub> A"
    let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2.  ex X be setHIDDENM2 st (X =HIDDENR1 Lamb2 & Lamb2 inHIDDENR3 M .FUNCT-1K1 Lamb1) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 Lamb1 implies D9 c=TARSKIR1 X)"
    have A2: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?Z(i,j))"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar12 be objectHIDDENM1 st  ex X be setHIDDENM2 st (X =HIDDENR1 tVar12 & tVar12 inHIDDENR3 M .FUNCT-1K1 i) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies D9 c=TARSKIR1 X))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A3: "i inHIDDENR3 I"
        have "M .FUNCT-1K1 i be c=-linearORDINAL1V6"
        proof-
          obtain c9 where
            [ty]:"c9 be ManySortedSetPBOOLEM1-of I" and 
            A4: "c9 inPBOOLER1\<^bsub>(I)\<^esub> M"
            using pboole_th_134 sorry
          obtain b9 where
            [ty]:"b9 be ManySortedSetPBOOLEM1-of I" and 
            A5: "b9 inPBOOLER1\<^bsub>(I)\<^esub> M"
            using pboole_th_134 sorry
          have " for B9 be setHIDDENM2 holds  for C9 be setHIDDENM2 holds B9 inTARSKIR2 M .FUNCT-1K1 i & C9 inTARSKIR2 M .FUNCT-1K1 i implies (B9,C9)are-c=-comparableXBOOLE-0R3"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix B9 assume [ty]: "B9 be setHIDDENM2"
            fix C9 assume [ty]: "C9 be setHIDDENM2"
            assume A6: "B9 inTARSKIR2 M .FUNCT-1K1 i"
              and A7: "C9 inTARSKIR2 M .FUNCT-1K1 i"
            have A8: "domRELAT-1K1 (i .-->FUNCOP-1K17 B9) =XBOOLE-0R4 {TARSKIK1 i}"
              using funcop_1_th_13 sorry
            let ?qc = "c9 +*FUNCT-4K1 (i .-->FUNCOP-1K17 C9)"
            have "domRELAT-1K1 ?qc =XBOOLE-0R4 I"
              using A3 pzfmisc1_th_1 sorry
            then obtain qc where 
              [ty]:"qc be ManySortedSetPBOOLEM1-of I" and qcDef:"qc = ?qc"
              using partfun1_def_2 relat_1_def_18 sorry
            have A9: "domRELAT-1K1 (i .-->FUNCOP-1K17 C9) =XBOOLE-0R4 {TARSKIK1 i}"
              using funcop_1_th_13 sorry
            have "i inHIDDENR3 {TARSKIK1 i}"
              using tarski_def_1 sorry
            then have A10: "qc .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 C9).FUNCT-1K1 i"
              using A9 funct_4_th_13 sorry
            also have "... = C9"
              using funcop_1_th_72 sorry
            finally have "qc .FUNCT-1K1 i =HIDDENR1 C9"
               sorry
            have A11: "qc inPBOOLER1\<^bsub>(I)\<^esub> M"
            proof-
              have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
              proof(rule ballI,rule impI)
                fix j assume [ty]: "j be objectHIDDENM1"
                assume A12: "j inHIDDENR3 I"
                have "j =HIDDENR1 i & qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                proof-
                  show "j =HIDDENR1 i & qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                  proof-
                    have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                       sorry
                    have case1: "j =HIDDENR1 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                    proof(rule impI)
                      assume "j =HIDDENR1 i"
                      thus "qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                        using A7 A10 sorry
                    qed
                    have case2: "j <>HIDDENR2 i implies qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                    proof(rule impI)
                      assume "j <>HIDDENR2 i"
                      then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 C9)"
                        using A9 tarski_def_1 sorry
                      then have "qc .FUNCT-1K1 j =XBOOLE-0R4 c9 .FUNCT-1K1 j"
                        using funct_4_th_11 sorry
                      thus "qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                        using A4 A12 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "qc .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                   sorry
              qed "sorry"
              thus "qc inPBOOLER1\<^bsub>(I)\<^esub> M"
                using pboole_def_1 sorry
            qed
            let ?qb = "b9 +*FUNCT-4K1 (i .-->FUNCOP-1K17 B9)"
            have "domRELAT-1K1 ?qb =XBOOLE-0R4 I"
              using A3 pzfmisc1_th_1 sorry
            then obtain qb where 
              [ty]:"qb be ManySortedSetPBOOLEM1-of I" and qbDef:"qb = ?qb"
              using partfun1_def_2 relat_1_def_18 sorry
            have " not B9 c=TARSKIR1 C9 implies C9 c=TARSKIR1 B9"
            proof(rule impI)
              assume A13: " not B9 c=TARSKIR1 C9"
              have "i inHIDDENR3 {TARSKIK1 i}"
                using tarski_def_1 sorry
              then have A14: "qb .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 B9).FUNCT-1K1 i"
                using A8 funct_4_th_13 sorry
              also have "... = B9"
                using funcop_1_th_72 sorry
              finally have "qb .FUNCT-1K1 i =HIDDENR1 B9"
                 sorry
              have "qb inPBOOLER1\<^bsub>(I)\<^esub> M"
              proof-
                have " for j be objectHIDDENM1 holds j inHIDDENR3 I implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                proof(rule ballI,rule impI)
                  fix j assume [ty]: "j be objectHIDDENM1"
                  assume A15: "j inHIDDENR3 I"
                  have "j =HIDDENR1 i & qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                  proof-
                    show "j =HIDDENR1 i & qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j or j <>HIDDENR2 i & (j <>HIDDENR2 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j)"
                    proof-
                      have cases: "j =HIDDENR1 i or j <>HIDDENR2 i"
                         sorry
                      have case1: "j =HIDDENR1 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                      proof(rule impI)
                        assume "j =HIDDENR1 i"
                        thus "qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                          using A6 A14 sorry
                      qed
                      have case2: "j <>HIDDENR2 i implies qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                      proof(rule impI)
                        assume "j <>HIDDENR2 i"
                        then have " not j inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 B9)"
                          using A8 tarski_def_1 sorry
                        then have "qb .FUNCT-1K1 j =XBOOLE-0R4 b9 .FUNCT-1K1 j"
                          using funct_4_th_11 sorry
                        thus "qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                          using A5 A15 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus "qb .FUNCT-1K1 j inTARSKIR2 M .FUNCT-1K1 j"
                     sorry
                qed "sorry"
                thus "qb inPBOOLER1\<^bsub>(I)\<^esub> M"
                  using pboole_def_1 sorry
              qed
              then have "qb c=PBOOLER2\<^bsub>(I)\<^esub> qc or qc c=PBOOLER2\<^bsub>(I)\<^esub> qb"
                using A1 A11 sorry
              thus "C9 c=TARSKIR1 B9"
                using A3 A13 A14 A10 sorry
            qed
            thus "(B9,C9)are-c=-comparableXBOOLE-0R3"
              using xboole_0_def_9 sorry
          qed "sorry"
          thus "M .FUNCT-1K1 i be c=-linearORDINAL1V6"
            using ordinal1_def_8 sorry
        qed
        then obtain m9 where
          [ty]:"m9 be setHIDDENM2" and 
          A16: "m9 inTARSKIR2 M .FUNCT-1K1 i & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies D9 c=TARSKIR1 m9)"
          using A3 finset_1_th_12 sorry
        show " ex tVar12 be objectHIDDENM1 st  ex X be setHIDDENM2 st (X =HIDDENR1 tVar12 & tVar12 inHIDDENR3 M .FUNCT-1K1 i) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies D9 c=TARSKIR1 X)"
        proof(rule bexI[of _ "m9"])
          show " ex X be setHIDDENM2 st (X =HIDDENR1 m9 & m9 inHIDDENR3 M .FUNCT-1K1 i) & ( for D9 be setHIDDENM2 holds D9 inTARSKIR2 M .FUNCT-1K1 i implies D9 c=TARSKIR1 X)"
            using A16 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain m where
      [ty]:"m be ManySortedSetPBOOLEM1-of I" and 
      A17: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?Z(i,m .FUNCT-1K1 i)"
      using pboole_sch_3 A2 sorry
    show " ex tVar13 be ManySortedSetPBOOLEM1-of I st tVar13 inPBOOLER1\<^bsub>(I)\<^esub> M & ( for K be ManySortedSetPBOOLEM1-of I holds K inPBOOLER1\<^bsub>(I)\<^esub> M implies K c=PBOOLER2\<^bsub>(I)\<^esub> tVar13)"
    proof(rule bexI[of _ "m"],rule conjMI)
      show "m inPBOOLER1\<^bsub>(I)\<^esub> M"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies m .FUNCT-1K1 i inTARSKIR2 M .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "?Z(i,m .FUNCT-1K1 i)"
            using A17 sorry
          thus "m .FUNCT-1K1 i inTARSKIR2 M .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "m inPBOOLER1\<^bsub>(I)\<^esub> M"
          using pboole_def_1 sorry
      qed
      show " for K be ManySortedSetPBOOLEM1-of I holds K inPBOOLER1\<^bsub>(I)\<^esub> M implies K c=PBOOLER2\<^bsub>(I)\<^esub> m"
      proof(rule ballI,rule impI)
        fix K assume [ty]: "K be ManySortedSetPBOOLEM1-of I"
        assume A18: "K inPBOOLER1\<^bsub>(I)\<^esub> M"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies K .FUNCT-1K1 i c=TARSKIR1 m .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume A19: "i inHIDDENR3 I"
          then have A20: "K .FUNCT-1K1 i inTARSKIR2 M .FUNCT-1K1 i"
            using A18 sorry
          have "?Z(i,m .FUNCT-1K1 i)"
            using A17 A19 sorry
          thus "K .FUNCT-1K1 i c=TARSKIR1 m .FUNCT-1K1 i"
            using A20 sorry
        qed "sorry"
        thus "K c=PBOOLER2\<^bsub>(I)\<^esub> m"
          using pboole_def_2 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_30:
" for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z be finite-yieldingFINSET-1V3 & Z c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F implies ( ex Y be ManySortedSetPBOOLEM1-of I st (Y c=PBOOLER2\<^bsub>(I)\<^esub> domsFUNCT-6K1 F & Y be finite-yieldingFINSET-1V3) & F .:.:PBOOLEK9\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Z)"
proof-
  have " for I be setHIDDENM2 holds  for F be ManySortedFunctionPBOOLEM2-of I holds  for Z be ManySortedSetPBOOLEM1-of I holds Z be finite-yieldingFINSET-1V3 & Z c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F implies ( ex tVar17 be ManySortedSetPBOOLEM1-of I st tVar17 c=PBOOLER2\<^bsub>(I)\<^esub> domsFUNCT-6K1 F & (tVar17 be finite-yieldingFINSET-1V3 & F .:.:PBOOLEK9\<^bsub>(I)\<^esub> tVar17 =PBOOLER7\<^bsub>(I)\<^esub> Z))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix F assume [ty]: "F be ManySortedFunctionPBOOLEM2-of I"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    assume A1: "Z be finite-yieldingFINSET-1V3"
      and A2: "Z c=PBOOLER2\<^bsub>(I)\<^esub> rngsFUNCT-6K2 F"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st  ex f be FunctionFUNCT-1M1 st (((A =HIDDENR1 Lamb2 & f =FUNCT-1R1 F .FUNCT-1K1 Lamb1) & A c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 Lamb1) & A be finiteFINSET-1V1) & f .:FUNCT-1K5 A =XBOOLE-0R4 Z .FUNCT-1K1 Lamb1"
    have A3: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?P(i,j))"
    proof-
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar14 be objectHIDDENM1 st  ex tVar15 be setHIDDENM2 st  ex tVar16 be FunctionFUNCT-1M1 st tVar15 =XBOOLE-0R4 tVar15 & (tVar16 =FUNCT-1R1 F .FUNCT-1K1 i & ((tVar15 c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 i & tVar15 be finiteFINSET-1V1) & tVar16 .:FUNCT-1K5 tVar15 =XBOOLE-0R4 Z .FUNCT-1K1 i)))"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        obtain f where 
          [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F .FUNCT-1K1 i"
           sorry
        assume A4: "i inHIDDENR3 I"
        then have "rngFUNCT-1K2 f =XBOOLE-0R4 rngsFUNCT-6K2 F .FUNCT-1K1 i"
          using mssubfam_th_13 sorry
        then have A5: "Z .FUNCT-1K1 i c=TARSKIR1 rngFUNCT-1K2 f"
          using A2 A4 sorry
        have "Z .FUNCT-1K1 i be finiteFINSET-1V1"
          using A1 sorry
        then obtain y where
          [ty]:"y be setHIDDENM2" and 
          A6: "(y c=TARSKIR1 domRELAT-1K1 f & y be finiteFINSET-1V1) & f .:FUNCT-1K5 y =XBOOLE-0R4 Z .FUNCT-1K1 i"
          using A5 orders_1_th_85 sorry
        show " ex tVar14 be objectHIDDENM1 st  ex tVar15 be setHIDDENM2 st  ex tVar16 be FunctionFUNCT-1M1 st tVar15 =XBOOLE-0R4 tVar15 & (tVar16 =FUNCT-1R1 F .FUNCT-1K1 i & ((tVar15 c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 i & tVar15 be finiteFINSET-1V1) & tVar16 .:FUNCT-1K5 tVar15 =XBOOLE-0R4 Z .FUNCT-1K1 i))"
        proof(rule bexI[of _ "y"])
          show " ex tVar15 be setHIDDENM2 st  ex tVar16 be FunctionFUNCT-1M1 st tVar15 =XBOOLE-0R4 tVar15 & (tVar16 =FUNCT-1R1 F .FUNCT-1K1 i & ((tVar15 c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 i & tVar15 be finiteFINSET-1V1) & tVar16 .:FUNCT-1K5 tVar15 =XBOOLE-0R4 Z .FUNCT-1K1 i))"
          proof(rule bexI[of _ "y"])
            show " ex tVar16 be FunctionFUNCT-1M1 st y =XBOOLE-0R4 y & (tVar16 =FUNCT-1R1 F .FUNCT-1K1 i & ((y c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 i & y be finiteFINSET-1V1) & tVar16 .:FUNCT-1K5 y =XBOOLE-0R4 Z .FUNCT-1K1 i))"
            proof(rule bexI[of _ "f"],rule conjMI,rule conjMI)
              show "y =XBOOLE-0R4 y"
                 sorry
              show "f =FUNCT-1R1 F .FUNCT-1K1 i"
                 sorry
              show "(y c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 i & y be finiteFINSET-1V1) & f .:FUNCT-1K5 y =XBOOLE-0R4 Z .FUNCT-1K1 i"
                using A4 A6 mssubfam_th_14 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain Y where
      [ty]:"Y be ManySortedSetPBOOLEM1-of I" and 
      A7: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?P(i,Y .FUNCT-1K1 i)"
      using pboole_sch_3 A3 sorry
    show " ex tVar17 be ManySortedSetPBOOLEM1-of I st tVar17 c=PBOOLER2\<^bsub>(I)\<^esub> domsFUNCT-6K1 F & (tVar17 be finite-yieldingFINSET-1V3 & F .:.:PBOOLEK9\<^bsub>(I)\<^esub> tVar17 =PBOOLER7\<^bsub>(I)\<^esub> Z)"
    proof(rule bexI[of _ "Y"],rule conjMI,rule conjMI)
      show "Y c=PBOOLER2\<^bsub>(I)\<^esub> domsFUNCT-6K1 F"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "?P(i,Y .FUNCT-1K1 i)"
            using A7 sorry
          thus "Y .FUNCT-1K1 i c=TARSKIR1 domsFUNCT-6K1 F .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "Y c=PBOOLER2\<^bsub>(I)\<^esub> domsFUNCT-6K1 F"
          using pboole_def_2 sorry
      qed
      show "Y be finite-yieldingFINSET-1V3"
      proof-
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Y .FUNCT-1K1 i be finiteFINSET-1V1"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "?P(i,Y .FUNCT-1K1 i)"
            using A7 sorry
          thus "Y .FUNCT-1K1 i be finiteFINSET-1V1"
             sorry
        qed "sorry"
        thus "Y be finite-yieldingFINSET-1V3"
          using finset_1_def_5 sorry
      qed
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (F .:.:PBOOLEK9\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 Z .FUNCT-1K1 i"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume A8: "i inHIDDENR3 I"
        then have "?P(i,Y .FUNCT-1K1 i)"
          using A7 sorry
        thus "(F .:.:PBOOLEK9\<^bsub>(I)\<^esub> Y).FUNCT-1K1 i =XBOOLE-0R4 Z .FUNCT-1K1 i"
          using A8 pboole_def_20 sorry
      qed "sorry"
      thus "F .:.:PBOOLEK9\<^bsub>(I)\<^esub> Y =PBOOLER7\<^bsub>(I)\<^esub> Z"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
abbreviation(input) MSSUBFAMM1("MSSubsetFamilyMSSUBFAMM1\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70) where
  "MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M \<equiv> ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of boolMBOOLEANK1\<^bsub>(I)\<^esub> M"

mtheorem mssubfam_cl_18:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster non-emptyRELAT-1V2 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be non-emptyRELAT-1V2"
  proof-
    have " not ( for VarFor1 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  not VarFor1 be non-emptyRELAT-1V2)"
    proof-
      have "boolMBOOLEANK1\<^bsub>(I)\<^esub> M be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of boolMBOOLEANK1\<^bsub>(I)\<^esub> M"
        using pboole_def_18 sorry
      thus " not ( for VarFor1 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  not VarFor1 be non-emptyRELAT-1V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) MSSUBFAMK1("boolMSSUBFAMK1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228) where
  "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M \<equiv> boolMBOOLEANK1\<^bsub>(I)\<^esub> M"

mtheorem mssubfam_add_1:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> M as-term-is MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> M be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    using pboole_def_18 sorry
qed "sorry"

mtheorem mssubfam_cl_19:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3"
  proof-
    have " not ( for VarFor1 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  not (VarFor1 be empty-yieldingRELAT-1V3 & VarFor1 be finite-yieldingFINSET-1V3))"
    proof-
      have "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
        using pboole_th_43 sorry
      then have "EmptyMSPBOOLEK1 I be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
        using pboole_def_18 sorry
      thus " not ( for VarFor1 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  not (VarFor1 be empty-yieldingRELAT-1V3 & VarFor1 be finite-yieldingFINSET-1V3))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_th_31:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds EmptyMSPBOOLEK1 I be empty-yieldingRELAT-1V3\<bar>finite-yieldingFINSET-1V3\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  using pboole_th_43 pboole_def_18 sorry

mtheorem mssubfam_cl_20:
  mlet "I be setHIDDENM2", "M be finite-yieldingFINSET-1V3\<bar>ManySortedSetPBOOLEM1-of I"
"cluster non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be non-emptyRELAT-1V2\<bar>finite-yieldingFINSET-1V3"
  proof-
    have " not ( for VarFor1 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  not (VarFor1 be non-emptyRELAT-1V2 & VarFor1 be finite-yieldingFINSET-1V3))"
    proof-
      have "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
         sorry
      thus " not ( for VarFor1 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  not (VarFor1 be non-emptyRELAT-1V2 & VarFor1 be finite-yieldingFINSET-1V3))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve SF, SG, SH for "MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
reserve SFe for "non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
reserve V, W for "ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
syntax MSSUBFAMK2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .MSSUBFAMK2\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "SF .MSSUBFAMK2\<^bsub>(I,M)\<^esub> i" \<rightharpoonup> "SF .FUNCT-1K1 i"

mtheorem mssubfam_add_2:
  mlet "I be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M", "i be ElementSUBSET-1M1-of I"
"cluster SF .FUNCT-1K1 i as-term-is Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
proof
(*coherence*)
  show "SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
  proof-
    have "SF c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_def_18 sorry
    then have "SF .FUNCT-1K1 i c=TARSKIR1 boolMSSUBFAMK1\<^bsub>(I)\<^esub> M .FUNCT-1K1 i"
       sorry
    thus "SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
      using mboolean_def_1 sorry
  qed
qed "sorry"

mtheorem mssubfam_th_32:
" for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds i inHIDDENR3 I implies SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
proof-
  have " for I be setHIDDENM2 holds  for i be objectHIDDENM1 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds i inHIDDENR3 I implies SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix i assume [ty]: "i be objectHIDDENM1"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "i inHIDDENR3 I"
    have "SF c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_def_18 sorry
    then have "SF .FUNCT-1K1 i c=TARSKIR1 boolMSSUBFAMK1\<^bsub>(I)\<^esub> M .FUNCT-1K1 i"
      using A1 sorry
    thus "SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
      using A1 mboolean_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_33:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF implies A be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF implies A be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    have A1: "SF c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_def_18 sorry
    assume "A inPBOOLER1\<^bsub>(I)\<^esub> SF"
    then have "A inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using A1 pboole_th_9 sorry
    then have "A c=PBOOLER2\<^bsub>(I)\<^esub> M"
      using mboolean_th_18 sorry
    thus "A be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
      using pboole_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_34:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix SG assume [ty]: "SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    have "SF c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M & SG c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_def_18 sorry
    then have "SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_th_16 sorry
    thus "SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using pboole_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_35:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix SG assume [ty]: "SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    have "SF c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M & SG c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_def_18 sorry
    then have "SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> SG c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M (/\\)PBOOLEK3\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_th_21 sorry
    thus "SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using pboole_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_36:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\)PBOOLEK4\<^bsub>(I)\<^esub> A be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\)PBOOLEK4\<^bsub>(I)\<^esub> A be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    have "SF c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_def_18 sorry
    then have A1: "SF (\\)PBOOLEK4\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M (\\)PBOOLEK4\<^bsub>(I)\<^esub> A"
      using pboole_th_53 sorry
    have "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M (\\)PBOOLEK4\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pboole_th_56 sorry
    then have "SF (\\)PBOOLEK4\<^bsub>(I)\<^esub> A c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using A1 pboole_th_13 sorry
    thus "SF (\\)PBOOLEK4\<^bsub>(I)\<^esub> A be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using pboole_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_37:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix SG assume [ty]: "SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    have "SF (\\)PBOOLEK4\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M & SG (\\)PBOOLEK4\<^bsub>(I)\<^esub> SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using mssubfam_th_36 sorry
    thus "SF (\\+\\)PBOOLEK5\<^bsub>(I)\<^esub> SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using mssubfam_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_38:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> M implies {PZFMISC1K1\<^bsub>(I)\<^esub> A} be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> M implies {PZFMISC1K1\<^bsub>(I)\<^esub> A} be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    assume "A c=PBOOLER2\<^bsub>(I)\<^esub> M"
    then have "A inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using mboolean_th_18 sorry
    then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using pzfmisc1_th_33 sorry
    thus "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using pboole_def_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_39:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> M & B c=PBOOLER2\<^bsub>(I)\<^esub> M implies {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds A c=PBOOLER2\<^bsub>(I)\<^esub> M & B c=PBOOLER2\<^bsub>(I)\<^esub> M implies {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    assume "A c=PBOOLER2\<^bsub>(I)\<^esub> M & B c=PBOOLER2\<^bsub>(I)\<^esub> M"
    then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M & {PZFMISC1K1\<^bsub>(I)\<^esub> B} be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using mssubfam_th_38 sorry
    then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using mssubfam_th_34 sorry
    thus "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      using pzfmisc1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_40:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds unionMBOOLEANK2\<^bsub>(I)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> M"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds unionMBOOLEANK2\<^bsub>(I)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> M"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    have A1: " for x be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of x holds unionSETFAM-1K5\<^bsub>(x)\<^esub> F be SubsetSUBSET-1M2-of x"
       sorry
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies unionMBOOLEANK2\<^bsub>(I)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 M .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      have "SF .FUNCT-1K1 i be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i"
        using A2 mssubfam_th_32 sorry
      then have "unionTARSKIK3 (SF .FUNCT-1K1 i) be SubsetSUBSET-1M2-of M .FUNCT-1K1 i"
        using A1 sorry
      then have "unionTARSKIK3 (SF .FUNCT-1K1 i) c=TARSKIR1 M .FUNCT-1K1 i"
         sorry
      thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 M .FUNCT-1K1 i"
        using A2 mboolean_def_2 sorry
    qed "sorry"
    thus "unionMBOOLEANK2\<^bsub>(I)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> M"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef mssubfam_def_1 ("meetMSSUBFAMK3\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
"func meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF \<rightarrow> ManySortedSetPBOOLEM1-of I means
  \<lambda>it.  for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)"
proof-
  (*existence*)
    show " ex it be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)"
    proof-
      have " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & ( for Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i holds  not (Q =XBOOLE-0R4 SF .FUNCT-1K1 i & VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)))))"
      proof-
        let ?Z = "\<lambda>Lamb1. \<lambda>Lamb2.  ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 Lamb1 st Q =XBOOLE-0R4 SF .FUNCT-1K1 Lamb1 & Lamb2 =HIDDENR1 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 Lamb1)\<^esub> Q"
        have A1: " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex j be objectHIDDENM1 st ?Z(i,j))"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex tVar18 be objectHIDDENM1 st  ex tVar19 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st tVar19 =XBOOLE-0R4 SF .FUNCT-1K1 i & tVar18 =HIDDENR1 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> tVar19)"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume A2: "i inHIDDENR3 I"
            then obtain Q where 
              [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and QDef:"Q = SF .FUNCT-1K1 i"
              using mssubfam_th_32 sorry
            obtain a where 
              [ty]:"a be ManySortedSetPBOOLEM1-of I" and aDef:"a = I -->FUNCOP-1K7 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
               sorry
            show " ex tVar18 be objectHIDDENM1 st  ex tVar19 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st tVar19 =XBOOLE-0R4 SF .FUNCT-1K1 i & tVar18 =HIDDENR1 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> tVar19"
            proof(rule bexI[of _ "a .FUNCT-1K1 i"])
              show " ex tVar19 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st tVar19 =XBOOLE-0R4 SF .FUNCT-1K1 i & a .FUNCT-1K1 i =HIDDENR1 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> tVar19"
              proof(rule bexI[of _ "Q"])
                show "Q =XBOOLE-0R4 SF .FUNCT-1K1 i & a .FUNCT-1K1 i =HIDDENR1 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
                  using A2 funcop_1_th_7 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex X be ManySortedSetPBOOLEM1-of I st  for i be objectHIDDENM1 holds i inHIDDENR3 I implies ?Z(i,X .FUNCT-1K1 i)"
          using pboole_sch_3 A1 sorry
        thus " not ( for VarFor1 be ManySortedSetPBOOLEM1-of I holds  not ( for i be objectHIDDENM1 holds  not (i inHIDDENR3 I & ( for Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i holds  not (Q =XBOOLE-0R4 SF .FUNCT-1K1 i & VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ManySortedSetPBOOLEM1-of I holds  for it2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it1 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & it2 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q)) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be ManySortedSetPBOOLEM1-of I holds  for X2 be ManySortedSetPBOOLEM1-of I holds ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q1 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q1 =XBOOLE-0R4 SF .FUNCT-1K1 i & X1 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q1)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q2 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q2 =XBOOLE-0R4 SF .FUNCT-1K1 i & X2 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q2)) implies X1 =PBOOLER7\<^bsub>(I)\<^esub> X2"
      proof(rule ballI,rule ballI,rule impI)
        fix X1 assume [ty]: "X1 be ManySortedSetPBOOLEM1-of I"
        fix X2 assume [ty]: "X2 be ManySortedSetPBOOLEM1-of I"
        assume A3: "( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q1 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q1 =XBOOLE-0R4 SF .FUNCT-1K1 i & X1 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q1)) & ( for i be objectHIDDENM1 holds i inHIDDENR3 I implies ( ex Q2 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q2 =XBOOLE-0R4 SF .FUNCT-1K1 i & X2 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q2))"
        have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies X1 .FUNCT-1K1 i =XBOOLE-0R4 X2 .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be objectHIDDENM1"
          assume "i inHIDDENR3 I"
          then have "( ex Q1 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q1 =XBOOLE-0R4 SF .FUNCT-1K1 i & X1 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q1) & ( ex Q2 be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q2 =XBOOLE-0R4 SF .FUNCT-1K1 i & X2 .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q2)"
            using A3 sorry
          thus "X1 .FUNCT-1K1 i =XBOOLE-0R4 X2 .FUNCT-1K1 i"
             sorry
        qed "sorry"
        thus "X1 =PBOOLER7\<^bsub>(I)\<^esub> X2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

abbreviation(input) MSSUBFAMK4("meetMSSUBFAMK4\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228) where
  "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF \<equiv> meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF"

mtheorem mssubfam_add_3:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I", "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
"cluster meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF as-term-is ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show "meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
  proof-
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 M .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then have " ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      thus "meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 M .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "meetMSSUBFAMK3\<^bsub>(I,M)\<^esub> SF be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
      using pboole_def_2 pboole_def_18 sorry
  qed
qed "sorry"

mtheorem mssubfam_th_41:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> M"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 M .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A2: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A3: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have "Q =XBOOLE-0R4 {}XBOOLE-0K1"
        using A1 A2 sorry
      thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 M .FUNCT-1K1 i"
        using A3 setfam_1_def_9 sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_42:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SFe be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SFe c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> SFe"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SFe be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SFe c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> SFe"
  proof(rule ballI,rule ballI,rule ballI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SFe assume [ty]: "SFe be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SFe .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> SFe .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A1: "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A2: "Q =XBOOLE-0R4 SFe .FUNCT-1K1 i"and A3: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SFe .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have "meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q c=TARSKIR1 unionSETFAM-1K5\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q & IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A1 A2 setfam_1_th_2 setfam_1_def_9 sorry
      thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SFe .FUNCT-1K1 i c=TARSKIR1 unionMBOOLEANK2\<^bsub>(I)\<^esub> SFe .FUNCT-1K1 i"
        using A1 A2 A3 mboolean_def_2 sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SFe c=PBOOLER2\<^bsub>(I)\<^esub> unionMBOOLEANK2\<^bsub>(I)\<^esub> SFe"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_43:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> A"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> SF"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A3: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A4: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have A5: "A .FUNCT-1K1 i inTARSKIR2 SF .FUNCT-1K1 i"
        using A1 A2 sorry
      then have "IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A3 setfam_1_def_9 sorry
      thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 A .FUNCT-1K1 i"
        using A3 A4 A5 setfam_1_th_3 sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> A"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_44:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> SF implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> SF implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> SF"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A3: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A4: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have "EmptyMSPBOOLEK1 I .FUNCT-1K1 i inTARSKIR2 Q"
        using A1 A2 A3 sorry
      then have A5: "{}XBOOLE-0K1 inTARSKIR2 Q"
         sorry
      have "EmptyMSPBOOLEK1 I .FUNCT-1K1 i inTARSKIR2 SF .FUNCT-1K1 i"
        using A1 A2 sorry
      then have "IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A3 setfam_1_def_9 sorry
      then have "IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q =XBOOLE-0R4 {}XBOOLE-0K1"
        using A5 setfam_1_th_4 sorry
      thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using A4 sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_45:
" for I be setHIDDENM2 holds  for Z be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds ( for Z1 be ManySortedSetPBOOLEM1-of I holds Z1 inPBOOLER1\<^bsub>(I)\<^esub> SF implies Z c=PBOOLER2\<^bsub>(I)\<^esub> Z1) implies Z c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
proof-
  have " for I be setHIDDENM2 holds  for Z be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds ( for Z1 be ManySortedSetPBOOLEM1-of I holds Z1 inPBOOLER1\<^bsub>(I)\<^esub> SF implies Z c=PBOOLER2\<^bsub>(I)\<^esub> Z1) implies Z c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix Z assume [ty]: "Z be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: " for Z1 be ManySortedSetPBOOLEM1-of I holds Z1 inPBOOLER1\<^bsub>(I)\<^esub> SF implies Z c=PBOOLER2\<^bsub>(I)\<^esub> Z1"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies Z .FUNCT-1K1 i c=TARSKIR1 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      obtain T where
        [ty]:"T be ManySortedSetPBOOLEM1-of I" and 
        A2: "T inPBOOLER1\<^bsub>(I)\<^esub> SF"
        using pboole_th_134 sorry
      assume A3: "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A4: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A5: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have A6: " for Z9 be setHIDDENM2 holds Z9 inTARSKIR2 Q implies Z .FUNCT-1K1 i c=TARSKIR1 Z9"
      proof(rule ballI,rule impI)
        fix Z9 assume [ty]: "Z9 be setHIDDENM2"
        assume A7: "Z9 inTARSKIR2 Q"
        have "domRELAT-1K1 (T +*FUNCT-4K1 (i .-->FUNCOP-1K17 Z9)) =XBOOLE-0R4 I"
          using A3 pzfmisc1_th_1 sorry
        then obtain K where 
          [ty]:"K be ManySortedSetPBOOLEM1-of I" and KDef:"K = T +*FUNCT-4K1 (i .-->FUNCOP-1K17 Z9)"
          using partfun1_def_2 relat_1_def_18 sorry
        have A8: "domRELAT-1K1 (i .-->FUNCOP-1K17 Z9) =XBOOLE-0R4 {TARSKIK1 i}"
          using funcop_1_th_13 sorry
        have "i inHIDDENR3 {TARSKIK1 i}"
          using tarski_def_1 sorry
        then have A9: "K .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 Z9).FUNCT-1K1 i"
          using A8 funct_4_th_13 sorry
        also have "... = Z9"
          using funcop_1_th_72 sorry
        finally have "K .FUNCT-1K1 i =HIDDENR1 Z9"
           sorry
        have "K inPBOOLER1\<^bsub>(I)\<^esub> SF"
        proof-
          have " for q be objectHIDDENM1 holds q inHIDDENR3 I implies K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
          proof(rule ballI,rule impI)
            fix q assume [ty]: "q be objectHIDDENM1"
            assume A10: "q inHIDDENR3 I"
            show "K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
            proof-
              have cases: "q =HIDDENR1 i or q <>HIDDENR2 i"
                 sorry
              have case1: "q =HIDDENR1 i implies K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
              proof(rule impI)
                assume "q =HIDDENR1 i"
                thus "K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
                  using A4 A7 A9 sorry
              qed
              have case2: "q <>HIDDENR2 i implies K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
              proof(rule impI)
                assume "q <>HIDDENR2 i"
                then have " not q inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 Z9)"
                  using A8 tarski_def_1 sorry
                then have "K .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
                  using funct_4_th_11 sorry
                thus "K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
                  using A2 A10 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus "K inPBOOLER1\<^bsub>(I)\<^esub> SF"
            using pboole_def_1 sorry
        qed
        then have "Z c=PBOOLER2\<^bsub>(I)\<^esub> K"
          using A1 sorry
        thus "Z .FUNCT-1K1 i c=TARSKIR1 Z9"
          using A3 A9 sorry
      qed "sorry"
      have "IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A3 A4 setfam_1_def_9 sorry
      thus "Z .FUNCT-1K1 i c=TARSKIR1 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i"
        using A3 A4 A5 A6 setfam_1_th_5 sorry
    qed "sorry"
    thus "Z c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_46:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF c=PBOOLER2\<^bsub>(I)\<^esub> SG implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF c=PBOOLER2\<^bsub>(I)\<^esub> SG implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix SG assume [ty]: "SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "SF c=PBOOLER2\<^bsub>(I)\<^esub> SG"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i c=TARSKIR1 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then obtain Qf where
        [ty]:"Qf be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A3: "Qf =XBOOLE-0R4 SF .FUNCT-1K1 i"and A4: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qf"
        using mssubfam_def_1 sorry
      obtain Qg where
        [ty]:"Qg be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A5: "Qg =XBOOLE-0R4 SG .FUNCT-1K1 i"and A6: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qg"
        using A2 mssubfam_def_1 sorry
      have "Qf c=TARSKIR1 Qg"
        using A1 A2 A3 A5 sorry
      thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i c=TARSKIR1 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i"
        using A4 A6 setfam_1_th_44 sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG c=PBOOLER2\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_47:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & A c=PBOOLER2\<^bsub>(I)\<^esub> B implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> B"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & A c=PBOOLER2\<^bsub>(I)\<^esub> B implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> SF"
      and A2: "A c=PBOOLER2\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have A4: "A .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A2 sorry
      obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A5: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A6: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A3 mssubfam_def_1 sorry
      have A7: "A .FUNCT-1K1 i inTARSKIR2 SF .FUNCT-1K1 i"
        using A1 A3 sorry
      then have "IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A5 setfam_1_def_9 sorry
      thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i c=TARSKIR1 B .FUNCT-1K1 i"
        using A5 A6 A7 A4 setfam_1_th_7 sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF c=PBOOLER2\<^bsub>(I)\<^esub> B"
      using pboole_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_48:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> SF"
      and A2: "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A4: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A5: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have A6: "A .FUNCT-1K1 i inTARSKIR2 SF .FUNCT-1K1 i"
        using A1 A3 sorry
      have "A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using A2 A3 pboole_def_5 sorry
      then have "A .FUNCT-1K1 i /\\XBOOLE-0K3 B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      then have "A .FUNCT-1K1 i missesXBOOLE-0R1 B .FUNCT-1K1 i"
         sorry
      then have "meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q missesXBOOLE-0R1 B .FUNCT-1K1 i"
        using A4 A6 setfam_1_th_8 sorry
      then have "meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q /\\SUBSET-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> B .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      then have A7: "meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q /\\SUBSET-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> B .FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
         sorry
      have "IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q =XBOOLE-0R4 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A4 A6 setfam_1_def_9 sorry
      thus "(meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B).FUNCT-1K1 i =XBOOLE-0R4 EmptyMSPBOOLEK1 I .FUNCT-1K1 i"
        using A3 A5 A7 pboole_def_5 sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_49:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SH be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SH =PBOOLER7\<^bsub>(I)\<^esub> SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH =PBOOLER7\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for SH be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SH =PBOOLER7\<^bsub>(I)\<^esub> SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH =PBOOLER7\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix SG assume [ty]: "SG be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix SH assume [ty]: "SH be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "SH =PBOOLER7\<^bsub>(I)\<^esub> SF (\\/)PBOOLEK2\<^bsub>(I)\<^esub> SG"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =XBOOLE-0R4 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then obtain Qf where
        [ty]:"Qf be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A3: "Qf =XBOOLE-0R4 SF .FUNCT-1K1 i"and A4: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qf"
        using mssubfam_def_1 sorry
      obtain Qh where
        [ty]:"Qh be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A5: "Qh =XBOOLE-0R4 SH .FUNCT-1K1 i"and A6: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qh"
        using A2 mssubfam_def_1 sorry
      obtain Qg where
        [ty]:"Qg be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A7: "Qg =XBOOLE-0R4 SG .FUNCT-1K1 i"and A8: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qg"
        using A2 mssubfam_def_1 sorry
      have A9: "Qh =XBOOLE-0R4 Qf \\/SUBSET-1K4\<^bsub>(boolZFMISC-1K1 (M .FUNCT-1K1 i))\<^esub> Qg"
        using A1 A2 A3 A7 A5 pboole_def_4 sorry
      have "(((Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1) & meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i or (Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1) & (Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i)) or (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1) & (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i)) or (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1) & (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i)"
      proof-
        show "(((Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1) & meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i or (Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1) & (Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i)) or (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1) & (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i)) or (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1) & (Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i)"
        proof-
          have cases: "((Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1 or Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1) or Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1) or Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1"
             sorry
          have case1: "Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
          proof(rule impI)
            assume A10: "Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1"
            then have "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qh"
              using A6 A9 setfam_1_def_9 sorry
            also have "... = meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qf /\\SUBSET-1K9\<^bsub>(M .FUNCT-1K1 i)\<^esub> meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qg"
              using A9 A10 setfam_1_th_9 sorry
            also have "... = meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i /\\SUBSET-1K9\<^bsub>(M .FUNCT-1K1 i)\<^esub> meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qg"
              using A4 A10 setfam_1_def_9 sorry
            also have "... = meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i /\\XBOOLE-0K3 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i"
              using A8 A10 setfam_1_def_9 sorry
            also have "... = (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
              using A2 pboole_def_5 sorry
            finally show "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
               sorry
          qed
          have case2: "Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
          proof(rule impI)
            assume A11: "Qf <>HIDDENR2 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1"
            then have "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i /\\XBOOLE-0K3 M .FUNCT-1K1 i"
              using A4 A6 A9 xboole_1_th_28 sorry
            also have "... = meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i /\\XBOOLE-0K3 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i"
              using A8 A11 setfam_1_def_9 sorry
            also have "... = (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
              using A2 pboole_def_5 sorry
            finally show "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
               sorry
          qed
          have case3: "Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
          proof(rule impI)
            assume A12: "Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg <>HIDDENR2 {}XBOOLE-0K1"
            then have "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 M .FUNCT-1K1 i /\\XBOOLE-0K3 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i"
              using A8 A6 A9 xboole_1_th_28 sorry
            also have "... = meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i /\\XBOOLE-0K3 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG .FUNCT-1K1 i"
              using A4 A12 setfam_1_def_9 sorry
            also have "... = (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
              using A2 pboole_def_5 sorry
            finally show "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
               sorry
          qed
          have case4: "Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1 implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
          proof(rule impI)
            assume "Qf =XBOOLE-0R4 {}XBOOLE-0K1 & Qg =XBOOLE-0R4 {}XBOOLE-0K1"
            then have "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qf)/\\SUBSET-1K9\<^bsub>(M .FUNCT-1K1 i)\<^esub> (IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Qg)"
              using A6 A9 sorry
            also have "... = (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
              using A2 A4 A8 pboole_def_5 sorry
            finally show "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =HIDDENR1 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed
      thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH .FUNCT-1K1 i =XBOOLE-0R4 (meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SH =PBOOLER7\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF (/\\)PBOOLEK3\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SG"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_50:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> V} implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> V} implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix V assume [ty]: "V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
    assume A1: "SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> V}"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =HIDDENR1 V .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A3: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A4: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =HIDDENR1 meetSETFAM-1K6\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A1 A2 A3 A4 setfam_1_def_9 sorry
      also have "... = meetSETFAM-1K1 {TARSKIK1 V .FUNCT-1K1 i }"
        using A1 A2 A3 pzfmisc1_def_1 sorry
      also have "... = V .FUNCT-1K1 i"
        using setfam_1_th_10 sorry
      finally show "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =HIDDENR1 V .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_51:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds  for W be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> V,W } implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V (/\\)PBOOLEK3\<^bsub>(I)\<^esub> W"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds  for V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds  for W be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M holds SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> V,W } implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V (/\\)PBOOLEK3\<^bsub>(I)\<^esub> W"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    fix V assume [ty]: "V be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
    fix W assume [ty]: "W be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
    assume A1: "SF =PBOOLER7\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> V,W }"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =HIDDENR1 (V (/\\)PBOOLEK3\<^bsub>(I)\<^esub> W).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A2: "i inHIDDENR3 I"
      then have " ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      then have "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =HIDDENR1 meetSETFAM-1K1 ({PZFMISC1K2\<^bsub>(I)\<^esub> V,W } .FUNCT-1K1 i)"
        using A1 A2 setfam_1_def_9 sorry
      also have "... = meetSETFAM-1K1 {TARSKIK2 V .FUNCT-1K1 i,W .FUNCT-1K1 i }"
        using A2 pzfmisc1_def_2 sorry
      also have "... = V .FUNCT-1K1 i /\\XBOOLE-0K3 W .FUNCT-1K1 i"
        using setfam_1_th_11 sorry
      also have "... = (V (/\\)PBOOLEK3\<^bsub>(I)\<^esub> W).FUNCT-1K1 i"
        using A2 pboole_def_5 sorry
      finally show "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =HIDDENR1 (V (/\\)PBOOLEK3\<^bsub>(I)\<^esub> W).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF =PBOOLER7\<^bsub>(I)\<^esub> V (/\\)PBOOLEK3\<^bsub>(I)\<^esub> W"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_52:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF implies ( for B be ManySortedSetPBOOLEM1-of I holds B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A inPBOOLER1\<^bsub>(I)\<^esub> B)"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF implies ( for B be ManySortedSetPBOOLEM1-of I holds B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A inPBOOLER1\<^bsub>(I)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
    fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
    assume A2: "B inPBOOLER1\<^bsub>(I)\<^esub> SF"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i inTARSKIR2 B .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      assume A3: "i inHIDDENR3 I"
      then have A4: "A .FUNCT-1K1 i inTARSKIR2 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i"
        using A1 sorry
      have A5: "B .FUNCT-1K1 i inTARSKIR2 SF .FUNCT-1K1 i"
        using A2 A3 sorry
      have " ex Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i st Q =XBOOLE-0R4 SF .FUNCT-1K1 i & meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using A3 mssubfam_def_1 sorry
      thus "A .FUNCT-1K1 i inTARSKIR2 B .FUNCT-1K1 i"
        using A4 A5 setfam_1_th_43 sorry
    qed "sorry"
    thus "A inPBOOLER1\<^bsub>(I)\<^esub> B"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_th_53:
" for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> M & ( for B be ManySortedSetPBOOLEM1-of I holds B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A inPBOOLER1\<^bsub>(I)\<^esub> B) implies A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
proof-
  have " for I be setHIDDENM2 holds  for A be ManySortedSetPBOOLEM1-of I holds  for M be ManySortedSetPBOOLEM1-of I holds  for SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds A inPBOOLER1\<^bsub>(I)\<^esub> M & ( for B be ManySortedSetPBOOLEM1-of I holds B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A inPBOOLER1\<^bsub>(I)\<^esub> B) implies A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    fix SF assume [ty]: "SF be non-emptyRELAT-1V2\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> M"
      and A2: " for B be ManySortedSetPBOOLEM1-of I holds B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A inPBOOLER1\<^bsub>(I)\<^esub> B"
    have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies A .FUNCT-1K1 i inTARSKIR2 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be objectHIDDENM1"
      obtain T where
        [ty]:"T be ManySortedSetPBOOLEM1-of I" and 
        A3: "T inPBOOLER1\<^bsub>(I)\<^esub> SF"
        using pboole_th_134 sorry
      assume A4: "i inHIDDENR3 I"
      then obtain Q where
        [ty]:"Q be Subset-FamilySETFAM-1M1-of M .FUNCT-1K1 i" and 
        A5: "Q =XBOOLE-0R4 SF .FUNCT-1K1 i"and A6: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(M .FUNCT-1K1 i)\<^esub> Q"
        using mssubfam_def_1 sorry
      have A7: " for B9 be setHIDDENM2 holds B9 inTARSKIR2 Q implies A .FUNCT-1K1 i inTARSKIR2 B9"
      proof(rule ballI,rule impI)
        fix B9 assume [ty]: "B9 be setHIDDENM2"
        assume A8: "B9 inTARSKIR2 Q"
        have "domRELAT-1K1 (T +*FUNCT-4K1 (i .-->FUNCOP-1K17 B9)) =XBOOLE-0R4 I"
          using A4 pzfmisc1_th_1 sorry
        then obtain K where 
          [ty]:"K be ManySortedSetPBOOLEM1-of I" and KDef:"K = T +*FUNCT-4K1 (i .-->FUNCOP-1K17 B9)"
          using partfun1_def_2 relat_1_def_18 sorry
        have A9: "domRELAT-1K1 (i .-->FUNCOP-1K17 B9) =XBOOLE-0R4 {TARSKIK1 i}"
          using funcop_1_th_13 sorry
        have "i inHIDDENR3 {TARSKIK1 i}"
          using tarski_def_1 sorry
        then have A10: "K .FUNCT-1K1 i =HIDDENR1 (i .-->FUNCOP-1K17 B9).FUNCT-1K1 i"
          using A9 funct_4_th_13 sorry
        also have "... = B9"
          using funcop_1_th_72 sorry
        finally have "K .FUNCT-1K1 i =HIDDENR1 B9"
           sorry
        have "K inPBOOLER1\<^bsub>(I)\<^esub> SF"
        proof-
          have " for q be objectHIDDENM1 holds q inHIDDENR3 I implies K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
          proof(rule ballI,rule impI)
            fix q assume [ty]: "q be objectHIDDENM1"
            assume A11: "q inHIDDENR3 I"
            show "K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
            proof-
              have cases: "q =HIDDENR1 i or q <>HIDDENR2 i"
                 sorry
              have case1: "q =HIDDENR1 i implies K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
              proof(rule impI)
                assume "q =HIDDENR1 i"
                thus "K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
                  using A5 A8 A10 sorry
              qed
              have case2: "q <>HIDDENR2 i implies K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
              proof(rule impI)
                assume "q <>HIDDENR2 i"
                then have " not q inHIDDENR3 domRELAT-1K1 (i .-->FUNCOP-1K17 B9)"
                  using A9 tarski_def_1 sorry
                then have "K .FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
                  using funct_4_th_11 sorry
                thus "K .FUNCT-1K1 q inTARSKIR2 SF .FUNCT-1K1 q"
                  using A3 A11 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus "K inPBOOLER1\<^bsub>(I)\<^esub> SF"
            using pboole_def_1 sorry
        qed
        then have "A inPBOOLER1\<^bsub>(I)\<^esub> K"
          using A2 sorry
        thus "A .FUNCT-1K1 i inTARSKIR2 B9"
          using A4 A10 sorry
      qed "sorry"
      have "A .FUNCT-1K1 i inTARSKIR2 M .FUNCT-1K1 i"
        using A1 A4 sorry
      thus "A .FUNCT-1K1 i inTARSKIR2 meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF .FUNCT-1K1 i"
        using A6 A7 setfam_1_th_43 sorry
    qed "sorry"
    thus "A inPBOOLER1\<^bsub>(I)\<^esub> meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> SF"
      using pboole_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef mssubfam_def_2 ("additiveMSSUBFAMV1\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> IT & B inPBOOLER1\<^bsub>(I)\<^esub> IT implies A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_3 ("absolutely-additiveMSSUBFAMV2\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for F be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds F c=PBOOLER2\<^bsub>(I)\<^esub> IT implies unionMBOOLEANK2\<^bsub>(I)\<^esub> F inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_4 ("multiplicativeMSSUBFAMV3\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> IT & B inPBOOLER1\<^bsub>(I)\<^esub> IT implies A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_5 ("absolutely-multiplicativeMSSUBFAMV4\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT.  for F be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds F c=PBOOLER2\<^bsub>(I)\<^esub> IT implies meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> F inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_6 ("properly-upper-boundMSSUBFAMV5\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT. M inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mdef mssubfam_def_7 ("properly-lower-boundMSSUBFAMV6\<^bsub>'( _ , _ ')\<^esub>" [0,0]70 ) where
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"attr properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M means
  (\<lambda>IT. EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> IT)"..

mlemma mssubfam_lm_1:
" for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
proof-
  have " for I be setHIDDENM2 holds  for M be ManySortedSetPBOOLEM1-of I holds boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub> & (boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> & (boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub> & (boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> & (boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> & boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>))))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix I assume [ty]: "I be setHIDDENM2"
    fix M assume [ty]: "M be ManySortedSetPBOOLEM1-of I"
    show "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>"
    proof-
      have " for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M implies A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      proof(rule ballI,rule ballI,rule impI)
        fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
        fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
        assume "A inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
        then have "A c=PBOOLER2\<^bsub>(I)\<^esub> M & B c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using mboolean_th_1 sorry
        then have "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using pboole_th_16 sorry
        thus "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
          using mboolean_th_1 sorry
      qed "sorry"
      thus "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>"
        using mssubfam_def_2 sorry
    qed
    show "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>"
      using mssubfam_th_40 mboolean_th_18 sorry
    show "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>"
    proof-
      have " for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M & B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M implies A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
        fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
        assume A1: "A inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
          and "B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
        have "A c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using A1 mboolean_th_1 sorry
        then have "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using mboolean_th_14 sorry
        thus "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
          using mboolean_th_1 sorry
      qed "sorry"
      thus "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>"
        using mssubfam_def_4 sorry
    qed
    show "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>"
      using pboole_def_18 mboolean_th_18 sorry
    have "M inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using mboolean_th_18 sorry
    thus "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>"
       sorry
    have "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> M"
      using mboolean_th_5 sorry
    then have "EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"
      using mboolean_th_1 sorry
    thus "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mssubfam_cl_21:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster non-emptyRELAT-1V2\<bar>additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*existence*)
  show " ex it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st it be non-emptyRELAT-1V2\<bar>additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
  proof-
    have " ex tVar20 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st (((((tVar20 be non-emptyRELAT-1V2 & tVar20 be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>) & tVar20 be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>) & tVar20 be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>) & tVar20 be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>) & tVar20 be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>) & tVar20 be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
    proof-
      show " ex tVar20 be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M st (((((tVar20 be non-emptyRELAT-1V2 & tVar20 be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>) & tVar20 be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>) & tVar20 be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>) & tVar20 be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>) & tVar20 be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>) & tVar20 be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
      proof(rule bexI[of _ "boolMSSUBFAMK1\<^bsub>(I)\<^esub> M"])
        show "(((((boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be non-emptyRELAT-1V2 & boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>) & boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>) & boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>) & boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>) & boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>) & boolMSSUBFAMK1\<^bsub>(I)\<^esub> M be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
          using mssubfam_lm_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) MSSUBFAMK5("boolMSSUBFAMK5\<^bsub>'( _ ')\<^esub>  _ " [0,228]228) where
  "boolMSSUBFAMK5\<^bsub>(I)\<^esub> M \<equiv> boolMBOOLEANK1\<^bsub>(I)\<^esub> M"

mtheorem mssubfam_add_4:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster boolMBOOLEANK1\<^bsub>(I)\<^esub> M as-term-is additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show "boolMBOOLEANK1\<^bsub>(I)\<^esub> M be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>\<bar>absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>\<bar>multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>\<bar>absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>\<bar>properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>\<bar>properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>\<bar>MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
    using mssubfam_lm_1 sorry
qed "sorry"

mtheorem mssubfam_cl_22:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> also-is additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> implies it be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>"
  proof-
    have " for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> implies SF be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>"
    proof(rule ballI,rule impI)
      fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      assume A1: "SF be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>"
      have " for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> SF"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
        fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
        assume A2: "A inPBOOLER1\<^bsub>(I)\<^esub> SF"
          and A3: "B inPBOOLER1\<^bsub>(I)\<^esub> SF"
        have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> SF & {PZFMISC1K1\<^bsub>(I)\<^esub> B} c=PBOOLER2\<^bsub>(I)\<^esub> SF"
          using A2 A3 pzfmisc1_th_33 sorry
        then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} c=PBOOLER2\<^bsub>(I)\<^esub> SF"
          using pboole_th_16 sorry
        then have A4: "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } c=PBOOLER2\<^bsub>(I)\<^esub> SF"
          using pzfmisc1_th_10 sorry
        have "B be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
          using A3 mssubfam_th_33 sorry
        then have A5: "B c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using pboole_def_18 sorry
        have "A be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
          using A2 mssubfam_th_33 sorry
        then have "A c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using pboole_def_18 sorry
        then have "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
          using A5 mssubfam_th_39 sorry
        then have "unionMBOOLEANK2\<^bsub>(I)\<^esub> {PZFMISC1K2\<^bsub>(I)\<^esub> A,B } inPBOOLER1\<^bsub>(I)\<^esub> SF"
          using A1 A4 sorry
        thus "A (\\/)PBOOLEK2\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> SF"
          using pzfmisc1_th_32 sorry
      qed "sorry"
      thus "SF be additiveMSSUBFAMV1\<^bsub>(I,M)\<^esub>"
        using mssubfam_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_23:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> also-is multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> implies it be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>"
  proof-
    have " for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> implies SF be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>"
    proof(rule ballI,rule impI)
      fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      assume A1: "SF be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>"
      have " for A be ManySortedSetPBOOLEM1-of I holds  for B be ManySortedSetPBOOLEM1-of I holds A inPBOOLER1\<^bsub>(I)\<^esub> SF & B inPBOOLER1\<^bsub>(I)\<^esub> SF implies A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> SF"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A assume [ty]: "A be ManySortedSetPBOOLEM1-of I"
        fix B assume [ty]: "B be ManySortedSetPBOOLEM1-of I"
        assume A2: "A inPBOOLER1\<^bsub>(I)\<^esub> SF"
          and A3: "B inPBOOLER1\<^bsub>(I)\<^esub> SF"
        have A4: "B be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
          using A3 mssubfam_th_33 sorry
        then have A5: "B c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using pboole_def_18 sorry
        have A6: "A be ManySortedSubsetPBOOLEM6\<^bsub>(I)\<^esub>-of M"
          using A2 mssubfam_th_33 sorry
        then have "A c=PBOOLER2\<^bsub>(I)\<^esub> M"
          using pboole_def_18 sorry
        then obtain ab where 
          [ty]:"ab be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M" and abDef:"ab = {PZFMISC1K2\<^bsub>(I)\<^esub> A,B }"
          using A5 mssubfam_th_39 sorry
        have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} c=PBOOLER2\<^bsub>(I)\<^esub> SF & {PZFMISC1K1\<^bsub>(I)\<^esub> B} c=PBOOLER2\<^bsub>(I)\<^esub> SF"
          using A2 A3 pzfmisc1_th_33 sorry
        then have "{PZFMISC1K1\<^bsub>(I)\<^esub> A} (\\/)PBOOLEK2\<^bsub>(I)\<^esub> {PZFMISC1K1\<^bsub>(I)\<^esub> B} c=PBOOLER2\<^bsub>(I)\<^esub> SF"
          using pboole_th_16 sorry
        then have "{PZFMISC1K2\<^bsub>(I)\<^esub> A,B } c=PBOOLER2\<^bsub>(I)\<^esub> SF"
          using pzfmisc1_th_10 sorry
        then have "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> ab inPBOOLER1\<^bsub>(I)\<^esub> SF"
          using A1 sorry
        thus "A (/\\)PBOOLEK3\<^bsub>(I)\<^esub> B inPBOOLER1\<^bsub>(I)\<^esub> SF"
          using A6 A4 mssubfam_th_51 sorry
      qed "sorry"
      thus "SF be multiplicativeMSSUBFAMV3\<^bsub>(I,M)\<^esub>"
        using mssubfam_def_4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_24:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> also-is properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> implies it be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>"
  proof-
    have " for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub> implies SF be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>"
    proof(rule ballI,rule impI)
      have "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK5\<^bsub>(I)\<^esub> M"
        using pboole_th_43 sorry
      then obtain a where 
        [ty]:"a be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M" and aDef:"a = EmptyMSPBOOLEK1 I"
        using pboole_def_18 sorry
      fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      assume A1: "SF be absolutely-multiplicativeMSSUBFAMV4\<^bsub>(I,M)\<^esub>"
      have Cut1798: "meetMSSUBFAMK4\<^bsub>(I,M)\<^esub> a =PBOOLER7\<^bsub>(I)\<^esub> M & EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> SF"
        using mssubfam_th_41 pboole_th_43 sorry
      have "M inPBOOLER1\<^bsub>(I)\<^esub> SF"
      proof-
        show "M inPBOOLER1\<^bsub>(I)\<^esub> SF"
          using A1 Cut1798 sorry
      qed
      thus "SF be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>"
        using mssubfam_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_25:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> also-is non-emptyRELAT-1V2 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> implies it be non-emptyRELAT-1V2"
  proof-
    have " for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub> implies SF be non-emptyRELAT-1V2"
    proof(rule ballI,rule impI)
      fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      assume "SF be properly-upper-boundMSSUBFAMV5\<^bsub>(I,M)\<^esub>"
      then have A1: "M inPBOOLER1\<^bsub>(I)\<^esub> SF"
         sorry
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not SF .FUNCT-1K1 i be emptyXBOOLE-0V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        thus " not SF .FUNCT-1K1 i be emptyXBOOLE-0V1"
          using A1 sorry
      qed "sorry"
      thus "SF be non-emptyRELAT-1V2"
        using pboole_def_13 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_26:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> also-is properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> implies it be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
  proof-
    have " for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub> implies SF be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
    proof(rule ballI,rule impI)
      have "EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> boolMSSUBFAMK5\<^bsub>(I)\<^esub> M"
        using pboole_th_43 sorry
      then obtain a where 
        [ty]:"a be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M" and aDef:"a = EmptyMSPBOOLEK1 I"
        using pboole_def_18 sorry
      fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      assume A1: "SF be absolutely-additiveMSSUBFAMV2\<^bsub>(I,M)\<^esub>"
      have Cut1827: "unionMBOOLEANK2\<^bsub>(I)\<^esub> a =PBOOLER7\<^bsub>(I)\<^esub> EmptyMSPBOOLEK1 I & EmptyMSPBOOLEK1 I c=PBOOLER2\<^bsub>(I)\<^esub> SF"
        using pboole_th_43 sorry
      have "EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> SF"
      proof-
        show "EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> SF"
          using A1 Cut1827 sorry
      qed
      thus "SF be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
        using mssubfam_def_7 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mssubfam_cl_27:
  mlet "I be setHIDDENM2", "M be ManySortedSetPBOOLEM1-of I"
"cluster properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> also-is non-emptyRELAT-1V2 for MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
proof
(*coherence*)
  show " for it be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds it be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> implies it be non-emptyRELAT-1V2"
  proof-
    have " for SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M holds SF be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub> implies SF be non-emptyRELAT-1V2"
    proof(rule ballI,rule impI)
      fix SF assume [ty]: "SF be MSSubsetFamilyMSSUBFAMM1\<^bsub>(I)\<^esub>-of M"
      assume "SF be properly-lower-boundMSSUBFAMV6\<^bsub>(I,M)\<^esub>"
      then have A1: "EmptyMSPBOOLEK1 I inPBOOLER1\<^bsub>(I)\<^esub> SF"
         sorry
      have " for i be objectHIDDENM1 holds i inHIDDENR3 I implies  not SF .FUNCT-1K1 i be emptyXBOOLE-0V1"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be objectHIDDENM1"
        assume "i inHIDDENR3 I"
        thus " not SF .FUNCT-1K1 i be emptyXBOOLE-0V1"
          using A1 sorry
      qed "sorry"
      thus "SF be non-emptyRELAT-1V2"
        using pboole_def_13 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

end
