theory afinsq_1
  imports ordinal4 finsop_1 funct_7
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, n for "NatNAT-1M1"
reserve x, y, z, y1, y2 for "objectHIDDENM1"
reserve X, Y for "setHIDDENM2"
reserve f, g for "FunctionFUNCT-1M1"
(*\$CT*)
mtheorem afinsq_1_th_2:
" for n be NatNAT-1M1 holds SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n} =XBOOLE-0R4 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n} =XBOOLE-0R4 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n inTARSKIR2 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      using nat_1_th_45 sorry
    then have A1: "{TARSKIK1 n} c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      using zfmisc_1_th_31 sorry
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have Cut59: "SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      using nat_1_th_39 sorry
    have "SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n} c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) & SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n}"
    proof(rule conjMI)
      show "SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n} c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
        using A1 xboole_1_th_8 Cut59 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) implies x inHIDDENR3 SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
        then have 
          [ty]:"x be NatNAT-1M1"
           sorry
        have "x <XXREAL-0R3 n & x inTARSKIR2 SegmCARD-1K5 n or x =XBOOLE-0R4 n & (x =XBOOLE-0R4 n implies x inTARSKIR2 {TARSKIK1 n})"
        proof-
          have Cut66: "x <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A2 nat_1_th_44 sorry
          show "x <XXREAL-0R3 n & x inTARSKIR2 SegmCARD-1K5 n or x =XBOOLE-0R4 n & (x =XBOOLE-0R4 n implies x inTARSKIR2 {TARSKIK1 n})"
          proof-
            have cases: "x <XXREAL-0R3 n or x =XBOOLE-0R4 n"
              using nat_1_th_22 Cut66 sorry
            have case1: "x <XXREAL-0R3 n implies x inTARSKIR2 SegmCARD-1K5 n"
            proof(rule impI)
              assume "x <XXREAL-0R3 n"
              thus "x inTARSKIR2 SegmCARD-1K5 n"
                using nat_1_th_44 sorry
            qed
            have case2: "x =XBOOLE-0R4 n implies x inTARSKIR2 {TARSKIK1 n}"
            proof(rule impI)
              assume "x =XBOOLE-0R4 n"
              thus "x inTARSKIR2 {TARSKIK1 n}"
                using tarski_def_1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n}"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n}"
        using tarski_def_3 sorry
    qed
    thus "SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n} =XBOOLE-0R4 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_3:
" for n be NatNAT-1M1 holds SegFINSEQ-1K2 n c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds SegFINSEQ-1K2 n c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 n implies x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 SegFINSEQ-1K2 n"
      then have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      have "x <=XXREAL-0R1 n"
        using A1 finseq_1_th_1 sorry
      then have "x <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      thus "x inHIDDENR3 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
        using nat_1_th_44 sorry
    qed "sorry"
    thus "SegFINSEQ-1K2 n c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_4:
" for n be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
proof-
  have " for n be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n +NAT-1K1 \<one>\<^sub>M c=TARSKIR1 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n & {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n c=TARSKIR1 n +NAT-1K1 \<one>\<^sub>M"
    proof(rule conjMI)
      show "n +NAT-1K1 \<one>\<^sub>M c=TARSKIR1 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 n +NAT-1K1 \<one>\<^sub>M implies x inHIDDENR3 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 n +NAT-1K1 \<one>\<^sub>M"
          then have "x inHIDDENR3 {j where j be NatNAT-1M1 : j <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M }"
            using axioms_th_4 sorry
          then obtain j where
            [ty]:"j be NatNAT-1M1" and 
            A1: "j =HIDDENR1 x"and A2: "j <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
             sorry
          have "j =XBOOLE-0R4 0NUMBERSK6 or \<one>\<^sub>M <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M & j <=XXREAL-0R1 n"
            using A2 nat_1_th_13 xreal_1_th_29 sorry
          then have "j =XBOOLE-0R4 0NUMBERSK6 or \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 n"
            using nat_1_th_13 sorry
          then have "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 } or x inHIDDENR3 SegFINSEQ-1K2 n"
            using A1 finseq_1_th_1 tarski_def_1 sorry
          thus "x inHIDDENR3 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
            using xboole_0_def_3 sorry
        qed "sorry"
        thus "n +NAT-1K1 \<one>\<^sub>M c=TARSKIR1 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
          using tarski_def_3 sorry
      qed
      have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have A3: "SegmCARD-1K5 \<one>\<^sub>M c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
        using nat_1_th_39 sorry
      have "SegFINSEQ-1K2 n c=TARSKIR1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
        using afinsq_1_th_3 sorry
      thus "{TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n c=TARSKIR1 n +NAT-1K1 \<one>\<^sub>M"
        using A3 card_1_th_49 xboole_1_th_8 sorry
    qed
    thus "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 } \\/XBOOLE-0K2 SegFINSEQ-1K2 n"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_5:
" for r be FunctionFUNCT-1M1 holds r be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5 iff ( ex n be NatNAT-1M1 st domRELAT-1K1 r =XBOOLE-0R4 n)"
  using finset_1_th_10 sorry

syntax AFINSQ_1M1 :: "Ty" ("XFinSequenceAFINSQ-1M1" 70)
translations "XFinSequenceAFINSQ-1M1" \<rightharpoonup> "finiteFINSET-1V1\<bar>SequenceORDINAL1M4"

reserve p, q, r, s, t for "XFinSequenceAFINSQ-1M1"
mtheorem afinsq_1_cl_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"cluster domRELAT-1K1 p as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "domRELAT-1K1 p be naturalORDINAL1V7"
     sorry
qed "sorry"

abbreviation(input) AFINSQ_1K1("lenAFINSQ-1K1  _ " [228]228) where
  "lenAFINSQ-1K1 p \<equiv> cardCARD-1K1 p"

mtheorem afinsq_1_ident_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"identify cardCARD-1K1 p with domRELAT-1K1 p"
proof
(*compatibility*)
  show "cardCARD-1K1 p =HIDDENR1 domRELAT-1K1 p"
  proof-
    have "lenAFINSQ-1K1 p =HIDDENR1 domRELAT-1K1 p"
    proof-
      have "lenAFINSQ-1K1 p =HIDDENR1 cardCARD-1K4 (domRELAT-1K1 p)"
        using card_1_th_62 sorry
      also have "... = domRELAT-1K1 p"
         sorry
      finally show "lenAFINSQ-1K1 p =HIDDENR1 domRELAT-1K1 p"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) AFINSQ_1K2("lenAFINSQ-1K2  _ " [228]228) where
  "lenAFINSQ-1K2 p \<equiv> cardCARD-1K1 p"

mtheorem afinsq_1_add_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"cluster cardCARD-1K1 p as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "cardCARD-1K1 p be ElementSUBSET-1M1-of NATNUMBERSK1"
  proof-
    have "cardCARD-1K4 p =XBOOLE-0R4 cardCARD-1K4 p"
       sorry
    thus "cardCARD-1K1 p be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

abbreviation(input) AFINSQ_1K3("domAFINSQ-1K3  _ " [228]228) where
  "domAFINSQ-1K3 p \<equiv> domRELAT-1K1 p"

mtheorem afinsq_1_add_2:
  mlet "p be XFinSequenceAFINSQ-1M1"
"cluster domRELAT-1K1 p as-term-is SubsetSUBSET-1M2-of NATNUMBERSK1"
proof
(*coherence*)
  show "domRELAT-1K1 p be SubsetSUBSET-1M2-of NATNUMBERSK1"
  proof-
    have "{i where i be NatNAT-1M1 : i <XXREAL-0R3 lenAFINSQ-1K2 p } c=TARSKIR1 NATNUMBERSK1"
    proof-
      have "{i where i be NatNAT-1M1 :  not i <XXREAL-0R3 lenAFINSQ-1K2 p } c=TARSKIR1 NATNUMBERSK1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {i where i be NatNAT-1M1 : i <XXREAL-0R3 lenAFINSQ-1K2 p } implies x inHIDDENR3 NATNUMBERSK1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {i where i be NatNAT-1M1 : i <XXREAL-0R3 lenAFINSQ-1K2 p }"
          then have " ex i be NatNAT-1M1 st i =HIDDENR1 x & i <XXREAL-0R3 lenAFINSQ-1K2 p"
             sorry
          thus "x inHIDDENR3 NATNUMBERSK1"
            using ordinal1_def_12 sorry
        qed "sorry"
        thus "{i where i be NatNAT-1M1 :  not i <XXREAL-0R3 lenAFINSQ-1K2 p } c=TARSKIR1 NATNUMBERSK1"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "domRELAT-1K1 p be SubsetSUBSET-1M2-of NATNUMBERSK1"
      using axioms_th_4 sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_6:
" for f be FunctionFUNCT-1M1 holds ( ex k be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 k) implies ( ex p be XFinSequenceAFINSQ-1M1 st f c=RELAT-1R2 p)"
proof-
  have " for f be FunctionFUNCT-1M1 holds ( ex k be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 k) implies ( ex tVar1 be XFinSequenceAFINSQ-1M1 st f c=RELAT-1R2 tVar1)"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume Given: " ex k be NatNAT-1M1 st domRELAT-1K1 f c=TARSKIR1 k"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "domRELAT-1K1 f c=TARSKIR1 k"
       sorry
    let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A2: "domRELAT-1K1 g =XBOOLE-0R4 k & ( for x be objectHIDDENM1 holds x inHIDDENR3 k implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
      using funct_1_sch_3 sorry
    have 
      [ty]:"g be XFinSequenceAFINSQ-1M1"
      using A2 finset_1_th_10 ordinal1_def_7 sorry
    show " ex tVar1 be XFinSequenceAFINSQ-1M1 st f c=RELAT-1R2 tVar1"
    proof(rule bexI[of _ "g"])
      have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g"
      proof(rule ballI,rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A3: "[TARSKIK4 y,z ] inHIDDENR3 f"
        then have A4: "y inHIDDENR3 domRELAT-1K1 f"
          using xtuple_0_def_12 sorry
        then have A5: "[TARSKIK4 y,g .FUNCT-1K1 y ] inHIDDENR3 g"
          using A1 A2 funct_1_th_1 sorry
        have "z be setHIDDENM2"
          using tarski_th_1 sorry
        then have "f .FUNCT-1K1 y =HIDDENR1 z"
          using A3 A4 funct_1_def_2 sorry
        thus "[TARSKIK4 y,z ] inHIDDENR3 g"
          using A1 A2 A4 A5 sorry
      qed "sorry"
      thus "f c=RELAT-1R2 g"
        using relat_1_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem afinsq_1_sch_1:
  fixes Af0 Pp2 
  assumes
[ty]: "Af0 be NatNAT-1M1" and
   A1: " for k be NatNAT-1M1 holds k inTARSKIR2 Af0 implies ( ex x be objectHIDDENM1 st Pp2(k,x))"
  shows " ex p be XFinSequenceAFINSQ-1M1 st domAFINSQ-1K3 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 Af0 implies Pp2(k,p .FUNCT-1K1 k))"
  proof-
    have " ex tVar2 be XFinSequenceAFINSQ-1M1 st domAFINSQ-1K3 tVar2 =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 Af0 &  not Pp2(k,tVar2 .FUNCT-1K1 k)))"
    proof-
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex y be objectHIDDENM1 st Pp2(x,y))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies  not ( for y be objectHIDDENM1 holds  not Pp2(x,y))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 Af0"
          have "Af0 =XBOOLE-0R4 {i where i be NatNAT-1M1 : i <XXREAL-0R3 Af0 }"
            using axioms_th_4 sorry
          then have " ex i be NatNAT-1M1 st i =HIDDENR1 x & i <XXREAL-0R3 Af0"
            using A3 sorry
          thus " not ( for y be objectHIDDENM1 holds  not Pp2(x,y))"
            using A1 A3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A4: "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp2(x,f .FUNCT-1K1 x))"
        using classes1_sch_1 A2 sorry
      obtain p where 
        [ty]:"p be XFinSequenceAFINSQ-1M1" and pDef:"p = f"
        using A4 finset_1_th_10 ordinal1_def_7 sorry
      show " ex tVar2 be XFinSequenceAFINSQ-1M1 st domAFINSQ-1K3 tVar2 =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 Af0 &  not Pp2(k,tVar2 .FUNCT-1K1 k)))"
      proof(rule bexI[of _ "p"])
        show "domAFINSQ-1K3 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 Af0 &  not Pp2(k,p .FUNCT-1K1 k)))"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem afinsq_1_sch_2:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be NatNAT-1M1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex p be XFinSequenceAFINSQ-1M1 st lenAFINSQ-1K2 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 Af0 implies p .FUNCT-1K1 k =HIDDENR1 Ff1(k))"
  proof-
    have " ex tVar3 be XFinSequenceAFINSQ-1M1 st lenAFINSQ-1K2 tVar3 =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 Af0 &  not tVar3 .FUNCT-1K1 k =HIDDENR1 Ff1(k)))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
        using funct_1_sch_3 sorry
      obtain p where 
        [ty]:"p be XFinSequenceAFINSQ-1M1" and pDef:"p = f"
        using A1 finset_1_th_10 ordinal1_def_7 sorry
      show " ex tVar3 be XFinSequenceAFINSQ-1M1 st lenAFINSQ-1K2 tVar3 =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 Af0 &  not tVar3 .FUNCT-1K1 k =HIDDENR1 Ff1(k)))"
      proof(rule bexI[of _ "p"])
        show "lenAFINSQ-1K2 p =XBOOLE-0R4 Af0 & ( for k be NatNAT-1M1 holds  not (k inTARSKIR2 Af0 &  not p .FUNCT-1K1 k =HIDDENR1 Ff1(k)))"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem afinsq_1_th_7:
" for z be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds z inHIDDENR3 p implies ( ex k be NatNAT-1M1 st k inTARSKIR2 domAFINSQ-1K3 p & z =HIDDENR1 [TARSKIK4 k,p .FUNCT-1K1 k ])"
proof-
  have " for z be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds z inHIDDENR3 p implies ( ex tVar4 be NatNAT-1M1 st tVar4 inTARSKIR2 domAFINSQ-1K3 p & z =HIDDENR1 [TARSKIK4 tVar4,p .FUNCT-1K1 tVar4 ])"
  proof(rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    assume A1: "z inHIDDENR3 p"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A2: "z =HIDDENR1 [TARSKIK4 x,y ]"
      using relat_1_def_1 sorry
    have "x inHIDDENR3 domAFINSQ-1K3 p"
      using A1 A2 funct_1_th_1 sorry
    then obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x"
       sorry
    show " ex tVar4 be NatNAT-1M1 st tVar4 inTARSKIR2 domAFINSQ-1K3 p & z =HIDDENR1 [TARSKIK4 tVar4,p .FUNCT-1K1 tVar4 ]"
    proof(rule bexI[of _ "k"])
      show "k inTARSKIR2 domAFINSQ-1K3 p & z =HIDDENR1 [TARSKIK4 k,p .FUNCT-1K1 k ]"
        using A1 A2 funct_1_th_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_8:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds domAFINSQ-1K3 p =XBOOLE-0R4 domAFINSQ-1K3 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
   sorry

mlemma afinsq_1_lm_1:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p iff k inTARSKIR2 domAFINSQ-1K3 p"
proof-
  have " for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds (k <XXREAL-0R3 lenAFINSQ-1K2 p implies k inTARSKIR2 domAFINSQ-1K3 p) & (k inTARSKIR2 domAFINSQ-1K3 p implies k <XXREAL-0R3 lenAFINSQ-1K2 p)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    show "k <XXREAL-0R3 lenAFINSQ-1K2 p implies k inTARSKIR2 domAFINSQ-1K3 p"
    proof(rule impI)
      assume "k <XXREAL-0R3 lenAFINSQ-1K2 p"
      then have "k inTARSKIR2 SegmCARD-1K5 lenAFINSQ-1K2 p"
        using nat_1_th_44 sorry
      thus "k inTARSKIR2 domAFINSQ-1K3 p"
         sorry
    qed
    assume "k inTARSKIR2 domAFINSQ-1K3 p"
    then have "k inTARSKIR2 SegmCARD-1K5 lenAFINSQ-1K2 p"
       sorry
    thus "k <XXREAL-0R3 lenAFINSQ-1K2 p"
      using nat_1_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_9:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k) implies p =FUNCT-1R1 q"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume A1: "lenAFINSQ-1K2 p =XBOOLE-0R4 lenAFINSQ-1K2 q"
      and A2: " for k be NatNAT-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 p implies p .FUNCT-1K1 x =XBOOLE-0R4 q .FUNCT-1K1 x"
      using A2 afinsq_1_lm_1 sorry
    thus "p =FUNCT-1R1 q"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_cl_2:
  mlet "p be XFinSequenceAFINSQ-1M1", "n be NatNAT-1M1"
"cluster p  |RELAT-1K8 n as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "p  |RELAT-1K8 n be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_th_10:
" for f be FunctionFUNCT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 domRELAT-1K1 f implies f *FUNCT-1K3 p be XFinSequenceAFINSQ-1M1"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 domRELAT-1K1 f implies f *FUNCT-1K3 p be XFinSequenceAFINSQ-1M1"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    assume "rngFUNCT-1K2 p c=TARSKIR1 domRELAT-1K1 f"
    then have "domRELAT-1K1 (f *FUNCT-1K3 p) =XBOOLE-0R4 lenAFINSQ-1K2 p"
      using relat_1_th_27 sorry
    thus "f *FUNCT-1K3 p be XFinSequenceAFINSQ-1M1"
      using ordinal1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_11:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies domAFINSQ-1K3 (p  |RELAT-1K8 k) =XBOOLE-0R4 k"
proof-
  have " for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies domAFINSQ-1K3 (p  |RELAT-1K8 k) =XBOOLE-0R4 k"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    assume "k <XXREAL-0R3 lenAFINSQ-1K2 p"
    then have "SegmCARD-1K5 k c=ORDINAL1R1 SegmCARD-1K5 lenAFINSQ-1K2 p"
      using nat_1_th_39 sorry
    thus "domAFINSQ-1K3 (p  |RELAT-1K8 k) =XBOOLE-0R4 k"
      using relat_1_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_cl_3:
  mlet "D be setHIDDENM2"
"cluster finiteFINSET-1V1 for SequenceORDINAL1M5-of D"
proof
(*existence*)
  show " ex it be SequenceORDINAL1M5-of D st it be finiteFINSET-1V1"
  proof-
    have " not ( for VarFor1 be SequenceORDINAL1M5-of D holds  not VarFor1 be finiteFINSET-1V1)"
    proof-
      have "{}XBOOLE-0K1 be SequenceORDINAL1M5-of D"
        using ordinal1_th_30 sorry
      thus " not ( for VarFor1 be SequenceORDINAL1M5-of D holds  not VarFor1 be finiteFINSET-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax AFINSQ_1M2 :: " Set \<Rightarrow> Ty" ("XFinSequenceAFINSQ-1M2-of  _ " [70]70)
translations "XFinSequenceAFINSQ-1M2-of D" \<rightharpoonup> "finiteFINSET-1V1\<bar>SequenceORDINAL1M5-of D"

mtheorem afinsq_1_th_12:
" for D be setHIDDENM2 holds  for f be XFinSequenceAFINSQ-1M2-of D holds f be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be setHIDDENM2"
  fix f assume [ty]: "f be XFinSequenceAFINSQ-1M2-of D"
  have "domAFINSQ-1K3 f c=ORDINAL1R1 NATNUMBERSK1 & rngFUNCT-1K2 f c=TARSKIR1 D"
    using relat_1_def_19 sorry
  thus "f be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
    using relset_1_th_4 sorry
qed "sorry"

mtheorem afinsq_1_cl_4:
"cluster emptyXBOOLE-0V1 also-is Sequence-likeORDINAL1V5 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

reserve D for "setHIDDENM2"
mtheorem afinsq_1_cl_5:
  mlet "k be NatNAT-1M1", "a be objectHIDDENM1"
"cluster SegmCARD-1K5 k -->FUNCOP-1K7 a as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "SegmCARD-1K5 k -->FUNCOP-1K7 a be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

(*\$CT*)
mtheorem afinsq_1_th_14:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex p be XFinSequenceAFINSQ-1M2-of D st lenAFINSQ-1K2 p =XBOOLE-0R4 k"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  ex tVar5 be XFinSequenceAFINSQ-1M2-of D st lenAFINSQ-1K2 tVar5 =XBOOLE-0R4 k"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    let ?y = "the ElementSUBSET-1M1-of D"
    let ?p = "k -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?y"
    obtain p where 
      [ty]:"p be XFinSequenceAFINSQ-1M1" and pDef:"p = k -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?y"
       sorry
    have 
      [ty]:"p be XFinSequenceAFINSQ-1M2-of D"
       sorry
    show " ex tVar5 be XFinSequenceAFINSQ-1M2-of D st lenAFINSQ-1K2 tVar5 =XBOOLE-0R4 k"
    proof(rule bexI[of _ "p"])
      show "lenAFINSQ-1K2 p =XBOOLE-0R4 k"
        using funcop_1_th_13 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_15:
" for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 0NUMBERSK6 iff p =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem afinsq_1_th_16:
" for D be setHIDDENM2 holds {}XBOOLE-0K1 be XFinSequenceAFINSQ-1M2-of D"
proof(rule ballI)
  fix D assume [ty]: "D be setHIDDENM2"
  have "rngFUNCT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 D"
     sorry
  thus "{}XBOOLE-0K1 be XFinSequenceAFINSQ-1M2-of D"
    using relat_1_def_19 sorry
qed "sorry"

mtheorem afinsq_1_cl_6:
  mlet "D be setHIDDENM2"
"cluster emptyXBOOLE-0V1 for XFinSequenceAFINSQ-1M2-of D"
proof
(*existence*)
  show " ex it be XFinSequenceAFINSQ-1M2-of D st it be emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be XFinSequenceAFINSQ-1M2-of D holds  not VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{}XBOOLE-0K1 be XFinSequenceAFINSQ-1M2-of D"
        using afinsq_1_th_16 sorry
      thus " not ( for VarFor1 be XFinSequenceAFINSQ-1M2-of D holds  not VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_cl_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for XFinSequenceAFINSQ-1M2-of D"
proof
(*existence*)
  show " ex it be XFinSequenceAFINSQ-1M2-of D st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be XFinSequenceAFINSQ-1M2-of D holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      let ?k = "\<one>\<^sub>M"
      obtain p where
        [ty]:"p be XFinSequenceAFINSQ-1M2-of D" and 
        A1: "lenAFINSQ-1K2 p =XBOOLE-0R4 ?k"
        using afinsq_1_th_14 sorry
      have "p <>HIDDENR2 {}XBOOLE-0K1"
        using A1 sorry
      thus " not ( for VarFor1 be XFinSequenceAFINSQ-1M2-of D holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef afinsq_1_def_1 ("<%AFINSQ-1K4  _ %>" [0]164 ) where
  mlet "x be objectHIDDENM1"
"func <%AFINSQ-1K4 x%> \<rightarrow> setHIDDENM2 equals
  (0NUMBERSK6).-->FUNCOP-1K17 x"
proof-
  (*coherence*)
    show "(0NUMBERSK6).-->FUNCOP-1K17 x be setHIDDENM2"
       sorry
qed "sorry"

mtheorem afinsq_1_cl_8:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K4 x%> as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<%AFINSQ-1K4 x%> be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mdef afinsq_1_def_2 ("<%>AFINSQ-1K5  _ " [354]354 ) where
  mlet "D be setHIDDENM2"
"func <%>AFINSQ-1K5 D \<rightarrow> XFinSequenceAFINSQ-1M2-of D equals
  {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "{}XBOOLE-0K1 be XFinSequenceAFINSQ-1M2-of D"
      using afinsq_1_th_16 sorry
qed "sorry"

mtheorem afinsq_1_cl_9:
  mlet "D be setHIDDENM2"
"cluster <%>AFINSQ-1K5 D as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<%>AFINSQ-1K5 D be emptyXBOOLE-0V1"
     sorry
qed "sorry"

abbreviation(input) AFINSQ_1K6(" _ ^AFINSQ-1K6  _ " [164,164]164) where
  "p ^AFINSQ-1K6 q \<equiv> p ^ORDINAL4K1 q"

mtheorem afinsq_1_def_3:
  mlet "p be XFinSequenceAFINSQ-1M1", "q be XFinSequenceAFINSQ-1M1"
"redefine func p ^AFINSQ-1K6 q \<rightarrow> setHIDDENM2 means
  \<lambda>it. (domRELAT-1K1 it =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies it .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 p ^AFINSQ-1K6 q iff (domRELAT-1K1 it =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies it .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k)) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies it .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)"
  proof-
    have " for pq be SequenceORDINAL1M4 holds (pq =FUNCT-1R1 p ^ORDINAL4K1 q implies domRELAT-1K1 pq =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q & (( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies pq .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies pq .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k))) & (domRELAT-1K1 pq =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q & (( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies pq .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies pq .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k)) implies pq =HIDDENR1 p ^ORDINAL4K1 q)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
      fix pq assume [ty]: "pq be SequenceORDINAL1M4"
      have A1: "lenAFINSQ-1K2 p +^ORDINAL2K10 lenAFINSQ-1K2 q =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
        using card_2_th_36 sorry
      show "pq =FUNCT-1R1 p ^ORDINAL4K1 q implies domRELAT-1K1 pq =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q & (( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies pq .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k) & ( for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies pq .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k))"
      proof(rule impI,rule conjMI,rule conjMI,rule ballI,rule impI)
        assume A2: "pq =FUNCT-1R1 p ^ORDINAL4K1 q"
        thus "domRELAT-1K1 pq =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
          using A1 ordinal4_def_1 sorry
        show " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies pq .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
          using A2 ordinal4_def_1 sorry
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domAFINSQ-1K3 q"
        then have "pq .FUNCT-1K1 (lenAFINSQ-1K2 p +^ORDINAL2K10 k) =XBOOLE-0R4 q .FUNCT-1K1 k & k inTARSKIR2 NATNUMBERSK1"
          using A2 ordinal4_def_1 sorry
        thus "pq .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k"
          using card_2_th_36 sorry
      qed "sorry"
      assume A3: "domRELAT-1K1 pq =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
        and A4: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies pq .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
        and A5: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies pq .FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 q .FUNCT-1K1 k"
      have A6: " for a be OrdinalORDINAL1M3 holds a inTARSKIR2 domAFINSQ-1K3 q implies pq .FUNCT-1K1 (domAFINSQ-1K3 p +^ORDINAL2K10 a) =HIDDENR1 q .FUNCT-1K1 a"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be OrdinalORDINAL1M3"
        assume A7: "a inTARSKIR2 domAFINSQ-1K3 q"
        then obtain k where 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = a"
           sorry
        have "pq .FUNCT-1K1 (domAFINSQ-1K3 p +^ORDINAL2K10 a) =HIDDENR1 pq .FUNCT-1K1 (lenAFINSQ-1K2 p +NAT-1K1 k)"
          using card_2_th_36 sorry
        also have "... = q .FUNCT-1K1 a"
          using A5 A7 sorry
        finally show "pq .FUNCT-1K1 (domAFINSQ-1K3 p +^ORDINAL2K10 a) =HIDDENR1 q .FUNCT-1K1 a"
           sorry
      qed "sorry"
      have " for a be OrdinalORDINAL1M3 holds a inTARSKIR2 domAFINSQ-1K3 p implies pq .FUNCT-1K1 a =XBOOLE-0R4 p .FUNCT-1K1 a"
        using A4 sorry
      thus "pq =HIDDENR1 p ^ORDINAL4K1 q"
        using A1 A3 A6 ordinal4_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_cl_10:
  mlet "p be XFinSequenceAFINSQ-1M1", "q be XFinSequenceAFINSQ-1M1"
"cluster p ^AFINSQ-1K6 q as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "p ^AFINSQ-1K6 q be finiteFINSET-1V1"
  proof-
    have "domRELAT-1K1 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 domAFINSQ-1K3 p +^ORDINAL2K10 domAFINSQ-1K3 q"
      using ordinal4_def_1 sorry
    thus "p ^AFINSQ-1K6 q be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_17:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
  using afinsq_1_def_3 sorry

mtheorem afinsq_1_th_18:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 k & k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q implies (p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
proof-
  have " for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 k & k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q implies (p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume A1: "lenAFINSQ-1K2 p <=XXREAL-0R1 k"
      and A2: "k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "lenAFINSQ-1K2 p +XCMPLX-0K2 m =XBOOLE-0R4 k"
      using A1 nat_1_th_10 sorry
    have "k -XCMPLX-0K6 lenAFINSQ-1K2 p <XXREAL-0R3 (lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)-XCMPLX-0K6 lenAFINSQ-1K2 p"
      using A2 xreal_1_th_14 sorry
    then have "m inTARSKIR2 domAFINSQ-1K3 q"
      using A3 afinsq_1_lm_1 sorry
    thus "(p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
      using A3 afinsq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_19:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 k & k <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
proof-
  have " for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 k & k <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume A1: "lenAFINSQ-1K2 p <=XXREAL-0R1 k"
      and A2: "k <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
    have "k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
      using A2 afinsq_1_def_3 sorry
    thus "(p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p)"
      using A1 afinsq_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_20:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) implies k inTARSKIR2 domAFINSQ-1K3 p or ( ex n be NatNAT-1M1 st n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n)"
proof-
  have " for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) implies  not ( not k inTARSKIR2 domAFINSQ-1K3 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume "k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
    then have "k inTARSKIR2 SegmCARD-1K5 (lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)"
      using afinsq_1_def_3 sorry
    then have A1: "k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
      using nat_1_th_44 sorry
    have "lenAFINSQ-1K2 p <=XXREAL-0R1 k implies  not ( not k inTARSKIR2 domAFINSQ-1K3 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n)))"
    proof(rule impI)
      assume "lenAFINSQ-1K2 p <=XXREAL-0R1 k"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A2: "k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n"
        using nat_1_th_10 sorry
      have "(n +NAT-1K1 lenAFINSQ-1K2 p)-XCMPLX-0K6 lenAFINSQ-1K2 p <XXREAL-0R3 (lenAFINSQ-1K2 q +NAT-1K1 lenAFINSQ-1K2 p)-XCMPLX-0K6 lenAFINSQ-1K2 p"
        using A1 A2 xreal_1_th_14 sorry
      then have "n inTARSKIR2 SegmCARD-1K5 lenAFINSQ-1K2 q"
        using afinsq_1_lm_1 sorry
      thus " not ( not k inTARSKIR2 domAFINSQ-1K3 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n)))"
        using A2 sorry
    qed
    thus " not ( not k inTARSKIR2 domAFINSQ-1K3 p & ( for n be NatNAT-1M1 holds  not (n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n)))"
      using afinsq_1_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_21:
" for p be SequenceORDINAL1M4 holds  for q be SequenceORDINAL1M4 holds domRELAT-1K1 p c=ORDINAL1R1 domRELAT-1K1 (p ^ORDINAL4K1 q)"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be SequenceORDINAL1M4"
  fix q assume [ty]: "q be SequenceORDINAL1M4"
  have "domRELAT-1K1 (p ^ORDINAL4K1 q) =XBOOLE-0R4 domRELAT-1K1 p +^ORDINAL2K10 domRELAT-1K1 q"
    using ordinal4_def_1 sorry
  thus "domRELAT-1K1 p c=ORDINAL1R1 domRELAT-1K1 (p ^ORDINAL4K1 q)"
    using ordinal3_th_24 sorry
qed "sorry"

mtheorem afinsq_1_th_22:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds x inHIDDENR3 domAFINSQ-1K3 q implies ( ex k be NatNAT-1M1 st k =HIDDENR1 x & lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q))"
proof-
  have " for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds x inHIDDENR3 domAFINSQ-1K3 q implies ( ex tVar6 be NatNAT-1M1 st tVar6 =HIDDENR1 x & lenAFINSQ-1K2 p +XCMPLX-0K2 tVar6 inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume A1: "x inHIDDENR3 domAFINSQ-1K3 q"
    then obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x"
       sorry
    show " ex tVar6 be NatNAT-1M1 st tVar6 =HIDDENR1 x & lenAFINSQ-1K2 p +XCMPLX-0K2 tVar6 inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
    proof(rule bexI[of _ "k"])
      have "k <XXREAL-0R3 lenAFINSQ-1K2 q"
        using A1 afinsq_1_lm_1 sorry
      then have "lenAFINSQ-1K2 p +NAT-1K1 k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
        using xreal_1_th_8 sorry
      then have "lenAFINSQ-1K2 p +NAT-1K1 k inTARSKIR2 SegmCARD-1K5 (lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)"
        using nat_1_th_44 sorry
      thus "k =HIDDENR1 x & lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
        using afinsq_1_def_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_23:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
proof-
  have " for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds k inTARSKIR2 domAFINSQ-1K3 q implies lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume "k inTARSKIR2 domAFINSQ-1K3 q"
    then have " ex n be NatNAT-1M1 st n =XBOOLE-0R4 k & lenAFINSQ-1K2 p +XCMPLX-0K2 n inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
      using afinsq_1_th_22 sorry
    thus "lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_24:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    have A1: "domAFINSQ-1K3 p c=ORDINAL1R1 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
      using afinsq_1_th_21 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x inHIDDENR3 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 p"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A2: "y inHIDDENR3 domAFINSQ-1K3 p"and A3: "x =HIDDENR1 p .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
        using A2 sorry
      have "(p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
        using A2 afinsq_1_def_3 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
        using A2 A3 A1 funct_1_th_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_25:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 q implies x inHIDDENR3 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 q"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 domAFINSQ-1K3 q"and A2: "x =HIDDENR1 q .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
        using A1 sorry
      have "lenAFINSQ-1K2 p +NAT-1K1 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) & (p ^AFINSQ-1K6 q).FUNCT-1K1 (lenAFINSQ-1K2 p +NAT-1K1 k) =XBOOLE-0R4 q .FUNCT-1K1 k"
        using A1 afinsq_1_def_3 afinsq_1_th_23 sorry
      thus "x inHIDDENR3 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
        using A2 funct_1_th_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_26:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds rngFUNCT-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (p ^AFINSQ-1K6 q) implies x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"and A2: "x =HIDDENR1 (p ^AFINSQ-1K6 q).FUNCT-1K1 y"
        using funct_1_def_3 sorry
      obtain k where 
        [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = y"
        using A1 sorry
      have "y inHIDDENR3 SegmCARD-1K5 (lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)"
        using A1 afinsq_1_def_3 sorry
      then have A3: "k <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
        using nat_1_th_44 sorry
      have A4: "lenAFINSQ-1K2 p <=XXREAL-0R1 k implies x inHIDDENR3 rngFUNCT-1K2 q"
      proof(rule impI)
        assume A5: "lenAFINSQ-1K2 p <=XXREAL-0R1 k"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A6: "lenAFINSQ-1K2 p +XCMPLX-0K2 m =XBOOLE-0R4 k"
          using nat_1_th_10 sorry
        have "(m +NAT-1K1 lenAFINSQ-1K2 p)-XCMPLX-0K6 lenAFINSQ-1K2 p <XXREAL-0R3 (lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)-XCMPLX-0K6 lenAFINSQ-1K2 p"
          using A3 A6 xreal_1_th_14 sorry
        then have A7: "m inTARSKIR2 SegmCARD-1K5 lenAFINSQ-1K2 q"
          using afinsq_1_lm_1 sorry
        have "q .FUNCT-1K1 (k -XCMPLX-0K6 lenAFINSQ-1K2 p) =HIDDENR1 x"
          using A2 A3 A5 afinsq_1_th_18 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 q"
          using A6 A7 funct_1_th_3 sorry
      qed
      have " not lenAFINSQ-1K2 p <=XXREAL-0R1 k implies x inHIDDENR3 rngFUNCT-1K2 p"
      proof(rule impI)
        assume " not lenAFINSQ-1K2 p <=XXREAL-0R1 k"
        then have A8: "k inTARSKIR2 domAFINSQ-1K3 p"
          using afinsq_1_lm_1 sorry
        then have "p .FUNCT-1K1 k =HIDDENR1 x"
          using A2 afinsq_1_def_3 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 p"
          using A8 funct_1_th_3 sorry
      qed
      thus "x inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
        using A4 xboole_0_def_3 sorry
    qed "sorry"
    then have A9: "rngFUNCT-1K2 (p ^AFINSQ-1K6 q) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
       sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q) & rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
      using afinsq_1_th_24 afinsq_1_th_25 sorry
    then have "rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 (p ^AFINSQ-1K6 q)"
      using xboole_1_th_8 sorry
    thus "rngFUNCT-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_27:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 q)^AFINSQ-1K6 r =FUNCT-1R1 p ^AFINSQ-1K6 (q ^AFINSQ-1K6 r)"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 q)^AFINSQ-1K6 r =FUNCT-1R1 p ^AFINSQ-1K6 (q ^AFINSQ-1K6 r)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    fix r assume [ty]: "r be XFinSequenceAFINSQ-1M1"
    have A1: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: "k inTARSKIR2 domAFINSQ-1K3 p"
        have "domAFINSQ-1K3 p c=ORDINAL1R1 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
          using afinsq_1_th_21 sorry
        then have "((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 k =HIDDENR1 (p ^AFINSQ-1K6 q).FUNCT-1K1 k"
          using A2 afinsq_1_def_3 sorry
        also have "... = p .FUNCT-1K1 k"
          using A2 afinsq_1_def_3 sorry
        finally show "((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (q ^AFINSQ-1K6 r) implies ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "k inTARSKIR2 domAFINSQ-1K3 (q ^AFINSQ-1K6 r)"
      have A5: " not k inTARSKIR2 domAFINSQ-1K3 q implies ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =HIDDENR1 (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
      proof(rule impI)
        assume " not k inTARSKIR2 domAFINSQ-1K3 q"
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A6: "n inTARSKIR2 domAFINSQ-1K3 r"and A7: "k =XBOOLE-0R4 lenAFINSQ-1K2 q +XCMPLX-0K2 n"
          using A4 afinsq_1_th_20 sorry
        have "((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =HIDDENR1 ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 ((lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)+XCMPLX-0K2 n)"
          using A7 sorry
        also have "... = ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) +XCMPLX-0K2 n)"
          using afinsq_1_def_3 sorry
        also have "... = r .FUNCT-1K1 n"
          using A6 afinsq_1_def_3 sorry
        also have "... = (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
          using A6 A7 afinsq_1_def_3 sorry
        finally show "((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =HIDDENR1 (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
           sorry
      qed
      have "k inTARSKIR2 domAFINSQ-1K3 q implies ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =HIDDENR1 (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
      proof(rule impI)
        assume A8: "k inTARSKIR2 domAFINSQ-1K3 q"
        then have "lenAFINSQ-1K2 p +XCMPLX-0K2 k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
          using afinsq_1_th_23 sorry
        then have "((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =HIDDENR1 (p ^AFINSQ-1K6 q).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k)"
          using afinsq_1_def_3 sorry
        also have "... = q .FUNCT-1K1 k"
          using A8 afinsq_1_def_3 sorry
        also have "... = (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
          using A8 afinsq_1_def_3 sorry
        finally show "((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =HIDDENR1 (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
           sorry
      qed
      thus "((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r).FUNCT-1K1 (lenAFINSQ-1K2 p +XCMPLX-0K2 k) =XBOOLE-0R4 (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
        using A5 sorry
    qed "sorry"
    have "domAFINSQ-1K3 ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r) =HIDDENR1 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) +NAT-1K1 lenAFINSQ-1K2 r"
      using afinsq_1_def_3 sorry
    also have "... = (lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)+NAT-1K1 lenAFINSQ-1K2 r"
      using afinsq_1_def_3 sorry
    also have "... = lenAFINSQ-1K2 p +NAT-1K1 (lenAFINSQ-1K2 q +NAT-1K1 lenAFINSQ-1K2 r)"
       sorry
    also have "... = lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 (q ^AFINSQ-1K6 r)"
      using afinsq_1_def_3 sorry
    finally have "domAFINSQ-1K3 ((p ^AFINSQ-1K6 q)^AFINSQ-1K6 r) =HIDDENR1 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 (q ^AFINSQ-1K6 r)"
       sorry
    thus "(p ^AFINSQ-1K6 q)^AFINSQ-1K6 r =FUNCT-1R1 p ^AFINSQ-1K6 (q ^AFINSQ-1K6 r)"
      using A1 A3 afinsq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_28:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r or r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q implies p =FUNCT-1R1 q"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r or r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q implies p =FUNCT-1R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    fix r assume [ty]: "r be XFinSequenceAFINSQ-1M1"
    have A1: "p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r implies  not ( not ( not p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r &  not r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q) &  not p =FUNCT-1R1 q)"
    proof(rule impI)
      assume A2: "p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r"
      then have "lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 r =XBOOLE-0R4 lenAFINSQ-1K2 (q ^AFINSQ-1K6 r)"
        using afinsq_1_def_3 sorry
      then have A3: "lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 r =XBOOLE-0R4 lenAFINSQ-1K2 q +NAT-1K1 lenAFINSQ-1K2 r"
        using afinsq_1_def_3 sorry
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
      proof-
        have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A4: "k inTARSKIR2 domAFINSQ-1K3 p"
          then have "p .FUNCT-1K1 k =HIDDENR1 (q ^AFINSQ-1K6 r).FUNCT-1K1 k"
            using A2 afinsq_1_def_3 sorry
          also have "... = q .FUNCT-1K1 k"
            using A3 A4 afinsq_1_def_3 sorry
          finally show "p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " not ( not ( not p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r &  not r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q) &  not p =FUNCT-1R1 q)"
        using A3 sorry
    qed
    have A5: "r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q implies  not ( not ( not p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r &  not r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q) &  not p =FUNCT-1R1 q)"
    proof(rule impI)
      assume A6: "r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q"
      then have A7: "lenAFINSQ-1K2 r +NAT-1K1 lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 (r ^AFINSQ-1K6 q)"
        using afinsq_1_def_3 sorry
      also have "... = lenAFINSQ-1K2 r +NAT-1K1 lenAFINSQ-1K2 q"
        using afinsq_1_def_3 sorry
      finally have "lenAFINSQ-1K2 r +NAT-1K1 lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 r +NAT-1K1 lenAFINSQ-1K2 q"
         sorry
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =XBOOLE-0R4 q .FUNCT-1K1 k"
      proof-
        have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A8: "k inTARSKIR2 domAFINSQ-1K3 p"
          then have "p .FUNCT-1K1 k =HIDDENR1 (r ^AFINSQ-1K6 q).FUNCT-1K1 (lenAFINSQ-1K2 r +XCMPLX-0K2 k)"
            using A6 afinsq_1_def_3 sorry
          also have "... = q .FUNCT-1K1 k"
            using A7 A8 afinsq_1_def_3 sorry
          finally show "p .FUNCT-1K1 k =HIDDENR1 q .FUNCT-1K1 k"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " not ( not ( not p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r &  not r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q) &  not p =FUNCT-1R1 q)"
        using A7 sorry
    qed
    assume "p ^AFINSQ-1K6 r =FUNCT-1R1 q ^AFINSQ-1K6 r or r ^AFINSQ-1K6 p =FUNCT-1R1 r ^AFINSQ-1K6 q"
    thus "p =FUNCT-1R1 q"
      using A1 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_reduce_1:
  mlet "p be XFinSequenceAFINSQ-1M1"
"reduce p ^AFINSQ-1K6 {}XBOOLE-0K1 to p"
proof
(*reducibility*)
  show "p ^AFINSQ-1K6 {}XBOOLE-0K1 =HIDDENR1 p"
  proof-
    have "p ^AFINSQ-1K6 {}XBOOLE-0K1 =FUNCT-1R1 p"
    proof-
      have A1: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =XBOOLE-0R4 (p ^AFINSQ-1K6 {}XBOOLE-0K1).FUNCT-1K1 k"
        using afinsq_1_def_3 sorry
      have "domAFINSQ-1K3 (p ^AFINSQ-1K6 {}XBOOLE-0K1) =HIDDENR1 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 ({}XBOOLE-0K1)"
        using afinsq_1_def_3 sorry
      also have "... = domAFINSQ-1K3 p"
         sorry
      finally have "domAFINSQ-1K3 (p ^AFINSQ-1K6 {}XBOOLE-0K1) =HIDDENR1 domAFINSQ-1K3 p"
         sorry
      thus "p ^AFINSQ-1K6 {}XBOOLE-0K1 =FUNCT-1R1 p"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_reduce_2:
  mlet "p be XFinSequenceAFINSQ-1M1"
"reduce {}XBOOLE-0K1 ^AFINSQ-1K6 p to p"
proof
(*reducibility*)
  show "{}XBOOLE-0K1 ^AFINSQ-1K6 p =HIDDENR1 p"
  proof-
    have A2: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =XBOOLE-0R4 ({}XBOOLE-0K1 ^AFINSQ-1K6 p).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies ({}XBOOLE-0K1 ^AFINSQ-1K6 p).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "k inTARSKIR2 domAFINSQ-1K3 p"
        have "({}XBOOLE-0K1 ^AFINSQ-1K6 p).FUNCT-1K1 k =HIDDENR1 ({}XBOOLE-0K1 ^AFINSQ-1K6 p).FUNCT-1K1 (lenAFINSQ-1K2 ({}XBOOLE-0K1) +XCMPLX-0K2 k)"
           sorry
        also have "... = p .FUNCT-1K1 k"
          using A3 afinsq_1_def_3 sorry
        finally show "({}XBOOLE-0K1 ^AFINSQ-1K6 p).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domAFINSQ-1K3 ({}XBOOLE-0K1 ^AFINSQ-1K6 p) =HIDDENR1 lenAFINSQ-1K2 ({}XBOOLE-0K1) +NAT-1K1 lenAFINSQ-1K2 p"
      using afinsq_1_def_3 sorry
    also have "... = domAFINSQ-1K3 p"
       sorry
    finally have "domAFINSQ-1K3 ({}XBOOLE-0K1 ^AFINSQ-1K6 p) =HIDDENR1 domAFINSQ-1K3 p"
       sorry
    thus "{}XBOOLE-0K1 ^AFINSQ-1K6 p =HIDDENR1 p"
      using A2 sorry
  qed
qed "sorry"

(*\$CT*)
mtheorem afinsq_1_th_30:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 {}XBOOLE-0K1 implies p =FUNCT-1R1 {}XBOOLE-0K1 & q =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 {}XBOOLE-0K1 implies p =FUNCT-1R1 {}XBOOLE-0K1 & q =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume "p ^AFINSQ-1K6 q =FUNCT-1R1 {}XBOOLE-0K1"
    then have "0NUMBERSK6 =HIDDENR1 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
       sorry
    also have "... = lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
      using afinsq_1_def_3 sorry
    finally have "0NUMBERSK6 =HIDDENR1 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
       sorry
    thus "p =FUNCT-1R1 {}XBOOLE-0K1 & q =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_cl_11:
  mlet "D be setHIDDENM2", "p be XFinSequenceAFINSQ-1M2-of D", "q be XFinSequenceAFINSQ-1M2-of D"
"cluster p ^AFINSQ-1K6 q as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "p ^AFINSQ-1K6 q be D -valuedRELAT-1V5"
  proof-
    have A1: "rngFUNCT-1K2 q c=TARSKIR1 D"
      using relat_1_def_19 sorry
    have "rngFUNCT-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q & rngFUNCT-1K2 p c=TARSKIR1 D"
      using afinsq_1_th_26 relat_1_def_19 sorry
    then have "rngFUNCT-1K2 (p ^AFINSQ-1K6 q) c=TARSKIR1 D"
      using A1 xboole_1_th_8 sorry
    thus "p ^AFINSQ-1K6 q be D -valuedRELAT-1V5"
       sorry
  qed
qed "sorry"

mlemma afinsq_1_lm_2:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for x1 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] } implies x =HIDDENR1 x1 & y =HIDDENR1 y1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for x1 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] } implies x =HIDDENR1 x1 & y =HIDDENR1 y1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix y1 assume [ty]: "y1 be setHIDDENM2"
    assume "[TARSKIK4 x,y ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x1,y1 ] }"
    then have "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ]"
      using tarski_def_1 sorry
    thus "x =HIDDENR1 x1 & y =HIDDENR1 y1"
      using xtuple_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) AFINSQ_1K7("<%AFINSQ-1K7  _ %>" [0]164) where
  "<%AFINSQ-1K7 x%> \<equiv> <%AFINSQ-1K4 x%>"

mtheorem afinsq_1_def_4:
  mlet "x be objectHIDDENM1"
"redefine func <%AFINSQ-1K7 x%> \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 \<one>\<^sub>M & it .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
proof
(*compatibility*)
  show " for it be FunctionFUNCT-1M1 holds it =HIDDENR1 <%AFINSQ-1K7 x%> iff domRELAT-1K1 it =XBOOLE-0R4 \<one>\<^sub>M & it .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
  proof-
    have " for f be FunctionFUNCT-1M1 holds (f =XBOOLE-0R4 <%AFINSQ-1K4 x%> implies domRELAT-1K1 f =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & (domRELAT-1K1 f =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x implies f =HIDDENR1 <%AFINSQ-1K4 x%>)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impI)
      fix f assume [ty]: "f be FunctionFUNCT-1M1"
      show "f =XBOOLE-0R4 <%AFINSQ-1K4 x%> implies domRELAT-1K1 f =XBOOLE-0R4 \<one>\<^sub>M & f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
        using card_1_th_49 funcop_1_th_13 funcop_1_th_72 sorry
      assume A1: "domRELAT-1K1 f =XBOOLE-0R4 \<one>\<^sub>M"
        and A2: "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
      obtain g where 
        [ty]:"g be FunctionFUNCT-1M1" and gDef:"g = {TARSKIK1 [TARSKIK4 0NUMBERSK6,f .FUNCT-1K1 (0NUMBERSK6) ] }"
         sorry
      have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 y,z ] inHIDDENR3 f iff [TARSKIK4 y,z ] inHIDDENR3 g"
      proof-
        have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ([TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g) & ([TARSKIK4 y,z ] inHIDDENR3 g implies [TARSKIK4 y,z ] inHIDDENR3 f)"
        proof(rule ballI,rule ballI,rule conjMI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          show "[TARSKIK4 y,z ] inHIDDENR3 f implies [TARSKIK4 y,z ] inHIDDENR3 g"
          proof(rule impI)
            assume A3: "[TARSKIK4 y,z ] inHIDDENR3 f"
            then have "y inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
              using A1 card_1_th_49 xtuple_0_def_12 sorry
            then have A4: "y =HIDDENR1 0NUMBERSK6"
              using tarski_def_1 sorry
            have A5: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 (0NUMBERSK6) }"
              using A1 card_1_th_49 funct_1_th_4 sorry
            have "z inHIDDENR3 rngFUNCT-1K2 f"
              using A3 xtuple_0_def_13 sorry
            then have "z =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
              using A5 tarski_def_1 sorry
            thus "[TARSKIK4 y,z ] inHIDDENR3 g"
              using A4 tarski_def_1 sorry
          qed
          assume "[TARSKIK4 y,z ] inHIDDENR3 g"
          then have A6: "y =HIDDENR1 0NUMBERSK6 & z =HIDDENR1 f .FUNCT-1K1 (0NUMBERSK6)"
            using afinsq_1_lm_2 sorry
          have "0NUMBERSK6 inTARSKIR2 domRELAT-1K1 f"
            using A1 card_1_th_49 tarski_def_1 sorry
          thus "[TARSKIK4 y,z ] inHIDDENR3 f"
            using A6 funct_1_def_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "f =FUNCT-1R1 {TARSKIK1 [TARSKIK4 0NUMBERSK6,f .FUNCT-1K1 (0NUMBERSK6) ] }"
         sorry
      thus "f =HIDDENR1 <%AFINSQ-1K4 x%>"
        using A2 funct_4_th_82 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_add_3:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K4 x%> as-term-is FunctionFUNCT-1M1"
proof
(*coherence*)
  show "<%AFINSQ-1K4 x%> be FunctionFUNCT-1M1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_12:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K7 x%> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K7 x%> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_13:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K7 x%> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K7 x%> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
    using afinsq_1_def_4 sorry
qed "sorry"

mtheorem afinsq_1_th_31:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for D be setHIDDENM2 holds p ^AFINSQ-1K6 q be XFinSequenceAFINSQ-1M2-of D implies p be XFinSequenceAFINSQ-1M2-of D & q be XFinSequenceAFINSQ-1M2-of D"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for D be setHIDDENM2 holds p ^AFINSQ-1K6 q be XFinSequenceAFINSQ-1M2-of D implies p be XFinSequenceAFINSQ-1M2-of D & q be XFinSequenceAFINSQ-1M2-of D"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    fix D assume [ty]: "D be setHIDDENM2"
    assume "p ^AFINSQ-1K6 q be XFinSequenceAFINSQ-1M2-of D"
    then have "rngFUNCT-1K2 (p ^AFINSQ-1K6 q) c=TARSKIR1 D"
      using relat_1_def_19 sorry
    then have A1: "rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q c=TARSKIR1 D"
      using afinsq_1_th_26 sorry
    have "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using xboole_1_th_7 sorry
    then have "rngFUNCT-1K2 p c=TARSKIR1 D"
      using A1 sorry
    thus "p be XFinSequenceAFINSQ-1M2-of D"
      using relat_1_def_19 sorry
    have "rngFUNCT-1K2 q c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using xboole_1_th_7 sorry
    then have "rngFUNCT-1K2 q c=TARSKIR1 D"
      using A1 sorry
    thus "q be XFinSequenceAFINSQ-1M2-of D"
      using relat_1_def_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef afinsq_1_def_5 ("<%AFINSQ-1K8 _ , _ %>" [0,0]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"func <%AFINSQ-1K8 x,y %> \<rightarrow> setHIDDENM2 equals
  (<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>)"
proof-
  (*coherence*)
    show "(<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>) be setHIDDENM2"
       sorry
qed "sorry"

mdef afinsq_1_def_6 ("<%AFINSQ-1K9 _ , _ , _ %>" [0,0,0]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"func <%AFINSQ-1K9 x,y,z %> \<rightarrow> setHIDDENM2 equals
  ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>))^AFINSQ-1K6 (<%AFINSQ-1K7 z%>)"
proof-
  (*coherence*)
    show "((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>))^AFINSQ-1K6 (<%AFINSQ-1K7 z%>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem afinsq_1_cl_14:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <%AFINSQ-1K8 x,y %> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K8 x,y %> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_15:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <%AFINSQ-1K9 x,y,z %> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K9 x,y,z %> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_16:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <%AFINSQ-1K8 x,y %> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K8 x,y %> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_17:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <%AFINSQ-1K9 x,y,z %> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K9 x,y,z %> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_th_32:
" for x be objectHIDDENM1 holds <%AFINSQ-1K7 x%> =FUNCT-1R1 {TARSKIK1 [TARSKIK4 0NUMBERSK6,x ] }"
  using funct_4_th_82 sorry

mtheorem afinsq_1_th_33:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K7 x%> iff domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds (p =FUNCT-1R1 <%AFINSQ-1K7 x%> implies domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}) & (domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x} implies p =FUNCT-1R1 <%AFINSQ-1K7 x%>)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    show "p =FUNCT-1R1 <%AFINSQ-1K7 x%> implies domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 \<one>\<^sub>M & rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
    proof(rule impI,rule conjMI)
      assume A1: "p =FUNCT-1R1 <%AFINSQ-1K7 x%>"
      thus "domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 \<one>\<^sub>M"
        using afinsq_1_def_4 sorry
      have "domAFINSQ-1K3 p =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
        using A1 afinsq_1_def_4 card_1_th_49 sorry
      then have "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 p .FUNCT-1K1 (0NUMBERSK6) }"
        using funct_1_th_4 sorry
      thus "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
        using A1 afinsq_1_def_4 sorry
    qed
    assume A2: "domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 \<one>\<^sub>M"
      and A3: "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 x}"
    have "\<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
       sorry
    then have "p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 {TARSKIK1 x}"
      using A2 A3 funct_1_th_3 nat_1_th_45 sorry
    then have "p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
      using tarski_def_1 sorry
    thus "p =FUNCT-1R1 <%AFINSQ-1K7 x%>"
      using A2 afinsq_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_34:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K7 x%> iff lenAFINSQ-1K2 p =XBOOLE-0R4 \<one>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
  using afinsq_1_def_4 sorry

mtheorem afinsq_1_reduce_3:
  mlet "x be objectHIDDENM1"
"reduce (<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6) to x"
proof
(*reducibility*)
  show "(<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
    using afinsq_1_th_34 sorry
qed "sorry"

mtheorem afinsq_1_th_35:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
proof-
  have " for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    have "0NUMBERSK6 inTARSKIR2 \<one>\<^sub>M"
      using card_1_th_49 tarski_def_1 sorry
    then have "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 x%>)"
      using afinsq_1_def_4 sorry
    then have "((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p).FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 (<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6)"
      using afinsq_1_def_3 sorry
    thus "((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_36:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 lenAFINSQ-1K2 p =HIDDENR1 x"
proof-
  have " for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 lenAFINSQ-1K2 p =HIDDENR1 x"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    have A1: "domAFINSQ-1K3 (<%AFINSQ-1K7 x%>) =XBOOLE-0R4 \<one>\<^sub>M & 0NUMBERSK6 inTARSKIR2 SegmCARD-1K5 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using afinsq_1_def_4 nat_1_th_45 sorry
    have "lenAFINSQ-1K2 p +NAT-1K1 0NUMBERSK6 =XBOOLE-0R4 lenAFINSQ-1K2 p"
       sorry
    then have "(p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 lenAFINSQ-1K2 p =HIDDENR1 (<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6)"
      using A1 afinsq_1_def_3 sorry
    also have "... = x"
       sorry
    finally show "(p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 lenAFINSQ-1K2 p =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_37:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds <%AFINSQ-1K9 x,y,z %> =FUNCT-1R1 (<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K8 y,z %>) & <%AFINSQ-1K9 x,y,z %> =FUNCT-1R1 (<%AFINSQ-1K8 x,y %>)^AFINSQ-1K6 (<%AFINSQ-1K7 z%>)"
  using afinsq_1_th_27 sorry

mtheorem afinsq_1_th_38:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K8 x,y %> iff (lenAFINSQ-1K2 p =XBOOLE-0R4 \<two>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds (p =FUNCT-1R1 <%AFINSQ-1K8 x,y %> implies (lenAFINSQ-1K2 p =XBOOLE-0R4 \<two>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y) & (lenAFINSQ-1K2 p =XBOOLE-0R4 \<two>\<^sub>M & (p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y) implies p =FUNCT-1R1 <%AFINSQ-1K8 x,y %>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    show "p =FUNCT-1R1 <%AFINSQ-1K8 x,y %> implies (lenAFINSQ-1K2 p =XBOOLE-0R4 \<two>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
    proof-
      have "p =FUNCT-1R1 <%AFINSQ-1K8 x,y %> implies lenAFINSQ-1K2 p =HIDDENR1 \<two>\<^sub>M & (p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y)"
      proof(rule impI,rule conjMI,rule conjMI)
        assume A1: "p =FUNCT-1R1 <%AFINSQ-1K8 x,y %>"
        then have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 y%>)"
          using afinsq_1_def_3 sorry
        also have "... = \<one>\<^sub>M +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 y%>)"
          using afinsq_1_th_33 sorry
        also have "... = \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using afinsq_1_th_33 sorry
        also have "... = \<two>\<^sub>M"
           sorry
        finally show "lenAFINSQ-1K2 p =HIDDENR1 \<two>\<^sub>M"
           sorry
        have A2: "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        then have A3: "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 y%>)"
          using afinsq_1_def_4 card_1_th_49 sorry
        have "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 x%>)"
          using A2 afinsq_1_def_4 card_1_th_49 sorry
        then have "p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 (<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6)"
          using A1 afinsq_1_def_3 sorry
        also have "... = x"
           sorry
        finally show "p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
           sorry
        have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K7 y%>)).FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 0NUMBERSK6)"
          using A1 afinsq_1_th_33 sorry
        also have "... = (<%AFINSQ-1K7 y%>).FUNCT-1K1 (0NUMBERSK6)"
          using A3 afinsq_1_def_3 sorry
        also have "... = y"
           sorry
        finally show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: "lenAFINSQ-1K2 p =XBOOLE-0R4 \<two>\<^sub>M"
      and A5: "p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
      and A6: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
    have A7: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 y%>) implies p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +XCMPLX-0K2 k) =XBOOLE-0R4 (<%AFINSQ-1K7 y%>).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 y%>) implies p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +XCMPLX-0K2 k) =HIDDENR1 (<%AFINSQ-1K7 y%>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 y%>)"
        then have A8: "k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using afinsq_1_def_4 card_1_th_49 sorry
        have "p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +XCMPLX-0K2 k) =HIDDENR1 p .FUNCT-1K1 (\<one>\<^sub>M +XCMPLX-0K2 k)"
          using afinsq_1_th_33 sorry
        also have "... = p .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
          using A8 tarski_def_1 sorry
        also have "... = (<%AFINSQ-1K7 y%>).FUNCT-1K1 (0NUMBERSK6)"
          using A6 sorry
        also have "... = (<%AFINSQ-1K7 y%>).FUNCT-1K1 k"
          using A8 tarski_def_1 sorry
        finally show "p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +XCMPLX-0K2 k) =HIDDENR1 (<%AFINSQ-1K7 y%>).FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 x%>) implies p .FUNCT-1K1 k =XBOOLE-0R4 (<%AFINSQ-1K7 x%>).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 x%>)"
      then have "k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using afinsq_1_def_4 card_1_th_49 sorry
      then have "k =XBOOLE-0R4 0NUMBERSK6"
        using tarski_def_1 sorry
      thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<%AFINSQ-1K7 x%>).FUNCT-1K1 k"
        using A5 sorry
    qed "sorry"
    have "domAFINSQ-1K3 p =HIDDENR1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A4 sorry
    also have "... = lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 \<one>\<^sub>M"
      using afinsq_1_th_33 sorry
    also have "... = lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 y%>)"
      using afinsq_1_th_33 sorry
    finally have "domAFINSQ-1K3 p =HIDDENR1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 y%>)"
       sorry
    thus "p =FUNCT-1R1 <%AFINSQ-1K8 x,y %>"
      using A9 A7 afinsq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_reduce_4:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"reduce (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 (0NUMBERSK6) to x"
proof
(*reducibility*)
  show "(<%AFINSQ-1K8 x,y %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
    using afinsq_1_th_38 sorry
qed "sorry"

mtheorem afinsq_1_reduce_5:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"reduce (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 \<one>\<^sub>M to y"
proof
(*reducibility*)
  show "(<%AFINSQ-1K8 x,y %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
    using afinsq_1_th_38 sorry
qed "sorry"

mtheorem afinsq_1_th_39:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %> iff ((lenAFINSQ-1K2 p =XBOOLE-0R4 \<three>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds (p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %> implies ((lenAFINSQ-1K2 p =XBOOLE-0R4 \<three>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z) & (lenAFINSQ-1K2 p =XBOOLE-0R4 \<three>\<^sub>M & (p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z)) implies p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    show "p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %> implies ((lenAFINSQ-1K2 p =XBOOLE-0R4 \<three>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x) & p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y) & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z"
    proof-
      have "p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %> implies lenAFINSQ-1K2 p =HIDDENR1 \<three>\<^sub>M & (p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x & (p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y & p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z))"
      proof(rule impI,rule conjMI,rule conjMI,rule conjMI)
        have A1: "0NUMBERSK6 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        then have A2: "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 x%>)"
          using afinsq_1_def_4 card_1_th_49 sorry
        have A3: "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 z%>)"
          using A1 afinsq_1_def_4 card_1_th_49 sorry
        assume A4: "p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %>"
        then have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 z%>)"
          using afinsq_1_def_3 sorry
        also have "... = \<two>\<^sub>M +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 z%>)"
          using afinsq_1_th_38 sorry
        also have "... = \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using afinsq_1_th_33 sorry
        also have "... = \<three>\<^sub>M"
           sorry
        finally show "lenAFINSQ-1K2 p =HIDDENR1 \<three>\<^sub>M"
           sorry
        have "p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (<%AFINSQ-1K8 y,z %>)).FUNCT-1K1 (0NUMBERSK6)"
          using A4 afinsq_1_th_27 sorry
        also have "... = (<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6)"
          using A2 afinsq_1_def_3 sorry
        also have "... = x"
           sorry
        finally show "p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
           sorry
        have "\<one>\<^sub>M inTARSKIR2 SegmCARD-1K5 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) & lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) =XBOOLE-0R4 \<two>\<^sub>M"
          using afinsq_1_th_38 nat_1_th_45 sorry
        then have "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 \<one>\<^sub>M"
          using A4 afinsq_1_def_3 sorry
        also have "... = y"
           sorry
        finally show "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
           sorry
        have "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 ((<%AFINSQ-1K8 x,y %>)^AFINSQ-1K6 (<%AFINSQ-1K7 z%>)).FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +NAT-1K1 0NUMBERSK6)"
          using A4 afinsq_1_th_38 sorry
        also have "... = (<%AFINSQ-1K7 z%>).FUNCT-1K1 (0NUMBERSK6)"
          using A3 afinsq_1_def_3 sorry
        also have "... = z"
           sorry
        finally show "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A5: "lenAFINSQ-1K2 p =XBOOLE-0R4 \<three>\<^sub>M"
      and A6: "p .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
      and A7: "p .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
      and A8: "p .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z"
    have A9: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K8 x,y %>) implies p .FUNCT-1K1 k =XBOOLE-0R4 (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      have A10: "lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) =XBOOLE-0R4 \<two>\<^sub>M"
        using afinsq_1_th_38 sorry
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A11: "k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K8 x,y %>)"
      have A12: "k =XBOOLE-0R4 \<one>\<^sub>M implies p .FUNCT-1K1 k =XBOOLE-0R4 (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 k"
        using A7 sorry
      have "k =XBOOLE-0R4 0NUMBERSK6 implies p .FUNCT-1K1 k =XBOOLE-0R4 (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 k"
        using A6 sorry
      thus "p .FUNCT-1K1 k =XBOOLE-0R4 (<%AFINSQ-1K8 x,y %>).FUNCT-1K1 k"
        using A11 A10 A12 card_1_th_50 tarski_def_2 sorry
    qed "sorry"
    have A13: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 z%>) implies p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +XCMPLX-0K2 k) =XBOOLE-0R4 (<%AFINSQ-1K7 z%>).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 z%>) implies p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +XCMPLX-0K2 k) =HIDDENR1 (<%AFINSQ-1K7 z%>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 z%>)"
        then have "k inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using afinsq_1_def_4 card_1_th_49 sorry
        then have A14: "k =XBOOLE-0R4 0NUMBERSK6"
          using tarski_def_1 sorry
        then have "p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +XCMPLX-0K2 k) =HIDDENR1 p .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6)"
          using afinsq_1_th_38 sorry
        also have "... = (<%AFINSQ-1K7 z%>).FUNCT-1K1 k"
          using A8 A14 sorry
        finally show "p .FUNCT-1K1 (lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +XCMPLX-0K2 k) =HIDDENR1 (<%AFINSQ-1K7 z%>).FUNCT-1K1 k"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domAFINSQ-1K3 p =HIDDENR1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A5 sorry
    also have "... = lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +NAT-1K1 \<one>\<^sub>M"
      using afinsq_1_th_38 sorry
    also have "... = lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 z%>)"
      using afinsq_1_th_33 sorry
    finally have "domAFINSQ-1K3 p =HIDDENR1 lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 z%>)"
       sorry
    thus "p =FUNCT-1R1 <%AFINSQ-1K9 x,y,z %>"
      using A9 A13 afinsq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_reduce_6:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"reduce (<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 (0NUMBERSK6) to x"
proof
(*reducibility*)
  show "(<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_reduce_7:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"reduce (<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<one>\<^sub>M to y"
proof
(*reducibility*)
  show "(<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_reduce_8:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"reduce (<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<two>\<^sub>M to z"
proof
(*reducibility*)
  show "(<%AFINSQ-1K9 x,y,z %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 z"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_cl_18:
  mlet "x be objectHIDDENM1"
"cluster <%AFINSQ-1K7 x%> as-term-is \<one>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<%AFINSQ-1K7 x%> be \<one>\<^sub>M -elementCARD-1V3"
    using afinsq_1_th_33 sorry
qed "sorry"

mtheorem afinsq_1_cl_19:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <%AFINSQ-1K8 x,y %> as-term-is \<two>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<%AFINSQ-1K8 x,y %> be \<two>\<^sub>M -elementCARD-1V3"
    using afinsq_1_th_38 sorry
qed "sorry"

mtheorem afinsq_1_cl_20:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "z be objectHIDDENM1"
"cluster <%AFINSQ-1K9 x,y,z %> as-term-is \<three>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "<%AFINSQ-1K9 x,y,z %> be \<three>\<^sub>M -elementCARD-1V3"
    using afinsq_1_th_39 sorry
qed "sorry"

mtheorem afinsq_1_cl_21:
  mlet "n be NatNAT-1M1"
"cluster n -elementCARD-1V3 also-is n -definedRELAT-1V4 for XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M1 holds it be n -elementCARD-1V3 implies it be n -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_22:
  mlet "n be NatNAT-1M1", "x be objectHIDDENM1"
"cluster n -->FUNCOP-1K7 x as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "n -->FUNCOP-1K7 x be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_23:
  mlet "n be NatNAT-1M1"
"cluster n -elementCARD-1V3 for XFinSequenceAFINSQ-1M1"
proof
(*existence*)
  show " ex it be XFinSequenceAFINSQ-1M1 st it be n -elementCARD-1V3"
  proof-
    have " ex tVar7 be XFinSequenceAFINSQ-1M1 st tVar7 be n -elementCARD-1V3"
    proof-
      show " ex tVar7 be XFinSequenceAFINSQ-1M1 st tVar7 be n -elementCARD-1V3"
      proof(rule bexI[of _ "n -->FUNCOP-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6"])
        have "cardCARD-1K4 (n -->FUNCOP-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6) =XBOOLE-0R4 n"
        proof-
          show "cardCARD-1K4 (n -->FUNCOP-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6) =XBOOLE-0R4 n"
            using funcop_1_th_13 sorry
        qed
        thus "n -->FUNCOP-1K8\<^bsub>(omegaORDINAL1K4)\<^esub> 0NUMBERSK6 be n -elementCARD-1V3"
          using card_1_def_7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_cl_24:
  mlet "n be NatNAT-1M1"
"cluster note-that totalPARTFUN1V1\<^bsub>(n)\<^esub> for n -elementCARD-1V3\<bar>n -definedRELAT-1V4\<bar>XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be n -elementCARD-1V3\<bar>n -definedRELAT-1V4\<bar>XFinSequenceAFINSQ-1M1 holds it be totalPARTFUN1V1\<^bsub>(n)\<^esub>"
  proof-
    have " for s be n -elementCARD-1V3\<bar>XFinSequenceAFINSQ-1M1 holds s be totalPARTFUN1V1\<^bsub>(n)\<^esub>"
    proof(rule ballI)
      fix s assume [ty]: "s be n -elementCARD-1V3\<bar>XFinSequenceAFINSQ-1M1"
      have Cut1027: "cardCARD-1K4 s =XBOOLE-0R4 n"
        using card_1_def_7 sorry
      have "domAFINSQ-1K3 s =XBOOLE-0R4 n"
      proof-
        show "domAFINSQ-1K3 s =XBOOLE-0R4 n"
          using Cut1027 sorry
      qed
      thus "s be totalPARTFUN1V1\<^bsub>(n)\<^esub>"
        using partfun1_def_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_40:
" for p be XFinSequenceAFINSQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex q be XFinSequenceAFINSQ-1M1 st  ex x be objectHIDDENM1 st p =FUNCT-1R1 q ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar8 be XFinSequenceAFINSQ-1M1 st  ex tVar9 be objectHIDDENM1 st tVar8 ^AFINSQ-1K6 (<%AFINSQ-1K7 tVar9%>) =FUNCT-1R1 p)"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    assume "p <>HIDDENR2 {}XBOOLE-0K1"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_6 sorry
    have A2: "domAFINSQ-1K3 p =XBOOLE-0R4 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
      using A1 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    let ?q = "p  |RELAT-1K8 n"
    have "domAFINSQ-1K3 ?q =XBOOLE-0R4 lenAFINSQ-1K2 p /\\XBOOLE-0K3 n & SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 lenAFINSQ-1K2 p"
      using A1 nat_1_th_11 nat_1_th_39 relat_1_th_61 sorry
    then have A3: "domAFINSQ-1K3 ?q =XBOOLE-0R4 n"
      using xboole_1_th_28 sorry
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 p implies p .FUNCT-1K1 x =XBOOLE-0R4 (?q ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 p implies p .FUNCT-1K1 x =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 domAFINSQ-1K3 p"
        then obtain k where 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = x"
           sorry
        have A6: "k inTARSKIR2 n implies p .FUNCT-1K1 k =HIDDENR1 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 k"
        proof(rule impI)
          assume A7: "k inTARSKIR2 n"
          then have "p .FUNCT-1K1 k =HIDDENR1 (p  |RELAT-1K8 n).FUNCT-1K1 k"
            using A3 funct_1_th_47 sorry
          also have "... = (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 k"
            using A3 A7 afinsq_1_def_3 sorry
          finally show "p .FUNCT-1K1 k =HIDDENR1 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 k"
             sorry
        qed
        have A8: "k inTARSKIR2 {TARSKIK1 n} implies (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
        proof(rule impI)
          have "0NUMBERSK6 inTARSKIR2 SegmCARD-1K5 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
            using nat_1_th_45 sorry
          then have A9: "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)"
            using afinsq_1_def_4 sorry
          assume A10: "k inTARSKIR2 {TARSKIK1 n}"
          then have "(p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 k =HIDDENR1 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 (lenAFINSQ-1K2 (p  |RELAT-1K8 n) +NAT-1K1 0NUMBERSK6)"
            using A3 tarski_def_1 sorry
          also have "... = (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>).FUNCT-1K1 (0NUMBERSK6)"
            using A9 afinsq_1_def_3 sorry
          also have "... = p .FUNCT-1K1 k"
            using A1 A10 tarski_def_1 sorry
          finally show "(p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 k =HIDDENR1 p .FUNCT-1K1 k"
             sorry
        qed
        have "k inTARSKIR2 SegmCARD-1K5 n \\/XBOOLE-0K2 {TARSKIK1 n}"
          using A5 afinsq_1_th_2 A2 sorry
        thus "p .FUNCT-1K1 x =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)).FUNCT-1K1 x"
          using A6 A8 xboole_0_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " ex tVar8 be XFinSequenceAFINSQ-1M1 st  ex tVar9 be objectHIDDENM1 st tVar8 ^AFINSQ-1K6 (<%AFINSQ-1K7 tVar9%>) =FUNCT-1R1 p"
    proof(rule bexI[of _ "?q"])
      show " ex tVar9 be objectHIDDENM1 st p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 tVar9%>) =FUNCT-1R1 p"
      proof(rule bexI[of _ "p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)"])
        have "domAFINSQ-1K3 (?q ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)) =HIDDENR1 lenAFINSQ-1K2 ?q +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)"
          using afinsq_1_def_3 sorry
        also have "... = domAFINSQ-1K3 p"
          using A1 A3 afinsq_1_th_33 sorry
        finally have "domAFINSQ-1K3 (?q ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>)) =HIDDENR1 domAFINSQ-1K3 p"
           sorry
        thus "p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 (lenAFINSQ-1K2 p -XCMPLX-0K6 \<one>\<^sub>M)%>) =FUNCT-1R1 p"
          using A4 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_cl_25:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D"
"cluster <%AFINSQ-1K7 d1%> as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K7 d1%> be D -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_26:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D", "d2 be ElementSUBSET-1M1-of D"
"cluster <%AFINSQ-1K8 d1,d2 %> as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K8 d1,d2 %> be D -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_27:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d1 be ElementSUBSET-1M1-of D", "d2 be ElementSUBSET-1M1-of D", "d3 be ElementSUBSET-1M1-of D"
"cluster <%AFINSQ-1K9 d1,d2,d3 %> as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K9 d1,d2,d3 %> be D -valuedRELAT-1V5"
     sorry
qed "sorry"

theorem afinsq_1_sch_3:
  fixes Pp1 
  assumes
    A1: "Pp1({}XBOOLE-0K1)" and
   A2: " for p be XFinSequenceAFINSQ-1M1 holds  for x be objectHIDDENM1 holds Pp1(p) implies Pp1(p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
  shows " for p be XFinSequenceAFINSQ-1M1 holds Pp1(p)"
  proof(rule ballI)
    let ?P1 = "\<lambda>Lamb1.  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =HIDDENR1 Lamb1 implies Pp1(p)"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    obtain X where
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
      A3: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 X iff ?P1(x)"
      using subset_1_sch_3 sorry
    have " for k be NatNAT-1M1 holds k inTARSKIR2 X"
    proof-
      have A4: "0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      let ?R = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
      have " for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 0NUMBERSK6 implies Pp1(p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
        assume "lenAFINSQ-1K2 p =XBOOLE-0R4 0NUMBERSK6"
        then have "p =FUNCT-1R1 {}XBOOLE-0K1"
           sorry
        thus "Pp1(p)"
          using A1 sorry
      qed "sorry"
      then have A5: "?R(0NUMBERSK6)"
        using A3 A4 sorry
      have A6: " for n be NatNAT-1M1 holds ?R(n) implies ?R(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds n inTARSKIR2 X implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 X"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A7: "?R(n)"
          have A8: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          have "?P1(n +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies Pp1(p)"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
              assume A9: "lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
              then have "p <>HIDDENR2 {}XBOOLE-0K1"
                 sorry
              then obtain w x where
                [ty]:"w be XFinSequenceAFINSQ-1M1" "x be objectHIDDENM1" and 
                A10: "p =FUNCT-1R1 w ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)"
                using afinsq_1_th_40 sorry
              have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 w +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>)"
                using A10 afinsq_1_def_3 sorry
              also have "... = lenAFINSQ-1K2 w +NAT-1K1 \<one>\<^sub>M"
                using afinsq_1_def_4 sorry
              finally have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 w +NAT-1K1 \<one>\<^sub>M"
                 sorry
              then have "Pp1(w)"
                using A3 A7 A9 sorry
              thus "Pp1(p)"
                using A10 A2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 X"
            using A3 A8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " for k be NatNAT-1M1 holds k inTARSKIR2 X"
        using nat_1_sch_2 A5 A6 sorry
    qed
    then have "lenAFINSQ-1K2 p inTARSKIR2 X"
       sorry
    thus "Pp1(p)"
      using A3 sorry
  qed "sorry"

mtheorem afinsq_1_th_41:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 r ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r implies ( ex t be XFinSequenceAFINSQ-1M1 st p ^AFINSQ-1K6 t =FUNCT-1R1 r)"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds  not ((p ^AFINSQ-1K6 q =FUNCT-1R1 r ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r) & ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r))"
  proof-
    let ?P = "\<lambda>Lamb1.  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 Lamb1 ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 Lamb1 implies ( ex t be XFinSequenceAFINSQ-1M1 st p ^AFINSQ-1K6 t =FUNCT-1R1 Lamb1)"
    have A1: " for r be XFinSequenceAFINSQ-1M1 holds  for x be objectHIDDENM1 holds ?P(r) implies ?P(r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
    proof-
      have " for r be XFinSequenceAFINSQ-1M1 holds  for x be objectHIDDENM1 holds ( for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 r ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r implies ( ex t be XFinSequenceAFINSQ-1M1 st p ^AFINSQ-1K6 t =FUNCT-1R1 r)) implies ( for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) implies  not ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)))"
      proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix r assume [ty]: "r be XFinSequenceAFINSQ-1M1"
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 r ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r implies ( ex t be XFinSequenceAFINSQ-1M1 st p ^AFINSQ-1K6 t =FUNCT-1R1 r)"
        fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
        fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
        fix s assume [ty]: "s be XFinSequenceAFINSQ-1M1"
        assume A3: "p ^AFINSQ-1K6 q =FUNCT-1R1 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))^AFINSQ-1K6 s"
          and A4: "lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
        have A5: "lenAFINSQ-1K2 p <>HIDDENR2 lenAFINSQ-1K2 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) implies  not ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
        proof(rule impI)
          assume "lenAFINSQ-1K2 p <>HIDDENR2 lenAFINSQ-1K2 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
          then have "lenAFINSQ-1K2 p <>HIDDENR2 lenAFINSQ-1K2 r +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>)"
            using afinsq_1_def_3 sorry
          then have A6: "lenAFINSQ-1K2 p <>HIDDENR2 lenAFINSQ-1K2 r +NAT-1K1 \<one>\<^sub>M"
            using afinsq_1_th_33 sorry
          have "lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>)"
            using A4 afinsq_1_def_3 sorry
          then have A7: "lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r +NAT-1K1 \<one>\<^sub>M"
            using afinsq_1_th_33 sorry
          have "p ^AFINSQ-1K6 q =FUNCT-1R1 r ^AFINSQ-1K6 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 s)"
            using A3 afinsq_1_th_27 sorry
          then obtain t where
            [ty]:"t be XFinSequenceAFINSQ-1M1" and 
            A8: "p ^AFINSQ-1K6 t =FUNCT-1R1 r"
            using A2 A6 A7 nat_1_th_8 sorry
          have "p ^AFINSQ-1K6 (t ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)"
            using A8 afinsq_1_th_27 sorry
          thus " not ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
             sorry
        qed
        have "lenAFINSQ-1K2 p =XBOOLE-0R4 lenAFINSQ-1K2 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) implies  not ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
        proof(rule impI)
          assume A9: "lenAFINSQ-1K2 p =XBOOLE-0R4 lenAFINSQ-1K2 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
          have A10: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =XBOOLE-0R4 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 k"
          proof-
            have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 k =HIDDENR1 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 k"
            proof(rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A11: "k inTARSKIR2 domAFINSQ-1K3 p"
              then have "p .FUNCT-1K1 k =HIDDENR1 ((r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))^AFINSQ-1K6 s).FUNCT-1K1 k"
                using A3 afinsq_1_def_3 sorry
              also have "... = (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 k"
                using A9 A11 afinsq_1_def_3 sorry
              finally show "p .FUNCT-1K1 k =HIDDENR1 (r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)).FUNCT-1K1 k"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "p ^AFINSQ-1K6 {}XBOOLE-0K1 =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)"
            using A9 A10 sorry
          thus " not ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
             sorry
        qed
        thus " not ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
          using A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A12: "?P({}XBOOLE-0K1)"
    proof-
      have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 {}XBOOLE-0K1 ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 ({}XBOOLE-0K1) implies ( ex tVar10 be XFinSequenceAFINSQ-1M1 st p ^AFINSQ-1K6 tVar10 =FUNCT-1R1 tVar10)"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
        fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
        fix s assume [ty]: "s be XFinSequenceAFINSQ-1M1"
        assume "p ^AFINSQ-1K6 q =FUNCT-1R1 {}XBOOLE-0K1 ^AFINSQ-1K6 s"
          and A13: "lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 ({}XBOOLE-0K1)"
        show " ex tVar10 be XFinSequenceAFINSQ-1M1 st p ^AFINSQ-1K6 tVar10 =FUNCT-1R1 tVar10"
        proof(rule bexI[of _ "{}XBOOLE-0K1"])
          show "p ^AFINSQ-1K6 {}XBOOLE-0K1 =FUNCT-1R1 {}XBOOLE-0K1"
            using A13 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for r be XFinSequenceAFINSQ-1M1 holds ?P(r)"
      using afinsq_1_sch_3 A12 A1 sorry
    thus " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for r be XFinSequenceAFINSQ-1M1 holds  for s be XFinSequenceAFINSQ-1M1 holds  not ((p ^AFINSQ-1K6 q =FUNCT-1R1 r ^AFINSQ-1K6 s & lenAFINSQ-1K2 p <=XXREAL-0R1 lenAFINSQ-1K2 r) & ( for t be XFinSequenceAFINSQ-1M1 holds  not p ^AFINSQ-1K6 t =FUNCT-1R1 r))"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef afinsq_1_def_7 (" _ ^omegaAFINSQ-1K10" [164]164 ) where
  mlet "D be setHIDDENM2"
"func D ^omegaAFINSQ-1K10 \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be XFinSequenceAFINSQ-1M2-of D"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be XFinSequenceAFINSQ-1M2-of D"
    proof-
      have " ex tVar11 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar11 implies x be XFinSequenceAFINSQ-1M2-of D) & (x be XFinSequenceAFINSQ-1M2-of D implies x inHIDDENR3 tVar11)"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be XFinSequenceAFINSQ-1M2-of D"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,D :]) & ?P(x)"
          using xboole_0_sch_1 sorry
        show " ex tVar11 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar11 implies x be XFinSequenceAFINSQ-1M2-of D) & (x be XFinSequenceAFINSQ-1M2-of D implies x inHIDDENR3 tVar11)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 X implies x be XFinSequenceAFINSQ-1M2-of D"
            using A1 sorry
          assume "x be XFinSequenceAFINSQ-1M2-of D"
          then obtain p where 
            [ty]:"p be XFinSequenceAFINSQ-1M2-of D" and pDef:"p = x"
             sorry
          have 
            [ty]:"p be PartFuncPARTFUN1M1-of(NATNUMBERSK1,D)"
            using afinsq_1_th_12 sorry
          have "p c=RELAT-1R2 [:ZFMISC-1K2 NATNUMBERSK1,D :]"
             sorry
          thus "x inHIDDENR3 X"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x be XFinSequenceAFINSQ-1M2-of D) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x be XFinSequenceAFINSQ-1M2-of D) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x be XFinSequenceAFINSQ-1M2-of D) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff x be XFinSequenceAFINSQ-1M2-of D) implies X1 =XBOOLE-0R4 X2"
      proof-
        let ?P = "\<lambda>Lamb1. Lamb1 be XFinSequenceAFINSQ-1M2-of D"
        show " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x be XFinSequenceAFINSQ-1M2-of D) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff x be XFinSequenceAFINSQ-1M2-of D) implies X1 =XBOOLE-0R4 X2"
          using xboole_0_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem afinsq_1_cl_28:
  mlet "D be setHIDDENM2"
"cluster D ^omegaAFINSQ-1K10 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "D ^omegaAFINSQ-1K10 be  non emptyXBOOLE-0V1"
  proof-
    have " not D ^omegaAFINSQ-1K10 be emptyXBOOLE-0V1"
    proof-
      let ?f = "the XFinSequenceAFINSQ-1M2-of D"
      have "?f inTARSKIR2 D ^omegaAFINSQ-1K10"
        using afinsq_1_def_7 sorry
      thus " not D ^omegaAFINSQ-1K10 be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_42:
" for x be objectHIDDENM1 holds  for D be setHIDDENM2 holds x inHIDDENR3 D ^omegaAFINSQ-1K10 iff x be XFinSequenceAFINSQ-1M2-of D"
  using afinsq_1_def_7 sorry

mtheorem afinsq_1_th_43:
" for D be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 D ^omegaAFINSQ-1K10"
proof-
  have " for D be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 D ^omegaAFINSQ-1K10"
  proof(rule ballI)
    fix D assume [ty]: "D be setHIDDENM2"
    have "{}XBOOLE-0K1 =FUNCT-1R1 <%>AFINSQ-1K5 D"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 D ^omegaAFINSQ-1K10"
      using afinsq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem afinsq_1_sch_4:
  fixes Df0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows " ex X be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex p be XFinSequenceAFINSQ-1M1 st (p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p)"
  proof-
    have " ex tVar12 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar12 & ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 tVar12)"
    proof-
      let ?P1 = "\<lambda>Lamb1.  ex p be XFinSequenceAFINSQ-1M1 st Pp1(p) & Lamb1 =HIDDENR1 p"
      obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Y iff x inHIDDENR3 Df0 ^omegaAFINSQ-1K10 & ?P1(x)"
        using xboole_0_sch_1 sorry
      show " ex tVar12 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar12 & ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 tVar12)"
      proof(rule bexI[of _ "Y"])
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex p be XFinSequenceAFINSQ-1M1 st (p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p)"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies  not ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Y"
            then have "x inHIDDENR3 Df0 ^omegaAFINSQ-1K10 & ( ex p be XFinSequenceAFINSQ-1M1 st Pp1(p) & x =HIDDENR1 p)"
              using A1 sorry
            thus " not ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Y & ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p))) &  not ( not ( for p be XFinSequenceAFINSQ-1M1 holds  not ((p inTARSKIR2 Df0 ^omegaAFINSQ-1K10 & Pp1(p)) & x =HIDDENR1 p)) &  not x inHIDDENR3 Y)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

abbreviation(input) AFINSQ_1K11("ReplaceAFINSQ-1K11'( _ , _ , _ ')" [0,0,0]164) where
  "ReplaceAFINSQ-1K11(p,i,x) \<equiv> p +*FUNCT-7K1(i,x)"

mtheorem afinsq_1_cl_29:
  mlet "p be XFinSequenceAFINSQ-1M1", "i be objectHIDDENM1", "x be objectHIDDENM1"
"cluster p +*FUNCT-7K1(i,x) as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "p +*FUNCT-7K1(i,x) be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
  proof-
    have "p +*FUNCT-7K1(i,x) be finiteFINSET-1V1 & p +*FUNCT-7K1(i,x) be Sequence-likeORDINAL1V5"
    proof-
      have "domRELAT-1K1 (p +*FUNCT-7K1(i,x)) =XBOOLE-0R4 domAFINSQ-1K3 p"
        using funct_7_th_30 sorry
      thus "p +*FUNCT-7K1(i,x) be finiteFINSET-1V1 & p +*FUNCT-7K1(i,x) be Sequence-likeORDINAL1V5"
        using finset_1_th_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_44:
" for p be XFinSequenceAFINSQ-1M1 holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for x be setHIDDENM2 holds (lenAFINSQ-1K2 (ReplaceAFINSQ-1K11(p,i,x)) =XBOOLE-0R4 lenAFINSQ-1K2 p & (i <XXREAL-0R3 lenAFINSQ-1K2 p implies (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 i =XBOOLE-0R4 x)) & ( for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds j <>HIDDENR2 i implies (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 j =XBOOLE-0R4 p .FUNCT-1K1 j)"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for x be setHIDDENM2 holds lenAFINSQ-1K2 (ReplaceAFINSQ-1K11(p,i,x)) =XBOOLE-0R4 lenAFINSQ-1K2 p & ((i <XXREAL-0R3 lenAFINSQ-1K2 p implies (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 i =XBOOLE-0R4 x) & ( for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( not j <>HIDDENR2 i &  not (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 j =XBOOLE-0R4 p .FUNCT-1K1 j)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix x assume [ty]: "x be setHIDDENM2"
    let ?f = "ReplaceAFINSQ-1K11(p,i,x)"
    show "lenAFINSQ-1K2 (ReplaceAFINSQ-1K11(p,i,x)) =XBOOLE-0R4 lenAFINSQ-1K2 p"
      using funct_7_th_30 sorry
    have "i <XXREAL-0R3 lenAFINSQ-1K2 p implies  not SegmCARD-1K5 lenAFINSQ-1K2 p c=ORDINAL1R1 SegmCARD-1K5 i"
      using nat_1_th_39 sorry
    thus "i <XXREAL-0R3 lenAFINSQ-1K2 p implies (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 i =XBOOLE-0R4 x"
      using funct_7_th_31 ordinal1_th_16 sorry
    show " for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( not j <>HIDDENR2 i &  not (ReplaceAFINSQ-1K11(p,i,x)).FUNCT-1K1 j =XBOOLE-0R4 p .FUNCT-1K1 j)"
      using funct_7_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_cl_30:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be XFinSequenceAFINSQ-1M2-of D", "i be ElementSUBSET-1M1-of NATNUMBERSK1", "a be ElementSUBSET-1M1-of D"
"cluster ReplaceAFINSQ-1K11(p,i,a) as-term-is D -valuedRELAT-1V5"
proof
(*coherence*)
  show "ReplaceAFINSQ-1K11(p,i,a) be D -valuedRELAT-1V5"
  proof-
    have "rngFUNCT-1K2 (ReplaceAFINSQ-1K11(p,i,a)) c=TARSKIR1 D"
    proof-
      show "rngFUNCT-1K2 (ReplaceAFINSQ-1K11(p,i,a)) c=TARSKIR1 D"
      proof-
        have cases: "i inTARSKIR2 domAFINSQ-1K3 p or  not i inTARSKIR2 domAFINSQ-1K3 p"
           sorry
        have case1: "i inTARSKIR2 domAFINSQ-1K3 p implies ReplaceAFINSQ-1K11(p,i,a) be D -valuedRELAT-1V5"
        proof(rule impI)
          assume "i inTARSKIR2 domAFINSQ-1K3 p"
          then have "ReplaceAFINSQ-1K11(p,i,a) =FUNCT-1R1 p +*FUNCT-4K1 (i .-->FUNCOP-1K17 a)"
            using funct_7_def_3 sorry
          then have A1: "rngFUNCT-1K2 (ReplaceAFINSQ-1K11(p,i,a)) c=TARSKIR1 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (i .-->FUNCOP-1K17 a)"
            using funct_4_th_17 sorry
          have "rngFUNCT-1K2 (i .-->FUNCOP-1K17 a) =XBOOLE-0R4 {TARSKIK1 a}"
            using funcop_1_th_8 sorry
          then have A2: "rngFUNCT-1K2 (i .-->FUNCOP-1K17 a) c=TARSKIR1 D"
            using zfmisc_1_th_31 sorry
          have "rngFUNCT-1K2 p c=TARSKIR1 D"
            using relat_1_def_19 sorry
          then have Cut1317: "rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 (i .-->FUNCOP-1K17 a) c=TARSKIR1 D"
            using A2 xboole_1_th_8 sorry
          have "rngFUNCT-1K2 (ReplaceAFINSQ-1K11(p,i,a)) c=TARSKIR1 D"
          proof-
            show "rngFUNCT-1K2 (ReplaceAFINSQ-1K11(p,i,a)) c=TARSKIR1 D"
              using A1 Cut1317 sorry
          qed
          thus "ReplaceAFINSQ-1K11(p,i,a) be D -valuedRELAT-1V5"
            using relat_1_def_19 sorry
        qed
        have case2: " not i inTARSKIR2 domAFINSQ-1K3 p implies ReplaceAFINSQ-1K11(p,i,a) be D -valuedRELAT-1V5"
        proof(rule impI)
          assume " not i inTARSKIR2 domAFINSQ-1K3 p"
          then have Cut1322: "ReplaceAFINSQ-1K11(p,i,a) =FUNCT-1R1 p"
            using funct_7_def_3 sorry
          have "rngFUNCT-1K2 (ReplaceAFINSQ-1K11(p,i,a)) c=TARSKIR1 D"
          proof-
            show "rngFUNCT-1K2 (ReplaceAFINSQ-1K11(p,i,a)) c=TARSKIR1 D"
              using relat_1_def_19 Cut1322 sorry
          qed
          thus "ReplaceAFINSQ-1K11(p,i,a) be D -valuedRELAT-1V5"
            using relat_1_def_19 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_cl_31:
"cluster note-that real-valuedVALUED-0V7 for XFinSequenceAFINSQ-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M2-of REALNUMBERSK2 holds it be real-valuedVALUED-0V7"
  proof-
    have " for F be XFinSequenceAFINSQ-1M2-of REALNUMBERSK2 holds F be real-valuedVALUED-0V7"
    proof(rule ballI)
      fix F assume [ty]: "F be XFinSequenceAFINSQ-1M2-of REALNUMBERSK2"
      have "rngFUNCT-1K2 F c=TARSKIR1 REALNUMBERSK2"
        using relat_1_def_19 sorry
      thus "F be real-valuedVALUED-0V7"
        using valued_0_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_cl_32:
"cluster note-that natural-valuedVALUED-0V8 for XFinSequenceAFINSQ-1M2-of NATNUMBERSK1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M2-of NATNUMBERSK1 holds it be natural-valuedVALUED-0V8"
  proof-
    have " for F be XFinSequenceAFINSQ-1M2-of NATNUMBERSK1 holds F be natural-valuedVALUED-0V8"
    proof(rule ballI)
      fix F assume [ty]: "F be XFinSequenceAFINSQ-1M2-of NATNUMBERSK1"
      have "rngFUNCT-1K2 F c=TARSKIR1 NATNUMBERSK1"
        using relat_1_def_19 sorry
      thus "F be natural-valuedVALUED-0V8"
        using valued_0_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_45:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds p =FUNCT-1R1 (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>) implies (((lenAFINSQ-1K2 p =XBOOLE-0R4 \<four>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds p =FUNCT-1R1 (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>) implies lenAFINSQ-1K2 p =HIDDENR1 \<four>\<^sub>M & (((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    assume A1: "p =FUNCT-1R1 (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>)"
    let ?p13 = "((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>)"
    have A2: "?p13 =FUNCT-1R1 <%AFINSQ-1K9 x1,x2,x3 %>"
       sorry
    then have A3: "lenAFINSQ-1K2 ?p13 =XBOOLE-0R4 \<three>\<^sub>M"
      using afinsq_1_th_39 sorry
    have A4: "?p13 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & ?p13 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2"
      using A2 sorry
    have A5: "?p13 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3"
      using A2 sorry
    have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>)) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x4%>)"
      using A1 afinsq_1_def_3 sorry
    also have "... = \<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A3 afinsq_1_th_33 sorry
    also have "... = \<four>\<^sub>M"
       sorry
    finally show "lenAFINSQ-1K2 p =HIDDENR1 \<four>\<^sub>M"
       sorry
    have "(0NUMBERSK6 inTARSKIR2 \<three>\<^sub>M & \<one>\<^sub>M inTARSKIR2 \<three>\<^sub>M) & \<two>\<^sub>M inTARSKIR2 \<three>\<^sub>M"
      using card_1_th_51 enumset1_def_1 sorry
    thus "(p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3"
      using A1 A4 A5 afinsq_1_def_3 A3 sorry
    have "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 p .FUNCT-1K1 lenAFINSQ-1K2 (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))"
      using A2 afinsq_1_th_39 sorry
    also have "... = x4"
      using A1 afinsq_1_th_36 sorry
    finally show "p .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_46:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds p =FUNCT-1R1 ((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>) implies ((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<five>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds p =FUNCT-1R1 ((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>) implies lenAFINSQ-1K2 p =HIDDENR1 \<five>\<^sub>M & ((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    assume A1: "p =FUNCT-1R1 ((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>)"
    let ?p14 = "(((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>)"
    have A2: "lenAFINSQ-1K2 ?p14 =XBOOLE-0R4 \<four>\<^sub>M"
      using afinsq_1_th_45 sorry
    have A3: "?p14 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & ?p14 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2"
      using afinsq_1_th_45 sorry
    have A4: "?p14 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3 & ?p14 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
      using afinsq_1_th_45 sorry
    have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 ((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>)) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x5%>)"
      using A1 afinsq_1_def_3 sorry
    also have "... = \<four>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A2 afinsq_1_th_33 sorry
    also have "... = \<five>\<^sub>M"
       sorry
    finally show "lenAFINSQ-1K2 p =HIDDENR1 \<five>\<^sub>M"
       sorry
    have " for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<three>\<^sub>M implies  not VarFor1 inTARSKIR2 \<four>\<^sub>M"
      using card_1_th_52 enumset1_def_2 sorry
    thus "((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
      using A1 A3 A4 afinsq_1_def_3 A2 sorry
    have "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 p .FUNCT-1K1 lenAFINSQ-1K2 ((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))"
      using afinsq_1_th_45 sorry
    also have "... = x5"
      using A1 afinsq_1_th_36 sorry
    finally show "p .FUNCT-1K1 \<four>\<^sub>M =HIDDENR1 x5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_47:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds p =FUNCT-1R1 (((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>) implies (((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<six>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds p =FUNCT-1R1 (((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>) implies lenAFINSQ-1K2 p =HIDDENR1 \<six>\<^sub>M & (((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    fix x6 assume [ty]: "x6 be setHIDDENM2"
    assume A1: "p =FUNCT-1R1 (((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>)"
    let ?p15 = "((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>)"
    have A2: "lenAFINSQ-1K2 ?p15 =XBOOLE-0R4 \<five>\<^sub>M"
      using afinsq_1_th_46 sorry
    have A3: "?p15 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & ?p15 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2"
      using afinsq_1_th_46 sorry
    have A4: "?p15 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3 & ?p15 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
      using afinsq_1_th_46 sorry
    have A5: "?p15 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5"
      using afinsq_1_th_46 sorry
    have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 (((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>)) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x6%>)"
      using A1 afinsq_1_def_3 sorry
    also have "... = \<five>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A2 afinsq_1_th_33 sorry
    also have "... = \<six>\<^sub>M"
       sorry
    finally show "lenAFINSQ-1K2 p =HIDDENR1 \<six>\<^sub>M"
       sorry
    have " for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<four>\<^sub>M implies  not VarFor1 inTARSKIR2 \<five>\<^sub>M"
      using card_1_th_53 enumset1_def_3 sorry
    thus "(((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5"
      using A1 A3 A4 A5 afinsq_1_def_3 A2 sorry
    have "p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 p .FUNCT-1K1 lenAFINSQ-1K2 (((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))"
      using afinsq_1_th_46 sorry
    also have "... = x6"
      using A1 afinsq_1_th_36 sorry
    finally show "p .FUNCT-1K1 \<five>\<^sub>M =HIDDENR1 x6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_48:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds p =FUNCT-1R1 ((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>) implies ((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<seven>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds p =FUNCT-1R1 ((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>) implies lenAFINSQ-1K2 p =HIDDENR1 \<seven>\<^sub>M & ((((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =HIDDENR1 x7)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    fix x6 assume [ty]: "x6 be setHIDDENM2"
    fix x7 assume [ty]: "x7 be setHIDDENM2"
    assume A1: "p =FUNCT-1R1 ((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>)"
    let ?p16 = "(((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>)"
    have A2: "lenAFINSQ-1K2 ?p16 =XBOOLE-0R4 \<six>\<^sub>M"
      using afinsq_1_th_47 sorry
    have A3: "?p16 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & ?p16 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2"
      using afinsq_1_th_47 sorry
    have A4: "?p16 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3 & ?p16 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
      using afinsq_1_th_47 sorry
    have A5: "?p16 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5 & ?p16 .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6"
      using afinsq_1_th_47 sorry
    have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 ((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>)) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x7%>)"
      using A1 afinsq_1_def_3 sorry
    also have "... = \<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using A2 afinsq_1_th_33 sorry
    also have "... = \<seven>\<^sub>M"
       sorry
    finally show "lenAFINSQ-1K2 p =HIDDENR1 \<seven>\<^sub>M"
       sorry
    have " for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<five>\<^sub>M implies  not VarFor1 inTARSKIR2 \<six>\<^sub>M"
      using card_1_th_54 enumset1_def_4 sorry
    thus "((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6"
      using A1 A3 A4 A5 afinsq_1_def_3 A2 sorry
    have "p .FUNCT-1K1 \<six>\<^sub>M =HIDDENR1 p .FUNCT-1K1 lenAFINSQ-1K2 ((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))"
      using afinsq_1_th_47 sorry
    also have "... = x7"
      using A1 afinsq_1_th_36 sorry
    finally show "p .FUNCT-1K1 \<six>\<^sub>M =HIDDENR1 x7"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_49:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds p =FUNCT-1R1 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>) implies (((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<eight>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds p =FUNCT-1R1 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>) implies (((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<eight>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    fix x6 assume [ty]: "x6 be setHIDDENM2"
    fix x7 assume [ty]: "x7 be setHIDDENM2"
    fix x8 assume [ty]: "x8 be setHIDDENM2"
    show "p =FUNCT-1R1 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>) implies (((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<eight>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8"
    proof-
      have "p =FUNCT-1R1 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>) implies lenAFINSQ-1K2 p =HIDDENR1 \<eight>\<^sub>M & (((((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =HIDDENR1 x8)"
      proof(rule impI,rule conjMI,rule conjMI)
        assume A1: "p =FUNCT-1R1 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>)"
        let ?p17 = "((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>)"
        have A2: "lenAFINSQ-1K2 ?p17 =XBOOLE-0R4 \<seven>\<^sub>M"
          using afinsq_1_th_48 sorry
        have A3: "?p17 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & ?p17 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2"
          using afinsq_1_th_48 sorry
        have A4: "?p17 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3 & ?p17 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
          using afinsq_1_th_48 sorry
        have A5: "?p17 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5 & ?p17 .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6"
          using afinsq_1_th_48 sorry
        have A6: "?p17 .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7"
          using afinsq_1_th_48 sorry
        have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>)) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x8%>)"
          using A1 afinsq_1_def_3 sorry
        also have "... = \<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A2 afinsq_1_th_33 sorry
        also have "... = \<eight>\<^sub>M"
           sorry
        finally show "lenAFINSQ-1K2 p =HIDDENR1 \<eight>\<^sub>M"
           sorry
        have " for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<six>\<^sub>M implies  not VarFor1 inTARSKIR2 \<seven>\<^sub>M"
          using card_1_th_55 enumset1_def_5 sorry
        thus "(((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7"
          using A1 A3 A4 A5 A6 afinsq_1_def_3 A2 sorry
        have "p .FUNCT-1K1 \<seven>\<^sub>M =HIDDENR1 p .FUNCT-1K1 lenAFINSQ-1K2 (((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))"
          using afinsq_1_th_48 sorry
        also have "... = x8"
          using A1 afinsq_1_th_36 sorry
        finally show "p .FUNCT-1K1 \<seven>\<^sub>M =HIDDENR1 x8"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_50:
" for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds  for x9 be setHIDDENM2 holds p =FUNCT-1R1 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x9%>) implies ((((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<nine>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x9"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for x5 be setHIDDENM2 holds  for x6 be setHIDDENM2 holds  for x7 be setHIDDENM2 holds  for x8 be setHIDDENM2 holds  for x9 be setHIDDENM2 holds p =FUNCT-1R1 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x9%>) implies ((((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<nine>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x9"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix x5 assume [ty]: "x5 be setHIDDENM2"
    fix x6 assume [ty]: "x6 be setHIDDENM2"
    fix x7 assume [ty]: "x7 be setHIDDENM2"
    fix x8 assume [ty]: "x8 be setHIDDENM2"
    fix x9 assume [ty]: "x9 be setHIDDENM2"
    show "p =FUNCT-1R1 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x9%>) implies ((((((((lenAFINSQ-1K2 p =XBOOLE-0R4 \<nine>\<^sub>M & p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1) & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<eight>\<^sub>M =XBOOLE-0R4 x9"
    proof-
      have "p =FUNCT-1R1 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x9%>) implies lenAFINSQ-1K2 p =HIDDENR1 \<nine>\<^sub>M & ((((((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8) & p .FUNCT-1K1 \<eight>\<^sub>M =HIDDENR1 x9)"
      proof(rule impI,rule conjMI,rule conjMI)
        assume A1: "p =FUNCT-1R1 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x9%>)"
        let ?p17 = "(((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>)"
        have A2: "lenAFINSQ-1K2 ?p17 =XBOOLE-0R4 \<eight>\<^sub>M"
          using afinsq_1_th_49 sorry
        have A3: "?p17 .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & ?p17 .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2"
          using afinsq_1_th_49 sorry
        have A4: "?p17 .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3 & ?p17 .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4"
          using afinsq_1_th_49 sorry
        have A5: "?p17 .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5 & ?p17 .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6"
          using afinsq_1_th_49 sorry
        have A6: "?p17 .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7 & ?p17 .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8"
          using afinsq_1_th_49 sorry
        have "lenAFINSQ-1K2 p =HIDDENR1 lenAFINSQ-1K2 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>)) +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x9%>)"
          using A1 afinsq_1_def_3 sorry
        also have "... = \<eight>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A2 afinsq_1_th_33 sorry
        also have "... = \<nine>\<^sub>M"
           sorry
        finally show "lenAFINSQ-1K2 p =HIDDENR1 \<nine>\<^sub>M"
           sorry
        have " for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<seven>\<^sub>M implies  not VarFor1 inTARSKIR2 \<eight>\<^sub>M"
          using card_1_th_56 enumset1_def_6 sorry
        thus "((((((p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 x1 & p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x2) & p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x3) & p .FUNCT-1K1 \<three>\<^sub>M =XBOOLE-0R4 x4) & p .FUNCT-1K1 \<four>\<^sub>M =XBOOLE-0R4 x5) & p .FUNCT-1K1 \<five>\<^sub>M =XBOOLE-0R4 x6) & p .FUNCT-1K1 \<six>\<^sub>M =XBOOLE-0R4 x7) & p .FUNCT-1K1 \<seven>\<^sub>M =XBOOLE-0R4 x8"
          using A1 A3 A4 A5 A6 afinsq_1_def_3 A2 sorry
        have "p .FUNCT-1K1 \<eight>\<^sub>M =HIDDENR1 p .FUNCT-1K1 lenAFINSQ-1K2 ((((((((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x5%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x6%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x7%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x8%>))"
          using afinsq_1_th_49 sorry
        also have "... = x9"
          using A1 afinsq_1_th_36 sorry
        finally show "p .FUNCT-1K1 \<eight>\<^sub>M =HIDDENR1 x9"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_51:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n <XXREAL-0R3 lenAFINSQ-1K2 p implies (p ^AFINSQ-1K6 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
proof-
  have " for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n <XXREAL-0R3 lenAFINSQ-1K2 p implies (p ^AFINSQ-1K6 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume "n <XXREAL-0R3 lenAFINSQ-1K2 p"
    then have "n inTARSKIR2 domAFINSQ-1K3 p"
      using afinsq_1_lm_1 sorry
    thus "(p ^AFINSQ-1K6 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
      using afinsq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_52:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 n implies p  |RELAT-1K8 n =FUNCT-1R1 p"
proof-
  have " for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p <=XXREAL-0R1 n implies p  |RELAT-1K8 n =FUNCT-1R1 p"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    assume "lenAFINSQ-1K2 p <=XXREAL-0R1 n"
    then have "SegmCARD-1K5 lenAFINSQ-1K2 p c=ORDINAL1R1 SegmCARD-1K5 n"
      using nat_1_th_39 sorry
    thus "p  |RELAT-1K8 n =FUNCT-1R1 p"
      using relat_1_th_68 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_53:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 lenAFINSQ-1K2 p & k inTARSKIR2 n implies (p  |RELAT-1K8 n).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k & k inTARSKIR2 domAFINSQ-1K3 p"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 lenAFINSQ-1K2 p & k inTARSKIR2 n implies (p  |RELAT-1K8 n).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k & k inTARSKIR2 domAFINSQ-1K3 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    assume A1: "n <=XXREAL-0R1 lenAFINSQ-1K2 p"
      and A2: "k inTARSKIR2 n"
    have A3: "SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 lenAFINSQ-1K2 p"
      using A1 nat_1_th_39 sorry
    then have "n =HIDDENR1 domAFINSQ-1K3 p /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n"
      using xboole_1_th_28 sorry
    also have "... = domAFINSQ-1K3 (p  |RELAT-1K8 n)"
      using relat_1_th_61 sorry
    finally have "n =HIDDENR1 domAFINSQ-1K3 (p  |RELAT-1K8 n)"
       sorry
    thus "(p  |RELAT-1K8 n).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k & k inTARSKIR2 domAFINSQ-1K3 p"
      using A2 A3 funct_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_54:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 lenAFINSQ-1K2 p implies lenAFINSQ-1K2 (p  |RELAT-1K8 n) =XBOOLE-0R4 n"
proof-
  have " for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 lenAFINSQ-1K2 p implies lenAFINSQ-1K2 (p  |RELAT-1K8 n) =XBOOLE-0R4 n"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    assume "n <=XXREAL-0R1 lenAFINSQ-1K2 p"
    then have "SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 lenAFINSQ-1K2 p"
      using nat_1_th_39 sorry
    thus "lenAFINSQ-1K2 (p  |RELAT-1K8 n) =XBOOLE-0R4 n"
      using relat_1_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_55:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p  |RELAT-1K8 n) <=XXREAL-0R1 n"
proof-
  have " for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p  |RELAT-1K8 n) <=XXREAL-0R1 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    have "SegmCARD-1K5 lenAFINSQ-1K2 (p  |RELAT-1K8 n) c=ORDINAL1R1 SegmCARD-1K5 n"
      using relat_1_th_58 sorry
    thus "lenAFINSQ-1K2 (p  |RELAT-1K8 n) <=XXREAL-0R1 n"
      using nat_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_56:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)"
proof-
  have " for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    let ?pn = "p  |RELAT-1K8 n"
    let ?x = "p .FUNCT-1K1 n"
    assume A1: "lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
    then have A2: "n <XXREAL-0R3 lenAFINSQ-1K2 p"
      using nat_1_th_13 sorry
    then have A3: "lenAFINSQ-1K2 ?pn =XBOOLE-0R4 n"
      using afinsq_1_th_54 sorry
    have A4: " for m be NatNAT-1M1 holds m inTARSKIR2 domAFINSQ-1K3 p implies p .FUNCT-1K1 m =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "m inTARSKIR2 domAFINSQ-1K3 p"
      then have "m <XXREAL-0R3 lenAFINSQ-1K2 p"
        using afinsq_1_lm_1 sorry
      then have A5: "m <=XXREAL-0R1 lenAFINSQ-1K2 ?pn"
        using A1 A3 nat_1_th_13 sorry
      have "m =XBOOLE-0R4 lenAFINSQ-1K2 ?pn & p .FUNCT-1K1 m =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m or m <>HIDDENR2 lenAFINSQ-1K2 ?pn & (m <>HIDDENR2 lenAFINSQ-1K2 (p  |RELAT-1K8 n) implies (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m =HIDDENR1 p .FUNCT-1K1 m)"
      proof-
        show "m =XBOOLE-0R4 lenAFINSQ-1K2 ?pn & p .FUNCT-1K1 m =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m or m <>HIDDENR2 lenAFINSQ-1K2 ?pn & (m <>HIDDENR2 lenAFINSQ-1K2 (p  |RELAT-1K8 n) implies (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m =HIDDENR1 p .FUNCT-1K1 m)"
        proof-
          have cases: "m =XBOOLE-0R4 lenAFINSQ-1K2 ?pn or m <>HIDDENR2 lenAFINSQ-1K2 ?pn"
             sorry
          have case1: "m =XBOOLE-0R4 lenAFINSQ-1K2 (p  |RELAT-1K8 n) implies p .FUNCT-1K1 m =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m"
          proof(rule impI)
            assume "m =XBOOLE-0R4 lenAFINSQ-1K2 ?pn"
            thus "p .FUNCT-1K1 m =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m"
              using A3 afinsq_1_th_36 sorry
          qed
          have case2: "m <>HIDDENR2 lenAFINSQ-1K2 (p  |RELAT-1K8 n) implies (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m =HIDDENR1 p .FUNCT-1K1 m"
          proof(rule impI)
            assume "m <>HIDDENR2 lenAFINSQ-1K2 ?pn"
            then have "m <XXREAL-0R3 lenAFINSQ-1K2 ?pn"
              using A5 xxreal_0_th_1 sorry
            then have A6: "m inTARSKIR2 domAFINSQ-1K3 ?pn"
              using afinsq_1_lm_1 sorry
            then have "(p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m =HIDDENR1 (p  |RELAT-1K8 n).FUNCT-1K1 m"
              using afinsq_1_def_3 sorry
            also have "... = p .FUNCT-1K1 m"
              using A2 A3 A6 afinsq_1_th_53 sorry
            finally show "(p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m =HIDDENR1 p .FUNCT-1K1 m"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "p .FUNCT-1K1 m =XBOOLE-0R4 (p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)).FUNCT-1K1 m"
         sorry
    qed "sorry"
    have "lenAFINSQ-1K2 (?pn ^AFINSQ-1K6 (<%AFINSQ-1K7 ?x%>)) =HIDDENR1 n +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 ?x%>)"
      using A3 afinsq_1_def_3 sorry
    also have "... = lenAFINSQ-1K2 p"
      using A1 afinsq_1_def_4 sorry
    finally have "lenAFINSQ-1K2 (?pn ^AFINSQ-1K6 (<%AFINSQ-1K7 ?x%>)) =HIDDENR1 lenAFINSQ-1K2 p"
       sorry
    thus "p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 (<%AFINSQ-1K7 p .FUNCT-1K1 n%>)"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_57:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p =FUNCT-1R1 p"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds (p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p =FUNCT-1R1 p"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    let ?r = "(p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p"
    have A1: " for k be NatNAT-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p implies ((p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A2: "k <XXREAL-0R3 lenAFINSQ-1K2 p"
      have A3: "k inTARSKIR2 domAFINSQ-1K3 p"
        using A2 afinsq_1_lm_1 sorry
      then have A4: "(p ^AFINSQ-1K6 q).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
        using afinsq_1_def_3 sorry
      have "k +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
        using A2 xreal_1_th_8 sorry
      then have "k inTARSKIR2 SegmCARD-1K5 (lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q)"
        using nat_1_th_44 sorry
      then have "k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
        using afinsq_1_def_3 sorry
      then have "k inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domAFINSQ-1K3 p"
        using A3 xboole_0_def_4 sorry
      thus "((p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p).FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
        using A4 funct_1_th_48 sorry
    qed "sorry"
    have "domAFINSQ-1K3 p c=ORDINAL1R1 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
      using afinsq_1_th_21 sorry
    then have "lenAFINSQ-1K2 ?r =XBOOLE-0R4 lenAFINSQ-1K2 p"
      using relat_1_th_62 sorry
    thus "(p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p =FUNCT-1R1 p"
      using A1 afinsq_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_58:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 domAFINSQ-1K3 p implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p  |RELAT-1K8 n"
proof-
  have " for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n <=XXREAL-0R1 domAFINSQ-1K3 p implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p  |RELAT-1K8 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume "n <=XXREAL-0R1 domAFINSQ-1K3 p"
    then have "SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 lenAFINSQ-1K2 p"
      using nat_1_th_39 sorry
    then have "((p ^AFINSQ-1K6 q) |RELAT-1K8 domAFINSQ-1K3 p) |RELAT-1K8 n =FUNCT-1R1 (p ^AFINSQ-1K6 q) |RELAT-1K8 n"
      using relat_1_th_74 sorry
    thus "(p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p  |RELAT-1K8 n"
      using afinsq_1_th_57 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_59:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n =XBOOLE-0R4 domAFINSQ-1K3 p +XCMPLX-0K2 k implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds n =XBOOLE-0R4 domAFINSQ-1K3 p +XCMPLX-0K2 k implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume A1: "n =XBOOLE-0R4 domAFINSQ-1K3 p +XCMPLX-0K2 k"
    have "(p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
    proof-
      show "(p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
      proof-
        have cases: "n >=XXREAL-0R2 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) or n <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
           sorry
        have case1: "n >=XXREAL-0R2 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
        proof(rule impI)
          assume A2: "n >=XXREAL-0R2 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
          then have "n >=XXREAL-0R2 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
            using afinsq_1_def_3 sorry
          then have "k >=XXREAL-0R2 lenAFINSQ-1K2 q"
            using A1 xreal_1_th_8 sorry
          then have "SegmCARD-1K5 lenAFINSQ-1K2 q c=ORDINAL1R1 SegmCARD-1K5 k"
            using nat_1_th_39 sorry
          then have A3: "q  |RELAT-1K8 k =FUNCT-1R1 q"
            using relat_1_th_68 sorry
          have "SegmCARD-1K5 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) c=ORDINAL1R1 SegmCARD-1K5 n"
            using A2 nat_1_th_39 sorry
          thus "(p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
            using A3 relat_1_th_68 sorry
        qed
        have case2: "n <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) implies (p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
        proof(rule impI)
          assume A4: "n <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
          then have A5: "lenAFINSQ-1K2 ((p ^AFINSQ-1K6 q) |RELAT-1K8 n) =XBOOLE-0R4 n"
            using afinsq_1_th_11 sorry
          have "n <XXREAL-0R3 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
            using A4 afinsq_1_def_3 sorry
          then have "k <XXREAL-0R3 lenAFINSQ-1K2 q"
            using A1 xreal_1_th_6 sorry
          then have "lenAFINSQ-1K2 (q  |RELAT-1K8 k) =XBOOLE-0R4 k"
            using afinsq_1_th_11 sorry
          then have A6: "lenAFINSQ-1K2 (p ^AFINSQ-1K6 q  |RELAT-1K8 k) =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 k"
            using afinsq_1_def_3 sorry
          have " for m be NatNAT-1M1 holds m inTARSKIR2 domAFINSQ-1K3 ((p ^AFINSQ-1K6 q) |RELAT-1K8 n) implies ((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
          proof(rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A7: "m inTARSKIR2 domAFINSQ-1K3 ((p ^AFINSQ-1K6 q) |RELAT-1K8 n)"
            have A8: "m <XXREAL-0R3 lenAFINSQ-1K2 ((p ^AFINSQ-1K6 q) |RELAT-1K8 n)"
              using A7 afinsq_1_lm_1 sorry
            then have "m <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
              using A4 A5 xxreal_0_th_2 sorry
            then have A9: "m inTARSKIR2 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
              using afinsq_1_lm_1 sorry
            have "m inTARSKIR2 n"
              using A4 afinsq_1_th_11 A7 sorry
            then have A10: "m inTARSKIR2 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) /\\SUBSET-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n"
              using A9 xboole_0_def_4 sorry
            then have A11: "((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q).FUNCT-1K1 m"
              using funct_1_th_48 sorry
            have "((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
            proof-
              show "((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
              proof-
                have cases: "m <XXREAL-0R3 lenAFINSQ-1K2 p or m >=XXREAL-0R2 lenAFINSQ-1K2 p"
                   sorry
                have case1: "m <XXREAL-0R3 lenAFINSQ-1K2 p implies ((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
                proof(rule impI)
                  assume "m <XXREAL-0R3 lenAFINSQ-1K2 p"
                  then have "m inTARSKIR2 domAFINSQ-1K3 p"
                    using afinsq_1_lm_1 sorry
                  then have "(p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m =XBOOLE-0R4 p .FUNCT-1K1 m & (p ^AFINSQ-1K6 q).FUNCT-1K1 m =XBOOLE-0R4 p .FUNCT-1K1 m"
                    using afinsq_1_def_3 sorry
                  thus "((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
                    using A10 funct_1_th_48 sorry
                qed
                have case2: "m >=XXREAL-0R2 lenAFINSQ-1K2 p implies ((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
                proof(rule impI)
                  assume A12: "m >=XXREAL-0R2 lenAFINSQ-1K2 p"
                  have "m <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
                    using A4 A5 A8 xxreal_0_th_2 sorry
                  then have A13: "q .FUNCT-1K1 (m -XCMPLX-0K6 lenAFINSQ-1K2 p) =XBOOLE-0R4 (p ^AFINSQ-1K6 q).FUNCT-1K1 m"
                    using A12 afinsq_1_th_19 sorry
                  have A14: "(m -XCMPLX-0K6 lenAFINSQ-1K2 p)+XCMPLX-0K2 lenAFINSQ-1K2 p <XXREAL-0R3 lenAFINSQ-1K2 (p ^AFINSQ-1K6 q)"
                    using A4 A5 A8 xxreal_0_th_2 sorry
                  have A15: "m -XCMPLX-0K6 lenAFINSQ-1K2 p be NatNAT-1M1"
                    using A12 nat_1_th_21 sorry
                  have "lenAFINSQ-1K2 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 q"
                    using afinsq_1_def_3 sorry
                  then have "m -XCMPLX-0K6 lenAFINSQ-1K2 p <XXREAL-0R3 lenAFINSQ-1K2 q"
                    using A14 xreal_1_th_6 sorry
                  then have A16: "m -XCMPLX-0K6 lenAFINSQ-1K2 p inTARSKIR2 lenAFINSQ-1K2 q"
                    using A15 afinsq_1_lm_1 sorry
                  have "m -XCMPLX-0K6 lenAFINSQ-1K2 p <XXREAL-0R3 k"
                    using A1 A5 A14 A8 xreal_1_th_6 sorry
                  then have "m -XCMPLX-0K6 lenAFINSQ-1K2 p inTARSKIR2 SegmCARD-1K5 k"
                    using A15 nat_1_th_44 sorry
                  then have A17: "m -XCMPLX-0K6 lenAFINSQ-1K2 p inTARSKIR2 k /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domAFINSQ-1K3 q"
                    using A16 xboole_0_def_4 sorry
                  have "(p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m =XBOOLE-0R4 (q  |RELAT-1K8 k).FUNCT-1K1 (m -XCMPLX-0K6 lenAFINSQ-1K2 p)"
                    using A1 A6 A5 A12 A8 afinsq_1_th_19 sorry
                  thus "((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
                    using A11 A13 A17 funct_1_th_48 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "((p ^AFINSQ-1K6 q) |RELAT-1K8 n).FUNCT-1K1 m =XBOOLE-0R4 (p ^AFINSQ-1K6 q  |RELAT-1K8 k).FUNCT-1K1 m"
               sorry
          qed "sorry"
          thus "(p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
            using A6 A1 A4 afinsq_1_th_11 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(p ^AFINSQ-1K6 q) |RELAT-1K8 n =FUNCT-1R1 p ^AFINSQ-1K6 q  |RELAT-1K8 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_60:
" for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  ex q be XFinSequenceAFINSQ-1M1 st p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q"
proof-
  have " for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    have " not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
    proof-
      show " not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
      proof-
        have cases: "n >XXREAL-0R4 lenAFINSQ-1K2 p or n <=XXREAL-0R1 lenAFINSQ-1K2 p"
           sorry
        have case1: "n >XXREAL-0R4 lenAFINSQ-1K2 p implies  not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
        proof(rule impI)
          assume "n >XXREAL-0R4 lenAFINSQ-1K2 p"
          then have "SegmCARD-1K5 lenAFINSQ-1K2 p c=ORDINAL1R1 SegmCARD-1K5 n"
            using nat_1_th_39 sorry
          then have A1: "p  |RELAT-1K8 n =FUNCT-1R1 p"
            using relat_1_th_68 sorry
          have "p ^AFINSQ-1K6 {}XBOOLE-0K1 =FUNCT-1R1 p"
             sorry
          thus " not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
            using A1 sorry
        qed
        have case2: "n <=XXREAL-0R1 lenAFINSQ-1K2 p implies  not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
        proof(rule impI)
          assume "n <=XXREAL-0R1 lenAFINSQ-1K2 p"
          then obtain n1 where 
            [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and n1Def:"n1 = lenAFINSQ-1K2 p -XCMPLX-0K6 n"
            using nat_1_th_21 sorry
          let ?P = "\<lambda>Lamb1.  for k be NatNAT-1M1 holds k =XBOOLE-0R4 lenAFINSQ-1K2 p -XCMPLX-0K6 Lamb1 implies ( ex q be XFinSequenceAFINSQ-1M1 st p =FUNCT-1R1 p  |RELAT-1K8 k ^AFINSQ-1K6 q)"
          have A2: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for m be NatNAT-1M1 holds ( for k be NatNAT-1M1 holds k =XBOOLE-0R4 lenAFINSQ-1K2 p -XCMPLX-0K6 m implies ( ex q be XFinSequenceAFINSQ-1M1 st p =FUNCT-1R1 p  |RELAT-1K8 k ^AFINSQ-1K6 q)) implies ( for k be NatNAT-1M1 holds k =XBOOLE-0R4 lenAFINSQ-1K2 p -XCMPLX-0K6 (m +NAT-1K1 \<one>\<^sub>M) implies  not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 k ^AFINSQ-1K6 q))"
            proof(rule ballI,rule impI,rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume A3: "?P(m)"
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A4: "k =XBOOLE-0R4 lenAFINSQ-1K2 p -XCMPLX-0K6 (m +NAT-1K1 \<one>\<^sub>M)"
              obtain q where
                [ty]:"q be XFinSequenceAFINSQ-1M1" and 
                A5: "p =FUNCT-1R1 p  |RELAT-1K8 (k +NAT-1K1 \<one>\<^sub>M) ^AFINSQ-1K6 q"
                using A3 A4 sorry
              have "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_11 sorry
              then have "SegmCARD-1K5 k c=ORDINAL1R1 SegmCARD-1K5 (k +NAT-1K1 \<one>\<^sub>M)"
                using nat_1_th_39 sorry
              then have A6: "(p  |RELAT-1K8 (k +NAT-1K1 \<one>\<^sub>M)) |RELAT-1K8 k =FUNCT-1R1 p  |RELAT-1K8 k"
                using relat_1_th_74 sorry
              have "lenAFINSQ-1K2 p -XCMPLX-0K6 m <=XXREAL-0R1 lenAFINSQ-1K2 p -XCMPLX-0K6 0NUMBERSK6"
                using xreal_1_th_10 sorry
              then have "lenAFINSQ-1K2 (p  |RELAT-1K8 (k +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                using afinsq_1_th_54 A4 sorry
              then have "p  |RELAT-1K8 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 (p  |RELAT-1K8 (k +NAT-1K1 \<one>\<^sub>M)) |RELAT-1K8 k ^AFINSQ-1K6 (<%AFINSQ-1K7 (p  |RELAT-1K8 (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k%>)"
                using afinsq_1_th_56 sorry
              then have "p =FUNCT-1R1 p  |RELAT-1K8 k ^AFINSQ-1K6 ((<%AFINSQ-1K7 (p  |RELAT-1K8 (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k%>)^AFINSQ-1K6 q)"
                using A5 A6 afinsq_1_th_27 sorry
              thus " not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 k ^AFINSQ-1K6 q)"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have "p  |RELAT-1K8 (lenAFINSQ-1K2 p -XCMPLX-0K6 0NUMBERSK6) =FUNCT-1R1 p & p ^AFINSQ-1K6 {}XBOOLE-0K1 =FUNCT-1R1 p"
             sorry
          then have A7: "?P(0NUMBERSK6)"
             sorry
          have A8: " for m be NatNAT-1M1 holds ?P(m)"
            using nat_1_sch_2 A7 A2 sorry
          have "n =XBOOLE-0R4 lenAFINSQ-1K2 p -XCMPLX-0K6 n1"
             sorry
          thus " not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
            using A8 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for q be XFinSequenceAFINSQ-1M1 holds  not p =FUNCT-1R1 p  |RELAT-1K8 n ^AFINSQ-1K6 q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_61:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +XCMPLX-0K2 k implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be XFinSequenceAFINSQ-1M1 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 n & lenAFINSQ-1K2 q2 =XBOOLE-0R4 k) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds  not (lenAFINSQ-1K2 p =XBOOLE-0R4 n +XCMPLX-0K2 k & ( for q1 be XFinSequenceAFINSQ-1M1 holds  for q2 be XFinSequenceAFINSQ-1M1 holds  not ((lenAFINSQ-1K2 q1 =XBOOLE-0R4 n & lenAFINSQ-1K2 q2 =XBOOLE-0R4 k) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)))"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    let ?P = "\<lambda>Lamb1.  for p be XFinSequenceAFINSQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 Lamb1 & lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be XFinSequenceAFINSQ-1M1 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)"
    have A1: " for n be NatNAT-1M1 holds ( for p be XFinSequenceAFINSQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n & lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be XFinSequenceAFINSQ-1M1 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)) implies ( for p be XFinSequenceAFINSQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be XFinSequenceAFINSQ-1M1 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2))"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A2: "?P(n)"
      show " for p be XFinSequenceAFINSQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be XFinSequenceAFINSQ-1M1 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)"
      proof-
        have " for p be XFinSequenceAFINSQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be setHIDDENM2 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
          fix i assume [ty]: "i be NatNAT-1M1"
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A3: "lenAFINSQ-1K2 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
            and A4: "lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j"
          show " ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be setHIDDENM2 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2"
          proof-
            have cases: "j =XBOOLE-0R4 0NUMBERSK6 or j >XXREAL-0R4 0NUMBERSK6"
               sorry
            have case1: "j =XBOOLE-0R4 0NUMBERSK6 implies ( ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be setHIDDENM2 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)"
            proof(rule impI)
              assume A5: "j =XBOOLE-0R4 0NUMBERSK6"
              obtain q1 where 
                [ty]:"q1 be XFinSequenceAFINSQ-1M1" and q1Def:"q1 = p"
                 sorry
              show " ex q1 be XFinSequenceAFINSQ-1M1 st  ex q2 be setHIDDENM2 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2"
              proof(rule bexI[of _ "q1"])
                obtain q2 where 
                  [ty]:"q2 be setHIDDENM2" and q2Def:"q2 = {}XBOOLE-0K1"
                   sorry
                show " ex q2 be setHIDDENM2 st (lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2"
                proof(rule bexI[of _ "q2"])
                  show "(lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2"
                    using A4 A5 sorry
                qed "sorry"
              qed "sorry"
            qed
            have case2: "j >XXREAL-0R4 0NUMBERSK6 implies  not ( for q1 be XFinSequenceAFINSQ-1M1 holds  for q2 be XFinSequenceAFINSQ-1M1 holds  not ((lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2))"
            proof(rule impI)
              assume "j >XXREAL-0R4 0NUMBERSK6"
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A6: "j =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_6 sorry
              have "p <>HIDDENR2 {}XBOOLE-0K1"
                using A3 sorry
              then obtain q x where
                [ty]:"q be XFinSequenceAFINSQ-1M1" "x be objectHIDDENM1" and 
                A7: "p =FUNCT-1R1 q ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)"
                using afinsq_1_th_40 sorry
              have A8: "n +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenAFINSQ-1K2 q +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>)"
                using A3 A7 afinsq_1_def_3 sorry
              also have "... = lenAFINSQ-1K2 q +NAT-1K1 \<one>\<^sub>M"
                using afinsq_1_th_33 sorry
              finally have "n +NAT-1K1 \<one>\<^sub>M =HIDDENR1 lenAFINSQ-1K2 q +NAT-1K1 \<one>\<^sub>M"
                 sorry
              have "n =XBOOLE-0R4 i +XCMPLX-0K2 k"
                using A3 A4 A6 sorry
              then obtain q1 q2 where
                [ty]:"q1 be XFinSequenceAFINSQ-1M1" "q2 be XFinSequenceAFINSQ-1M1" and 
                A9: "lenAFINSQ-1K2 q1 =XBOOLE-0R4 i"and A10: "lenAFINSQ-1K2 q2 =XBOOLE-0R4 k"and A11: "q =FUNCT-1R1 q1 ^AFINSQ-1K6 q2"
                using A2 A8 sorry
              have A12: "lenAFINSQ-1K2 (q2 ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =HIDDENR1 lenAFINSQ-1K2 q2 +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>)"
                using afinsq_1_def_3 sorry
              also have "... = j"
                using A6 A10 afinsq_1_th_33 sorry
              finally have "lenAFINSQ-1K2 (q2 ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =HIDDENR1 j"
                 sorry
              have "p =FUNCT-1R1 q1 ^AFINSQ-1K6 (q2 ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>))"
                using A7 A11 afinsq_1_th_27 sorry
              thus " not ( for q1 be XFinSequenceAFINSQ-1M1 holds  for q2 be XFinSequenceAFINSQ-1M1 holds  not ((lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2))"
                using A9 A12 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed "sorry"
    have A13: "?P(0NUMBERSK6)"
    proof-
      have " for p be XFinSequenceAFINSQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds lenAFINSQ-1K2 p =XBOOLE-0R4 0NUMBERSK6 & lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j implies  not ( for q1 be XFinSequenceAFINSQ-1M1 holds  for q2 be XFinSequenceAFINSQ-1M1 holds  not ((lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2))"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
        fix i assume [ty]: "i be NatNAT-1M1"
        fix j assume [ty]: "j be NatNAT-1M1"
        assume A14: "lenAFINSQ-1K2 p =XBOOLE-0R4 0NUMBERSK6"
          and A15: "lenAFINSQ-1K2 p =XBOOLE-0R4 i +XCMPLX-0K2 j"
        have "p =FUNCT-1R1 {}XBOOLE-0K1"
          using A14 sorry
        then have A16: "p =FUNCT-1R1 {}XBOOLE-0K1 ^AFINSQ-1K6 {}XBOOLE-0K1"
           sorry
        have "lenAFINSQ-1K2 ({}XBOOLE-0K1) =XBOOLE-0R4 i"
          using A14 A15 sorry
        thus " not ( for q1 be XFinSequenceAFINSQ-1M1 holds  for q2 be XFinSequenceAFINSQ-1M1 holds  not ((lenAFINSQ-1K2 q1 =XBOOLE-0R4 i & lenAFINSQ-1K2 q2 =XBOOLE-0R4 j) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2))"
          using A15 A16 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A13 A1 sorry
    thus " not (lenAFINSQ-1K2 p =XBOOLE-0R4 n +XCMPLX-0K2 k & ( for q1 be XFinSequenceAFINSQ-1M1 holds  for q2 be XFinSequenceAFINSQ-1M1 holds  not ((lenAFINSQ-1K2 q1 =XBOOLE-0R4 n & lenAFINSQ-1K2 q2 =XBOOLE-0R4 k) & p =FUNCT-1R1 q1 ^AFINSQ-1K6 q2)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_62:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds (<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p =FUNCT-1R1 (<%AFINSQ-1K7 y%>)^AFINSQ-1K6 q implies x =HIDDENR1 y & p =FUNCT-1R1 q"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds (<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p =FUNCT-1R1 (<%AFINSQ-1K7 y%>)^AFINSQ-1K6 q implies x =HIDDENR1 y & p =FUNCT-1R1 q"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    assume A1: "(<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p =FUNCT-1R1 (<%AFINSQ-1K7 y%>)^AFINSQ-1K6 q"
    have "((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 p).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
      using afinsq_1_th_35 sorry
    then have "x =HIDDENR1 y"
      using A1 afinsq_1_th_35 sorry
    thus "x =HIDDENR1 y & p =FUNCT-1R1 q"
      using A1 afinsq_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef afinsq_1_def_8 ("FS2XFSAFINSQ-1K12\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be setHIDDENM2", "q be FinSequenceFINSEQ-1M3-of D"
"func FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q \<rightarrow> XFinSequenceAFINSQ-1M2-of D means
  \<lambda>it. lenAFINSQ-1K2 it =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be XFinSequenceAFINSQ-1M2-of D st lenAFINSQ-1K2 it =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
    proof-
      have " not ( for VarFor1 be XFinSequenceAFINSQ-1M2-of D holds  not (lenAFINSQ-1K2 VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 q &  not q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 VarFor1 .FUNCT-1K1 i))))"
      proof-
        let ?F = "\<lambda>Lamb1. q .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
        have " ex p be XFinSequenceAFINSQ-1M1 st lenAFINSQ-1K2 p =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 lenFINSEQ-1K4 q implies p .FUNCT-1K1 k =XBOOLE-0R4 ?F(k))"
          using afinsq_1_sch_2 sorry
        then obtain p where
          [ty]:"p be XFinSequenceAFINSQ-1M1" and 
          A1: "lenAFINSQ-1K2 p =XBOOLE-0R4 lenFINSEQ-1K4 q"and A2: " for k be NatNAT-1M1 holds k inTARSKIR2 SegmCARD-1K5 lenFINSEQ-1K4 q implies p .FUNCT-1K1 k =XBOOLE-0R4 ?F(k)"
           sorry
        have "rngFUNCT-1K2 p c=TARSKIR1 D"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 p implies y inHIDDENR3 D"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            have A3: "rngFUNCT-1K2 q c=TARSKIR1 D"
              using finseq_1_def_4 sorry
            assume "y inHIDDENR3 rngFUNCT-1K2 p"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A4: "x inHIDDENR3 domAFINSQ-1K3 p"and A5: "y =HIDDENR1 p .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            obtain nx where 
              [ty]:"nx be ElementSUBSET-1M1-of NATNUMBERSK1" and nxDef:"nx = x"
              using A4 sorry
            have "nx <XXREAL-0R3 lenFINSEQ-1K4 q"
              using A1 A4 afinsq_1_lm_1 sorry
            then have A6: "nx +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 q"
              using nat_1_th_13 sorry
            have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 nx +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            then have "nx +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
              using A6 finseq_1_th_1 sorry
            then have "nx +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 q"
              using finseq_1_def_3 sorry
            then have A7: "q .FUNCT-1K1 (nx +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 q"
              using funct_1_def_3 sorry
            have "p .FUNCT-1K1 nx =XBOOLE-0R4 q .FUNCT-1K1 (nx +NAT-1K1 \<one>\<^sub>M)"
              using A1 A2 A4 sorry
            thus "y inHIDDENR3 D"
              using A5 A7 A3 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 p c=TARSKIR1 D"
            using tarski_def_3 sorry
        qed
        then have A8: "p be XFinSequenceAFINSQ-1M2-of D"
          using relat_1_def_19 sorry
        have " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 i"
          using A2 nat_1_th_44 sorry
        thus " not ( for VarFor1 be XFinSequenceAFINSQ-1M2-of D holds  not (lenAFINSQ-1K2 VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds  not ( not i <XXREAL-0R3 lenFINSEQ-1K4 q &  not q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 VarFor1 .FUNCT-1K1 i))))"
          using A1 A8 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be XFinSequenceAFINSQ-1M2-of D holds  for it2 be XFinSequenceAFINSQ-1M2-of D holds (lenAFINSQ-1K2 it1 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it1 .FUNCT-1K1 i)) & (lenAFINSQ-1K2 it2 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 it2 .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
    proof-
      have " for p1 be XFinSequenceAFINSQ-1M2-of D holds  for p2 be XFinSequenceAFINSQ-1M2-of D holds (lenAFINSQ-1K2 p1 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i)) & (lenAFINSQ-1K2 p2 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i)) implies p1 =FUNCT-1R1 p2"
      proof-
        show " for p1 be XFinSequenceAFINSQ-1M2-of D holds  for p2 be XFinSequenceAFINSQ-1M2-of D holds (lenAFINSQ-1K2 p1 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i)) & (lenAFINSQ-1K2 p2 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i)) implies p1 =FUNCT-1R1 p2"
        proof-
          have " for p1 be XFinSequenceAFINSQ-1M2-of D holds  for p2 be XFinSequenceAFINSQ-1M2-of D holds lenAFINSQ-1K2 p1 =XBOOLE-0R4 lenFINSEQ-1K4 q & (( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i) & (lenAFINSQ-1K2 p2 =XBOOLE-0R4 lenFINSEQ-1K4 q & ( for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i))) implies p1 =FUNCT-1R1 p2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
            fix p1 assume [ty]: "p1 be XFinSequenceAFINSQ-1M2-of D"
            fix p2 assume [ty]: "p2 be XFinSequenceAFINSQ-1M2-of D"
            assume A9: "lenAFINSQ-1K2 p1 =XBOOLE-0R4 lenFINSEQ-1K4 q"
              and A10: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i"
              and A11: "lenAFINSQ-1K2 p2 =XBOOLE-0R4 lenFINSEQ-1K4 q"
              and A12: " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 q implies q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i"
            have " for i be NatNAT-1M1 holds i <XXREAL-0R3 lenAFINSQ-1K2 p1 implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A13: "i <XXREAL-0R3 lenAFINSQ-1K2 p1"
              then have "q .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i"
                using A9 A10 sorry
              thus "p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                using A9 A12 A13 sorry
            qed "sorry"
            thus "p1 =FUNCT-1R1 p2"
              using A9 A11 afinsq_1_th_9 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

reserve i for "NatNAT-1M1"
mdef afinsq_1_def_9 ("XFS2FSAFINSQ-1K13\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be setHIDDENM2", "q be XFinSequenceAFINSQ-1M2-of D"
"func XFS2FSAFINSQ-1K13\<^bsub>(D)\<^esub> q \<rightarrow> FinSequenceFINSEQ-1M3-of D means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of D st lenFINSEQ-1K4 it =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it .FUNCT-1K1 i)"
    proof-
      have " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of D holds  not (lenFINSEQ-1K4 VarFor1 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q) &  not q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 VarFor1 .FUNCT-1K1 i))))"
      proof-
        let ?F = "\<lambda>Lamb1. q .FUNCT-1K1 (Lamb1 -'NAT-DK9 \<one>\<^sub>M)"
        have " ex p be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 p =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 ?F(k))"
          using finseq_1_sch_2 sorry
        then obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M1" and 
          A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenAFINSQ-1K2 q"and A2: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 ?F(k)"
           sorry
        have "rngFUNCT-1K2 p c=TARSKIR1 D"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 p implies y inHIDDENR3 D"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            have A3: "rngFUNCT-1K2 q c=TARSKIR1 D"
              using relat_1_def_19 sorry
            assume "y inHIDDENR3 rngFUNCT-1K2 p"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A4: "x inHIDDENR3 domFINSEQ-1K5 p"and A5: "y =HIDDENR1 p .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            obtain nx where 
              [ty]:"nx be ElementSUBSET-1M1-of NATNUMBERSK1" and nxDef:"nx = x"
              using A4 sorry
            have A6: "nx inTARSKIR2 SegFINSEQ-1K2 (lenAFINSQ-1K2 q)"
              using A1 A4 finseq_1_def_3 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 nx"
              using finseq_1_th_1 sorry
            then have "nx -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
              using xreal_1_th_48 sorry
            then have A7: "nx -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 nx -'NAT-DK9 \<one>\<^sub>M"
              using xreal_0_def_2 sorry
            have A8: "nx -'NAT-DK9 \<one>\<^sub>M <XXREAL-0R3 (nx -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            have "nx <=XXREAL-0R1 lenAFINSQ-1K2 q"
              using A6 finseq_1_th_1 sorry
            then have "nx -'NAT-DK9 \<one>\<^sub>M <XXREAL-0R3 lenAFINSQ-1K2 q"
              using A7 A8 xxreal_0_th_2 sorry
            then have "nx -'NAT-DK9 \<one>\<^sub>M inTARSKIR2 domAFINSQ-1K3 q"
              using afinsq_1_lm_1 sorry
            then have A9: "q .FUNCT-1K1 (nx -'NAT-DK9 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 q"
              using funct_1_def_3 sorry
            have "p .FUNCT-1K1 nx =XBOOLE-0R4 q .FUNCT-1K1 (nx -'NAT-DK9 \<one>\<^sub>M)"
              using A2 A4 sorry
            thus "y inHIDDENR3 D"
              using A5 A9 A3 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 p c=TARSKIR1 D"
            using tarski_def_3 sorry
        qed
        then have A10: "p be FinSequenceFINSEQ-1M3-of D"
          using finseq_1_def_4 sorry
        have A11: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenAFINSQ-1K2 q)"
          using A1 finseq_1_def_3 sorry
        have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 i"
          using A2 A11 finseq_1_th_1 sorry
        thus " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of D holds  not (lenFINSEQ-1K4 VarFor1 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q) &  not q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 VarFor1 .FUNCT-1K1 i))))"
          using A1 A10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of D holds  for it2 be FinSequenceFINSEQ-1M3-of D holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it1 .FUNCT-1K1 i)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 it2 .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
    proof-
      have " for p1 be FinSequenceFINSEQ-1M3-of D holds  for p2 be FinSequenceFINSEQ-1M3-of D holds (lenFINSEQ-1K4 p1 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i)) & (lenFINSEQ-1K4 p2 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i)) implies p1 =FINSEQ-1R1 p2"
      proof-
        show " for p1 be FinSequenceFINSEQ-1M3-of D holds  for p2 be FinSequenceFINSEQ-1M3-of D holds (lenFINSEQ-1K4 p1 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i)) & (lenFINSEQ-1K4 p2 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i)) implies p1 =FINSEQ-1R1 p2"
        proof-
          have " for p1 be FinSequenceFINSEQ-1M3-of D holds  for p2 be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 p1 =XBOOLE-0R4 lenAFINSQ-1K2 q & (( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i) & (lenFINSEQ-1K4 p2 =XBOOLE-0R4 lenAFINSQ-1K2 q & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i))) implies p1 =FINSEQ-1R1 p2"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
            fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M3-of D"
            fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M3-of D"
            assume A12: "lenFINSEQ-1K4 p1 =XBOOLE-0R4 lenAFINSQ-1K2 q"
              and A13: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i"
              and A14: "lenFINSEQ-1K4 p2 =XBOOLE-0R4 lenAFINSQ-1K2 q"
              and A15: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenAFINSQ-1K2 q implies q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p2 .FUNCT-1K1 i"
            have " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 p1 implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A16: "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 p1"
              then have "q .FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M) =XBOOLE-0R4 p1 .FUNCT-1K1 i"
                using A12 A13 sorry
              thus "p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                using A12 A15 A16 sorry
            qed "sorry"
            thus "p1 =FINSEQ-1R1 p2"
              using A12 A14 finseq_1_th_14 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem afinsq_1_th_63:
" for D be setHIDDENM2 holds  for n be NatNAT-1M1 holds  for r be setHIDDENM2 holds r inTARSKIR2 D implies n -->FUNCOP-1K7 r be XFinSequenceAFINSQ-1M2-of D"
   sorry

mdef afinsq_1_def_10 ("FS2XFS*AFINSQ-1K14\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "q be FinSequenceFINSEQ-1M3-of D", "n be NatNAT-1M1"
"assume n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D func FS2XFS*AFINSQ-1K14\<^bsub>(D)\<^esub>(q,n) \<rightarrow>  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D means
  \<lambda>it. ((lenFINSEQ-1K4 q =XBOOLE-0R4 it .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)"
proof-
  (*existence*)
    show "n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D implies ( ex it be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D st ((lenFINSEQ-1K4 q =XBOOLE-0R4 it .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6))"
    proof(rule impI)
      assume Assume: "n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D"
      have A1: "n >XXREAL-0R4 lenFINSEQ-1K4 q"
        using Assume sorry
      have A2: "NATNUMBERSK1 c=TARSKIR1 D"
        using Assume sorry
      show " ex it be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D st ((lenFINSEQ-1K4 q =XBOOLE-0R4 it .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)"
      proof-
        have " not ( for VarFor1 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds  not (((lenFINSEQ-1K4 q =XBOOLE-0R4 VarFor1 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 VarFor1 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q) &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i))) & ( for j be NatNAT-1M1 holds  not (( not lenFINSEQ-1K4 q <XXREAL-0R3 j &  not j <XXREAL-0R3 n) &  not VarFor1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6))))"
        proof-
          obtain x where 
            [ty]:"x be ElementSUBSET-1M1-of D" and xDef:"x = lenFINSEQ-1K4 q"
            using A2 sorry
          obtain r where 
            [ty]:"r be ElementSUBSET-1M1-of D" and rDef:"r = 0NUMBERSK6"
            using A2 sorry
          obtain q5 where 
            [ty]:"q5 be XFinSequenceAFINSQ-1M2-of D" and q5Def:"q5 = (n -'NAT-DK9 lenFINSEQ-1K4 q)-'NAT-DK9 \<one>\<^sub>M -->FUNCOP-1K8\<^bsub>(D)\<^esub> r"
             sorry
          have "(<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q) <>HIDDENR2 {}XBOOLE-0K1"
            using afinsq_1_th_30 sorry
          then obtain p0 where 
            [ty]:"p0 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D" and p0Def:"p0 = ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q))^AFINSQ-1K6 q5"
            using afinsq_1_th_30 sorry
          have "0NUMBERSK6 <XXREAL-0R3 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>)"
             sorry
          then have A3: "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 x%>)"
            using afinsq_1_lm_1 sorry
          have A4: "lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) =XBOOLE-0R4 \<one>\<^sub>M"
            using afinsq_1_def_4 sorry
          have "0NUMBERSK6 inTARSKIR2 SegmCARD-1K5 (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q))"
            using nat_1_th_44 sorry
          then have "0NUMBERSK6 inTARSKIR2 lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q))"
            using afinsq_1_def_3 sorry
          then have A5: "p0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)).FUNCT-1K1 (0NUMBERSK6)"
            using afinsq_1_def_3 sorry
          also have "... = (<%AFINSQ-1K7 x%>).FUNCT-1K1 (0NUMBERSK6)"
            using A3 afinsq_1_def_3 sorry
          also have "... = x"
             sorry
          finally have "p0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
             sorry
          have A6: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p0 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
          proof(rule ballI,rule impMI ,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A7: "\<one>\<^sub>M <=XXREAL-0R1 i"
              and A8: "i <=XXREAL-0R1 lenFINSEQ-1K4 q"
            have "i -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
              using A7 xreal_1_th_48 sorry
            then have A9: "i -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 i -XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_0_def_2 sorry
            have "i <XXREAL-0R3 i +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            then have "i -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_9 sorry
            then have A10: "i -'NAT-DK9 \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 q"
              using A8 A9 xxreal_0_th_2 sorry
            then have "i -'NAT-DK9 \<one>\<^sub>M inTARSKIR2 SegmCARD-1K5 lenFINSEQ-1K4 q"
              using nat_1_th_44 sorry
            then have A11: "i -'NAT-DK9 \<one>\<^sub>M inTARSKIR2 lenAFINSQ-1K2 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)"
              using afinsq_1_def_8 sorry
            have "i <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q"
              using A8 nat_1_th_13 sorry
            then have "i <XXREAL-0R3 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)"
              using A4 afinsq_1_def_8 sorry
            then have "i inTARSKIR2 SegmCARD-1K5 (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q))"
              using nat_1_th_44 sorry
            then have "i inTARSKIR2 lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q))"
              using afinsq_1_def_3 sorry
            then have "p0 .FUNCT-1K1 i =HIDDENR1 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)).FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 (i -'NAT-DK9 \<one>\<^sub>M))"
              using A9 afinsq_1_def_3 sorry
            also have "... = (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q).FUNCT-1K1 (i -'NAT-DK9 \<one>\<^sub>M)"
              using A4 A11 afinsq_1_def_3 sorry
            also have "... = q .FUNCT-1K1 ((i -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
              using A10 afinsq_1_def_8 sorry
            also have "... = q .FUNCT-1K1 i"
              using A9 sorry
            finally have "p0 .FUNCT-1K1 i =HIDDENR1 q .FUNCT-1K1 i"
               sorry
            thus "p0 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
               sorry
          qed "sorry"
          have A12: "n -XCMPLX-0K6 lenFINSEQ-1K4 q >XXREAL-0R4 0NUMBERSK6"
            using A1 xreal_1_th_50 sorry
          then have A13: "n -'NAT-DK9 lenFINSEQ-1K4 q =XBOOLE-0R4 n -XCMPLX-0K6 lenFINSEQ-1K4 q"
            using xreal_0_def_2 sorry
          then have "n -'NAT-DK9 lenFINSEQ-1K4 q >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
            using A12 nat_1_th_13 sorry
          then have A14: "(n -'NAT-DK9 lenFINSEQ-1K4 q)-XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
            using xreal_1_th_48 sorry
          have A15: "lenAFINSQ-1K2 q5 =XBOOLE-0R4 (n -'NAT-DK9 lenFINSEQ-1K4 q)-'NAT-DK9 \<one>\<^sub>M"
            using funcop_1_th_13 sorry
          have A16: " for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies p0 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6"
          proof(rule ballI,rule impMI ,rule impI)
            fix j assume [ty]: "j be NatNAT-1M1"
            assume A17: "lenFINSEQ-1K4 q <XXREAL-0R3 j"
              and A18: "j <XXREAL-0R3 n"
            have A19: "lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)) =HIDDENR1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)"
              using afinsq_1_def_3 sorry
            also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q"
              using A4 afinsq_1_def_8 sorry
            finally have "lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q"
               sorry
            have "lenFINSEQ-1K4 q <XXREAL-0R3 n"
              using A17 A18 xxreal_0_th_2 sorry
            then have A20: "n -XCMPLX-0K6 lenFINSEQ-1K4 q >XXREAL-0R4 0NUMBERSK6"
              using xreal_1_th_50 sorry
            then have A21: "n -'NAT-DK9 lenFINSEQ-1K4 q =XBOOLE-0R4 n -XCMPLX-0K6 lenFINSEQ-1K4 q"
              using xreal_0_def_2 sorry
            then have "n -XCMPLX-0K6 lenFINSEQ-1K4 q >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using A20 nat_1_th_13 sorry
            then have "(n -'NAT-DK9 lenFINSEQ-1K4 q)-XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
              using A21 xreal_1_th_48 sorry
            then have A22: "(n -'NAT-DK9 lenFINSEQ-1K4 q)-'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 n -XCMPLX-0K6 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
              using A21 xreal_0_def_2 sorry
            have "\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q <=XXREAL-0R1 j"
              using A17 nat_1_th_13 sorry
            then have "j -XCMPLX-0K6 (\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q) >=XXREAL-0R2 0NUMBERSK6"
              using xreal_1_th_48 sorry
            then have A23: "j -'NAT-DK9 (\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q) =XBOOLE-0R4 j -XCMPLX-0K6 (\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q)"
              using xreal_0_def_2 sorry
            have "j -XCMPLX-0K6 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 n -XCMPLX-0K6 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
              using A18 xreal_1_th_9 sorry
            then have A24: "j -'NAT-DK9 lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)) inTARSKIR2 SegmCARD-1K5 ((n -'NAT-DK9 lenFINSEQ-1K4 q)-'NAT-DK9 \<one>\<^sub>M)"
              using A19 A23 A22 nat_1_th_44 sorry
            have "j =XBOOLE-0R4 lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)) +NAT-1K1 (j -'NAT-DK9 lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)))"
              using A19 A23 sorry
            then have "p0 .FUNCT-1K1 j =HIDDENR1 q5 .FUNCT-1K1 (j -'NAT-DK9 lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)))"
              using A15 A24 afinsq_1_def_3 sorry
            also have "... = 0NUMBERSK6"
              using A24 funcop_1_th_7 sorry
            finally have "p0 .FUNCT-1K1 j =HIDDENR1 0NUMBERSK6"
               sorry
            thus "p0 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6"
               sorry
          qed "sorry"
          have "lenAFINSQ-1K2 p0 =HIDDENR1 lenAFINSQ-1K2 ((<%AFINSQ-1K7 x%>)^AFINSQ-1K6 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q)) +NAT-1K1 lenAFINSQ-1K2 q5"
            using afinsq_1_def_3 sorry
          also have "... = (lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>) +NAT-1K1 lenAFINSQ-1K2 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q))+NAT-1K1 lenAFINSQ-1K2 q5"
            using afinsq_1_def_3 sorry
          also have "... = (\<one>\<^sub>M +NAT-1K1 lenAFINSQ-1K2 (FS2XFSAFINSQ-1K12\<^bsub>(D)\<^esub> q))+NAT-1K1 lenAFINSQ-1K2 q5"
            using afinsq_1_th_33 sorry
          also have "... = (\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q)+NAT-1K1 lenAFINSQ-1K2 q5"
            using afinsq_1_def_8 sorry
          also have "... = (\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q)+NAT-1K1 ((n -'NAT-DK9 lenFINSEQ-1K4 q)-'NAT-DK9 \<one>\<^sub>M)"
            using funcop_1_th_13 sorry
          also have "... = (n -XCMPLX-0K6 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M)"
            using A13 A14 xreal_0_def_2 sorry
          also have "... = n"
             sorry
          finally have "lenAFINSQ-1K2 p0 =HIDDENR1 n"
             sorry
          thus " not ( for VarFor1 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds  not (((lenFINSEQ-1K4 q =XBOOLE-0R4 VarFor1 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 VarFor1 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q) &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i))) & ( for j be NatNAT-1M1 holds  not (( not lenFINSEQ-1K4 q <XXREAL-0R3 j &  not j <XXREAL-0R3 n) &  not VarFor1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6))))"
            using A5 A6 A16 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D implies ( for it1 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds  for it2 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds (((lenFINSEQ-1K4 q =XBOOLE-0R4 it1 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it1 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)) & (((lenFINSEQ-1K4 q =XBOOLE-0R4 it2 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it2 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it2 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it2 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "n >XXREAL-0R4 lenFINSEQ-1K4 q & NATNUMBERSK1 c=TARSKIR1 D"
      have A1: "n >XXREAL-0R4 lenFINSEQ-1K4 q"
        using Assume sorry
      have A2: "NATNUMBERSK1 c=TARSKIR1 D"
        using Assume sorry
      show " for it1 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds  for it2 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds (((lenFINSEQ-1K4 q =XBOOLE-0R4 it1 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it1 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)) & (((lenFINSEQ-1K4 q =XBOOLE-0R4 it2 .FUNCT-1K1 (0NUMBERSK6) & lenAFINSQ-1K2 it2 =XBOOLE-0R4 n) & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies it2 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i)) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies it2 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6)) implies it1 =HIDDENR1 it2"
      proof-
        have " for p1 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds  for p2 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D holds lenFINSEQ-1K4 q =XBOOLE-0R4 p1 .FUNCT-1K1 (0NUMBERSK6) & (lenAFINSQ-1K2 p1 =XBOOLE-0R4 n & (( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i) & (( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies p1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6) & (lenFINSEQ-1K4 q =XBOOLE-0R4 p2 .FUNCT-1K1 (0NUMBERSK6) & (lenAFINSQ-1K2 p2 =XBOOLE-0R4 n & (( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p2 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i) & ( for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies p2 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6))))))) implies p1 =HIDDENR1 p2"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix p1 assume [ty]: "p1 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D"
          fix p2 assume [ty]: "p2 be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M2-of D"
          assume A25: "lenFINSEQ-1K4 q =XBOOLE-0R4 p1 .FUNCT-1K1 (0NUMBERSK6)"
            and A26: "lenAFINSQ-1K2 p1 =XBOOLE-0R4 n"
            and A27: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
            and A28: " for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies p1 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6"
            and A29: "lenFINSEQ-1K4 q =XBOOLE-0R4 p2 .FUNCT-1K1 (0NUMBERSK6)"
            and A30: "lenAFINSQ-1K2 p2 =XBOOLE-0R4 n"
            and A31: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p2 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
            and A32: " for j be NatNAT-1M1 holds lenFINSEQ-1K4 q <XXREAL-0R3 j & j <XXREAL-0R3 n implies p2 .FUNCT-1K1 j =XBOOLE-0R4 0NUMBERSK6"
          have " for i be NatNAT-1M1 holds i <XXREAL-0R3 n implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume "i <XXREAL-0R3 n"
            then have A33: "(i <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M or \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q) or lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n"
               sorry
            have "(i =XBOOLE-0R4 0NUMBERSK6 & p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i or (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q) & (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i)) or (lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n) & (lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i)"
            proof-
              show "(i =XBOOLE-0R4 0NUMBERSK6 & p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i or (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q) & (\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i)) or (lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n) & (lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i)"
              proof-
                have cases: "(i =XBOOLE-0R4 0NUMBERSK6 or \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q) or lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n"
                  using A33 nat_1_th_13 sorry
                have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                proof(rule impI)
                  assume "i =XBOOLE-0R4 0NUMBERSK6"
                  thus "p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                    using A25 A29 sorry
                qed
                have case2: "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                proof(rule impI)
                  assume A34: "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 q"
                  then have "p1 .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
                    using A27 sorry
                  thus "p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                    using A31 A34 sorry
                qed
                have case3: "lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n implies p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                proof(rule impI)
                  assume A35: "lenFINSEQ-1K4 q <XXREAL-0R3 i & i <XXREAL-0R3 n"
                  then have "p1 .FUNCT-1K1 i =XBOOLE-0R4 0NUMBERSK6"
                    using A28 sorry
                  thus "p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
                    using A32 A35 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 sorry
              qed
            qed
            thus "p1 .FUNCT-1K1 i =XBOOLE-0R4 p2 .FUNCT-1K1 i"
               sorry
          qed "sorry"
          thus "p1 =HIDDENR1 p2"
            using A26 A30 afinsq_1_th_9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

reserve m for "NatNAT-1M1"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
mdef afinsq_1_def_11 ("XFS2FS*AFINSQ-1K15\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be XFinSequenceAFINSQ-1M2-of D"
"assume p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p func XFS2FS*AFINSQ-1K15\<^bsub>(D)\<^esub> p \<rightarrow> FinSequenceFINSEQ-1M3-of D means
  \<lambda>it.  for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)"
proof-
  (*existence*)
    show "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p implies ( ex it be FinSequenceFINSEQ-1M3-of D st  for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i))"
    proof(rule impI)
      assume Assume: "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p"
      have A1: "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1"
        using Assume sorry
      have A2: "p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p"
        using Assume sorry
      show " ex it be FinSequenceFINSEQ-1M3-of D st  for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)"
      proof-
        have " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of D holds  not ( for m be NatNAT-1M1 holds  not (m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) &  not (lenFINSEQ-1K4 VarFor1 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m) &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i))))))"
        proof-
          obtain m0 where 
            [ty]:"m0 be ElementSUBSET-1M1-of NATNUMBERSK1" and m0Def:"m0 = p .FUNCT-1K1 (0NUMBERSK6)"
            using A1 ordinal1_def_12 sorry
          let ?F = "\<lambda>Lamb1. p .FUNCT-1K1 Lamb1"
          have " ex q be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 q =XBOOLE-0R4 m0 & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 k =XBOOLE-0R4 ?F(k))"
            using finseq_1_sch_2 sorry
          then obtain q where
            [ty]:"q be FinSequenceFINSEQ-1M1" and 
            A3: "lenFINSEQ-1K4 q =XBOOLE-0R4 m0"and A4: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 q implies q .FUNCT-1K1 k =XBOOLE-0R4 ?F(k)"
             sorry
          have "rngFUNCT-1K2 q c=TARSKIR1 D"
          proof-
            have A5: "m0 <XXREAL-0R3 lenAFINSQ-1K2 p"
              using A2 afinsq_1_lm_1 sorry
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 q implies y inHIDDENR3 D"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 rngFUNCT-1K2 q"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A6: "x inHIDDENR3 domFINSEQ-1K5 q"and A7: "y =HIDDENR1 q .FUNCT-1K1 x"
                using funct_1_def_3 sorry
              obtain k0 where 
                [ty]:"k0 be ElementSUBSET-1M1-of NATNUMBERSK1" and k0Def:"k0 = x"
                using A6 sorry
              have "k0 inTARSKIR2 SegFINSEQ-1K2 m0"
                using A3 A6 finseq_1_def_3 sorry
              then have "k0 <=XXREAL-0R1 m0"
                using finseq_1_th_1 sorry
              then have "k0 <XXREAL-0R3 lenAFINSQ-1K2 p"
                using A5 xxreal_0_th_2 sorry
              then have A8: "k0 inTARSKIR2 domAFINSQ-1K3 p"
                using afinsq_1_lm_1 sorry
              have "y =HIDDENR1 p .FUNCT-1K1 k0"
                using A4 A6 A7 sorry
              then have "rngFUNCT-1K2 p c=TARSKIR1 D & y inHIDDENR3 rngFUNCT-1K2 p"
                using A8 funct_1_def_3 relat_1_def_19 sorry
              thus "y inHIDDENR3 D"
                 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 q c=TARSKIR1 D"
              using tarski_def_3 sorry
          qed
          then obtain q0 where 
            [ty]:"q0 be FinSequenceFINSEQ-1M3-of D" and q0Def:"q0 = q"
            using finseq_1_def_4 sorry
          have A9: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 m0"
            using A3 finseq_1_def_3 sorry
          have " for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 q0 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies q0 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)"
            using A4 A9 finseq_1_th_1 A3 sorry
          thus " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of D holds  not ( for m be NatNAT-1M1 holds  not (m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) &  not (lenFINSEQ-1K4 VarFor1 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds  not ((\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m) &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i))))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p implies ( for it1 be FinSequenceFINSEQ-1M3-of D holds  for it2 be FinSequenceFINSEQ-1M3-of D holds ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it1 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) & ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it2 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it2 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1 & p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p"
      have A1: "p .FUNCT-1K1 (0NUMBERSK6) be NatNAT-1M1"
        using Assume sorry
      have A2: "p .FUNCT-1K1 (0NUMBERSK6) inTARSKIR2 lenAFINSQ-1K2 p"
        using Assume sorry
      show " for it1 be FinSequenceFINSEQ-1M3-of D holds  for it2 be FinSequenceFINSEQ-1M3-of D holds ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it1 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) & ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 it2 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies it2 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) implies it1 =HIDDENR1 it2"
      proof-
        have " for g1 be FinSequenceFINSEQ-1M3-of D holds  for g2 be FinSequenceFINSEQ-1M3-of D holds ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 g1 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies g1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) & ( for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 g2 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies g2 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)) implies g1 =HIDDENR1 g2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          obtain m2 where 
            [ty]:"m2 be NatNAT-1M1" and m2Def:"m2 = p .FUNCT-1K1 (0NUMBERSK6)"
            using A1 sorry
          fix g1 assume [ty]: "g1 be FinSequenceFINSEQ-1M3-of D"
          fix g2 assume [ty]: "g2 be FinSequenceFINSEQ-1M3-of D"
          assume A10: " for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 g1 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies g1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)"
            and A11: " for m be NatNAT-1M1 holds m =XBOOLE-0R4 p .FUNCT-1K1 (0NUMBERSK6) implies lenFINSEQ-1K4 g2 =XBOOLE-0R4 m & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 m implies g2 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i)"
          have A12: "lenFINSEQ-1K4 g1 =XBOOLE-0R4 m2"
            using A10 sorry
          have A13: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 g1 implies g1 .FUNCT-1K1 i =XBOOLE-0R4 g2 .FUNCT-1K1 i"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be NatNAT-1M1"
            assume A14: "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 g1"
            then have "g1 .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
              using A10 A12 sorry
            thus "g1 .FUNCT-1K1 i =XBOOLE-0R4 g2 .FUNCT-1K1 i"
              using A11 A12 A14 sorry
          qed "sorry"
          have "lenFINSEQ-1K4 g2 =XBOOLE-0R4 m2"
            using A11 sorry
          thus "g1 =HIDDENR1 g2"
            using A10 A13 finseq_1_th_14 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem afinsq_1_th_64:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M2-of D holds p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 lenAFINSQ-1K2 p implies XFS2FS*AFINSQ-1K15\<^bsub>(D)\<^esub> p =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M2-of D holds p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 lenAFINSQ-1K2 p implies XFS2FS*AFINSQ-1K15\<^bsub>(D)\<^esub> p =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M2-of D"
    assume A1: "p .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
      and A2: "0NUMBERSK6 <XXREAL-0R3 lenAFINSQ-1K2 p"
    let ?q = "XFS2FS*AFINSQ-1K15\<^bsub>(D)\<^esub> p"
    have "0NUMBERSK6 inTARSKIR2 lenAFINSQ-1K2 p"
      using A2 afinsq_1_lm_1 sorry
    then have "lenFINSEQ-1K4 ?q =XBOOLE-0R4 0NUMBERSK6"
      using A1 afinsq_1_def_11 sorry
    thus "XFS2FS*AFINSQ-1K15\<^bsub>(D)\<^esub> p =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef afinsq_1_def_12 ("initialAFINSQ-1V1" 70 ) where
"attr initialAFINSQ-1V1 for FunctionFUNCT-1M1 means
  (\<lambda>F.  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n inTARSKIR2 domRELAT-1K1 F & m <XXREAL-0R3 n implies m inTARSKIR2 domRELAT-1K1 F)"..

mtheorem afinsq_1_cl_33:
"cluster emptyXBOOLE-0V1 also-is initialAFINSQ-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be initialAFINSQ-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_34:
"cluster note-that initialAFINSQ-1V1 for XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M1 holds it be initialAFINSQ-1V1"
  proof-
    have " for p be XFinSequenceAFINSQ-1M1 holds p be initialAFINSQ-1V1"
    proof(rule ballI)
      fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
      have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n inTARSKIR2 domAFINSQ-1K3 p implies (m <XXREAL-0R3 n implies m inTARSKIR2 domAFINSQ-1K3 p)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A1: "n inTARSKIR2 domAFINSQ-1K3 p"
        assume "m <XXREAL-0R3 n"
        then have "m inTARSKIR2 SegmCARD-1K5 n"
          using nat_1_th_44 sorry
        thus "m inTARSKIR2 domAFINSQ-1K3 p"
          using A1 ordinal1_th_10 sorry
      qed "sorry"
      thus "p be initialAFINSQ-1V1"
        using afinsq_1_def_12 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_cl_35:
"cluster note-that NATNUMBERSK1 -definedRELAT-1V4 for XFinSequenceAFINSQ-1M1"
proof
(*coherence*)
  show " for it be XFinSequenceAFINSQ-1M1 holds it be NATNUMBERSK1 -definedRELAT-1V4"
  proof-
    have " for f be XFinSequenceAFINSQ-1M1 holds f be NATNUMBERSK1 -definedRELAT-1V4"
    proof(rule ballI)
      fix f assume [ty]: "f be XFinSequenceAFINSQ-1M1"
      have "domAFINSQ-1K3 f c=ORDINAL1R1 NATNUMBERSK1"
      proof-
        show "domAFINSQ-1K3 f c=ORDINAL1R1 NATNUMBERSK1"
           sorry
      qed
      thus "f be NATNUMBERSK1 -definedRELAT-1V4"
        using relat_1_def_18 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_65:
" for F be  non emptyXBOOLE-0V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds 0NUMBERSK6 inTARSKIR2 domRELAT-1K1 F"
proof(rule ballI)
  fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
  obtain x where
    [ty]:"x be objectHIDDENM1" and 
    A1: "x inHIDDENR3 domRELAT-1K1 F"
    using xboole_0_def_1 sorry
  have "domRELAT-1K1 F c=TARSKIR1 NATNUMBERSK1"
    using relat_1_def_18 sorry
  then have 
    [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
    using A1 sorry
  have "x =XBOOLE-0R4 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 x"
     sorry
  thus "0NUMBERSK6 inTARSKIR2 domRELAT-1K1 F"
    using A1 afinsq_1_def_12 sorry
qed "sorry"

mtheorem afinsq_1_cl_36:
"cluster initialAFINSQ-1V1\<bar>finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 also-is Sequence-likeORDINAL1V5 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be initialAFINSQ-1V1\<bar>finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 implies it be Sequence-likeORDINAL1V5"
  proof-
    have " for F be FunctionFUNCT-1M1 holds F be initialAFINSQ-1V1\<bar>finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 implies F be Sequence-likeORDINAL1V5"
    proof(rule ballI,rule impI)
      fix F assume [ty]: "F be FunctionFUNCT-1M1"
      assume A1: "F be initialAFINSQ-1V1\<bar>finiteFINSET-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4"
      have "domRELAT-1K1 F be epsilon-transitiveORDINAL1V1 & domRELAT-1K1 F be epsilon-connectedORDINAL1V2"
      proof(rule conjMI)
        show "domRELAT-1K1 F be epsilon-transitiveORDINAL1V1"
        proof-
          have " for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 F implies x c=TARSKIR1 domRELAT-1K1 F"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be setHIDDENM2"
            assume A2: "x inTARSKIR2 domRELAT-1K1 F"
            then obtain i where 
              [ty]:"i be NatNAT-1M1" and iDef:"i = x"
              using A1 sorry
            have " for y be objectHIDDENM1 holds y inHIDDENR3 x implies y inHIDDENR3 domRELAT-1K1 F"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 x"
              then have A3: "y inHIDDENR3 SegmCARD-1K5 i"
                 sorry
              then obtain j where 
                [ty]:"j be NatNAT-1M1" and jDef:"j = y"
                 sorry
              have "j <XXREAL-0R3 i"
                using nat_1_th_44 A3 sorry
              thus "y inHIDDENR3 domRELAT-1K1 F"
                using A1 A2 sorry
            qed "sorry"
            thus "x c=TARSKIR1 domRELAT-1K1 F"
              using tarski_def_3 sorry
          qed "sorry"
          thus "domRELAT-1K1 F be epsilon-transitiveORDINAL1V1"
            using ordinal1_def_2 sorry
        qed
        have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 F & y inTARSKIR2 domRELAT-1K1 F implies  not (( not x inTARSKIR2 y &  not x =HIDDENR1 y) &  not y inTARSKIR2 x)"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          fix y assume [ty]: "y be setHIDDENM2"
          assume "x inTARSKIR2 domRELAT-1K1 F & y inTARSKIR2 domRELAT-1K1 F"
          then have 
            [ty]:"x be OrdinalORDINAL1M3" and
            [ty]:"y be OrdinalORDINAL1M3"
            using A1 sorry
          have "(x inTARSKIR2 y or x =XBOOLE-0R4 y) or y inTARSKIR2 x"
            using ordinal1_th_14 sorry
          thus " not (( not x inTARSKIR2 y &  not x =HIDDENR1 y) &  not y inTARSKIR2 x)"
             sorry
        qed "sorry"
        thus "domRELAT-1K1 F be epsilon-connectedORDINAL1V2"
          using ordinal1_def_3 sorry
      qed
      thus "F be Sequence-likeORDINAL1V5"
        using ordinal1_def_7 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_66:
" for F be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for n be NatNAT-1M1 holds n inTARSKIR2 domAFINSQ-1K3 F iff n <XXREAL-0R3 cardCARD-1K4 F"
  using afinsq_1_lm_1 sorry

mtheorem afinsq_1_th_67:
" for F be initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for G be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 G implies G be initialAFINSQ-1V1"
  using afinsq_1_def_12 sorry

mtheorem afinsq_1_th_68:
" for F be initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domAFINSQ-1K3 F =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 cardCARD-1K4 F }"
proof-
  have " for F be initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domAFINSQ-1K3 F =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 cardCARD-1K4 F }"
  proof(rule ballI)
    fix F assume [ty]: "F be initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 F implies x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 cardCARD-1K4 F }) & {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 cardCARD-1K4 F } c=TARSKIR1 domAFINSQ-1K3 F"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 F implies x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 cardCARD-1K4 F }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 domAFINSQ-1K3 F"
        then obtain f where 
          [ty]:"f be ElementSUBSET-1M1-of NATNUMBERSK1" and fDef:"f = x"
           sorry
        have "f <XXREAL-0R3 cardCARD-1K4 F"
          using A1 afinsq_1_lm_1 sorry
        thus "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 cardCARD-1K4 F }"
           sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 cardCARD-1K4 F } implies x inHIDDENR3 domAFINSQ-1K3 F"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k <XXREAL-0R3 cardCARD-1K4 F }"
        then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 k & k <XXREAL-0R3 cardCARD-1K4 F"
           sorry
        thus "x inHIDDENR3 domAFINSQ-1K3 F"
          using afinsq_1_lm_1 sorry
      qed "sorry"
      thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 cardCARD-1K4 F } c=TARSKIR1 domAFINSQ-1K3 F"
        using tarski_def_3 sorry
    qed
    thus "domAFINSQ-1K3 F =XBOOLE-0R4 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k <XXREAL-0R3 cardCARD-1K4 F }"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_69:
" for F be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1 holds  for G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds F c=RELAT-1R2 G & LastLocVALUED-1K65 F =XBOOLE-0R4 LastLocVALUED-1K65 G implies F =FUNCT-1R1 G"
proof-
  have " for F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds F c=RELAT-1R2 G & LastLocVALUED-1K65 F =XBOOLE-0R4 LastLocVALUED-1K65 G implies F =FUNCT-1R1 G"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix F assume [ty]: "F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    fix G assume [ty]: "G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    assume A1: "F c=RELAT-1R2 G"
      and A2: "LastLocVALUED-1K65 F =XBOOLE-0R4 LastLocVALUED-1K65 G"
    have "domAFINSQ-1K3 F =XBOOLE-0R4 domRELAT-1K1 G"
    proof-
      have "domAFINSQ-1K3 F c=TARSKIR1 domRELAT-1K1 G & domRELAT-1K1 G c=TARSKIR1 domAFINSQ-1K3 F"
      proof(rule conjMI)
        show "domAFINSQ-1K3 F c=TARSKIR1 domRELAT-1K1 G"
          using A1 grfunc_1_th_2 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 G implies x inHIDDENR3 domAFINSQ-1K3 F"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 domRELAT-1K1 G"
          have "domRELAT-1K1 G c=TARSKIR1 NATNUMBERSK1"
            using relat_1_def_18 sorry
          then have 
            [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A3 sorry
          have A4: "LastLocVALUED-1K65 F inTARSKIR2 domAFINSQ-1K3 F"
            using valued_1_th_30 sorry
          have "x <=XXREAL-0R1 LastLocVALUED-1K65 F"
            using A2 A3 valued_1_th_32 sorry
          then have "x <XXREAL-0R3 LastLocVALUED-1K65 F or x =XBOOLE-0R4 LastLocVALUED-1K65 F"
            using xxreal_0_th_1 sorry
          thus "x inHIDDENR3 domAFINSQ-1K3 F"
            using A4 afinsq_1_def_12 sorry
        qed "sorry"
        thus "domRELAT-1K1 G c=TARSKIR1 domAFINSQ-1K3 F"
          using tarski_def_3 sorry
      qed
      thus "domAFINSQ-1K3 F =XBOOLE-0R4 domRELAT-1K1 G"
        using xboole_0_def_10 sorry
    qed
    thus "F =FUNCT-1R1 G"
      using A1 grfunc_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_70:
" for F be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1 holds LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
proof-
  have " for F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
  proof(rule ballI)
    fix F assume [ty]: "F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "LastLocVALUED-1K65 F =XBOOLE-0R4 k"
       sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "LastLocVALUED-1K65 F inTARSKIR2 domAFINSQ-1K3 F"
      using valued_1_th_30 sorry
    then have "k <XXREAL-0R3 cardCARD-1K4 F"
      using A1 afinsq_1_lm_1 sorry
    then have A2: "k <=XXREAL-0R1 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
      using nat_d_th_49 sorry
    show "LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
    proof-
      have cases: "k <XXREAL-0R3 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M or k =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
        using A2 xxreal_0_th_1 sorry
      have case1: "k <XXREAL-0R3 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M implies LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
      proof(rule impI)
        assume "k <XXREAL-0R3 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
        then have "k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 (cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 cardCARD-1K4 F"
          using nat_1_th_14 xreal_1_th_235 sorry
        then have "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domAFINSQ-1K3 F"
          using afinsq_1_lm_1 sorry
        then have A3: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
          using A1 valued_1_th_32 sorry
        have "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have "k +NAT-1K1 0NUMBERSK6 =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"
          using A3 xxreal_0_th_1 sorry
        thus "LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
           sorry
      qed
      have case2: "k =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M implies LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
      proof(rule impI)
        assume "k =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
        thus "LastLocVALUED-1K65 F =XBOOLE-0R4 cardCARD-1K4 F -'NAT-DK9 \<one>\<^sub>M"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_71:
" for F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds FirstLocVALUED-1K67 F =XBOOLE-0R4 0NUMBERSK6"
  using afinsq_1_th_65 valued_1_th_35 sorry

mtheorem afinsq_1_cl_37:
  mlet "F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster CutLastLocVALUED-1K66 F as-term-is initialAFINSQ-1V1"
proof
(*coherence*)
  show "CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
  proof-
    let ?G = "CutLastLocVALUED-1K66 F"
    show "CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
    proof-
      have cases: "?G be emptyXBOOLE-0V1 or ?G be  non emptyXBOOLE-0V1"
         sorry
      have case1: "CutLastLocVALUED-1K66 F be emptyXBOOLE-0V1 implies CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
      proof(rule impI)
        assume "?G be emptyXBOOLE-0V1"
        then obtain H where 
          [ty]:"H be emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and HDef:"H = ?G"
           sorry
        have "H be initialAFINSQ-1V1"
           sorry
        thus "CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
           sorry
      qed
      have case2: "CutLastLocVALUED-1K66 F be  non emptyXBOOLE-0V1 implies CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
      proof(rule impI)
        assume "?G be  non emptyXBOOLE-0V1"
        then obtain G where 
          [ty]:"G be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and GDef:"G = ?G"
           sorry
        have "G be initialAFINSQ-1V1"
        proof-
          have " for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l inTARSKIR2 domRELAT-1K1 G & m <XXREAL-0R3 l implies m inTARSKIR2 domRELAT-1K1 G"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            fix l assume [ty]: "l be NatNAT-1M1"
            assume A1: "l inTARSKIR2 domRELAT-1K1 G"
              and A2: "m <XXREAL-0R3 l"
            let ?M = "domAFINSQ-1K3 F"
            obtain R where 
              [ty]:"R be RelationRELAT-1M1" and RDef:"R = {TARSKIK1 [TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ] }"
               sorry
            have "R =RELAT-1R1 (LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F)"
              using funct_4_th_82 sorry
            then have A3: "domRELAT-1K1 R =XBOOLE-0R4 {TARSKIK1 LastLocVALUED-1K65 F }"
              using funcop_1_th_13 sorry
            then have A4: "domAFINSQ-1K3 F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> domRELAT-1K1 R =XBOOLE-0R4 domRELAT-1K1 G"
              using valued_1_th_36 sorry
            then have "l inTARSKIR2 domAFINSQ-1K3 F"
              using A1 xboole_0_def_5 sorry
            then have A5: "m inTARSKIR2 domAFINSQ-1K3 F"
              using A2 afinsq_1_def_12 sorry
            have "l inTARSKIR2 ?M"
              using A4 A1 xboole_0_def_5 sorry
            then have "m <>HIDDENR2 LastLocVALUED-1K65 F"
              using A2 xxreal_2_def_8 sorry
            then have " not m inTARSKIR2 {TARSKIK1 LastLocVALUED-1K65 F }"
              using tarski_def_1 sorry
            thus "m inTARSKIR2 domRELAT-1K1 G"
              using A3 A4 A5 xboole_0_def_5 sorry
          qed "sorry"
          thus "G be initialAFINSQ-1V1"
            using afinsq_1_def_12 sorry
        qed
        thus "CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

reserve l for "NatNAT-1M1"
mtheorem afinsq_1_th_72:
" for I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for J be FunctionFUNCT-1M1 holds domAFINSQ-1K3 I missesXBOOLE-0R1 domRELAT-1K1 (ShiftVALUED-1K64(J,cardCARD-1K4 I))"
proof-
  have " for I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for J be FunctionFUNCT-1M1 holds domAFINSQ-1K3 I meetsXBOOLE-0R5 domRELAT-1K1 (ShiftVALUED-1K64(J,cardCARD-1K4 I)) implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix I assume [ty]: "I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    fix J assume [ty]: "J be FunctionFUNCT-1M1"
    assume A1: "domAFINSQ-1K3 I meetsXBOOLE-0R5 domRELAT-1K1 (ShiftVALUED-1K64(J,cardCARD-1K4 I))"
    have "domRELAT-1K1 (ShiftVALUED-1K64(J,cardCARD-1K4 I)) =XBOOLE-0R4 {l +NAT-1K1 cardCARD-1K4 I where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 J }"
      using valued_1_def_12 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 domAFINSQ-1K3 I"and A3: "x inHIDDENR3 {l +NAT-1K1 cardCARD-1K4 I where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 J }"
      using A1 xboole_0_th_3 sorry
    obtain l where
      [ty]:"l be NatNAT-1M1" and 
      A4: "x =HIDDENR1 l +NAT-1K1 cardCARD-1K4 I"and "l inTARSKIR2 domRELAT-1K1 J"
      using A3 sorry
    have "l +NAT-1K1 cardCARD-1K4 I <XXREAL-0R3 cardCARD-1K4 I"
      using A2 A4 afinsq_1_lm_1 sorry
    thus " False "
      using nat_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_73:
" for p be XFinSequenceAFINSQ-1M1 holds  for m be NatNAT-1M1 holds  not m inTARSKIR2 domAFINSQ-1K3 p implies  not m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domAFINSQ-1K3 p"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for m be NatNAT-1M1 holds  not m inTARSKIR2 domAFINSQ-1K3 p implies  not m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domAFINSQ-1K3 p"
  proof(rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume " not m inTARSKIR2 domAFINSQ-1K3 p"
    then have A1: "m >=XXREAL-0R2 cardCARD-1K4 p"
      using afinsq_1_lm_1 sorry
    have "m +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 m"
      using nat_1_th_11 sorry
    then have "m +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 cardCARD-1K4 p"
      using A1 xxreal_0_th_2 sorry
    thus " not m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domAFINSQ-1K3 p"
      using afinsq_1_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_cl_38:
  mlet "D be setHIDDENM2"
"cluster D ^omegaAFINSQ-1K10 as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "D ^omegaAFINSQ-1K10 be functionalFUNCT-1V6"
    using afinsq_1_def_7 sorry
qed "sorry"

mtheorem afinsq_1_cl_39:
  mlet "D be setHIDDENM2"
"cluster note-that finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5 for ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10 holds it be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
    using afinsq_1_def_7 sorry
qed "sorry"

mdef afinsq_1_def_13 ("DownAFINSQ-1K16\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be setHIDDENM2", "f be XFinSequenceAFINSQ-1M2-of D"
"func DownAFINSQ-1K16\<^bsub>(D)\<^esub> f \<rightarrow> ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10 equals
  f"
proof-
  (*coherence*)
    show "f be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
      using afinsq_1_def_7 sorry
qed "sorry"

syntax AFINSQ_1K17 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^AFINSQ-1K17\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "f ^AFINSQ-1K17\<^bsub>(D)\<^esub> g" \<rightharpoonup> "f ^ORDINAL4K1 g"

mtheorem afinsq_1_add_4:
  mlet "D be setHIDDENM2", "f be XFinSequenceAFINSQ-1M2-of D", "g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
"cluster f ^ORDINAL4K1 g as-term-is ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
proof
(*coherence*)
  show "f ^ORDINAL4K1 g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
  proof-
    have 
      [ty]:"g be XFinSequenceAFINSQ-1M2-of D"
      using afinsq_1_def_7 sorry
    have "f ^AFINSQ-1K6 g be XFinSequenceAFINSQ-1M2-of D"
       sorry
    thus "f ^ORDINAL4K1 g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
      using afinsq_1_def_7 sorry
  qed
qed "sorry"

syntax AFINSQ_1K18 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^AFINSQ-1K18\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "f ^AFINSQ-1K18\<^bsub>(D)\<^esub> g" \<rightharpoonup> "f ^ORDINAL4K1 g"

mtheorem afinsq_1_add_5:
  mlet "D be setHIDDENM2", "f be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10", "g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
"cluster f ^ORDINAL4K1 g as-term-is ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
proof
(*coherence*)
  show "f ^ORDINAL4K1 g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
  proof-
    have 
      [ty]:"f be XFinSequenceAFINSQ-1M2-of D" and
      [ty]:"g be XFinSequenceAFINSQ-1M2-of D"
      using afinsq_1_def_7 sorry
    have "f ^AFINSQ-1K6 g be XFinSequenceAFINSQ-1M2-of D"
       sorry
    thus "f ^ORDINAL4K1 g be ElementSUBSET-1M1-of D ^omegaAFINSQ-1K10"
      using afinsq_1_def_7 sorry
  qed
qed "sorry"

mtheorem afinsq_1_th_74:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p c=RELAT-1R2 p ^AFINSQ-1K6 q"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p c=RELAT-1R2 p ^AFINSQ-1K6 q"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    have A1: "domAFINSQ-1K3 p c=ORDINAL1R1 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
      using afinsq_1_th_21 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 p implies (p ^AFINSQ-1K6 q).FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 x"
      using afinsq_1_def_3 sorry
    thus "p c=RELAT-1R2 p ^AFINSQ-1K6 q"
      using A1 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_75:
" for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =XBOOLE-0R4 lenAFINSQ-1K2 p +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for x be objectHIDDENM1 holds  for p be XFinSequenceAFINSQ-1M1 holds lenAFINSQ-1K2 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =HIDDENR1 lenAFINSQ-1K2 p +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    have "lenAFINSQ-1K2 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =HIDDENR1 lenAFINSQ-1K2 p +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 x%>)"
      using afinsq_1_def_3 sorry
    also have "... = lenAFINSQ-1K2 p +NAT-1K1 \<one>\<^sub>M"
      using afinsq_1_th_33 sorry
    finally show "lenAFINSQ-1K2 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 x%>)) =HIDDENR1 lenAFINSQ-1K2 p +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_76:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <%AFINSQ-1K8 x,y %> =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(x,y)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <%AFINSQ-1K8 x,y %> =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(x,y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have A1: "domAFINSQ-1K3 (<%AFINSQ-1K8 x,y %>) =HIDDENR1 lenAFINSQ-1K2 (<%AFINSQ-1K8 x,y %>)"
       sorry
    also have "... = {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
      using afinsq_1_th_38 card_1_th_50 sorry
    finally have "domAFINSQ-1K3 (<%AFINSQ-1K8 x,y %>) =HIDDENR1 {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
       sorry
    have A2: "(<%AFINSQ-1K8 x,y %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
       sorry
    have "(<%AFINSQ-1K8 x,y %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 y"
       sorry
    thus "<%AFINSQ-1K8 x,y %> =FUNCT-1R1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(x,y)"
      using A1 A2 funct_4_th_66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve M for "NatNAT-1M1"
mtheorem afinsq_1_th_77:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 p +*FUNCT-4K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p ^AFINSQ-1K6 q =FUNCT-1R1 p +*FUNCT-4K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    have A1: "domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) =XBOOLE-0R4 {M +NAT-1K1 cardCARD-1K4 p where M be NatNAT-1M1 : M inTARSKIR2 domAFINSQ-1K3 q }"
      using valued_1_def_12 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) iff x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) implies x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))) & (x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q) implies x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
        proof(rule impI)
          assume A2: "x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
          then obtain k where 
            [ty]:"k be NatNAT-1M1" and kDef:"k = x"
             sorry
          show "x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
          proof-
            have cases: "k inTARSKIR2 domAFINSQ-1K3 p or ( ex n be NatNAT-1M1 st n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n)"
              using A2 afinsq_1_th_20 sorry
            have case1: "k inTARSKIR2 domAFINSQ-1K3 p implies x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
            proof(rule impI)
              assume "k inTARSKIR2 domAFINSQ-1K3 p"
              thus "x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
                 sorry
            qed
            have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n) implies x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
            proof(rule impI)
              assume " ex n be NatNAT-1M1 st n inTARSKIR2 domAFINSQ-1K3 q & k =XBOOLE-0R4 lenAFINSQ-1K2 p +XCMPLX-0K2 n"
              thus "x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
                using A1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        assume A3: "x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
        show "x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
        proof-
          have cases: "x inHIDDENR3 domAFINSQ-1K3 p or x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
            using A3 sorry
          have case1: "x inHIDDENR3 domAFINSQ-1K3 p implies x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
          proof(rule impI)
            assume A4: "x inHIDDENR3 domAFINSQ-1K3 p"
            have "domAFINSQ-1K3 p c=ORDINAL1R1 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
              using afinsq_1_th_21 sorry
            thus "x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
              using A4 sorry
          qed
          have case2: "x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
          proof(rule impI)
            assume "x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
            then have " ex M be NatNAT-1M1 st x =HIDDENR1 M +NAT-1K1 cardCARD-1K4 p & M inTARSKIR2 domAFINSQ-1K3 q"
              using A1 sorry
            thus "x inHIDDENR3 domAFINSQ-1K3 (p ^AFINSQ-1K6 q)"
              using afinsq_1_th_23 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A5: "domAFINSQ-1K3 (p ^AFINSQ-1K6 q) =XBOOLE-0R4 domAFINSQ-1K3 p \\/XBOOLE-0K2 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
      using xboole_0_def_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 p \\/XBOOLE-0K2 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies (x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 x =XBOOLE-0R4 (ShiftVALUED-1K64(q,cardCARD-1K4 p)).FUNCT-1K1 x) & ( not x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 x)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domAFINSQ-1K3 p \\/XBOOLE-0K2 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies (x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 x =HIDDENR1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)).FUNCT-1K1 x) & ( not x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 x)"
      proof(rule ballI,rule impI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 domAFINSQ-1K3 p \\/XBOOLE-0K2 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
        show "x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)) implies (p ^AFINSQ-1K6 q).FUNCT-1K1 x =HIDDENR1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)).FUNCT-1K1 x"
        proof(rule impI)
          assume A7: "x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
          then obtain k where 
            [ty]:"k be NatNAT-1M1" and kDef:"k = x"
             sorry
          obtain M where
            [ty]:"M be NatNAT-1M1" and 
            A8: "x =HIDDENR1 M +NAT-1K1 cardCARD-1K4 p"and A9: "M inTARSKIR2 domAFINSQ-1K3 q"
            using A7 A1 sorry
          let ?m = "k -'NAT-DK9 lenAFINSQ-1K2 p"
          have A10: "lenAFINSQ-1K2 p +NAT-1K1 ?m =XBOOLE-0R4 k"
            using A8 nat_d_th_34 sorry
          then have "(p ^AFINSQ-1K6 q).FUNCT-1K1 x =HIDDENR1 q .FUNCT-1K1 (k -'NAT-DK9 lenAFINSQ-1K2 p)"
            using A8 A9 afinsq_1_def_3 sorry
          also have "... = (ShiftVALUED-1K64(q,cardCARD-1K4 p)).FUNCT-1K1 x"
            using A8 A9 A10 valued_1_def_12 sorry
          finally show "(p ^AFINSQ-1K6 q).FUNCT-1K1 x =HIDDENR1 (ShiftVALUED-1K64(q,cardCARD-1K4 p)).FUNCT-1K1 x"
             sorry
        qed
        assume " not x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
        then have "x inHIDDENR3 domAFINSQ-1K3 p"
          using A6 xboole_0_def_3 sorry
        thus "(p ^AFINSQ-1K6 q).FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 x"
          using afinsq_1_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "p ^AFINSQ-1K6 q =FUNCT-1R1 p +*FUNCT-4K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
      using A5 funct_4_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_78:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds p +*FUNCT-4K1 (p ^AFINSQ-1K6 q) =FUNCT-1R1 p ^AFINSQ-1K6 q & (p ^AFINSQ-1K6 q)+*FUNCT-4K1 p =FUNCT-1R1 p ^AFINSQ-1K6 q"
  using afinsq_1_th_74 funct_4_th_97 funct_4_th_98 sorry

reserve m, n for "NatNAT-1M1"
mtheorem afinsq_1_th_79:
" for n be NatNAT-1M1 holds  for I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for J be FunctionFUNCT-1M1 holds domRELAT-1K1 (ShiftVALUED-1K64(I,n)) missesXBOOLE-0R1 domRELAT-1K1 (ShiftVALUED-1K64(J,n +NAT-1K1 cardCARD-1K4 I))"
proof-
  have " for n be NatNAT-1M1 holds  for I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for J be FunctionFUNCT-1M1 holds domRELAT-1K1 (ShiftVALUED-1K64(I,n)) meetsXBOOLE-0R5 domRELAT-1K1 (ShiftVALUED-1K64(J,n +NAT-1K1 cardCARD-1K4 I)) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix I assume [ty]: "I be finiteFINSET-1V1\<bar>initialAFINSQ-1V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    fix J assume [ty]: "J be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 (ShiftVALUED-1K64(I,n)) meetsXBOOLE-0R5 domRELAT-1K1 (ShiftVALUED-1K64(J,n +NAT-1K1 cardCARD-1K4 I))"
    have "domRELAT-1K1 (ShiftVALUED-1K64(J,n +NAT-1K1 cardCARD-1K4 I)) =XBOOLE-0R4 {l +NAT-1K1 (n +NAT-1K1 cardCARD-1K4 I) where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 J }"
      using valued_1_def_12 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(I,n))"and A3: "x inHIDDENR3 {l +NAT-1K1 (n +NAT-1K1 cardCARD-1K4 I) where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 J }"
      using A1 xboole_0_th_3 sorry
    have "domRELAT-1K1 (ShiftVALUED-1K64(I,n)) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domAFINSQ-1K3 I }"
      using valued_1_def_12 sorry
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A4: "x =HIDDENR1 m +XCMPLX-0K2 n"and A5: "m inTARSKIR2 domAFINSQ-1K3 I"
      using A2 sorry
    obtain l where
      [ty]:"l be NatNAT-1M1" and 
      A6: "x =HIDDENR1 l +NAT-1K1 (n +NAT-1K1 cardCARD-1K4 I)"and "l inTARSKIR2 domRELAT-1K1 J"
      using A3 sorry
    have "m <XXREAL-0R3 cardCARD-1K4 I"
      using A5 afinsq_1_lm_1 sorry
    then have "l +NAT-1K1 (n +NAT-1K1 cardCARD-1K4 I) <XXREAL-0R3 n +NAT-1K1 cardCARD-1K4 I"
      using A4 A6 xreal_1_th_6 sorry
    thus " False "
      using nat_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_80:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p,n) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p,n) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "p ^AFINSQ-1K6 q =FUNCT-1R1 p +*FUNCT-4K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
      using afinsq_1_th_77 sorry
    then have A1: "ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) =FUNCT-1R1 (ShiftVALUED-1K64(p,n))+*FUNCT-4K1 (ShiftVALUED-1K64(ShiftVALUED-1K64(q,cardCARD-1K4 p),n))"
      using valued_1_th_23 sorry
    have "ShiftVALUED-1K64(ShiftVALUED-1K64(q,cardCARD-1K4 p),n) =FUNCT-1R1 ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p)"
      using valued_1_th_21 sorry
    then have "domRELAT-1K1 (ShiftVALUED-1K64(p,n)) missesXBOOLE-0R1 domRELAT-1K1 (ShiftVALUED-1K64(ShiftVALUED-1K64(q,cardCARD-1K4 p),n))"
      using afinsq_1_th_79 sorry
    thus "ShiftVALUED-1K64(p,n) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
      using A1 funct_4_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_81:
" for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
  proof(rule ballI,rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "ShiftVALUED-1K64(ShiftVALUED-1K64(q,cardCARD-1K4 p),n) =FUNCT-1R1 ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p)"
      using valued_1_th_21 sorry
    have "p ^AFINSQ-1K6 q =FUNCT-1R1 p +*FUNCT-4K1 (ShiftVALUED-1K64(q,cardCARD-1K4 p))"
      using afinsq_1_th_77 sorry
    then have "ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) =FUNCT-1R1 (ShiftVALUED-1K64(p,n))+*FUNCT-4K1 (ShiftVALUED-1K64(ShiftVALUED-1K64(q,cardCARD-1K4 p),n))"
      using valued_1_th_23 sorry
    thus "ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
      using A1 funct_4_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_82:
" for X be setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X implies ShiftVALUED-1K64(p,n) c=RELAT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X implies ShiftVALUED-1K64(p,n) c=RELAT-1R2 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X"
    have "ShiftVALUED-1K64(p,n) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
      using afinsq_1_th_80 sorry
    thus "ShiftVALUED-1K64(p,n) c=RELAT-1R2 X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_83:
" for X be setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X implies ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 X"
proof-
  have " for X be setHIDDENM2 holds  for p be XFinSequenceAFINSQ-1M1 holds  for q be XFinSequenceAFINSQ-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X implies ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 X"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix q assume [ty]: "q be XFinSequenceAFINSQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n) c=RELAT-1R2 X"
    have "ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 ShiftVALUED-1K64(p ^AFINSQ-1K6 q,n)"
      using afinsq_1_th_81 sorry
    thus "ShiftVALUED-1K64(q,n +NAT-1K1 cardCARD-1K4 p) c=RELAT-1R2 X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_cl_40:
  mlet "F be initialAFINSQ-1V1\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster CutLastLocVALUED-1K66 F as-term-is initialAFINSQ-1V1"
proof
(*coherence*)
  show "CutLastLocVALUED-1K66 F be initialAFINSQ-1V1"
     sorry
qed "sorry"

mdef afinsq_1_def_14 ("<%AFINSQ-1K19 _ , _ , _ , _ %>" [0,0,0,0]164 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"func <%AFINSQ-1K19 x1,x2,x3,x4 %> \<rightarrow> setHIDDENM2 equals
  (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>)"
proof-
  (*coherence*)
    show "(((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K7 x2%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x3%>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem afinsq_1_cl_41:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster <%AFINSQ-1K19 x1,x2,x3,x4 %> as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "<%AFINSQ-1K19 x1,x2,x3,x4 %> be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem afinsq_1_cl_42:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"cluster <%AFINSQ-1K19 x1,x2,x3,x4 %> as-term-is finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "<%AFINSQ-1K19 x1,x2,x3,x4 %> be finiteFINSET-1V1\<bar>Sequence-likeORDINAL1V5"
     sorry
qed "sorry"

reserve x1, x2, x3, x4 for "objectHIDDENM1"
mtheorem afinsq_1_th_84:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds lenAFINSQ-1K2 (<%AFINSQ-1K19 x1,x2,x3,x4 %>) =XBOOLE-0R4 \<four>\<^sub>M"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds lenAFINSQ-1K2 (<%AFINSQ-1K19 x1,x2,x3,x4 %>) =HIDDENR1 \<four>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "lenAFINSQ-1K2 (<%AFINSQ-1K19 x1,x2,x3,x4 %>) =HIDDENR1 lenAFINSQ-1K2 (<%AFINSQ-1K9 x1,x2,x3 %>) +NAT-1K1 \<one>\<^sub>M"
      using afinsq_1_th_75 sorry
    also have "... = \<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using afinsq_1_th_39 sorry
    also have "... = \<four>\<^sub>M"
       sorry
    finally show "lenAFINSQ-1K2 (<%AFINSQ-1K19 x1,x2,x3,x4 %>) =HIDDENR1 \<four>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma afinsq_1_lm_3:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds ((<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x2 & (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x3) & (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x2 & ((<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x3 & (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have A1: "lenAFINSQ-1K2 (<%AFINSQ-1K9 x1,x2,x3 %>) =XBOOLE-0R4 \<three>\<^sub>M"
      using afinsq_1_th_39 sorry
    then have A2: "\<one>\<^sub>M inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K9 x1,x2,x3 %>)"
      using afinsq_1_lm_1 sorry
    have "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 (<%AFINSQ-1K9 x1,x2,x3 %>).FUNCT-1K1 \<one>\<^sub>M"
      using A2 afinsq_1_def_3 sorry
    also have "... = x2"
       sorry
    finally show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x2"
       sorry
    have A3: "\<two>\<^sub>M inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K9 x1,x2,x3 %>)"
      using A1 afinsq_1_lm_1 sorry
    have "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 (<%AFINSQ-1K9 x1,x2,x3 %>).FUNCT-1K1 \<two>\<^sub>M"
      using A3 afinsq_1_def_3 sorry
    also have "... = x3"
       sorry
    finally show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x3"
       sorry
    show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4"
      using A1 afinsq_1_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_reduce_9:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 (0NUMBERSK6) to x1"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x1"
  proof-
    have "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 (((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K8 x2,x3 %>))^AFINSQ-1K6 (<%AFINSQ-1K7 x4%>)).FUNCT-1K1 (0NUMBERSK6)"
      using afinsq_1_th_27 sorry
    also have "... = ((<%AFINSQ-1K7 x1%>)^AFINSQ-1K6 (<%AFINSQ-1K9 x2,x3,x4 %>)).FUNCT-1K1 (0NUMBERSK6)"
      using afinsq_1_th_27 sorry
    also have "... = x1"
      using afinsq_1_th_35 sorry
    finally show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x1"
       sorry
  qed
qed "sorry"

mtheorem afinsq_1_reduce_10:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M to x2"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 x2"
    using afinsq_1_lm_3 sorry
qed "sorry"

mtheorem afinsq_1_reduce_11:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M to x3"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 x3"
    using afinsq_1_lm_3 sorry
qed "sorry"

mtheorem afinsq_1_reduce_12:
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"reduce (<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M to x4"
proof
(*reducibility*)
  show "(<%AFINSQ-1K19 x1,x2,x3,x4 %>).FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 x4"
    using afinsq_1_lm_3 sorry
qed "sorry"

(*\$CT*)
mtheorem afinsq_1_th_86:
" for k be NatNAT-1M1 holds  for p be XFinSequenceAFINSQ-1M1 holds k <XXREAL-0R3 lenAFINSQ-1K2 p iff k inTARSKIR2 domAFINSQ-1K3 p"
  using afinsq_1_lm_1 sorry

reserve e, u for "objectHIDDENM1"
mtheorem afinsq_1_th_87:
" for n be NatNAT-1M1 holds  for e be objectHIDDENM1 holds SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e =FUNCT-1R1 (SegmCARD-1K5 n -->FUNCOP-1K7 e)^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)"
proof-
  have " for n be NatNAT-1M1 holds  for e be objectHIDDENM1 holds SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e =FUNCT-1R1 (SegmCARD-1K5 n -->FUNCOP-1K7 e)^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix e assume [ty]: "e be objectHIDDENM1"
    let ?p = "SegmCARD-1K5 n -->FUNCOP-1K7 e"
    let ?q = "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e"
    have A1: "lenAFINSQ-1K2 ?p =XBOOLE-0R4 n"
      using funcop_1_th_13 sorry
    have A2: "domAFINSQ-1K3 ?q =HIDDENR1 n +NAT-1K1 \<one>\<^sub>M"
      using funcop_1_th_13 sorry
    also have "... = lenAFINSQ-1K2 ?p +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 e%>)"
      using A1 afinsq_1_th_34 sorry
    finally have "domAFINSQ-1K3 ?q =HIDDENR1 lenAFINSQ-1K2 ?p +NAT-1K1 lenAFINSQ-1K2 (<%AFINSQ-1K7 e%>)"
       sorry
    have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 ?p implies ?q .FUNCT-1K1 k =XBOOLE-0R4 ?p .FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (SegmCARD-1K5 n -->FUNCOP-1K7 e) implies (SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e).FUNCT-1K1 k =XBOOLE-0R4 (SegmCARD-1K5 n -->FUNCOP-1K7 e).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A4: "k inTARSKIR2 domAFINSQ-1K3 ?p"
        have "SegmCARD-1K5 n c=ORDINAL1R1 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
          using nat_1_th_63 sorry
        then have "?p c=RELAT-1R2 ?q"
          using funct_4_th_4 sorry
        thus "(SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e).FUNCT-1K1 k =XBOOLE-0R4 (SegmCARD-1K5 n -->FUNCOP-1K7 e).FUNCT-1K1 k"
          using A4 grfunc_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 e%>) implies ?q .FUNCT-1K1 (lenAFINSQ-1K2 ?p +XCMPLX-0K2 k) =XBOOLE-0R4 (<%AFINSQ-1K7 e%>).FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 e%>) implies (SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e).FUNCT-1K1 (lenAFINSQ-1K2 (SegmCARD-1K5 n -->FUNCOP-1K7 e) +XCMPLX-0K2 k) =XBOOLE-0R4 (<%AFINSQ-1K7 e%>).FUNCT-1K1 k"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A5: "k inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 e%>)"
        have "domAFINSQ-1K3 (<%AFINSQ-1K7 e%>) =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
          using afinsq_1_th_33 card_1_th_49 sorry
        then have A6: "k =XBOOLE-0R4 0NUMBERSK6"
          using A5 tarski_def_1 sorry
        have "lenAFINSQ-1K2 ?p <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A1 nat_1_th_13 sorry
        then have "lenAFINSQ-1K2 ?p +NAT-1K1 0NUMBERSK6 inTARSKIR2 SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
          using nat_1_th_44 sorry
        thus "(SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e).FUNCT-1K1 (lenAFINSQ-1K2 (SegmCARD-1K5 n -->FUNCOP-1K7 e) +XCMPLX-0K2 k) =XBOOLE-0R4 (<%AFINSQ-1K7 e%>).FUNCT-1K1 k"
          using A6 funcop_1_th_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "SegmCARD-1K5 (n +NAT-1K1 \<one>\<^sub>M) -->FUNCOP-1K7 e =FUNCT-1R1 (SegmCARD-1K5 n -->FUNCOP-1K7 e)^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)"
      using A2 A3 afinsq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_88:
" for p be XFinSequenceAFINSQ-1M1 holds  for e be objectHIDDENM1 holds domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)) =XBOOLE-0R4 {TARSKIK1 cardCARD-1K4 p }"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for e be objectHIDDENM1 holds domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)) =XBOOLE-0R4 {TARSKIK1 cardCARD-1K4 p }"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix e assume [ty]: "e be objectHIDDENM1"
    have " for u be objectHIDDENM1 holds u inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)) iff u =HIDDENR1 cardCARD-1K4 p"
    proof-
      have " for u be objectHIDDENM1 holds (u inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)) implies u =HIDDENR1 cardCARD-1K4 p) &  not (u =HIDDENR1 cardCARD-1K4 p &  not u inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)))"
      proof(rule ballI,rule conjMI)
        fix u assume [ty]: "u be objectHIDDENM1"
        show "u inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)) implies u =HIDDENR1 cardCARD-1K4 p"
        proof(rule impI)
          assume "u inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p))"
          then have "u inHIDDENR3 {m +NAT-1K1 cardCARD-1K4 p where m be NatNAT-1M1 : m inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 e%>) }"
            using valued_1_def_12 sorry
          then obtain m where
            [ty]:"m be NatNAT-1M1" and 
            A1: "u =HIDDENR1 m +NAT-1K1 cardCARD-1K4 p"and A2: "m inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 e%>)"
             sorry
          have "m inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A2 afinsq_1_def_4 card_1_th_49 sorry
          then have "m =XBOOLE-0R4 0NUMBERSK6"
            using tarski_def_1 sorry
          thus "u =HIDDENR1 cardCARD-1K4 p"
            using A1 sorry
        qed
        have "0NUMBERSK6 inTARSKIR2 \<one>\<^sub>M"
          using card_1_th_49 tarski_def_1 sorry
        then have "0NUMBERSK6 inTARSKIR2 domAFINSQ-1K3 (<%AFINSQ-1K7 e%>)"
          using afinsq_1_def_4 sorry
        then have "0NUMBERSK6 +NAT-1K1 cardCARD-1K4 p inTARSKIR2 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p))"
          using valued_1_th_24 sorry
        thus " not (u =HIDDENR1 cardCARD-1K4 p &  not u inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)) =XBOOLE-0R4 {TARSKIK1 cardCARD-1K4 p }"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_89:
" for p be XFinSequenceAFINSQ-1M1 holds  for e be objectHIDDENM1 holds domAFINSQ-1K3 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)) =XBOOLE-0R4 domAFINSQ-1K3 p \\/XBOOLE-0K2 {TARSKIK1 cardCARD-1K4 p }"
proof-
  have " for p be XFinSequenceAFINSQ-1M1 holds  for e be objectHIDDENM1 holds domAFINSQ-1K3 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)) =HIDDENR1 domAFINSQ-1K3 p \\/XBOOLE-0K2 {TARSKIK1 cardCARD-1K4 p }"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be XFinSequenceAFINSQ-1M1"
    fix e assume [ty]: "e be objectHIDDENM1"
    have "domAFINSQ-1K3 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)) =HIDDENR1 domRELAT-1K1 (p +*FUNCT-4K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p)))"
      using afinsq_1_th_77 sorry
    also have "... = domAFINSQ-1K3 p \\/XBOOLE-0K2 domRELAT-1K1 (ShiftVALUED-1K64(<%AFINSQ-1K7 e%>,cardCARD-1K4 p))"
      using funct_4_def_1 sorry
    also have "... = domAFINSQ-1K3 p \\/XBOOLE-0K2 {TARSKIK1 cardCARD-1K4 p }"
      using afinsq_1_th_88 sorry
    finally show "domAFINSQ-1K3 (p ^AFINSQ-1K6 (<%AFINSQ-1K7 e%>)) =HIDDENR1 domAFINSQ-1K3 p \\/XBOOLE-0K2 {TARSKIK1 cardCARD-1K4 p }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_90:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y) =FUNCT-1R1 <%AFINSQ-1K7 y%>"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y) =FUNCT-1R1 <%AFINSQ-1K7 y%>"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have A1: "domRELAT-1K1 ((<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y)) =HIDDENR1 domAFINSQ-1K3 (<%AFINSQ-1K7 x%>)"
      using funct_4_th_99 sorry
    also have "... = SegmCARD-1K5 \<one>\<^sub>M"
      using afinsq_1_th_33 sorry
    finally have "domRELAT-1K1 ((<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y)) =HIDDENR1 SegmCARD-1K5 \<one>\<^sub>M"
       sorry
    then have "(<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y) be finiteFINSET-1V1"
      using finset_1_th_10 sorry
    then obtain p where 
      [ty]:"p be XFinSequenceAFINSQ-1M1" and pDef:"p = (<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y)"
      using A1 ordinal1_def_7 sorry
    have A2: "rngFUNCT-1K2 (<%AFINSQ-1K7 x%>) =XBOOLE-0R4 {TARSKIK1 x}"
      using afinsq_1_th_33 sorry
    then have "rngFUNCT-1K2 p c=TARSKIR1 ({TARSKIK1 x} \\SUBSET-1K6 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 y}"
      using funct_4_th_104 sorry
    then have "rngFUNCT-1K2 p c=TARSKIR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 {TARSKIK1 y}"
      using xboole_1_th_37 sorry
    then have A3: "rngFUNCT-1K2 p c=TARSKIR1 {TARSKIK1 y}"
       sorry
    have "x inHIDDENR3 rngFUNCT-1K2 (<%AFINSQ-1K7 x%>)"
      using A2 tarski_def_1 sorry
    then have "y inHIDDENR3 rngFUNCT-1K2 p"
      using funct_4_th_101 sorry
    then have "rngFUNCT-1K2 p =XBOOLE-0R4 {TARSKIK1 y}"
      using A3 zfmisc_1_th_33 sorry
    thus "(<%AFINSQ-1K7 x%>)+~FUNCT-4K8(x,y) =FUNCT-1R1 <%AFINSQ-1K7 y%>"
      using A1 afinsq_1_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem afinsq_1_th_91:
" for I be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1 holds LastLocVALUED-1K65 I =XBOOLE-0R4 cardCARD-1K4 I -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for I be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1 holds LastLocVALUED-1K65 I =HIDDENR1 cardCARD-1K4 I -XCMPLX-0K6 \<one>\<^sub>M"
  proof(rule ballI)
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>XFinSequenceAFINSQ-1M1"
    have A1: "cardCARD-1K4 I >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have "LastLocVALUED-1K65 I =HIDDENR1 cardCARD-1K4 I -'NAT-DK9 \<one>\<^sub>M"
      using afinsq_1_th_70 sorry
    also have "... = cardCARD-1K4 I -XCMPLX-0K6 \<one>\<^sub>M"
      using A1 xreal_1_th_233 sorry
    finally show "LastLocVALUED-1K65 I =HIDDENR1 cardCARD-1K4 I -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
