theory partfun1
  imports relat_2 relset_1 grfunc_1
begin
(*begin*)
reserve x, x1, x2, y, y9, y1, y2, z, z1, z2 for "objectHIDDENM1"
reserve P, X, X1, X2, Y, Y1, Y2, V, Z for "setHIDDENM2"
mtheorem partfun1_th_1:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) implies f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. [TARSKIK4 Lamb1,Lamb2 ] inHIDDENR3 f \\/XBOOLE-0K2 g"
  have A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ?P(x,y1) & ?P(x,y2) implies y1 =HIDDENR1 y2"
  proof-
    have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 f \\/XBOOLE-0K2 g & [TARSKIK4 x,y2 ] inHIDDENR3 f \\/XBOOLE-0K2 g implies y1 =HIDDENR1 y2"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume A3: "[TARSKIK4 x,y1 ] inHIDDENR3 f \\/XBOOLE-0K2 g"
        and A4: "[TARSKIK4 x,y2 ] inHIDDENR3 f \\/XBOOLE-0K2 g"
      have "y1 =HIDDENR1 y2"
      proof-
        have "[TARSKIK4 x,y1 ] inHIDDENR3 f or [TARSKIK4 x,y1 ] inHIDDENR3 g"
          using A3 xboole_0_def_3 sorry
        then have A5: "x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =HIDDENR1 y1 or x inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =HIDDENR1 y1"
          using funct_1_th_1 sorry
        have A6: "[TARSKIK4 x,y2 ] inHIDDENR3 f or [TARSKIK4 x,y2 ] inHIDDENR3 g"
          using A4 xboole_0_def_3 sorry
        then have A7: "x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =HIDDENR1 y2 or x inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =HIDDENR1 y2"
          using funct_1_th_1 sorry
        show "y1 =HIDDENR1 y2"
        proof-
          have cases: "(x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 domRELAT-1K1 g or x inHIDDENR3 domRELAT-1K1 f &  not x inHIDDENR3 domRELAT-1K1 g) or  not x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 domRELAT-1K1 g"
            using A6 xtuple_0_def_12 sorry
          have case1: "x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 domRELAT-1K1 g implies y1 =HIDDENR1 y2"
          proof(rule impI)
            assume "x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 domRELAT-1K1 g"
            then have "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
              using xboole_0_def_4 sorry
            thus "y1 =HIDDENR1 y2"
              using A1 A5 A7 sorry
          qed
          have case2: "x inHIDDENR3 domRELAT-1K1 f &  not x inHIDDENR3 domRELAT-1K1 g implies y1 =HIDDENR1 y2"
          proof(rule impI)
            assume "x inHIDDENR3 domRELAT-1K1 f &  not x inHIDDENR3 domRELAT-1K1 g"
            thus "y1 =HIDDENR1 y2"
              using A6 A5 funct_1_th_1 sorry
          qed
          have case3: " not x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 domRELAT-1K1 g implies y1 =HIDDENR1 y2"
          proof(rule impI)
            assume " not x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 domRELAT-1K1 g"
            thus "y1 =HIDDENR1 y2"
              using A6 A5 funct_1_th_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed
      thus "y1 =HIDDENR1 y2"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  obtain h where
    [ty]:"h be FunctionFUNCT-1M1" and 
    A8: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 h iff x inHIDDENR3 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g & ?P(x,y)"
    using funct_1_sch_1 A2 sorry
  have "h =RELAT-1R1 f \\/XBOOLE-0K2 g"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 h implies [TARSKIK4 x,y ] inHIDDENR3 f \\/XBOOLE-0K2 g) & ([TARSKIK4 x,y ] inHIDDENR3 f \\/XBOOLE-0K2 g implies [TARSKIK4 x,y ] inHIDDENR3 h)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 h implies [TARSKIK4 x,y ] inHIDDENR3 f \\/XBOOLE-0K2 g"
        using A8 sorry
      assume A9: "[TARSKIK4 x,y ] inHIDDENR3 f \\/XBOOLE-0K2 g"
      have "[TARSKIK4 x,y ] inHIDDENR3 f or [TARSKIK4 x,y ] inHIDDENR3 g"
        using A9 xboole_0_def_3 sorry
      then have "x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 g"
        using xtuple_0_def_12 sorry
      then have "x inHIDDENR3 domRELAT-1K1 f \\/XBOOLE-0K2 domRELAT-1K1 g"
        using xboole_0_def_3 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 h"
        using A8 A9 sorry
    qed "sorry"
    thus "h =RELAT-1R1 f \\/XBOOLE-0K2 g"
      using relat_1_def_2 sorry
  qed
  thus "f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
     sorry
qed "sorry"

mtheorem partfun1_th_2:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds f \\/XBOOLE-0K2 g =RELAT-1R1 h implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix h assume [ty]: "h be FunctionFUNCT-1M1"
  assume A1: "f \\/XBOOLE-0K2 g =RELAT-1R1 h"
  fix x assume [ty]: "x be objectHIDDENM1"
  assume A2: "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
  then have "x inHIDDENR3 domRELAT-1K1 f"
    using xboole_0_def_4 sorry
  then have A3: "h .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    using A1 grfunc_1_th_15 sorry
  have "x inHIDDENR3 domRELAT-1K1 g"
    using A2 xboole_0_def_4 sorry
  thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    using A1 A3 grfunc_1_th_15 sorry
qed "sorry"

theorem partfun1_sch_1:
  fixes Af0 Ff1 Gf1 Cp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Cp1(Lamb1) implies Lamb2 =HIDDENR1 Ff1(Lamb1)) & ( not Cp1(Lamb1) implies Lamb2 =HIDDENR1 Gf1(Lamb1))"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Af0 & ( for y be objectHIDDENM1 holds  not ((Cp1(x) implies y =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies y =HIDDENR1 Gf1(x)))))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have " not Cp1(x) implies (Cp1(x) implies Gf1(x) =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies Gf1(x) =HIDDENR1 Gf1(x))"
           sorry
        thus " not (x inHIDDENR3 Af0 & ( for y be objectHIDDENM1 holds  not ((Cp1(x) implies y =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies y =HIDDENR1 Gf1(x)))))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Af0 & ?P(x,y1)) & ?P(x,y2) implies y1 =HIDDENR1 y2"
       sorry
    show " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
      using funct_1_sch_2 A2 A1 sorry
  qed

mlemma partfun1_lm_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  ex E be setHIDDENM2 st domRELAT-1K1 E c=RELAT-1R2 X & rngFUNCT-1K2 E c=RELAT-1R2 Y"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  obtain E where 
    [ty]:"E be setHIDDENM2" and EDef:"E = {}XBOOLE-0K1"
     sorry
  show " ex E be setHIDDENM2 st domRELAT-1K1 E c=RELAT-1R2 X & rngFUNCT-1K2 E c=RELAT-1R2 Y"
  proof(rule bexI[of _ "E"])
    show "domRELAT-1K1 E c=RELAT-1R2 X & rngFUNCT-1K2 E c=RELAT-1R2 Y"
       sorry
  qed "sorry"
qed "sorry"

mtheorem partfun1_cl_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster Function-likeFUNCT-1V1 for RelationRELSET-1M1-of(X,Y)"
proof
(*existence*)
  show " ex it be RelationRELSET-1M1-of(X,Y) st it be Function-likeFUNCT-1V1"
  proof-
    have " ex tVar2 be RelationRELSET-1M1-of(X,Y) st tVar2 be Function-likeFUNCT-1V1"
    proof-
      obtain E where
        [ty]:"E be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 E c=TARSKIR1 X & rngFUNCT-1K2 E c=TARSKIR1 Y"
        using partfun1_lm_1 sorry
      have 
        [ty]:"E be RelationRELSET-1M1-of(X,Y)"
        using A1 relset_1_th_4 sorry
      show " ex tVar2 be RelationRELSET-1M1-of(X,Y) st tVar2 be Function-likeFUNCT-1V1"
      proof(rule bexI[of _ "E"])
        show "E be Function-likeFUNCT-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) PARTFUN1M1("PartFuncPARTFUN1M1-of'( _ , _ ')" [0,0]70) where
  "PartFuncPARTFUN1M1-of(X,Y) \<equiv> Function-likeFUNCT-1V1\<bar>RelationRELSET-1M1-of(X,Y)"

mtheorem partfun1_th_3:
" for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be ElementSUBSET-1M1-of X st x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f & y =HIDDENR1 f .FUNCT-1K1 x)"
proof-
  have " for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds y inHIDDENR3 rngFUNCT-1K2 f implies  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f & y =HIDDENR1 f .FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    assume "y inHIDDENR3 rngFUNCT-1K2 f"
    then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & y =HIDDENR1 f .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    thus " not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f & y =HIDDENR1 f .FUNCT-1K1 x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_4:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 Y"
proof-
  have " for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
    assume "x inHIDDENR3 domRELAT-1K1 f"
    then have A1: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
      using funct_1_def_3 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 Y"
      using relat_1_def_19 sorry
    thus "f .FUNCT-1K1 x inTARSKIR2 Y"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X,Y) holds  for f2 be PartFuncPARTFUN1M1-of(X,Y) holds domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f2 & ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x) implies f1 =FUNCT-1R1 f2"
   sorry

theorem partfun1_sch_2:
  fixes Xf0 Yf0 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & Pp2(x,y) implies y inHIDDENR3 Yf0" and
   A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & Pp2(x,y1)) & Pp2(x,y2) implies y1 =HIDDENR1 y2"
  shows " ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies Pp2(x,f .FUNCT-1K1 x))"
  proof-
    have " not ( for f be PartFuncPARTFUN1M1-of(Xf0,Yf0) holds  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f &  not (x inHIDDENR3 Xf0 &  not ( for y be objectHIDDENM1 holds  not Pp2(x,y)))) &  not ((x inHIDDENR3 Xf0 &  not ( for y be objectHIDDENM1 holds  not Pp2(x,y))) &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f)) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f &  not Pp2(x,f .FUNCT-1K1 x)))))"
    proof-
      have A3: "Yf0 <>HIDDENR2 {}XBOOLE-0K1 implies ( ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies Pp2(x,f .FUNCT-1K1 x)))"
      proof(rule impI)
        let ?R = "\<lambda>Lamb1.  ex y be objectHIDDENM1 st Pp2(Lamb1,y)"
        let ?y1 = "the setHIDDENM2"
        assume "Yf0 <>HIDDENR2 {}XBOOLE-0K1"
        let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. (( ex y be objectHIDDENM1 st Pp2(Lamb1,y)) implies Pp2(Lamb1,Lamb2)) & (( for y be objectHIDDENM1 holds  not Pp2(Lamb1,y)) implies Lamb2 =HIDDENR1 ?y1)"
        have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex z be objectHIDDENM1 st ?Q(x,z))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies  not ( for z be objectHIDDENM1 holds  not ((( ex y be objectHIDDENM1 st Pp2(x,y)) implies Pp2(x,z)) & (( for y be objectHIDDENM1 holds  not Pp2(x,y)) implies z =HIDDENR1 the setHIDDENM2)))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Xf0"
            have "( for y be objectHIDDENM1 holds  not Pp2(x,y)) implies (( ex y be objectHIDDENM1 st Pp2(x,y)) implies Pp2(x,?y1)) & (( for y be objectHIDDENM1 holds  not Pp2(x,y)) implies ?y1 =XBOOLE-0R4 ?y1)"
               sorry
            thus " not ( for z be objectHIDDENM1 holds  not ((( ex y be objectHIDDENM1 st Pp2(x,y)) implies Pp2(x,z)) & (( for y be objectHIDDENM1 holds  not Pp2(x,y)) implies z =HIDDENR1 the setHIDDENM2)))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A5: " for x be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & ?Q(x,z1)) & ?Q(x,z2) implies z1 =HIDDENR1 z2"
          using A2 sorry
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A6: "domRELAT-1K1 g =XBOOLE-0R4 Xf0"and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ?Q(x,g .FUNCT-1K1 x)"
          using funct_1_sch_2 A5 A4 sorry
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A8: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Xf0 & ?R(x)"
          using xboole_0_sch_1 sorry
        let ?f = "g  |RELAT-1K8 X"
        have A9: "domRELAT-1K1 ?f c=TARSKIR1 Xf0"
          using A6 relat_1_th_60 sorry
        have "rngFUNCT-1K2 ?f c=TARSKIR1 Yf0"
        proof-
          have "rngFUNCT-1K2 (g  |RELAT-1K8 X) c=TARSKIR1 Yf0"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (g  |RELAT-1K8 X) implies y inHIDDENR3 Yf0"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 rngFUNCT-1K2 ?f"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A10: "x inHIDDENR3 domRELAT-1K1 ?f"and A11: "y =HIDDENR1 ?f .FUNCT-1K1 x"
                using funct_1_def_3 sorry
              have A12: "domRELAT-1K1 ?f c=TARSKIR1 X"
                using relat_1_th_58 sorry
              then have "x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))"
                using A8 A10 sorry
              then have "Pp2(x,g .FUNCT-1K1 x)"
                using A7 sorry
              then have A13: "Pp2(x,y)"
                using A10 A11 funct_1_th_47 sorry
              have "x inHIDDENR3 Xf0"
                using A8 A10 A12 sorry
              thus "y inHIDDENR3 Yf0"
                using A1 A13 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 (g  |RELAT-1K8 X) c=TARSKIR1 Yf0"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain f where 
          [ty]:"f be PartFuncPARTFUN1M1-of(Xf0,Yf0)" and fDef:"f = ?f"
          using A9 relset_1_th_4 sorry
        show " ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies Pp2(x,f .FUNCT-1K1 x))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
          show " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))"
          proof-
            have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))) & (x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f)"
            proof(rule ballI,rule conjMI,rule impMI ,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              have "domRELSET-1K1\<^bsub>(Xf0)\<^esub> f c=TARSKIR1 X"
                using relat_1_th_58 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))"
                using A8 sorry
              assume A14: "x inHIDDENR3 Xf0"
                and A15: " ex y be objectHIDDENM1 st Pp2(x,y)"
              have "x inHIDDENR3 X"
                using A8 A14 A15 sorry
              then have "x inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 X"
                using A6 A14 xboole_0_def_4 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f"
                using relat_1_th_61 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A16: "x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f"
          have "domRELSET-1K1\<^bsub>(Xf0)\<^esub> f c=TARSKIR1 X"
            using relat_1_th_58 sorry
          then have " ex y be objectHIDDENM1 st Pp2(x,y)"
            using A8 A16 sorry
          then have "Pp2(x,g .FUNCT-1K1 x)"
            using A7 A16 sorry
          thus "Pp2(x,f .FUNCT-1K1 x)"
            using A16 funct_1_th_47 sorry
        qed "sorry"
      qed
      have "Yf0 =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies Pp2(x,f .FUNCT-1K1 x)))"
      proof(rule impI)
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A17: "domRELAT-1K1 f c=TARSKIR1 Xf0 & rngFUNCT-1K2 f c=TARSKIR1 Yf0"
          using partfun1_lm_1 sorry
        have 
          [ty]:"f be PartFuncPARTFUN1M1-of(Xf0,Yf0)"
          using A17 relset_1_th_4 sorry
        assume A18: "Yf0 =XBOOLE-0R4 {}XBOOLE-0K1"
        show " ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies Pp2(x,f .FUNCT-1K1 x))"
        proof(rule bexI[of _ "f"],rule conjMI)
          show " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st Pp2(x,y))"
            using A1 A18 sorry
          show " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies Pp2(x,f .FUNCT-1K1 x)"
            using A18 sorry
        qed "sorry"
      qed
      thus " not ( for f be PartFuncPARTFUN1M1-of(Xf0,Yf0) holds  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f &  not (x inHIDDENR3 Xf0 &  not ( for y be objectHIDDENM1 holds  not Pp2(x,y)))) &  not ((x inHIDDENR3 Xf0 &  not ( for y be objectHIDDENM1 holds  not Pp2(x,y))) &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f)) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f &  not Pp2(x,f .FUNCT-1K1 x)))))"
        using A3 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem partfun1_sch_3:
  fixes Xf0 Yf0 Ff1 Pp1 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds Pp1(x) implies Ff1(x) inHIDDENR3 Yf0"
  shows " ex f be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & Pp1(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
  proof-
    have " ex tVar5 be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> tVar5 iff x inHIDDENR3 Xf0 & Pp1(x)) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> tVar5 &  not tVar5 .FUNCT-1K1 x =HIDDENR1 Ff1(x)))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. Pp1(Lamb1) & Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & ?Q(x,y1)) & ?Q(x,y2) implies y1 =HIDDENR1 y2"
         sorry
      have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & ?Q(x,y) implies y inHIDDENR3 Yf0"
        using A1 sorry
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(Xf0,Yf0)" and 
        A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & ( ex y be objectHIDDENM1 st ?Q(x,y))"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies ?Q(x,f .FUNCT-1K1 x)"
        using partfun1_sch_2 A3 A2 sorry
      show " ex tVar5 be PartFuncPARTFUN1M1-of(Xf0,Yf0) st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> tVar5 iff x inHIDDENR3 Xf0 & Pp1(x)) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> tVar5 &  not tVar5 .FUNCT-1K1 x =HIDDENR1 Ff1(x)))"
      proof(rule bexI[of _ "f"],rule conjMI)
        show " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f iff x inHIDDENR3 Xf0 & Pp1(x)"
        proof-
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies x inHIDDENR3 Xf0 & Pp1(x)) & (x inHIDDENR3 Xf0 & Pp1(x) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f)"
          proof(rule ballI,rule conjMI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f implies x inHIDDENR3 Xf0 & Pp1(x)"
            proof(rule impI)
              assume A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f"
              then have " ex y be objectHIDDENM1 st Pp1(x) & y =HIDDENR1 Ff1(x)"
                using A4 sorry
              thus "x inHIDDENR3 Xf0 & Pp1(x)"
                using A6 sorry
            qed
            assume A7: "x inHIDDENR3 Xf0"
              and A8: "Pp1(x)"
            have " ex y be objectHIDDENM1 st Pp1(x) & y =HIDDENR1 Ff1(x)"
              using A8 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f"
              using A4 A7 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(Xf0)\<^esub> f &  not f .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
          using A5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

syntax PARTFUN1K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *PARTFUN1K1\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "g *PARTFUN1K1\<^bsub>(X,Y,V,Z)\<^esub> f" \<rightharpoonup> "f *RELAT-1K6 g"

mtheorem partfun1_add_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "V be setHIDDENM2", "Z be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "g be PartFuncPARTFUN1M1-of(V,Z)"
"cluster f *RELAT-1K6 g as-term-is PartFuncPARTFUN1M1-of(X,Z)"
proof
(*coherence*)
  show "f *RELAT-1K6 g be PartFuncPARTFUN1M1-of(X,Z)"
  proof-
    have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> (g *FUNCT-1K3 f) c=TARSKIR1 X"
       sorry
    have "rngFUNCT-1K2 (g *FUNCT-1K3 f) c=TARSKIR1 Z"
      using relat_1_def_19 sorry
    thus "f *RELAT-1K6 g be PartFuncPARTFUN1M1-of(X,Z)"
      using A1 relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem partfun1_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,Y) holds idRELAT-1K7 X *RELAT-1K6 f =RELAT-1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,Y) holds idRELAT-1K7 X *RELAT-1K6 f =RELAT-1R1 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be RelationRELSET-1M1-of(X,Y)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f c=TARSKIR1 X"
       sorry
    thus "idRELAT-1K7 X *RELAT-1K6 f =RELAT-1R1 f"
      using relat_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,Y) holds f *RELAT-1K6 idRELAT-1K7 Y =RELAT-1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be RelationRELSET-1M1-of(X,Y) holds f *RELAT-1K6 idRELAT-1K7 Y =RELAT-1R1 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be RelationRELSET-1M1-of(X,Y)"
    have "rngRELSET-1K2\<^bsub>(Y)\<^esub> f c=TARSKIR1 Y"
       sorry
    thus "f *RELAT-1K6 idRELAT-1K7 Y =RELAT-1R1 f"
      using relat_1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds ( for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds (x1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f & x2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =XBOOLE-0R4 x2) implies f be one-to-oneFUNCT-1V2"
   sorry

mtheorem partfun1_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K4 be PartFuncPARTFUN1M1-of(Y,X)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K4 be PartFuncPARTFUN1M1-of(Y,X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have "rngFUNCT-1K2 f c=TARSKIR1 Y"
      using relat_1_def_19 sorry
    then have A2: "domRELAT-1K1 (f \<inverse>FUNCT-1K4) c=TARSKIR1 Y"
      using A1 funct_1_th_33 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f c=TARSKIR1 X"
       sorry
    then have "rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) c=TARSKIR1 X"
      using A1 funct_1_th_33 sorry
    thus "f \<inverse>FUNCT-1K4 be PartFuncPARTFUN1M1-of(Y,X)"
      using A2 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f  |RELSET-1K5\<^bsub>(X,Y)\<^esub> Z be PartFuncPARTFUN1M1-of(Z,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f  |RELSET-1K5\<^bsub>(X,Y)\<^esub> Z be PartFuncPARTFUN1M1-of(Z,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |RELSET-1K5\<^bsub>(X,Y)\<^esub> Z) c=TARSKIR1 Z & rngFUNCT-1K2 (f  |RELSET-1K5\<^bsub>(X,Y)\<^esub> Z) c=TARSKIR1 Y"
      using relat_1_th_58 relat_1_def_19 sorry
    thus "f  |RELSET-1K5\<^bsub>(X,Y)\<^esub> Z be PartFuncPARTFUN1M1-of(Z,Y)"
      using relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f  |RELSET-1K5\<^bsub>(X,Y)\<^esub> Z be PartFuncPARTFUN1M1-of(X,Y)"
   sorry

syntax PARTFUN1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |PARTFUN1K2\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "f  |PARTFUN1K2\<^bsub>(X,Y)\<^esub> Z" \<rightharpoonup> "f  |RELAT-1K8 Z"

mtheorem partfun1_add_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)", "Z be setHIDDENM2"
"cluster f  |RELAT-1K8 Z as-term-is PartFuncPARTFUN1M1-of(X,Y)"
proof
(*coherence*)
  show "f  |RELAT-1K8 Z be PartFuncPARTFUN1M1-of(X,Y)"
    using partfun1_th_11 sorry
qed "sorry"

mtheorem partfun1_th_12:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f be PartFuncPARTFUN1M1-of(X,Z)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f be PartFuncPARTFUN1M1-of(X,Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f) c=TARSKIR1 X & rngFUNCT-1K2 (Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f) c=TARSKIR1 Z"
      using relat_1_th_85 sorry
    thus "Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f be PartFuncPARTFUN1M1-of(X,Z)"
      using relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_13:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> f be PartFuncPARTFUN1M1-of(X,Y)"
   sorry

mtheorem partfun1_th_14:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f) |RELAT-1K8 X be PartFuncPARTFUN1M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f) |RELAT-1K8 X be PartFuncPARTFUN1M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "(Y  |`RELAT-1K9 f) |RELAT-1K8 X =FUNCT-1R1 Y  |`RELAT-1K9 (f  |RELAT-1K8 X)"
      using relat_1_th_109 sorry
    then have "domRELAT-1K1 ((Y  |`RELAT-1K9 f) |RELAT-1K8 X) c=TARSKIR1 X & rngFUNCT-1K2 ((Y  |`RELAT-1K9 f) |RELAT-1K8 X) c=TARSKIR1 Y"
      using relat_1_th_58 relat_1_th_85 sorry
    thus "(Y  |`RELAT-1K9 f) |RELAT-1K8 X be PartFuncPARTFUN1M1-of(X,Y)"
      using relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_15:
" for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds y inHIDDENR3 f .:FUNCT-1K5 X implies ( ex x be ElementSUBSET-1M1-of X st x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f & y =HIDDENR1 f .FUNCT-1K1 x)"
proof-
  have " for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds y inHIDDENR3 f .:FUNCT-1K5 X implies  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f & y =HIDDENR1 f .FUNCT-1K1 x))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    assume "y inHIDDENR3 f .:FUNCT-1K5 X"
    then have " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x"
      using funct_1_def_6 sorry
    thus " not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f & y =HIDDENR1 f .FUNCT-1K1 x))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_16:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y) holds rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
proof-
  have " for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y) holds rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y)"
    have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f =XBOOLE-0R4 {}XBOOLE-0K1 or domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f =XBOOLE-0R4 {TARSKIK1 x}"
      using zfmisc_1_th_33 sorry
    thus "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
      using funct_1_th_4 relat_1_th_42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_17:
" for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y) holds f be one-to-oneFUNCT-1V2"
proof-
  have " for x be objectHIDDENM1 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y) holds f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y)"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f implies  not (f .FUNCT-1K1 x1 =HIDDENR1 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A1: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f"
        and A2: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f"
      have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 implies x1 =HIDDENR1 x & x2 =HIDDENR1 x"
        using A1 A2 tarski_def_1 sorry
      thus " not (f .FUNCT-1K1 x1 =HIDDENR1 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
        using A1 sorry
    qed "sorry"
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_18:
" for x be objectHIDDENM1 holds  for P be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y) holds f .:FUNCT-1K5 P c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
proof-
  have " for x be objectHIDDENM1 holds  for P be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y) holds f .:FUNCT-1K5 P c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix P assume [ty]: "P be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of({TARSKIK1 x},Y)"
    have "f .:FUNCT-1K5 P c=TARSKIR1 rngFUNCT-1K2 f & rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
      using partfun1_th_16 relat_1_th_111 sorry
    thus "f .:FUNCT-1K5 P c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 x }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_19:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Y implies f be PartFuncPARTFUN1M1-of(X,Y)"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} & (x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Y) implies f be PartFuncPARTFUN1M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x}"
      and A2: "x inHIDDENR3 X"
      and A3: "f .FUNCT-1K1 x inTARSKIR2 Y"
    have "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
      using A1 funct_1_th_4 sorry
    then have A4: "rngFUNCT-1K2 f c=TARSKIR1 Y"
      using A3 zfmisc_1_th_31 sorry
    have "domRELAT-1K1 f c=TARSKIR1 X"
      using A1 A2 zfmisc_1_th_31 sorry
    thus "f be PartFuncPARTFUN1M1-of(X,Y)"
      using A4 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_20:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies f .FUNCT-1K1 x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds  not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y})"
    have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 y}"
      using partfun1_th_4 sorry
    thus " not (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not f .FUNCT-1K1 x =HIDDENR1 y)"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_21:
" for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds  for f2 be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f2 implies f1 =FUNCT-1R1 f2"
proof-
  have " for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds  for f2 be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f2 implies f1 =FUNCT-1R1 f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y})"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y})"
    assume A1: "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f1 implies f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f1"
      then have "f1 .FUNCT-1K1 x =HIDDENR1 y"
        using partfun1_th_20 sorry
      thus "f1 .FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 x"
        using A1 A2 partfun1_th_20 sorry
    qed "sorry"
    thus "f1 =FUNCT-1R1 f2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partfun1_def_1 ("<:PARTFUN1K3 _ , _ , _ :>" [0,0,0]164 ) where
  mlet "f be FunctionFUNCT-1M1", "X be setHIDDENM2", "Y be setHIDDENM2"
"func <:PARTFUN1K3 f,X,Y :> \<rightarrow> PartFuncPARTFUN1M1-of(X,Y) equals
  (Y  |`RELAT-1K9 f) |RELAT-1K8 X"
proof-
  (*coherence*)
    show "(Y  |`RELAT-1K9 f) |RELAT-1K8 X be PartFuncPARTFUN1M1-of(X,Y)"
      using partfun1_th_14 sorry
qed "sorry"

mtheorem partfun1_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds <:PARTFUN1K3 f,X,Y :> c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds <:PARTFUN1K3 f,X,Y :> c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "(Y  |`RELAT-1K9 f) |RELAT-1K8 X c=RELAT-1R2 Y  |`RELAT-1K9 f & Y  |`RELAT-1K9 f c=RELAT-1R2 f"
      using relat_1_th_59 relat_1_th_86 sorry
    thus "<:PARTFUN1K3 f,X,Y :> c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_23:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 rngFUNCT-1K2 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "<:PARTFUN1K3 f,X,Y :> c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
      using partfun1_th_22 sorry
    thus "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 rngFUNCT-1K2 f"
      using relat_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_24:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) iff (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Y"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) implies (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Y) & (x inHIDDENR3 domRELAT-1K1 f & (x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Y) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) implies (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Y"
    proof(rule impI)
      assume A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      then have "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)"
        using xboole_0_def_4 sorry
      thus "(x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Y"
        using A1 funct_1_th_54 sorry
    qed
    assume A2: "x inHIDDENR3 domRELAT-1K1 f"
      and A3: "x inHIDDENR3 X"
      and A4: "f .FUNCT-1K1 x inTARSKIR2 Y"
    have "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)"
      using A2 A4 funct_1_th_54 sorry
    then have "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f) /\\XBOOLE-0K3 X"
      using A3 xboole_0_def_4 sorry
    thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      using relat_1_th_61 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_25:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & f .FUNCT-1K1 x inTARSKIR2 Y implies (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & (x inHIDDENR3 X & f .FUNCT-1K1 x inTARSKIR2 Y) implies (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
      and A2: "x inHIDDENR3 X"
      and A3: "f .FUNCT-1K1 x inTARSKIR2 Y"
    have "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)"
      using A1 A3 funct_1_th_54 sorry
    then have "f .FUNCT-1K1 x =HIDDENR1 (Y  |`RELAT-1K9 f).FUNCT-1K1 x"
      using funct_1_th_55 sorry
    also have "... = ((Y  |`RELAT-1K9 f) |RELAT-1K8 X).FUNCT-1K1 x"
      using A2 funct_1_th_49 sorry
    finally have "f .FUNCT-1K1 x =HIDDENR1 ((Y  |`RELAT-1K9 f) |RELAT-1K8 X).FUNCT-1K1 x"
       sorry
    thus "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_26:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) implies (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) implies (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
    then have "x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
      using partfun1_th_24 sorry
    thus "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A1 partfun1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_27:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies <:PARTFUN1K3 f,X,Y :> c=RELSET-1R1\<^bsub>(X,Y)\<^esub> <:PARTFUN1K3 g,X,Y :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies <:PARTFUN1K3 f,X,Y :> c=RELSET-1R1\<^bsub>(X,Y)\<^esub> <:PARTFUN1K3 g,X,Y :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f c=RELAT-1R2 g"
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELAT-1K1 f"
      using partfun1_th_23 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g,X,Y :>) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) implies (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 g,X,Y :>).FUNCT-1K1 x)"
    proof(rule conjMI,rule ballI,rule impI)
      show A3: "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g,X,Y :>)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g,X,Y :>)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have A4: "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
            using A1 relat_1_th_11 sorry
          assume A5: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          then have A6: "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
            using A1 A2 grfunc_1_th_2 sorry
          have "x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
            using A5 partfun1_th_24 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g,X,Y :>)"
            using A5 A4 A6 partfun1_th_24 sorry
        qed "sorry"
        thus "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g,X,Y :>)"
          using tarski_def_3 sorry
      qed
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      then have A8: "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using partfun1_th_26 sorry
      have "(<:PARTFUN1K3 g,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A3 A7 partfun1_th_26 sorry
      thus "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 g,X,Y :>).FUNCT-1K1 x"
        using A1 A2 A7 A8 grfunc_1_th_2 sorry
    qed "sorry"
    thus "<:PARTFUN1K3 f,X,Y :> c=RELSET-1R1\<^bsub>(X,Y)\<^esub> <:PARTFUN1K3 g,X,Y :>"
      using grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_28:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Z c=TARSKIR1 X implies <:PARTFUN1K3 f,Z,Y :> c=RELSET-1R1\<^bsub>(Z,Y)\<^esub> <:PARTFUN1K3 f,X,Y :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Z c=TARSKIR1 X implies <:PARTFUN1K3 f,Z,Y :> c=RELSET-1R1\<^bsub>(Z,Y)\<^esub> <:PARTFUN1K3 f,X,Y :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "Z c=TARSKIR1 X"
    have A2: "domRELSET-1K1\<^bsub>(Z)\<^esub> (<:PARTFUN1K3 f,Z,Y :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Z)\<^esub> (<:PARTFUN1K3 f,Z,Y :>) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(Z)\<^esub> (<:PARTFUN1K3 f,Z,Y :>)"
        then have A4: "f .FUNCT-1K1 x inTARSKIR2 Y"
          using partfun1_th_24 sorry
        have "x inHIDDENR3 Z & x inHIDDENR3 domRELAT-1K1 f"
          using A3 partfun1_th_24 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using A1 A4 partfun1_th_24 sorry
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(Z)\<^esub> (<:PARTFUN1K3 f,Z,Y :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Z)\<^esub> (<:PARTFUN1K3 f,Z,Y :>) implies (<:PARTFUN1K3 f,Z,Y :>).FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 domRELSET-1K1\<^bsub>(Z)\<^esub> (<:PARTFUN1K3 f,Z,Y :>)"
      then have "(<:PARTFUN1K3 f,Z,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using partfun1_th_26 sorry
      thus "(<:PARTFUN1K3 f,Z,Y :>).FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x"
        using A2 A5 partfun1_th_26 sorry
    qed "sorry"
    thus "<:PARTFUN1K3 f,Z,Y :> c=RELSET-1R1\<^bsub>(Z,Y)\<^esub> <:PARTFUN1K3 f,X,Y :>"
      using A2 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_29:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Z c=TARSKIR1 Y implies <:PARTFUN1K3 f,X,Z :> c=RELSET-1R1\<^bsub>(X,Z)\<^esub> <:PARTFUN1K3 f,X,Y :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Z c=TARSKIR1 Y implies <:PARTFUN1K3 f,X,Z :> c=RELSET-1R1\<^bsub>(X,Z)\<^esub> <:PARTFUN1K3 f,X,Y :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "Z c=TARSKIR1 Y"
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Z :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Z :>) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Z :>)"
        then have "f .FUNCT-1K1 x inTARSKIR2 Z & x inHIDDENR3 domRELAT-1K1 f"
          using partfun1_th_24 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using A1 A3 partfun1_th_24 sorry
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Z :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Z :>) implies (<:PARTFUN1K3 f,X,Z :>).FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Z :>)"
      then have "(<:PARTFUN1K3 f,X,Z :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using partfun1_th_26 sorry
      thus "(<:PARTFUN1K3 f,X,Z :>).FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x"
        using A2 A4 partfun1_th_26 sorry
    qed "sorry"
    thus "<:PARTFUN1K3 f,X,Z :> c=RELSET-1R1\<^bsub>(X,Z)\<^esub> <:PARTFUN1K3 f,X,Y :>"
      using A2 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_30:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies <:PARTFUN1K3 f,X1,Y1 :> c=RELSET-1R1\<^bsub>(X1,Y1)\<^esub> <:PARTFUN1K3 f,X2,Y2 :>"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies <:PARTFUN1K3 f,X1,Y1 :> c=RELSET-1R1\<^bsub>(X1,Y1)\<^esub> <:PARTFUN1K3 f,X2,Y2 :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2"
    then have "<:PARTFUN1K3 f,X1,Y1 :> c=RELSET-1R1\<^bsub>(X1,Y1)\<^esub> <:PARTFUN1K3 f,X2,Y1 :> & <:PARTFUN1K3 f,X2,Y1 :> c=RELSET-1R1\<^bsub>(X2,Y1)\<^esub> <:PARTFUN1K3 f,X2,Y2 :>"
      using partfun1_th_28 partfun1_th_29 sorry
    thus "<:PARTFUN1K3 f,X1,Y1 :> c=RELSET-1R1\<^bsub>(X1,Y1)\<^esub> <:PARTFUN1K3 f,X2,Y2 :>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_31:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y implies f =FUNCT-1R1 <:PARTFUN1K3 f,X,Y :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y implies f =FUNCT-1R1 <:PARTFUN1K3 f,X,Y :>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y"
    have A2: "domRELAT-1K1 f c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 domRELAT-1K1 f"
        then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
          using funct_1_def_3 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using A1 A3 partfun1_th_24 sorry
      qed "sorry"
      thus "domRELAT-1K1 f c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
        using tarski_def_3 sorry
    qed
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELAT-1K1 f"
      using partfun1_th_23 sorry
    then have A4: "domRELAT-1K1 f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      using A2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x"
      using A2 partfun1_th_26 sorry
    thus "f =FUNCT-1R1 <:PARTFUN1K3 f,X,Y :>"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_32:
" for f be FunctionFUNCT-1M1 holds f =FUNCT-1R1 <:PARTFUN1K3 f,domRELAT-1K1 f,rngFUNCT-1K2 f :>"
   sorry

mtheorem partfun1_th_33:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds <:PARTFUN1K3 f,X,Y :> =FUNCT-1R1 f"
   sorry

mtheorem partfun1_th_34:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds <:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds <:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 X & rngFUNCT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 Y"
       sorry
    thus "<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> =FUNCT-1R1 {}XBOOLE-0K1"
      using partfun1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_35:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=RELSET-1R1\<^bsub>(X,Z)\<^esub> <:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=RELSET-1R1\<^bsub>(X,Z)\<^esub> <:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)) implies ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x =XBOOLE-0R4 (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)) implies ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x =HIDDENR1 (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>))"
        then have A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using funct_1_th_11 sorry
        then have A4: "x inHIDDENR3 domRELAT-1K1 f"
          using partfun1_th_24 sorry
        have "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 g,Y,Z :>)"
          using A2 funct_1_th_11 sorry
        then have A5: "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 g,Y,Z :>)"
          using A3 partfun1_th_26 sorry
        then have "g .FUNCT-1K1 (f .FUNCT-1K1 x) inTARSKIR2 Z"
          using partfun1_th_24 sorry
        then have A6: "(g *FUNCT-1K3 f).FUNCT-1K1 x inTARSKIR2 Z"
          using A4 funct_1_th_13 sorry
        have "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
          using A5 partfun1_th_24 sorry
        then have "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
          using A4 funct_1_th_11 sorry
        then have A7: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>)"
          using A2 A6 partfun1_th_24 sorry
        have "((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x =HIDDENR1 (<:PARTFUN1K3 g,Y,Z :>).FUNCT-1K1 ((<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x)"
          using A2 funct_1_th_12 sorry
        also have "... = (<:PARTFUN1K3 g,Y,Z :>).FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A3 partfun1_th_26 sorry
        also have "... = g .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A5 partfun1_th_26 sorry
        also have "... = (g *FUNCT-1K3 f).FUNCT-1K1 x"
          using A4 funct_1_th_13 sorry
        also have "... = (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x"
          using A7 partfun1_th_26 sorry
        finally show "((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x =HIDDENR1 (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A8: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>))"
        then have A9: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using funct_1_th_11 sorry
        then have A10: "x inHIDDENR3 domRELAT-1K1 f"
          using partfun1_th_24 sorry
        have "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 g,Y,Z :>)"
          using A8 funct_1_th_11 sorry
        then have A11: "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 g,Y,Z :>)"
          using A9 partfun1_th_26 sorry
        then have "g .FUNCT-1K1 (f .FUNCT-1K1 x) inTARSKIR2 Z"
          using partfun1_th_24 sorry
        then have A12: "(g *FUNCT-1K3 f).FUNCT-1K1 x inTARSKIR2 Z"
          using A10 funct_1_th_13 sorry
        have "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
          using A11 partfun1_th_24 sorry
        then have "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
          using A10 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>)"
          using A8 A12 partfun1_th_24 sorry
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>)"
        using tarski_def_3 sorry
    qed
    thus "(<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=RELSET-1R1\<^bsub>(X,Z)\<^esub> <:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>"
      using A1 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_36:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f /\\XBOOLE-0K3 domRELAT-1K1 g c=TARSKIR1 Y implies (<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =FUNCT-1R1 <:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f /\\XBOOLE-0K3 domRELAT-1K1 g c=TARSKIR1 Y implies (<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =FUNCT-1R1 <:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f /\\XBOOLE-0K3 domRELAT-1K1 g c=TARSKIR1 Y"
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>)"
        then have A4: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
          using partfun1_th_24 sorry
        then have A5: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
          using funct_1_th_11 sorry
        have A6: "x inHIDDENR3 domRELAT-1K1 f"
          using A4 funct_1_th_11 sorry
        then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
          using funct_1_def_3 sorry
        then have A7: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f /\\XBOOLE-0K3 domRELAT-1K1 g"
          using A5 xboole_0_def_4 sorry
        have "(g *FUNCT-1K3 f).FUNCT-1K1 x inTARSKIR2 Z"
          using A3 partfun1_th_24 sorry
        then have "g .FUNCT-1K1 (f .FUNCT-1K1 x) inTARSKIR2 Z"
          using A4 funct_1_th_12 sorry
        then have A8: "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 g,Y,Z :>)"
          using A1 A5 A7 partfun1_th_24 sorry
        have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) & (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
          using A1 A3 A6 A7 partfun1_th_24 partfun1_th_25 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>))"
          using A8 funct_1_th_11 sorry
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>) c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>))"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>) implies (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x =XBOOLE-0R4 ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>) implies (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x =HIDDENR1 ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A9: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>)"
        then have A10: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
          using partfun1_th_24 sorry
        then have A11: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
          using funct_1_th_11 sorry
        have "x inHIDDENR3 domRELAT-1K1 f"
          using A10 funct_1_th_11 sorry
        then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
          using funct_1_def_3 sorry
        then have A12: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f /\\XBOOLE-0K3 domRELAT-1K1 g"
          using A11 xboole_0_def_4 sorry
        have "(g *FUNCT-1K3 f).FUNCT-1K1 x inTARSKIR2 Z"
          using A9 partfun1_th_24 sorry
        then have "g .FUNCT-1K1 (f .FUNCT-1K1 x) inTARSKIR2 Z"
          using A10 funct_1_th_12 sorry
        then have A13: "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 g,Y,Z :>)"
          using A1 A11 A12 partfun1_th_24 sorry
        have "x inHIDDENR3 domRELAT-1K1 f"
          using A10 funct_1_th_11 sorry
        then have A14: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using A1 A9 A12 partfun1_th_24 sorry
        have "(<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x =HIDDENR1 (g *FUNCT-1K3 f).FUNCT-1K1 x"
          using A9 partfun1_th_26 sorry
        also have "... = g .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A10 funct_1_th_12 sorry
        also have "... = (<:PARTFUN1K3 g,Y,Z :>).FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A13 partfun1_th_26 sorry
        also have "... = (<:PARTFUN1K3 g,Y,Z :>).FUNCT-1K1 ((<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x)"
          using A14 partfun1_th_26 sorry
        also have "... = ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x"
          using A2 A9 funct_1_th_12 sorry
        finally show "(<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>).FUNCT-1K1 x =HIDDENR1 ((<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A15: "<:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :> c=RELSET-1R1\<^bsub>(X,Z)\<^esub> (<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      using A2 grfunc_1_th_2 sorry
    have "(<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=RELSET-1R1\<^bsub>(X,Z)\<^esub> <:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>"
      using partfun1_th_35 sorry
    thus "(<:PARTFUN1K3 g,Y,Z :>)*PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =FUNCT-1R1 <:PARTFUN1K3 g *FUNCT-1K3 f,X,Z :>"
      using A15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_37:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies <:PARTFUN1K3 f,X,Y :> be one-to-oneFUNCT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies <:PARTFUN1K3 f,X,Y :> be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "f be one-to-oneFUNCT-1V2"
    then have "Y  |`RELAT-1K9 f be one-to-oneFUNCT-1V2"
      using funct_1_th_58 sorry
    thus "<:PARTFUN1K3 f,X,Y :> be one-to-oneFUNCT-1V2"
      using funct_1_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_38:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies (<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4 =FUNCT-1R1 <:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies (<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4 =FUNCT-1R1 <:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    then have A2: "<:PARTFUN1K3 f,X,Y :> be one-to-oneFUNCT-1V2"
      using partfun1_th_37 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 ((<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4) iff y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>)"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 domRELAT-1K1 ((<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4) implies y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>)) & (y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>) implies y inHIDDENR3 domRELAT-1K1 ((<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4))"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 domRELAT-1K1 ((<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4) implies y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>)"
        proof(rule impI)
          assume "y inHIDDENR3 domRELAT-1K1 ((<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4)"
          then have A3: "y inHIDDENR3 rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>)"
            using A2 funct_1_th_33 sorry
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"and A5: "y =HIDDENR1 (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x"
            using funct_1_def_3 sorry
          have A6: "f .FUNCT-1K1 x =HIDDENR1 y"
            using A4 A5 partfun1_th_26 sorry
          then have A7: "y inHIDDENR3 Y"
            using A4 partfun1_th_24 sorry
          have "rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 rngFUNCT-1K2 f"
            using partfun1_th_23 sorry
          then have "y inHIDDENR3 rngFUNCT-1K2 f"
            using A3 sorry
          then have A8: "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
            using A1 funct_1_th_32 sorry
          have "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 domRELAT-1K1 f"
            using partfun1_th_23 sorry
          then have "f \<inverse>FUNCT-1K4 .FUNCT-1K1 y =HIDDENR1 x"
            using A1 A4 A6 funct_1_th_32 sorry
          thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>)"
            using A4 A8 A7 partfun1_th_24 sorry
        qed
        assume A9: "y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>)"
        have "domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>) c=TARSKIR1 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
          using partfun1_th_23 sorry
        then have "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
          using A9 sorry
        then have "y inHIDDENR3 rngFUNCT-1K2 f"
          using A1 funct_1_th_33 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A10: "x inHIDDENR3 domRELAT-1K1 f"and A11: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have "x =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A1 A10 funct_1_th_34 sorry
        then have "x inHIDDENR3 X"
          using A9 A11 partfun1_th_24 sorry
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using A9 A10 A11 partfun1_th_24 sorry
        then have "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>) & (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
          using partfun1_th_26 funct_1_def_3 sorry
        thus "y inHIDDENR3 domRELAT-1K1 ((<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4)"
          using A2 A11 funct_1_th_33 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A12: "domRELAT-1K1 ((<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>)"
      using tarski_th_2 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>) implies (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>).FUNCT-1K1 y =XBOOLE-0R4 (<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4 .FUNCT-1K1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      have A13: "rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 rngFUNCT-1K2 f"
        using partfun1_th_23 sorry
      assume A14: "y inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>)"
      then have "y inHIDDENR3 rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>)"
        using A2 A12 funct_1_th_33 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A15: "x inHIDDENR3 domRELAT-1K1 f"and A16: "y =HIDDENR1 f .FUNCT-1K1 x"
        using A13 funct_1_def_3 sorry
      have A17: "x =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x)"
        using A1 A15 funct_1_th_34 sorry
      then have "x inHIDDENR3 X"
        using A14 A16 partfun1_th_24 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
        using A14 A15 A16 partfun1_th_24 sorry
      then have "(<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4 .FUNCT-1K1 ((<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x) =HIDDENR1 x & (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A2 partfun1_th_26 funct_1_th_34 sorry
      thus "(<:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>).FUNCT-1K1 y =XBOOLE-0R4 (<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4 .FUNCT-1K1 y"
        using A14 A16 A17 partfun1_th_26 sorry
    qed "sorry"
    thus "(<:PARTFUN1K3 f,X,Y :>)\<inverse>FUNCT-1K4 =FUNCT-1R1 <:PARTFUN1K3 f \<inverse>FUNCT-1K4,Y,X :>"
      using A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_39:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =FUNCT-1R1 <:PARTFUN1K3 f,X,Z /\\XBOOLE-0K3 Y :>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =HIDDENR1 <:PARTFUN1K3 f,X,Z /\\XBOOLE-0K3 Y :>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =HIDDENR1 Z  |`RELAT-1K9 (Y  |`RELAT-1K9 (f  |RELAT-1K8 X))"
      using relat_1_th_109 sorry
    also have "... = (Z /\\XBOOLE-0K3 Y) |`RELAT-1K9 (f  |RELAT-1K8 X)"
      using relat_1_th_96 sorry
    also have "... = <:PARTFUN1K3 f,X,Z /\\XBOOLE-0K3 Y :>"
      using relat_1_th_109 sorry
    finally show "Z  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =HIDDENR1 <:PARTFUN1K3 f,X,Z /\\XBOOLE-0K3 Y :>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partfun1_def_2 ("totalPARTFUN1V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr totalPARTFUN1V1\<^bsub>(X)\<^esub> for X -definedRELAT-1V4\<bar>RelationRELAT-1M1 means
  (\<lambda>f. domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X)"..

mtheorem partfun1_cl_2:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be setHIDDENM2"
"cluster note-that totalPARTFUN1V1\<^bsub>(X)\<^esub> for RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(X,Y) holds it be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem partfun1_cl_3:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non totalPARTFUN1V1\<^bsub>(X)\<^esub> for RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(X,Y) holds it be  non totalPARTFUN1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem partfun1_th_40:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds <:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies X c=TARSKIR1 domRELAT-1K1 f"
  using partfun1_th_23 sorry

mtheorem partfun1_th_41:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds <:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub> &  not X =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "domRELAT-1K1 ({}XBOOLE-0K1) =FUNCT-1R1 {}XBOOLE-0K1"
       sorry
    thus " not (<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub> &  not X =XBOOLE-0R4 {}XBOOLE-0K1)"
      using partfun1_th_40 xboole_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_42:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 f c=TARSKIR1 Y implies <:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 f c=TARSKIR1 Y implies <:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 f"
      and A2: "rngFUNCT-1K2 f c=TARSKIR1 Y"
    have Cut895: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 X"
        then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
          using A1 funct_1_def_3 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using A1 A2 A3 partfun1_th_24 sorry
      qed "sorry"
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
        using tarski_def_3 sorry
    qed
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =XBOOLE-0R4 X"
    proof-
      show "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =XBOOLE-0R4 X"
        using Cut895 sorry
    qed
    thus "<:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_43:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds <:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies f .:FUNCT-1K5 X c=TARSKIR1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  not (<:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub> &  not f .:FUNCT-1K5 X c=TARSKIR1 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =XBOOLE-0R4 X implies f .:FUNCT-1K5 X c=TARSKIR1 Y"
    proof(rule impI)
      assume A1: "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =XBOOLE-0R4 X"
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 X implies y inHIDDENR3 Y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        have A2: "rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>) c=TARSKIR1 Y"
          using relat_1_def_19 sorry
        assume "y inHIDDENR3 f .:FUNCT-1K5 X"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          "x inHIDDENR3 domRELAT-1K1 f"and A3: "x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        have "(<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x =HIDDENR1 y & (<:PARTFUN1K3 f,X,Y :>).FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (<:PARTFUN1K3 f,X,Y :>)"
          using A1 A3 partfun1_th_26 funct_1_def_3 sorry
        thus "y inHIDDENR3 Y"
          using A2 sorry
      qed "sorry"
      thus "f .:FUNCT-1K5 X c=TARSKIR1 Y"
        using tarski_def_3 sorry
    qed
    thus " not (<:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub> &  not f .:FUNCT-1K5 X c=TARSKIR1 Y)"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_44:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f .:FUNCT-1K5 X c=TARSKIR1 Y implies <:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f .:FUNCT-1K5 X c=TARSKIR1 Y implies <:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f .:FUNCT-1K5 X c=TARSKIR1 Y"
    have Cut927: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 X"
        then have "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
          using A1 funct_1_def_6 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
          using A1 A2 A3 partfun1_th_24 sorry
      qed "sorry"
      thus "X c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>)"
        using tarski_def_3 sorry
    qed
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =XBOOLE-0R4 X"
    proof-
      show "domRELSET-1K1\<^bsub>(X)\<^esub> (<:PARTFUN1K3 f,X,Y :>) =XBOOLE-0R4 X"
        using Cut927 sorry
    qed
    thus "<:PARTFUN1K3 f,X,Y :> be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partfun1_def_3 ("PFuncsPARTFUN1K4'( _ , _ ')" [0,0]228 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"func PFuncsPARTFUN1K4(X,Y) \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
    proof-
      have " ex tVar6 be setHIDDENM2 st  for z be objectHIDDENM1 holds (z inHIDDENR3 tVar6 implies ( ex f be FunctionFUNCT-1M1 st (z =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & (( ex f be FunctionFUNCT-1M1 st z =HIDDENR1 f & (domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies z inHIDDENR3 tVar6)"
      proof-
        let ?P = "\<lambda>Lamb1.  ex f be FunctionFUNCT-1M1 st (Lamb1 =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y"
        obtain F where
          [ty]:"F be setHIDDENM2" and 
          A1: " for z be objectHIDDENM1 holds z inHIDDENR3 F iff z inHIDDENR3 boolZFMISC-1K1 ([:ZFMISC-1K2 X,Y :]) & ?P(z)"
          using xboole_0_sch_1 sorry
        show " ex tVar6 be setHIDDENM2 st  for z be objectHIDDENM1 holds (z inHIDDENR3 tVar6 implies ( ex f be FunctionFUNCT-1M1 st (z =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & (( ex f be FunctionFUNCT-1M1 st z =HIDDENR1 f & (domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies z inHIDDENR3 tVar6)"
        proof(rule bexI[of _ "F"],rule ballI,rule conjMI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          show "z inHIDDENR3 F implies ( ex f be FunctionFUNCT-1M1 st (z =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
            using A1 sorry
          assume Given: " ex f be FunctionFUNCT-1M1 st z =HIDDENR1 f & (domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y)"
          then obtain f where
            [ty]:"f be FunctionFUNCT-1M1" and 
            A2: "z =HIDDENR1 f"and A3: "domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y"
             sorry
          have "f c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
          proof-
            have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
            proof(rule ballI,rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A4: "[TARSKIK4 x,y ] inHIDDENR3 f"
              have 
                [ty]:"y be setHIDDENM2"
                using tarski_th_1 sorry
              have A5: "x inHIDDENR3 domRELAT-1K1 f"
                using xtuple_0_def_12 A4 sorry
              then have "y =XBOOLE-0R4 f .FUNCT-1K1 x"
                using A4 funct_1_def_2 sorry
              then have "y inTARSKIR2 rngFUNCT-1K2 f"
                using A5 funct_1_def_3 sorry
              thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
                using A3 A5 zfmisc_1_def_2 sorry
            qed "sorry"
            thus "f c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
              using relat_1_def_3 sorry
          qed
          thus "z inHIDDENR3 F"
            using A1 A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies it1 =HIDDENR1 it2"
    proof-
      have " for F1 be setHIDDENM2 holds  for F2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 F2 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies F1 =HIDDENR1 F2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix F1 assume [ty]: "F1 be setHIDDENM2"
        fix F2 assume [ty]: "F2 be setHIDDENM2"
        assume A6: " for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
          and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 F2 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff x inHIDDENR3 F2"
        proof-
          have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 F1 &  not x inHIDDENR3 F2) &  not (x inHIDDENR3 F2 &  not x inHIDDENR3 F1)"
          proof(rule ballI)
            fix x assume [ty]: "x be objectHIDDENM1"
            have "x inHIDDENR3 F1 iff ( ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
              using A6 sorry
            thus " not (x inHIDDENR3 F1 &  not x inHIDDENR3 F2) &  not (x inHIDDENR3 F2 &  not x inHIDDENR3 F1)"
              using A7 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "F1 =HIDDENR1 F2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem partfun1_cl_4:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be  non emptyXBOOLE-0V1"
  proof-
    have " not PFuncsPARTFUN1K4(X,Y) be emptyXBOOLE-0V1"
    proof-
      have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y"
        using partfun1_lm_1 sorry
      thus " not PFuncsPARTFUN1K4(X,Y) be emptyXBOOLE-0V1"
        using partfun1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem partfun1_th_45:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f c=TARSKIR1 X & rngFUNCT-1K2 f c=TARSKIR1 Y"
      using relat_1_def_19 sorry
    thus "f inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
      using partfun1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_46:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be setHIDDENM2 holds f inTARSKIR2 PFuncsPARTFUN1K4(X,Y) implies f be PartFuncPARTFUN1M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be setHIDDENM2 holds f inTARSKIR2 PFuncsPARTFUN1K4(X,Y) implies f be PartFuncPARTFUN1M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be setHIDDENM2"
    assume "f inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
    then have " ex F be FunctionFUNCT-1M1 st (f =XBOOLE-0R4 F & domRELAT-1K1 F c=TARSKIR1 X) & rngFUNCT-1K2 F c=TARSKIR1 Y"
      using partfun1_def_3 sorry
    thus "f be PartFuncPARTFUN1M1-of(X,Y)"
      using relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_47:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(X,Y) holds f be PartFuncPARTFUN1M1-of(X,Y)"
  using partfun1_th_46 sorry

mtheorem partfun1_th_48:
" for Y be setHIDDENM2 holds PFuncsPARTFUN1K4({}XBOOLE-0K1,Y) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for Y be setHIDDENM2 holds PFuncsPARTFUN1K4({}XBOOLE-0K1,Y) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 PFuncsPARTFUN1K4({}XBOOLE-0K1,Y) iff x =HIDDENR1 {}XBOOLE-0K1"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 PFuncsPARTFUN1K4({}XBOOLE-0K1,Y) implies x =HIDDENR1 {}XBOOLE-0K1) &  not (x =HIDDENR1 {}XBOOLE-0K1 &  not x inHIDDENR3 PFuncsPARTFUN1K4({}XBOOLE-0K1,Y))"
      proof(rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 PFuncsPARTFUN1K4({}XBOOLE-0K1,Y) implies x =HIDDENR1 {}XBOOLE-0K1"
        proof(rule impI)
          assume "x inHIDDENR3 PFuncsPARTFUN1K4({}XBOOLE-0K1,Y)"
          then have "x be PartFuncPARTFUN1M1-of({}XBOOLE-0K1,Y)"
            using partfun1_th_46 sorry
          thus "x =HIDDENR1 {}XBOOLE-0K1"
             sorry
        qed
        have "{}XBOOLE-0K1 be PartFuncPARTFUN1M1-of({}XBOOLE-0K1,Y)"
          using relset_1_th_12 sorry
        thus " not (x =HIDDENR1 {}XBOOLE-0K1 &  not x inHIDDENR3 PFuncsPARTFUN1K4({}XBOOLE-0K1,Y))"
          using partfun1_th_45 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "PFuncsPARTFUN1K4({}XBOOLE-0K1,Y) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_49:
" for X be setHIDDENM2 holds PFuncsPARTFUN1K4(X,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  have " for X be setHIDDENM2 holds PFuncsPARTFUN1K4(X,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 PFuncsPARTFUN1K4(X,{}XBOOLE-0K1) iff x =HIDDENR1 {}XBOOLE-0K1"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 PFuncsPARTFUN1K4(X,{}XBOOLE-0K1) implies x =HIDDENR1 {}XBOOLE-0K1) &  not (x =HIDDENR1 {}XBOOLE-0K1 &  not x inHIDDENR3 PFuncsPARTFUN1K4(X,{}XBOOLE-0K1))"
      proof(rule ballI,rule conjMI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 PFuncsPARTFUN1K4(X,{}XBOOLE-0K1) implies x =HIDDENR1 {}XBOOLE-0K1"
        proof(rule impI)
          assume "x inHIDDENR3 PFuncsPARTFUN1K4(X,{}XBOOLE-0K1)"
          then have "x be PartFuncPARTFUN1M1-of(X,{}XBOOLE-0K1)"
            using partfun1_th_46 sorry
          thus "x =HIDDENR1 {}XBOOLE-0K1"
             sorry
        qed
        have "{}XBOOLE-0K1 be PartFuncPARTFUN1M1-of(X,{}XBOOLE-0K1)"
          using relset_1_th_12 sorry
        thus " not (x =HIDDENR1 {}XBOOLE-0K1 &  not x inHIDDENR3 PFuncsPARTFUN1K4(X,{}XBOOLE-0K1))"
          using partfun1_th_45 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "PFuncsPARTFUN1K4(X,{}XBOOLE-0K1) =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_50:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies PFuncsPARTFUN1K4(X1,Y1) c=TARSKIR1 PFuncsPARTFUN1K4(X2,Y2)"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2 implies PFuncsPARTFUN1K4(X1,Y1) c=TARSKIR1 PFuncsPARTFUN1K4(X2,Y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    assume A1: "X1 c=TARSKIR1 X2 & Y1 c=TARSKIR1 Y2"
    have " for f be objectHIDDENM1 holds f inHIDDENR3 PFuncsPARTFUN1K4(X1,Y1) implies f inHIDDENR3 PFuncsPARTFUN1K4(X2,Y2)"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be objectHIDDENM1"
      assume "f inHIDDENR3 PFuncsPARTFUN1K4(X1,Y1)"
      then have "f be PartFuncPARTFUN1M1-of(X1,Y1)"
        using partfun1_th_46 sorry
      then have "f be PartFuncPARTFUN1M1-of(X2,Y2)"
        using A1 relset_1_th_7 sorry
      thus "f inHIDDENR3 PFuncsPARTFUN1K4(X2,Y2)"
        using partfun1_th_45 sorry
    qed "sorry"
    thus "PFuncsPARTFUN1K4(X1,Y1) c=TARSKIR1 PFuncsPARTFUN1K4(X2,Y2)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partfun1_def_4 (" _ toleratesPARTFUN1R1  _ " [50,50]50 ) where
  mlet "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"pred f toleratesPARTFUN1R1 g means
   for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"..

mtheorem PARTFUN1R1_reflexivity:
" for g be FunctionFUNCT-1M1 holds g toleratesPARTFUN1R1 g"
proof-
  have " for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
     sorry
  thus " ?thesis "
    using partfun1_def_4 sorry
qed

mtheorem PARTFUN1R1_symmetry:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f toleratesPARTFUN1R1 g implies g toleratesPARTFUN1R1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 f implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
     sorry
  thus " ?thesis "
    using partfun1_def_4 sorry
qed

mtheorem partfun1_th_51:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f toleratesPARTFUN1R1 g iff f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
  using partfun1_th_1 partfun1_th_2 sorry

mtheorem partfun1_th_52:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f toleratesPARTFUN1R1 g iff ( ex h be FunctionFUNCT-1M1 st f c=RELAT-1R2 h & g c=RELAT-1R2 h)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (f toleratesPARTFUN1R1 g implies ( ex h be FunctionFUNCT-1M1 st f c=RELAT-1R2 h & g c=RELAT-1R2 h)) & (( ex h be FunctionFUNCT-1M1 st f c=RELAT-1R2 h & g c=RELAT-1R2 h) implies f toleratesPARTFUN1R1 g)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    show "f toleratesPARTFUN1R1 g implies ( ex h be FunctionFUNCT-1M1 st f c=RELAT-1R2 h & g c=RELAT-1R2 h)"
    proof-
      have "f toleratesPARTFUN1R1 g implies ( ex tVar7 be FunctionFUNCT-1M1 st f c=RELAT-1R2 tVar7 & g c=RELAT-1R2 tVar7)"
      proof(rule impI)
        assume "f toleratesPARTFUN1R1 g"
        then obtain h where 
          [ty]:"h be FunctionFUNCT-1M1" and hDef:"h = f \\/XBOOLE-0K2 g"
          using partfun1_th_1 sorry
        show " ex tVar7 be FunctionFUNCT-1M1 st f c=RELAT-1R2 tVar7 & g c=RELAT-1R2 tVar7"
        proof(rule bexI[of _ "h"])
          show "f c=RELAT-1R2 h & g c=RELAT-1R2 h"
            using xboole_1_th_7 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex h be FunctionFUNCT-1M1 st f c=RELAT-1R2 h & g c=RELAT-1R2 h"
    then obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A1: "f c=RELAT-1R2 h & g c=RELAT-1R2 h"
       sorry
    have "f \\/XBOOLE-0K2 g be FunctionFUNCT-1M1"
      using A1 grfunc_1_th_1 xboole_1_th_8 sorry
    thus "f toleratesPARTFUN1R1 g"
      using partfun1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_53:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g implies (f toleratesPARTFUN1R1 g iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g implies  not (f toleratesPARTFUN1R1 g &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))) &  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) &  not f toleratesPARTFUN1R1 g)"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 g"
    then have "domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
      using xboole_1_th_28 sorry
    thus " not (f toleratesPARTFUN1R1 g &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))) &  not (( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) &  not f toleratesPARTFUN1R1 g)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_54:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f c=RELAT-1R2 g implies f toleratesPARTFUN1R1 g"
  using partfun1_th_52 sorry

mtheorem partfun1_th_55:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & f toleratesPARTFUN1R1 g implies f =FUNCT-1R1 g"
   sorry

mtheorem partfun1_th_56:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g implies f toleratesPARTFUN1R1 g"
   sorry

mtheorem partfun1_th_57:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds f c=RELAT-1R2 h & g c=RELAT-1R2 h implies f toleratesPARTFUN1R1 g"
  using partfun1_th_52 sorry

mtheorem partfun1_th_58:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds  for h be FunctionFUNCT-1M1 holds f toleratesPARTFUN1R1 h & g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f implies g toleratesPARTFUN1R1 h"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds  for h be FunctionFUNCT-1M1 holds f toleratesPARTFUN1R1 h & g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f implies g toleratesPARTFUN1R1 h"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "f toleratesPARTFUN1R1 h"
      and A2: "g c=RELSET-1R1\<^bsub>(X,Y)\<^esub> f"
    have A3: "domRELSET-1K1\<^bsub>(X)\<^esub> g c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using A2 relat_1_th_11 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 h implies g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 h"
      then have A5: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
        using xboole_0_def_4 sorry
      then have A6: "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A2 grfunc_1_th_2 sorry
      have "x inHIDDENR3 domRELAT-1K1 h"
        using A4 xboole_0_def_4 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 h"
        using A5 A3 xboole_0_def_4 sorry
      thus "g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
        using A1 A6 sorry
    qed "sorry"
    thus "g toleratesPARTFUN1R1 h"
      using partfun1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_59:
" for f be FunctionFUNCT-1M1 holds {}XBOOLE-0K1 toleratesPARTFUN1R1 f"
   sorry

mtheorem partfun1_th_60:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds <:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> toleratesPARTFUN1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds <:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> toleratesPARTFUN1R1 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> =FUNCT-1R1 {}XBOOLE-0K1"
      using partfun1_th_34 sorry
    thus "<:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> toleratesPARTFUN1R1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_61:
" for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds  for g be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds f toleratesPARTFUN1R1 g"
proof-
  have " for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds  for g be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y}) holds f toleratesPARTFUN1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y})"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,{TARSKIK1 y})"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> g"
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
        using xboole_0_def_4 sorry
      then have A2: "f .FUNCT-1K1 x =HIDDENR1 y"
        using partfun1_th_20 sorry
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
        using A1 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A2 partfun1_th_20 sorry
    qed "sorry"
    thus "f toleratesPARTFUN1R1 g"
      using partfun1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_62:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f  |RELAT-1K8 X toleratesPARTFUN1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f  |RELAT-1K8 X toleratesPARTFUN1R1 f"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "f  |RELAT-1K8 X c=RELAT-1R2 f"
      using relat_1_th_59 sorry
    thus "f  |RELAT-1K8 X toleratesPARTFUN1R1 f"
      using partfun1_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_63:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y  |`RELAT-1K9 f toleratesPARTFUN1R1 f"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y  |`RELAT-1K9 f toleratesPARTFUN1R1 f"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "Y  |`RELAT-1K9 f c=RELAT-1R2 f"
      using relat_1_th_86 sorry
    thus "Y  |`RELAT-1K9 f toleratesPARTFUN1R1 f"
      using partfun1_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_64:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f) |RELAT-1K8 X toleratesPARTFUN1R1 f"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f) |RELAT-1K8 X toleratesPARTFUN1R1 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "(Y  |`RELAT-1K9 f) |RELAT-1K8 X c=RELAT-1R2 Y  |`RELAT-1K9 f & Y  |`RELAT-1K9 f c=RELAT-1R2 f"
      using relat_1_th_59 relat_1_th_86 sorry
    then have "(Y  |`RELAT-1K9 f) |RELAT-1K8 X c=RELAT-1R2 f"
       sorry
    thus "(Y  |`RELAT-1K9 f) |RELAT-1K8 X toleratesPARTFUN1R1 f"
      using partfun1_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_65:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds <:PARTFUN1K3 f,X,Y :> toleratesPARTFUN1R1 f"
  using partfun1_th_64 sorry

mtheorem partfun1_th_66:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds (f be totalPARTFUN1V1\<^bsub>(X)\<^esub> & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g implies f =FUNCT-1R1 g"
   sorry

mtheorem partfun1_th_67:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds  for h be PartFuncPARTFUN1M1-of(X,Y) holds (f toleratesPARTFUN1R1 h & g toleratesPARTFUN1R1 h) & h be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies f toleratesPARTFUN1R1 g"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds  for h be PartFuncPARTFUN1M1-of(X,Y) holds  not (((f toleratesPARTFUN1R1 h & g toleratesPARTFUN1R1 h) & h be totalPARTFUN1V1\<^bsub>(X)\<^esub>) &  not f toleratesPARTFUN1R1 g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(X,Y)"
    have "f toleratesPARTFUN1R1 h & (g toleratesPARTFUN1R1 h & domRELSET-1K1\<^bsub>(X)\<^esub> h =XBOOLE-0R4 X) implies f toleratesPARTFUN1R1 g"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A1: "f toleratesPARTFUN1R1 h"
        and A2: "g toleratesPARTFUN1R1 h"
        and A3: "domRELSET-1K1\<^bsub>(X)\<^esub> h =XBOOLE-0R4 X"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> g"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
          using xboole_0_def_4 sorry
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> h"
          using A3 xboole_0_def_4 sorry
        then have A5: "f .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
          using A1 sorry
        have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
          using A4 xboole_0_def_4 sorry
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> h"
          using A3 xboole_0_def_4 sorry
        thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          using A2 A5 sorry
      qed "sorry"
      thus "f toleratesPARTFUN1R1 g"
        using partfun1_def_4 sorry
    qed
    thus " not (((f toleratesPARTFUN1R1 h & g toleratesPARTFUN1R1 h) & h be totalPARTFUN1V1\<^bsub>(X)\<^esub>) &  not f toleratesPARTFUN1R1 g)"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_68:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies ( ex h be PartFuncPARTFUN1M1-of(X,Y) st (h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies  not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    assume A1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
      and A2: "f toleratesPARTFUN1R1 g"
    have " not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
    proof-
      show " not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
      proof-
        have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
        proof(rule impI)
          assume A3: "Y =XBOOLE-0R4 {}XBOOLE-0K1"
          then have "f toleratesPARTFUN1R1 <:PARTFUN1K3 {}XBOOLE-0K1,X,Y :> & g toleratesPARTFUN1R1 <:PARTFUN1K3 {}XBOOLE-0K1,X,Y :>"
             sorry
          thus " not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
            using A1 A3 sorry
        qed
        have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
        proof(rule impI)
          assume A4: "Y <>HIDDENR2 {}XBOOLE-0K1"
          let ?y = "the ElementSUBSET-1M1-of Y"
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. ((Lamb1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies Lamb2 =HIDDENR1 f .FUNCT-1K1 Lamb1) & (Lamb1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies Lamb2 =HIDDENR1 g .FUNCT-1K1 Lamb1)) & ( not Lamb1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not Lamb1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies Lamb2 =HIDDENR1 ?y)"
          have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y9 be objectHIDDENM1 st ?P(x,y9))"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y9 be setHIDDENM2 st (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y)))"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 X"
              show " ex y9 be setHIDDENM2 st (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y))"
              proof-
                have cases: "((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g or x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g) or  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g) or  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                   sorry
                have case1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies ( ex y9 be setHIDDENM2 st (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y)))"
                proof(rule impI)
                  assume A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  obtain y9 where 
                    [ty]:"y9 be setHIDDENM2" and y9Def:"y9 = f .FUNCT-1K1 x"
                     sorry
                  show " ex y9 be setHIDDENM2 st (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y))"
                  proof(rule bexI[of _ "y9"],rule conjMI,rule conjMI)
                    show "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x"
                       sorry
                    have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> g"
                      using A6 xboole_0_def_4 sorry
                    thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x"
                      using A2 sorry
                    show " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y"
                      using A6 sorry
                  qed "sorry"
                qed
                have case2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies ( ex y9 be setHIDDENM2 st ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y))"
                proof(rule impI)
                  assume A7: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  obtain y9 where 
                    [ty]:"y9 be setHIDDENM2" and y9Def:"y9 = f .FUNCT-1K1 x"
                     sorry
                  show " ex y9 be setHIDDENM2 st ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y)"
                  proof(rule bexI[of _ "y9"])
                    show "((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y)"
                      using A7 sorry
                  qed "sorry"
                qed
                have case3: " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies ( ex y9 be setHIDDENM2 st ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y))"
                proof(rule impI)
                  assume A8: " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  obtain y9 where 
                    [ty]:"y9 be setHIDDENM2" and y9Def:"y9 = g .FUNCT-1K1 x"
                     sorry
                  show " ex y9 be setHIDDENM2 st ((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y)"
                  proof(rule bexI[of _ "y9"])
                    show "((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =XBOOLE-0R4 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =XBOOLE-0R4 the ElementSUBSET-1M1-of Y)"
                      using A8 sorry
                  qed "sorry"
                qed
                have case4: " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies  not ( for y9 be objectHIDDENM1 holds  not (((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =HIDDENR1 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =HIDDENR1 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =HIDDENR1 the ElementSUBSET-1M1-of Y)))"
                proof(rule impI)
                  assume " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  thus " not ( for y9 be objectHIDDENM1 holds  not (((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f implies y9 =HIDDENR1 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =HIDDENR1 g .FUNCT-1K1 x)) & ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies y9 =HIDDENR1 the ElementSUBSET-1M1-of Y)))"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 case4 sorry
              qed
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A9: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 X & ?P(x,y1)) & ?P(x,y2) implies y1 =HIDDENR1 y2"
             sorry
          obtain h where
            [ty]:"h be FunctionFUNCT-1M1" and 
            A10: "domRELAT-1K1 h =XBOOLE-0R4 X"and A11: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ?P(x,h .FUNCT-1K1 x)"
            using funct_1_sch_2 A9 A5 sorry
          have "rngFUNCT-1K2 h c=TARSKIR1 Y"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 h implies z inHIDDENR3 Y"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume "z inHIDDENR3 rngFUNCT-1K2 h"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A12: "x inHIDDENR3 domRELAT-1K1 h"and A13: "z =HIDDENR1 h .FUNCT-1K1 x"
                using funct_1_def_3 sorry
              show "z inHIDDENR3 Y"
              proof-
                have cases: "((x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g or x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g) or  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g) or  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                   sorry
                have case1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies z inHIDDENR3 Y"
                proof(rule impI)
                  assume A14: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  then have "z =HIDDENR1 f .FUNCT-1K1 x"
                    using A11 A13 sorry
                  thus "z inHIDDENR3 Y"
                    using A14 partfun1_th_4 sorry
                qed
                have case2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies z inHIDDENR3 Y"
                proof(rule impI)
                  assume A15: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  then have "z =HIDDENR1 f .FUNCT-1K1 x"
                    using A11 A13 sorry
                  thus "z inHIDDENR3 Y"
                    using A15 partfun1_th_4 sorry
                qed
                have case3: " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies z inHIDDENR3 Y"
                proof(rule impI)
                  assume A16: " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  then have "z =HIDDENR1 g .FUNCT-1K1 x"
                    using A11 A13 sorry
                  thus "z inHIDDENR3 Y"
                    using A16 partfun1_th_4 sorry
                qed
                have case4: " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g implies z inHIDDENR3 Y"
                proof(rule impI)
                  assume " not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f &  not x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                  then have "z =HIDDENR1 ?y"
                    using A10 A11 A12 A13 sorry
                  thus "z inHIDDENR3 Y"
                    using A4 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 case4 sorry
              qed
            qed "sorry"
            thus "rngFUNCT-1K2 h c=TARSKIR1 Y"
              using tarski_def_3 sorry
          qed
          then obtain h9 where 
            [ty]:"h9 be PartFuncPARTFUN1M1-of(X,Y)" and h9Def:"h9 = h"
            using A10 relset_1_th_4 sorry
          have A17: "f toleratesPARTFUN1R1 h"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 h implies f .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 h"
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
                using xboole_0_def_4 sorry
              thus "f .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
                using A11 sorry
            qed "sorry"
            thus "f toleratesPARTFUN1R1 h"
              using partfun1_def_4 sorry
          qed
          have A18: "g toleratesPARTFUN1R1 h"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 h implies g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g /\\SUBSET-1K8\<^bsub>(X)\<^esub> domRELAT-1K1 h"
              then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> g"
                using xboole_0_def_4 sorry
              thus "g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
                using A11 sorry
            qed "sorry"
            thus "g toleratesPARTFUN1R1 h"
              using partfun1_def_4 sorry
          qed
          have "h9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
            using A10 sorry
          thus " not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
            using A17 A18 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for h be PartFuncPARTFUN1M1-of(X,Y) holds  not ((h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partfun1_def_5 ("TotFuncsPARTFUN1K5\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,228]228 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"func TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 VarFor1 & ( for g be PartFuncPARTFUN1M1-of(X,Y) holds  not ((g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g))) &  not ( not ( for g be PartFuncPARTFUN1M1-of(X,Y) holds  not ((g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) &  not x inHIDDENR3 VarFor1)))"
      proof-
        let ?P = "\<lambda>Lamb1.  ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 Lamb1 & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g"
        have " ex F be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 F implies ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) & (( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g) implies x inHIDDENR3 F)"
        proof-
          obtain F where
            [ty]:"F be setHIDDENM2" and 
            A1: " for x be objectHIDDENM1 holds x inHIDDENR3 F iff x inHIDDENR3 PFuncsPARTFUN1K4(X,Y) & ?P(x)"
            using xboole_0_sch_1 sorry
          show " ex F be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 F implies ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) & (( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g) implies x inHIDDENR3 F)"
          proof(rule bexI[of _ "F"],rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 F implies ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)"
              using A1 sorry
            assume Given: " ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g"
            then obtain g where
              [ty]:"g be PartFuncPARTFUN1M1-of(X,Y)" and 
              A2: "(g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g"
               sorry
            have "g inTARSKIR2 PFuncsPARTFUN1K4(X,Y)"
              using partfun1_th_45 sorry
            thus "x inHIDDENR3 F"
              using A1 A2 sorry
          qed "sorry"
        qed
        thus " not ( for VarFor1 be setHIDDENM2 holds  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 VarFor1 & ( for g be PartFuncPARTFUN1M1-of(X,Y) holds  not ((g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g))) &  not ( not ( for g be PartFuncPARTFUN1M1-of(X,Y) holds  not ((g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) &  not x inHIDDENR3 VarFor1)))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) implies it1 =HIDDENR1 it2"
    proof-
      have " for F1 be setHIDDENM2 holds  for F2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 F2 iff ( ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 x & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g)) implies F1 =HIDDENR1 F2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1.  ex g be PartFuncPARTFUN1M1-of(X,Y) st (g =HIDDENR1 Lamb1 & g be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g"
        fix F1 assume [ty]: "F1 be setHIDDENM2"
        fix F2 assume [ty]: "F2 be setHIDDENM2"
        assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 F1 iff ?P(x)"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 F2 iff ?P(x)"
        show "F1 =HIDDENR1 F2"
          using xboole_0_sch_2 A3 A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem partfun1_th_69:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be setHIDDENM2 holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies g be PartFuncPARTFUN1M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be setHIDDENM2 holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies g be PartFuncPARTFUN1M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be setHIDDENM2"
    assume "g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
    then have " ex g9 be PartFuncPARTFUN1M1-of(X,Y) st (g9 =XBOOLE-0R4 g & g9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g9"
      using partfun1_def_5 sorry
    thus "g be PartFuncPARTFUN1M1-of(X,Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_70:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies g be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies g be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    assume "g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
    then have " ex g9 be PartFuncPARTFUN1M1-of(X,Y) st (g9 =FUNCT-1R1 g & g9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g9"
      using partfun1_def_5 sorry
    thus "g be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_71:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be FunctionFUNCT-1M1 holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies f toleratesPARTFUN1R1 g"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be FunctionFUNCT-1M1 holds g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies f toleratesPARTFUN1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "g inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
    then have " ex g9 be PartFuncPARTFUN1M1-of(X,Y) st (g9 =FUNCT-1R1 g & g9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g9"
      using partfun1_def_5 sorry
    thus "f toleratesPARTFUN1R1 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_cl_5:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,Y)"
"cluster TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f be emptyXBOOLE-0V1"
  proof-
    have " not TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f be emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      let ?g = "the ElementSUBSET-1M1-of TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
      assume " not TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f be emptyXBOOLE-0V1"
      then have " ex g9 be PartFuncPARTFUN1M1-of(X,{}XBOOLE-0K1) st (g9 =XBOOLE-0R4 ?g & g9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g9"
        using partfun1_def_5 sorry
      thus " False "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem partfun1_th_72:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds f be totalPARTFUN1V1\<^bsub>(X)\<^esub> iff TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f}"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds (f be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f}) & (TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f} implies f be totalPARTFUN1V1\<^bsub>(X)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    show "f be totalPARTFUN1V1\<^bsub>(X)\<^esub> implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f}"
    proof(rule impI)
      assume A1: "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      have " for g be objectHIDDENM1 holds g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f iff f =HIDDENR1 g"
      proof-
        have " for g be objectHIDDENM1 holds (g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies f =HIDDENR1 g) &  not (f =HIDDENR1 g &  not g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f)"
        proof(rule ballI,rule conjMI)
          fix g assume [ty]: "g be objectHIDDENM1"
          show "g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f implies f =HIDDENR1 g"
          proof(rule impI)
            assume "g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
            then have " ex g9 be PartFuncPARTFUN1M1-of(X,Y) st (g9 =HIDDENR1 g & g9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>) & f toleratesPARTFUN1R1 g9"
              using partfun1_def_5 sorry
            thus "f =HIDDENR1 g"
              using A1 partfun1_th_66 sorry
          qed
          show " not (f =HIDDENR1 g &  not g inHIDDENR3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f)"
            using A1 partfun1_def_5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f}"
        using tarski_def_1 sorry
    qed
    assume "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f}"
    then have "f inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
      using tarski_def_1 sorry
    thus "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using partfun1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_73:
" for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({}XBOOLE-0K1,Y) holds TotFuncsPARTFUN1K5\<^bsub>({}XBOOLE-0K1,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 f}"
  using partfun1_th_72 sorry

mtheorem partfun1_th_74:
" for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of({}XBOOLE-0K1,Y) holds TotFuncsPARTFUN1K5\<^bsub>({}XBOOLE-0K1,Y)\<^esub> f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  using partfun1_th_72 sorry

mtheorem partfun1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f meetsXBOOLE-0R5 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g implies f toleratesPARTFUN1R1 g"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds  not ( not TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f meetsXBOOLE-0R5 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not f toleratesPARTFUN1R1 g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    let ?h = "the ElementSUBSET-1M1-of TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f /\\XBOOLE-0K3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
    have "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f /\\XBOOLE-0K3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g <>HIDDENR2 {}XBOOLE-0K1 implies f toleratesPARTFUN1R1 g"
    proof(rule impI)
      assume A1: "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f /\\XBOOLE-0K3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g <>HIDDENR2 {}XBOOLE-0K1"
      then have A2: "?h inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f"
        using xboole_0_def_4 sorry
      have A3: "?h inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
        using A1 xboole_0_def_4 sorry
      obtain h where 
        [ty]:"h be PartFuncPARTFUN1M1-of(X,Y)" and hDef:"h = ?h"
        using A2 partfun1_th_69 sorry
      have A4: "g toleratesPARTFUN1R1 h"
        using A3 partfun1_th_71 sorry
      have "f toleratesPARTFUN1R1 h"
        using A2 partfun1_th_71 sorry
      thus "f toleratesPARTFUN1R1 g"
        using A2 A4 partfun1_th_67 partfun1_th_70 sorry
    qed
    thus " not ( not TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f meetsXBOOLE-0R5 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g &  not f toleratesPARTFUN1R1 g)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_76:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f meetsXBOOLE-0R5 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(X,Y) holds  for g be PartFuncPARTFUN1M1-of(X,Y) holds (Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g implies  not TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f meetsXBOOLE-0R5 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(X,Y)"
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(X,Y)"
    assume "(Y =XBOOLE-0R4 {}XBOOLE-0K1 implies X =XBOOLE-0R4 {}XBOOLE-0K1) & f toleratesPARTFUN1R1 g"
    then obtain h where
      [ty]:"h be PartFuncPARTFUN1M1-of(X,Y)" and 
      A1: "(h be totalPARTFUN1V1\<^bsub>(X)\<^esub> & f toleratesPARTFUN1R1 h) & g toleratesPARTFUN1R1 h"
      using partfun1_th_68 sorry
    have Cut1468: "h inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f & h inTARSKIR2 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
      using A1 partfun1_def_5 sorry
    have "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f /\\XBOOLE-0K3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g <>HIDDENR2 {}XBOOLE-0K1"
    proof-
      show "TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f /\\XBOOLE-0K3 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g <>HIDDENR2 {}XBOOLE-0K1"
        using xboole_0_def_4 Cut1468 sorry
    qed
    thus " not TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> f meetsXBOOLE-0R5 TotFuncsPARTFUN1K5\<^bsub>(X,Y)\<^esub> g"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mlemma partfun1_lm_2:
" for X be setHIDDENM2 holds  for R be RelationRELSET-1M2-of X holds R =RELAT-1R1 idRELAT-1K7 X implies R be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
   sorry

mlemma partfun1_lm_3:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R =RELAT-1R1 idRELAT-1K7 X implies R be reflexiveRELAT-2V1\<bar>symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>transitiveRELAT-2V8"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds R =RELAT-1R1 idRELAT-1K7 X implies ((R be reflexiveRELAT-2V1 & R be symmetricRELAT-2V3) & R be antisymmetricRELAT-2V4) & R be transitiveRELAT-2V8"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "R =RELAT-1R1 idRELAT-1K7 X"
    have "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R & ((R be symmetricRELAT-2V3 & R be antisymmetricRELAT-2V4) & R be transitiveRELAT-2V8)"
    proof(rule conjMI)
      show "R is-reflexive-inRELAT-2R1 fieldRELAT-1K3 R"
        using A1 relat_1_def_10 sorry
      have "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R & (R be antisymmetricRELAT-2V4 & R be transitiveRELAT-2V8)"
      proof(rule conjMI)
        show "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
          using A1 relat_1_def_10 sorry
        have "R is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 R & R be transitiveRELAT-2V8"
        proof(rule conjMI)
          show "R is-antisymmetric-inRELAT-2R4 fieldRELAT-1K3 R"
            using A1 relat_1_def_10 sorry
          have "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
          proof-
            show "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
              using A1 relat_1_def_10 sorry
          qed
          thus "R be transitiveRELAT-2V8"
            using relat_2_def_16 sorry
        qed
        thus "R be antisymmetricRELAT-2V4 & R be transitiveRELAT-2V8"
          using relat_2_def_12 sorry
      qed
      thus "(R be symmetricRELAT-2V3 & R be antisymmetricRELAT-2V4) & R be transitiveRELAT-2V8"
        using relat_2_def_11 sorry
    qed
    thus "((R be reflexiveRELAT-2V1 & R be symmetricRELAT-2V3) & R be antisymmetricRELAT-2V4) & R be transitiveRELAT-2V8"
      using relat_2_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma partfun1_lm_4:
" for X be setHIDDENM2 holds idRELAT-1K7 X be RelationRELSET-1M2-of X"
proof-
  have " for X be setHIDDENM2 holds idRELAT-1K7 X be RelationRELSET-1M2-of X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> (idRELAT-1K7 X) c=TARSKIR1 X & rngFUNCT-1K2 (idRELAT-1K7 X) c=TARSKIR1 X"
       sorry
    thus "idRELAT-1K7 X be RelationRELSET-1M2-of X"
      using relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_cl_6:
  mlet "X be setHIDDENM2"
"cluster totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>transitiveRELAT-2V8 for RelationRELSET-1M2-of X"
proof
(*existence*)
  show " ex it be RelationRELSET-1M2-of X st it be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>reflexiveRELAT-2V1\<bar>symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>transitiveRELAT-2V8"
  proof-
    have " ex tVar12 be RelationRELSET-1M2-of X st (((tVar12 be totalPARTFUN1V1\<^bsub>(X)\<^esub> & tVar12 be reflexiveRELAT-2V1) & tVar12 be symmetricRELAT-2V3) & tVar12 be antisymmetricRELAT-2V4) & tVar12 be transitiveRELAT-2V8"
    proof-
      obtain R where 
        [ty]:"R be RelationRELSET-1M2-of X" and RDef:"R = idRELAT-1K7 X"
        using partfun1_lm_4 sorry
      show " ex tVar12 be RelationRELSET-1M2-of X st (((tVar12 be totalPARTFUN1V1\<^bsub>(X)\<^esub> & tVar12 be reflexiveRELAT-2V1) & tVar12 be symmetricRELAT-2V3) & tVar12 be antisymmetricRELAT-2V4) & tVar12 be transitiveRELAT-2V8"
      proof(rule bexI[of _ "R"])
        show "(((R be totalPARTFUN1V1\<^bsub>(X)\<^esub> & R be reflexiveRELAT-2V1) & R be symmetricRELAT-2V3) & R be antisymmetricRELAT-2V4) & R be transitiveRELAT-2V8"
          using partfun1_lm_3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem partfun1_cl_7:
"cluster symmetricRELAT-2V3\<bar>transitiveRELAT-2V8 also-is reflexiveRELAT-2V1 for RelationRELAT-1M1"
proof
(*coherence*)
  show " for it be RelationRELAT-1M1 holds it be symmetricRELAT-2V3\<bar>transitiveRELAT-2V8 implies it be reflexiveRELAT-2V1"
  proof-
    have " for R be RelationRELAT-1M1 holds  not ((R be symmetricRELAT-2V3 & R be transitiveRELAT-2V8) &  not R be reflexiveRELAT-2V1)"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELAT-1M1"
      have "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R & R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R implies R be reflexiveRELAT-2V1"
      proof(rule impMI ,rule impI)
        assume A1: "R is-symmetric-inRELAT-2R3 fieldRELAT-1K3 R"
          and A2: "R is-transitive-inRELAT-2R8 fieldRELAT-1K3 R"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 fieldRELAT-1K3 R implies [TARSKIK4 x,x ] inHIDDENR3 R"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 fieldRELAT-1K3 R"
          then have "x inHIDDENR3 domRELAT-1K1 R or x inHIDDENR3 rngRELAT-1K2 R"
            using xboole_0_def_3 sorry
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A4: "[TARSKIK4 x,y ] inHIDDENR3 R or [TARSKIK4 y,x ] inHIDDENR3 R"
            using xtuple_0_def_12 xtuple_0_def_13 sorry
          have "y inHIDDENR3 rngRELAT-1K2 R or y inHIDDENR3 domRELAT-1K1 R"
            using A4 xtuple_0_def_12 xtuple_0_def_13 sorry
          then have A5: "y inHIDDENR3 fieldRELAT-1K3 R"
            using xboole_0_def_3 sorry
          then have "[TARSKIK4 x,y ] inHIDDENR3 R & [TARSKIK4 y,x ] inHIDDENR3 R"
            using A1 A3 A4 sorry
          thus "[TARSKIK4 x,x ] inHIDDENR3 R"
            using A2 A3 A5 sorry
        qed "sorry"
        thus "R be reflexiveRELAT-2V1"
          using relat_2_def_1 relat_2_def_9 sorry
      qed
      thus " not ((R be symmetricRELAT-2V3 & R be transitiveRELAT-2V8) &  not R be reflexiveRELAT-2V1)"
        using relat_2_def_11 relat_2_def_16 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem partfun1_cl_8:
  mlet "X be setHIDDENM2"
"cluster idRELAT-1K7 X as-term-is symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>transitiveRELAT-2V8"
proof
(*coherence*)
  show "idRELAT-1K7 X be symmetricRELAT-2V3\<bar>antisymmetricRELAT-2V4\<bar>transitiveRELAT-2V8"
    using partfun1_lm_3 sorry
qed "sorry"

abbreviation(input) PARTFUN1K6("idPARTFUN1K6  _ " [228]228) where
  "idPARTFUN1K6 X \<equiv> idRELAT-1K7 X"

mtheorem partfun1_add_3:
  mlet "X be setHIDDENM2"
"cluster idRELAT-1K7 X as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>RelationRELSET-1M2-of X"
proof
(*coherence*)
  show "idRELAT-1K7 X be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>RelationRELSET-1M2-of X"
    using partfun1_lm_2 partfun1_lm_4 sorry
qed "sorry"

theorem partfun1_sch_4:
  fixes Af0 Ff1 Gf1 Cp1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be ElementSUBSET-1M1-of Af0 holds (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
  proof-
    have " ex tVar13 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar13 =XBOOLE-0R4 Af0 & ( for x be ElementSUBSET-1M1-of Af0 holds  not (Cp1(x) &  not tVar13 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not tVar13 .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
        using partfun1_sch_1 sorry
      show " ex tVar13 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar13 =XBOOLE-0R4 Af0 & ( for x be ElementSUBSET-1M1-of Af0 holds  not (Cp1(x) &  not tVar13 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not tVar13 .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
      proof(rule bexI[of _ "f"])
        show "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be ElementSUBSET-1M1-of Af0 holds  not (Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

(*begin*)
reserve A for "setHIDDENM2"
reserve f, g, h for "FunctionFUNCT-1M1"
mtheorem partfun1_th_77:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (f toleratesPARTFUN1R1 g & [TARSKIK4 x,y ] inHIDDENR3 f) & [TARSKIK4 x,z ] inHIDDENR3 g implies y =HIDDENR1 z"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f toleratesPARTFUN1R1 g implies ([TARSKIK4 x,y ] inHIDDENR3 f & [TARSKIK4 x,z ] inHIDDENR3 g implies y =HIDDENR1 z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    let ?h = "f \\/XBOOLE-0K2 g"
    assume "f toleratesPARTFUN1R1 g"
    then have A1: "?h be FunctionFUNCT-1M1"
      using partfun1_th_51 sorry
    assume "[TARSKIK4 x,y ] inHIDDENR3 f & [TARSKIK4 x,z ] inHIDDENR3 g"
    then have "[TARSKIK4 x,y ] inHIDDENR3 ?h & [TARSKIK4 x,z ] inHIDDENR3 ?h"
      using xboole_0_def_3 sorry
    thus "y =HIDDENR1 z"
      using A1 funct_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_78:
" for A be setHIDDENM2 holds A be functionalFUNCT-1V6 & ( for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f inTARSKIR2 A & g inTARSKIR2 A implies f toleratesPARTFUN1R1 g) implies unionTARSKIK3 A be FunctionFUNCT-1M1"
proof-
  have " for A be setHIDDENM2 holds  not ((A be functionalFUNCT-1V6 & ( for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  not ((f inTARSKIR2 A & g inTARSKIR2 A) &  not f toleratesPARTFUN1R1 g))) &  not unionTARSKIK3 A be FunctionFUNCT-1M1)"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 A implies x be FunctionFUNCT-1M1) & ( for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f inTARSKIR2 A & g inTARSKIR2 A implies f toleratesPARTFUN1R1 g) implies unionTARSKIK3 A be FunctionFUNCT-1M1"
    proof(rule impMI ,rule impI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x be FunctionFUNCT-1M1"
        and A2: " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f inTARSKIR2 A & g inTARSKIR2 A implies f toleratesPARTFUN1R1 g"
      have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 unionTARSKIK3 A & [TARSKIK4 x,z ] inHIDDENR3 unionTARSKIK3 A implies y =HIDDENR1 z"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A4: "[TARSKIK4 x,y ] inHIDDENR3 unionTARSKIK3 A"
          and A5: "[TARSKIK4 x,z ] inHIDDENR3 unionTARSKIK3 A"
        obtain p where
          [ty]:"p be setHIDDENM2" and 
          A6: "[TARSKIK4 x,y ] inHIDDENR3 p"and A7: "p inTARSKIR2 A"
          using A4 tarski_def_4 sorry
        obtain q where
          [ty]:"q be setHIDDENM2" and 
          A8: "[TARSKIK4 x,z ] inHIDDENR3 q"and A9: "q inTARSKIR2 A"
          using A5 tarski_def_4 sorry
        have 
          [ty]:"p be FunctionFUNCT-1M1" and
          [ty]:"q be FunctionFUNCT-1M1"
          using A1 A7 A9 sorry
        have "p toleratesPARTFUN1R1 q"
          using A2 A7 A9 sorry
        thus "y =HIDDENR1 z"
          using A6 A8 partfun1_th_77 sorry
      qed "sorry"
      have " for z be objectHIDDENM1 holds z inHIDDENR3 unionTARSKIK3 A implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 z)"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 unionTARSKIK3 A"
        then obtain p where
          [ty]:"p be setHIDDENM2" and 
          A10: "z inHIDDENR3 p"and A11: "p inTARSKIR2 A"
          using tarski_def_4 sorry
        have 
          [ty]:"p be FunctionFUNCT-1M1"
          using A1 A11 sorry
        have "p =FUNCT-1R1 p"
           sorry
        thus " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 z"
          using A10 relat_1_def_1 sorry
      qed "sorry"
      thus "unionTARSKIK3 A be FunctionFUNCT-1M1"
        using A3 funct_1_def_1 relat_1_def_1 sorry
    qed
    thus " not ((A be functionalFUNCT-1V6 & ( for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  not ((f inTARSKIR2 A & g inTARSKIR2 A) &  not f toleratesPARTFUN1R1 g))) &  not unionTARSKIK3 A be FunctionFUNCT-1M1)"
      using funct_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef partfun1_def_6 (" _ '/.PARTFUN1K7\<^bsub>'( _ ')\<^esub>  _ " [200,0,200]200 ) where
  mlet "D be setHIDDENM2", "p be D -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "i be objectHIDDENM1"
"assume i inHIDDENR3 domRELAT-1K1 p func p /.PARTFUN1K7\<^bsub>(D)\<^esub> i \<rightarrow> ElementSUBSET-1M1-of D equals
  p .FUNCT-1K1 i"
proof-
  (*coherence*)
    show "i inHIDDENR3 domRELAT-1K1 p implies p .FUNCT-1K1 i be ElementSUBSET-1M1-of D"
    proof(rule impI)
      assume Assume: "i inHIDDENR3 domRELAT-1K1 p"
      have A1: "i inHIDDENR3 domRELAT-1K1 p"
        using Assume sorry
      show "p .FUNCT-1K1 i be ElementSUBSET-1M1-of D"
        using A1 partfun1_th_4 sorry
    qed
qed "sorry"

mtheorem partfun1_cl_9:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(X,Y) st it be  non emptyXBOOLE-0V1"
  proof-
    have " ex tVar14 be PartFuncPARTFUN1M1-of(X,Y) st  not tVar14 be emptyXBOOLE-0V1"
    proof-
      obtain p where 
        [ty]:"p be PartFuncPARTFUN1M1-of(X,Y)" and pDef:"p = {TARSKIK1 [TARSKIK4 the ElementSUBSET-1M1-of X,the ElementSUBSET-1M1-of Y ] }"
        using relset_1_th_3 sorry
      show " ex tVar14 be PartFuncPARTFUN1M1-of(X,Y) st  not tVar14 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "p"])
        show " not p be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem partfun1_cl_10:
  mlet "A be setHIDDENM2", "B be setHIDDENM2"
"cluster PFuncsPARTFUN1K4(A,B) as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(A,B) be functionalFUNCT-1V6"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 PFuncsPARTFUN1K4(A,B) implies x be setHIDDENM2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 PFuncsPARTFUN1K4(A,B)"
      then have " ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f c=TARSKIR1 A) & rngFUNCT-1K2 f c=TARSKIR1 B"
        using partfun1_def_3 sorry
      thus "x be setHIDDENM2"
         sorry
    qed "sorry"
    thus "PFuncsPARTFUN1K4(A,B) be functionalFUNCT-1V6"
      using funct_1_def_13 sorry
  qed
qed "sorry"

mtheorem partfun1_th_79:
" for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f1 & rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f2) & f1 toleratesPARTFUN1R1 f2 implies f1 *FUNCT-1K3 g =FUNCT-1R1 f2 *FUNCT-1K3 g"
proof-
  have " for f1 be FunctionFUNCT-1M1 holds  for f2 be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f1 & (rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f2 & f1 toleratesPARTFUN1R1 f2) implies f1 *FUNCT-1K3 g =FUNCT-1R1 f2 *FUNCT-1K3 g"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f1 assume [ty]: "f1 be FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f1"
      and A2: "rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f2"
      and A3: "f1 toleratesPARTFUN1R1 f2"
    have A4: "domRELAT-1K1 (f2 *FUNCT-1K3 g) =XBOOLE-0R4 domRELAT-1K1 g"
      using A2 relat_1_th_27 sorry
    have A5: "domRELAT-1K1 (f1 *FUNCT-1K3 g) =XBOOLE-0R4 domRELAT-1K1 g"
      using A1 relat_1_th_27 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies (f1 *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 (f2 *FUNCT-1K3 g).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domRELAT-1K1 g"
      then have A7: "(f2 *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 f2 .FUNCT-1K1 (g .FUNCT-1K1 x)"
        using A4 funct_1_th_12 sorry
      have "g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g"
        using A6 funct_1_def_3 sorry
      then have A8: "g .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A1 A2 xboole_0_def_4 sorry
      have "(f1 *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 (g .FUNCT-1K1 x)"
        using A5 A6 funct_1_th_12 sorry
      thus "(f1 *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 (f2 *FUNCT-1K3 g).FUNCT-1K1 x"
        using A3 A7 A8 sorry
    qed "sorry"
    thus "f1 *FUNCT-1K3 g =FUNCT-1R1 f2 *FUNCT-1K3 g"
      using A5 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_80:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies (f  |RELAT-1K8 X)/.PARTFUN1K7\<^bsub>(Y)\<^esub> x =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(Y)\<^esub> x"
proof-
  have " for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies (f  |RELAT-1K8 X)/.PARTFUN1K7\<^bsub>(Y)\<^esub> x =HIDDENR1 f /.PARTFUN1K7\<^bsub>(Y)\<^esub> x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be Y -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
    then have A2: "x inHIDDENR3 domRELAT-1K1 f"
      using relat_1_th_57 sorry
    have "(f  |RELAT-1K8 X)/.PARTFUN1K7\<^bsub>(Y)\<^esub> x =HIDDENR1 (f  |RELAT-1K8 X).FUNCT-1K1 x"
      using A1 partfun1_def_6 sorry
    also have "... = f .FUNCT-1K1 x"
      using A1 funct_1_th_47 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(Y)\<^esub> x"
      using A2 partfun1_def_6 sorry
    finally show "(f  |RELAT-1K8 X)/.PARTFUN1K7\<^bsub>(Y)\<^esub> x =HIDDENR1 f /.PARTFUN1K7\<^bsub>(Y)\<^esub> x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem partfun1_sch_5:
  fixes Af0 Ff1 Gf1 Cp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds x inTARSKIR2 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))"
  proof-
    have " ex tVar15 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar15 =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Af0 &  not ( not (Cp1(x) &  not tVar15 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not tVar15 .FUNCT-1K1 x =HIDDENR1 Gf1(x)))))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Af0"and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) & ( not Cp1(x) implies f .FUNCT-1K1 x =HIDDENR1 Gf1(x))"
        using partfun1_sch_1 sorry
      show " ex tVar15 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar15 =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Af0 &  not ( not (Cp1(x) &  not tVar15 .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not tVar15 .FUNCT-1K1 x =HIDDENR1 Gf1(x)))))"
      proof(rule bexI[of _ "f"])
        show "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be setHIDDENM2 holds  not (x inTARSKIR2 Af0 &  not ( not (Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Ff1(x)) &  not ( not Cp1(x) &  not f .FUNCT-1K1 x =HIDDENR1 Gf1(x)))))"
          using A1 A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem partfun1_th_81:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x implies f  |RELAT-1K8 {TARSKIK1 x} toleratesPARTFUN1R1 g  |RELAT-1K8 {TARSKIK1 x}"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x implies f  |RELAT-1K8 {TARSKIK1 x} toleratesPARTFUN1R1 g  |RELAT-1K8 {TARSKIK1 x}"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 {TARSKIK1 x}) /\\XBOOLE-0K3 domRELAT-1K1 (g  |RELAT-1K8 {TARSKIK1 x}) implies (g  |RELAT-1K8 {TARSKIK1 x}).FUNCT-1K1 a =HIDDENR1 (f  |RELAT-1K8 {TARSKIK1 x}).FUNCT-1K1 a"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      let ?F = "f  |RELAT-1K8 {TARSKIK1 x}"
      let ?G = "g  |RELAT-1K8 {TARSKIK1 x}"
      assume "a inHIDDENR3 domRELAT-1K1 ?F /\\XBOOLE-0K3 domRELAT-1K1 ?G"
      then have "a inHIDDENR3 domRELAT-1K1 ?F"
        using xboole_0_def_4 sorry
      then have A2: "a inHIDDENR3 {TARSKIK1 x}"
        using relat_1_th_57 sorry
      then have "a =HIDDENR1 x"
        using tarski_def_1 sorry
      then have "(g  |RELAT-1K8 {TARSKIK1 x}).FUNCT-1K1 a =HIDDENR1 f .FUNCT-1K1 a"
        using A1 A2 funct_1_th_49 sorry
      also have "... = (f  |RELAT-1K8 {TARSKIK1 x}).FUNCT-1K1 a"
        using A2 funct_1_th_49 sorry
      finally show "(g  |RELAT-1K8 {TARSKIK1 x}).FUNCT-1K1 a =HIDDENR1 (f  |RELAT-1K8 {TARSKIK1 x}).FUNCT-1K1 a"
         sorry
    qed "sorry"
    thus "f  |RELAT-1K8 {TARSKIK1 x} toleratesPARTFUN1R1 g  |RELAT-1K8 {TARSKIK1 x}"
      using partfun1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem partfun1_th_82:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x & f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y implies f  |RELAT-1K8 {TARSKIK2 x,y } toleratesPARTFUN1R1 g  |RELAT-1K8 {TARSKIK2 x,y }"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x & f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y implies f  |RELAT-1K8 {TARSKIK2 x,y } toleratesPARTFUN1R1 g  |RELAT-1K8 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x & f .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 {TARSKIK2 x,y }) /\\XBOOLE-0K3 domRELAT-1K1 (g  |RELAT-1K8 {TARSKIK2 x,y }) implies (g  |RELAT-1K8 {TARSKIK2 x,y }).FUNCT-1K1 a =HIDDENR1 (f  |RELAT-1K8 {TARSKIK2 x,y }).FUNCT-1K1 a"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      let ?F = "f  |RELAT-1K8 {TARSKIK2 x,y }"
      let ?G = "g  |RELAT-1K8 {TARSKIK2 x,y }"
      assume "a inHIDDENR3 domRELAT-1K1 ?F /\\XBOOLE-0K3 domRELAT-1K1 ?G"
      then have "a inHIDDENR3 domRELAT-1K1 ?F"
        using xboole_0_def_4 sorry
      then have A2: "a inHIDDENR3 {TARSKIK2 x,y }"
        using relat_1_th_57 sorry
      then have "a =HIDDENR1 x or a =HIDDENR1 y"
        using tarski_def_2 sorry
      then have "(g  |RELAT-1K8 {TARSKIK2 x,y }).FUNCT-1K1 a =HIDDENR1 f .FUNCT-1K1 a"
        using A1 A2 funct_1_th_49 sorry
      also have "... = (f  |RELAT-1K8 {TARSKIK2 x,y }).FUNCT-1K1 a"
        using A2 funct_1_th_49 sorry
      finally show "(g  |RELAT-1K8 {TARSKIK2 x,y }).FUNCT-1K1 a =HIDDENR1 (f  |RELAT-1K8 {TARSKIK2 x,y }).FUNCT-1K1 a"
         sorry
    qed "sorry"
    thus "f  |RELAT-1K8 {TARSKIK2 x,y } toleratesPARTFUN1R1 g  |RELAT-1K8 {TARSKIK2 x,y }"
      using partfun1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
