theory funcop_1
  imports funct_3 wellord1 grfunc_1
begin
(*begin*)
reserve f, g, h for "FunctionFUNCT-1M1"
reserve A for "setHIDDENM2"
mtheorem funcop_1_th_1:
" for A be setHIDDENM2 holds deltaFUNCT-3K13 A =FUNCT-1R1 <:FUNCT-3K14 idPARTFUN1K6 A,idPARTFUN1K6 A :>"
proof-
  have " for A be setHIDDENM2 holds deltaFUNCT-3K13 A =HIDDENR1 <:FUNCT-3K14 idPARTFUN1K6 A,idPARTFUN1K6 A :>"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have "deltaFUNCT-3K13 A =HIDDENR1 idPARTFUN1K6 ([:ZFMISC-1K2 A,A :]) *PARTFUN1K1\<^bsub>(A,[:ZFMISC-1K2 A,A :],[:ZFMISC-1K2 A,A :],[:ZFMISC-1K2 A,A :])\<^esub> deltaFUNCT-3K13 A"
      using funct_2_th_17 sorry
    also have "... = ([:FUNCT-3K17\<^bsub>(A,A,A,A)\<^esub> idPARTFUN1K6 A,idPARTFUN1K6 A :])*PARTFUN1K1\<^bsub>(A,[:ZFMISC-1K2 A,A :],[:ZFMISC-1K2 A,A :],[:ZFMISC-1K2 A,A :])\<^esub> deltaFUNCT-3K13 A"
      using funct_3_th_69 sorry
    also have "... = <:FUNCT-3K14 idPARTFUN1K6 A,idPARTFUN1K6 A :>"
      using funct_3_th_78 sorry
    finally show "deltaFUNCT-3K13 A =HIDDENR1 <:FUNCT-3K14 idPARTFUN1K6 A,idPARTFUN1K6 A :>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve F for "FunctionFUNCT-1M1"
reserve B, x, y, y1, y2, z for "setHIDDENM2"
mdef funcop_1_def_1 (" _ ~FUNCOP-1K1" [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func f ~FUNCOP-1K1 \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 it .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 it .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))"
    proof-
      have " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 Lamb1 =HIDDENR1 [TARSKIK4 y,z ] implies Lamb2 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 Lamb1 =HIDDENR1 Lamb2 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 Lamb1 =HIDDENR1 [TARSKIK4 y,z ]))"
        have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( ex y be objectHIDDENM1 st ( for yc be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 yc,z ] implies y =HIDDENR1 [TARSKIK4 z,yc ]) & (f .FUNCT-1K1 x =HIDDENR1 y or ( ex yc be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 yc,z ])))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          have "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) & ( ex y1 be objectHIDDENM1 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))) or  not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) & ( not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies ( ex y1 be setHIDDENM2 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))))"
          proof-
            show "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) & ( ex y1 be objectHIDDENM1 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))) or  not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) & ( not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies ( ex y1 be setHIDDENM2 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))))"
            proof-
              have cases: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) or  not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
                 sorry
              have case1: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies ( ex y1 be objectHIDDENM1 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))"
              proof(rule impI)
                assume A2: " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
                then obtain y z where
                  [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
                  A3: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
                   sorry
                obtain y1 where 
                  [ty]:"y1 be objectHIDDENM1" and y1Def:"y1 = [TARSKIK4 z,y ]"
                   sorry
                show " ex y1 be objectHIDDENM1 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))"
                proof(rule bexI[of _ "y1"],rule conjMI)
                  show " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]"
                  proof-
                    have " for y9 be objectHIDDENM1 holds  for z9 be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y9,z9 ] implies y1 =HIDDENR1 [TARSKIK4 z9,y9 ]"
                    proof(rule ballI,rule ballI,rule impI)
                      fix y9 assume [ty]: "y9 be objectHIDDENM1"
                      fix z9 assume [ty]: "z9 be objectHIDDENM1"
                      assume A4: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y9,z9 ]"
                      then have "z =HIDDENR1 z9"
                        using A3 xtuple_0_th_1 sorry
                      thus "y1 =HIDDENR1 [TARSKIK4 z9,y9 ]"
                        using A3 A4 xtuple_0_th_1 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  show "f .FUNCT-1K1 x =HIDDENR1 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
                    using A2 sorry
                qed "sorry"
              qed
              have case2: " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies ( ex y1 be setHIDDENM2 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))"
              proof(rule impI)
                assume A5: " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
                obtain y1 where 
                  [ty]:"y1 be setHIDDENM2" and y1Def:"y1 = f .FUNCT-1K1 x"
                   sorry
                show " ex y1 be setHIDDENM2 st ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))"
                proof(rule bexI[of _ "y1"])
                  show "( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))"
                    using A5 sorry
                qed "sorry"
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " ex y be objectHIDDENM1 st ( for yc be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 yc,z ] implies y =HIDDENR1 [TARSKIK4 z,yc ]) & (f .FUNCT-1K1 x =HIDDENR1 y or ( ex yc be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 yc,z ]))"
             sorry
        qed "sorry"
        have A6: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ((( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y1 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 y1 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))) & (( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies y2 =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 y2 or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))) implies y1 =HIDDENR1 y2)"
        proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y1 assume [ty]: "y1 be objectHIDDENM1"
          fix y2 assume [ty]: "y2 be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          assume A7: "?P(x,y1)"
            and A8: "?P(x,y2)"
          have "y1 =HIDDENR1 y2"
          proof-
            show "y1 =HIDDENR1 y2"
            proof-
              have cases: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) or  not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
                 sorry
              have case1: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies y1 =HIDDENR1 y2"
              proof(rule impI)
                assume " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
                then obtain y z where
                  [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
                  A9: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
                   sorry
                have "y1 =HIDDENR1 [TARSKIK4 z,y ]"
                  using A7 A9 sorry
                thus "y1 =HIDDENR1 y2"
                  using A8 A9 sorry
              qed
              have case2: " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies y1 =HIDDENR1 y2"
              proof(rule impI)
                assume " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
                thus "y1 =HIDDENR1 y2"
                  using A7 A8 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "y1 =HIDDENR1 y2"
             sorry
        qed "sorry"
        show " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))"
          using funct_1_sch_2 A6 A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies it1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 it1 .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies it2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 it2 .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))) implies it1 =HIDDENR1 it2"
    proof-
      have " for g1 be FunctionFUNCT-1M1 holds  for g2 be FunctionFUNCT-1M1 holds domRELAT-1K1 g1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies g1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 g1 .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))) & (domRELAT-1K1 g2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies g2 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))))) implies g1 =HIDDENR1 g2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies Lamb1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 Lamb1 .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))"
        fix g1 assume [ty]: "g1 be FunctionFUNCT-1M1"
        fix g2 assume [ty]: "g2 be FunctionFUNCT-1M1"
        assume A10: "domRELAT-1K1 g1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A11: "?P(g1)"
          and A12: "domRELAT-1K1 g2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A13: "?P(g2)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A14: "x inHIDDENR3 domRELAT-1K1 f"
          have "g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
          proof-
            show "g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
            proof-
              have cases: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) or  not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
                 sorry
              have case1: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
              proof(rule impI)
                assume " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
                then obtain y z where
                  [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
                  A15: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
                   sorry
                have "g1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
                  using A11 A14 A15 sorry
                thus "g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
                  using A13 A14 A15 sorry
              qed
              have case2: " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
              proof(rule impI)
                assume A16: " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
                then have "g1 .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
                  using A11 A14 sorry
                thus "g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
                  using A13 A14 A16 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "g1 .FUNCT-1K1 x =XBOOLE-0R4 g2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "g1 =HIDDENR1 g2"
          using A10 A12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem FUNCOP_1K1_involutiveness:
" for f be FunctionFUNCT-1M1 holds (f ~FUNCOP-1K1)~FUNCOP-1K1 =HIDDENR1 f"
proof-
  have " for it be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds it =HIDDENR1 f ~FUNCOP-1K1 implies f =HIDDENR1 it ~FUNCOP-1K1"
  proof-
    have " for it be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 it .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))) implies domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 it & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (it .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st it .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])))"
    proof-
      have " for g be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))) implies domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (g .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 x implies ( ex tVar3 be objectHIDDENM1 st  ex tVar4 be objectHIDDENM1 st g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 tVar3,tVar4 ])))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI,rule conjMI,rule impI)
        fix g assume [ty]: "g be FunctionFUNCT-1M1"
        fix f assume [ty]: "f be FunctionFUNCT-1M1"
        assume A17: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
          and A18: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) & (f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x or ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]))"
        show "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
          using A17 sorry
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A19: "x inHIDDENR3 domRELAT-1K1 g"
        show " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ] implies f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
        proof(rule ballI,rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A20: "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
          show "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
          proof-
            have cases: "( ex z be objectHIDDENM1 st  ex y be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) or  not ( ex z be objectHIDDENM1 st  ex y be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ])"
               sorry
            have case1: "( ex z be objectHIDDENM1 st  ex y be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) implies f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
            proof(rule impI)
              assume " ex z be objectHIDDENM1 st  ex y be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
              then obtain y1 y2 where
                [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
                A21: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y1,y2 ]"
                 sorry
              have A22: "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y2,y1 ]"
                using A17 A18 A19 A21 sorry
              then have "y =HIDDENR1 y2"
                using A20 xtuple_0_th_1 sorry
              thus "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
                using A20 A21 A22 xtuple_0_th_1 sorry
            qed
            have case2: " not ( ex z be objectHIDDENM1 st  ex y be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]) implies f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
            proof(rule impI)
              assume " not ( ex z be objectHIDDENM1 st  ex y be objectHIDDENM1 st f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ])"
              then have "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
                using A17 A18 A19 sorry
              thus "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
                using A17 A18 A19 A20 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        assume "g .FUNCT-1K1 x <>HIDDENR2 f .FUNCT-1K1 x"
        then obtain y z where
          [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
          A23: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
          using A17 A18 A19 sorry
        show " ex tVar3 be objectHIDDENM1 st  ex tVar4 be objectHIDDENM1 st g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 tVar3,tVar4 ]"
        proof(rule bexI[of _ "z"])
          show " ex tVar4 be objectHIDDENM1 st g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,tVar4 ]"
          proof(rule bexI[of _ "y"])
            show "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
              using A17 A18 A19 A23 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using funcop_1_def_1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_2:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds <:FUNCT-3K14 f,g :> =FUNCT-1R1 (<:FUNCT-3K14 g,f :>)~FUNCOP-1K1"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds <:FUNCT-3K14 f,g :> =FUNCT-1R1 (<:FUNCT-3K14 g,f :>)~FUNCOP-1K1"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =HIDDENR1 domRELAT-1K1 g /\\XBOOLE-0K3 domRELAT-1K1 f"
      using funct_3_def_7 sorry
    also have "... = domRELAT-1K1 (<:FUNCT-3K14 g,f :>)"
      using funct_3_def_7 sorry
    finally have "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =HIDDENR1 domRELAT-1K1 (<:FUNCT-3K14 g,f :>)"
       sorry
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,g :>) implies (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 (<:FUNCT-3K14 g,f :>)~FUNCOP-1K1 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
      then have A4: "(<:FUNCT-3K14 g,f :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 g .FUNCT-1K1 x,f .FUNCT-1K1 x ]"
        using A1 funct_3_def_7 sorry
      have "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
        using A3 funct_3_def_7 sorry
      also have "... = (<:FUNCT-3K14 g,f :>)~FUNCOP-1K1 .FUNCT-1K1 x"
        using A1 A3 A4 funcop_1_def_1 sorry
      finally show "(<:FUNCT-3K14 f,g :>).FUNCT-1K1 x =HIDDENR1 (<:FUNCT-3K14 g,f :>)~FUNCOP-1K1 .FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (<:FUNCT-3K14 f,g :>) =XBOOLE-0R4 domRELAT-1K1 ((<:FUNCT-3K14 g,f :>)~FUNCOP-1K1)"
      using A1 funcop_1_def_1 sorry
    thus "<:FUNCT-3K14 f,g :> =FUNCT-1R1 (<:FUNCT-3K14 g,f :>)~FUNCOP-1K1"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_3:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f  |RELAT-1K8 A)~FUNCOP-1K1 =FUNCT-1R1 f ~FUNCOP-1K1  |RELAT-1K8 A"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (f  |RELAT-1K8 A)~FUNCOP-1K1 =FUNCT-1R1 f ~FUNCOP-1K1  |RELAT-1K8 A"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    have A1: "domRELAT-1K1 (f  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 f /\\XBOOLE-0K3 A"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f ~FUNCOP-1K1) /\\XBOOLE-0K3 A"
      using funcop_1_def_1 sorry
    also have "... = domRELAT-1K1 (f ~FUNCOP-1K1  |RELAT-1K8 A)"
      using relat_1_th_61 sorry
    finally have "domRELAT-1K1 (f  |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 (f ~FUNCOP-1K1  |RELAT-1K8 A)"
       sorry
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f ~FUNCOP-1K1  |RELAT-1K8 A) implies (f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =XBOOLE-0R4 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELAT-1K1 (f ~FUNCOP-1K1  |RELAT-1K8 A)"
      have A4: "domRELAT-1K1 (f  |RELAT-1K8 A) c=TARSKIR1 domRELAT-1K1 f"
        using relat_1_th_60 sorry
      have "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
      proof-
        show "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
        proof-
          have cases: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (f  |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) or  not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (f  |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
             sorry
          have case1: "( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (f  |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies (f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
          proof(rule impI)
            assume " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (f  |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
            then obtain y z where
              [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
              A5: "(f  |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
               sorry
            have A6: "f .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]"
              using A1 A3 A5 funct_1_th_47 sorry
            have "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 z,y ]"
              using A1 A3 A5 funcop_1_def_1 sorry
            also have "... = f ~FUNCOP-1K1 .FUNCT-1K1 x"
              using A1 A3 A4 A6 funcop_1_def_1 sorry
            also have "... = (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
              using A3 funct_1_th_47 sorry
            finally show "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
               sorry
          qed
          have case2: " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (f  |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ]) implies (f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
          proof(rule impI)
            assume A7: " not ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (f  |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 y,z ])"
            have A8: "(f  |RELAT-1K8 A).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
              using A1 A3 funct_1_th_47 sorry
            have "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =XBOOLE-0R4 (f  |RELAT-1K8 A).FUNCT-1K1 x"
              using A1 A3 A7 funcop_1_def_1 sorry
            then have "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 f ~FUNCOP-1K1 .FUNCT-1K1 x"
              using A1 A3 A4 A7 A8 funcop_1_def_1 sorry
            also have "... = (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
              using A3 funct_1_th_47 sorry
            finally show "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(f  |RELAT-1K8 A)~FUNCOP-1K1 .FUNCT-1K1 x =XBOOLE-0R4 (f ~FUNCOP-1K1  |RELAT-1K8 A).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f  |RELAT-1K8 A)~FUNCOP-1K1) =XBOOLE-0R4 domRELAT-1K1 (f  |RELAT-1K8 A)"
      using funcop_1_def_1 sorry
    thus "(f  |RELAT-1K8 A)~FUNCOP-1K1 =FUNCT-1R1 f ~FUNCOP-1K1  |RELAT-1K8 A"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_4:
" for A be setHIDDENM2 holds (deltaFUNCT-3K13 A)~FUNCOP-1K1 =FUNCT-1R1 deltaFUNCT-3K13 A"
proof-
  have " for A be setHIDDENM2 holds (deltaFUNCT-3K13 A)~FUNCOP-1K1 =HIDDENR1 deltaFUNCT-3K13 A"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have "(deltaFUNCT-3K13 A)~FUNCOP-1K1 =HIDDENR1 (<:FUNCT-3K14 idPARTFUN1K6 A,idPARTFUN1K6 A :>)~FUNCOP-1K1"
      using funcop_1_th_1 sorry
    also have "... = <:FUNCT-3K14 idPARTFUN1K6 A,idPARTFUN1K6 A :>"
      using funcop_1_th_2 sorry
    also have "... = deltaFUNCT-3K13 A"
      using funcop_1_th_1 sorry
    finally show "(deltaFUNCT-3K13 A)~FUNCOP-1K1 =HIDDENR1 deltaFUNCT-3K13 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_5:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (<:FUNCT-3K14 f,g :>) |RELAT-1K8 A =FUNCT-1R1 <:FUNCT-3K14 f  |RELAT-1K8 A,g :>"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (<:FUNCT-3K14 f,g :>) |RELAT-1K8 A =FUNCT-1R1 <:FUNCT-3K14 f  |RELAT-1K8 A,g :>"
  proof(rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    have A1: "domRELAT-1K1 ((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 (<:FUNCT-3K14 f,g :>) /\\XBOOLE-0K3 A"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g)/\\XBOOLE-0K3 A"
      using funct_3_def_7 sorry
    also have "... = (domRELAT-1K1 f /\\XBOOLE-0K3 A)/\\XBOOLE-0K3 domRELAT-1K1 g"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 A) /\\XBOOLE-0K3 domRELAT-1K1 g"
      using relat_1_th_61 sorry
    finally have "domRELAT-1K1 ((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 A) /\\XBOOLE-0K3 domRELAT-1K1 g"
       sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A) implies ((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (f  |RELAT-1K8 A).FUNCT-1K1 x,g .FUNCT-1K1 x ]"
    proof(rule ballI,rule impI)
      have A2: "domRELAT-1K1 ((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A) c=TARSKIR1 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
        using relat_1_th_60 sorry
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELAT-1K1 ((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A)"
      have A4: "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 A)"
        using A1 A3 xboole_0_def_4 sorry
      have "((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 (<:FUNCT-3K14 f,g :>).FUNCT-1K1 x"
        using A3 funct_1_th_47 sorry
      also have "... = [TARSKIK4 f .FUNCT-1K1 x,g .FUNCT-1K1 x ]"
        using A3 A2 funct_3_def_7 sorry
      also have "... = [TARSKIK4 (f  |RELAT-1K8 A).FUNCT-1K1 x,g .FUNCT-1K1 x ]"
        using A4 funct_1_th_47 sorry
      finally show "((<:FUNCT-3K14 f,g :>) |RELAT-1K8 A).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (f  |RELAT-1K8 A).FUNCT-1K1 x,g .FUNCT-1K1 x ]"
         sorry
    qed "sorry"
    thus "(<:FUNCT-3K14 f,g :>) |RELAT-1K8 A =FUNCT-1R1 <:FUNCT-3K14 f  |RELAT-1K8 A,g :>"
      using A1 funct_3_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_6:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (<:FUNCT-3K14 f,g :>) |RELAT-1K8 A =FUNCT-1R1 <:FUNCT-3K14 f,g  |RELAT-1K8 A :>"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds (<:FUNCT-3K14 f,g :>) |RELAT-1K8 A =HIDDENR1 <:FUNCT-3K14 f,g  |RELAT-1K8 A :>"
  proof(rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    have "(<:FUNCT-3K14 f,g :>) |RELAT-1K8 A =HIDDENR1 (<:FUNCT-3K14 g,f :>)~FUNCOP-1K1  |RELAT-1K8 A"
      using funcop_1_th_2 sorry
    also have "... = ((<:FUNCT-3K14 g,f :>) |RELAT-1K8 A)~FUNCOP-1K1"
      using funcop_1_th_3 sorry
    also have "... = (<:FUNCT-3K14 g  |RELAT-1K8 A,f :>)~FUNCOP-1K1"
      using funcop_1_th_5 sorry
    also have "... = <:FUNCT-3K14 f,g  |RELAT-1K8 A :>"
      using funcop_1_th_2 sorry
    finally show "(<:FUNCT-3K14 f,g :>) |RELAT-1K8 A =HIDDENR1 <:FUNCT-3K14 f,g  |RELAT-1K8 A :>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funcop_1_def_2 (" _ -->FUNCOP-1K2  _ " [116,116]116 ) where
  mlet "A be setHIDDENM2", "z be objectHIDDENM1"
"func A -->FUNCOP-1K2 z \<rightarrow> setHIDDENM2 equals
  [:ZFMISC-1K2 A,{TARSKIK1 z} :]"
proof-
  (*coherence*)
    show "[:ZFMISC-1K2 A,{TARSKIK1 z} :] be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funcop_1_cl_1:
  mlet "A be setHIDDENM2", "z be objectHIDDENM1"
"cluster A -->FUNCOP-1K2 z as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "A -->FUNCOP-1K2 z be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
  proof-
    have "A -->FUNCOP-1K2 z be Function-likeFUNCT-1V1 & A -->FUNCOP-1K2 z be Relation-likeRELAT-1V1"
    proof(rule conjMI)
      show "A -->FUNCOP-1K2 z be Function-likeFUNCT-1V1"
      proof-
        have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 A -->FUNCOP-1K2 z & [TARSKIK4 x,y2 ] inHIDDENR3 A -->FUNCOP-1K2 z implies y1 =HIDDENR1 y2"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y1 assume [ty]: "y1 be objectHIDDENM1"
          fix y2 assume [ty]: "y2 be objectHIDDENM1"
          assume A1: "[TARSKIK4 x,y1 ] inHIDDENR3 A -->FUNCOP-1K2 z"
            and A2: "[TARSKIK4 x,y2 ] inHIDDENR3 A -->FUNCOP-1K2 z"
          have "y1 inHIDDENR3 {TARSKIK1 z}"
            using A1 zfmisc_1_th_87 sorry
          then have A3: "y1 =HIDDENR1 z"
            using tarski_def_1 sorry
          have "y2 inHIDDENR3 {TARSKIK1 z}"
            using A2 zfmisc_1_th_87 sorry
          thus "y1 =HIDDENR1 y2"
            using A3 tarski_def_1 sorry
        qed "sorry"
        thus "A -->FUNCOP-1K2 z be Function-likeFUNCT-1V1"
          using funct_1_def_1 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A -->FUNCOP-1K2 z implies ( ex y1 be objectHIDDENM1 st  ex y2 be objectHIDDENM1 st [TARSKIK4 y1,y2 ] =HIDDENR1 x)"
      proof-
        show " for x be objectHIDDENM1 holds x inHIDDENR3 A -->FUNCOP-1K2 z implies ( ex y1 be objectHIDDENM1 st  ex y2 be objectHIDDENM1 st [TARSKIK4 y1,y2 ] =HIDDENR1 x)"
          using relat_1_def_1 sorry
      qed
      thus "A -->FUNCOP-1K2 z be Relation-likeRELAT-1V1"
        using relat_1_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve x, z for "objectHIDDENM1"
mtheorem funcop_1_th_7:
" for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 A implies (A -->FUNCOP-1K2 z).FUNCT-1K1 x =HIDDENR1 z"
proof-
  have " for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 A implies (A -->FUNCOP-1K2 z).FUNCT-1K1 x =HIDDENR1 z"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    assume A1: "x inHIDDENR3 A"
    have "z inHIDDENR3 {TARSKIK1 z}"
      using tarski_def_1 sorry
    then have "[TARSKIK4 x,z ] inHIDDENR3 A -->FUNCOP-1K2 z"
      using A1 zfmisc_1_th_87 sorry
    thus "(A -->FUNCOP-1K2 z).FUNCT-1K1 x =HIDDENR1 z"
      using funct_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_8:
" for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds A <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 {TARSKIK1 x}"
  using relat_1_th_160 sorry

mtheorem funcop_1_th_9:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 x} implies f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 x} implies f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 x}"
    then have "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
      using relat_1_th_42 sorry
    then have "domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K2 x) =XBOOLE-0R4 domRELAT-1K1 f & rngFUNCT-1K2 (domRELAT-1K1 f -->FUNCOP-1K2 x) =XBOOLE-0R4 {TARSKIK1 x}"
      using relat_1_th_160 sorry
    thus "f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
      using A1 funct_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_cl_2:
  mlet "x be objectHIDDENM1"
"cluster {}XBOOLE-0K1 -->FUNCOP-1K2 x as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "{}XBOOLE-0K1 -->FUNCOP-1K2 x be emptyXBOOLE-0V1"
    using zfmisc_1_th_90 sorry
qed "sorry"

mtheorem funcop_1_cl_3:
  mlet "x be objectHIDDENM1", "A be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster A -->FUNCOP-1K2 x as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "A -->FUNCOP-1K2 x be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem funcop_1_cl_4:
  mlet "x be objectHIDDENM1", "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster A -->FUNCOP-1K2 x as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "A -->FUNCOP-1K2 x be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem funcop_1_th_10:
" for x be objectHIDDENM1 holds domRELAT-1K1 ({}XBOOLE-0K1 -->FUNCOP-1K2 x) =FUNCT-1R1 {}XBOOLE-0K1 & rngFUNCT-1K2 ({}XBOOLE-0K1 -->FUNCOP-1K2 x) =FUNCT-1R1 {}XBOOLE-0K1"
   sorry

mtheorem funcop_1_th_11:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 z =HIDDENR1 x) implies f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 z =HIDDENR1 x) implies f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 z =HIDDENR1 x"
    have "f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
    proof-
      show "f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
      proof-
        have cases: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 or domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
        proof(rule impI)
          assume A2: "domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
          show "f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
            using A2 sorry
        qed
        have case2: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1 implies f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
        proof(rule impI)
          assume A3: "domRELAT-1K1 f <>HIDDENR2 {}XBOOLE-0K1"
          let ?z = "the ElementSUBSET-1M1-of domRELAT-1K1 f"
          have " for y be objectHIDDENM1 holds (y inHIDDENR3 {TARSKIK1 x} implies ( ex y1 be objectHIDDENM1 st y1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 y1)) & (( ex y1 be objectHIDDENM1 st y1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 y1) implies y inHIDDENR3 {TARSKIK1 x})"
          proof(rule ballI,rule conjMI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            show "y inHIDDENR3 {TARSKIK1 x} implies ( ex y1 be objectHIDDENM1 st y1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 y1)"
            proof-
              have "y inHIDDENR3 {TARSKIK1 x} implies  not ( for y1 be objectHIDDENM1 holds  not (y1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 y1))"
              proof(rule impI)
                assume "y inHIDDENR3 {TARSKIK1 x}"
                then have "y =HIDDENR1 x"
                  using tarski_def_1 sorry
                then have "f .FUNCT-1K1 ?z =HIDDENR1 y"
                  using A1 A3 sorry
                thus " not ( for y1 be objectHIDDENM1 holds  not (y1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 y1))"
                  using A3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            assume " ex y1 be objectHIDDENM1 st y1 inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 y1"
            then have "y =HIDDENR1 x"
              using A1 sorry
            thus "y inHIDDENR3 {TARSKIK1 x}"
              using tarski_def_1 sorry
          qed "sorry"
          then have "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 x}"
            using funct_1_def_3 sorry
          thus "f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
            using funcop_1_th_9 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K2 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_12:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 x) |RELAT-1K8 B =FUNCT-1R1 A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 x) |RELAT-1K8 B =FUNCT-1R1 A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have A2: "A /\\XBOOLE-0K3 B =XBOOLE-0R4 {}XBOOLE-0K1 or A /\\XBOOLE-0K3 B <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    have A3: "domRELAT-1K1 ((A -->FUNCOP-1K2 x) |RELAT-1K8 B) =HIDDENR1 domRELAT-1K1 (A -->FUNCOP-1K2 x) /\\XBOOLE-0K3 B"
      using relat_1_th_61 sorry
    also have "... = A /\\XBOOLE-0K3 B"
      using A1 relat_1_th_160 sorry
    also have "... = domRELAT-1K1 (A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x)"
      using A2 relat_1_th_160 sorry
    finally have "domRELAT-1K1 ((A -->FUNCOP-1K2 x) |RELAT-1K8 B) =HIDDENR1 domRELAT-1K1 (A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x)"
       sorry
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x) implies ((A -->FUNCOP-1K2 x) |RELAT-1K8 B).FUNCT-1K1 z =HIDDENR1 (A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x).FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A4: "z inHIDDENR3 domRELAT-1K1 (A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x)"
      have "A /\\XBOOLE-0K3 B =XBOOLE-0R4 {}XBOOLE-0K1 or A /\\XBOOLE-0K3 B <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      then have A5: "z inHIDDENR3 A /\\XBOOLE-0K3 B"
        using A4 relat_1_th_160 sorry
      then have A6: "z inHIDDENR3 A"
        using xboole_0_def_4 sorry
      have "((A -->FUNCOP-1K2 x) |RELAT-1K8 B).FUNCT-1K1 z =HIDDENR1 (A -->FUNCOP-1K2 x).FUNCT-1K1 z"
        using A3 A4 funct_1_th_47 sorry
      also have "... = x"
        using A6 funcop_1_th_7 sorry
      also have "... = (A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x).FUNCT-1K1 z"
        using A5 funcop_1_th_7 sorry
      finally show "((A -->FUNCOP-1K2 x) |RELAT-1K8 B).FUNCT-1K1 z =HIDDENR1 (A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x).FUNCT-1K1 z"
         sorry
    qed "sorry"
    thus "(A -->FUNCOP-1K2 x) |RELAT-1K8 B =FUNCT-1R1 A /\\XBOOLE-0K3 B -->FUNCOP-1K2 x"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_13:
" for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
proof-
  have " for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
    proof-
      show "domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
      proof-
        have cases: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
        proof(rule impI)
          assume A1: "A =XBOOLE-0R4 {}XBOOLE-0K1"
          show "domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
            using A1 sorry
        qed
        have case2: "A <>HIDDENR2 {}XBOOLE-0K1 implies domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
        proof(rule impI)
          assume "A <>HIDDENR2 {}XBOOLE-0K1"
          thus "domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
            using relat_1_th_160 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A & rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_14:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 B implies (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 A"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 B implies (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 A"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 B"
    have "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 A"
    proof-
      show "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 A"
      proof-
        have cases: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 A"
        proof(rule impI)
          assume A2: "A =XBOOLE-0R4 {}XBOOLE-0K1"
          show "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 A"
            using A2 sorry
        qed
        have case2: "A <>HIDDENR2 {}XBOOLE-0K1 implies (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =HIDDENR1 A"
        proof(rule impI)
          assume "A <>HIDDENR2 {}XBOOLE-0K1"
          then have A3: "rngFUNCT-1K2 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 {TARSKIK1 x}"
            using relat_1_th_160 sorry
          have "{TARSKIK1 x} c=TARSKIR1 B"
            using A1 zfmisc_1_th_31 sorry
          then have "{TARSKIK1 x} /\\XBOOLE-0K3 B =XBOOLE-0R4 {TARSKIK1 x}"
            using xboole_1_th_28 sorry
          then have "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =HIDDENR1 (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 {TARSKIK1 x}"
            using A3 relat_1_th_133 sorry
          also have "... = domRELAT-1K1 (A -->FUNCOP-1K2 x)"
            using A3 relat_1_th_134 sorry
          also have "... = A"
            using funcop_1_th_13 sorry
          finally show "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =HIDDENR1 A"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_15:
" for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 A"
proof-
  have " for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 A"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 A"
      using funcop_1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_16:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for x be objectHIDDENM1 holds  not x inHIDDENR3 B implies (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for x be objectHIDDENM1 holds  not x inHIDDENR3 B implies (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: " not x inHIDDENR3 B"
    have "rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    then have "rngFUNCT-1K2 (A -->FUNCOP-1K2 x) missesXBOOLE-0R1 B"
      using A1 xboole_1_th_63 zfmisc_1_th_50 sorry
    thus "(A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 B =XBOOLE-0R4 {}XBOOLE-0K1"
      using relat_1_th_138 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_17:
" for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h *FUNCT-1K3 (A -->FUNCOP-1K2 x) =FUNCT-1R1 A -->FUNCOP-1K2 h .FUNCT-1K1 x"
proof-
  have " for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h *FUNCT-1K3 (A -->FUNCOP-1K2 x) =FUNCT-1R1 A -->FUNCOP-1K2 h .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 h"
    have A2: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 (A -->FUNCOP-1K2 x)) implies (h *FUNCT-1K3 (A -->FUNCOP-1K2 x)).FUNCT-1K1 z =HIDDENR1 (A -->FUNCOP-1K2 h .FUNCT-1K1 x).FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A3: "z inHIDDENR3 domRELAT-1K1 (h *FUNCT-1K3 (A -->FUNCOP-1K2 x))"
      then have "z inHIDDENR3 domRELAT-1K1 (A -->FUNCOP-1K2 x)"
        using funct_1_th_11 sorry
      then have A4: "z inHIDDENR3 A"
        using funcop_1_th_13 sorry
      have "(h *FUNCT-1K3 (A -->FUNCOP-1K2 x)).FUNCT-1K1 z =HIDDENR1 h .FUNCT-1K1 ((A -->FUNCOP-1K2 x).FUNCT-1K1 z)"
        using A3 funct_1_th_12 sorry
      also have "... = h .FUNCT-1K1 x"
        using A4 funcop_1_th_7 sorry
      also have "... = (A -->FUNCOP-1K2 h .FUNCT-1K1 x).FUNCT-1K1 z"
        using A4 funcop_1_th_7 sorry
      finally show "(h *FUNCT-1K3 (A -->FUNCOP-1K2 x)).FUNCT-1K1 z =HIDDENR1 (A -->FUNCOP-1K2 h .FUNCT-1K1 x).FUNCT-1K1 z"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (h *FUNCT-1K3 (A -->FUNCOP-1K2 x)) =HIDDENR1 (A -->FUNCOP-1K2 x)\<inverse>FUNCT-1K6 (domRELAT-1K1 h)"
      using relat_1_th_147 sorry
    also have "... = A"
      using A1 funcop_1_th_14 sorry
    also have "... = domRELAT-1K1 (A -->FUNCOP-1K2 h .FUNCT-1K1 x)"
      using funcop_1_th_13 sorry
    finally have "domRELAT-1K1 (h *FUNCT-1K3 (A -->FUNCOP-1K2 x)) =HIDDENR1 domRELAT-1K1 (A -->FUNCOP-1K2 h .FUNCT-1K1 x)"
       sorry
    thus "h *FUNCT-1K3 (A -->FUNCOP-1K2 x) =FUNCT-1R1 A -->FUNCOP-1K2 h .FUNCT-1K1 x"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_18:
" for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds A <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 domRELAT-1K1 h implies domRELAT-1K1 (h *FUNCT-1K3 (A -->FUNCOP-1K2 x)) <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds A <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 domRELAT-1K1 h implies  not domRELAT-1K1 (h *FUNCT-1K3 (A -->FUNCOP-1K2 x)) <>HIDDENR2 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "x inHIDDENR3 domRELAT-1K1 h"
    let ?y = "the ElementSUBSET-1M1-of A"
    have "?y inTARSKIR2 A"
      using A1 sorry
    then have A3: "?y inTARSKIR2 domRELAT-1K1 (A -->FUNCOP-1K2 x)"
      using funcop_1_th_13 sorry
    have "(A -->FUNCOP-1K2 x).FUNCT-1K1 ?y =HIDDENR1 x"
      using A1 funcop_1_th_7 sorry
    thus " not domRELAT-1K1 (h *FUNCT-1K3 (A -->FUNCOP-1K2 x)) <>HIDDENR2 {}XBOOLE-0K1"
      using A2 A3 funct_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_19:
" for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 x)*FUNCT-1K3 h =FUNCT-1R1 h \<inverse>FUNCT-1K6 A -->FUNCOP-1K2 x"
proof-
  have " for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 x)*FUNCT-1K3 h =FUNCT-1R1 h \<inverse>FUNCT-1K6 A -->FUNCOP-1K2 x"
  proof(rule ballI,rule ballI,rule ballI)
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "domRELAT-1K1 ((A -->FUNCOP-1K2 x)*FUNCT-1K3 h) =HIDDENR1 h \<inverse>FUNCT-1K6 (domRELAT-1K1 (A -->FUNCOP-1K2 x))"
      using relat_1_th_147 sorry
    also have "... = h \<inverse>FUNCT-1K6 A"
      using funcop_1_th_13 sorry
    finally have "domRELAT-1K1 ((A -->FUNCOP-1K2 x)*FUNCT-1K3 h) =HIDDENR1 h \<inverse>FUNCT-1K6 A"
       sorry
    have A2: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 ((A -->FUNCOP-1K2 x)*FUNCT-1K3 h) implies ((A -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 (h \<inverse>FUNCT-1K6 A -->FUNCOP-1K2 x).FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A3: "z inHIDDENR3 domRELAT-1K1 ((A -->FUNCOP-1K2 x)*FUNCT-1K3 h)"
      then have "h .FUNCT-1K1 z inTARSKIR2 domRELAT-1K1 (A -->FUNCOP-1K2 x)"
        using funct_1_th_11 sorry
      then have A4: "h .FUNCT-1K1 z inTARSKIR2 A"
        using funcop_1_th_13 sorry
      have "((A -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 (A -->FUNCOP-1K2 x).FUNCT-1K1 (h .FUNCT-1K1 z)"
        using A3 funct_1_th_12 sorry
      also have "... = x"
        using A4 funcop_1_th_7 sorry
      also have "... = (h \<inverse>FUNCT-1K6 A -->FUNCOP-1K2 x).FUNCT-1K1 z"
        using A1 A3 funcop_1_th_7 sorry
      finally show "((A -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 (h \<inverse>FUNCT-1K6 A -->FUNCOP-1K2 x).FUNCT-1K1 z"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((A -->FUNCOP-1K2 x)*FUNCT-1K3 h) =XBOOLE-0R4 domRELAT-1K1 (h \<inverse>FUNCT-1K6 A -->FUNCOP-1K2 x)"
      using A1 funcop_1_th_13 sorry
    thus "(A -->FUNCOP-1K2 x)*FUNCT-1K3 h =FUNCT-1R1 h \<inverse>FUNCT-1K6 A -->FUNCOP-1K2 x"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_20:
" for A be setHIDDENM2 holds  for y be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1 =FUNCT-1R1 A -->FUNCOP-1K2 [TARSKIK4 y,x ]"
proof-
  have " for A be setHIDDENM2 holds  for y be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1 =FUNCT-1R1 A -->FUNCOP-1K2 [TARSKIK4 y,x ]"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "domRELAT-1K1 ((A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1) =XBOOLE-0R4 domRELAT-1K1 (A -->FUNCOP-1K2 [TARSKIK4 x,y ])"
      using funcop_1_def_1 sorry
    then have A2: "domRELAT-1K1 ((A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1) =XBOOLE-0R4 A"
      using funcop_1_th_13 sorry
    have A3: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 ((A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1) implies (A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1 .FUNCT-1K1 z =HIDDENR1 (A -->FUNCOP-1K2 [TARSKIK4 y,x ]).FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A4: "z inHIDDENR3 domRELAT-1K1 ((A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1)"
      then have "(A -->FUNCOP-1K2 [TARSKIK4 x,y ]).FUNCT-1K1 z =HIDDENR1 [TARSKIK4 x,y ]"
        using A2 funcop_1_th_7 sorry
      then have "(A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1 .FUNCT-1K1 z =HIDDENR1 [TARSKIK4 y,x ]"
        using A1 A4 funcop_1_def_1 sorry
      also have "... = (A -->FUNCOP-1K2 [TARSKIK4 y,x ]).FUNCT-1K1 z"
        using A2 A4 funcop_1_th_7 sorry
      finally show "(A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1 .FUNCT-1K1 z =HIDDENR1 (A -->FUNCOP-1K2 [TARSKIK4 y,x ]).FUNCT-1K1 z"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1) =XBOOLE-0R4 domRELAT-1K1 (A -->FUNCOP-1K2 [TARSKIK4 y,x ])"
      using A2 funcop_1_th_13 sorry
    thus "(A -->FUNCOP-1K2 [TARSKIK4 x,y ])~FUNCOP-1K1 =FUNCT-1R1 A -->FUNCOP-1K2 [TARSKIK4 y,x ]"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funcop_1_def_3 (" _ .:FUNCOP-1K3'( _ , _ ')" [200,0,0]200 ) where
  mlet "F be FunctionFUNCT-1M1", "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"func F .:FUNCOP-1K3(f,g) \<rightarrow> setHIDDENM2 equals
  F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)"
proof-
  (*coherence*)
    show "F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funcop_1_cl_5:
  mlet "F be FunctionFUNCT-1M1", "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"cluster F .:FUNCOP-1K3(f,g) as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "F .:FUNCOP-1K3(f,g) be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mlemma funcop_1_lm_1:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)) implies (F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)) implies (F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>))"
    then have A2: "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
      using funct_1_th_11 sorry
    have "(F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 F .FUNCT-1K1 ((<:FUNCT-3K14 f,g :>).FUNCT-1K1 x)"
      using A1 funct_1_th_12 sorry
    also have "... = F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
      using A2 funct_3_def_7 sorry
    finally show "(F *FUNCT-1K3 (<:FUNCT-3K14 f,g :>)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_21:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) & ( for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) implies h .FUNCT-1K1 z =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 z,g .FUNCT-1K1 z)) implies h =FUNCT-1R1 F .:FUNCOP-1K3(f,g)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) & ( for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) implies h .FUNCT-1K1 z =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 z,g .FUNCT-1K1 z)) implies h =FUNCT-1R1 F .:FUNCOP-1K3(f,g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 (F .:FUNCOP-1K3(f,g))"
      and A2: " for z be setHIDDENM2 holds z inTARSKIR2 domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) implies h .FUNCT-1K1 z =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 z,g .FUNCT-1K1 z)"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) implies h .FUNCT-1K1 z =HIDDENR1 (F .:FUNCOP-1K3(f,g)).FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A3: "z inHIDDENR3 domRELAT-1K1 (F .:FUNCOP-1K3(f,g))"
      then have "h .FUNCT-1K1 z =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 z,g .FUNCT-1K1 z)"
        using A2 sorry
      also have "... = (F .:FUNCOP-1K3(f,g)).FUNCT-1K1 z"
        using A3 funcop_1_lm_1 sorry
      finally show "h .FUNCT-1K1 z =HIDDENR1 (F .:FUNCOP-1K3(f,g)).FUNCT-1K1 z"
         sorry
    qed "sorry"
    thus "h =FUNCT-1R1 F .:FUNCOP-1K3(f,g)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_22:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) implies (F .:FUNCOP-1K3(f,g)).FUNCT-1K1 x =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
  using funcop_1_lm_1 sorry

mtheorem funcop_1_th_23:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F .:FUNCOP-1K3(f,h)) |RELAT-1K8 A =FUNCT-1R1 (F .:FUNCOP-1K3(g,h)) |RELAT-1K8 A"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F .:FUNCOP-1K3(f,h)) |RELAT-1K8 A =HIDDENR1 (F .:FUNCOP-1K3(g,h)) |RELAT-1K8 A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    assume A1: "f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A"
    have "(F .:FUNCOP-1K3(f,h)) |RELAT-1K8 A =HIDDENR1 F *FUNCT-1K3 (<:FUNCT-3K14 f,h :>) |RELAT-1K8 A"
      using relat_1_th_83 sorry
    also have "... = F *FUNCT-1K3 (<:FUNCT-3K14 f  |RELAT-1K8 A,h :>)"
      using funcop_1_th_5 sorry
    also have "... = F *FUNCT-1K3 (<:FUNCT-3K14 g,h :>) |RELAT-1K8 A"
      using A1 funcop_1_th_5 sorry
    also have "... = (F .:FUNCOP-1K3(g,h)) |RELAT-1K8 A"
      using relat_1_th_83 sorry
    finally show "(F .:FUNCOP-1K3(f,h)) |RELAT-1K8 A =HIDDENR1 (F .:FUNCOP-1K3(g,h)) |RELAT-1K8 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_24:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F .:FUNCOP-1K3(h,f)) |RELAT-1K8 A =FUNCT-1R1 (F .:FUNCOP-1K3(h,g)) |RELAT-1K8 A"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F .:FUNCOP-1K3(h,f)) |RELAT-1K8 A =HIDDENR1 (F .:FUNCOP-1K3(h,g)) |RELAT-1K8 A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    assume A1: "f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A"
    have "(F .:FUNCOP-1K3(h,f)) |RELAT-1K8 A =HIDDENR1 F *FUNCT-1K3 (<:FUNCT-3K14 h,f :>) |RELAT-1K8 A"
      using relat_1_th_83 sorry
    also have "... = F *FUNCT-1K3 (<:FUNCT-3K14 h,f  |RELAT-1K8 A :>)"
      using funcop_1_th_6 sorry
    also have "... = F *FUNCT-1K3 (<:FUNCT-3K14 h,g :>) |RELAT-1K8 A"
      using A1 funcop_1_th_6 sorry
    also have "... = (F .:FUNCOP-1K3(h,g)) |RELAT-1K8 A"
      using relat_1_th_83 sorry
    finally show "(F .:FUNCOP-1K3(h,f)) |RELAT-1K8 A =HIDDENR1 (F .:FUNCOP-1K3(h,g)) |RELAT-1K8 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_25:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds F .:FUNCOP-1K3(f,g) *FUNCT-1K3 h =FUNCT-1R1 F .:FUNCOP-1K3(f *FUNCT-1K3 h,g *FUNCT-1K3 h)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds F .:FUNCOP-1K3(f,g) *FUNCT-1K3 h =HIDDENR1 F .:FUNCOP-1K3(f *FUNCT-1K3 h,g *FUNCT-1K3 h)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    have "F .:FUNCOP-1K3(f,g) *FUNCT-1K3 h =HIDDENR1 F *FUNCT-1K3 ((<:FUNCT-3K14 f,g :>)*FUNCT-1K3 h)"
      using relat_1_th_36 sorry
    also have "... = F .:FUNCOP-1K3(f *FUNCT-1K3 h,g *FUNCT-1K3 h)"
      using funct_3_th_55 sorry
    finally show "F .:FUNCOP-1K3(f,g) *FUNCT-1K3 h =HIDDENR1 F .:FUNCOP-1K3(f *FUNCT-1K3 h,g *FUNCT-1K3 h)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funcop_1_def_4 (" _ [:]FUNCOP-1K4'( _ , _ ')" [180,0,0]180 ) where
  mlet "F be FunctionFUNCT-1M1", "f be FunctionFUNCT-1M1", "x be objectHIDDENM1"
"func F [:]FUNCOP-1K4(f,x) \<rightarrow> setHIDDENM2 equals
  F *FUNCT-1K3 (<:FUNCT-3K14 f,domRELAT-1K1 f -->FUNCOP-1K2 x :>)"
proof-
  (*coherence*)
    show "F *FUNCT-1K3 (<:FUNCT-3K14 f,domRELAT-1K1 f -->FUNCOP-1K2 x :>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funcop_1_cl_6:
  mlet "F be FunctionFUNCT-1M1", "f be FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster F [:]FUNCOP-1K4(f,x) as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "F [:]FUNCOP-1K4(f,x) be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem funcop_1_th_26:
" for f be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [:]FUNCOP-1K4(f,x) =FUNCT-1R1 F .:FUNCOP-1K3(f,domRELAT-1K1 f -->FUNCOP-1K2 x)"
   sorry

mtheorem funcop_1_th_27:
" for f be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F [:]FUNCOP-1K4(f,z)) implies (F [:]FUNCOP-1K4(f,z)).FUNCT-1K1 x =XBOOLE-0R4 F .BINOP-1K1(f .FUNCT-1K1 x,z)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F [:]FUNCOP-1K4(f,z)) implies (F [:]FUNCOP-1K4(f,z)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 x,z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    have A1: "domRELAT-1K1 (<:FUNCT-3K14 f,domRELAT-1K1 f -->FUNCOP-1K2 z :>) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K2 z)"
      using funct_3_def_7 sorry
    assume A2: "x inHIDDENR3 domRELAT-1K1 (F [:]FUNCOP-1K4(f,z))"
    then have "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 f,domRELAT-1K1 f -->FUNCOP-1K2 z :>)"
      using funct_1_th_11 sorry
    then have A3: "x inHIDDENR3 domRELAT-1K1 f"
      using A1 xboole_0_def_4 sorry
    have "(F [:]FUNCOP-1K4(f,z)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 x,(domRELAT-1K1 f -->FUNCOP-1K2 z).FUNCT-1K1 x)"
      using A2 funcop_1_lm_1 sorry
    also have "... = F .BINOP-1K1(f .FUNCT-1K1 x,z)"
      using A3 funcop_1_th_7 sorry
    finally show "(F [:]FUNCOP-1K4(f,z)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 x,z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_28:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F [:]FUNCOP-1K4(f,x)) |RELAT-1K8 A =FUNCT-1R1 (F [:]FUNCOP-1K4(g,x)) |RELAT-1K8 A"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F [:]FUNCOP-1K4(f,x)) |RELAT-1K8 A =HIDDENR1 (F [:]FUNCOP-1K4(g,x)) |RELAT-1K8 A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A"
    have "domRELAT-1K1 f /\\XBOOLE-0K3 A =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 A)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 g /\\XBOOLE-0K3 A"
      using A1 relat_1_th_61 sorry
    finally have "domRELAT-1K1 f /\\XBOOLE-0K3 A =HIDDENR1 domRELAT-1K1 g /\\XBOOLE-0K3 A"
       sorry
    then have A2: "(domRELAT-1K1 f -->FUNCOP-1K2 x) |RELAT-1K8 A =HIDDENR1 domRELAT-1K1 g /\\XBOOLE-0K3 A -->FUNCOP-1K2 x"
      using funcop_1_th_12 sorry
    also have "... = (domRELAT-1K1 g -->FUNCOP-1K2 x) |RELAT-1K8 A"
      using funcop_1_th_12 sorry
    finally have "(domRELAT-1K1 f -->FUNCOP-1K2 x) |RELAT-1K8 A =HIDDENR1 (domRELAT-1K1 g -->FUNCOP-1K2 x) |RELAT-1K8 A"
       sorry
    have "(F [:]FUNCOP-1K4(f,x)) |RELAT-1K8 A =HIDDENR1 (F .:FUNCOP-1K3(f,domRELAT-1K1 f -->FUNCOP-1K2 x)) |RELAT-1K8 A"
       sorry
    also have "... = (F .:FUNCOP-1K3(g,domRELAT-1K1 f -->FUNCOP-1K2 x)) |RELAT-1K8 A"
      using A1 funcop_1_th_23 sorry
    also have "... = (F .:FUNCOP-1K3(g,domRELAT-1K1 g -->FUNCOP-1K2 x)) |RELAT-1K8 A"
      using A2 funcop_1_th_24 sorry
    also have "... = (F [:]FUNCOP-1K4(g,x)) |RELAT-1K8 A"
       sorry
    finally show "(F [:]FUNCOP-1K4(f,x)) |RELAT-1K8 A =HIDDENR1 (F [:]FUNCOP-1K4(g,x)) |RELAT-1K8 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_29:
" for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 h =FUNCT-1R1 F [:]FUNCOP-1K4(f *FUNCT-1K3 h,x)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 h =HIDDENR1 F [:]FUNCOP-1K4(f *FUNCT-1K3 h,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K2 x) =XBOOLE-0R4 domRELAT-1K1 f"
      using funcop_1_th_13 sorry
    then have A2: "domRELAT-1K1 ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h) =XBOOLE-0R4 domRELAT-1K1 (f *FUNCT-1K3 h)"
      using relat_1_th_163 sorry
    have A3: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h) implies ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 x"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A4: "z inHIDDENR3 domRELAT-1K1 ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h)"
      then have A5: "h .FUNCT-1K1 z inTARSKIR2 domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K2 x)"
        using funct_1_th_11 sorry
      have "((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 (domRELAT-1K1 f -->FUNCOP-1K2 x).FUNCT-1K1 (h .FUNCT-1K1 z)"
        using A4 funct_1_th_12 sorry
      also have "... = x"
        using A1 A5 funcop_1_th_7 sorry
      finally show "((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 x"
         sorry
    qed "sorry"
    have "F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 h =HIDDENR1 F .:FUNCOP-1K3(f,domRELAT-1K1 f -->FUNCOP-1K2 x) *FUNCT-1K3 h"
       sorry
    also have "... = F .:FUNCOP-1K3(f *FUNCT-1K3 h,(domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h)"
      using funcop_1_th_25 sorry
    also have "... = F [:]FUNCOP-1K4(f *FUNCT-1K3 h,x)"
      using A2 A3 funcop_1_th_11 sorry
    finally show "F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 h =HIDDENR1 F [:]FUNCOP-1K4(f *FUNCT-1K3 h,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_30:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 idPARTFUN1K6 A =FUNCT-1R1 F [:]FUNCOP-1K4(f  |RELAT-1K8 A,x)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 idPARTFUN1K6 A =HIDDENR1 F [:]FUNCOP-1K4(f  |RELAT-1K8 A,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 idPARTFUN1K6 A =HIDDENR1 F [:]FUNCOP-1K4(f *FUNCT-1K3 idPARTFUN1K6 A,x)"
      using funcop_1_th_29 sorry
    also have "... = F [:]FUNCOP-1K4(f  |RELAT-1K8 A,x)"
      using relat_1_th_65 sorry
    finally show "F [:]FUNCOP-1K4(f,x) *FUNCT-1K3 idPARTFUN1K6 A =HIDDENR1 F [:]FUNCOP-1K4(f  |RELAT-1K8 A,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funcop_1_def_5 (" _ [;]FUNCOP-1K5'( _ , _ ')" [180,0,0]180 ) where
  mlet "F be FunctionFUNCT-1M1", "x be objectHIDDENM1", "g be FunctionFUNCT-1M1"
"func F [;]FUNCOP-1K5(x,g) \<rightarrow> setHIDDENM2 equals
  F *FUNCT-1K3 (<:FUNCT-3K14 domRELAT-1K1 g -->FUNCOP-1K2 x,g :>)"
proof-
  (*coherence*)
    show "F *FUNCT-1K3 (<:FUNCT-3K14 domRELAT-1K1 g -->FUNCOP-1K2 x,g :>) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funcop_1_cl_7:
  mlet "F be FunctionFUNCT-1M1", "x be objectHIDDENM1", "g be FunctionFUNCT-1M1"
"cluster F [;]FUNCOP-1K5(x,g) as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "F [;]FUNCOP-1K5(x,g) be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem funcop_1_th_31:
" for g be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [;]FUNCOP-1K5(x,g) =FUNCT-1R1 F .:FUNCOP-1K3(domRELAT-1K1 g -->FUNCOP-1K2 x,g)"
   sorry

mtheorem funcop_1_th_32:
" for f be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F [;]FUNCOP-1K5(z,f)) implies (F [;]FUNCOP-1K5(z,f)).FUNCT-1K1 x =XBOOLE-0R4 F .BINOP-1K1(z,f .FUNCT-1K1 x)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F [;]FUNCOP-1K5(z,f)) implies (F [;]FUNCOP-1K5(z,f)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1(z,f .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    have A1: "domRELAT-1K1 (<:FUNCT-3K14 domRELAT-1K1 f -->FUNCOP-1K2 z,f :>) =XBOOLE-0R4 domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K2 z) /\\XBOOLE-0K3 domRELAT-1K1 f"
      using funct_3_def_7 sorry
    assume A2: "x inHIDDENR3 domRELAT-1K1 (F [;]FUNCOP-1K5(z,f))"
    then have "x inHIDDENR3 domRELAT-1K1 (<:FUNCT-3K14 domRELAT-1K1 f -->FUNCOP-1K2 z,f :>)"
      using funct_1_th_11 sorry
    then have A3: "x inHIDDENR3 domRELAT-1K1 f"
      using A1 xboole_0_def_4 sorry
    have "(F [;]FUNCOP-1K5(z,f)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1((domRELAT-1K1 f -->FUNCOP-1K2 z).FUNCT-1K1 x,f .FUNCT-1K1 x)"
      using A2 funcop_1_lm_1 sorry
    also have "... = F .BINOP-1K1(z,f .FUNCT-1K1 x)"
      using A3 funcop_1_th_7 sorry
    finally show "(F [;]FUNCOP-1K5(z,f)).FUNCT-1K1 x =HIDDENR1 F .BINOP-1K1(z,f .FUNCT-1K1 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_33:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F [;]FUNCOP-1K5(x,f)) |RELAT-1K8 A =FUNCT-1R1 (F [;]FUNCOP-1K5(x,g)) |RELAT-1K8 A"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A implies (F [;]FUNCOP-1K5(x,f)) |RELAT-1K8 A =HIDDENR1 (F [;]FUNCOP-1K5(x,g)) |RELAT-1K8 A"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "f  |RELAT-1K8 A =FUNCT-1R1 g  |RELAT-1K8 A"
    have "domRELAT-1K1 f /\\XBOOLE-0K3 A =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 A)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 g /\\XBOOLE-0K3 A"
      using A1 relat_1_th_61 sorry
    finally have "domRELAT-1K1 f /\\XBOOLE-0K3 A =HIDDENR1 domRELAT-1K1 g /\\XBOOLE-0K3 A"
       sorry
    then have A2: "(domRELAT-1K1 f -->FUNCOP-1K2 x) |RELAT-1K8 A =HIDDENR1 domRELAT-1K1 g /\\XBOOLE-0K3 A -->FUNCOP-1K2 x"
      using funcop_1_th_12 sorry
    also have "... = (domRELAT-1K1 g -->FUNCOP-1K2 x) |RELAT-1K8 A"
      using funcop_1_th_12 sorry
    finally have "(domRELAT-1K1 f -->FUNCOP-1K2 x) |RELAT-1K8 A =HIDDENR1 (domRELAT-1K1 g -->FUNCOP-1K2 x) |RELAT-1K8 A"
       sorry
    have "(F [;]FUNCOP-1K5(x,f)) |RELAT-1K8 A =HIDDENR1 (F .:FUNCOP-1K3(domRELAT-1K1 f -->FUNCOP-1K2 x,f)) |RELAT-1K8 A"
       sorry
    also have "... = (F .:FUNCOP-1K3(domRELAT-1K1 f -->FUNCOP-1K2 x,g)) |RELAT-1K8 A"
      using A1 funcop_1_th_24 sorry
    also have "... = (F .:FUNCOP-1K3(domRELAT-1K1 g -->FUNCOP-1K2 x,g)) |RELAT-1K8 A"
      using A2 funcop_1_th_23 sorry
    also have "... = (F [;]FUNCOP-1K5(x,g)) |RELAT-1K8 A"
       sorry
    finally show "(F [;]FUNCOP-1K5(x,f)) |RELAT-1K8 A =HIDDENR1 (F [;]FUNCOP-1K5(x,g)) |RELAT-1K8 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_34:
" for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 h =FUNCT-1R1 F [;]FUNCOP-1K5(x,f *FUNCT-1K3 h)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 h =HIDDENR1 F [;]FUNCOP-1K5(x,f *FUNCT-1K3 h)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K2 x) =XBOOLE-0R4 domRELAT-1K1 f"
      using funcop_1_th_13 sorry
    then have A2: "domRELAT-1K1 ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h) =XBOOLE-0R4 domRELAT-1K1 (f *FUNCT-1K3 h)"
      using relat_1_th_163 sorry
    have A3: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h) implies ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 x"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A4: "z inHIDDENR3 domRELAT-1K1 ((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h)"
      then have A5: "h .FUNCT-1K1 z inTARSKIR2 domRELAT-1K1 (domRELAT-1K1 f -->FUNCOP-1K2 x)"
        using funct_1_th_11 sorry
      have "((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 (domRELAT-1K1 f -->FUNCOP-1K2 x).FUNCT-1K1 (h .FUNCT-1K1 z)"
        using A4 funct_1_th_12 sorry
      also have "... = x"
        using A1 A5 funcop_1_th_7 sorry
      finally show "((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h).FUNCT-1K1 z =HIDDENR1 x"
         sorry
    qed "sorry"
    have "F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 h =HIDDENR1 F .:FUNCOP-1K3(domRELAT-1K1 f -->FUNCOP-1K2 x,f) *FUNCT-1K3 h"
       sorry
    also have "... = F .:FUNCOP-1K3((domRELAT-1K1 f -->FUNCOP-1K2 x)*FUNCT-1K3 h,f *FUNCT-1K3 h)"
      using funcop_1_th_25 sorry
    also have "... = F [;]FUNCOP-1K5(x,f *FUNCT-1K3 h)"
      using A2 A3 funcop_1_th_11 sorry
    finally show "F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 h =HIDDENR1 F [;]FUNCOP-1K5(x,f *FUNCT-1K3 h)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_35:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 idPARTFUN1K6 A =FUNCT-1R1 F [;]FUNCOP-1K5(x,f  |RELAT-1K8 A)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for F be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 idPARTFUN1K6 A =HIDDENR1 F [;]FUNCOP-1K5(x,f  |RELAT-1K8 A)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    have "F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 idPARTFUN1K6 A =HIDDENR1 F [;]FUNCOP-1K5(x,f *FUNCT-1K3 idPARTFUN1K6 A)"
      using funcop_1_th_34 sorry
    also have "... = F [;]FUNCOP-1K5(x,f  |RELAT-1K8 A)"
      using relat_1_th_65 sorry
    finally show "F [;]FUNCOP-1K5(x,f) *FUNCT-1K3 idPARTFUN1K6 A =HIDDENR1 F [;]FUNCOP-1K5(x,f  |RELAT-1K8 A)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve X for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Y for "setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f, g, h for "FunctionFUNCT-2M1-of(Y,X)"
mtheorem funcop_1_th_36:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds F .:FUNCOP-1K3(f,g) be FunctionFUNCT-2M1-of(Y,X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds F .:FUNCOP-1K3(f,g) be FunctionFUNCT-2M1-of(Y,X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    have "F *PARTFUN1K1\<^bsub>(Y,[:ZFMISC-1K2 X,X :],[:ZFMISC-1K2 X,X :],X)\<^esub> (<:FUNCT-3K15\<^bsub>(Y,X,X)\<^esub> f,g :>) be FunctionFUNCT-2M1-of(Y,X)"
       sorry
    thus "F .:FUNCOP-1K3(f,g) be FunctionFUNCT-2M1-of(Y,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCOP_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .:FUNCOP-1K6\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [200,0,0,0,0]200)
translations "F .:FUNCOP-1K6\<^bsub>(X,Z)\<^esub>(f,g)" \<rightharpoonup> "F .:FUNCOP-1K3(f,g)"

mtheorem funcop_1_add_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Z be setHIDDENM2", "F be BinOpBINOP-1M2-of X", "f be FunctionFUNCT-2M1-of(Z,X)", "g be FunctionFUNCT-2M1-of(Z,X)"
"cluster F .:FUNCOP-1K3(f,g) as-term-is FunctionFUNCT-2M1-of(Z,X)"
proof
(*coherence*)
  show "F .:FUNCOP-1K3(f,g) be FunctionFUNCT-2M1-of(Z,X)"
    using funcop_1_th_36 sorry
qed "sorry"

reserve Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f, g, h for "FunctionFUNCT-2M1-of(Y,X)"
reserve x, x1, x2 for "ElementSUBSET-1M1-of X"
mtheorem funcop_1_th_37:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for z be ElementSUBSET-1M1-of Y holds (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z,g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for z be ElementSUBSET-1M1-of Y holds (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z,g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of Y"
    have "domRELSET-1K1\<^bsub>(Y)\<^esub> (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)) =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    thus "(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z,g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z)"
      using funcop_1_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_38:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for h be FunctionFUNCT-2M1-of(Y,X) holds ( for z be ElementSUBSET-1M1-of Y holds h .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z,g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z)) implies h =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for h be FunctionFUNCT-2M1-of(Y,X) holds ( for z be ElementSUBSET-1M1-of Y holds h .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z,g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z)) implies h =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(Y,X)"
    assume A1: " for z be ElementSUBSET-1M1-of Y holds h .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z,g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z)"
    have " for z be ElementSUBSET-1M1-of Y holds h .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> z"
    proof(rule ballI)
      fix z assume [ty]: "z be ElementSUBSET-1M1-of Y"
      have "h .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z,g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z)"
        using A1 sorry
      also have "... = (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> z"
        using funcop_1_th_37 sorry
      finally show "h .FUNCT-2K3\<^bsub>(Y,X)\<^esub> z =HIDDENR1 (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> z"
         sorry
    qed "sorry"
    thus "h =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_39:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have "F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(idPARTFUN1K6 X *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
      using funcop_1_th_25 sorry
    also have "... = F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
      using funct_2_th_17 sorry
    finally show "F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_40:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(X,X) holds F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have "F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,idPARTFUN1K6 X *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
      using funcop_1_th_25 sorry
    also have "... = F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,f)"
      using funct_2_th_17 sorry
    finally show "F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_41:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    have "F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(idPARTFUN1K6 X *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,idPARTFUN1K6 X *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
      using funcop_1_th_25 sorry
    also have "... = F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(idPARTFUN1K6 X *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,f)"
      using funct_2_th_17 sorry
    also have "... = F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f)"
      using funct_2_th_17 sorry
    finally show "F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_42:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds  for g be FunctionFUNCT-2M1-of(X,X) holds (F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds  for g be FunctionFUNCT-2M1-of(X,X) holds (F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have "(F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(idPARTFUN1K6 X .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
      using funcop_1_th_37 sorry
    also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x,g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
       sorry
    finally show "(F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,g)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_43:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds  for g be FunctionFUNCT-2M1-of(X,X) holds (F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds  for g be FunctionFUNCT-2M1-of(X,X) holds (F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,X)"
    have "(F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,idPARTFUN1K6 X .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
      using funcop_1_th_37 sorry
    also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,x)"
       sorry
    finally show "(F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(g,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(g .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_44:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds (F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds (F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "(F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(idPARTFUN1K6 X .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,idPARTFUN1K6 X .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
      using funcop_1_th_37 sorry
    also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(idPARTFUN1K6 X .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,x)"
       sorry
    also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
       sorry
    finally show "(F .:FUNCOP-1K6\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_45:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies A -->FUNCOP-1K2 x be FunctionFUNCT-2M1-of(A,B)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies A -->FUNCOP-1K2 x be FunctionFUNCT-2M1-of(A,B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have A1: "rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    have A2: "domRELAT-1K1 (A -->FUNCOP-1K2 x) =XBOOLE-0R4 A"
      using funcop_1_th_13 sorry
    assume A3: "x inTARSKIR2 B"
    then have "{TARSKIK1 x} c=TARSKIR1 B"
      using zfmisc_1_th_31 sorry
    then have "rngFUNCT-1K2 (A -->FUNCOP-1K2 x) c=TARSKIR1 B"
      using A1 sorry
    thus "A -->FUNCOP-1K2 x be FunctionFUNCT-2M1-of(A,B)"
      using A3 A2 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCOP_1K7(" _ -->FUNCOP-1K7  _ " [116,116]116) where
  "I -->FUNCOP-1K7 i \<equiv> I -->FUNCOP-1K2 i"

mtheorem funcop_1_add_2:
  mlet "I be setHIDDENM2", "i be objectHIDDENM1"
"cluster I -->FUNCOP-1K2 i as-term-is FunctionFUNCT-2M1-of(I,{TARSKIK1 i})"
proof
(*coherence*)
  show "I -->FUNCOP-1K2 i be FunctionFUNCT-2M1-of(I,{TARSKIK1 i})"
  proof-
    have "domRELAT-1K1 (I -->FUNCOP-1K2 i) =XBOOLE-0R4 I & rngFUNCT-1K2 (I -->FUNCOP-1K2 i) c=TARSKIR1 {TARSKIK1 i}"
      using funcop_1_th_13 sorry
    thus "I -->FUNCOP-1K2 i be FunctionFUNCT-2M1-of(I,{TARSKIK1 i})"
      using funct_2_def_1 relset_1_th_4 sorry
  qed
qed "sorry"

syntax FUNCOP_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -->FUNCOP-1K8\<^bsub>'( _ ')\<^esub>  _ " [116,0,116]116)
translations "A -->FUNCOP-1K8\<^bsub>(B)\<^esub> b" \<rightharpoonup> "A -->FUNCOP-1K2 b"

mtheorem funcop_1_add_3:
  mlet "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "A be setHIDDENM2", "b be ElementSUBSET-1M1-of B"
"cluster A -->FUNCOP-1K2 b as-term-is FunctionFUNCT-2M1-of(A,B)"
proof
(*coherence*)
  show "A -->FUNCOP-1K2 b be FunctionFUNCT-2M1-of(A,B)"
    using funcop_1_th_45 sorry
qed "sorry"

mtheorem funcop_1_th_46:
" for A be setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds A -->FUNCOP-1K8\<^bsub>(X)\<^esub> x be FunctionFUNCT-2M1-of(A,X)"
   sorry

reserve Y for "setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f, g, h for "FunctionFUNCT-2M1-of(Y,X)"
reserve x, x1, x2 for "ElementSUBSET-1M1-of X"
mtheorem funcop_1_th_47:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [:]FUNCOP-1K4(f,x) be FunctionFUNCT-2M1-of(Y,X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [:]FUNCOP-1K4(f,x) be FunctionFUNCT-2M1-of(Y,X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "domRELSET-1K1\<^bsub>(Y)\<^esub> f =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    then obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(Y,X)" and gDef:"g = domRELSET-1K1\<^bsub>(Y)\<^esub> f -->FUNCOP-1K8\<^bsub>(X)\<^esub> x"
       sorry
    have "F *PARTFUN1K1\<^bsub>(Y,[:ZFMISC-1K2 X,X :],[:ZFMISC-1K2 X,X :],X)\<^esub> (<:FUNCT-3K15\<^bsub>(Y,X,X)\<^esub> f,g :>) be FunctionFUNCT-2M1-of(Y,X)"
       sorry
    thus "F [:]FUNCOP-1K4(f,x) be FunctionFUNCT-2M1-of(Y,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCOP_1K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [:]FUNCOP-1K9\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [180,0,0,0,0]180)
translations "F [:]FUNCOP-1K9\<^bsub>(X,Z)\<^esub>(f,x)" \<rightharpoonup> "F [:]FUNCOP-1K4(f,x)"

mtheorem funcop_1_add_4:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Z be setHIDDENM2", "F be BinOpBINOP-1M2-of X", "f be FunctionFUNCT-2M1-of(Z,X)", "x be ElementSUBSET-1M1-of X"
"cluster F [:]FUNCOP-1K4(f,x) as-term-is FunctionFUNCT-2M1-of(Z,X)"
proof
(*coherence*)
  show "F [:]FUNCOP-1K4(f,x) be FunctionFUNCT-2M1-of(Z,X)"
    using funcop_1_th_47 sorry
qed "sorry"

reserve Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f, g, h for "FunctionFUNCT-2M1-of(Y,X)"
reserve x, x1, x2 for "ElementSUBSET-1M1-of X"
mtheorem funcop_1_th_48:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
    have "domRELSET-1K1\<^bsub>(Y)\<^esub> (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)) =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    thus "(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,x)"
      using funcop_1_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_49:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds ( for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,x)) implies g =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds ( for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,x)) implies g =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A1: " for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,x)"
    have " for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
    proof(rule ballI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
      have "g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,x)"
        using A1 sorry
      also have "... = (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
        using funcop_1_th_48 sorry
      finally show "g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
         sorry
    qed "sorry"
    thus "g =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_50:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(idPARTFUN1K6 X *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f,x)"
      using funcop_1_th_29 sorry
    also have "... = F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
      using funct_2_th_17 sorry
    finally show "F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_51:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds (F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds (F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "(F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(idPARTFUN1K6 X .FUNCT-2K3\<^bsub>(X,X)\<^esub> x,x)"
      using funcop_1_th_48 sorry
    also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
       sorry
    finally show "(F [:]FUNCOP-1K9\<^bsub>(X,X)\<^esub>(idPARTFUN1K6 X,x)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve Y for "setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f, g, h for "FunctionFUNCT-2M1-of(Y,X)"
reserve x, x1, x2 for "ElementSUBSET-1M1-of X"
mtheorem funcop_1_th_52:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [;]FUNCOP-1K5(x,g) be FunctionFUNCT-2M1-of(Y,X)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [;]FUNCOP-1K5(x,g) be FunctionFUNCT-2M1-of(Y,X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "domRELSET-1K1\<^bsub>(Y)\<^esub> g =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    then obtain f where 
      [ty]:"f be FunctionFUNCT-2M1-of(Y,X)" and fDef:"f = domRELSET-1K1\<^bsub>(Y)\<^esub> g -->FUNCOP-1K8\<^bsub>(X)\<^esub> x"
       sorry
    have "F *PARTFUN1K1\<^bsub>(Y,[:ZFMISC-1K2 X,X :],[:ZFMISC-1K2 X,X :],X)\<^esub> (<:FUNCT-3K15\<^bsub>(Y,X,X)\<^esub> f,g :>) be FunctionFUNCT-2M1-of(Y,X)"
       sorry
    thus "F [;]FUNCOP-1K5(x,g) be FunctionFUNCT-2M1-of(Y,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax FUNCOP_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ [;]FUNCOP-1K10\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [180,0,0,0,0]180)
translations "F [;]FUNCOP-1K10\<^bsub>(X,Z)\<^esub>(x,g)" \<rightharpoonup> "F [;]FUNCOP-1K5(x,g)"

mtheorem funcop_1_add_5:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Z be setHIDDENM2", "F be BinOpBINOP-1M2-of X", "x be ElementSUBSET-1M1-of X", "g be FunctionFUNCT-2M1-of(Z,X)"
"cluster F [;]FUNCOP-1K5(x,g) as-term-is FunctionFUNCT-2M1-of(Z,X)"
proof
(*coherence*)
  show "F [;]FUNCOP-1K5(x,g) be FunctionFUNCT-2M1-of(Z,X)"
    using funcop_1_th_52 sorry
qed "sorry"

reserve Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f, g, h for "FunctionFUNCT-2M1-of(Y,X)"
reserve x, x1, x2 for "ElementSUBSET-1M1-of X"
mtheorem funcop_1_th_53:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
    have "domRELSET-1K1\<^bsub>(Y)\<^esub> (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)) =XBOOLE-0R4 Y"
      using funct_2_def_1 sorry
    thus "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)"
      using funcop_1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_54:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds ( for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)) implies g =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds ( for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)) implies g =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A1: " for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)"
    have " for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
    proof(rule ballI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
      have "g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)"
        using A1 sorry
      also have "... = (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
        using funcop_1_th_53 sorry
      finally show "g .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
         sorry
    qed "sorry"
    thus "g =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve Y for "setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f, g, h for "FunctionFUNCT-2M1-of(Y,X)"
reserve x, x1, x2 for "ElementSUBSET-1M1-of X"
mtheorem funcop_1_th_55:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,idPARTFUN1K6 X *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f)"
      using funcop_1_th_34 sorry
    also have "... = F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)"
      using funct_2_th_17 sorry
    finally show "F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X) *PARTFUN1K1\<^bsub>(Y,X,X,X)\<^esub> f =HIDDENR1 F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_56:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds (F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for x be ElementSUBSET-1M1-of X holds (F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "(F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,idPARTFUN1K6 X .FUNCT-2K3\<^bsub>(X,X)\<^esub> x)"
      using funcop_1_th_53 sorry
    also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
       sorry
    finally show "(F [;]FUNCOP-1K10\<^bsub>(X,X)\<^esub>(x,idPARTFUN1K6 X)).FUNCT-2K3\<^bsub>(X,X)\<^esub> x =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_57:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :]) holds  for x be ElementSUBSET-1M1-of X holds f ~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> x)`2XTUPLE-0K2,(f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> x)`1XTUPLE-0K1 ]"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
  have "x inTARSKIR2 X"
     sorry
  then have A1: "x inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> f"
    using funct_2_def_1 sorry
  have "f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> x =HIDDENR1 [TARSKIK4 (f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> x)`1XTUPLE-0K1,(f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> x)`2XTUPLE-0K2 ]"
    using mcart_1_th_22 sorry
  thus "f ~FUNCOP-1K1 .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 (f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> x)`2XTUPLE-0K2,(f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> x)`1XTUPLE-0K1 ]"
    using A1 funcop_1_def_1 sorry
qed "sorry"

syntax FUNCOP_1K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("rngFUNCOP-1K11\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [0,0,0,228]228)
translations "rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f" \<rightharpoonup> "proj2XTUPLE-0K13 f"

mtheorem funcop_1_add_6:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
"cluster proj2XTUPLE-0K13 f as-term-is RelationRELSET-1M1-of(Y,Z)"
proof
(*coherence*)
  show "proj2XTUPLE-0K13 f be RelationRELSET-1M1-of(Y,Z)"
    using relat_1_def_19 sorry
qed "sorry"

syntax FUNCOP_1K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ~FUNCOP-1K12\<^bsub>'( _ , _ , _ ')\<^esub>" [228,0,0,0]228)
translations "f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>" \<rightharpoonup> "f ~FUNCOP-1K1"

mtheorem funcop_1_add_7:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
"cluster f ~FUNCOP-1K1 as-term-is FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Z,Y :])"
proof
(*coherence*)
  show "f ~FUNCOP-1K1 be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Z,Y :])"
  proof-
    have A1: "rngFUNCT-1K2 (f ~FUNCOP-1K1) c=TARSKIR1 [:ZFMISC-1K2 Z,Y :]"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f ~FUNCOP-1K1) implies x inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (f ~FUNCOP-1K1)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A2: "y inHIDDENR3 domRELAT-1K1 (f ~FUNCOP-1K1)"and A3: "x =HIDDENR1 f ~FUNCOP-1K1 .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have A4: "y inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
          using A2 funcop_1_def_1 sorry
        then have 
          [ty]:"y be ElementSUBSET-1M1-of X"
           sorry
        have A5: "f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> y =HIDDENR1 [TARSKIK4 (f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> y)`1XTUPLE-0K1,(f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> y)`2XTUPLE-0K2 ]"
          using mcart_1_th_21 sorry
        then have "f ~FUNCOP-1K1 .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 (f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> y)`2XTUPLE-0K2,(f .FUNCT-2K3\<^bsub>(X,[:ZFMISC-1K2 Y,Z :])\<^esub> y)`1XTUPLE-0K1 ]"
          using A4 funcop_1_def_1 sorry
        thus "x inHIDDENR3 [:ZFMISC-1K2 Z,Y :]"
          using A3 A5 zfmisc_1_th_88 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (f ~FUNCOP-1K1) c=TARSKIR1 [:ZFMISC-1K2 Z,Y :]"
        using tarski_def_3 sorry
    qed
    have "X =HIDDENR1 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using funct_2_def_1 sorry
    also have "... = domRELAT-1K1 (f ~FUNCOP-1K1)"
      using funcop_1_def_1 sorry
    finally have "X =HIDDENR1 domRELAT-1K1 (f ~FUNCOP-1K1)"
       sorry
    thus "f ~FUNCOP-1K1 be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Z,Y :])"
      using A1 funct_2_def_1 relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem funcop_1_th_58:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :]) holds rngFUNCOP-1K11\<^bsub>(X,Z,Y)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>) =RELSET-1R2\<^bsub>(Z,Y)\<^esub> (rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f)~RELSET-1K3\<^bsub>(Y,Z)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,[:ZFMISC-1K2 Y,Z :])"
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 rngFUNCOP-1K11\<^bsub>(X,Z,Y)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>) implies [TARSKIK4 x,y ] inHIDDENR3 (rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f)~RELSET-1K3\<^bsub>(Y,Z)\<^esub>) & ([TARSKIK4 x,y ] inHIDDENR3 (rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f)~RELSET-1K3\<^bsub>(Y,Z)\<^esub> implies [TARSKIK4 x,y ] inHIDDENR3 rngFUNCOP-1K11\<^bsub>(X,Z,Y)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>))"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "[TARSKIK4 x,y ] inHIDDENR3 rngFUNCOP-1K11\<^bsub>(X,Z,Y)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>) implies [TARSKIK4 x,y ] inHIDDENR3 (rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f)~RELSET-1K3\<^bsub>(Y,Z)\<^esub>"
    proof(rule impI)
      assume "[TARSKIK4 x,y ] inHIDDENR3 rngFUNCOP-1K11\<^bsub>(X,Z,Y)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>)"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A1: "z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>)"and A2: "[TARSKIK4 x,y ] =HIDDENR1 f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub> .FUNCT-1K1 z"
        using funct_1_def_3 sorry
      have A3: "z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"
        using A1 funcop_1_def_1 sorry
      have "f .FUNCT-1K1 z =HIDDENR1 (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>)~FUNCOP-1K12\<^bsub>(X,Z,Y)\<^esub> .FUNCT-1K1 z"
         sorry
      also have "... = [TARSKIK4 y,x ]"
        using A1 A2 funcop_1_def_1 sorry
      finally have "f .FUNCT-1K1 z =HIDDENR1 [TARSKIK4 y,x ]"
         sorry
      then have "[TARSKIK4 y,x ] inHIDDENR3 rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f"
        using A3 funct_1_def_3 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 (rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f)~RELSET-1K3\<^bsub>(Y,Z)\<^esub>"
        using relat_1_def_7 sorry
    qed
    assume "[TARSKIK4 x,y ] inHIDDENR3 (rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f)~RELSET-1K3\<^bsub>(Y,Z)\<^esub>"
    then have "[TARSKIK4 y,x ] inHIDDENR3 rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f"
      using relat_1_def_7 sorry
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A4: "z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & [TARSKIK4 y,x ] =HIDDENR1 f .FUNCT-1K1 z"
      using funct_1_def_3 sorry
    have "z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>) & f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub> .FUNCT-1K1 z =HIDDENR1 [TARSKIK4 x,y ]"
      using A4 funcop_1_def_1 sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 rngFUNCOP-1K11\<^bsub>(X,Z,Y)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>)"
      using funct_1_def_3 sorry
  qed "sorry"
  thus "rngFUNCOP-1K11\<^bsub>(X,Z,Y)\<^esub> (f ~FUNCOP-1K12\<^bsub>(X,Y,Z)\<^esub>) =RELSET-1R2\<^bsub>(Z,Y)\<^esub> (rngFUNCOP-1K11\<^bsub>(X,Y,Z)\<^esub> f)~RELSET-1K3\<^bsub>(Y,Z)\<^esub>"
    using relat_1_def_2 sorry
qed "sorry"

reserve y for "ElementSUBSET-1M1-of Y"
mtheorem funcop_1_th_59:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(X)\<^esub>"
    show "F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2))"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2))"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2))"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2))"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(x1,(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2)).FUNCT-1K1 y)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x3 where 
            [ty]:"x3 be ElementSUBSET-1M1-of X" and x3Def:"x3 = f .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1((F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f)).FUNCT-1K1 y,x2)"
            using A2 funcop_1_th_48 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x3),x2)"
            using A2 funcop_1_th_53 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,F .BINOP-1K4\<^bsub>(X)\<^esub>(x3,x2))"
            using A1 sorry
          also have "... = F .BINOP-1K1(x1,(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2)).FUNCT-1K1 y)"
            using A2 funcop_1_th_48 sorry
          finally show "(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(x1,(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2)).FUNCT-1K1 y)"
             sorry
        qed "sorry"
        thus "F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,f),x2) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x2))"
          using A2 funcop_1_th_54 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_60:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(X)\<^esub>"
    show "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g))"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g))"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g))"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g))"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g)).FUNCT-1K1 y)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x1 x2 where 
            [ty]:"x1 be ElementSUBSET-1M1-of X" and x1Def:"x1 = f .FUNCT-1K1 y" and
            [ty]:"x2 be ElementSUBSET-1M1-of X" and x2Def:"x2 = g .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1((F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)).FUNCT-1K1 y,g .FUNCT-1K1 y)"
            using A2 funcop_1_th_37 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x),x2)"
            using A2 funcop_1_th_48 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x2))"
            using A1 sorry
          also have "... = F .BINOP-1K1(f .FUNCT-1K1 y,(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g)).FUNCT-1K1 y)"
            using A2 funcop_1_th_53 sorry
          finally show "(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g)).FUNCT-1K1 y)"
             sorry
        qed "sorry"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,g))"
          using A2 funcop_1_th_38 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_61:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for h be FunctionFUNCT-2M1-of(Y,X) holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for h be FunctionFUNCT-2M1-of(Y,X) holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(Y,X)"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(X)\<^esub>"
    show "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h))"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h))"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h))"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h))"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h)).FUNCT-1K1 y)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x1 x2 x3 where 
            [ty]:"x1 be ElementSUBSET-1M1-of X" and x1Def:"x1 = f .FUNCT-1K1 y" and
            [ty]:"x2 be ElementSUBSET-1M1-of X" and x2Def:"x2 = g .FUNCT-1K1 y" and
            [ty]:"x3 be ElementSUBSET-1M1-of X" and x3Def:"x3 = h .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1((F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-1K1 y,h .FUNCT-1K1 y)"
            using A2 funcop_1_th_37 sorry
          also have "... = F .BINOP-1K1(F .BINOP-1K1(f .FUNCT-1K1 y,g .FUNCT-1K1 y),h .FUNCT-1K1 y)"
            using A2 funcop_1_th_37 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,F .BINOP-1K4\<^bsub>(X)\<^esub>(x2,x3))"
            using A1 sorry
          also have "... = F .BINOP-1K1(f .FUNCT-1K1 y,(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h)).FUNCT-1K1 y)"
            using A2 funcop_1_th_37 sorry
          finally show "(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h)).FUNCT-1K1 y)"
             sorry
        qed "sorry"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g),h) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,h))"
          using A2 funcop_1_th_38 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_62:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(X)\<^esub>"
    show "F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f))"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f))"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f))"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f))"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(x1,(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f)).FUNCT-1K1 y)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x3 where 
            [ty]:"x3 be ElementSUBSET-1M1-of X" and x3Def:"x3 = f .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f .FUNCT-1K1 y)"
            using A2 funcop_1_th_53 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,F .BINOP-1K4\<^bsub>(X)\<^esub>(x2,x3))"
            using A1 sorry
          also have "... = F .BINOP-1K1(x1,(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f)).FUNCT-1K1 y)"
            using A2 funcop_1_th_53 sorry
          finally show "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(x1,(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f)).FUNCT-1K1 y)"
             sorry
        qed "sorry"
        thus "F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2),f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x1,F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x2,f))"
          using A2 funcop_1_th_54 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_63:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1),x2)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x1 be ElementSUBSET-1M1-of X holds  for x2 be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1),x2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of X"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of X"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(X)\<^esub>"
    show "F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1),x2)"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1),x2)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1),x2)"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1),x2)"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2))).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1((F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1)).FUNCT-1K1 y,x2)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x3 where 
            [ty]:"x3 be ElementSUBSET-1M1-of X" and x3Def:"x3 = f .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2))).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2))"
            using A2 funcop_1_th_48 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x3,x1),x2)"
            using A1 sorry
          also have "... = F .BINOP-1K1((F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1)).FUNCT-1K1 y,x2)"
            using A2 funcop_1_th_48 sorry
          finally show "(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2))).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1((F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1)).FUNCT-1K1 y,x2)"
             sorry
        qed "sorry"
        thus "F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x1),x2)"
          using A2 funcop_1_th_49 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_64:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F be commutativeBINOP-1V1\<^bsub>(X)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F be commutativeBINOP-1V1\<^bsub>(X)\<^esub> implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(X)\<^esub>"
    show "F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,x)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x1 where 
            [ty]:"x1 be ElementSUBSET-1M1-of X" and x1Def:"x1 = f .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x1)"
            using A2 funcop_1_th_53 sorry
          also have "... = F .BINOP-1K1(f .FUNCT-1K1 y,x)"
            using A1 sorry
          finally show "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,x)"
             sorry
        qed "sorry"
        thus "F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,x)"
          using A2 funcop_1_th_49 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_65:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds F be commutativeBINOP-1V1\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds F be commutativeBINOP-1V1\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(X)\<^esub>"
    show "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,f)"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,f)"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,f)"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,f)"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(g .FUNCT-1K1 y,f .FUNCT-1K1 y)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x1 x2 where 
            [ty]:"x1 be ElementSUBSET-1M1-of X" and x1Def:"x1 = f .FUNCT-1K1 y" and
            [ty]:"x2 be ElementSUBSET-1M1-of X" and x2Def:"x2 = g .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2)"
            using A2 funcop_1_th_37 sorry
          also have "... = F .BINOP-1K1(g .FUNCT-1K1 y,f .FUNCT-1K1 y)"
            using A1 sorry
          finally show "(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(g .FUNCT-1K1 y,f .FUNCT-1K1 y)"
             sorry
        qed "sorry"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(g,f)"
          using A2 funcop_1_th_38 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_66:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds F be idempotentBINOP-1V3\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> f"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds F be idempotentBINOP-1V3\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =HIDDENR1 f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(X)\<^esub>"
    show "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =HIDDENR1 f"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =HIDDENR1 f"
      proof(rule impI)
        assume A2: "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =HIDDENR1 {}XBOOLE-0K1"
           sorry
        also have "... = f"
          using A2 sorry
        finally show "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =HIDDENR1 f"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> f"
      proof(rule impI)
        assume A3: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds f .FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,f .FUNCT-1K1 y)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x where 
            [ty]:"x be ElementSUBSET-1M1-of X" and xDef:"x = f .FUNCT-1K1 y"
            using A3 funct_2_th_5 sorry
          have "f .FUNCT-1K1 y =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x)"
            using A1 sorry
          also have "... = F .BINOP-1K1(f .FUNCT-1K1 y,f .FUNCT-1K1 y)"
             sorry
          finally show "f .FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(f .FUNCT-1K1 y,f .FUNCT-1K1 y)"
             sorry
        qed "sorry"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,f) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> f"
          using A3 funcop_1_th_38 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of X"
reserve f for "FunctionFUNCT-2M1-of(Y,X)"
reserve x for "ElementSUBSET-1M1-of X"
reserve y for "ElementSUBSET-1M1-of Y"
mtheorem funcop_1_th_67:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for y be ElementSUBSET-1M1-of Y holds F be idempotentBINOP-1V3\<^bsub>(X)\<^esub> implies (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for y be ElementSUBSET-1M1-of Y holds F be idempotentBINOP-1V3\<^bsub>(X)\<^esub> implies (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(X)\<^esub>"
    have "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)"
      using funcop_1_th_53 sorry
    also have "... = f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
      using A1 sorry
    finally show "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,f)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_68:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for y be ElementSUBSET-1M1-of Y holds F be idempotentBINOP-1V3\<^bsub>(X)\<^esub> implies (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for y be ElementSUBSET-1M1-of Y holds F be idempotentBINOP-1V3\<^bsub>(X)\<^esub> implies (F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(X)\<^esub>"
    have "(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 F .BINOP-1K4\<^bsub>(X)\<^esub>(f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)"
      using funcop_1_th_48 sorry
    also have "... = f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
      using A1 sorry
    finally show "(F [:]FUNCOP-1K9\<^bsub>(X,Y)\<^esub>(f,f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y)).FUNCT-2K3\<^bsub>(Y,X)\<^esub> y =HIDDENR1 f .FUNCT-2K3\<^bsub>(Y,X)\<^esub> y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_69:
" for F be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 domRELAT-1K1 F implies domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 domRELAT-1K1 F implies domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) =HIDDENR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "[:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :] c=RELAT-1R2 domRELAT-1K1 F"
    have "rngFUNCT-1K2 (<:FUNCT-3K14 f,g :>) c=TARSKIR1 [:ZFMISC-1K2 rngFUNCT-1K2 f,rngFUNCT-1K2 g :]"
      using funct_3_th_51 sorry
    then have "domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) =HIDDENR1 domRELAT-1K1 (<:FUNCT-3K14 f,g :>)"
      using A1 relat_1_th_27 xboole_1_th_1 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
      using funct_3_def_7 sorry
    finally show "domRELAT-1K1 (F .:FUNCOP-1K3(f,g)) =HIDDENR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funcop_1_def_6 ("Function-yieldingFUNCOP-1V1" 70 ) where
"attr Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 IT implies IT .FUNCT-1K1 x be FunctionFUNCT-1M1)"..

mtheorem funcop_1_cl_8:
"cluster Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be Function-yieldingFUNCOP-1V1"
  proof-
    have " ex tVar5 be FunctionFUNCT-1M1 st tVar5 be Function-yieldingFUNCOP-1V1"
    proof-
      show " ex tVar5 be FunctionFUNCT-1M1 st tVar5 be Function-yieldingFUNCOP-1V1"
      proof(rule bexI[of _ "(the setHIDDENM2)-->FUNCOP-1K7 (the FunctionFUNCT-1M1)"])
        have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 ((the setHIDDENM2)-->FUNCOP-1K7 (the FunctionFUNCT-1M1)) &  not ((the setHIDDENM2)-->FUNCOP-1K7 (the FunctionFUNCT-1M1)).FUNCT-1K1 x be FunctionFUNCT-1M1)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " not (x inHIDDENR3 domRELAT-1K1 ((the setHIDDENM2)-->FUNCOP-1K7 (the FunctionFUNCT-1M1)) &  not ((the setHIDDENM2)-->FUNCOP-1K7 (the FunctionFUNCT-1M1)).FUNCT-1K1 x be FunctionFUNCT-1M1)"
             sorry
        qed "sorry"
        thus "(the setHIDDENM2)-->FUNCOP-1K7 (the FunctionFUNCT-1M1) be Function-yieldingFUNCOP-1V1"
          using funcop_1_def_6 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_cl_9:
  mlet "B be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1", "j be objectHIDDENM1"
"cluster B .FUNCT-1K1 j as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "B .FUNCT-1K1 j be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
  proof-
    have "B .FUNCT-1K1 j be Function-likeFUNCT-1V1 & B .FUNCT-1K1 j be Relation-likeRELAT-1V1"
    proof-
      show "B .FUNCT-1K1 j be Function-likeFUNCT-1V1 & B .FUNCT-1K1 j be Relation-likeRELAT-1V1"
      proof-
        have cases: "j inHIDDENR3 domRELAT-1K1 B or  not j inHIDDENR3 domRELAT-1K1 B"
           sorry
        have case1: "j inHIDDENR3 domRELAT-1K1 B implies B .FUNCT-1K1 j be Function-likeFUNCT-1V1 & B .FUNCT-1K1 j be Relation-likeRELAT-1V1"
        proof(rule impI)
          assume "j inHIDDENR3 domRELAT-1K1 B"
          thus "B .FUNCT-1K1 j be Function-likeFUNCT-1V1 & B .FUNCT-1K1 j be Relation-likeRELAT-1V1"
            using funcop_1_def_6 sorry
        qed
        have case2: " not j inHIDDENR3 domRELAT-1K1 B implies B .FUNCT-1K1 j be Function-likeFUNCT-1V1 & B .FUNCT-1K1 j be Relation-likeRELAT-1V1"
        proof(rule impI)
          assume " not j inHIDDENR3 domRELAT-1K1 B"
          thus "B .FUNCT-1K1 j be Function-likeFUNCT-1V1 & B .FUNCT-1K1 j be Relation-likeRELAT-1V1"
            using funct_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_cl_10:
  mlet "F be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1", "f be FunctionFUNCT-1M1"
"cluster F *FUNCT-1K3 f as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "F *FUNCT-1K3 f be Function-yieldingFUNCOP-1V1"
  proof-
    show "F *FUNCT-1K3 f be Function-yieldingFUNCOP-1V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 f) implies (F *FUNCT-1K3 f).FUNCT-1K1 x be FunctionFUNCT-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 f)"
        then have "(F *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using funct_1_th_12 sorry
        thus "(F *FUNCT-1K3 f).FUNCT-1K1 x be FunctionFUNCT-1M1"
           sorry
      qed "sorry"
      thus "F *FUNCT-1K3 f be Function-yieldingFUNCOP-1V1"
        using funcop_1_def_6 sorry
    qed
  qed
qed "sorry"

mtheorem funcop_1_cl_11:
  mlet "B be setHIDDENM2", "c be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster B -->FUNCOP-1K7 c as-term-is non-emptyFUNCT-1V4"
proof
(*coherence*)
  show "B -->FUNCOP-1K7 c be non-emptyFUNCT-1V4"
  proof-
    have "B -->FUNCOP-1K7 c be non-emptyRELAT-1V2"
    proof-
      have " not {}XBOOLE-0K1 inTARSKIR2 rngRELSET-1K2\<^bsub>({TARSKIK1 c})\<^esub> (B -->FUNCOP-1K7 c)"
        using tarski_def_1 sorry
      thus "B -->FUNCOP-1K7 c be non-emptyRELAT-1V2"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_th_70:
" for z be objectHIDDENM1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds ([:ZFMISC-1K2 X,Y :] -->FUNCOP-1K7 z).BINOP-1K2\<^bsub>(X,Y,{TARSKIK1 z})\<^esub>(x,y) =HIDDENR1 z"
  using funcop_1_th_7 zfmisc_1_th_87 sorry

reserve a, b, c for "setHIDDENM2"
mdef funcop_1_def_7 ("'( _ , _ ').-->FUNCOP-1K13  _ " [0,0,164]164 ) where
  mlet "a be objectHIDDENM1", "b be objectHIDDENM1", "c be objectHIDDENM1"
"func (a,b).-->FUNCOP-1K13 c \<rightarrow> FunctionFUNCT-1M1 equals
  {TARSKIK1 [TARSKIK4 a,b ] } -->FUNCOP-1K7 c"
proof-
  (*coherence*)
    show "{TARSKIK1 [TARSKIK4 a,b ] } -->FUNCOP-1K7 c be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem funcop_1_th_71:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds ((a,b).-->FUNCOP-1K13 c).BINOP-1K1(a,b) =HIDDENR1 c"
proof(rule ballI,rule ballI,rule ballI)
  fix a assume [ty]: "a be objectHIDDENM1"
  fix b assume [ty]: "b be objectHIDDENM1"
  fix c assume [ty]: "c be objectHIDDENM1"
  have "[TARSKIK4 a,b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 a,b ] }"
    using tarski_def_1 sorry
  thus "((a,b).-->FUNCOP-1K13 c).BINOP-1K1(a,b) =HIDDENR1 c"
    using funcop_1_th_7 sorry
qed "sorry"

mdef funcop_1_def_8 ("IFEQFUNCOP-1K14'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"func IFEQFUNCOP-1K14(x,y,a,b) \<rightarrow> objectHIDDENM1 equals
  a if x =HIDDENR1 y otherwise b"
proof-
  (*coherence*)
    show "(x =HIDDENR1 y implies a be objectHIDDENM1) & ( not x =HIDDENR1 y implies b be objectHIDDENM1)"
       sorry
  (*consistency*)
    show " for it be objectHIDDENM1 holds  True "
       sorry
qed "sorry"

abbreviation(input) FUNCOP_1K15("IFEQFUNCOP-1K15'( _ , _ , _ , _ ')" [0,0,0,0]164) where
  "IFEQFUNCOP-1K15(x,y,a,b) \<equiv> IFEQFUNCOP-1K14(x,y,a,b)"

mtheorem funcop_1_add_8:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1", "a be setHIDDENM2", "b be setHIDDENM2"
"cluster IFEQFUNCOP-1K14(x,y,a,b) as-term-is setHIDDENM2"
proof
(*coherence*)
  show "IFEQFUNCOP-1K14(x,y,a,b) be setHIDDENM2"
  proof-
    have "x =HIDDENR1 y or x <>HIDDENR2 y"
       sorry
    thus "IFEQFUNCOP-1K14(x,y,a,b) be setHIDDENM2"
      using funcop_1_def_8 sorry
  qed
qed "sorry"

syntax FUNCOP_1K16 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("IFEQFUNCOP-1K16\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ ')" [0,0,0,0,0]164)
translations "IFEQFUNCOP-1K16\<^bsub>(D)\<^esub>(x,y,a,b)" \<rightharpoonup> "IFEQFUNCOP-1K14(x,y,a,b)"

mtheorem funcop_1_add_9:
  mlet "D be setHIDDENM2", "x be objectHIDDENM1", "y be objectHIDDENM1", "a be ElementSUBSET-1M1-of D", "b be ElementSUBSET-1M1-of D"
"cluster IFEQFUNCOP-1K14(x,y,a,b) as-term-is ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show "IFEQFUNCOP-1K14(x,y,a,b) be ElementSUBSET-1M1-of D"
  proof-
    have "x =HIDDENR1 y or x <>HIDDENR2 y"
       sorry
    thus "IFEQFUNCOP-1K14(x,y,a,b) be ElementSUBSET-1M1-of D"
      using funcop_1_def_8 sorry
  qed
qed "sorry"

mdef funcop_1_def_9 (" _ .-->FUNCOP-1K17  _ " [164,164]164 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"func x .-->FUNCOP-1K17 y \<rightarrow> setHIDDENM2 equals
  {TARSKIK1 x} -->FUNCOP-1K7 y"
proof-
  (*coherence*)
    show "{TARSKIK1 x} -->FUNCOP-1K7 y be setHIDDENM2"
       sorry
qed "sorry"

mtheorem funcop_1_cl_12:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster x .-->FUNCOP-1K17 y as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "x .-->FUNCOP-1K17 y be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem funcop_1_cl_13:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster x .-->FUNCOP-1K17 y as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "x .-->FUNCOP-1K17 y be one-to-oneFUNCT-1V2"
  proof-
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y) & x2 inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y) implies  not ((x .-->FUNCOP-1K17 y).FUNCT-1K1 x1 =HIDDENR1 (x .-->FUNCOP-1K17 y).FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      let ?f = "x .-->FUNCOP-1K17 y"
      assume A1: "x1 inHIDDENR3 domRELAT-1K1 ?f"
        and A2: "x2 inHIDDENR3 domRELAT-1K1 ?f"
      have A3: "domRELAT-1K1 ?f =XBOOLE-0R4 {TARSKIK1 x}"
        using funcop_1_th_13 sorry
      then have "x1 =HIDDENR1 x"
        using A1 tarski_def_1 sorry
      thus " not ((x .-->FUNCOP-1K17 y).FUNCT-1K1 x1 =HIDDENR1 (x .-->FUNCOP-1K17 y).FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
        using A3 A2 tarski_def_1 sorry
    qed "sorry"
    thus "x .-->FUNCOP-1K17 y be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed
qed "sorry"

mtheorem funcop_1_th_72:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x .-->FUNCOP-1K17 y).FUNCT-1K1 x =HIDDENR1 y"
proof(rule ballI,rule ballI)
  fix x assume [ty]: "x be objectHIDDENM1"
  fix y assume [ty]: "y be objectHIDDENM1"
  have "x inHIDDENR3 {TARSKIK1 x}"
    using tarski_def_1 sorry
  thus "(x .-->FUNCOP-1K17 y).FUNCT-1K1 x =HIDDENR1 y"
    using funcop_1_th_7 sorry
qed "sorry"

mtheorem funcop_1_th_73:
" for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds a .-->FUNCOP-1K17 b c=RELAT-1R2 f iff a inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 a =HIDDENR1 b"
proof-
  have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds (a .-->FUNCOP-1K17 b c=RELAT-1R2 f implies a inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 a =HIDDENR1 b) & (a inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 a =HIDDENR1 b implies a .-->FUNCOP-1K17 b c=RELAT-1R2 f)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix a assume [ty]: "a be objectHIDDENM1"
    fix b assume [ty]: "b be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (a .-->FUNCOP-1K17 b) =XBOOLE-0R4 {TARSKIK1 a}"
      using funcop_1_th_13 sorry
    then have A2: "a inHIDDENR3 domRELAT-1K1 (a .-->FUNCOP-1K17 b)"
      using tarski_def_1 sorry
    show "a .-->FUNCOP-1K17 b c=RELAT-1R2 f implies a inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 a =HIDDENR1 b"
    proof(rule impI,rule conjMI)
      assume A3: "a .-->FUNCOP-1K17 b c=RELAT-1R2 f"
      then have "{TARSKIK1 a} c=TARSKIR1 domRELAT-1K1 f"
        using A1 grfunc_1_th_2 sorry
      thus "a inHIDDENR3 domRELAT-1K1 f"
        using zfmisc_1_th_31 sorry
      have "f .FUNCT-1K1 a =HIDDENR1 (a .-->FUNCOP-1K17 b).FUNCT-1K1 a"
        using A2 A3 grfunc_1_th_2 sorry
      also have "... = b"
        using funcop_1_th_72 sorry
      finally show "f .FUNCT-1K1 a =HIDDENR1 b"
         sorry
    qed
    assume A4: "a inHIDDENR3 domRELAT-1K1 f"
      and A5: "f .FUNCT-1K1 a =HIDDENR1 b"
    have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (a .-->FUNCOP-1K17 b) implies (a .-->FUNCOP-1K17 b).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 (a .-->FUNCOP-1K17 b)"
      then have "x =HIDDENR1 a"
        using A1 tarski_def_1 sorry
      thus "(a .-->FUNCOP-1K17 b).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A5 funcop_1_th_72 sorry
    qed "sorry"
    have "domRELAT-1K1 (a .-->FUNCOP-1K17 b) c=TARSKIR1 domRELAT-1K1 f"
      using A1 A4 zfmisc_1_th_31 sorry
    thus "a .-->FUNCOP-1K17 b c=RELAT-1R2 f"
      using A6 grfunc_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCOP_1K18("'( _ , _ '):->FUNCOP-1K18  _ " [0,0,228]228) where
  "(o,m):->FUNCOP-1K18 r \<equiv> (o,m).-->FUNCOP-1K13 r"

mlemma funcop_1_lm_2:
" for o be objectHIDDENM1 holds  for m be objectHIDDENM1 holds  for r be objectHIDDENM1 holds (o,m):->FUNCOP-1K18 r be FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r})"
proof(rule ballI,rule ballI,rule ballI)
  fix o assume [ty]: "o be objectHIDDENM1"
  fix m assume [ty]: "m be objectHIDDENM1"
  fix r assume [ty]: "r be objectHIDDENM1"
  have "[:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :] =RELAT-1R1 {TARSKIK1 [TARSKIK4 o,m ] }"
    using zfmisc_1_th_29 sorry
  then have "domRELAT-1K1 ((o,m):->FUNCOP-1K18 r) =XBOOLE-0R4 [:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :]"
    using funcop_1_th_13 sorry
  thus "(o,m):->FUNCOP-1K18 r be FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r})"
    using funct_2_def_1 sorry
qed "sorry"

abbreviation(input) FUNCOP_1K19("'( _ , _ '):->FUNCOP-1K19  _ " [0,0,228]228) where
  "(o,m):->FUNCOP-1K19 r \<equiv> (o,m).-->FUNCOP-1K13 r"

mtheorem funcop_1_def_10:
  mlet "o be objectHIDDENM1", "m be objectHIDDENM1", "r be objectHIDDENM1"
"redefine func (o,m):->FUNCOP-1K19 r \<rightarrow> FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r}) means
  \<lambda>it.  not  False "
proof
(*compatibility*)
  show " for it be FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r}) holds it =HIDDENR1 (o,m):->FUNCOP-1K19 r iff  not  False "
  proof-
    have " for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r}) holds  not (f =HIDDENR1 (o,m).-->FUNCOP-1K13 r &  not  True ) & f =HIDDENR1 (o,m).-->FUNCOP-1K13 r"
    proof(rule ballI)
      fix f assume [ty]: "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r})"
      have "(o,m).-->FUNCOP-1K13 r be FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r})"
        using funcop_1_lm_2 sorry
      thus " not (f =HIDDENR1 (o,m).-->FUNCOP-1K13 r &  not  True ) & f =HIDDENR1 (o,m).-->FUNCOP-1K13 r"
        using funct_2_th_51 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_add_10:
  mlet "o be objectHIDDENM1", "m be objectHIDDENM1", "r be objectHIDDENM1"
"cluster (o,m).-->FUNCOP-1K13 r as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r})"
proof
(*coherence*)
  show "(o,m).-->FUNCOP-1K13 r be FunctionFUNCT-2M1-of([:ZFMISC-1K2 {TARSKIK1 o},{TARSKIK1 m} :],{TARSKIK1 r})"
    using funcop_1_lm_2 sorry
qed "sorry"

reserve x, y, z for "objectHIDDENM1"
mtheorem funcop_1_th_74:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y)"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "domRELAT-1K1 (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    thus "x inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y)"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_75:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y) implies z =HIDDENR1 x"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  not (z inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y) &  not z =HIDDENR1 x)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    have "domRELAT-1K1 (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    thus " not (z inHIDDENR3 domRELAT-1K1 (x .-->FUNCOP-1K17 y) &  not z =HIDDENR1 x)"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_76:
" for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not x inHIDDENR3 A implies (x .-->FUNCOP-1K17 y) |RELAT-1K8 A =FUNCT-1R1 {}XBOOLE-0K1"
proof-
  have " for A be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not x inHIDDENR3 A implies (x .-->FUNCOP-1K17 y) |RELAT-1K8 A =FUNCT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume " not x inHIDDENR3 A"
    then have "{TARSKIK1 x} missesXBOOLE-0R1 A"
      using zfmisc_1_th_50 sorry
    then have "domRELAT-1K1 (x .-->FUNCOP-1K17 y) missesXBOOLE-0R1 A"
      using funcop_1_th_13 sorry
    thus "(x .-->FUNCOP-1K17 y) |RELAT-1K8 A =FUNCT-1R1 {}XBOOLE-0K1"
      using relat_1_th_66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCOP_1K20(" _ :->FUNCOP-1K20  _ " [228,228]228) where
  "x :->FUNCOP-1K20 y \<equiv> x .-->FUNCOP-1K17 y"

abbreviation(input) FUNCOP_1K21(" _ :->FUNCOP-1K21  _ " [228,228]228) where
  "m :->FUNCOP-1K21 o \<equiv> m .-->FUNCOP-1K17 o"

mtheorem funcop_1_add_11:
  mlet "m be objectHIDDENM1", "o be objectHIDDENM1"
"cluster m .-->FUNCOP-1K17 o as-term-is FunctionFUNCT-2M1-of({TARSKIK1 m},{TARSKIK1 o})"
proof
(*coherence*)
  show "m .-->FUNCOP-1K17 o be FunctionFUNCT-2M1-of({TARSKIK1 m},{TARSKIK1 o})"
     sorry
qed "sorry"

mtheorem funcop_1_th_77:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for x be ElementSUBSET-1M1-of {TARSKIK1 a} holds  for y be ElementSUBSET-1M1-of {TARSKIK1 b} holds (a,b):->FUNCOP-1K19 c .BINOP-1K2\<^bsub>({TARSKIK1 a},{TARSKIK1 b},{TARSKIK1 c})\<^esub>(x,y) =XBOOLE-0R4 c"
  using tarski_def_1 sorry

mtheorem funcop_1_cl_14:
  mlet "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1", "C be setHIDDENM2"
"cluster f  |RELAT-1K8 C as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "f  |RELAT-1K8 C be Function-yieldingFUNCOP-1V1"
  proof-
    have " for i be objectHIDDENM1 holds  not (i inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 C) &  not (f  |RELAT-1K8 C).FUNCT-1K1 i be FunctionFUNCT-1M1)"
    proof(rule ballI)
      fix i assume [ty]: "i be objectHIDDENM1"
      have "f .FUNCT-1K1 i be FunctionFUNCT-1M1"
         sorry
      thus " not (i inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 C) &  not (f  |RELAT-1K8 C).FUNCT-1K1 i be FunctionFUNCT-1M1)"
        using funct_1_th_47 sorry
    qed "sorry"
    thus "f  |RELAT-1K8 C be Function-yieldingFUNCOP-1V1"
      using funcop_1_def_6 sorry
  qed
qed "sorry"

mtheorem funcop_1_cl_15:
  mlet "A be setHIDDENM2", "f be FunctionFUNCT-1M1"
"cluster A -->FUNCOP-1K7 f as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "A -->FUNCOP-1K7 f be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mtheorem funcop_1_cl_16:
  mlet "X be setHIDDENM2", "a be objectHIDDENM1"
"cluster X -->FUNCOP-1K7 a as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "X -->FUNCOP-1K7 a be constantFUNCT-1V5"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 a) & y inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 a) implies (X -->FUNCOP-1K7 a).FUNCT-1K1 x =HIDDENR1 (X -->FUNCOP-1K7 a).FUNCT-1K1 y"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 a)"
        and A2: "y inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 a)"
      have "(X -->FUNCOP-1K7 a).FUNCT-1K1 x =HIDDENR1 a"
        using A1 funcop_1_th_7 sorry
      also have "... = (X -->FUNCOP-1K7 a).FUNCT-1K1 y"
        using A2 funcop_1_th_7 sorry
      finally show "(X -->FUNCOP-1K7 a).FUNCT-1K1 x =HIDDENR1 (X -->FUNCOP-1K7 a).FUNCT-1K1 y"
         sorry
    qed "sorry"
    thus "X -->FUNCOP-1K7 a be constantFUNCT-1V5"
      using funct_1_def_10 sorry
  qed
qed "sorry"

mtheorem funcop_1_cl_17:
"cluster  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5"
  proof-
    have " ex tVar6 be FunctionFUNCT-1M1 st  not tVar6 be emptyXBOOLE-0V1 & tVar6 be constantFUNCT-1V5"
    proof-
      show " ex tVar6 be FunctionFUNCT-1M1 st  not tVar6 be emptyXBOOLE-0V1 & tVar6 be constantFUNCT-1V5"
      proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 {}XBOOLE-0K1"])
        show " not {TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 {}XBOOLE-0K1 be emptyXBOOLE-0V1 & {TARSKIK1 {}XBOOLE-0K1 } -->FUNCOP-1K7 {}XBOOLE-0K1 be constantFUNCT-1V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_cl_18:
  mlet "X be setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster constantFUNCT-1V5 for FunctionFUNCT-2M1-of(X,Y)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(X,Y) st it be constantFUNCT-1V5"
  proof-
    have " ex tVar7 be FunctionFUNCT-2M1-of(X,Y) st tVar7 be constantFUNCT-1V5"
    proof-
      show " ex tVar7 be FunctionFUNCT-2M1-of(X,Y) st tVar7 be constantFUNCT-1V5"
      proof(rule bexI[of _ "X -->FUNCOP-1K8\<^bsub>(Y)\<^esub> (the ElementSUBSET-1M1-of Y)"])
        show "X -->FUNCOP-1K8\<^bsub>(Y)\<^esub> (the ElementSUBSET-1M1-of Y) be constantFUNCT-1V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_cl_19:
  mlet "f be constantFUNCT-1V5\<bar>FunctionFUNCT-1M1", "X be setHIDDENM2"
"cluster f  |RELAT-1K8 X as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "f  |RELAT-1K8 X be constantFUNCT-1V5"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) & y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies (f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 (f  |RELAT-1K8 X).FUNCT-1K1 y"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "domRELAT-1K1 (f  |RELAT-1K8 X) c=TARSKIR1 domRELAT-1K1 f"
        using relat_1_th_60 sorry
      assume A2: "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
        and A3: "y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
      have "(f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
        using A2 funct_1_th_47 sorry
      also have "... = f .FUNCT-1K1 y"
        using A1 A2 A3 funct_1_def_10 sorry
      also have "... = (f  |RELAT-1K8 X).FUNCT-1K1 y"
        using A3 funct_1_th_47 sorry
      finally show "(f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 (f  |RELAT-1K8 X).FUNCT-1K1 y"
         sorry
    qed "sorry"
    thus "f  |RELAT-1K8 X be constantFUNCT-1V5"
      using funct_1_def_10 sorry
  qed
qed "sorry"

mtheorem funcop_1_th_78:
" for f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5\<bar>FunctionFUNCT-1M1 holds  ex y be objectHIDDENM1 st  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 y"
proof-
  have " for f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5\<bar>FunctionFUNCT-1M1 holds  ex tVar8 be objectHIDDENM1 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x =HIDDENR1 tVar8)"
  proof(rule ballI)
    fix f assume [ty]: "f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5\<bar>FunctionFUNCT-1M1"
    obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A1: "y inHIDDENR3 rngFUNCT-1K2 f"
      using xboole_0_def_1 sorry
    show " ex tVar8 be objectHIDDENM1 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x =HIDDENR1 tVar8)"
    proof(rule bexI[of _ "y"])
      have " ex x0 be objectHIDDENM1 st x0 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x0 =HIDDENR1 y"
        using A1 funct_1_def_3 sorry
      thus " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x =HIDDENR1 y)"
        using funct_1_def_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_79:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds the-value-ofFUNCT-1K7 (X -->FUNCOP-1K7 x) =HIDDENR1 x"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix x assume [ty]: "x be setHIDDENM2"
  let ?f = "X -->FUNCOP-1K7 x"
  have " ex i be setHIDDENM2 st i inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> ?f & the-value-ofFUNCT-1K7 ?f =HIDDENR1 ?f .FUNCT-1K1 i"
    using funct_1_def_12 sorry
  thus "the-value-ofFUNCT-1K7 (X -->FUNCOP-1K7 x) =HIDDENR1 x"
    using funcop_1_th_7 sorry
qed "sorry"

mtheorem funcop_1_th_80:
" for f be constantFUNCT-1V5\<bar>FunctionFUNCT-1M1 holds f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 the-value-ofFUNCT-1K7 f"
proof(rule ballI)
  fix f assume [ty]: "f be constantFUNCT-1V5\<bar>FunctionFUNCT-1M1"
  have "domRELSET-1K1\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f -->FUNCOP-1K7 the-value-ofFUNCT-1K7 f) =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 (domRELAT-1K1 f -->FUNCOP-1K7 the-value-ofFUNCT-1K7 f).FUNCT-1K1 x)"
  proof(rule conjMI,rule ballI,rule impI)
    show "domRELSET-1K1\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f -->FUNCOP-1K7 the-value-ofFUNCT-1K7 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using funcop_1_th_13 sorry
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
    then have "f <>HIDDENR2 {}XBOOLE-0K1 & (domRELAT-1K1 f -->FUNCOP-1K7 the-value-ofFUNCT-1K7 f).FUNCT-1K1 x =HIDDENR1 the-value-ofFUNCT-1K7 f"
      using funcop_1_th_7 sorry
    thus "f .FUNCT-1K1 x =HIDDENR1 (domRELAT-1K1 f -->FUNCOP-1K7 the-value-ofFUNCT-1K7 f).FUNCT-1K1 x"
      using A1 funct_1_def_12 sorry
  qed "sorry"
  thus "f =FUNCT-1R1 domRELAT-1K1 f -->FUNCOP-1K7 the-value-ofFUNCT-1K7 f"
    using funct_1_def_11 sorry
qed "sorry"

mtheorem funcop_1_cl_20:
  mlet "X be setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster totalPARTFUN1V1\<^bsub>(X)\<^esub> for PartFuncPARTFUN1M1-of(X,Y)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(X,Y) st it be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have " ex tVar9 be PartFuncPARTFUN1M1-of(X,Y) st tVar9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
    proof-
      obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 Y"
        using xboole_0_def_1 sorry
      have 
        [ty]:"y be ElementSUBSET-1M1-of Y"
        using A1 sorry
      show " ex tVar9 be PartFuncPARTFUN1M1-of(X,Y) st tVar9 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      proof(rule bexI[of _ "X -->FUNCOP-1K8\<^bsub>(Y)\<^esub> y"])
        show "X -->FUNCOP-1K8\<^bsub>(Y)\<^esub> y be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_cl_21:
  mlet "I be setHIDDENM2", "A be objectHIDDENM1"
"cluster I -->FUNCOP-1K7 A as-term-is I -definedRELAT-1V4"
proof
(*coherence*)
  show "I -->FUNCOP-1K7 A be I -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem funcop_1_cl_22:
  mlet "I be objectHIDDENM1", "A be objectHIDDENM1"
"cluster I .-->FUNCOP-1K17 A as-term-is {TARSKIK1 I} -definedRELAT-1V4"
proof
(*coherence*)
  show "I .-->FUNCOP-1K17 A be {TARSKIK1 I} -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem funcop_1_th_81:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for x be objectHIDDENM1 holds (A -->FUNCOP-1K7 x).:RELSET-1K7\<^bsub>(A,{TARSKIK1 x})\<^esub> B c=TARSKIR1 {TARSKIK1 x}"
   sorry

mtheorem funcop_1_cl_23:
  mlet "I be setHIDDENM2", "f be FunctionFUNCT-1M1"
"cluster I .-->FUNCOP-1K17 f as-term-is Function-yieldingFUNCOP-1V1"
proof
(*coherence*)
  show "I .-->FUNCOP-1K17 f be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mtheorem funcop_1_cl_24:
  mlet "I be setHIDDENM2"
"cluster totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be I -definedRELAT-1V4\<bar>non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1 st it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
  proof-
    have " ex tVar10 be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 st tVar10 be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
    proof-
      show " ex tVar10 be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 st tVar10 be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
      proof(rule bexI[of _ "I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"])
        show "I -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 } be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funcop_1_th_82:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x .-->FUNCOP-1K17 y is-isomorphism-ofWELLORD1R3({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x .-->FUNCOP-1K17 y is-isomorphism-ofWELLORD1R3({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?F = "x .-->FUNCOP-1K17 y"
    let ?R = "{TARSKIK1 [TARSKIK4 x,x ] }"
    let ?S = "{TARSKIK1 [TARSKIK4 y,y ] }"
    have A1: "fieldRELAT-1K3 ?R =XBOOLE-0R4 {TARSKIK1 x}"
      using relat_1_th_173 sorry
    have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> ?F =XBOOLE-0R4 fieldRELAT-1K3 ?R & (rngFUNCT-1K2 ?F =XBOOLE-0R4 fieldRELAT-1K3 ?S & (?F be one-to-oneFUNCT-1V2 & ( for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] } implies (a inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } & b inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] }) & [TARSKIK4 (x .-->FUNCOP-1K17 y).FUNCT-1K1 a,(x .-->FUNCOP-1K17 y).FUNCT-1K1 b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 y,y ] }) & (a inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } & b inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } implies  not ([TARSKIK4 (x .-->FUNCOP-1K17 y).FUNCT-1K1 a,(x .-->FUNCOP-1K17 y).FUNCT-1K1 b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 y,y ] } &  not [TARSKIK4 a,b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] })))))"
    proof(rule conjMI,rule conjMI,rule conjMI,rule ballI,rule ballI,rule conjMI,rule impI)
      show "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] }"
        using funcop_1_th_13 A1 sorry
      have "fieldRELAT-1K3 ?S =XBOOLE-0R4 {TARSKIK1 y}"
        using relat_1_th_173 sorry
      thus "rngFUNCT-1K2 (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 y,y ] }"
        using relat_1_th_160 sorry
      show "x .-->FUNCOP-1K17 y be one-to-oneFUNCT-1V2"
         sorry
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      show "[TARSKIK4 a,b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] } implies (a inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } & b inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] }) & [TARSKIK4 (x .-->FUNCOP-1K17 y).FUNCT-1K1 a,(x .-->FUNCOP-1K17 y).FUNCT-1K1 b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 y,y ] }"
      proof(rule impI,rule conjMI)
        assume "[TARSKIK4 a,b ] inHIDDENR3 ?R"
        then have "[TARSKIK4 a,b ] =HIDDENR1 [TARSKIK4 x,x ]"
          using tarski_def_1 sorry
        then have A2: "a =HIDDENR1 x & b =HIDDENR1 x"
          using xtuple_0_th_1 sorry
        thus "a inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] } & b inHIDDENR3 fieldRELAT-1K3 {TARSKIK1 [TARSKIK4 x,x ] }"
          using A1 tarski_def_1 sorry
        have "?F .FUNCT-1K1 x =HIDDENR1 y"
          using funcop_1_th_72 sorry
        thus "[TARSKIK4 (x .-->FUNCOP-1K17 y).FUNCT-1K1 a,(x .-->FUNCOP-1K17 y).FUNCT-1K1 b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 y,y ] }"
          using A2 tarski_def_1 sorry
      qed
      assume "a inHIDDENR3 fieldRELAT-1K3 ?R & b inHIDDENR3 fieldRELAT-1K3 ?R"
      then have "a =HIDDENR1 x & b =HIDDENR1 x"
        using A1 tarski_def_1 sorry
      thus " not ([TARSKIK4 (x .-->FUNCOP-1K17 y).FUNCT-1K1 a,(x .-->FUNCOP-1K17 y).FUNCT-1K1 b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 y,y ] } &  not [TARSKIK4 a,b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 x,x ] })"
        using tarski_def_1 sorry
    qed "sorry"
    thus "x .-->FUNCOP-1K17 y is-isomorphism-ofWELLORD1R3({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })"
      using wellord1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_83:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })are-isomorphicWELLORD1R4"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })are-isomorphicWELLORD1R4"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "x .-->FUNCOP-1K17 y is-isomorphism-ofWELLORD1R3({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })"
    proof-
      show "x .-->FUNCOP-1K17 y is-isomorphism-ofWELLORD1R3({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })"
        using funcop_1_th_82 sorry
    qed
    thus "({TARSKIK1 [TARSKIK4 x,x ] },{TARSKIK1 [TARSKIK4 y,y ] })are-isomorphicWELLORD1R4"
      using bexI[of _ "x .-->FUNCOP-1K17 y"] wellord1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_cl_25:
  mlet "I be setHIDDENM2", "A be objectHIDDENM1"
"cluster I -->FUNCOP-1K7 A as-term-is totalPARTFUN1V1\<^bsub>(I)\<^esub> for I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be I -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 I -->FUNCOP-1K7 A implies it be totalPARTFUN1V1\<^bsub>(I)\<^esub>"
     sorry
qed "sorry"

mtheorem funcop_1_th_84:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies x .-->FUNCOP-1K17 f .FUNCT-1K1 x c=RELAT-1R2 f"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies x .-->FUNCOP-1K17 f .FUNCT-1K1 x c=RELAT-1R2 f"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "x inHIDDENR3 domRELAT-1K1 f"
    then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
      using funct_1_th_1 sorry
    then have "{TARSKIK1 [TARSKIK4 x,f .FUNCT-1K1 x ] } c=RELAT-1R2 f"
      using zfmisc_1_th_31 sorry
    thus "x .-->FUNCOP-1K17 f .FUNCT-1K1 x c=RELAT-1R2 f"
      using zfmisc_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_cl_26:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be setHIDDENM2", "i be ElementSUBSET-1M1-of A"
"cluster x .-->FUNCOP-1K17 i as-term-is A -valuedRELAT-1V5"
proof
(*coherence*)
  show "x .-->FUNCOP-1K17 i be A -valuedRELAT-1V5"
  proof-
    have Cut1798: "rngFUNCT-1K2 (x .-->FUNCOP-1K17 i) =XBOOLE-0R4 {TARSKIK1 i}"
      using relat_1_th_160 sorry
    have "rngFUNCT-1K2 (x .-->FUNCOP-1K17 i) c=TARSKIR1 A"
    proof-
      show "rngFUNCT-1K2 (x .-->FUNCOP-1K17 i) c=TARSKIR1 A"
        using zfmisc_1_th_31 Cut1798 sorry
    qed
    thus "x .-->FUNCOP-1K17 i be A -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

reserve Y for "setHIDDENM2"
reserve f, g for "FunctionFUNCT-2M1-of(Y,X)"
reserve x for "ElementSUBSET-1M1-of X"
reserve y for "ElementSUBSET-1M1-of Y"
mtheorem funcop_1_th_85:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(Y,X) holds  for g be FunctionFUNCT-2M1-of(Y,X) holds  for x be ElementSUBSET-1M1-of X holds F be associativeBINOP-1V2\<^bsub>(X)\<^esub> implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(Y,X)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,X)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(X)\<^esub>"
    show "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))"
    proof-
      have cases: "Y =XBOOLE-0R4 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "Y =XBOOLE-0R4 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))"
      proof(rule impI)
        assume "Y =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))"
           sorry
      qed
      have case2: "Y <>HIDDENR2 {}XBOOLE-0K1 implies F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))"
      proof(rule impI)
        assume A2: "Y <>HIDDENR2 {}XBOOLE-0K1"
        have " for y be ElementSUBSET-1M1-of Y holds (F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1((F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-1K1 y,g .FUNCT-1K1 y)"
        proof(rule ballI)
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          obtain x1 x2 where 
            [ty]:"x1 be ElementSUBSET-1M1-of X" and x1Def:"x1 = f .FUNCT-1K1 y" and
            [ty]:"x2 be ElementSUBSET-1M1-of X" and x2Def:"x2 = g .FUNCT-1K1 y"
            using A2 funct_2_th_5 sorry
          have "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1(x,(F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g)).FUNCT-1K1 y)"
            using A2 funcop_1_th_53 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(x,F .BINOP-1K4\<^bsub>(X)\<^esub>(x1,x2))"
            using A2 funcop_1_th_37 sorry
          also have "... = F .BINOP-1K4\<^bsub>(X)\<^esub>(F .BINOP-1K4\<^bsub>(X)\<^esub>(x,x1),x2)"
            using A1 sorry
          also have "... = F .BINOP-1K1((F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-1K1 y,g .FUNCT-1K1 y)"
            using A2 funcop_1_th_53 sorry
          finally show "(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))).FUNCT-1K1 y =HIDDENR1 F .BINOP-1K1((F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f)).FUNCT-1K1 y,g .FUNCT-1K1 y)"
             sorry
        qed "sorry"
        thus "F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,f),g) =FUNCT-2R2\<^bsub>(Y,X)\<^esub> F [;]FUNCOP-1K10\<^bsub>(X,Y)\<^esub>(x,F .:FUNCOP-1K6\<^bsub>(X,Y)\<^esub>(f,g))"
          using A2 funcop_1_th_38 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_cl_27:
  mlet "A be setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of B"
"cluster A -->FUNCOP-1K8\<^bsub>(B)\<^esub> x as-term-is B -valuedRELAT-1V5"
proof
(*coherence*)
  show "A -->FUNCOP-1K8\<^bsub>(B)\<^esub> x be B -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem funcop_1_cl_28:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of A", "y be objectHIDDENM1"
"cluster x .-->FUNCOP-1K17 y as-term-is A -definedRELAT-1V4"
proof
(*coherence*)
  show "x .-->FUNCOP-1K17 y be A -definedRELAT-1V4"
  proof-
    have Cut1843: "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) c=TARSKIR1 A"
    proof-
      show "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) c=TARSKIR1 A"
        using zfmisc_1_th_31 Cut1843 sorry
    qed
    thus "x .-->FUNCOP-1K17 y be A -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem funcop_1_th_86:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for A be setHIDDENM2 holds x inTARSKIR2 A implies (x .-->FUNCOP-1K17 y) |RELAT-1K8 A =FUNCT-1R1 x .-->FUNCOP-1K17 y"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be setHIDDENM2"
  fix y assume [ty]: "y be setHIDDENM2"
  fix A assume [ty]: "A be setHIDDENM2"
  assume "x inTARSKIR2 A"
  then have "{TARSKIK1 x} c=TARSKIR1 A"
    using zfmisc_1_th_31 sorry
  then have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) c=TARSKIR1 A"
     sorry
  thus "(x .-->FUNCOP-1K17 y) |RELAT-1K8 A =FUNCT-1R1 x .-->FUNCOP-1K17 y"
    using relat_1_th_68 sorry
qed "sorry"

mtheorem funcop_1_cl_29:
  mlet "Y be functionalFUNCT-1V6\<bar>setHIDDENM2"
"cluster Y -valuedRELAT-1V5 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be Y -valuedRELAT-1V5 implies it be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mdef funcop_1_def_11 ("Relation-yieldingFUNCOP-1V2" 70 ) where
"attr Relation-yieldingFUNCOP-1V2 for FunctionFUNCT-1M1 means
  (\<lambda>IT.  for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 IT implies IT .FUNCT-1K1 x be RelationRELAT-1M1)"..

mtheorem funcop_1_cl_30:
"cluster Function-yieldingFUNCOP-1V1 also-is Relation-yieldingFUNCOP-1V2 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be Function-yieldingFUNCOP-1V1 implies it be Relation-yieldingFUNCOP-1V2"
     sorry
qed "sorry"

mtheorem funcop_1_cl_31:
"cluster emptyXBOOLE-0V1 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

mtheorem funcop_1_th_87:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds X -->FUNCOP-1K7 x toleratesPARTFUN1R1 Y -->FUNCOP-1K7 y iff x =HIDDENR1 y or X missesXBOOLE-0R1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (X -->FUNCOP-1K7 x toleratesPARTFUN1R1 Y -->FUNCOP-1K7 y implies x =HIDDENR1 y or X missesXBOOLE-0R1 Y) & (x =HIDDENR1 y or X missesXBOOLE-0R1 Y implies X -->FUNCOP-1K7 x toleratesPARTFUN1R1 Y -->FUNCOP-1K7 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?f = "X -->FUNCOP-1K7 x"
    let ?g = "Y -->FUNCOP-1K7 y"
    have A1: "domRELSET-1K1\<^bsub>(Y)\<^esub> ?g =XBOOLE-0R4 Y"
      using funcop_1_th_13 sorry
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> ?f =XBOOLE-0R4 X"
      using funcop_1_th_13 sorry
    show "X -->FUNCOP-1K7 x toleratesPARTFUN1R1 Y -->FUNCOP-1K7 y implies x =HIDDENR1 y or X missesXBOOLE-0R1 Y"
    proof-
      have " not ((X -->FUNCOP-1K7 x toleratesPARTFUN1R1 Y -->FUNCOP-1K7 y &  not x =HIDDENR1 y) &  not X missesXBOOLE-0R1 Y)"
      proof-
        have "( for z be objectHIDDENM1 holds z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 x) /\\SUBSET-1K9\<^bsub>(Y)\<^esub> domRELSET-1K1\<^bsub>(Y)\<^esub> (Y -->FUNCOP-1K7 y) implies (X -->FUNCOP-1K7 x).FUNCT-1K1 z =XBOOLE-0R4 (Y -->FUNCOP-1K7 y).FUNCT-1K1 z) & x <>HIDDENR2 y implies (X meetsXBOOLE-0R5 Y implies  not  True )"
        proof(rule impMI ,rule impI,rule impI)
          assume A3: " for z be objectHIDDENM1 holds z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ?f /\\SUBSET-1K9\<^bsub>(Y)\<^esub> domRELSET-1K1\<^bsub>(Y)\<^esub> ?g implies ?f .FUNCT-1K1 z =XBOOLE-0R4 ?g .FUNCT-1K1 z"
            and A4: "x <>HIDDENR2 y"
          assume "X meetsXBOOLE-0R5 Y"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A5: "z inHIDDENR3 X"and A6: "z inHIDDENR3 Y"
            using xboole_0_th_3 sorry
          have A7: "?f .FUNCT-1K1 z =HIDDENR1 x"
            using A5 funcop_1_th_7 sorry
          have A8: "?g .FUNCT-1K1 z =HIDDENR1 y"
            using A6 funcop_1_th_7 sorry
          have "z inHIDDENR3 X /\\XBOOLE-0K3 Y"
            using A5 A6 xboole_0_def_4 sorry
          thus " not  True "
            using A2 A1 A3 A4 A7 A8 sorry
        qed
        thus " not ((X -->FUNCOP-1K7 x toleratesPARTFUN1R1 Y -->FUNCOP-1K7 y &  not x =HIDDENR1 y) &  not X missesXBOOLE-0R1 Y)"
          using partfun1_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A9: "x =HIDDENR1 y or X missesXBOOLE-0R1 Y"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (X -->FUNCOP-1K7 x) /\\SUBSET-1K9\<^bsub>(Y)\<^esub> domRELSET-1K1\<^bsub>(Y)\<^esub> (Y -->FUNCOP-1K7 y) implies (X -->FUNCOP-1K7 x).FUNCT-1K1 z =HIDDENR1 (Y -->FUNCOP-1K7 y).FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A10: "z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ?f /\\SUBSET-1K9\<^bsub>(Y)\<^esub> domRELSET-1K1\<^bsub>(Y)\<^esub> ?g"
      then have A11: "z inHIDDENR3 Y"
         sorry
      have A12: "z inHIDDENR3 X"
        using A2 A10 xboole_0_def_4 sorry
      then have "?f .FUNCT-1K1 z =HIDDENR1 x"
        using funcop_1_th_7 sorry
      thus "(X -->FUNCOP-1K7 x).FUNCT-1K1 z =HIDDENR1 (Y -->FUNCOP-1K7 y).FUNCT-1K1 z"
        using A9 A12 A11 funcop_1_th_7 xboole_0_th_3 sorry
    qed "sorry"
    thus "X -->FUNCOP-1K7 x toleratesPARTFUN1R1 Y -->FUNCOP-1K7 y"
      using partfun1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x, y, z, A for "setHIDDENM2"
mtheorem funcop_1_th_88:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds rngFUNCT-1K2 (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 {TARSKIK1 y}"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds rngFUNCT-1K2 (x .-->FUNCOP-1K17 y) =HIDDENR1 {TARSKIK1 y}"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    have "domRELSET-1K1\<^bsub>({TARSKIK1 x})\<^esub> (x .-->FUNCOP-1K17 y) =XBOOLE-0R4 {TARSKIK1 x}"
      using funcop_1_th_13 sorry
    then have "rngFUNCT-1K2 (x .-->FUNCOP-1K17 y) =HIDDENR1 {TARSKIK1 (x .-->FUNCOP-1K17 y).FUNCT-1K1 x }"
      using funct_1_th_4 sorry
    also have "... = {TARSKIK1 y}"
      using funcop_1_th_72 sorry
    finally show "rngFUNCT-1K2 (x .-->FUNCOP-1K17 y) =HIDDENR1 {TARSKIK1 y}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_th_89:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds  for A be setHIDDENM2 holds z inTARSKIR2 A implies (A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z) =FUNCT-1R1 y .-->FUNCOP-1K17 x"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds  for A be setHIDDENM2 holds z inTARSKIR2 A implies (A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z) =FUNCT-1R1 y .-->FUNCOP-1K17 x"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    assume A1: "z inTARSKIR2 A"
    have A2: "domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> (y .-->FUNCOP-1K17 z) =HIDDENR1 {TARSKIK1 y}"
      using funcop_1_th_13 sorry
    also have "... = domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> (y .-->FUNCOP-1K17 x)"
      using funcop_1_th_13 sorry
    finally have "domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> (y .-->FUNCOP-1K17 z) =HIDDENR1 domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> (y .-->FUNCOP-1K17 x)"
       sorry
    have "rngFUNCT-1K2 (y .-->FUNCOP-1K17 z) =XBOOLE-0R4 {TARSKIK1 z}"
      using funcop_1_th_88 sorry
    then have "rngFUNCT-1K2 (y .-->FUNCOP-1K17 z) c=TARSKIR1 A"
      using A1 zfmisc_1_th_31 sorry
    then have Cut1939: "rngFUNCT-1K2 (y .-->FUNCOP-1K17 z) c=TARSKIR1 domRELSET-1K1\<^bsub>(A)\<^esub> (A -->FUNCOP-1K7 x)"
      using funcop_1_th_13 sorry
    have "domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> ((A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> (y .-->FUNCOP-1K17 x) & ( for e be objectHIDDENM1 holds e inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> ((A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z)) implies ((A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z)).FUNCT-1K1 e =HIDDENR1 (y .-->FUNCOP-1K17 x).FUNCT-1K1 e)"
    proof(rule conjMI,rule ballI,rule impI)
      show "domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> ((A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> (y .-->FUNCOP-1K17 x)"
        using A2 relat_1_th_27 Cut1939 sorry
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A3: "e inHIDDENR3 domRELSET-1K1\<^bsub>({TARSKIK1 y})\<^esub> ((A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z))"
      have "((A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z)).FUNCT-1K1 e =HIDDENR1 (A -->FUNCOP-1K7 x).FUNCT-1K1 ((y .-->FUNCOP-1K17 z).FUNCT-1K1 e)"
        using A3 funct_1_th_12 sorry
      also have "... = (A -->FUNCOP-1K7 x).FUNCT-1K1 z"
        using A3 funcop_1_th_7 sorry
      also have "... = x"
        using A1 funcop_1_th_7 sorry
      also have "... = (y .-->FUNCOP-1K17 x).FUNCT-1K1 e"
        using A3 funcop_1_th_7 sorry
      finally show "((A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z)).FUNCT-1K1 e =HIDDENR1 (y .-->FUNCOP-1K17 x).FUNCT-1K1 e"
         sorry
    qed "sorry"
    thus "(A -->FUNCOP-1K7 x)*FUNCT-1K3 (y .-->FUNCOP-1K17 z) =FUNCT-1R1 y .-->FUNCOP-1K17 x"
      using funct_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funcop_1_cl_32:
  mlet "f be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"cluster f .BINOP-1K1(a,b) as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "f .BINOP-1K1(a,b) be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem funcop_1_cl_33:
  mlet "Y be setHIDDENM2", "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that Function-yieldingFUNCOP-1V1 for FunctionFUNCT-2M1-of(X,FuncsFUNCT-2K9(Y,Z))"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(X,FuncsFUNCT-2K9(Y,Z)) holds it be Function-yieldingFUNCOP-1V1"
     sorry
qed "sorry"

end
