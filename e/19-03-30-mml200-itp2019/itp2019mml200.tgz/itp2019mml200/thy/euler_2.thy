theory euler_2
  imports recdef_1 euler_1 wsierp_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, m, x, n, l, xi, xj for "NatNAT-1M1"
reserve t, z for "IntegerINT-1M1"
reserve f, F for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
mlemma euler_2_lm_1:
" for t be IntegerINT-1M1 holds t <XXREAL-0R3 \<one>\<^sub>M iff t <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for t be IntegerINT-1M1 holds  not ( not t <XXREAL-0R3 \<one>\<^sub>M &  not t <=XXREAL-0R1 0NUMBERSK6) &  not (t <=XXREAL-0R1 0NUMBERSK6 & t <XXREAL-0R3 \<one>\<^sub>M)"
  proof(rule ballI)
    fix t assume [ty]: "t be IntegerINT-1M1"
    have "t <XXREAL-0R3 \<one>\<^sub>M implies t <=XXREAL-0R1 0NUMBERSK6"
    proof-
      have "t <XXREAL-0R3 \<one>\<^sub>M implies (t >XXREAL-0R4 0NUMBERSK6 implies  False )"
      proof(rule impI,rule impI)
        assume A1: "t <XXREAL-0R3 \<one>\<^sub>M"
        assume A2: "t >XXREAL-0R4 0NUMBERSK6"
        then have 
          [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
          using int_1_th_3 sorry
        have "t >=XXREAL-0R2 \<one>\<^sub>M"
          using A2 nat_1_th_14 sorry
        thus " False "
          using A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( not t <XXREAL-0R3 \<one>\<^sub>M &  not t <=XXREAL-0R1 0NUMBERSK6) &  not (t <=XXREAL-0R1 0NUMBERSK6 & t <XXREAL-0R3 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma euler_2_lm_2:
" for a be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for a be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    assume "a <>HIDDENR2 0NUMBERSK6"
    then have "a >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    then have "a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    thus "a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma euler_2_lm_3:
" for z be IntegerINT-1M1 holds \<one>\<^sub>M gcdINT-2K3 z =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for z be IntegerINT-1M1 holds \<one>\<^sub>M gcdINT-2K3 z =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix z assume [ty]: "z be IntegerINT-1M1"
    have "\<one>\<^sub>M gcdINT-2K3 z =HIDDENR1  |.INT-2K1 \<one>\<^sub>M.| gcdNAT-DK8  |.INT-2K1 z.|"
      using int_2_th_34 sorry
    also have "... = \<one>\<^sub>M gcdNAT-DK8  |.INT-2K1 z.|"
      using absvalue_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using newton_th_51 sorry
    finally show "\<one>\<^sub>M gcdINT-2K3 z =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_1:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds (a,b)are-coprimeINT-2R1 iff (a,b)are-coprimeINT-2R1"
   sorry

mtheorem euler_2_th_2:
" for m be NatNAT-1M1 holds  for t be IntegerINT-1M1 holds m *XCMPLX-0K3 t >=XXREAL-0R2 \<one>\<^sub>M implies t >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for m be NatNAT-1M1 holds  for t be IntegerINT-1M1 holds m *XCMPLX-0K3 t >=XXREAL-0R2 \<one>\<^sub>M implies (t <XXREAL-0R3 \<one>\<^sub>M implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix t assume [ty]: "t be IntegerINT-1M1"
    assume A1: "m *XCMPLX-0K3 t >=XXREAL-0R2 \<one>\<^sub>M"
    assume "t <XXREAL-0R3 \<one>\<^sub>M"
    then have "t <=XXREAL-0R1 0NUMBERSK6"
      using euler_2_lm_1 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma euler_2_lm_4:
" for m be NatNAT-1M1 holds  for z be IntegerINT-1M1 holds (\<one>\<^sub>M -XCMPLX-0K6 m <=XXREAL-0R1 z & z <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M) & m dividesINT-1R1 z implies z =HIDDENR1 0NUMBERSK6"
proof-
  have " for m be NatNAT-1M1 holds  for z be IntegerINT-1M1 holds \<one>\<^sub>M -XCMPLX-0K6 m <=XXREAL-0R1 z & (z <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M & m dividesINT-1R1 z) implies (z <>HIDDENR2 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix z assume [ty]: "z be IntegerINT-1M1"
    assume A1: "\<one>\<^sub>M -XCMPLX-0K6 m <=XXREAL-0R1 z"
      and A2: "z <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M"
      and A3: "m dividesINT-1R1 z"
    obtain t where
      [ty]:"t be IntegerINT-1M1" and 
      A4: "z =HIDDENR1 m *XCMPLX-0K3 t"
      using A3 int_1_def_3 sorry
    assume A5: "z <>HIDDENR2 0NUMBERSK6"
    have " False "
    proof-
      show " False "
      proof-
        have cases: "t >XXREAL-0R4 0NUMBERSK6 or t <XXREAL-0R3 0NUMBERSK6"
          using A5 A4 sorry
        have case1: "t >XXREAL-0R4 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume A6: "t >XXREAL-0R4 0NUMBERSK6"
          then have 
            [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
            using int_1_th_3 sorry
          have "m *XCMPLX-0K3 t >=XXREAL-0R2 m"
            using A6 nat_1_th_14 newton_th_33 sorry
          then have "m *XCMPLX-0K3 t +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 m"
            using nat_1_th_13 sorry
          thus " False "
            using A2 A4 xreal_1_th_19 sorry
        qed
        have case2: "t <XXREAL-0R3 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume A7: "t <XXREAL-0R3 0NUMBERSK6"
          obtain r where 
            [ty]:"r be IntegerINT-1M1" and rDef:"r = t +XCMPLX-0K2 \<one>\<^sub>M"
             sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 m *XCMPLX-0K3 t +XCMPLX-0K2 m *XCMPLX-0K3 \<one>\<^sub>M"
            using A1 A4 xreal_1_th_20 sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 m *XCMPLX-0K3 (t +XCMPLX-0K2 \<one>\<^sub>M)"
             sorry
          then have "r >=XXREAL-0R2 \<one>\<^sub>M"
            using euler_2_th_2 sorry
          then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 t"
            using xreal_1_th_20 sorry
          thus " False "
            using A7 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_3:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (((a <>HIDDENR2 0NUMBERSK6 & b <>HIDDENR2 0NUMBERSK6) & m <>HIDDENR2 0NUMBERSK6) & (a,m)are-coprimeINT-2R1) & (b,m)are-coprimeINT-2R1 implies (m,a *XCMPLX-0K3 b modNAT-DK4 m)are-coprimeINT-2R1"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for m be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & (b <>HIDDENR2 0NUMBERSK6 & (m <>HIDDENR2 0NUMBERSK6 & ((a,m)are-coprimeINT-2R1 & (b,m)are-coprimeINT-2R1))) implies (m,a *XCMPLX-0K3 b modNAT-DK4 m)are-coprimeINT-2R1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "b <>HIDDENR2 0NUMBERSK6"
      and A3: "m <>HIDDENR2 0NUMBERSK6"
      and A4: "(a,m)are-coprimeINT-2R1 & (b,m)are-coprimeINT-2R1"
    have "(a *XCMPLX-0K3 b,m)are-coprimeINT-2R1"
      using A1 A3 A4 euler_1_th_14 sorry
    then have A5: "a *XCMPLX-0K3 b gcdNAT-DK8 m =XBOOLE-0R4 \<one>\<^sub>M"
      using int_2_def_3 sorry
    obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A6: "a *XCMPLX-0K3 b =XBOOLE-0R4 m *XCMPLX-0K3 t +NAT-1K1 (a *XCMPLX-0K3 b modNAT-DK4 m)"and "a *XCMPLX-0K3 b modNAT-DK4 m <XXREAL-0R3 m"
      using A3 nat_d_def_2 sorry
    have "a *XCMPLX-0K3 b <>HIDDENR2 a *XCMPLX-0K3 (0NUMBERSK6)"
      using A1 A2 xcmplx_1_th_5 sorry
    then have "(a *XCMPLX-0K3 b +XCMPLX-0K2 (-XCMPLX-0K4 t)*XCMPLX-0K3 m)gcdINT-2K3 m =XBOOLE-0R4 a *XCMPLX-0K3 b gcdNAT-DK8 m"
      using euler_1_th_16 sorry
    thus "(m,a *XCMPLX-0K3 b modNAT-DK4 m)are-coprimeINT-2R1"
      using A6 A5 int_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_4:
" for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m >XXREAL-0R4 \<one>\<^sub>M & (m,n)are-coprimeINT-2R1) & n =XBOOLE-0R4 a *XCMPLX-0K3 b modNAT-DK4 m implies (m,b)are-coprimeINT-2R1"
proof-
  have " for a be NatNAT-1M1 holds  for b be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >XXREAL-0R4 \<one>\<^sub>M & ((m,n)are-coprimeINT-2R1 & n =XBOOLE-0R4 a *XCMPLX-0K3 b modNAT-DK4 m) implies ( not (m,b)are-coprimeINT-2R1 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix b assume [ty]: "b be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "m >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "(m,n)are-coprimeINT-2R1"
      and A3: "n =XBOOLE-0R4 a *XCMPLX-0K3 b modNAT-DK4 m"
    let ?k = "m gcdNAT-DK8 b"
    have "?k dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    then obtain km where
      [ty]:"km be NatNAT-1M1" and 
      A4: "m =XBOOLE-0R4 ?k *XCMPLX-0K3 km"
      using nat_d_def_3 sorry
    have A5: "?k <>HIDDENR2 0NUMBERSK6 & km <>HIDDENR2 0NUMBERSK6"
      using A1 A4 sorry
    have 
      [ty]:"km be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "?k dividesNAT-DR1 b"
      using nat_d_def_5 sorry
    then obtain kb where
      [ty]:"kb be NatNAT-1M1" and 
      A6: "b =XBOOLE-0R4 ?k *XCMPLX-0K3 kb"
      using nat_d_def_3 sorry
    obtain p where
      [ty]:"p be NatNAT-1M1" and 
      A7: "a *XCMPLX-0K3 (?k *XCMPLX-0K3 kb) =XBOOLE-0R4 (?k *NAT-1K2 km)*XCMPLX-0K3 p +NAT-1K1 (a *XCMPLX-0K3 (?k *XCMPLX-0K3 kb) modNAT-DK4 ?k *NAT-1K2 km)"and "a *XCMPLX-0K3 (?k *XCMPLX-0K3 kb) modNAT-DK4 ?k *NAT-1K2 km <XXREAL-0R3 ?k *NAT-1K2 km"
      using A1 A4 nat_d_def_2 sorry
    let ?tm = "a *XCMPLX-0K3 kb -XCMPLX-0K6 km *XCMPLX-0K3 p"
    have A8: "a *XCMPLX-0K3 (?k *XCMPLX-0K3 kb) modNAT-DK4 ?k *NAT-1K2 km =XBOOLE-0R4 ?k *XCMPLX-0K3 (a *XCMPLX-0K3 kb -XCMPLX-0K6 km *XCMPLX-0K3 p)"
      using A7 sorry
    assume " not (m,b)are-coprimeINT-2R1"
    then have A9: "m gcdNAT-DK8 b <>HIDDENR2 \<one>\<^sub>M"
      using int_2_def_3 sorry
    have A10: "?k <>HIDDENR2 -XCMPLX-0K4 \<one>\<^sub>M"
      using nat_1_th_2 sorry
    have A11: "?tm <>HIDDENR2 0NUMBERSK6 implies m gcdNAT-DK8 n <>HIDDENR2 \<one>\<^sub>M"
    proof-
      have "a *XCMPLX-0K3 kb -XCMPLX-0K6 km *XCMPLX-0K3 p <>HIDDENR2 0NUMBERSK6 implies  not m gcdNAT-DK8 n <>HIDDENR2 \<one>\<^sub>M"
      proof(rule impI)
        assume "?tm <>HIDDENR2 0NUMBERSK6"
        have "m gcdNAT-DK8 n =XBOOLE-0R4 ?k *XCMPLX-0K3 (km gcdINT-2K3 ?tm)"
          using A3 A4 A5 A6 A8 euler_1_th_15 sorry
        thus " not m gcdNAT-DK8 n <>HIDDENR2 \<one>\<^sub>M"
          using A9 A10 int_1_th_9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "?tm =XBOOLE-0R4 0NUMBERSK6 implies m gcdNAT-DK8 n <>HIDDENR2 \<one>\<^sub>M"
      using A1 A3 A4 A6 A8 newton_th_52 sorry
    thus " False "
      using A2 A11 int_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_5:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m modNAT-DK4 n)modNAT-DK4 n =XBOOLE-0R4 m modNAT-DK4 n"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (m modNAT-DK4 n)modNAT-DK4 n =XBOOLE-0R4 m modNAT-DK4 n"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    show "(m modNAT-DK4 n)modNAT-DK4 n =XBOOLE-0R4 m modNAT-DK4 n"
    proof-
      have cases: "n <>HIDDENR2 0NUMBERSK6 or n =XBOOLE-0R4 0NUMBERSK6"
         sorry
      have case1: "n <>HIDDENR2 0NUMBERSK6 implies (m modNAT-DK4 n)modNAT-DK4 n =XBOOLE-0R4 m modNAT-DK4 n"
      proof(rule impI)
        assume "n <>HIDDENR2 0NUMBERSK6"
        then have " ex t be NatNAT-1M1 st m =XBOOLE-0R4 n *XCMPLX-0K3 t +NAT-1K1 (m modNAT-DK4 n) & m modNAT-DK4 n <XXREAL-0R3 n"
          using nat_d_def_2 sorry
        thus "(m modNAT-DK4 n)modNAT-DK4 n =XBOOLE-0R4 m modNAT-DK4 n"
          using nat_d_th_24 sorry
      qed
      have case2: "n =XBOOLE-0R4 0NUMBERSK6 implies (m modNAT-DK4 n)modNAT-DK4 n =HIDDENR1 m modNAT-DK4 n"
      proof(rule impI)
        assume A1: "n =XBOOLE-0R4 0NUMBERSK6"
        then have "(m modNAT-DK4 n)modNAT-DK4 n =HIDDENR1 0NUMBERSK6"
          using nat_d_def_2 sorry
        also have "... = m modNAT-DK4 n"
          using A1 nat_d_def_2 sorry
        finally show "(m modNAT-DK4 n)modNAT-DK4 n =HIDDENR1 m modNAT-DK4 n"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_6:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds (l +XCMPLX-0K2 m)modNAT-DK4 n =XBOOLE-0R4 ((l modNAT-DK4 n)+NAT-1K1 (m modNAT-DK4 n))modNAT-DK4 n"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds (l +XCMPLX-0K2 m)modNAT-DK4 n =HIDDENR1 ((l modNAT-DK4 n)+NAT-1K1 (m modNAT-DK4 n))modNAT-DK4 n"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    have "(l +XCMPLX-0K2 m)modNAT-DK4 n =HIDDENR1 ((l modNAT-DK4 n)+XCMPLX-0K2 m)modNAT-DK4 n"
      using nat_d_th_22 sorry
    also have "... = ((l modNAT-DK4 n)+NAT-1K1 (m modNAT-DK4 n))modNAT-DK4 n"
      using nat_d_th_23 sorry
    finally show "(l +XCMPLX-0K2 m)modNAT-DK4 n =HIDDENR1 ((l modNAT-DK4 n)+NAT-1K1 (m modNAT-DK4 n))modNAT-DK4 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_7:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    show "l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
    proof-
      have cases: "n <>HIDDENR2 0NUMBERSK6 or n =XBOOLE-0R4 0NUMBERSK6"
         sorry
      have case1: "n <>HIDDENR2 0NUMBERSK6 implies l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
      proof(rule impI)
        assume "n <>HIDDENR2 0NUMBERSK6"
        then obtain t where
          [ty]:"t be NatNAT-1M1" and 
          A1: "m =XBOOLE-0R4 n *XCMPLX-0K3 t +NAT-1K1 (m modNAT-DK4 n)"and "m modNAT-DK4 n <XXREAL-0R3 n"
          using nat_d_def_2 sorry
        have "l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 ((l *XCMPLX-0K3 t)*XCMPLX-0K3 n +XCMPLX-0K2 l *XCMPLX-0K3 (m modNAT-DK4 n))modNAT-DK4 n"
          using A1 sorry
        thus "l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
          using nat_d_th_21 sorry
      qed
      have case2: "n =XBOOLE-0R4 0NUMBERSK6 implies l *XCMPLX-0K3 m modNAT-DK4 n =HIDDENR1 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
      proof(rule impI)
        assume A2: "n =XBOOLE-0R4 0NUMBERSK6"
        then have "l *XCMPLX-0K3 m modNAT-DK4 n =HIDDENR1 0NUMBERSK6"
          using nat_d_def_2 sorry
        also have "... = l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
          using A2 nat_d_def_2 sorry
        finally show "l *XCMPLX-0K3 m modNAT-DK4 n =HIDDENR1 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_8:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 (l modNAT-DK4 n)*XCMPLX-0K3 m modNAT-DK4 n"
  using euler_2_th_7 sorry

mtheorem euler_2_th_9:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 (l modNAT-DK4 n)*NAT-1K2 (m modNAT-DK4 n) modNAT-DK4 n"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 (l modNAT-DK4 n)*NAT-1K2 (m modNAT-DK4 n) modNAT-DK4 n"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix l assume [ty]: "l be NatNAT-1M1"
    have "l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 l *XCMPLX-0K3 (m modNAT-DK4 n) modNAT-DK4 n"
      using euler_2_th_7 sorry
    thus "l *XCMPLX-0K3 m modNAT-DK4 n =XBOOLE-0R4 (l modNAT-DK4 n)*NAT-1K2 (m modNAT-DK4 n) modNAT-DK4 n"
      using euler_2_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
abbreviation(input) EULER_2K1(" _ *EULER-2K1  _ " [164,164]164) where
  "a *EULER-2K1 f \<equiv> a *RVSUM-1K11 f"

mtheorem euler_2_add_1:
  mlet "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1", "a be NatNAT-1M1"
"cluster a *RVSUM-1K11 f as-term-is FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
proof
(*coherence*)
  show "a *RVSUM-1K11 f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
  proof-
    have "rngRVSUM-1K1 (a *RVSUM-1K12 f) c=TARSKIR1 NATNUMBERSK1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 (a *RVSUM-1K12 f) implies x inHIDDENR3 NATNUMBERSK1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngRVSUM-1K1 (a *RVSUM-1K12 f)"
        then obtain xx where
          [ty]:"xx be objectHIDDENM1" and 
          A1: "xx inHIDDENR3 domFINSEQ-1K5 (a *RVSUM-1K12 f)"and A2: "x =HIDDENR1 (a *RVSUM-1K12 f).FUNCT-1K1 xx"
          using funct_1_def_3 sorry
        have 
          [ty]:"xx be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A1 sorry
        have "(a *RVSUM-1K12 f).FUNCT-1K1 xx =XBOOLE-0R4 a *XCMPLX-0K3 f .RECDEF-1K1 xx"
          using rvsum_1_th_44 sorry
        thus "x inHIDDENR3 NATNUMBERSK1"
          using A2 ordinal1_def_12 sorry
      qed "sorry"
      thus "rngRVSUM-1K1 (a *RVSUM-1K12 f) c=TARSKIR1 NATNUMBERSK1"
        using tarski_def_3 sorry
    qed
    thus "a *RVSUM-1K11 f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

mtheorem euler_2_th_10:
" for R1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for R2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (R1,R2)are-fiberwise-equipotentCLASSES1R2 implies ProductWSIERP-1K2 R1 =XBOOLE-0R4 ProductWSIERP-1K2 R2"
proof(rule ballI,rule ballI,rule impI)
  fix R1 assume [ty]: "R1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
  fix R2 assume [ty]: "R2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
  let ?P = "\<lambda>Lamb1.  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for g be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =XBOOLE-0R4 Lamb1 implies ProductWSIERP-1K2 f =XBOOLE-0R4 ProductWSIERP-1K2 g"
  have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds ( for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for g be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =XBOOLE-0R4 n implies ProductWSIERP-1K2 f =XBOOLE-0R4 ProductWSIERP-1K2 g) implies ( for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for g be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies ProductWSIERP-1K2 f =HIDDENR1 ProductWSIERP-1K2 g)"
    proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A2: "?P(n)"
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      fix g assume [ty]: "g be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      assume A3: "(f,g)are-fiberwise-equipotentCLASSES1R2"
        and A4: "lenFINSEQ-1K4 f =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      obtain a where 
        [ty]:"a be ElementSUBSET-1M1-of NATNUMBERSK1" and aDef:"a = f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A5: "rngRVSUM-1K1 f =XBOOLE-0R4 rngRVSUM-1K1 g"
        using A3 classes1_th_75 sorry
      let ?fn = "f  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n"
      have A6: "f =FINSEQ-1R1 ?fn ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)"
        using A4 rfinseq_th_7 sorry
      have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
        using A4 finseq_3_th_25 sorry
      then have "a inTARSKIR2 rngRVSUM-1K1 g"
        using A5 funct_1_def_3 sorry
      then obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A7: "m inTARSKIR2 domFINSEQ-1K5 g"and A8: "g .RECDEF-1K1 m =XBOOLE-0R4 a"
        using finseq_2_th_10 sorry
      have 
        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      let ?gg = "g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m"
      let ?gm = "g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m"
      have "m <=XXREAL-0R1 lenFINSEQ-1K4 g"
        using A7 finseq_3_th_25 sorry
      then have A9: "lenFINSEQ-1K4 ?gm =XBOOLE-0R4 m"
        using finseq_1_th_59 sorry
      have A10: "\<one>\<^sub>M <=XXREAL-0R1 m"
        using A7 finseq_3_th_25 sorry
      then have "maxXXREAL-0K5(0NUMBERSK6,m -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 m -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_4 sorry
      then obtain m1 where 
        [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = m -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_5 sorry
      have A11: "m =XBOOLE-0R4 m1 +NAT-1K1 \<one>\<^sub>M"
         sorry
      then have "m1 <=XXREAL-0R1 m"
        using nat_1_th_11 sorry
      then have A12: "SegFINSEQ-1K2 m1 c=TARSKIR1 SegFINSEQ-1K2 m"
        using finseq_1_th_5 sorry
      have "m inTARSKIR2 SegFINSEQ-1K2 m"
        using A10 finseq_1_th_1 sorry
      then have "?gm .RECDEF-1K1 m =XBOOLE-0R4 a"
        using A7 A8 rfinseq_th_6 sorry
      then have A13: "?gm =FINSEQ-1R1 ?gm  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)"
        using A9 A11 rfinseq_th_7 sorry
      have A14: "g =FINSEQ-1R1 g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m)"
        using rfinseq_th_8 sorry
      have A15: "?gm  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 =HIDDENR1 ?gm  |RELAT-1K8 SegFINSEQ-1K2 m1"
        using finseq_1_def_15 sorry
      also have "... = (g  |RELAT-1K8 SegFINSEQ-1K2 m) |RELAT-1K8 SegFINSEQ-1K2 m1"
        using finseq_1_def_15 sorry
      also have "... = g  |RELAT-1K8 (SegFINSEQ-1K2 m /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1)"
        using relat_1_th_71 sorry
      also have "... = g  |RELAT-1K8 SegFINSEQ-1K2 m1"
        using A12 xboole_1_th_28 sorry
      also have "... = g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1"
        using finseq_1_def_15 sorry
      finally have "?gm  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 =HIDDENR1 g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1"
         sorry
      have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(f  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m),x))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "cardCARD-1K1 (CoimRELAT-1K13(f,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(g,x))"
          using A3 classes1_def_10 sorry
        then have "cardCARD-1K4 (?fn \<inverse>FUNCT-1K6 {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)\<inverse>FUNCT-1K6 {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (((g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>))^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m))\<inverse>FUNCT-1K6 {TARSKIK1 x})"
          using A14 A13 A15 A6 finseq_3_th_57 sorry
        also have "... = cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>))\<inverse>FUNCT-1K6 {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m)\<inverse>FUNCT-1K6 {TARSKIK1 x})"
          using finseq_3_th_57 sorry
        also have "... = (cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1)\<inverse>FUNCT-1K6 {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)\<inverse>FUNCT-1K6 {TARSKIK1 x}))+NAT-1K1 cardCARD-1K4 ((g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m)\<inverse>FUNCT-1K6 {TARSKIK1 x})"
          using finseq_3_th_57 sorry
        also have "... = (cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1)\<inverse>FUNCT-1K6 {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m)\<inverse>FUNCT-1K6 {TARSKIK1 x}))+NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)\<inverse>FUNCT-1K6 {TARSKIK1 x})"
           sorry
        also have "... = cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m))\<inverse>FUNCT-1K6 {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)\<inverse>FUNCT-1K6 {TARSKIK1 x})"
          using finseq_3_th_57 sorry
        finally have "cardCARD-1K4 (?fn \<inverse>FUNCT-1K6 {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)\<inverse>FUNCT-1K6 {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m))\<inverse>FUNCT-1K6 {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)\<inverse>FUNCT-1K6 {TARSKIK1 x})"
           sorry
        thus "cardCARD-1K1 (CoimRELAT-1K13(f  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m),x))"
           sorry
      qed "sorry"
      then have A16: "(?fn,g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m))are-fiberwise-equipotentCLASSES1R2"
        using classes1_def_10 sorry
      have "lenFINSEQ-1K4 ?fn =XBOOLE-0R4 n"
        using A4 finseq_1_th_59 nat_1_th_11 sorry
      then have "ProductWSIERP-1K2 ?fn =XBOOLE-0R4 ProductWSIERP-1K2 (g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> ?gg)"
        using A2 A16 sorry
      then have "ProductWSIERP-1K2 f =HIDDENR1 ProductWSIERP-1K2 (g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1 ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m)) *NAT-1K2 ProductWSIERP-1K2 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)"
        using A6 rvsum_1_th_97 sorry
      also have "... = (ProductWSIERP-1K2 (g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1) *NAT-1K2 ProductWSIERP-1K2 (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m))*NAT-1K2 ProductWSIERP-1K2 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>)"
        using rvsum_1_th_97 sorry
      also have "... = (ProductWSIERP-1K2 (g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m1) *NAT-1K2 ProductWSIERP-1K2 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> a*>))*NAT-1K2 ProductWSIERP-1K2 (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m)"
         sorry
      also have "... = ProductWSIERP-1K2 (g  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> m) *NAT-1K2 ProductWSIERP-1K2 (g /^RFINSEQK2\<^bsub>(NATNUMBERSK1)\<^esub> m)"
        using A13 A15 rvsum_1_th_97 sorry
      also have "... = ProductWSIERP-1K2 g"
        using A14 rvsum_1_th_97 sorry
      finally show "ProductWSIERP-1K2 f =HIDDENR1 ProductWSIERP-1K2 g"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  assume A17: "(R1,R2)are-fiberwise-equipotentCLASSES1R2"
  have A18: "lenFINSEQ-1K4 R1 =XBOOLE-0R4 lenFINSEQ-1K4 R1"
     sorry
  have A19: "?P(0NUMBERSK6)"
  proof-
    have " for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for g be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =XBOOLE-0R4 0NUMBERSK6 implies ProductWSIERP-1K2 f =XBOOLE-0R4 ProductWSIERP-1K2 g"
    proof(rule ballI,rule ballI,rule impI)
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      fix g assume [ty]: "g be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      assume "(f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =XBOOLE-0R4 0NUMBERSK6"
      then have A20: "lenFINSEQ-1K4 g =XBOOLE-0R4 0NUMBERSK6 & f =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1"
        using rfinseq_th_3 sorry
      then have "g =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1"
         sorry
      thus "ProductWSIERP-1K2 f =XBOOLE-0R4 ProductWSIERP-1K2 g"
        using A20 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A19 A1 sorry
  thus "ProductWSIERP-1K2 R1 =XBOOLE-0R4 ProductWSIERP-1K2 R2"
    using A17 A18 sorry
qed "sorry"

(*begin*)
mdef euler_2_def_1 (" _ modEULER-2K2  _ " [132,132]132 ) where
  mlet "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1", "m be NatNAT-1M1"
"func f modEULER-2K2 m \<rightarrow> FinSequenceFINSEQ-1M3-of NATNUMBERSK1 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)"
    proof-
      have " ex tVar1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st lenFINSEQ-1K4 tVar1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 f implies tVar1 .RECDEF-1K1 k =XBOOLE-0R4 f .RECDEF-1K1 k modNAT-DK4 m)"
      proof-
        let ?F = "\<lambda>Lamb1. f .RECDEF-1K1 Lamb1 modNAT-DK4 m"
        obtain g where
          [ty]:"g be FinSequenceFINSEQ-1M1" and 
          A1: "lenFINSEQ-1K4 g =XBOOLE-0R4 lenFINSEQ-1K4 f"and A2: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 g implies g .FUNCT-1K1 k =XBOOLE-0R4 ?F(k)"
          using finseq_1_sch_2 sorry
        have "rngFUNCT-1K2 g c=TARSKIR1 NATNUMBERSK1"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 NATNUMBERSK1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 g"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A3: "y inHIDDENR3 domFINSEQ-1K5 g"and A4: "x =HIDDENR1 g .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A3 sorry
            have "g .FUNCT-1K1 y =XBOOLE-0R4 f .RECDEF-1K1 y modNAT-DK4 m"
              using A2 A3 sorry
            thus "x inHIDDENR3 NATNUMBERSK1"
              using A4 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 g c=TARSKIR1 NATNUMBERSK1"
            using tarski_def_3 sorry
        qed
        then have 
          [ty]:"g be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          using finseq_1_def_4 sorry
        show " ex tVar1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st lenFINSEQ-1K4 tVar1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 f implies tVar1 .RECDEF-1K1 k =XBOOLE-0R4 f .RECDEF-1K1 k modNAT-DK4 m)"
        proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule impI)
          show "lenFINSEQ-1K4 g =XBOOLE-0R4 lenFINSEQ-1K4 f"
            using A1 sorry
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "k inTARSKIR2 domFINSEQ-1K5 f"
          then have "k inTARSKIR2 domFINSEQ-1K5 g"
            using A1 finseq_3_th_29 sorry
          thus "g .RECDEF-1K1 k =XBOOLE-0R4 f .RECDEF-1K1 k modNAT-DK4 m"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for it2 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it1 .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies it2 .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m)) implies it1 =HIDDENR1 it2"
    proof-
      have " for fa be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for fb be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fa & (( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies fa .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m) & (lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fb & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies fb .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m))) implies fa =HIDDENR1 fb"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix fa assume [ty]: "fa be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        fix fb assume [ty]: "fb be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume A5: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fa"
          and A6: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies fa .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m"
          and A7: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 fb"
          and A8: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies fb .RECDEF-1K1 i =XBOOLE-0R4 f .RECDEF-1K1 i modNAT-DK4 m"
        have " for X be setHIDDENM2 holds domFINSEQ-1K5 f =XBOOLE-0R4 X implies fa =HIDDENR1 fb"
        proof(rule ballI,rule impI)
          fix X assume [ty]: "X be setHIDDENM2"
          assume A9: "domFINSEQ-1K5 f =XBOOLE-0R4 X"
          have A10: " for i be NatNAT-1M1 holds i inTARSKIR2 X implies fa .RECDEF-1K1 i =XBOOLE-0R4 fb .RECDEF-1K1 i"
          proof-
            have "( ex j be NatNAT-1M1 st j inTARSKIR2 X & fa .RECDEF-1K1 j <>HIDDENR2 fb .RECDEF-1K1 j) implies  False "
            proof(rule impI)
              assume Given: " ex j be NatNAT-1M1 st j inTARSKIR2 X & fa .RECDEF-1K1 j <>HIDDENR2 fb .RECDEF-1K1 j"
              then obtain j where
                [ty]:"j be NatNAT-1M1" and 
                A11: "j inTARSKIR2 X"and A12: "fa .RECDEF-1K1 j <>HIDDENR2 fb .RECDEF-1K1 j"
                 sorry
              have "fa .RECDEF-1K1 j <>HIDDENR2 f .RECDEF-1K1 j modNAT-DK4 m"
                using A8 A9 A11 A12 sorry
              thus " False "
                using A6 A9 A11 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have A13: "domFINSEQ-1K5 f =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
            using finseq_1_def_3 sorry
          also have "... = domFINSEQ-1K5 fb"
            using A7 finseq_1_def_3 sorry
          finally have "domFINSEQ-1K5 f =HIDDENR1 domFINSEQ-1K5 fb"
             sorry
          have "domFINSEQ-1K5 f =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
            using finseq_1_def_3 sorry
          also have "... = domFINSEQ-1K5 fa"
            using A5 finseq_1_def_3 sorry
          finally have "domFINSEQ-1K5 f =HIDDENR1 domFINSEQ-1K5 fa"
             sorry
          thus "fa =HIDDENR1 fb"
            using A9 A13 A10 sorry
        qed "sorry"
        thus "fa =HIDDENR1 fb"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem euler_2_th_11:
" for m be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds m <>HIDDENR2 0NUMBERSK6 implies ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
proof-
  have " for m be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds m <>HIDDENR2 0NUMBERSK6 implies ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 f =XBOOLE-0R4 Lamb1 implies ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    assume A1: "m <>HIDDENR2 0NUMBERSK6"
    have A2: "lenFINSEQ-1K4 f be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
    have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 f =XBOOLE-0R4 n implies ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m) implies ( for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 f =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m)"
      proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "?P(n)"
        fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume A5: "m <>HIDDENR2 0NUMBERSK6"
          and A6: "lenFINSEQ-1K4 f =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
        obtain fn where 
          [ty]:"fn be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and fnDef:"fn = f  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n"
           sorry
        have A7: "lenFINSEQ-1K4 fn =XBOOLE-0R4 n"
          using A6 finseq_1_th_59 nat_1_th_11 sorry
        have A8: "lenFINSEQ-1K4 (f modEULER-2K2 m) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
          using A6 euler_2_def_1 sorry
        then have A9: "lenFINSEQ-1K4 ((f modEULER-2K2 m) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) =XBOOLE-0R4 n"
          using finseq_1_th_59 nat_1_th_11 sorry
        have A10: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A6 nat_1_th_11 sorry
        have A11: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 ((f modEULER-2K2 m) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) implies ((f modEULER-2K2 m) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n).RECDEF-1K1 i =XBOOLE-0R4 (fn modEULER-2K2 m).RECDEF-1K1 i"
        proof(rule ballI,rule impMI ,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A12: "\<one>\<^sub>M <=XXREAL-0R1 i"
            and A13: "i <=XXREAL-0R1 lenFINSEQ-1K4 ((f modEULER-2K2 m) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n)"
          have A14: "(f  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n).RECDEF-1K1 i =XBOOLE-0R4 (f  |RELAT-1K8 SegFINSEQ-1K2 n).RECDEF-1K1 i"
            using finseq_1_def_15 sorry
          have A15: "i inTARSKIR2 SegFINSEQ-1K2 n"
            using A9 A12 A13 finseq_1_th_1 sorry
          then have A16: "((f modEULER-2K2 m) |RELAT-1K8 SegFINSEQ-1K2 n).RECDEF-1K1 i =XBOOLE-0R4 (f modEULER-2K2 m).RECDEF-1K1 i"
            using funct_1_th_49 sorry
          have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
            using A10 A9 A13 xxreal_0_th_2 sorry
          then have A17: "i inTARSKIR2 domFINSEQ-1K5 f"
            using A12 finseq_3_th_25 sorry
          have "i inTARSKIR2 domFINSEQ-1K5 fn"
            using A7 A9 A12 A13 finseq_3_th_25 sorry
          then have "(fn modEULER-2K2 m).RECDEF-1K1 i =HIDDENR1 fn .RECDEF-1K1 i modNAT-DK4 m"
            using euler_2_def_1 sorry
          also have "... = f .RECDEF-1K1 i modNAT-DK4 m"
            using A15 A14 funct_1_th_49 sorry
          also have "... = (f modEULER-2K2 m).RECDEF-1K1 i"
            using A17 euler_2_def_1 sorry
          finally have "(fn modEULER-2K2 m).RECDEF-1K1 i =HIDDENR1 (f modEULER-2K2 m).RECDEF-1K1 i"
             sorry
          thus "((f modEULER-2K2 m) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n).RECDEF-1K1 i =XBOOLE-0R4 (fn modEULER-2K2 m).RECDEF-1K1 i"
            using A16 finseq_1_def_15 sorry
        qed "sorry"
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
          using A6 finseq_3_th_25 sorry
        then have A18: "(f modEULER-2K2 m).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
          using euler_2_def_1 sorry
        have "lenFINSEQ-1K4 ((f modEULER-2K2 m) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) =XBOOLE-0R4 lenFINSEQ-1K4 (fn modEULER-2K2 m)"
          using A7 A9 euler_2_def_1 sorry
        then have "(f modEULER-2K2 m) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n =FINSEQ-1R1 fn modEULER-2K2 m"
          using A11 finseq_1_th_14 sorry
        then have "f modEULER-2K2 m =FINSEQ-1R1 (fn modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m *>)"
          using A8 A18 rfinseq_th_7 sorry
        then have A19: "ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =HIDDENR1 ProductWSIERP-1K2 (fn modEULER-2K2 m) *NAT-1K2 (f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m) modNAT-DK4 m"
          using rvsum_1_th_96 sorry
        also have "... = (ProductWSIERP-1K2 (fn modEULER-2K2 m) modNAT-DK4 m)*NAT-1K2 ((f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m)modNAT-DK4 m) modNAT-DK4 m"
          using euler_2_th_9 sorry
        also have "... = (ProductWSIERP-1K2 fn modNAT-DK4 m)*NAT-1K2 ((f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m)modNAT-DK4 m) modNAT-DK4 m"
          using A4 A5 A7 sorry
        also have "... = (ProductWSIERP-1K2 fn modNAT-DK4 m)*NAT-1K2 (f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m) modNAT-DK4 m"
          using euler_2_th_5 sorry
        finally have "ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =HIDDENR1 (ProductWSIERP-1K2 fn modNAT-DK4 m)*NAT-1K2 (f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m) modNAT-DK4 m"
           sorry
        have "ProductWSIERP-1K2 f modNAT-DK4 m =HIDDENR1 ProductWSIERP-1K2 (fn ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)*>)) modNAT-DK4 m"
          using A6 rfinseq_th_7 sorry
        also have "... = ProductWSIERP-1K2 fn *NAT-1K2 f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
          using rvsum_1_th_96 sorry
        finally have "ProductWSIERP-1K2 f modNAT-DK4 m =HIDDENR1 ProductWSIERP-1K2 fn *NAT-1K2 f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
           sorry
        thus "ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
          using A19 euler_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A20: "?P(0NUMBERSK6)"
    proof-
      have " for f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds m <>HIDDENR2 0NUMBERSK6 & lenFINSEQ-1K4 f =XBOOLE-0R4 0NUMBERSK6 implies ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
      proof(rule ballI,rule impMI ,rule impI)
        fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume "m <>HIDDENR2 0NUMBERSK6"
          and A21: "lenFINSEQ-1K4 f =XBOOLE-0R4 0NUMBERSK6"
        have A22: "f =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1 & lenFINSEQ-1K4 (f modEULER-2K2 m) =XBOOLE-0R4 0NUMBERSK6"
          using A21 euler_2_def_1 sorry
        then have "f modEULER-2K2 m =FINSEQ-1R1 <*>FINSEQ-1K7 NATNUMBERSK1"
           sorry
        thus "ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
          using A22 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A20 A3 sorry
    thus "ProductWSIERP-1K2 (f modEULER-2K2 m) modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 f modNAT-DK4 m"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_12:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds ((a <>HIDDENR2 0NUMBERSK6 & m >XXREAL-0R4 \<one>\<^sub>M) & a *XCMPLX-0K3 n modNAT-DK4 m =XBOOLE-0R4 n modNAT-DK4 m) & (m,n)are-coprimeINT-2R1 implies a modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & (m >XXREAL-0R4 \<one>\<^sub>M & (a *XCMPLX-0K3 n modNAT-DK4 m =XBOOLE-0R4 n modNAT-DK4 m & (m,n)are-coprimeINT-2R1)) implies a modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "m >XXREAL-0R4 \<one>\<^sub>M"
      and A3: "a *XCMPLX-0K3 n modNAT-DK4 m =XBOOLE-0R4 n modNAT-DK4 m"
      and A4: "(m,n)are-coprimeINT-2R1"
    obtain k2 where
      [ty]:"k2 be NatNAT-1M1" and 
      A5: "n =XBOOLE-0R4 m *XCMPLX-0K3 k2 +NAT-1K1 (n modNAT-DK4 m)"and "n modNAT-DK4 m <XXREAL-0R3 m"
      using A2 nat_d_def_2 sorry
    obtain k1 where
      [ty]:"k1 be NatNAT-1M1" and 
      A6: "a *XCMPLX-0K3 n =XBOOLE-0R4 m *XCMPLX-0K3 k1 +NAT-1K1 (a *XCMPLX-0K3 n modNAT-DK4 m)"and "a *XCMPLX-0K3 n modNAT-DK4 m <XXREAL-0R3 m"
      using A2 nat_d_def_2 sorry
    have "(a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 n =XBOOLE-0R4 m *XCMPLX-0K3 (k1 -XCMPLX-0K6 k2)"
      using A3 A6 A5 sorry
    then have A7: "m dividesINT-1R1 (a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 n"
      using int_1_def_3 sorry
    obtain t where 
      [ty]:"t be IntegerINT-1M1" and tDef:"t = a -XCMPLX-0K6 \<one>\<^sub>M" and
      [ty]:"m be IntegerINT-1M1"
       sorry
    have "m dividesINT-1R1 t"
      using A4 A7 int_2_th_25 sorry
    then obtain tt where
      [ty]:"tt be IntegerINT-1M1" and 
      A8: "a -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 tt"
      using int_1_def_3 sorry
    have "a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
      using A1 euler_2_lm_2 sorry
    then have A9: "tt >=XXREAL-0R2 0NUMBERSK6"
      using A2 A8 xreal_1_th_158 sorry
    have A10: "a =XBOOLE-0R4 m *XCMPLX-0K3 tt +XCMPLX-0K2 \<one>\<^sub>M"
      using A8 sorry
    have 
      [ty]:"tt be ElementSUBSET-1M1-of NATNUMBERSK1" and
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A9 int_1_th_3 sorry
    have "a modNAT-DK4 m =HIDDENR1 ((m *NAT-1K2 tt modNAT-DK4 m)+NAT-1K1 \<one>\<^sub>M)modNAT-DK4 m"
      using A10 nat_d_th_22 sorry
    also have "... = (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 m"
      using nat_d_th_13 sorry
    also have "... = \<one>\<^sub>M"
      using A2 nat_d_th_24 sorry
    finally have "a modNAT-DK4 m =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "a modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_13:
" for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (F modEULER-2K2 m)modEULER-2K2 m =FINSEQ-1R1 F modEULER-2K2 m"
proof-
  have " for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (F modEULER-2K2 m)modEULER-2K2 m =FINSEQ-1R1 F modEULER-2K2 m"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have A1: "domFINSEQ-1K5 (F modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (F modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using euler_2_def_1 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (F modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 F implies ((F modEULER-2K2 m)modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 (F modEULER-2K2 m).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domFINSEQ-1K5 F"
      then have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      have "((F modEULER-2K2 m)modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (F modEULER-2K2 m).RECDEF-1K1 x modNAT-DK4 m"
        using A1 A3 euler_2_def_1 sorry
      also have "... = (F .RECDEF-1K1 x modNAT-DK4 m)modNAT-DK4 m"
        using A3 euler_2_def_1 sorry
      also have "... = F .RECDEF-1K1 x modNAT-DK4 m"
        using euler_2_th_5 sorry
      also have "... = (F modEULER-2K2 m).RECDEF-1K1 x"
        using A3 euler_2_def_1 sorry
      finally have "((F modEULER-2K2 m)modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (F modEULER-2K2 m).RECDEF-1K1 x"
         sorry
      thus "((F modEULER-2K2 m)modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 (F modEULER-2K2 m).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domFINSEQ-1K5 ((F modEULER-2K2 m)modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((F modEULER-2K2 m)modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (F modEULER-2K2 m))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using euler_2_def_1 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 ((F modEULER-2K2 m)modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    thus "(F modEULER-2K2 m)modEULER-2K2 m =FINSEQ-1R1 F modEULER-2K2 m"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_14:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m =FINSEQ-1R1 a *EULER-2K1 F modEULER-2K2 m"
proof-
  have " for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m =FINSEQ-1R1 a *EULER-2K1 F modEULER-2K2 m"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have A1: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_2_th_24 numbers_th_19 sorry
    have A2: "F modEULER-2K2 m be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_2_th_24 numbers_th_19 sorry
    have A3: "domFINSEQ-1K5 (a *EULER-2K1 F) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using A1 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 F) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have A4: "domFINSEQ-1K5 (a *EULER-2K1 (F modEULER-2K2 m)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 (F modEULER-2K2 m)))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (F modEULER-2K2 m))"
      using A2 newton_th_2 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using euler_2_def_1 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 (F modEULER-2K2 m)) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 F implies (a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 (a *EULER-2K1 F modEULER-2K2 m).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 domFINSEQ-1K5 F"
      then have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      have "(a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (a *EULER-2K1 (F modEULER-2K2 m)).RECDEF-1K1 x modNAT-DK4 m"
        using A4 A6 euler_2_def_1 sorry
      also have "... = a *XCMPLX-0K3 (F modEULER-2K2 m).RECDEF-1K1 x modNAT-DK4 m"
        using rvsum_1_th_44 sorry
      also have "... = a *XCMPLX-0K3 (F .RECDEF-1K1 x modNAT-DK4 m) modNAT-DK4 m"
        using A6 euler_2_def_1 sorry
      also have "... = a *XCMPLX-0K3 F .RECDEF-1K1 x modNAT-DK4 m"
        using euler_2_th_7 sorry
      also have "... = (a *EULER-2K1 F).RECDEF-1K1 x modNAT-DK4 m"
        using rvsum_1_th_44 sorry
      also have "... = (a *EULER-2K1 F modEULER-2K2 m).RECDEF-1K1 x"
        using A3 A6 euler_2_def_1 sorry
      finally have "(a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (a *EULER-2K1 F modEULER-2K2 m).RECDEF-1K1 x"
         sorry
      thus "(a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 (a *EULER-2K1 F modEULER-2K2 m).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have A7: "domFINSEQ-1K5 (a *EULER-2K1 F modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using A1 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 F modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have "domFINSEQ-1K5 (a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 (F modEULER-2K2 m)))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (F modEULER-2K2 m))"
      using A2 newton_th_2 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using euler_2_def_1 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    thus "a *EULER-2K1 (F modEULER-2K2 m) modEULER-2K2 m =FINSEQ-1R1 a *EULER-2K1 F modEULER-2K2 m"
      using A7 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_15:
" for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m =FINSEQ-1R1 (F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)"
proof-
  have " for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m =FINSEQ-1R1 (F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)"
  proof(rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have A1: "domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G))"
      using euler_2_def_1 sorry
    also have "... = domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
       sorry
    have A2: "domFINSEQ-1K5 (G modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (G modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 G)"
      using euler_2_def_1 sorry
    also have "... = domFINSEQ-1K5 G"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (G modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 G"
       sorry
    have A3: "domFINSEQ-1K5 (F modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (F modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using euler_2_def_1 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (F modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) implies (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
      then have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      have "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x"
      proof-
        show "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x"
        proof-
          have cases: "x inTARSKIR2 domFINSEQ-1K5 F or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 G & x =XBOOLE-0R4 lenFINSEQ-1K4 F +XCMPLX-0K2 n)"
            using A5 finseq_1_th_25 sorry
          have case1: "x inTARSKIR2 domFINSEQ-1K5 F implies (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x"
          proof(rule impI)
            assume A6: "x inTARSKIR2 domFINSEQ-1K5 F"
            have A7: "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G).RECDEF-1K1 x modNAT-DK4 m"
              using A5 euler_2_def_1 sorry
            also have "... = F .RECDEF-1K1 x modNAT-DK4 m"
              using A6 finseq_1_def_7 sorry
            finally have "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 F .RECDEF-1K1 x modNAT-DK4 m"
               sorry
            have "((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 (F modEULER-2K2 m).RECDEF-1K1 x"
              using A3 A6 finseq_1_def_7 sorry
            also have "... = F .RECDEF-1K1 x modNAT-DK4 m"
              using A6 euler_2_def_1 sorry
            finally have "((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 F .RECDEF-1K1 x modNAT-DK4 m"
               sorry
            thus "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x"
              using A7 sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 G & x =XBOOLE-0R4 lenFINSEQ-1K4 F +XCMPLX-0K2 n) implies (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x"
          proof(rule impI)
            assume " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 G & x =XBOOLE-0R4 lenFINSEQ-1K4 F +XCMPLX-0K2 n"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A8: "n inTARSKIR2 domFINSEQ-1K5 G"and A9: "x =XBOOLE-0R4 lenFINSEQ-1K4 F +NAT-1K1 n"
               sorry
            have A10: "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G).RECDEF-1K1 x modNAT-DK4 m"
              using A5 euler_2_def_1 sorry
            also have "... = G .RECDEF-1K1 n modNAT-DK4 m"
              using A8 A9 finseq_1_def_7 sorry
            finally have "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 G .RECDEF-1K1 n modNAT-DK4 m"
               sorry
            have "lenFINSEQ-1K4 (F modEULER-2K2 m) =XBOOLE-0R4 lenFINSEQ-1K4 F"
              using euler_2_def_1 sorry
            then have "((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 (G modEULER-2K2 m).RECDEF-1K1 n"
              using A2 A8 A9 finseq_1_def_7 sorry
            also have "... = G .RECDEF-1K1 n modNAT-DK4 m"
              using A8 euler_2_def_1 sorry
            finally have "((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 G .RECDEF-1K1 n modNAT-DK4 m"
               sorry
            thus "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).RECDEF-1K1 x"
              using A10 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domFINSEQ-1K5 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (F modEULER-2K2 m) +NAT-1K1 lenFINSEQ-1K4 (G modEULER-2K2 m))"
      using finseq_1_th_22 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F +NAT-1K1 lenFINSEQ-1K4 (G modEULER-2K2 m))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F +NAT-1K1 lenFINSEQ-1K4 G)"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G))"
      using finseq_1_th_22 sorry
    also have "... = domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 ((F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)) =HIDDENR1 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
       sorry
    thus "F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G modEULER-2K2 m =FINSEQ-1R1 (F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (G modEULER-2K2 m)"
      using A1 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_16:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m =FINSEQ-1R1 (a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)"
proof-
  have " for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m =FINSEQ-1R1 (a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix F assume [ty]: "F be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    fix G assume [ty]: "G be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have A1: "F be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_2_th_24 numbers_th_19 sorry
    have A2: "G be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_2_th_24 numbers_th_19 sorry
    obtain FG where 
      [ty]:"FG be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and FGDef:"FG = F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G"
       sorry
    have A3: "FG be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_2_th_24 numbers_th_19 sorry
    have A4: "domFINSEQ-1K5 (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 FG))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 FG)"
      using A3 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)) =HIDDENR1 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
       sorry
    have A5: "domFINSEQ-1K5 (a *EULER-2K1 G) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 G))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 G)"
      using A2 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 G"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 G) =HIDDENR1 domFINSEQ-1K5 G"
       sorry
    have A6: "domFINSEQ-1K5 (a *EULER-2K1 G modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 G modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 G))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 G)"
      using A2 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 G"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 G modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 G"
       sorry
    have A7: "domFINSEQ-1K5 (a *EULER-2K1 F) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using A1 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 F) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have A8: "domFINSEQ-1K5 (a *EULER-2K1 F modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F)"
      using A1 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 F"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 F modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 F"
       sorry
    have A9: " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) implies (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      obtain H where 
        [ty]:"H be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and HDef:"H = F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G"
         sorry
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A10: "x inHIDDENR3 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
      then have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      have "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x"
      proof-
        show "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x"
        proof-
          have cases: "x inTARSKIR2 domFINSEQ-1K5 F or ( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 G & x =XBOOLE-0R4 lenFINSEQ-1K4 F +XCMPLX-0K2 n)"
            using A10 finseq_1_th_25 sorry
          have case1: "x inTARSKIR2 domFINSEQ-1K5 F implies (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x"
          proof(rule impI)
            assume A11: "x inTARSKIR2 domFINSEQ-1K5 F"
            have A12: "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)).RECDEF-1K1 x modNAT-DK4 m"
              using A4 A10 euler_2_def_1 sorry
            also have "... = a *XCMPLX-0K3 H .RECDEF-1K1 x modNAT-DK4 m"
              using rvsum_1_th_44 sorry
            also have "... = a *XCMPLX-0K3 F .RECDEF-1K1 x modNAT-DK4 m"
              using A11 finseq_1_def_7 sorry
            finally have "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 a *XCMPLX-0K3 F .RECDEF-1K1 x modNAT-DK4 m"
               sorry
            have "((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 (a *EULER-2K1 F modEULER-2K2 m).RECDEF-1K1 x"
              using A8 A11 finseq_1_def_7 sorry
            also have "... = (a *EULER-2K1 F).RECDEF-1K1 x modNAT-DK4 m"
              using A7 A11 euler_2_def_1 sorry
            also have "... = a *XCMPLX-0K3 F .RECDEF-1K1 x modNAT-DK4 m"
              using rvsum_1_th_44 sorry
            finally have "((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 a *XCMPLX-0K3 F .RECDEF-1K1 x modNAT-DK4 m"
               sorry
            thus "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x"
              using A12 sorry
          qed
          have case2: "( ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 G & x =XBOOLE-0R4 lenFINSEQ-1K4 F +XCMPLX-0K2 n) implies (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x"
          proof(rule impI)
            assume " ex n be NatNAT-1M1 st n inTARSKIR2 domFINSEQ-1K5 G & x =XBOOLE-0R4 lenFINSEQ-1K4 F +XCMPLX-0K2 n"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A13: "n inTARSKIR2 domFINSEQ-1K5 G"and A14: "x =XBOOLE-0R4 lenFINSEQ-1K4 F +NAT-1K1 n"
               sorry
            have A15: "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)).RECDEF-1K1 x modNAT-DK4 m"
              using A4 A10 euler_2_def_1 sorry
            also have "... = a *XCMPLX-0K3 H .RECDEF-1K1 x modNAT-DK4 m"
              using rvsum_1_th_44 sorry
            also have "... = a *XCMPLX-0K3 G .RECDEF-1K1 n modNAT-DK4 m"
              using A13 A14 finseq_1_def_7 sorry
            finally have "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =HIDDENR1 a *XCMPLX-0K3 G .RECDEF-1K1 n modNAT-DK4 m"
               sorry
            have "lenFINSEQ-1K4 (a *EULER-2K1 F modEULER-2K2 m) =HIDDENR1 lenFINSEQ-1K4 (a *EULER-2K1 F)"
              using euler_2_def_1 sorry
            also have "... = lenFINSEQ-1K4 F"
              using A1 newton_th_2 sorry
            finally have "lenFINSEQ-1K4 (a *EULER-2K1 F modEULER-2K2 m) =HIDDENR1 lenFINSEQ-1K4 F"
               sorry
            then have "((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 (a *EULER-2K1 G modEULER-2K2 m).RECDEF-1K1 n"
              using A6 A13 A14 finseq_1_def_7 sorry
            also have "... = (a *EULER-2K1 G).RECDEF-1K1 n modNAT-DK4 m"
              using A5 A13 euler_2_def_1 sorry
            also have "... = a *XCMPLX-0K3 G .RECDEF-1K1 n modNAT-DK4 m"
              using rvsum_1_th_44 sorry
            finally have "((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x =HIDDENR1 a *XCMPLX-0K3 G .RECDEF-1K1 n modNAT-DK4 m"
               sorry
            thus "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).RECDEF-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).RECDEF-1K1 x"
              using A15 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m).FUNCT-1K1 x =XBOOLE-0R4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have A16: "domFINSEQ-1K5 (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 FG modEULER-2K2 m))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 FG))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 FG)"
      using A3 newton_th_2 sorry
    also have "... = domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 (a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m) =HIDDENR1 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
       sorry
    have "domFINSEQ-1K5 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)))"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F modEULER-2K2 m) +NAT-1K1 lenFINSEQ-1K4 (a *EULER-2K1 G modEULER-2K2 m))"
      using finseq_1_th_22 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F) +NAT-1K1 lenFINSEQ-1K4 (a *EULER-2K1 G modEULER-2K2 m))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (a *EULER-2K1 F) +NAT-1K1 lenFINSEQ-1K4 (a *EULER-2K1 G))"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F +NAT-1K1 lenFINSEQ-1K4 (a *EULER-2K1 G))"
      using A1 newton_th_2 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 F +NAT-1K1 lenFINSEQ-1K4 G)"
      using A2 newton_th_2 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G))"
      using finseq_1_th_22 sorry
    also have "... = domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
      using finseq_1_def_3 sorry
    finally have "domFINSEQ-1K5 ((a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)) =HIDDENR1 domFINSEQ-1K5 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G)"
       sorry
    thus "a *EULER-2K1 (F ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> G) modEULER-2K2 m =FINSEQ-1R1 (a *EULER-2K1 F modEULER-2K2 m)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (a *EULER-2K1 G modEULER-2K2 m)"
      using A16 A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem euler_2_th_17:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 0NUMBERSK6) & (a,m)are-coprimeINT-2R1 implies ( for b be NatNAT-1M1 holds (a  |^NEWTONK1 b,m)are-coprimeINT-2R1)"
proof-
  have " for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 0NUMBERSK6) & (a,m)are-coprimeINT-2R1 implies ( for b be NatNAT-1M1 holds (a  |^NEWTONK1 b,m)are-coprimeINT-2R1)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. (a  |^NEWTONK1 Lamb1,m)are-coprimeINT-2R1"
    assume A1: "(a <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 0NUMBERSK6) & (a,m)are-coprimeINT-2R1"
    have A2: " for b be NatNAT-1M1 holds ?P(b) implies ?P(b +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for b be NatNAT-1M1 holds (a  |^NEWTONK1 b,m)are-coprimeINT-2R1 implies (a  |^NEWTONK1 (b +NAT-1K1 \<one>\<^sub>M),m)are-coprimeINT-2R1"
      proof(rule ballI,rule impI)
        fix b assume [ty]: "b be NatNAT-1M1"
        have A3: "a  |^NEWTONK1 (b +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 b *XCMPLX-0K3 a  |^NEWTONK1 \<one>\<^sub>M"
          using newton_th_8 sorry
        also have "... = a  |^NEWTONK1 b *XCMPLX-0K3 a"
           sorry
        finally have "a  |^NEWTONK1 (b +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 b *XCMPLX-0K3 a"
           sorry
        assume "(a  |^NEWTONK1 b,m)are-coprimeINT-2R1"
        thus "(a  |^NEWTONK1 (b +NAT-1K1 \<one>\<^sub>M),m)are-coprimeINT-2R1"
          using A1 A3 euler_1_th_14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "a  |^NEWTONK1 (0NUMBERSK6) gcdNAT-DK8 m =XBOOLE-0R4 \<one>\<^sub>M gcdNAT-DK8 m & m gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using newton_th_4 newton_th_51 sorry
    then have A4: "?P(0NUMBERSK6)"
      using int_2_def_3 sorry
    have " for b be NatNAT-1M1 holds ?P(b)"
      using nat_1_sch_2 A4 A2 sorry
    thus " for b be NatNAT-1M1 holds (a  |^NEWTONK1 b,m)are-coprimeINT-2R1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
(*\$N Euler's Generalization of Fermat's Little Theorem*)
mtheorem euler_2_th_18:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & m >XXREAL-0R4 \<one>\<^sub>M) & (a,m)are-coprimeINT-2R1 implies a  |^NEWTONK1 EulerEULER-1K1 m modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & (m >XXREAL-0R4 \<one>\<^sub>M & (a,m)are-coprimeINT-2R1) implies a  |^NEWTONK1 EulerEULER-1K1 m modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "m >XXREAL-0R4 \<one>\<^sub>M"
      and A3: "(a,m)are-coprimeINT-2R1"
    let ?X = "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m }"
    have A4: "a  |^NEWTONK1 EulerEULER-1K1 m <>HIDDENR2 0NUMBERSK6"
      using A1 prepower_th_5 sorry
    let ?Y = "{l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 ?X }"
    have A5: " for x be NatNAT-1M1 holds x inTARSKIR2 ?X implies a *XCMPLX-0K3 x modNAT-DK4 m inTARSKIR2 ?X"
    proof-
      have " for x be NatNAT-1M1 holds x inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } implies a *XCMPLX-0K3 x modNAT-DK4 m inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be NatNAT-1M1"
        assume "x inTARSKIR2 ?X"
        then obtain t where
          [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A6: "t =XBOOLE-0R4 x"and A7: "(m,t)are-coprimeINT-2R1"and A8: "t >=XXREAL-0R2 \<one>\<^sub>M"and "t <=XXREAL-0R1 m"
           sorry
        have A9: "(a *XCMPLX-0K3 t,m)are-coprimeINT-2R1"
          using A1 A2 A3 A7 euler_1_th_14 sorry
        have "a *XCMPLX-0K3 t modNAT-DK4 m <>HIDDENR2 0NUMBERSK6"
        proof-
          have "a *XCMPLX-0K3 t modNAT-DK4 m =XBOOLE-0R4 0NUMBERSK6 implies  False "
          proof(rule impI)
            assume "a *XCMPLX-0K3 t modNAT-DK4 m =XBOOLE-0R4 0NUMBERSK6"
            then obtain s where
              [ty]:"s be NatNAT-1M1" and 
              A10: "a *XCMPLX-0K3 t =XBOOLE-0R4 m *XCMPLX-0K3 s +NAT-1K1 0NUMBERSK6"and "0NUMBERSK6 <XXREAL-0R3 m"
              using A2 nat_d_def_2 sorry
            have "s gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
              using newton_th_51 sorry
            then have "m *XCMPLX-0K3 s gcdNAT-DK8 m *XCMPLX-0K3 \<one>\<^sub>M =XBOOLE-0R4 m"
              using euler_1_th_5 sorry
            thus " False "
              using A2 A9 A10 int_2_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have A11: "a *XCMPLX-0K3 t modNAT-DK4 m >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_14 sorry
        have A12: "a *XCMPLX-0K3 t modNAT-DK4 m <=XXREAL-0R1 m"
          using A2 nat_d_th_1 sorry
        have "(m,a *XCMPLX-0K3 t modNAT-DK4 m)are-coprimeINT-2R1"
          using A1 A2 A3 A7 A8 euler_2_th_3 sorry
        thus "a *XCMPLX-0K3 x modNAT-DK4 m inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m }"
          using A6 A11 A12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A13: "?X =XBOOLE-0R4 ?Y"
    proof-
      have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } =XBOOLE-0R4 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
      proof-
        have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } } & {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) } c=TARSKIR1 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m }"
        proof(rule conjMI)
          show "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } }"
          proof-
            have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } implies x inHIDDENR3 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 ?X"
                then obtain xx where
                  [ty]:"xx be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A14: "x =HIDDENR1 xx"and A15: "(m,xx)are-coprimeINT-2R1"and "xx >=XXREAL-0R2 \<one>\<^sub>M"and A16: "xx <=XXREAL-0R1 m"
                   sorry
                obtain i j where
                  [ty]:"i be IntegerINT-1M1" "j be IntegerINT-1M1" and 
                  A17: "i *XCMPLX-0K3 a +XCMPLX-0K2 j *XCMPLX-0K3 m =XBOOLE-0R4 xx"
                  using A3 euler_1_th_10 sorry
                have "xx <>HIDDENR2 m"
                  using A2 A15 euler_1_th_1 sorry
                then have "xx <XXREAL-0R3 m"
                  using A16 xxreal_0_th_1 sorry
                then have A18: "xx modNAT-DK4 m =XBOOLE-0R4 xx"
                  using nat_d_th_24 sorry
                obtain im where 
                  [ty]:"im be ElementSUBSET-1M1-of NATNUMBERSK1" and imDef:"im = i modINT-1K6 m"
                  using int_1_th_3 newton_th_64 sorry
                have "i modINT-1K6 m <>HIDDENR2 0NUMBERSK6"
                proof-
                  have "i modINT-1K6 m =HIDDENR1 0NUMBERSK6 implies  False "
                  proof(rule impI)
                    assume "i modINT-1K6 m =HIDDENR1 0NUMBERSK6"
                    then have "0NUMBERSK6 =XBOOLE-0R4 i -XCMPLX-0K6 (i divINT-1K5 m)*XCMPLX-0K3 m"
                      using A2 int_1_def_10 sorry
                    then have "m gcdNAT-DK8 xx =HIDDENR1 m *XCMPLX-0K3 \<one>\<^sub>M gcdINT-2K3 m *XCMPLX-0K3 ((i divINT-1K5 m)*XCMPLX-0K3 a +XCMPLX-0K2 j)"
                      using A17 sorry
                    also have "... = m *XCMPLX-0K3 (\<one>\<^sub>M gcdINT-2K3 ((i divINT-1K5 m)*XCMPLX-0K3 a +XCMPLX-0K2 j))"
                      using euler_1_th_15 sorry
                    also have "... = m *XCMPLX-0K3 \<one>\<^sub>M"
                      using euler_2_lm_3 sorry
                    also have "... = m"
                       sorry
                    finally have "m gcdNAT-DK8 xx =HIDDENR1 m"
                       sorry
                    thus " False "
                      using A2 A15 int_2_def_3 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                then have A19: "im >=XXREAL-0R2 \<one>\<^sub>M"
                  using nat_1_th_14 sorry
                have A20: "i =HIDDENR1 (i divINT-1K5 m)*XCMPLX-0K3 m +XCMPLX-0K2 (i modINT-1K6 m)"
                  using A2 newton_th_66 sorry
                then obtain ij where 
                  [ty]:"ij be ElementSUBSET-1M1-of NATNUMBERSK1" and ijDef:"ij = (i modINT-1K6 m)*XCMPLX-0K3 a +XCMPLX-0K2 ((i divINT-1K5 m)*XCMPLX-0K3 a +XCMPLX-0K2 j)*XCMPLX-0K3 m"
                  using A17 sorry
                have A21: "im <=XXREAL-0R1 m"
                  using A2 newton_th_65 sorry
                have A22: "ij modNAT-DK4 m =XBOOLE-0R4 im *XCMPLX-0K3 a modNAT-DK4 m"
                  using euler_1_th_12 sorry
                then have "(m,im)are-coprimeINT-2R1"
                  using A2 A15 A18 A17 A20 euler_2_th_4 sorry
                then have "im inTARSKIR2 ?X"
                  using A19 A21 sorry
                thus "x inHIDDENR3 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
                  using A14 A18 A17 A20 A22 sorry
              qed "sorry"
              thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } } implies y inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m }"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 ?Y"
            then have " ex yy be ElementSUBSET-1M1-of NATNUMBERSK1 st y =HIDDENR1 yy & ( ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st yy =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 ?X)"
               sorry
            thus "y inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m }"
              using A5 sorry
          qed "sorry"
          thus "{l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) } c=TARSKIR1 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m }"
            using tarski_def_3 sorry
        qed
        thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } =XBOOLE-0R4 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A23: " for xi be NatNAT-1M1 holds  for xj be NatNAT-1M1 holds (xi inTARSKIR2 ?X & xj inTARSKIR2 ?X) & xi <>HIDDENR2 xj implies a *XCMPLX-0K3 xi modNAT-DK4 m <>HIDDENR2 a *XCMPLX-0K3 xj modNAT-DK4 m"
    proof-
      have " for xi be NatNAT-1M1 holds  for xj be NatNAT-1M1 holds xi inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } & (xj inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } & xi <>HIDDENR2 xj) implies (a *XCMPLX-0K3 xi modNAT-DK4 m =XBOOLE-0R4 a *XCMPLX-0K3 xj modNAT-DK4 m implies  False )"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
        fix xi assume [ty]: "xi be NatNAT-1M1"
        fix xj assume [ty]: "xj be NatNAT-1M1"
        assume A24: "xi inTARSKIR2 ?X"
          and A25: "xj inTARSKIR2 ?X"
          and A26: "xi <>HIDDENR2 xj"
        let ?tm = "a *XCMPLX-0K3 xi modNAT-DK4 m"
        let ?sm = "a *XCMPLX-0K3 xj modNAT-DK4 m"
        assume A27: "a *XCMPLX-0K3 xi modNAT-DK4 m =XBOOLE-0R4 a *XCMPLX-0K3 xj modNAT-DK4 m"
        obtain s where
          [ty]:"s be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A28: "s =XBOOLE-0R4 xj"and "(m,s)are-coprimeINT-2R1"and A29: "s >=XXREAL-0R2 \<one>\<^sub>M & s <=XXREAL-0R1 m"
          using A25 sorry
        have A30: "?sm =XBOOLE-0R4 a *XCMPLX-0K3 s -XCMPLX-0K6 m *XCMPLX-0K3 (a *XCMPLX-0K3 s divNAT-DK3 m)"
          using A2 A28 newton_th_63 sorry
        obtain t where
          [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A31: "t =XBOOLE-0R4 xi"and "(m,t)are-coprimeINT-2R1"and A32: "t >=XXREAL-0R2 \<one>\<^sub>M & t <=XXREAL-0R1 m"
          using A24 sorry
        have "?tm =XBOOLE-0R4 a *XCMPLX-0K3 t -XCMPLX-0K6 m *XCMPLX-0K3 (a *XCMPLX-0K3 t divNAT-DK3 m)"
          using A2 A31 newton_th_63 sorry
        then have "0NUMBERSK6 =XBOOLE-0R4 a *XCMPLX-0K3 (t -XCMPLX-0K6 s) -XCMPLX-0K6 m *XCMPLX-0K3 ((a *XCMPLX-0K3 t divNAT-DK3 m)-XCMPLX-0K6 (a *XCMPLX-0K3 s divNAT-DK3 m))"
          using A27 A30 sorry
        then have A33: "m dividesINT-1R1 a *XCMPLX-0K3 (t -XCMPLX-0K6 s)"
          using int_1_def_3 sorry
        obtain c where 
          [ty]:"m be IntegerINT-1M1" and
          [ty]:"c be IntegerINT-1M1" and cDef:"c = t -XCMPLX-0K6 s"
           sorry
        have "\<one>\<^sub>M -XCMPLX-0K6 m <=XXREAL-0R1 c & c <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M"
          using A32 A29 xreal_1_th_13 sorry
        then have "t -XCMPLX-0K6 s =XBOOLE-0R4 0NUMBERSK6"
          using A3 A33 euler_2_lm_4 int_2_th_25 sorry
        thus " False "
          using A26 A31 A28 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain FX where 
      [ty]:"FX be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and FXDef:"FX = SgmFINSEQ-1K15 ?X"
       sorry
    have A34: "FX be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_2_th_24 numbers_th_19 sorry
    obtain FYY where 
      [ty]:"FYY be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and FYYDef:"FYY = a *EULER-2K1 FX"
       sorry
    obtain FY where 
      [ty]:"FY be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and FYDef:"FY = FYY modEULER-2K2 m"
       sorry
    have A35: "?X c=TARSKIR1 SegFINSEQ-1K2 m"
    proof-
      have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } c=TARSKIR1 SegFINSEQ-1K2 m"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } implies x inHIDDENR3 SegFINSEQ-1K2 m"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then have " ex xx be ElementSUBSET-1M1-of NATNUMBERSK1 st ((x =HIDDENR1 xx & (m,xx)are-coprimeINT-2R1) & xx >=XXREAL-0R2 \<one>\<^sub>M) & xx <=XXREAL-0R1 m"
             sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 m"
            using finseq_1_th_1 sorry
        qed "sorry"
        thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } c=TARSKIR1 SegFINSEQ-1K2 m"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain X where 
      [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = ?X"
       sorry
    have "domFINSEQ-1K5 FYY =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 FYY)"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 FX)"
      using A34 newton_th_2 sorry
    finally have "domFINSEQ-1K5 FYY =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 FX)"
       sorry
    then have A36: "domFINSEQ-1K5 FX =XBOOLE-0R4 domFINSEQ-1K5 FYY"
      using finseq_1_def_3 sorry
    have A37: "domFINSEQ-1K5 FY =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 FY)"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 FYY)"
      using euler_2_def_1 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 FX)"
      using A34 newton_th_2 sorry
    finally have "domFINSEQ-1K5 FY =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 FX)"
       sorry
    then have A38: "domFINSEQ-1K5 FX =XBOOLE-0R4 domFINSEQ-1K5 FY"
      using finseq_1_def_3 sorry
    have A39: "rngRVSUM-1K1 FY =XBOOLE-0R4 ?Y"
    proof-
      have "rngRVSUM-1K1 FY =XBOOLE-0R4 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
      proof-
        have "rngRVSUM-1K1 FY c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } } & {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) } c=TARSKIR1 rngRVSUM-1K1 FY"
        proof(rule conjMI)
          show "rngRVSUM-1K1 FY c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } }"
          proof-
            have "rngRVSUM-1K1 FY c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 FY implies x inHIDDENR3 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRVSUM-1K1 FY"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A40: "y inHIDDENR3 domFINSEQ-1K5 FY"and A41: "x =HIDDENR1 FY .FUNCT-1K1 y"
                  using funct_1_def_3 sorry
                have 
                  [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using A40 sorry
                have "FX .RECDEF-1K1 y inTARSKIR2 rngRVSUM-1K1 FX"
                  using A38 A40 funct_1_def_3 sorry
                then have A42: "FX .RECDEF-1K1 y inTARSKIR2 X"
                  using A35 finseq_1_def_13 sorry
                have "y inTARSKIR2 domFINSEQ-1K5 FX"
                  using A37 A40 finseq_1_def_3 sorry
                then have "FY .RECDEF-1K1 y =HIDDENR1 FYY .RECDEF-1K1 y modNAT-DK4 m"
                  using A36 euler_2_def_1 sorry
                also have "... = a *XCMPLX-0K3 FX .RECDEF-1K1 y modNAT-DK4 m"
                  using rvsum_1_th_44 sorry
                finally have "FY .RECDEF-1K1 y =HIDDENR1 a *XCMPLX-0K3 FX .RECDEF-1K1 y modNAT-DK4 m"
                   sorry
                thus "x inHIDDENR3 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
                  using A41 A42 sorry
              qed "sorry"
              thus "rngRVSUM-1K1 FY c=TARSKIR1 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m } } implies y inHIDDENR3 rngRVSUM-1K1 FY"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 ?Y"
            then obtain yy where
              [ty]:"yy be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A43: "y =HIDDENR1 yy"and A44: " ex u be ElementSUBSET-1M1-of NATNUMBERSK1 st yy =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 X"
               sorry
            obtain uu where
              [ty]:"uu be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A45: "yy =XBOOLE-0R4 a *XCMPLX-0K3 uu modNAT-DK4 m"and A46: "uu inTARSKIR2 X"
              using A44 sorry
            have "uu inTARSKIR2 rngRVSUM-1K1 FX"
              using A35 A46 finseq_1_def_13 sorry
            then obtain xx where
              [ty]:"xx be objectHIDDENM1" and 
              A47: "xx inHIDDENR3 domFINSEQ-1K5 FX"and A48: "uu =XBOOLE-0R4 FX .FUNCT-1K1 xx"
              using funct_1_def_3 sorry
            have 
              [ty]:"xx be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A47 sorry
            have "FY .RECDEF-1K1 xx =HIDDENR1 FYY .RECDEF-1K1 xx modNAT-DK4 m"
              using A36 A47 euler_2_def_1 sorry
            also have "... = y"
              using A43 A45 A48 rvsum_1_th_44 sorry
            finally have "FY .RECDEF-1K1 xx =HIDDENR1 y"
               sorry
            thus "y inHIDDENR3 rngRVSUM-1K1 FY"
              using A38 A47 funct_1_def_3 sorry
          qed "sorry"
          thus "{l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) } c=TARSKIR1 rngRVSUM-1K1 FY"
            using tarski_def_3 sorry
        qed
        thus "rngRVSUM-1K1 FY =XBOOLE-0R4 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 :  not ( for u be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (l =XBOOLE-0R4 a *XCMPLX-0K3 u modNAT-DK4 m & u inTARSKIR2 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((m,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 m })) }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A49: "FY be one-to-oneFUNCT-1V2"
    proof-
      have A50: "FX be one-to-oneFUNCT-1V2"
        using A35 finseq_3_th_92 sorry
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domFINSEQ-1K5 FY & (x2 inHIDDENR3 domFINSEQ-1K5 FY & FY .FUNCT-1K1 x1 =XBOOLE-0R4 FY .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A51: "x1 inHIDDENR3 domFINSEQ-1K5 FY"
          and A52: "x2 inHIDDENR3 domFINSEQ-1K5 FY"
          and A53: "FY .FUNCT-1K1 x1 =XBOOLE-0R4 FY .FUNCT-1K1 x2"
        have A54: "x2 inHIDDENR3 domFINSEQ-1K5 FX"
          using A37 A52 finseq_1_def_3 sorry
        have 
          [ty]:"x2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A52 sorry
        have A55: "x1 inHIDDENR3 domFINSEQ-1K5 FX"
          using A37 A51 finseq_1_def_3 sorry
        have 
          [ty]:"x1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A51 sorry
        have A56: "FX .RECDEF-1K1 x1 inTARSKIR2 rngRVSUM-1K1 FX & FX .RECDEF-1K1 x2 inTARSKIR2 rngRVSUM-1K1 FX"
          using A38 A51 A52 funct_1_def_3 sorry
        have A57: "FY .RECDEF-1K1 x2 =HIDDENR1 FYY .RECDEF-1K1 x2 modNAT-DK4 m"
          using A36 A54 euler_2_def_1 sorry
        also have "... = a *XCMPLX-0K3 FX .RECDEF-1K1 x2 modNAT-DK4 m"
          using rvsum_1_th_44 sorry
        finally have "FY .RECDEF-1K1 x2 =HIDDENR1 a *XCMPLX-0K3 FX .RECDEF-1K1 x2 modNAT-DK4 m"
           sorry
        have "FY .RECDEF-1K1 x1 =HIDDENR1 FYY .RECDEF-1K1 x1 modNAT-DK4 m"
          using A36 A55 euler_2_def_1 sorry
        also have "... = a *XCMPLX-0K3 FX .RECDEF-1K1 x1 modNAT-DK4 m"
          using rvsum_1_th_44 sorry
        finally have "FY .RECDEF-1K1 x1 =HIDDENR1 a *XCMPLX-0K3 FX .RECDEF-1K1 x1 modNAT-DK4 m"
           sorry
        then have " not ((FX .RECDEF-1K1 x1 inTARSKIR2 X & FX .RECDEF-1K1 x2 inTARSKIR2 X) & FX .RECDEF-1K1 x1 <>HIDDENR2 FX .RECDEF-1K1 x2)"
          using A23 A53 A57 sorry
        thus "x1 =HIDDENR1 x2"
          using A35 A55 A54 A56 A50 finseq_1_def_13 sorry
      qed "sorry"
      thus "FY be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(FX,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(FY,x))"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "cardCARD-1K1 (CoimRELAT-1K13(FX,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(FY,x))"
      proof-
        have cases: "x inHIDDENR3 X or  not x inHIDDENR3 X"
           sorry
        have case1: "x inHIDDENR3 X implies cardCARD-1K1 (CoimRELAT-1K13(FX,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(FY,x))"
        proof(rule impI)
          assume A58: "x inHIDDENR3 X"
          have A59: "FX be one-to-oneFUNCT-1V2"
            using A35 finseq_3_th_92 sorry
          have "x inHIDDENR3 rngRVSUM-1K1 FX"
            using A35 A58 finseq_1_def_13 sorry
          then have A60: "lenFINSEQ-1K4 (FX -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 FX -XCMPLX-0K6 \<one>\<^sub>M"
            using A59 finseq_3_th_90 sorry
          have A61: "lenFINSEQ-1K4 (FX -FINSEQ-3K1 {TARSKIK1 x}) -XCMPLX-0K6 lenFINSEQ-1K4 (FX -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 (lenFINSEQ-1K4 FX -XCMPLX-0K6 cardCARD-1K4 (FX \<inverse>FUNCT-1K6 {TARSKIK1 x}))-XCMPLX-0K6 lenFINSEQ-1K4 (FX -FINSEQ-3K1 {TARSKIK1 x}) & lenFINSEQ-1K4 (FY -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 FY -XCMPLX-0K6 cardCARD-1K4 (FY \<inverse>FUNCT-1K6 {TARSKIK1 x})"
            using finseq_3_th_59 sorry
          have "lenFINSEQ-1K4 (FY -FINSEQ-3K1 {TARSKIK1 x}) =XBOOLE-0R4 lenFINSEQ-1K4 FY -XCMPLX-0K6 \<one>\<^sub>M"
            using A13 A39 A49 A58 finseq_3_th_90 sorry
          thus "cardCARD-1K1 (CoimRELAT-1K13(FX,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(FY,x))"
            using A60 A61 sorry
        qed
        have case2: " not x inHIDDENR3 X implies cardCARD-1K1 (CoimRELAT-1K13(FX,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(FY,x))"
        proof(rule impI)
          assume " not x inHIDDENR3 X"
          then have " not x inHIDDENR3 rngRVSUM-1K1 FX & FY \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
            using A13 A35 A39 finseq_1_def_13 funct_1_th_72 sorry
          thus "cardCARD-1K1 (CoimRELAT-1K13(FX,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(FY,x))"
            using funct_1_th_72 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    then have A62: "(FX,FY)are-fiberwise-equipotentCLASSES1R2"
      using classes1_def_10 sorry
    then have A63: "lenFINSEQ-1K4 FX =XBOOLE-0R4 lenFINSEQ-1K4 FY"
      using rfinseq_th_3 sorry
    have A64: "ProductWSIERP-1K2 FY modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 FY *XCMPLX-0K3 ProductWSIERP-1K2 FX modNAT-DK4 m"
    proof-
      let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1) modNAT-DK4 m"
      have "FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 FY =FUNCT-1R1 FY  |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 FY)"
        using finseq_1_def_15 sorry
      then have A65: "FY =FINSEQ-1R1 FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 FY"
        using finseq_2_th_20 sorry
      have A66: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds  not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m))"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "(n <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m)"
          proof-
            show "(n <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m)"
            proof-
              have cases: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY or n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 lenFINSEQ-1K4 FY"
                 sorry
              have case1: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ((n <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m))"
              proof(rule impI,rule impI)
                assume A67: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY"
                then have "lenFINSEQ-1K4 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
                  using A63 finseq_1_th_59 sorry
                then have A68: "FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)*>)"
                  using rfinseq_th_7 sorry
                assume A69: "?P(n)"
                have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_13 sorry
                then have A70: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FY"
                  using A67 finseq_3_th_25 sorry
                have A71: "(FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FY .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using finseq_3_th_112 sorry
                have A72: "(FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FX .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using finseq_3_th_112 sorry
                have A73: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                then have A74: "lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) =XBOOLE-0R4 n"
                  using A67 finseq_1_th_59 xxreal_0_th_2 sorry
                have A75: "(FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n =FINSEQ-1R1 FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n"
                  using A73 finseq_5_th_77 sorry
                have A76: "(FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n =FINSEQ-1R1 FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n"
                  using A73 finseq_5_th_77 sorry
                have A77: "lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
                  using A67 finseq_1_th_59 sorry
                then have "FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)*>)"
                  using rfinseq_th_7 sorry
                then have "ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =HIDDENR1 ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *NAT-1K2 FY .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
                  using A76 A71 rvsum_1_th_96 sorry
                also have "... = (a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m)*NAT-1K2 (FY .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m) modNAT-DK4 m"
                  using A67 A69 A73 euler_2_th_9 xxreal_0_th_2 sorry
                also have "... = (a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m)*NAT-1K2 ((FYY .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m)modNAT-DK4 m) modNAT-DK4 m"
                  using A38 A36 A70 euler_2_def_1 sorry
                also have "... = (a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m)*NAT-1K2 ((a *EULER-2K1 FX).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m) modNAT-DK4 m"
                  using euler_2_th_5 sorry
                also have "... = (a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n))*XCMPLX-0K3 (a *EULER-2K1 FX).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
                  using euler_2_th_9 sorry
                also have "... = (a  |^NEWTONK1 n *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n))*XCMPLX-0K3 (a *XCMPLX-0K3 FX .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m"
                  using A74 rvsum_1_th_44 sorry
                also have "... = (a  |^NEWTONK1 n *XCMPLX-0K3 a)*XCMPLX-0K3 (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *NAT-1K2 FX .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m"
                   sorry
                also have "... = a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *NAT-1K2 FX .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m"
                  using A77 newton_th_6 sorry
                also have "... = a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m"
                  using A68 A75 A72 rvsum_1_th_96 sorry
                finally have "ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =HIDDENR1 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m"
                   sorry
                thus "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m"
                   sorry
              qed
              have case2: "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 lenFINSEQ-1K4 FY implies  not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m))"
              proof(rule impI)
                assume "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 lenFINSEQ-1K4 FY"
                thus " not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m))"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n) modNAT-DK4 m) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FY implies ProductWSIERP-1K2 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 (FY  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) *XCMPLX-0K3 ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 m))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 FX =FUNCT-1R1 FX  |RELAT-1K8 SegFINSEQ-1K2 (lenFINSEQ-1K4 FX)"
        using finseq_1_def_15 sorry
      then have A78: "FX =FINSEQ-1R1 FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 FY"
        using A63 finseq_2_th_20 sorry
      have A79: "?P(0NUMBERSK6)"
        using newton_th_4 rvsum_1_th_94 sorry
      have " for n be NatNAT-1M1 holds ?P(n)"
        using nat_1_sch_2 A79 A66 sorry
      thus "ProductWSIERP-1K2 FY modNAT-DK4 m =XBOOLE-0R4 a  |^NEWTONK1 lenFINSEQ-1K4 FY *XCMPLX-0K3 ProductWSIERP-1K2 FX modNAT-DK4 m"
        using A65 A78 sorry
    qed
    have A80: "(ProductWSIERP-1K2 FX,m)are-coprimeINT-2R1"
    proof-
      let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> Lamb1),m)are-coprimeINT-2R1"
      have A81: "FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 FX =FINSEQ-1R1 FX"
        using finseq_1_th_58 sorry
      have A82: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds  not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n),m)are-coprimeINT-2R1) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1))"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "(n <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n),m)are-coprimeINT-2R1) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1)"
          proof-
            show "(n <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n),m)are-coprimeINT-2R1) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1)"
            proof-
              have cases: "lenFINSEQ-1K4 FX >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M or lenFINSEQ-1K4 FX <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                 sorry
              have case1: "lenFINSEQ-1K4 FX >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M implies ((n <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n),m)are-coprimeINT-2R1) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1))"
              proof(rule impI,rule impI)
                assume A83: "lenFINSEQ-1K4 FX >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
                obtain FF where 
                  [ty]:"FF be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and FFDef:"FF = FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                obtain ff where 
                  [ty]:"ff be ElementSUBSET-1M1-of NATNUMBERSK1" and ffDef:"ff = FF .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                   sorry
                have "lenFINSEQ-1K4 FF =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
                  using A83 finseq_1_th_59 sorry
                then have A84: "FF =FINSEQ-1R1 FF  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> ff*>)"
                  using rfinseq_th_7 sorry
                obtain a b m9 where 
                  [ty]:"a be IntegerINT-1M1" and aDef:"a = ProductWSIERP-1K2 (FF  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n)" and
                  [ty]:"b be IntegerINT-1M1" and bDef:"b = ff" and
                  [ty]:"m9 be IntegerINT-1M1" and m9Def:"m9 = m"
                   sorry
                have A85: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                  using xreal_1_th_6 sorry
                then have "(FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 FX .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FX"
                  using A83 finseq_3_th_25 finseq_3_th_112 sorry
                then have A86: "(FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngRVSUM-1K1 FX"
                  using funct_1_def_3 sorry
                have "rngRVSUM-1K1 FX =XBOOLE-0R4 X"
                  using A35 finseq_1_def_13 sorry
                then have A87: " ex p be ElementSUBSET-1M1-of NATNUMBERSK1 st ((ff =XBOOLE-0R4 p & (m,p)are-coprimeINT-2R1) & p >=XXREAL-0R2 \<one>\<^sub>M) & p <=XXREAL-0R1 m"
                  using A86 sorry
                assume "?P(n)"
                then have "(a,m9)are-coprimeINT-2R1"
                  using A83 A85 finseq_5_th_77 xxreal_0_th_2 sorry
                then have "(a *XCMPLX-0K3 b,m9)are-coprimeINT-2R1"
                  using A87 int_2_th_26 sorry
                thus "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1"
                  using A84 rvsum_1_th_96 sorry
              qed
              have case2: "lenFINSEQ-1K4 FX <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies  not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n),m)are-coprimeINT-2R1) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1))"
              proof(rule impI)
                assume "lenFINSEQ-1K4 FX <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                thus " not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n),m)are-coprimeINT-2R1) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1))"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ((n <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> n),m)are-coprimeINT-2R1) &  not (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FX implies (ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)),m)are-coprimeINT-2R1))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "ProductWSIERP-1K2 (FX  |FINSEQ-1K18\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)) gcdNAT-DK8 m =XBOOLE-0R4 \<one>\<^sub>M"
        using newton_th_51 rvsum_1_th_94 sorry
      then have A88: "?P(0NUMBERSK6)"
        using int_2_def_3 sorry
      have " for n be NatNAT-1M1 holds ?P(n)"
        using nat_1_sch_2 A88 A82 sorry
      thus "(ProductWSIERP-1K2 FX,m)are-coprimeINT-2R1"
        using A81 sorry
    qed
    have "lenFINSEQ-1K4 FX =HIDDENR1 cardCARD-1K4 X"
      using A35 finseq_3_th_39 sorry
    also have "... = EulerEULER-1K1 m"
      using euler_1_def_1 sorry
    finally have "lenFINSEQ-1K4 FX =HIDDENR1 EulerEULER-1K1 m"
       sorry
    then have A89: "lenFINSEQ-1K4 FY =XBOOLE-0R4 EulerEULER-1K1 m"
      using A62 rfinseq_th_3 sorry
    have "ProductWSIERP-1K2 FX modNAT-DK4 m =XBOOLE-0R4 ProductWSIERP-1K2 FY modNAT-DK4 m"
      using A62 euler_2_th_10 sorry
    thus "a  |^NEWTONK1 EulerEULER-1K1 m modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 A64 A89 A4 A80 euler_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Small Fermat's Theorem*)
mtheorem euler_2_th_19:
" for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (a <>HIDDENR2 0NUMBERSK6 & m be primeINT-2V1) & (a,m)are-coprimeINT-2R1 implies a  |^NEWTONK1 m modNAT-DK4 m =XBOOLE-0R4 a modNAT-DK4 m"
proof-
  have " for a be NatNAT-1M1 holds  for m be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 & (m be primeINT-2V1 & (a,m)are-coprimeINT-2R1) implies a  |^NEWTONK1 m modNAT-DK4 m =XBOOLE-0R4 a modNAT-DK4 m"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "m be primeINT-2V1"
      and A3: "(a,m)are-coprimeINT-2R1"
    have A4: "m >XXREAL-0R4 \<one>\<^sub>M"
      using A2 int_2_def_4 sorry
    then have "m -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then obtain mm where 
      [ty]:"mm be ElementSUBSET-1M1-of NATNUMBERSK1" and mmDef:"mm = m -XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_3 sorry
    have "EulerEULER-1K1 m =XBOOLE-0R4 m -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 euler_1_th_20 sorry
    then have "(a  |^NEWTONK1 mm modNAT-DK4 m)*XCMPLX-0K3 a =XBOOLE-0R4 \<one>\<^sub>M *XCMPLX-0K3 a"
      using A1 A3 A4 euler_2_th_18 sorry
    then have "mm +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m & a  |^NEWTONK1 mm *XCMPLX-0K3 a modNAT-DK4 m =XBOOLE-0R4 a modNAT-DK4 m"
      using euler_2_th_7 sorry
    thus "a  |^NEWTONK1 m modNAT-DK4 m =XBOOLE-0R4 a modNAT-DK4 m"
      using newton_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
