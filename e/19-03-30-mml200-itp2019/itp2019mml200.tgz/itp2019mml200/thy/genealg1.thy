theory genealg1
  imports card_3 finseq_6
   "../mizar_extension/E_number"
begin
(*begin*)
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve f1, f2 for "FinSequenceFINSEQ-1M3-of D"
reserve i, n, n1, n2, n3, n4, n5, n6 for "ElementSUBSET-1M1-of NATNUMBERSK1"
mtheorem genealg1_th_1:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n =FINSEQ-1R1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds n <=XXREAL-0R1 lenFINSEQ-1K4 f1 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n =FINSEQ-1R1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n <=XXREAL-0R1 lenFINSEQ-1K4 f1"
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "lenFINSEQ-1K4 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =XBOOLE-0R4 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
      using finseq_1_th_22 sorry
    then have "lenFINSEQ-1K4 f1 <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using nat_1_th_11 sorry
    then have A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using A1 xxreal_0_th_2 sorry
    then have A3: "lenFINSEQ-1K4 ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n) =XBOOLE-0R4 lenFINSEQ-1K4 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) -XCMPLX-0K6 n"
      using rfinseq_def_1 sorry
    have A4: "lenFINSEQ-1K4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =HIDDENR1 lenFINSEQ-1K4 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n) +NAT-1K1 lenFINSEQ-1K4 f2"
      using finseq_1_th_22 sorry
    also have "... = (lenFINSEQ-1K4 f1 -XCMPLX-0K6 n)+XCMPLX-0K2 lenFINSEQ-1K4 f2"
      using A1 rfinseq_def_1 sorry
    also have "... = (lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2)-XCMPLX-0K6 n"
       sorry
    finally have "lenFINSEQ-1K4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =HIDDENR1 (lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2)-XCMPLX-0K6 n"
       sorry
    have A5: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n) implies ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
    proof(rule ballI,rule impMI ,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A6: "\<one>\<^sub>M <=XXREAL-0R1 i"
        and A7: "i <=XXREAL-0R1 lenFINSEQ-1K4 ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n)"
      have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n))"
        using A6 A7 finseq_1_th_1 sorry
      then have A8: "i inTARSKIR2 domFINSEQ-1K5 ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n)"
        using finseq_1_def_3 sorry
      have 
        [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
      proof-
        show "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
        proof-
          have cases: "i <=XXREAL-0R1 lenFINSEQ-1K4 f1 -XCMPLX-0K6 n or lenFINSEQ-1K4 f1 -XCMPLX-0K6 n <XXREAL-0R3 i"
             sorry
          have case1: "i <=XXREAL-0R1 lenFINSEQ-1K4 f1 -XCMPLX-0K6 n implies ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
          proof(rule impI)
            assume A9: "i <=XXREAL-0R1 lenFINSEQ-1K4 f1 -XCMPLX-0K6 n"
            have "i <=XXREAL-0R1 i +NAT-1K1 n"
              using nat_1_th_11 sorry
            then have A10: "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 n"
              using A6 xxreal_0_th_2 sorry
            have "i +NAT-1K1 n <=XXREAL-0R1 lenFINSEQ-1K4 f1"
              using A9 xreal_1_th_19 sorry
            then have "i +NAT-1K1 n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1)"
              using A10 finseq_1_th_1 sorry
            then have A11: "i +NAT-1K1 n inTARSKIR2 domFINSEQ-1K5 f1"
              using finseq_1_def_3 sorry
            have "i <=XXREAL-0R1 lenFINSEQ-1K4 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
              using A1 A9 rfinseq_def_1 sorry
            then have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n))"
              using A6 finseq_1_th_1 sorry
            then have A12: "i inTARSKIR2 domFINSEQ-1K5 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
              using finseq_1_def_3 sorry
            then have A13: "((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i =HIDDENR1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i"
              using finseq_1_def_7 sorry
            also have "... = f1 .FUNCT-1K1 (i +NAT-1K1 n)"
              using A1 A12 rfinseq_def_1 sorry
            finally have "((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i =HIDDENR1 f1 .FUNCT-1K1 (i +NAT-1K1 n)"
               sorry
            have "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =HIDDENR1 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 (i +NAT-1K1 n)"
              using A2 A8 rfinseq_def_1 sorry
            also have "... = f1 .FUNCT-1K1 (i +NAT-1K1 n)"
              using A11 finseq_1_def_7 sorry
            finally have "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =HIDDENR1 f1 .FUNCT-1K1 (i +NAT-1K1 n)"
               sorry
            thus "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
              using A13 sorry
          qed
          have case2: "lenFINSEQ-1K4 f1 -XCMPLX-0K6 n <XXREAL-0R3 i implies ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
          proof(rule impI)
            assume A14: "lenFINSEQ-1K4 f1 -XCMPLX-0K6 n <XXREAL-0R3 i"
            then have A15: "lenFINSEQ-1K4 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n) <XXREAL-0R3 i"
              using A1 rfinseq_def_1 sorry
            have "i <=XXREAL-0R1 lenFINSEQ-1K4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
              using A3 A4 A7 finseq_1_th_22 sorry
            then have A16: "((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i =HIDDENR1 f2 .FUNCT-1K1 (i -XCMPLX-0K6 lenFINSEQ-1K4 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n))"
              using A15 finseq_1_th_24 sorry
            also have "... = f2 .FUNCT-1K1 (i -XCMPLX-0K6 (lenFINSEQ-1K4 f1 -XCMPLX-0K6 n))"
              using A1 rfinseq_def_1 sorry
            also have "... = f2 .FUNCT-1K1 ((i +NAT-1K1 n)-XCMPLX-0K6 lenFINSEQ-1K4 f1)"
               sorry
            finally have "((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i =HIDDENR1 f2 .FUNCT-1K1 ((i +NAT-1K1 n)-XCMPLX-0K6 lenFINSEQ-1K4 f1)"
               sorry
            have A17: "i +NAT-1K1 n <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
              using A3 A7 xreal_1_th_19 sorry
            have A18: "lenFINSEQ-1K4 f1 <XXREAL-0R3 i +NAT-1K1 n"
              using A14 xreal_1_th_19 sorry
            have "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =HIDDENR1 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 (i +NAT-1K1 n)"
              using A2 A8 rfinseq_def_1 sorry
            also have "... = f2 .FUNCT-1K1 ((i +NAT-1K1 n)-XCMPLX-0K6 lenFINSEQ-1K4 f1)"
              using A18 A17 finseq_1_th_24 sorry
            finally have "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =HIDDENR1 f2 .FUNCT-1K1 ((i +NAT-1K1 n)-XCMPLX-0K6 lenFINSEQ-1K4 f1)"
               sorry
            thus "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
              using A16 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 i"
         sorry
    qed "sorry"
    have "lenFINSEQ-1K4 ((f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n) =XBOOLE-0R4 lenFINSEQ-1K4 ((f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using A3 A4 finseq_1_th_22 sorry
    thus "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/^RFINSEQK2\<^bsub>(D)\<^esub> n =FINSEQ-1R1 (f1 /^RFINSEQK2\<^bsub>(D)\<^esub> n)^FINSEQ-1K9\<^bsub>(D)\<^esub> f2"
      using A5 finseq_1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +NAT-1K1 i) =FINSEQ-1R1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +NAT-1K1 i) =FINSEQ-1R1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
    have "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +NAT-1K1 i) =FUNCT-1R1 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 f1 +NAT-1K1 i) & f2  |FINSEQ-1K18\<^bsub>(D)\<^esub> i =FUNCT-1R1 f2  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 i"
      using finseq_1_def_15 sorry
    thus "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) |FINSEQ-1K18\<^bsub>(D)\<^esub> (lenFINSEQ-1K4 f1 +NAT-1K1 i) =FINSEQ-1R1 f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2  |FINSEQ-1K18\<^bsub>(D)\<^esub> i"
      using finseq_6_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax GENEALG1M1 :: "Ty" ("Gene-SetGENEALG1M1" 70)
translations "Gene-SetGENEALG1M1" \<rightharpoonup> "non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"

abbreviation(input) GENEALG1K1("GA-SpaceGENEALG1K1  _ " [164]164) where
  "GA-SpaceGENEALG1K1 S \<equiv> UnionCARD-3K3 S"

mtheorem genealg1_cl_1:
  mlet "f be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1"
"cluster UnionCARD-3K3 f as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "UnionCARD-3K3 f be  non emptyXBOOLE-0V1"
  proof-
    have " not UnionCARD-3K3 f be emptyXBOOLE-0V1"
    proof-
      have "UnionCARD-3K3 f =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 f)"
        using card_3_def_4 sorry
      thus " not UnionCARD-3K3 f be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef genealg1_def_1 ("IndividualGENEALG1M2-of  _ " [70]70 ) where
  mlet "S be Gene-SetGENEALG1M1"
"mode IndividualGENEALG1M2-of S \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S means
  (\<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 S & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 S & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i)"
    proof-
      have " ex tVar2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S st lenFINSEQ-1K4 tVar2 =XBOOLE-0R4 lenFINSEQ-1K4 S & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domFINSEQ-1K5 tVar2 &  not tVar2 .FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inTARSKIR2 S .FUNCT-1K1 Lamb1"
        have A1: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 S) implies ( ex x be ElementSUBSET-1M1-of GA-SpaceGENEALG1K1 S st ?P(k,x))"
        proof-
          have " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 S) implies ( ex tVar1 be ElementSUBSET-1M1-of GA-SpaceGENEALG1K1 S st tVar1 inTARSKIR2 S .FUNCT-1K1 k)"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A2: "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 S)"
            then obtain k9 where 
              [ty]:"k9 be ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of domFINSEQ-1K5 S" and k9Def:"k9 = k"
              using finseq_1_def_3 sorry
            have "S .FUNCT-1K1 k9 <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            then obtain x where
              [ty]:"x be ElementSUBSET-1M1-of S .FUNCT-1K1 k" and 
              A3: "x inTARSKIR2 [#]SUBSET-1K2 (S .FUNCT-1K1 k)"
              using subset_1_th_4 sorry
            have "k inTARSKIR2 domFINSEQ-1K5 S"
              using A2 finseq_1_def_3 sorry
            then have "S .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 S"
              using funct_1_def_3 sorry
            then have "[#]SUBSET-1K2 (S .FUNCT-1K1 k) c=TARSKIR1 unionTARSKIK3 (rngFUNCT-1K2 S)"
              using zfmisc_1_th_74 sorry
            then have 
              [ty]:"x be ElementSUBSET-1M1-of GA-SpaceGENEALG1K1 S"
              using A3 card_3_def_4 sorry
            show " ex tVar1 be ElementSUBSET-1M1-of GA-SpaceGENEALG1K1 S st tVar1 inTARSKIR2 S .FUNCT-1K1 k"
            proof(rule bexI[of _ "x"])
              show "x inTARSKIR2 S .FUNCT-1K1 k"
                using A3 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain IT where
          [ty]:"IT be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S" and 
          A4: "domFINSEQ-1K5 IT =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 S) & ( for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 S) implies ?P(k,IT .FUNCT-1K1 k))"
          using finseq_1_sch_5 A1 sorry
        show " ex tVar2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S st lenFINSEQ-1K4 tVar2 =XBOOLE-0R4 lenFINSEQ-1K4 S & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domFINSEQ-1K5 tVar2 &  not tVar2 .FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i))"
        proof(rule bexI[of _ "IT"])
          show "lenFINSEQ-1K4 IT =XBOOLE-0R4 lenFINSEQ-1K4 S & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domFINSEQ-1K5 IT &  not IT .FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i))"
            using A4 finseq_1_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

(*begin*)
mdef genealg1_def_2 ("crossoverGENEALG1K2\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"
proof-
  (*coherence*)
    show "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_3 ("crossoverGENEALG1K3\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p2,p1,n1),n2)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p2,p1,n1),n2) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_4 ("crossoverGENEALG1K4\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_5 ("crossoverGENEALG1K5\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_6 ("crossoverGENEALG1K6\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

mdef genealg1_def_7 ("crossoverGENEALG1K7\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]164 ) where
  mlet "S be Gene-SetGENEALG1M1", "p1 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "p2 be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1", "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
"func crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) \<rightarrow> FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S equals
  crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5),crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
proof-
  (*coherence*)
    show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5),crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6) be FinSequenceFINSEQ-1M3-of GA-SpaceGENEALG1K1 S"
       sorry
qed "sorry"

(*begin*)
reserve S for "Gene-SetGENEALG1M1"
reserve p1, p2 for "IndividualGENEALG1M2-of S"
mtheorem genealg1_th_3:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) be IndividualGENEALG1M2-of S"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) be IndividualGENEALG1M2-of S"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
    proof-
      have A2: "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) +NAT-1K1 lenFINSEQ-1K4 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"
        using finseq_1_th_22 sorry
      have "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
      proof-
        show "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
        proof-
          have cases: "n <=XXREAL-0R1 lenFINSEQ-1K4 p1 or n >XXREAL-0R4 lenFINSEQ-1K4 p1"
             sorry
          have case1: "n <=XXREAL-0R1 lenFINSEQ-1K4 p1 implies lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
          proof(rule impI)
            assume A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 p1"
            have "lenFINSEQ-1K4 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) =HIDDENR1 lenFINSEQ-1K4 p2 -'NAT-DK9 n"
              using rfinseq_th_29 sorry
            also have "... = lenFINSEQ-1K4 S -'NAT-DK9 n"
              using genealg1_def_1 sorry
            also have "... = lenFINSEQ-1K4 p1 -'NAT-DK9 n"
              using genealg1_def_1 sorry
            also have "... = lenFINSEQ-1K4 p1 -XCMPLX-0K6 n"
              using A3 xreal_1_th_233 sorry
            finally have "lenFINSEQ-1K4 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) =HIDDENR1 lenFINSEQ-1K4 p1 -XCMPLX-0K6 n"
               sorry
            then have "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =HIDDENR1 n +XCMPLX-0K2 (lenFINSEQ-1K4 p1 -XCMPLX-0K6 n)"
              using A2 A3 finseq_1_th_59 sorry
            also have "... = lenFINSEQ-1K4 p1"
               sorry
            finally have "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =HIDDENR1 lenFINSEQ-1K4 p1"
               sorry
            thus "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
              using genealg1_def_1 sorry
          qed
          have case2: "n >XXREAL-0R4 lenFINSEQ-1K4 p1 implies lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
          proof(rule impI)
            assume A4: "n >XXREAL-0R4 lenFINSEQ-1K4 p1"
            have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n =FUNCT-1R1 p1  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,GA-SpaceGENEALG1K1 S)\<^esub> SegFINSEQ-1K2 n"
              using finseq_1_def_15 sorry
            then have A5: "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n =FINSEQ-1R1 p1"
              using A4 finseq_2_th_20 sorry
            have A6: "lenFINSEQ-1K4 p1 -XCMPLX-0K6 n <XXREAL-0R3 0NUMBERSK6"
              using A4 xreal_1_th_49 sorry
            have "lenFINSEQ-1K4 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) =HIDDENR1 lenFINSEQ-1K4 p2 -'NAT-DK9 n"
              using rfinseq_th_29 sorry
            also have "... = lenFINSEQ-1K4 S -'NAT-DK9 n"
              using genealg1_def_1 sorry
            also have "... = lenFINSEQ-1K4 p1 -'NAT-DK9 n"
              using genealg1_def_1 sorry
            also have "... = 0NUMBERSK6"
              using A6 xreal_0_def_2 sorry
            finally have "lenFINSEQ-1K4 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) =HIDDENR1 0NUMBERSK6"
               sorry
            thus "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
              using A2 A5 genealg1_def_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "lenFINSEQ-1K4 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
         sorry
    qed
    have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domFINSEQ-1K5 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)) implies (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
      assume A7: "i inTARSKIR2 domFINSEQ-1K5 (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n))"
      have "(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
      proof-
        show "(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) or ( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) & i =XBOOLE-0R4 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) +XCMPLX-0K2 k)"
            using A7 finseq_1_th_25 sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) implies (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
          proof(rule impI)
            assume A8: "i inTARSKIR2 domFINSEQ-1K5 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"
            have A9: "domFINSEQ-1K5 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) c=TARSKIR1 domFINSEQ-1K5 p1"
              using finseq_5_th_18 sorry
            have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n).FUNCT-1K1 i =HIDDENR1 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)/.PARTFUN1K7\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i"
              using A8 partfun1_def_6 sorry
            also have "... = p1 /.PARTFUN1K7\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i"
              using A8 finseq_4_th_70 sorry
            also have "... = p1 .FUNCT-1K1 i"
              using A8 A9 partfun1_def_6 sorry
            finally have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n).FUNCT-1K1 i =HIDDENR1 p1 .FUNCT-1K1 i"
               sorry
            then have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
              using A8 A9 genealg1_def_1 sorry
            thus "(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
              using A8 finseq_1_def_7 sorry
          qed
          have case2: "( ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) & i =XBOOLE-0R4 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) +XCMPLX-0K2 k) implies (crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
          proof(rule impI)
            assume " ex k be NatNAT-1M1 st k inTARSKIR2 domFINSEQ-1K5 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) & i =XBOOLE-0R4 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) +XCMPLX-0K2 k"
            then obtain k where
              [ty]:"k be NatNAT-1M1" and 
              A10: "k inTARSKIR2 domFINSEQ-1K5 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"and A11: "i =XBOOLE-0R4 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) +XCMPLX-0K2 k"
               sorry
            have 
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have A12: "n <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"
            proof-
              have "n >XXREAL-0R4 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) implies  False "
              proof(rule impI)
                have "n +NAT-1K1 k inTARSKIR2 domFINSEQ-1K5 p2"
                  using A10 finseq_5_th_26 sorry
                then have "n +NAT-1K1 k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p2)"
                  using finseq_1_def_3 sorry
                then have "n +NAT-1K1 k <=XXREAL-0R1 lenFINSEQ-1K4 p2"
                  using finseq_1_th_1 sorry
                then have "n +NAT-1K1 k <=XXREAL-0R1 lenFINSEQ-1K4 S"
                  using genealg1_def_1 sorry
                then have "n +NAT-1K1 k <=XXREAL-0R1 lenFINSEQ-1K4 p1"
                  using genealg1_def_1 sorry
                then have A13: "k <=XXREAL-0R1 lenFINSEQ-1K4 p1 -XCMPLX-0K6 n"
                  using xreal_1_th_19 sorry
                have "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n))"
                  using A10 finseq_1_def_3 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 k"
                  using finseq_1_th_1 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p1 -XCMPLX-0K6 n"
                  using A13 xxreal_0_th_2 sorry
                then have "\<one>\<^sub>M +NAT-1K1 n <=XXREAL-0R1 lenFINSEQ-1K4 p1"
                  using xreal_1_th_19 sorry
                then have A14: "n <=XXREAL-0R1 lenFINSEQ-1K4 p1 -XCMPLX-0K6 \<one>\<^sub>M"
                  using xreal_1_th_19 sorry
                have "lenFINSEQ-1K4 p1 <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                then have A15: "lenFINSEQ-1K4 p1 -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p1"
                  using xreal_1_th_20 sorry
                assume "n >XXREAL-0R4 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"
                thus " False "
                  using A14 A15 finseq_1_th_59 xxreal_0_th_2 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) <=XXREAL-0R1 n"
              using finseq_5_th_17 sorry
            then have A16: "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n) =XBOOLE-0R4 n"
              using A12 xxreal_0_th_1 sorry
            then have "n +NAT-1K1 k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 S)"
              using A1 A7 A11 finseq_1_def_3 sorry
            then have "n +NAT-1K1 k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p2)"
              using genealg1_def_1 sorry
            then have A17: "n +NAT-1K1 k inTARSKIR2 domFINSEQ-1K5 p2"
              using finseq_1_def_3 sorry
            have "(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i =HIDDENR1 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n).FUNCT-1K1 k"
              using A10 A11 finseq_1_def_7 sorry
            also have "... = (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)/.PARTFUN1K7\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> k"
              using A10 partfun1_def_6 sorry
            also have "... = p2 /.PARTFUN1K7\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (n +NAT-1K1 k)"
              using A10 finseq_5_th_27 sorry
            also have "... = p2 .FUNCT-1K1 (n +NAT-1K1 k)"
              using A17 partfun1_def_6 sorry
            finally have "(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i =HIDDENR1 p2 .FUNCT-1K1 (n +NAT-1K1 k)"
               sorry
            thus "(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
              using A11 A16 A17 genealg1_def_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)).FUNCT-1K1 i inTARSKIR2 S .FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) be IndividualGENEALG1M2-of S"
      using A1 genealg1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) GENEALG1K8("crossoverGENEALG1K8\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]164) where
  "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) \<equiv> crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n)"

mtheorem genealg1_add_1:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K2\<^bsub>(S)\<^esub>(p1,p2,n) be IndividualGENEALG1M2-of S"
    using genealg1_th_3 sorry
qed "sorry"

mtheorem genealg1_th_4:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6) =FINSEQ-1R1 p2"
proof-
  have " for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6) =FINSEQ-1R1 p2"
  proof(rule ballI,rule ballI,rule ballI)
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6) =HIDDENR1 p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (0NUMBERSK6)"
      using finseq_1_th_34 sorry
    also have "... = p2"
      using finseq_5_th_28 sorry
    finally have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6) =HIDDENR1 p2"
       sorry
    thus "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6) =FINSEQ-1R1 p2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_5:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) =FINSEQ-1R1 p1"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) =FINSEQ-1R1 p1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    then have "n >=XXREAL-0R2 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    then have A2: "n >=XXREAL-0R2 lenFINSEQ-1K4 p2"
      using genealg1_def_1 sorry
    have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) =HIDDENR1 p1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n)"
      using A1 finseq_1_th_58 sorry
    also have "... = p1 ^FINSEQ-1K8 {}XBOOLE-0K1"
      using A2 finseq_5_th_32 sorry
    also have "... = p1"
      using finseq_1_th_34 sorry
    finally have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) =HIDDENR1 p1"
       sorry
    thus "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n) =FINSEQ-1R1 p1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem genealg1_th_6:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) be IndividualGENEALG1M2-of S"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) be IndividualGENEALG1M2-of S"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    obtain q1 q2 where 
      [ty]:"q1 be IndividualGENEALG1M2-of S" and q1Def:"q1 = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)" and
      [ty]:"q2 be IndividualGENEALG1M2-of S" and q2Def:"q2 = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1)"
       sorry
    have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(q1,q2,n2) be IndividualGENEALG1M2-of S"
       sorry
    thus "crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) be IndividualGENEALG1M2-of S"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) GENEALG1K9("crossoverGENEALG1K9\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ ')" [0,0,0,0,0]164) where
  "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) \<equiv> crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"

mtheorem genealg1_add_2:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K3\<^bsub>(S)\<^esub>(p1,p2,n1,n2) be IndividualGENEALG1M2-of S"
    using genealg1_th_6 sorry
qed "sorry"

mtheorem genealg1_th_7:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6),n)"
      using genealg1_th_4 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
      using genealg1_th_4 sorry
    finally have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
       sorry
    thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_8:
" for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
proof-
  have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    obtain q1 where 
      [ty]:"q1 be IndividualGENEALG1M2-of S" and q1Def:"q1 = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n)"
       sorry
    obtain q2 where 
      [ty]:"q2 be IndividualGENEALG1M2-of S" and q2Def:"q2 = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
       sorry
    have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n,0NUMBERSK6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(q1,q2,0NUMBERSK6)"
       sorry
    also have "... = q2"
      using genealg1_th_4 sorry
    finally have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n,0NUMBERSK6) =HIDDENR1 q2"
       sorry
    thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_9:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    then have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    then have A2: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
      using genealg1_def_1 sorry
    have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n2)"
      using A1 genealg1_th_5 sorry
    thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
      using A2 genealg1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_10:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    then have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    then have A1: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
      using genealg1_def_1 sorry
    have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n2)"
       sorry
    thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
      using A1 genealg1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_11:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 p1"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 p1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      and A2: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
      using A1 genealg1_th_9 sorry
    thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 p1"
      using A2 genealg1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_12:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n1) =FINSEQ-1R1 p1"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n1) =FINSEQ-1R1 p1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
    proof-
      have "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
      proof-
        show "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
        proof-
          have cases: "n1 <=XXREAL-0R1 lenFINSEQ-1K4 p2 or n1 >XXREAL-0R4 lenFINSEQ-1K4 p2"
             sorry
          have case1: "n1 <=XXREAL-0R1 lenFINSEQ-1K4 p2 implies (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
          proof(rule impI)
            assume "n1 <=XXREAL-0R1 lenFINSEQ-1K4 p2"
            then have "lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =XBOOLE-0R4 n1"
              using finseq_1_th_59 sorry
            thus "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
              using finseq_5_th_37 sorry
          qed
          have case2: "n1 >XXREAL-0R4 lenFINSEQ-1K4 p2 implies (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
          proof(rule impI)
            assume "n1 >XXREAL-0R4 lenFINSEQ-1K4 p2"
            then have A2: "n1 >XXREAL-0R4 lenFINSEQ-1K4 S"
              using genealg1_def_1 sorry
            then have "n1 >XXREAL-0R4 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1))"
              using genealg1_def_1 sorry
            then have A3: "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 {}XBOOLE-0K1"
              using finseq_5_th_32 sorry
            have "n1 >XXREAL-0R4 lenFINSEQ-1K4 p1"
              using A2 genealg1_def_1 sorry
            thus "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
              using A3 finseq_5_th_32 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
         sorry
    qed
    have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
    proof-
      have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
      proof-
        show "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
        proof-
          have cases: "n1 <=XXREAL-0R1 lenFINSEQ-1K4 p1 or n1 >XXREAL-0R4 lenFINSEQ-1K4 p1"
             sorry
          have case1: "n1 <=XXREAL-0R1 lenFINSEQ-1K4 p1 implies (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
          proof(rule impI)
            assume "n1 <=XXREAL-0R1 lenFINSEQ-1K4 p1"
            then have "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =XBOOLE-0R4 n1"
              using finseq_1_th_59 sorry
            thus "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
              using finseq_5_th_23 sorry
          qed
          have case2: "n1 >XXREAL-0R4 lenFINSEQ-1K4 p1 implies (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
          proof(rule impI)
            assume A4: "n1 >XXREAL-0R4 lenFINSEQ-1K4 p1"
            then have A5: "n1 >XXREAL-0R4 lenFINSEQ-1K4 S"
              using genealg1_def_1 sorry
            then have A6: "n1 >XXREAL-0R4 lenFINSEQ-1K4 p2"
              using genealg1_def_1 sorry
            have "n1 >XXREAL-0R4 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
              using A5 genealg1_def_1 sorry
            then have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)"
              using finseq_1_th_58 sorry
            also have "... = p1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)"
              using A4 finseq_1_th_58 sorry
            also have "... = p1 ^FINSEQ-1K8 {}XBOOLE-0K1"
              using A6 finseq_5_th_32 sorry
            also have "... = p1"
              using finseq_1_th_34 sorry
            also have "... = p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
              using A4 finseq_1_th_58 sorry
            finally have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
               sorry
            thus "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
         sorry
    qed
    thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n1) =FINSEQ-1R1 p1"
      using A1 rfinseq_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_13:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "lenFINSEQ-1K4 p1 =XBOOLE-0R4 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    have "lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) =XBOOLE-0R4 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2))"
       sorry
    then have A2: "lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    have A3: "lenFINSEQ-1K4 p2 =XBOOLE-0R4 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    have "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) =XBOOLE-0R4 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))"
       sorry
    then have A4: "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) =XBOOLE-0R4 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
    proof-
      show "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
      proof-
        have cases: "(n1 >=XXREAL-0R2 n2 & n2 >XXREAL-0R4 0NUMBERSK6 or n1 <XXREAL-0R3 n2 & n2 >XXREAL-0R4 0NUMBERSK6) or n2 =XBOOLE-0R4 0NUMBERSK6"
          using nat_1_th_3 sorry
        have case1: "n1 >=XXREAL-0R2 n2 & n2 >XXREAL-0R4 0NUMBERSK6 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
        proof(rule impI)
          assume A5: "n1 >=XXREAL-0R2 n2 & n2 >XXREAL-0R4 0NUMBERSK6"
          have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
          proof-
            show "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
            proof-
              have cases: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 or n1 <XXREAL-0R3 lenFINSEQ-1K4 p1"
                 sorry
              have case1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
              proof(rule impI)
                assume A6: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
                then have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p2"
                  using A1 A3 finseq_1_th_58 sorry
                then have A7: "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p2 ^FINSEQ-1K8 {}XBOOLE-0K1"
                  using A6 finseq_5_th_32 sorry
                also have "... = p2"
                  using finseq_1_th_34 sorry
                finally have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p2"
                   sorry
                have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1"
                  using A6 finseq_1_th_58 sorry
                then have A8: "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p1 ^FINSEQ-1K8 {}XBOOLE-0K1"
                  using A1 A3 A6 finseq_5_th_32 sorry
                also have "... = p1"
                  using finseq_1_th_34 sorry
                finally have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p1"
                   sorry
                have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  using A1 A4 A6 finseq_1_th_58 sorry
                then have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1) =HIDDENR1 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))^FINSEQ-1K8 {}XBOOLE-0K1"
                  using A1 A2 A6 finseq_5_th_32 sorry
                also have "... = p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  using finseq_1_th_34 sorry
                finally have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1) =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                   sorry
                thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
                  using A8 A7 sorry
              qed
              have case2: "n1 <XXREAL-0R3 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
              proof(rule impI)
                assume A9: "n1 <XXREAL-0R3 lenFINSEQ-1K4 p1"
                then have "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =XBOOLE-0R4 n1"
                  using finseq_1_th_59 sorry
                then have A10: "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 =HIDDENR1 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2"
                  using A5 finseq_5_th_22 sorry
                also have "... = p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2"
                  using A5 finseq_5_th_77 sorry
                finally have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2"
                   sorry
                have "n1 <=XXREAL-0R1 lenFINSEQ-1K4 p2"
                  using A3 A9 genealg1_def_1 sorry
                then have "n2 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)"
                  using A5 finseq_1_th_59 sorry
                then have A11: "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> ((p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))"
                  using A10 genealg1_th_1 sorry
                also have "... = (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)"
                  using finseq_1_th_32 sorry
                finally have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =HIDDENR1 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)"
                   sorry
                have "lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) =XBOOLE-0R4 n2"
                  using A1 A3 A5 A9 finseq_1_th_59 xxreal_0_th_2 sorry
                then obtain i where
                  [ty]:"i be NatNAT-1M1" and 
                  A12: "lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) +XCMPLX-0K2 i =XBOOLE-0R4 n1"
                  using A5 nat_1_th_10 sorry
                have 
                  [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have A13: "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) =XBOOLE-0R4 n2"
                  using A5 A9 finseq_1_th_59 xxreal_0_th_2 sorry
                then have A14: "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) +NAT-1K1 i =XBOOLE-0R4 n1"
                  using A1 A3 A5 A9 A12 finseq_1_th_59 xxreal_0_th_2 sorry
                then have "i =XBOOLE-0R4 n1 -XCMPLX-0K6 n2"
                  using A13 sorry
                then have A15: "i =XBOOLE-0R4 n1 -'NAT-DK9 n2"
                  using A5 xreal_1_th_233 sorry
                have A16: "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i"
                  using A14 genealg1_th_2 sorry
                also have "... = p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  using A15 finseq_5_th_80 sorry
                finally have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                   sorry
                have "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i"
                  using A12 finseq_5_th_36 sorry
                also have "... = p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (n2 +NAT-1K1 i)"
                  using finseq_6_th_81 sorry
                also have "... = p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
                  using A1 A3 A5 A9 A12 finseq_1_th_59 xxreal_0_th_2 sorry
                finally have "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
                   sorry
                thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
                  using A11 A16 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
             sorry
        qed
        have case2: "n1 <XXREAL-0R3 n2 & n2 >XXREAL-0R4 0NUMBERSK6 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
        proof(rule impI)
          assume A17: "n1 <XXREAL-0R3 n2 & n2 >XXREAL-0R4 0NUMBERSK6"
          have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
          proof-
            show "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
            proof-
              have cases: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 or n1 <XXREAL-0R3 lenFINSEQ-1K4 p1"
                 sorry
              have case1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
              proof(rule impI)
                assume A18: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
                then have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
                  using A17 xxreal_0_th_2 sorry
                then have A19: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
                  using A3 genealg1_def_1 sorry
                have A20: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
                  using A3 A18 genealg1_def_1 sorry
                then have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p2"
                  using finseq_1_th_58 sorry
                then have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p2 ^FINSEQ-1K8 {}XBOOLE-0K1"
                  using A18 finseq_5_th_32 sorry
                also have "... = p2"
                  using finseq_1_th_34 sorry
                finally have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p2"
                   sorry
                then have A21: "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 =FINSEQ-1R1 {}XBOOLE-0K1"
                  using A19 finseq_5_th_32 sorry
                have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 =FINSEQ-1R1 p1"
                  using A17 A18 finseq_1_th_58 xxreal_0_th_2 sorry
                then have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) =HIDDENR1 p1 ^FINSEQ-1K8 {}XBOOLE-0K1"
                  using A19 finseq_5_th_32 sorry
                also have "... = p1"
                  using finseq_1_th_34 sorry
                finally have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) =HIDDENR1 p1"
                   sorry
                then have A22: "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1"
                  using A18 finseq_1_th_58 sorry
                have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 =FINSEQ-1R1 p2"
                  using A19 finseq_1_th_58 sorry
                then have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) =HIDDENR1 p2 ^FINSEQ-1K8 {}XBOOLE-0K1"
                  using A17 A18 finseq_5_th_32 xxreal_0_th_2 sorry
                also have "... = p2"
                  using finseq_1_th_34 sorry
                finally have "p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) =HIDDENR1 p2"
                   sorry
                then have A23: "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 {}XBOOLE-0K1"
                  using A20 finseq_5_th_32 sorry
                have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =FINSEQ-1R1 p1"
                  using A18 finseq_1_th_58 sorry
                then have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p1 ^FINSEQ-1K8 {}XBOOLE-0K1"
                  using A20 finseq_5_th_32 sorry
                also have "... = p1"
                  using finseq_1_th_34 sorry
                finally have "p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =HIDDENR1 p1"
                   sorry
                thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
                  using A17 A18 A21 A22 A23 finseq_1_th_58 xxreal_0_th_2 sorry
              qed
              have case2: "n1 <XXREAL-0R3 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
              proof(rule impI)
                assume A24: "n1 <XXREAL-0R3 lenFINSEQ-1K4 p1"
                have "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                proof-
                  have "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  proof-
                    show "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                    proof-
                      have cases: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 or n2 <XXREAL-0R3 lenFINSEQ-1K4 p1"
                         sorry
                      have case1: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                      proof(rule impI)
                        assume "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
                        thus "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                          using A24 finseq_1_th_58 sorry
                      qed
                      have case2: "n2 <XXREAL-0R3 lenFINSEQ-1K4 p1 implies n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                      proof(rule impI)
                        assume "n2 <XXREAL-0R3 lenFINSEQ-1K4 p1"
                        thus "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                          using A17 finseq_1_th_59 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                     sorry
                qed
                then have A25: "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
                  using finseq_5_th_22 sorry
                also have "... = p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
                  using A17 finseq_5_th_77 sorry
                finally have "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1"
                   sorry
                have A26: "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =XBOOLE-0R4 n1"
                  using A24 finseq_1_th_59 sorry
                then obtain i where
                  [ty]:"i be NatNAT-1M1" and 
                  A27: "lenFINSEQ-1K4 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) +XCMPLX-0K2 i =XBOOLE-0R4 n2"
                  using A17 nat_1_th_10 sorry
                have 
                  [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have A28: "(p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 =FINSEQ-1R1 p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i"
                  using A27 genealg1_th_2 sorry
                have "lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) =XBOOLE-0R4 n1"
                  using A1 A3 A24 finseq_1_th_59 sorry
                then have "lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) +NAT-1K1 i =XBOOLE-0R4 n2"
                  using A24 A27 finseq_1_th_59 sorry
                then have A29: "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =HIDDENR1 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i)^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> ((p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i)"
                  using A28 finseq_5_th_36 sorry
                also have "... = (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i)^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (n1 +NAT-1K1 i))"
                  using finseq_6_th_81 sorry
                also have "... = (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i)^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  using A24 A27 finseq_1_th_59 sorry
                finally have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =HIDDENR1 (p1  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i)^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                   sorry
                have A30: "i =XBOOLE-0R4 n2 -XCMPLX-0K6 n1"
                  using A26 A27 sorry
                have "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                proof-
                  have "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  proof-
                    show "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                    proof-
                      have cases: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2 or n2 <XXREAL-0R3 lenFINSEQ-1K4 p2"
                         sorry
                      have case1: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2 implies n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                      proof(rule impI)
                        assume "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
                        thus "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                          using A1 A3 A24 finseq_1_th_58 sorry
                      qed
                      have case2: "n2 <XXREAL-0R3 lenFINSEQ-1K4 p2 implies n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                      proof(rule impI)
                        assume "n2 <XXREAL-0R3 lenFINSEQ-1K4 p2"
                        thus "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                          using A17 finseq_1_th_59 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus "n1 <=XXREAL-0R1 lenFINSEQ-1K4 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                     sorry
                qed
                then have "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 (p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1)^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  using genealg1_th_1 sorry
                also have "... = (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (n2 -'NAT-DK9 n1) ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  using finseq_5_th_80 sorry
                also have "... = (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                  using A17 A30 xreal_1_th_233 sorry
                finally have "(p2  |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2 ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2))/^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1 =HIDDENR1 (p2 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n1) |FINSEQ-1K18\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> i ^FINSEQ-1K9\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> (p1 /^RFINSEQK2\<^bsub>(GA-SpaceGENEALG1K1 S)\<^esub> n2)"
                   sorry
                thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
                  using A29 A25 finseq_1_th_32 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
             sorry
        qed
        have case3: "n2 =XBOOLE-0R4 0NUMBERSK6 implies crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
        proof(rule impI)
          assume A31: "n2 =XBOOLE-0R4 0NUMBERSK6"
          then have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1)"
            using genealg1_th_8 sorry
          also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n1)"
            using genealg1_th_7 sorry
          finally have "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n1)"
             sorry
          thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
            using A31 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem genealg1_th_14:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) be IndividualGENEALG1M2-of S"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) be IndividualGENEALG1M2-of S"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    obtain q1 q2 where 
      [ty]:"q1 be IndividualGENEALG1M2-of S" and q1Def:"q1 = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)" and
      [ty]:"q2 be IndividualGENEALG1M2-of S" and q2Def:"q2 = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
       sorry
    have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(q1,q2,n3) be IndividualGENEALG1M2-of S"
       sorry
    thus "crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) be IndividualGENEALG1M2-of S"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) GENEALG1K10("crossoverGENEALG1K10\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164) where
  "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) \<equiv> crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"

mtheorem genealg1_add_3:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K4\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) be IndividualGENEALG1M2-of S"
    using genealg1_th_14 sorry
qed "sorry"

mtheorem genealg1_th_15:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3) & (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n2),n3)"
      using genealg1_th_7 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),n3)"
      using genealg1_th_7 sorry
    finally have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),n3)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)"
       sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6),n3)"
      using genealg1_th_8 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),n3)"
      using genealg1_th_8 sorry
    finally have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),n3)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)"
       sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),0NUMBERSK6)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
      using genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_16:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3) & (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,0NUMBERSK6),n3)"
      using genealg1_th_12 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
      using genealg1_th_12 sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),0NUMBERSK6)"
      using genealg1_th_8 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
      using genealg1_th_4 sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),0NUMBERSK6)"
      using genealg1_th_7 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
      using genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_17:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
proof-
  have " for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
  proof(rule ballI,rule ballI,rule ballI)
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6),p2,0NUMBERSK6)"
      using genealg1_th_12 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
      using genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_18:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    then have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    then have A2: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
      using genealg1_def_1 sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3)"
      using A1 genealg1_th_9 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n3)"
      using A2 genealg1_th_9 sorry
    finally have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n3)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_19:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    then have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    then have A2: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
      using genealg1_def_1 sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3)"
      using A1 genealg1_th_10 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n3)"
      using A2 genealg1_th_10 sorry
    finally have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n3)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_20:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    then have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
      using genealg1_def_1 sorry
    then have A1: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
      using genealg1_def_1 sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
      using A1 genealg1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_21:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      and A2: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
      using A1 genealg1_th_18 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
      using A2 genealg1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_22:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      and A2: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
      using A1 genealg1_th_18 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
      using A2 genealg1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_23:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      and A2: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
      using A1 genealg1_th_19 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
      using A2 genealg1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_24:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 p1"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 p1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      and A2: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
      using A1 genealg1_th_21 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 p1"
      using A2 genealg1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_25:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    let ?q1 = "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
    let ?q2 = "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1)"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n3)"
      using genealg1_th_13 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n1),n3)"
      using genealg1_th_13 sorry
    finally have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n1),n3)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3)"
       sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n2,n3)"
       sorry
    also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n3,n2)"
      using genealg1_th_13 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n2)"
       sorry
    finally have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n2)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_26:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2)"
      using genealg1_th_25 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2)"
      using genealg1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_27:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3) & (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2) & crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n1),n3)"
      using genealg1_th_12 sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
      using genealg1_th_12 sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1) =HIDDENR1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n2)"
      using genealg1_th_25 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n1),n2)"
      using genealg1_th_12 sorry
    finally have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n1),n2)"
       sorry
    thus "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
      using genealg1_th_12 sorry
    have "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2) =HIDDENR1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n2,n1)"
      using genealg1_th_26 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n2),n1)"
      using genealg1_th_12 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
      using genealg1_th_12 sorry
    finally show "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem genealg1_th_28:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) be IndividualGENEALG1M2-of S"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) be IndividualGENEALG1M2-of S"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    obtain q1 q2 where 
      [ty]:"q1 be IndividualGENEALG1M2-of S" and q1Def:"q1 = crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)" and
      [ty]:"q2 be IndividualGENEALG1M2-of S" and q2Def:"q2 = crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3)"
       sorry
    have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(q1,q2,n4) be IndividualGENEALG1M2-of S"
       sorry
    thus "crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) be IndividualGENEALG1M2-of S"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) GENEALG1K11("crossoverGENEALG1K11\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164) where
  "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) \<equiv> crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4)"

mtheorem genealg1_add_4:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K5\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) be IndividualGENEALG1M2-of S"
    using genealg1_th_28 sorry
qed "sorry"

mtheorem genealg1_th_29:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n2,n3),n4)"
      using genealg1_th_15 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),n4)"
      using genealg1_th_15 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),n4)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6,n3),n4)"
      using genealg1_th_15 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),n4)"
      using genealg1_th_15 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),n4)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,0NUMBERSK6),n4)"
      using genealg1_th_15 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),n4)"
      using genealg1_th_15 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),n4)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),0NUMBERSK6)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3)"
      using genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_30:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n3,n4)"
      using genealg1_th_29 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
      using genealg1_th_15 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,0NUMBERSK6,n4)"
      using genealg1_th_29 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)"
      using genealg1_th_15 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,0NUMBERSK6)"
      using genealg1_th_29 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
      using genealg1_th_15 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,0NUMBERSK6)"
      using genealg1_th_29 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
      using genealg1_th_15 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6,n4)"
      using genealg1_th_29 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)"
      using genealg1_th_15 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,0NUMBERSK6)"
      using genealg1_th_29 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
      using genealg1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_31:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6)"
      using genealg1_th_30 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1)"
      using genealg1_th_8 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2)"
      using genealg1_th_30 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2)"
      using genealg1_th_7 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n3)"
      using genealg1_th_30 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3)"
      using genealg1_th_7 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n4)"
      using genealg1_th_30 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4)"
      using genealg1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_32:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p1"
proof-
  have " for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p1"
  proof(rule ballI,rule ballI,rule ballI)
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6)"
      using genealg1_th_31 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p1"
      using genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_33:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (( not (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) &  not (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) &  not (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) &  not (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
    proof(rule impI)
      assume "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A2: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
        using A2 genealg1_th_5 sorry
    qed
    have A3: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)"
    proof(rule impI)
      assume A4: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A5: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using A4 genealg1_th_19 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n4)"
        using A5 genealg1_th_19 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n4)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)"
         sorry
    qed
    have A6: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)"
    proof(rule impI)
      assume A7: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A8: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using A7 genealg1_th_20 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n4)"
        using A8 genealg1_th_20 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n4)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)"
         sorry
    qed
    have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
    proof(rule impI)
      assume A9: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A10: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using A9 genealg1_th_18 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n4)"
        using A10 genealg1_th_18 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n4)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
         sorry
    qed
    thus "(( not (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) &  not (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) &  not (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) &  not (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
      using A3 A6 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_34:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((( not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) &  not ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)"
    proof(rule impMI ,rule impI)
      assume A2: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A3: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
        using A2 genealg1_th_33 sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)"
        using A3 genealg1_th_19 sorry
    qed
    have A4: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
    proof(rule impMI ,rule impI)
      assume A5: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A6: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
        using A5 genealg1_th_33 sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
        using A6 genealg1_th_20 sorry
    qed
    have A7: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
    proof(rule impMI ,rule impI)
      assume A8: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A9: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)"
        using A8 genealg1_th_33 sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
        using A9 genealg1_th_20 sorry
    qed
    have A10: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
    proof(rule impMI ,rule impI)
      assume A11: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A12: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)"
        using A11 genealg1_th_33 sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
        using A12 genealg1_th_20 sorry
    qed
    have A13: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)"
    proof(rule impMI ,rule impI)
      assume A14: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A15: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)"
        using A14 genealg1_th_33 sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)"
        using A15 genealg1_th_19 sorry
    qed
    have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
    proof(rule impMI ,rule impI)
      assume A16: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A17: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
        using A16 genealg1_th_33 sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
        using A17 genealg1_th_18 sorry
    qed
    thus "(((( not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) &  not ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
      using A1 A4 A13 A10 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_35:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (( not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)"
    proof(rule impMI ,rule impI)
      assume A2: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A3: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
        using A2 genealg1_th_34 sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)"
        using A3 genealg1_th_9 sorry
    qed
    have A4: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
    proof(rule impMI ,rule impI)
      assume A5: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A6: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)"
        using A5 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n2)"
        using genealg1_th_13 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n2)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
        using A6 genealg1_th_9 sorry
    qed
    have A7: "(n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
    proof(rule impMI ,rule impI)
      assume A8: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A9: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)"
        using A8 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n1)"
        using genealg1_th_13 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n1)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
        using A9 genealg1_th_9 sorry
    qed
    have "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
    proof(rule impMI ,rule impI)
      assume A10: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A11: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
        using A10 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n3)"
        using genealg1_th_13 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n3)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
        using A11 genealg1_th_9 sorry
    qed
    thus "(( not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
      using A1 A4 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_36:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 p1"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 p1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      and A2: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)"
      using A1 genealg1_th_35 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 p1"
      using A2 genealg1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_37:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((((((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n3) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((((((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n3) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2,n1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n3)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n3,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n3)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q1,?q2,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q2,?q1,n4),n3)"
         sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q1,?q2,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q2,?q1,n4),n3)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n3)"
         sorry
    qed
    have A2: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
      using genealg1_th_25 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n2),n4)"
      using genealg1_th_25 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n2),n4)"
       sorry
    have A3: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n1),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n1)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n1)"
         sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n1)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1)"
         sorry
    qed
    have A4: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3,n2)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n2),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n2,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n2)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4),n2)"
         sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4),n2)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n4,n3),n2)"
        using genealg1_th_25 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n4,n3),n2)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3,n2)"
         sorry
    qed
    have A5: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2,n1)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n2)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n2)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n1)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n4),n1)"
         sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n4),n1)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n4,n3,n2),n1)"
        using genealg1_th_26 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n4,n3,n2),n1)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2,n1)"
         sorry
    qed
    have A6: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4,n3)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n1)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n3,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n3)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n4),n3)"
         sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n4),n3)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4,n3)"
         sorry
    qed
    have A7: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n1),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n1)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n1)"
         sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n1)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n4,n2,n3),n1)"
        using genealg1_th_26 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n4,n2,n3),n1)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1)"
         sorry
    qed
    have A8: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n2)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n2),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n2,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n2)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q1,?q2,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q2,?q1,n4),n2)"
         sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q1,?q2,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q2,?q1,n4),n2)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n2)"
         sorry
    qed
    have A9: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4,n1)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n2)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n2)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n1)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n4),n1)"
         sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n4),n1)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4,n1)"
         sorry
    qed
    have A10: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1,n3)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n1)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n1)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n3,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n3)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n4),n3)"
         sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n4),n3)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n4,n1),n3)"
        using genealg1_th_25 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n4,n1),n3)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1,n3)"
         sorry
    qed
    have A11: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2,n1)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n2)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n2)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n1)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n4),n1)"
         sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n4),n1)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n4,n2),n1)"
        using genealg1_th_25 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n4,n2),n1)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2,n1)"
         sorry
    qed
    have A12: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
      using genealg1_th_26 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
      using genealg1_th_26 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
      using genealg1_th_25 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1),n4)"
      using genealg1_th_25 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1),n4)"
       sorry
    have A13: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1,n2)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n1)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n1)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n2),n4)"
        using genealg1_th_26 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n2,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n2)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n1,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n4),n2)"
         sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n1,n4),n2)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n4,n1),n2)"
        using genealg1_th_25 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n4,n1),n2)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1,n2)"
         sorry
    qed
    have A14: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3,n1)"
    proof-
      let ?q2 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)"
      let ?q1 = "crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
      have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n1),n4)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n4)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n4,n1)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n1)"
         sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n1)"
        using genealg1_th_25 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n4,n3),n1)"
        using genealg1_th_25 sorry
      finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n4,n3),n1)"
         sorry
      thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3,n1)"
         sorry
    qed
    have A15: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
      using genealg1_th_25 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
      using genealg1_th_25 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n4)"
      using genealg1_th_25 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
      using genealg1_th_25 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3),n4)"
      using genealg1_th_25 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n1),n4)"
      using genealg1_th_25 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n1),n4)"
       sorry
    thus "((((((((((((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n3) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n3,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n4,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n4,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n1,n2)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n2,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n3,n2,n1)"
      using A2 A15 A1 A8 A4 A6 A3 A10 A14 A12 A9 A13 A11 A7 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_38:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4) & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n1,n3),n4)"
      using genealg1_th_27 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3),n4)"
      using genealg1_th_27 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3),n4)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n1),n4)"
      using genealg1_th_27 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n4)"
      using genealg1_th_27 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n4)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1) =HIDDENR1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n2,n3)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n1,n2),n3)"
      using genealg1_th_27 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n3)"
      using genealg1_th_27 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n3)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n2),n4)"
      using genealg1_th_27 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n4)"
      using genealg1_th_27 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n4) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n4)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n4) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n2) =HIDDENR1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n3)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n2),n3)"
      using genealg1_th_27 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n3)"
      using genealg1_th_27 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n2) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n3)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
       sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n3) =HIDDENR1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n3,n2)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n3),n2)"
      using genealg1_th_27 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n2)"
      using genealg1_th_27 sorry
    finally have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n3) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n2)"
       sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_39:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n3) =FINSEQ-1R1 p1 & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n2) =FINSEQ-1R1 p1) & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n1) =FINSEQ-1R1 p1"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n3) =FINSEQ-1R1 p1 & (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n2) =FINSEQ-1R1 p1 & crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n1) =FINSEQ-1R1 p1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n3) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n3)"
      using genealg1_th_38 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n3) =FINSEQ-1R1 p1"
      using genealg1_th_12 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n2) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n2)"
      using genealg1_th_38 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n2) =FINSEQ-1R1 p1"
      using genealg1_th_12 sorry
    have "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n1) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n2)"
      using genealg1_th_38 sorry
    thus "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n2,n1) =FINSEQ-1R1 p1"
      using genealg1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem genealg1_th_40:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) be IndividualGENEALG1M2-of S"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) be IndividualGENEALG1M2-of S"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    obtain q1 q2 where 
      [ty]:"q1 be IndividualGENEALG1M2-of S" and q1Def:"q1 = crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4)" and
      [ty]:"q2 be IndividualGENEALG1M2-of S" and q2Def:"q2 = crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4)"
       sorry
    have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(q1,q2,n5) be IndividualGENEALG1M2-of S"
       sorry
    thus "crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) be IndividualGENEALG1M2-of S"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) GENEALG1K12("crossoverGENEALG1K12\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164) where
  "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) \<equiv> crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5)"

mtheorem genealg1_add_5:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K6\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) be IndividualGENEALG1M2-of S"
    using genealg1_th_40 sorry
qed "sorry"

mtheorem genealg1_th_41:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),0NUMBERSK6)"
       sorry
    have A2: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6,n3,n4),n5)"
      using genealg1_th_29 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),n5)"
      using genealg1_th_29 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),n5)"
       sorry
    have A3: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,0NUMBERSK6),n5)"
      using genealg1_th_29 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),n5)"
      using genealg1_th_29 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),n5)"
       sorry
    have A4: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,0NUMBERSK6,n4),n5)"
      using genealg1_th_29 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4),n5)"
      using genealg1_th_29 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4),n5)"
       sorry
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n2,n3,n4),n5)"
      using genealg1_th_29 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),n5)"
      using genealg1_th_29 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),n5)"
       sorry
    thus "(((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4)"
      using A2 A4 A3 A1 genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_42:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),0NUMBERSK6) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),0NUMBERSK6)"
      using genealg1_th_29 sorry
    have A2: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4),0NUMBERSK6) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),0NUMBERSK6)"
      using genealg1_th_29 sorry
    have A3: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6,n3,0NUMBERSK6),n5)"
      using genealg1_th_30 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n5)"
      using genealg1_th_30 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n5)"
       sorry
    have A4: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6,0NUMBERSK6,n4),n5)"
      using genealg1_th_30 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4),n5)"
      using genealg1_th_30 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4),n5)"
       sorry
    have A5: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,0NUMBERSK6,0NUMBERSK6),n5)"
      using genealg1_th_30 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n5)"
      using genealg1_th_30 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n5)"
       sorry
    have A6: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n2,n3,0NUMBERSK6),n5)"
      using genealg1_th_30 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n5)"
      using genealg1_th_30 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n5)"
       sorry
    have A7: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n2,0NUMBERSK6,n4),n5)"
      using genealg1_th_30 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4),n5)"
      using genealg1_th_30 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4),n5)"
       sorry
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,0NUMBERSK6,n3,n4),n5)"
      using genealg1_th_30 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4),n5)"
      using genealg1_th_30 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4),n5)"
       sorry
    thus "((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
      using A7 A6 A4 A3 A1 A5 A2 genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_43:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4),0NUMBERSK6) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4),0NUMBERSK6)"
      using genealg1_th_30 sorry
    have A2: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),0NUMBERSK6) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4),0NUMBERSK6)"
      using genealg1_th_30 sorry
    have A3: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6),n5)"
      using genealg1_th_31 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),n5)"
      using genealg1_th_31 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),n5)"
       sorry
    have A4: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),0NUMBERSK6) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),0NUMBERSK6)"
      using genealg1_th_30 sorry
    have A5: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6),n5)"
      using genealg1_th_31 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),n5)"
      using genealg1_th_31 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),n5)"
       sorry
    have A6: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6),n5)"
      using genealg1_th_31 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),n5)"
      using genealg1_th_31 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),n5)"
       sorry
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4),n5)"
      using genealg1_th_31 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4),n5)"
      using genealg1_th_31 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4),n5)"
       sorry
    thus "((((((((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2)"
      using A3 A6 A1 A5 A2 A4 genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_44:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),0NUMBERSK6) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),0NUMBERSK6)"
      using genealg1_th_31 sorry
    have A2: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),0NUMBERSK6)"
      using genealg1_th_31 sorry
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6),n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4),0NUMBERSK6)"
      using genealg1_th_31 genealg1_th_32 sorry
    thus "(((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,n4,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,n3,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
      using A1 A2 genealg1_th_4 genealg1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_45:
" for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
proof-
  have " for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
  proof(rule ballI,rule ballI,rule ballI)
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6),p2,0NUMBERSK6)"
      using genealg1_th_32 sorry
    thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6,0NUMBERSK6) =FINSEQ-1R1 p2"
      using genealg1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_46:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5))) & (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((( not (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)) &  not (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5))) &  not (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5))) &  not (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5))) &  not (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4)"
    proof(rule impI)
      assume "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A2: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4)"
        using A2 genealg1_th_5 sorry
    qed
    have A3: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5)"
    proof(rule impI)
      assume A4: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A5: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A4 genealg1_th_33 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4),n5)"
        using A5 genealg1_th_33 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5)"
         sorry
    qed
    have A6: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5)"
    proof(rule impI)
      assume A7: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A8: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A7 genealg1_th_33 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n5)"
        using A8 genealg1_th_33 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5)"
         sorry
    qed
    have A9: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5)"
    proof(rule impI)
      assume A10: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A11: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A10 genealg1_th_33 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4),n5)"
        using A11 genealg1_th_33 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5)"
         sorry
    qed
    have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)"
    proof(rule impI)
      assume A12: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A13: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A12 genealg1_th_33 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n5)"
        using A13 genealg1_th_33 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)"
         sorry
    qed
    thus "((( not (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)) &  not (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5))) &  not (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5))) &  not (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5))) &  not (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4))"
      using A3 A9 A6 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_47:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5)) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5))) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5))) & (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5))) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((((( not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5)) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5))) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5))) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) &  not ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5))) &  not ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) &  not ((n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)"
    proof(rule impMI ,rule impI)
      assume A2: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A3: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A3 genealg1_def_1 sorry
      then have A4: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A2 genealg1_th_33 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4)"
        using A4 genealg1_th_5 sorry
    qed
    have A5: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)"
    proof(rule impMI ,rule impI)
      assume A6: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A7: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A7 genealg1_def_1 sorry
      then have A8: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A6 genealg1_th_33 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4)"
        using A8 genealg1_th_5 sorry
    qed
    have A9: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)"
    proof(rule impMI ,rule impI)
      assume A10: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A11: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A10 genealg1_def_1 sorry
      then have A12: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A11 genealg1_def_1 sorry
      then have A13: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A10 A11 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n5)"
        using A12 A13 genealg1_th_34 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)"
         sorry
    qed
    have A14: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)"
    proof(rule impMI ,rule impI)
      assume A15: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A16: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A15 genealg1_def_1 sorry
      then have A17: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A16 genealg1_def_1 sorry
      then have A18: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A15 A16 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4),n5)"
        using A17 A18 genealg1_th_34 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)"
         sorry
    qed
    have A19: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5)"
    proof(rule impMI ,rule impI)
      assume A20: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A21: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A20 genealg1_def_1 sorry
      then have A22: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A21 genealg1_def_1 sorry
      then have A23: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A20 A21 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n5)"
        using A22 A23 genealg1_th_34 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n3),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5)"
         sorry
    qed
    have A24: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5)"
    proof(rule impMI ,rule impI)
      assume A25: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A26: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A25 genealg1_def_1 sorry
      then have A27: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A26 genealg1_def_1 sorry
      then have A28: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A25 A26 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4),n5)"
        using A27 A28 genealg1_th_34 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n4),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5)"
         sorry
    qed
    have A29: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5)"
    proof(rule impMI ,rule impI)
      assume A30: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A31: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A30 genealg1_def_1 sorry
      then have A32: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A31 genealg1_def_1 sorry
      then have A33: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A30 A31 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n5)"
        using A32 A33 genealg1_th_34 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n1,n2),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5)"
         sorry
    qed
    have A34: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5)"
    proof(rule impMI ,rule impI)
      assume A35: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A36: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A35 genealg1_def_1 sorry
      then have A37: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A36 genealg1_def_1 sorry
      then have A38: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A35 A36 genealg1_th_34 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4),n5)"
        using A37 A38 genealg1_th_34 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4),n5)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5)"
         sorry
    qed
    have A39: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
    proof(rule impMI ,rule impI)
      assume A40: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A41: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A41 genealg1_def_1 sorry
      then have A42: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A40 genealg1_th_33 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3)"
        using A42 genealg1_th_5 sorry
    qed
    have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
    proof(rule impMI ,rule impI)
      assume A43: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A44: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A44 genealg1_def_1 sorry
      then have A45: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A43 genealg1_th_33 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
        using A45 genealg1_th_5 sorry
    qed
    thus "(((((((( not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5)) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5))) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5))) &  not ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n4,n5))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n5))) &  not ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4))) &  not ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n5))) &  not ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4))) &  not ((n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3))"
      using A34 A14 A9 A24 A19 A1 A29 A5 A39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_48:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n5)) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n5))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n5))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) & ((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n5))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) & ((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) & ((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((((( not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n5)) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n5))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n5))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n5))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) &  not (((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)"
    proof(rule impMI ,rule impI)
      assume A2: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A3: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A3 genealg1_def_1 sorry
      then have A4: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A2 genealg1_th_34 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4)"
        using A4 genealg1_th_5 sorry
    qed
    have A5: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
    proof(rule impMI ,rule impI)
      assume A6: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A7: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A7 genealg1_def_1 sorry
      then have A8: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A6 genealg1_th_34 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3)"
        using A8 genealg1_th_5 sorry
    qed
    have A9: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n5)"
    proof-
      have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n5)"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A10: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A11: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A12: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A10 genealg1_def_1 sorry
        then have A13: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A12 genealg1_def_1 sorry
        then have A14: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A11 genealg1_def_1 sorry
        then have A15: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
          using A10 A11 A12 genealg1_th_35 sorry
        also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3),n5)"
          using A13 A15 A14 genealg1_th_35 sorry
        finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n3),n5)"
           sorry
        thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n5)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A16: "(n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
    proof(rule impMI ,rule impI)
      assume A17: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A18: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A18 genealg1_def_1 sorry
      then have A19: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A17 genealg1_th_34 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3)"
        using A19 genealg1_th_5 sorry
    qed
    have A20: "(n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n5)"
    proof-
      have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n5)"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A21: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A22: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A23: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A21 genealg1_def_1 sorry
        then have A24: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A23 genealg1_def_1 sorry
        then have A25: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A22 genealg1_def_1 sorry
        then have A26: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
          using A21 A22 A23 genealg1_th_35 sorry
        also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n5)"
          using A24 A26 A25 genealg1_th_35 sorry
        finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n1),n5)"
           sorry
        thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n5)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A27: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n5)"
    proof-
      have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n5)"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A28: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A29: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A30: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A28 genealg1_def_1 sorry
        then have A31: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A30 genealg1_def_1 sorry
        then have A32: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A29 genealg1_def_1 sorry
        then have A33: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
          using A28 A29 A30 genealg1_th_35 sorry
        also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4),n5)"
          using A31 A33 A32 genealg1_th_35 sorry
        finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n4),n5)"
           sorry
        thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n5)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A34: "(n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)"
    proof(rule impMI ,rule impI)
      assume A35: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A36: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A36 genealg1_def_1 sorry
      then have A37: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A35 genealg1_th_34 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4)"
        using A37 genealg1_th_5 sorry
    qed
    have A38: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n5)"
    proof-
      have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n5)"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A39: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A40: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A41: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A39 genealg1_def_1 sorry
        then have A42: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A41 genealg1_def_1 sorry
        then have A43: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A40 genealg1_def_1 sorry
        then have A44: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
          using A39 A40 A41 genealg1_th_35 sorry
        also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n5)"
          using A42 A44 A43 genealg1_th_35 sorry
        finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p2,p1,n2),n5)"
           sorry
        thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n5)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A45: "(n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
    proof(rule impMI ,rule impI)
      assume A46: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A47: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A47 genealg1_def_1 sorry
      then have A48: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A46 genealg1_th_34 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2)"
        using A48 genealg1_th_5 sorry
    qed
    have "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
    proof(rule impMI ,rule impI)
      assume A49: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A50: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A50 genealg1_def_1 sorry
      then have A51: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A49 genealg1_th_34 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4)"
        using A51 genealg1_th_5 sorry
    qed
    thus "(((((((( not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n4,n5)) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n5))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n5))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4))) &  not (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n5))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n4))) &  not (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n3))) &  not (((n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n1,n2))"
      using A27 A9 A38 A1 A5 A20 A34 A16 A45 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_49:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5)) & (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4))) & (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) & (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) & (((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((( not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5)) &  not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4))) &  not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) &  not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) &  not ((((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
    proof(rule impMI ,rule impI)
      assume A2: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A3: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A3 genealg1_def_1 sorry
      then have A4: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A2 genealg1_th_35 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3)"
        using A4 genealg1_th_5 sorry
    qed
    have A5: "((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
    proof(rule impMI ,rule impI)
      assume A6: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A7: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A7 genealg1_def_1 sorry
      then have A8: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A6 genealg1_th_35 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2)"
        using A8 genealg1_th_5 sorry
    qed
    have A9: "((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5)"
    proof-
      have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1)) implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5)"
      proof(rule impMI ,rule impMI ,rule impMI ,rule impI)
        assume A10: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A11: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A12: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
          and A13: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A10 genealg1_def_1 sorry
        then have A14: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A12 genealg1_def_1 sorry
        then have A15: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A11 genealg1_def_1 sorry
        then have A16: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
          using A13 genealg1_def_1 sorry
        then have A17: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
          using genealg1_def_1 sorry
        have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
          using A10 A11 A12 A13 genealg1_th_36 sorry
        thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5)"
          using A14 A16 A15 A17 genealg1_th_36 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A18: "((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
    proof(rule impMI ,rule impI)
      assume A19: "(n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A20: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A20 genealg1_def_1 sorry
      then have A21: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A19 genealg1_th_35 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1)"
        using A21 genealg1_th_5 sorry
    qed
    have "((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)"
    proof(rule impMI ,rule impI)
      assume A22: "(n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
        and A23: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using A23 genealg1_def_1 sorry
      then have A24: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using A22 genealg1_th_35 sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4)"
        using A24 genealg1_th_5 sorry
    qed
    thus "((( not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n5)) &  not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n4))) &  not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n3))) &  not ((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n2))) &  not ((((n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1) &  not crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,p2,n1))"
      using A9 A1 A5 A18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_50:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 p1"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 p1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    assume A1: "((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 & n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1) & n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      and A2: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(p1,crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
      using A1 genealg1_th_36 sorry
    thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 p1"
      using A2 genealg1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_51:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1,n4),n5)"
      using genealg1_th_37 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1,n4),n5)"
       sorry
    have A2: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n4,n2,n3,n1),n5)"
      using genealg1_th_37 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n4,n2,n3,n1),n5)"
       sorry
    have A3: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1)"
    proof-
      let ?q2 = "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4)"
      let ?q1 = "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
      have A4: "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q1,?q2,n5)"
         sorry
      have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
        using genealg1_th_37 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n1),n5)"
        using genealg1_th_37 sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n5)"
         sorry
      also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n5,n1)"
        using genealg1_th_13 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5),n1)"
        using A4 genealg1_th_37 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n5,n2,n3,n4),n1)"
        using genealg1_th_37 sorry
      finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n5,n2,n3,n4),n1)"
         sorry
      thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1)"
         sorry
    qed
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n5)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3,n4),n5)"
      using genealg1_th_37 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3,n4),n5)"
       sorry
    thus "((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1)"
      using A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_52:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5) & (crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5) & (crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5) & crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    let ?q1 = "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
    let ?q2 = "crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4)"
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n1,n3,n4),n5)"
      using genealg1_th_38 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4),n5)"
      using genealg1_th_38 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n3,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n3,n4),n5)"
       sorry
    thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5)"
       sorry
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n1,n4),n5)"
      using genealg1_th_38 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4),n5)"
      using genealg1_th_38 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n4),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n4),n5)"
       sorry
    thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5)"
       sorry
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n1),n5)"
      using genealg1_th_38 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n5)"
      using genealg1_th_38 sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p1,p2,n2,n3),crossoverGENEALG1K9\<^bsub>(S)\<^esub>(p2,p1,n2,n3),n5)"
       sorry
    thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5)"
       sorry
    have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n1)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n1),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n1),n1)"
      using genealg1_th_37 sorry
    also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n1)"
       sorry
    finally have "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1) =HIDDENR1 crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n1)"
       sorry
    thus "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1) =FINSEQ-1R1 crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4)"
      using genealg1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem genealg1_th_53:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) be IndividualGENEALG1M2-of S"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) be IndividualGENEALG1M2-of S"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n6 assume [ty]: "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    obtain q1 q2 where 
      [ty]:"q1 be IndividualGENEALG1M2-of S" and q1Def:"q1 = crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5)" and
      [ty]:"q2 be IndividualGENEALG1M2-of S" and q2Def:"q2 = crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5)"
       sorry
    have "crossoverGENEALG1K8\<^bsub>(S)\<^esub>(q1,q2,n6) be IndividualGENEALG1M2-of S"
       sorry
    thus "crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) be IndividualGENEALG1M2-of S"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) GENEALG1K13("crossoverGENEALG1K13\<^bsub>'( _ ')\<^esub>'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]164) where
  "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) \<equiv> crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6)"

mtheorem genealg1_add_6:
  mlet "S be Gene-SetGENEALG1M1", "p1 be IndividualGENEALG1M2-of S", "p2 be IndividualGENEALG1M2-of S", "n1 be ElementSUBSET-1M1-of NATNUMBERSK1", "n2 be ElementSUBSET-1M1-of NATNUMBERSK1", "n3 be ElementSUBSET-1M1-of NATNUMBERSK1", "n4 be ElementSUBSET-1M1-of NATNUMBERSK1", "n5 be ElementSUBSET-1M1-of NATNUMBERSK1", "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
"cluster crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) as-term-is IndividualGENEALG1M2-of S"
proof
(*coherence*)
  show "crossoverGENEALG1K7\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) be IndividualGENEALG1M2-of S"
    using genealg1_th_53 sorry
qed "sorry"

mtheorem genealg1_th_54:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds ((((crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,0NUMBERSK6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,0NUMBERSK6) =HIDDENR1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5)))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n6 assume [ty]: "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,0NUMBERSK6,n2,n3,n4,n5),n6)"
      using genealg1_th_41 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5),n6)"
      using genealg1_th_41 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,0NUMBERSK6,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,0NUMBERSK6,n3,n4,n5),n6)"
      using genealg1_th_41 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5),n6)"
      using genealg1_th_41 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,0NUMBERSK6,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,0NUMBERSK6,n4,n5),n6)"
      using genealg1_th_41 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5),n6)"
      using genealg1_th_41 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,0NUMBERSK6,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,0NUMBERSK6,n5),n6)"
      using genealg1_th_41 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5),n6)"
      using genealg1_th_41 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,0NUMBERSK6,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,0NUMBERSK6),n6)"
      using genealg1_th_41 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),n6)"
      using genealg1_th_41 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,0NUMBERSK6,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,0NUMBERSK6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),0NUMBERSK6)"
       sorry
    also have "... = crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5)"
      using genealg1_th_4 sorry
    finally show "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,0NUMBERSK6) =HIDDENR1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_55:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((((n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5,n6)) & (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5,n6))) & (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5,n6))) & (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5,n6))) & (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n6))) & (n6 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5))"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((( not (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5,n6)) &  not (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5,n6))) &  not (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5,n6))) &  not (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5,n6))) &  not (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n6))) &  not (n6 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n6 assume [ty]: "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have A1: "n6 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5)"
    proof(rule impI)
      assume "n6 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n6 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A2: "n6 >=XXREAL-0R2 lenFINSEQ-1K4 (crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5))"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
         sorry
      thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5)"
        using A2 genealg1_th_5 sorry
    qed
    have A3: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5,n6)"
    proof(rule impI)
      assume A4: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n2 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A5: "n2 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
        using A4 genealg1_th_46 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5),n6)"
        using A5 genealg1_th_46 sorry
      finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n3,n4,n5),n6)"
         sorry
      thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5,n6)"
         sorry
    qed
    have A6: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n6)"
    proof(rule impI)
      assume A7: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n5 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A8: "n5 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
        using A7 genealg1_th_46 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n6)"
        using A8 genealg1_th_46 sorry
      finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4),n6)"
         sorry
      thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n6)"
         sorry
    qed
    have A9: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5,n6)"
    proof(rule impI)
      assume A10: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n4 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A11: "n4 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
        using A10 genealg1_th_46 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5),n6)"
        using A11 genealg1_th_46 sorry
      finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n5),n6)"
         sorry
      thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5,n6)"
         sorry
    qed
    have A12: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5,n6)"
    proof(rule impI)
      assume A13: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n3 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A14: "n3 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
        using A13 genealg1_th_46 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5),n6)"
        using A14 genealg1_th_46 sorry
      finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n4,n5),n6)"
         sorry
      thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5,n6)"
         sorry
    qed
    have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5,n6)"
    proof(rule impI)
      assume A15: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1"
      then have "n1 >=XXREAL-0R2 lenFINSEQ-1K4 S"
        using genealg1_def_1 sorry
      then have A16: "n1 >=XXREAL-0R2 lenFINSEQ-1K4 p2"
        using genealg1_def_1 sorry
      have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
        using A15 genealg1_th_46 sorry
      also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5),n6)"
        using A16 genealg1_th_46 sorry
      finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5),crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4,n5),n6)"
         sorry
      thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5,n6)"
         sorry
    qed
    thus "(((( not (n1 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5,n6)) &  not (n2 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n3,n4,n5,n6))) &  not (n3 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n4,n5,n6))) &  not (n4 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n5,n6))) &  not (n5 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n6))) &  not (n6 >=XXREAL-0R2 lenFINSEQ-1K4 p1 &  not crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5))"
      using A3 A12 A9 A6 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_56:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n6,n2,n3,n4,n5,n1)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n6,n2,n3,n4,n5,n1))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n6 assume [ty]: "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    let ?q1 = "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4)"
    let ?q2 = "crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p2,p1,n5,n2,n3,n4)"
    have A1: "crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n6) =FINSEQ-1R1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(?q1,?q2,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
      using genealg1_th_51 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3,n4,n5),n6)"
      using genealg1_th_51 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n2,n1,n3,n4,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n2,n1,n3,n4,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
      using genealg1_th_51 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1,n4,n5),n6)"
      using genealg1_th_51 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n3,n2,n1,n4,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n3,n2,n1,n4,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
      using genealg1_th_51 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n4,n2,n3,n1,n5),n6)"
      using genealg1_th_51 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n4,n2,n3,n1,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n4,n2,n3,n1,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
      using genealg1_th_51 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n5,n2,n3,n4,n1),n6)"
      using genealg1_th_51 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n5,n2,n3,n4,n1),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n5),n6)"
      using genealg1_th_51 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n5,n2,n3,n4,n1),n6)"
      using genealg1_th_51 sorry
    also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n1,n6)"
       sorry
    also have "... = crossoverGENEALG1K9\<^bsub>(S)\<^esub>(?q1,?q2,n6,n1)"
      using genealg1_th_13 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n6,n2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n5,n2,n3,n4,n6),n1)"
      using A1 genealg1_th_51 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n6,n2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n6,n2,n3,n4,n5),n1)"
      using genealg1_th_51 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p1,p2,n6,n2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n6,n2,n3,n4,n5),n1)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n6,n2,n3,n4,n5,n1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem genealg1_th_57:
" for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds (((crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n6)) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n1) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)"
proof-
  have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n3 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n4 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n5 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n6 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for S be Gene-SetGENEALG1M1 holds  for p1 be IndividualGENEALG1M2-of S holds  for p2 be IndividualGENEALG1M2-of S holds crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5,n6) & (crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n6) & crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n1) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n3 assume [ty]: "n3 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n4 assume [ty]: "n4 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n5 assume [ty]: "n5 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n6 assume [ty]: "n6 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix S assume [ty]: "S be Gene-SetGENEALG1M1"
    fix p1 assume [ty]: "p1 be IndividualGENEALG1M2-of S"
    fix p2 assume [ty]: "p2 be IndividualGENEALG1M2-of S"
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n1,n3,n4,n5),n6)"
      using genealg1_th_52 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n4,n5),n6)"
      using genealg1_th_52 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n3,n4,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n1,n3,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n3,n4,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n1,n4,n5),n6)"
      using genealg1_th_52 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n4,n5),n6)"
      using genealg1_th_52 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n4,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n1,n4,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n4,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n1,n5),n6)"
      using genealg1_th_52 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n5),n6)"
      using genealg1_th_52 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n5),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n1,n5,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n5,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n1),n6)"
      using genealg1_th_52 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n6)"
      using genealg1_th_52 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1,n6) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n6)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1,n6) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n6)"
       sorry
    have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n1) =HIDDENR1 crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n5,n2,n3,n4,n1,n1)"
      using genealg1_th_56 sorry
    also have "... = crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n1,n5)"
      using genealg1_th_56 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K12\<^bsub>(S)\<^esub>(p2,p1,n1,n2,n3,n4,n1),n5)"
      using genealg1_th_52 sorry
    also have "... = crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n5)"
      using genealg1_th_52 sorry
    finally have "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n1) =HIDDENR1 crossoverGENEALG1K8\<^bsub>(S)\<^esub>(crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4),crossoverGENEALG1K10\<^bsub>(S)\<^esub>(p2,p1,n2,n3,n4),n5)"
       sorry
    thus "crossoverGENEALG1K13\<^bsub>(S)\<^esub>(p1,p2,n1,n2,n3,n4,n5,n1) =FINSEQ-1R1 crossoverGENEALG1K11\<^bsub>(S)\<^esub>(p1,p2,n2,n3,n4,n5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
