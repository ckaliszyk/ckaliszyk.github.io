theory card_fil
  imports setfam_1 card_5 setwiseo trees_2
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem card_fil_th_1:
" for x be setHIDDENM2 holds  for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds cardCARD-1K4 {TARSKIK1 x} inTARSKIR2 cardCARD-1K1 X"
  using card_3_th_86 sorry

theorem card_fil_sch_1:
  fixes Df0 xf0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "xf0 be setHIDDENM2" and
   A1: "xf0 inTARSKIR2 {y where y be ElementSUBSET-1M1-of Df0 : Pp1(y) }"
  shows "Pp1(xf0)"
  proof-
    have " ex y be ElementSUBSET-1M1-of Df0 st xf0 =XBOOLE-0R4 y & Pp1(y)"
      using A1 sorry
    thus "Pp1(xf0)"
       sorry
  qed

reserve N for "CardinalCARD-1M1"
reserve M for "AlephCARD-5M1"
reserve X for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve Y, Z, Z1, Z2, Y1, Y2, Y3, Y4 for "SubsetSUBSET-1M2-of X"
reserve S for "Subset-FamilySETFAM-1M1-of X"
mtheorem card_fil_th_2:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds ({TARSKIK1 X} be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 X}) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 {TARSKIK1 X} & Y2 inTARSKIR2 {TARSKIK1 X} implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 {TARSKIK1 X}) & (Y1 inTARSKIR2 {TARSKIK1 X} & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 {TARSKIK1 X}))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {TARSKIK1 X} be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X & ( not {}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 X} & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 {TARSKIK1 X} & Y2 inTARSKIR2 {TARSKIK1 X} implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 {TARSKIK1 X}) & (Y1 inTARSKIR2 {TARSKIK1 X} & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 {TARSKIK1 X})))"
  proof(rule ballI,rule conjMI,rule conjMI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have A1: "X c=TARSKIR1 X"
       sorry
    have "{TARSKIK1 X} c=TARSKIR1 boolSETFAM-1K9 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 X} implies x inHIDDENR3 boolSETFAM-1K9 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {TARSKIK1 X}"
        then have "x =HIDDENR1 X"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 boolSETFAM-1K9 X"
          using A1 sorry
      qed "sorry"
      thus "{TARSKIK1 X} c=TARSKIR1 boolSETFAM-1K9 X"
        using tarski_def_3 sorry
    qed
    thus "{TARSKIK1 X} be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
       sorry
    show " not {}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of X"
    fix Y2 assume [ty]: "Y2 be SubsetSUBSET-1M2-of X"
    show "Y1 inTARSKIR2 {TARSKIK1 X} & Y2 inTARSKIR2 {TARSKIK1 X} implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 {TARSKIK1 X}"
    proof(rule impI)
      assume "Y1 inTARSKIR2 {TARSKIK1 X} & Y2 inTARSKIR2 {TARSKIK1 X}"
      then have "Y1 =XBOOLE-0R4 X & Y2 =XBOOLE-0R4 X"
        using tarski_def_1 sorry
      thus "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 {TARSKIK1 X}"
        using tarski_def_1 sorry
    qed
    show "Y1 inTARSKIR2 {TARSKIK1 X} & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 {TARSKIK1 X}"
    proof(rule impI)
      assume "Y1 inTARSKIR2 {TARSKIK1 X} & Y1 c=TARSKIR1 Y2"
      then have "X c=TARSKIR1 Y2"
        using tarski_def_1 sorry
      then have "Y2 =XBOOLE-0R4 X"
         sorry
      thus "Y2 inTARSKIR2 {TARSKIK1 X}"
        using tarski_def_1 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_fil_def_1 ("FilterCARD-FILM1-of  _ " [70]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"mode FilterCARD-FILM1-of X \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X means
  (\<lambda>it.  not {}XBOOLE-0K1 inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 it)))"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st  not {}XBOOLE-0K1 inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 it))"
    proof-
      have " ex tVar1 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st (tVar1 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 tVar1) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds  not ((Y1 inTARSKIR2 tVar1 & Y2 inTARSKIR2 tVar1) &  not Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 tVar1) &  not ((Y1 inTARSKIR2 tVar1 & Y1 c=TARSKIR1 Y2) &  not Y2 inTARSKIR2 tVar1))"
      proof-
        show " ex tVar1 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st (tVar1 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 tVar1) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds  not ((Y1 inTARSKIR2 tVar1 & Y2 inTARSKIR2 tVar1) &  not Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 tVar1) &  not ((Y1 inTARSKIR2 tVar1 & Y1 c=TARSKIR1 Y2) &  not Y2 inTARSKIR2 tVar1))"
        proof(rule bexI[of _ "{TARSKIK1 X}"])
          show "({TARSKIK1 X} be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 X}) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds  not ((Y1 inTARSKIR2 {TARSKIK1 X} & Y2 inTARSKIR2 {TARSKIK1 X}) &  not Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 {TARSKIK1 X}) &  not ((Y1 inTARSKIR2 {TARSKIK1 X} & Y1 c=TARSKIR1 Y2) &  not Y2 inTARSKIR2 {TARSKIK1 X}))"
            using card_fil_th_2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem card_fil_th_3:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be setHIDDENM2 holds F be FilterCARD-FILM1-of X iff (F be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 F) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 F & Y2 inTARSKIR2 F implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 F) & (Y1 inTARSKIR2 F & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 F))"
  using card_fil_def_1 sorry

mtheorem card_fil_th_4:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {TARSKIK1 X} be FilterCARD-FILM1-of X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds {TARSKIK1 X} be FilterCARD-FILM1-of X"
  proof(rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have A1: " for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 {TARSKIK1 X} & Y2 inTARSKIR2 {TARSKIK1 X} implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 {TARSKIK1 X}) & (Y1 inTARSKIR2 {TARSKIK1 X} & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 {TARSKIK1 X})"
      using card_fil_th_2 sorry
    have "{TARSKIK1 X} be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X &  not {}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 X}"
      using card_fil_th_2 sorry
    thus "{TARSKIK1 X} be FilterCARD-FILM1-of X"
      using A1 card_fil_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve F, Uf for "FilterCARD-FILM1-of X"
mtheorem card_fil_th_5:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds X inTARSKIR2 F"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds X inTARSKIR2 F"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    let ?Y = "the ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of F"
    have "?Y inTARSKIR2 F & X c=TARSKIR1 X"
       sorry
    thus "X inTARSKIR2 F"
      using card_fil_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_6:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds Y inTARSKIR2 F implies  not X \\SUBSET-1K6 Y inTARSKIR2 F"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds Y inTARSKIR2 F implies (X \\SUBSET-1K6 Y inTARSKIR2 F implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    assume A1: "Y inTARSKIR2 F"
    assume "X \\SUBSET-1K6 Y inTARSKIR2 F"
    then have A2: "Y /\\SUBSET-1K9\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Y) inTARSKIR2 F"
      using A1 card_fil_def_1 sorry
    have "Y missesXBOOLE-0R1 X \\SUBSET-1K6 Y"
      using xboole_1_th_79 sorry
    then have "{}XBOOLE-0K1 inTARSKIR2 F"
      using A2 sorry
    thus " False "
      using card_fil_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_7:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  for I be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds ( for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 I iff Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F) implies  not X inTARSKIR2 I & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 I & Y2 inTARSKIR2 I implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 I) & (Y1 inTARSKIR2 I & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 I))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  for I be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds ( for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 I iff Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F) implies  not X inTARSKIR2 I & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 I & Y2 inTARSKIR2 I implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 I) & (Y1 inTARSKIR2 I & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 I))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    fix I assume [ty]: "I be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
    assume A1: " for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 I iff Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
    have " not (({}SUBSET-1K1 X)`SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using card_fil_def_1 sorry
    thus " not X inTARSKIR2 I"
      using A1 sorry
    fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of X"
    fix Y2 assume [ty]: "Y2 be SubsetSUBSET-1M2-of X"
    show "Y1 inTARSKIR2 I & Y2 inTARSKIR2 I implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 I"
    proof(rule impI)
      assume "Y1 inTARSKIR2 I & Y2 inTARSKIR2 I"
      then have "Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F & Y2 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
        using A1 sorry
      then have "Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
        using card_fil_def_1 sorry
      then have "(Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
        using xboole_1_th_53 sorry
      thus "Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 I"
        using A1 sorry
    qed
    assume A2: "Y1 inTARSKIR2 I"
      and A3: "Y2 c=TARSKIR1 Y1"
    have A4: "Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> c=TARSKIR1 Y2 `SUBSET-1K3\<^bsub>(X)\<^esub>"
      using A3 subset_1_th_12 sorry
    have "Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using A1 A2 sorry
    then have "Y2 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using A4 card_fil_def_1 sorry
    thus "Y2 inTARSKIR2 I"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) CARD_FILK1("dualCARD-FILK1\<^bsub>'( _ ')\<^esub>  _ " [0,164]164) where
  "dualCARD-FILK1\<^bsub>(X)\<^esub> S \<equiv> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> S"

reserve S for " non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
mtheorem card_fil_cl_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"cluster COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> S as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> S be  non emptyXBOOLE-0V1"
    using setfam_1_th_32 sorry
qed "sorry"

mtheorem card_fil_th_8:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
    have "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S } & {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S } c=TARSKIR1 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
    proof(rule conjMI)
      show "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
      proof-
        have "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
        proof-
          have " for X1 be objectHIDDENM1 holds X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S implies X1 inHIDDENR3 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
          proof(rule ballI,rule impI)
            fix X1 assume [ty]: "X1 be objectHIDDENM1"
            assume A1: "X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
            obtain Y1 where 
              [ty]:"Y1 be SubsetSUBSET-1M2-of X" and Y1Def:"Y1 = X1"
              using A1 sorry
            have "Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S"
              using A1 setfam_1_def_7 sorry
            thus "X1 inHIDDENR3 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
               sorry
          qed "sorry"
          thus "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for X1 be objectHIDDENM1 holds X1 inHIDDENR3 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S } implies X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
      proof(rule ballI,rule impI)
        fix X1 assume [ty]: "X1 be objectHIDDENM1"
        assume "X1 inHIDDENR3 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
        then have " ex Y be SubsetSUBSET-1M2-of X st Y =HIDDENR1 X1 & Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S"
           sorry
        thus "X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
          using setfam_1_def_7 sorry
      qed "sorry"
      thus "{Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S } c=TARSKIR1 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
        using tarski_def_3 sorry
    qed
    thus "dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y where Y be SubsetSUBSET-1M2-of X : Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_9:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
    have "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S } & {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S } c=TARSKIR1 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
    proof(rule conjMI)
      show "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
      proof-
        have "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
        proof-
          have " for X1 be objectHIDDENM1 holds X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S implies X1 inHIDDENR3 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
          proof(rule ballI,rule impI)
            fix X1 assume [ty]: "X1 be objectHIDDENM1"
            assume A1: "X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
            obtain Y1 where 
              [ty]:"Y1 be SubsetSUBSET-1M2-of X" and Y1Def:"Y1 = X1"
              using A1 sorry
            have "Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S"
              using A1 setfam_1_def_7 sorry
            then have "(Y1 `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
               sorry
            thus "X1 inHIDDENR3 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
               sorry
          qed "sorry"
          thus "dualCARD-FILK1\<^bsub>(X)\<^esub> S c=TARSKIR1 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have " for X1 be objectHIDDENM1 holds X1 inHIDDENR3 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S } implies X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
      proof(rule ballI,rule impI)
        fix X1 assume [ty]: "X1 be objectHIDDENM1"
        assume "X1 inHIDDENR3 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
        then obtain Y where
          [ty]:"Y be SubsetSUBSET-1M2-of X" and 
          A2: "Y `SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 X1"and A3: "Y inTARSKIR2 S"
           sorry
        have "(Y `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S"
          using A3 sorry
        thus "X1 inHIDDENR3 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
          using A2 setfam_1_def_7 sorry
      qed "sorry"
      thus "{Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S } c=TARSKIR1 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
        using tarski_def_3 sorry
    qed
    thus "dualCARD-FILK1\<^bsub>(X)\<^esub> S =XBOOLE-0R4 {Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_fil_def_2 ("IdealCARD-FILM2-of  _ " [70]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"mode IdealCARD-FILM2-of X \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X means
  (\<lambda>it.  not X inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 it)))"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st  not X inTARSKIR2 it & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 it & Y2 inTARSKIR2 it implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 it) & (Y1 inTARSKIR2 it & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 it))"
    proof-
      have " ex tVar2 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st  not X inTARSKIR2 tVar2 & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds  not ((Y1 inTARSKIR2 tVar2 & Y2 inTARSKIR2 tVar2) &  not Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 tVar2) &  not ((Y1 inTARSKIR2 tVar2 & Y2 c=TARSKIR1 Y1) &  not Y2 inTARSKIR2 tVar2))"
      proof-
        let ?F = "the FilterCARD-FILM1-of X"
        show " ex tVar2 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X st  not X inTARSKIR2 tVar2 & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds  not ((Y1 inTARSKIR2 tVar2 & Y2 inTARSKIR2 tVar2) &  not Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 tVar2) &  not ((Y1 inTARSKIR2 tVar2 & Y2 c=TARSKIR1 Y1) &  not Y2 inTARSKIR2 tVar2))"
        proof(rule bexI[of _ "dualCARD-FILK1\<^bsub>(X)\<^esub> ?F"])
          have " for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> ?F iff Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 ?F"
            using setfam_1_def_7 sorry
          thus " not X inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> (the FilterCARD-FILM1-of X) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds  not ((Y1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> (the FilterCARD-FILM1-of X) & Y2 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> (the FilterCARD-FILM1-of X)) &  not Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> (the FilterCARD-FILM1-of X)) &  not ((Y1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> (the FilterCARD-FILM1-of X) & Y2 c=TARSKIR1 Y1) &  not Y2 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> (the FilterCARD-FILM1-of X)))"
            using card_fil_th_7 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

abbreviation(input) CARD_FILK2("dualCARD-FILK2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164) where
  "dualCARD-FILK2\<^bsub>(X)\<^esub> F \<equiv> COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F"

mtheorem card_fil_add_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FilterCARD-FILM1-of X"
"cluster COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F as-term-is IdealCARD-FILM2-of X"
proof
(*coherence*)
  show "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F be IdealCARD-FILM2-of X"
  proof-
    have " for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> F iff Y1 `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using setfam_1_def_7 sorry
    then have " not X inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> F & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> F & Y2 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> F implies Y1 \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y2 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> F) & (Y1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> F & Y2 c=TARSKIR1 Y1 implies Y2 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> F))"
      using card_fil_th_7 sorry
    thus "COMPLEMENTSETFAM-1K7\<^bsub>(X)\<^esub> F be IdealCARD-FILM2-of X"
      using card_fil_def_2 sorry
  qed
qed "sorry"

reserve I for "IdealCARD-FILM2-of X"
mtheorem card_fil_th_10:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  for I be IdealCARD-FILM2-of X holds ( for Y be SubsetSUBSET-1M2-of X holds  not (Y inTARSKIR2 F & Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F)) & ( for Y be SubsetSUBSET-1M2-of X holds  not (Y inTARSKIR2 I & Y inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> I))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  for I be IdealCARD-FILM2-of X holds ( for Y be SubsetSUBSET-1M2-of X holds  not (Y inTARSKIR2 F & Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F)) & ( for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 I & Y inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> I implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    fix I assume [ty]: "I be IdealCARD-FILM2-of X"
    show " for Y be SubsetSUBSET-1M2-of X holds  not (Y inTARSKIR2 F & Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F)"
    proof-
      have " for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F & Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F implies  False "
      proof(rule ballI,rule impMI ,rule impI)
        fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
        assume A1: "Y inTARSKIR2 F"
          and A2: "Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F"
        have "Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
          using A2 setfam_1_def_7 sorry
        then have A3: "Y `SUBSET-1K3\<^bsub>(X)\<^esub> /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y inTARSKIR2 F"
          using A1 card_fil_def_1 sorry
        have "Y `SUBSET-1K3\<^bsub>(X)\<^esub> missesXBOOLE-0R1 Y"
          using xboole_1_th_79 sorry
        then have "{}SUBSET-1K1 X inTARSKIR2 F"
          using A3 sorry
        thus " False "
          using card_fil_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
    assume A4: "Y inTARSKIR2 I"
      and A5: "Y inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> I"
    have "Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 I"
      using A5 setfam_1_def_7 sorry
    then have "Y `SUBSET-1K3\<^bsub>(X)\<^esub> \\/SUBSET-1K4\<^bsub>(X)\<^esub> Y inTARSKIR2 I"
      using A4 card_fil_def_2 sorry
    then have "[#]SUBSET-1K2 X inTARSKIR2 I"
      using subset_1_th_10 sorry
    thus " False "
      using card_fil_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_11:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for I be IdealCARD-FILM2-of X holds {}XBOOLE-0K1 inTARSKIR2 I"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for I be IdealCARD-FILM2-of X holds {}XBOOLE-0K1 inTARSKIR2 I"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix I assume [ty]: "I be IdealCARD-FILM2-of X"
    let ?Y = "the ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 X)\<^esub>-of I"
    have "{}XBOOLE-0K1 c=TARSKIR1 ?Y & {}XBOOLE-0K1 c=TARSKIR1 X"
       sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 I"
      using card_fil_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_fil_def_3 (" _ is-multiplicative-withCARD-FILR1\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "N be CardinalCARD-1M1", "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"pred S is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N means
   for S1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds S1 c=TARSKIR1 S & cardCARD-1K1 S1 inTARSKIR2 N implies meetSETFAM-1K1 S1 inTARSKIR2 S"..

mdef card_fil_def_4 (" _ is-additive-withCARD-FILR2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "N be CardinalCARD-1M1", "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
"pred S is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N means
   for S1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds S1 c=TARSKIR1 S & cardCARD-1K1 S1 inTARSKIR2 N implies unionTARSKIK3 S1 inTARSKIR2 S"..

abbreviation(input) CARD_FILR3(" _ is-complete-withCARD-FILR3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "F is-complete-withCARD-FILR3\<^bsub>(X)\<^esub> N \<equiv> F is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N"

abbreviation(input) CARD_FILR4(" _ is-complete-withCARD-FILR4\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "I is-complete-withCARD-FILR4\<^bsub>(X)\<^esub> N \<equiv> I is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N"

mtheorem card_fil_th_12:
" for N be CardinalCARD-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds S is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N implies dualCARD-FILK1\<^bsub>(X)\<^esub> S is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N"
proof-
  have " for N be CardinalCARD-1M1 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X holds S is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N implies dualCARD-FILK1\<^bsub>(X)\<^esub> S is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix N assume [ty]: "N be CardinalCARD-1M1"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix S assume [ty]: "S be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
    assume A1: "S is-multiplicative-withCARD-FILR1\<^bsub>(X)\<^esub> N"
    let ?F = "\<lambda>Lamb1. Lamb1 `SUBSET-1K3\<^bsub>(X)\<^esub>"
    have " for S1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds S1 c=TARSKIR1 dualCARD-FILK1\<^bsub>(X)\<^esub> S & cardCARD-1K1 S1 inTARSKIR2 N implies unionTARSKIK3 S1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
    proof(rule ballI,rule impMI ,rule impI)
      fix S1 assume [ty]: "S1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      assume A2: "S1 c=TARSKIR1 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
        and A3: "cardCARD-1K1 S1 inTARSKIR2 N"
      obtain S2 where 
        [ty]:"S2 be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X" and S2Def:"S2 = S1"
        using A2 xboole_1_th_1 sorry
      let ?S3 = "dualCARD-FILK1\<^bsub>(X)\<^esub> S2"
      have A4: "cardCARD-1K1 ({?F(Y) where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S2 }) c=ORDINAL1R1 cardCARD-1K1 S2"
        using trees_2_sch_2 sorry
      have "{Y `SUBSET-1K3\<^bsub>(X)\<^esub> where Y be SubsetSUBSET-1M2-of X : Y inTARSKIR2 S2 } =XBOOLE-0R4 ?S3"
        using card_fil_th_9 sorry
      then have A5: "cardCARD-1K1 ?S3 inTARSKIR2 N"
        using A3 A4 ordinal1_th_12 sorry
      have A6: "(unionSETFAM-1K5\<^bsub>(X)\<^esub> S2)`SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 [#]SUBSET-1K2 X \\SUBSET-1K7\<^bsub>(X)\<^esub> unionSETFAM-1K5\<^bsub>(X)\<^esub> S2"
         sorry
      also have "... = meetSETFAM-1K6\<^bsub>(X)\<^esub> ?S3"
        using setfam_1_th_33 sorry
      finally have "(unionSETFAM-1K5\<^bsub>(X)\<^esub> S2)`SUBSET-1K3\<^bsub>(X)\<^esub> =HIDDENR1 meetSETFAM-1K6\<^bsub>(X)\<^esub> ?S3"
         sorry
      have "?S3 c=TARSKIR1 S"
        using A2 setfam_1_th_37 sorry
      then have "((meetSETFAM-1K6\<^bsub>(X)\<^esub> ?S3)`SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 S"
        using A1 A5 sorry
      thus "unionTARSKIK3 S1 inTARSKIR2 dualCARD-FILK1\<^bsub>(X)\<^esub> S"
        using A6 setfam_1_def_7 sorry
    qed "sorry"
    thus "dualCARD-FILK1\<^bsub>(X)\<^esub> S is-additive-withCARD-FILR2\<^bsub>(X)\<^esub> N"
      using card_fil_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_fil_def_5 ("uniformCARD-FILV1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr uniformCARD-FILV1\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X means
  (\<lambda>F.  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F implies cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X)"..

mdef card_fil_def_6 ("principalCARD-FILV2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr principalCARD-FILV2\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X means
  (\<lambda>F.  ex Y be SubsetSUBSET-1M2-of X st Y inTARSKIR2 F & ( for Z be SubsetSUBSET-1M2-of X holds Z inTARSKIR2 F implies Y c=TARSKIR1 Z))"..

mdef card_fil_def_7 ("being-ultrafilterCARD-FILV3\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X means
  (\<lambda>F.  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F or X \\SUBSET-1K6 Y inTARSKIR2 F)"..

mdef card_fil_def_8 ("Extend-FilterCARD-FILK3\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be FilterCARD-FILM1-of X", "Z be SubsetSUBSET-1M2-of X"
"func Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X equals
  {Y where Y be SubsetSUBSET-1M2-of X :  ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Y }"
proof-
  (*coherence*)
    show "{Y where Y be SubsetSUBSET-1M2-of X :  ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Y } be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
    proof-
      have "{Y where Y be SubsetSUBSET-1M2-of X :  not ( for Y2 be SubsetSUBSET-1M2-of X holds  not (Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Y)) } be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
      proof-
        let ?P = "\<lambda>Lamb1.  ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Lamb1"
        let ?IT = "{Y where Y be SubsetSUBSET-1M2-of X : ?P(Y) }"
        have "X inTARSKIR2 F"
          using card_fil_th_5 sorry
        then have "X /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F }"
           sorry
        then have "Z inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F }"
          using xboole_1_th_28 sorry
        then have A1: "Z inTARSKIR2 {Y where Y be SubsetSUBSET-1M2-of X :  ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Y }"
           sorry
        have "?IT be Subset-FamilySETFAM-1M1-of X"
          using domain_1_sch_7 sorry
        thus "{Y where Y be SubsetSUBSET-1M2-of X :  not ( for Y2 be SubsetSUBSET-1M2-of X holds  not (Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Y)) } be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
          using A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem card_fil_th_13:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds  for Z1 be SubsetSUBSET-1M2-of X holds Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) iff ( ex Z2 be SubsetSUBSET-1M2-of X st Z2 inTARSKIR2 F & Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds  for Z1 be SubsetSUBSET-1M2-of X holds (Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) implies ( ex Z2 be SubsetSUBSET-1M2-of X st Z2 inTARSKIR2 F & Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1)) & (( ex Z2 be SubsetSUBSET-1M2-of X st Z2 inTARSKIR2 F & Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1) implies Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of X"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    fix Z1 assume [ty]: "Z1 be SubsetSUBSET-1M2-of X"
    show "Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) implies ( ex Z2 be SubsetSUBSET-1M2-of X st Z2 inTARSKIR2 F & Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1)"
    proof-
      have "Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) implies ( ex tVar3 be SubsetSUBSET-1M2-of X st tVar3 inTARSKIR2 F & tVar3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1)"
      proof(rule impI)
        let ?P = "\<lambda>Lamb1.  ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Lamb1"
        assume "Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
        then have A1: "Z1 inTARSKIR2 {Y where Y be SubsetSUBSET-1M2-of X : ?P(Y) }"
           sorry
        have "?P(Z1)"
          using card_fil_sch_1 A1 sorry
        then obtain Y2 where
          [ty]:"Y2 be SubsetSUBSET-1M2-of X" and 
          A2: "Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F }"and A3: "Y2 c=TARSKIR1 Z1"
           sorry
        obtain Y3 where
          [ty]:"Y3 be SubsetSUBSET-1M2-of X" and 
          A4: "Y2 =XBOOLE-0R4 Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z"and A5: "Y3 inTARSKIR2 F"
          using A2 sorry
        show " ex tVar3 be SubsetSUBSET-1M2-of X st tVar3 inTARSKIR2 F & tVar3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1"
        proof(rule bexI[of _ "Y3"],rule conjMI)
          show "Y3 inTARSKIR2 F"
            using A5 sorry
          show "Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1"
            using A3 A4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex Z2 be SubsetSUBSET-1M2-of X st Z2 inTARSKIR2 F & Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1"
    then obtain Z2 where
      [ty]:"Z2 be SubsetSUBSET-1M2-of X" and 
      A6: "Z2 inTARSKIR2 F"and A7: "Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1"
       sorry
    have " ex Y2 be SubsetSUBSET-1M2-of X st Y2 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & Y2 c=TARSKIR1 Z1"
    proof-
      have " ex tVar4 be SubsetSUBSET-1M2-of X st tVar4 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & tVar4 c=TARSKIR1 Z1"
      proof-
        show " ex tVar4 be SubsetSUBSET-1M2-of X st tVar4 inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F } & tVar4 c=TARSKIR1 Z1"
        proof(rule bexI[of _ "Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z"],rule conjMI)
          show "Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z inTARSKIR2 {Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z where Y1 be SubsetSUBSET-1M2-of X : Y1 inTARSKIR2 F }"
            using A6 sorry
          show "Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z1"
            using A7 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus "Z1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_14:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds ( for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 F implies Y1 meetsXBOOLE-0R5 Z) implies (Z inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) be FilterCARD-FILM1-of X) & F c=TARSKIR1 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be SubsetSUBSET-1M2-of X holds  for F be FilterCARD-FILM1-of X holds ( for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 F implies Y1 meetsXBOOLE-0R5 Z) implies Z inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & (Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) be FilterCARD-FILM1-of X & F c=TARSKIR1 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of X"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    assume A1: " for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 F implies Y1 meetsXBOOLE-0R5 Z"
    have "X inTARSKIR2 F & X /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Z"
      using card_fil_th_5 xboole_1_th_17 sorry
    thus "Z inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
      using card_fil_th_13 sorry
    show "Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) be FilterCARD-FILM1-of X"
    proof-
      have " not {}XBOOLE-0K1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)) & (Y1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)))"
      proof(rule conjMI,rule ballI,rule ballI,rule conjMI)
        show " not {}XBOOLE-0K1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
        proof-
          have "{}XBOOLE-0K1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) implies  False "
          proof(rule impI)
            assume "{}XBOOLE-0K1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
            then obtain Z2 where
              [ty]:"Z2 be SubsetSUBSET-1M2-of X" and 
              A2: "Z2 inTARSKIR2 F"and A3: "Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 {}XBOOLE-0K1"
              using card_fil_th_13 sorry
            have "Z2 meetsXBOOLE-0R5 Z"
              using A1 A2 sorry
            then have "Z2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            thus " False "
              using A3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of X"
        fix Y2 assume [ty]: "Y2 be SubsetSUBSET-1M2-of X"
        show "Y1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
        proof(rule impMI ,rule impI)
          assume A4: "Y1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
            and A5: "Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
          obtain Y3 where
            [ty]:"Y3 be SubsetSUBSET-1M2-of X" and 
            A6: "Y3 inTARSKIR2 F"and A7: "Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Y1"
            using A4 card_fil_th_13 sorry
          obtain Y4 where
            [ty]:"Y4 be SubsetSUBSET-1M2-of X" and 
            A8: "Y4 inTARSKIR2 F"and A9: "Y4 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Y2"
            using A5 card_fil_th_13 sorry
          have "(Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z)/\\SUBSET-1K9\<^bsub>(X)\<^esub> (Y4 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z) =HIDDENR1 Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> (Z /\\SUBSET-1K9\<^bsub>(X)\<^esub> (Y4 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z))"
            using xboole_1_th_16 sorry
          also have "... = Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> (Y4 /\\SUBSET-1K9\<^bsub>(X)\<^esub> (Z /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z))"
            using xboole_1_th_16 sorry
          also have "... = (Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y4)/\\SUBSET-1K9\<^bsub>(X)\<^esub> Z"
            using xboole_1_th_16 sorry
          finally have "(Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z)/\\SUBSET-1K9\<^bsub>(X)\<^esub> (Y4 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z) =HIDDENR1 (Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y4)/\\SUBSET-1K9\<^bsub>(X)\<^esub> Z"
             sorry
          then have A10: "(Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y4)/\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2"
            using A7 A9 xboole_1_th_27 sorry
          have "Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y4 inTARSKIR2 F"
            using A6 A8 card_fil_def_1 sorry
          thus "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
            using A10 card_fil_th_13 sorry
        qed
        show "Y1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
        proof(rule impMI ,rule impI)
          have A11: "X \\SUBSET-1K6 Z missesXBOOLE-0R1 Z"
            using xboole_1_th_79 sorry
          have "(Y2 \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z))/\\SUBSET-1K9\<^bsub>(X)\<^esub> Z =HIDDENR1 Y2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z)/\\SUBSET-1K9\<^bsub>(X)\<^esub> Z"
            using xboole_1_th_23 sorry
          also have "... = Y2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z \\/XBOOLE-0K2 {}XBOOLE-0K1"
            using A11 sorry
          also have "... = Y2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z"
             sorry
          finally have "(Y2 \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z))/\\SUBSET-1K9\<^bsub>(X)\<^esub> Z =HIDDENR1 Y2 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z"
             sorry
          then have A12: "(Y2 \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z))/\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Y2"
            using xboole_1_th_17 sorry
          assume A13: "Y1 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
            and A14: "Y1 c=TARSKIR1 Y2"
          obtain Y3 where
            [ty]:"Y3 be SubsetSUBSET-1M2-of X" and 
            A15: "Y3 inTARSKIR2 F"and A16: "Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Y1"
            using A13 card_fil_th_13 sorry
          have "Y3 =XBOOLE-0R4 Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z \\/SUBSET-1K4\<^bsub>(X)\<^esub> (Y3 \\SUBSET-1K7\<^bsub>(X)\<^esub> Z) & Y3 \\SUBSET-1K7\<^bsub>(X)\<^esub> Z c=TARSKIR1 X \\SUBSET-1K6 Z"
            using xboole_1_th_33 xboole_1_th_51 sorry
          then have A17: "Y3 c=TARSKIR1 Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z)"
            using xboole_1_th_9 sorry
          have "Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Y2"
            using A14 A16 sorry
          then have "Y3 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z) c=TARSKIR1 Y2 \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z)"
            using xboole_1_th_9 sorry
          then have "Y3 c=TARSKIR1 Y2 \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z)"
            using A17 sorry
          then have "Y2 \\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Z) inTARSKIR2 F"
            using A15 card_fil_def_1 sorry
          thus "Y2 inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
            using A12 card_fil_th_13 sorry
        qed
      qed "sorry"
      thus "Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z) be FilterCARD-FILM1-of X"
        using card_fil_def_1 sorry
    qed
    show "F c=TARSKIR1 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
    proof-
      have " for Y be objectHIDDENM1 holds Y inHIDDENR3 F implies Y inHIDDENR3 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
      proof(rule ballI,rule impI)
        fix Y assume [ty]: "Y be objectHIDDENM1"
        assume A18: "Y inHIDDENR3 F"
        then have 
          [ty]:"Y be SubsetSUBSET-1M2-of X"
           sorry
        have "Y /\\SUBSET-1K9\<^bsub>(X)\<^esub> Z c=TARSKIR1 Y"
          using xboole_1_th_17 sorry
        thus "Y inHIDDENR3 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
          using A18 card_fil_th_13 sorry
      qed "sorry"
      thus "F c=TARSKIR1 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(F,Z)"
        using tarski_def_3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve S, S1 for "Subset-FamilySETFAM-1M1-of X"
mdef card_fil_def_9 ("FiltersCARD-FILK4  _ " [164]164 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func FiltersCARD-FILK4 X \<rightarrow>  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 X equals
  {S where S be Subset-FamilySETFAM-1M1-of X : S be FilterCARD-FILM1-of X }"
proof-
  (*coherence*)
    show "{S where S be Subset-FamilySETFAM-1M1-of X : S be FilterCARD-FILM1-of X } be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 X"
    proof-
      let ?P = "\<lambda>Lamb1. Lamb1 be FilterCARD-FILM1-of X"
      have "{TARSKIK1 X} be FilterCARD-FILM1-of X"
        using card_fil_th_4 sorry
      then have A1: "{TARSKIK1 X} inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of X : S be FilterCARD-FILM1-of X }"
         sorry
      have "{S where S be Subset-FamilySETFAM-1M1-of X : ?P(S) } be Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 X"
        using domain_1_sch_7 sorry
      thus "{S where S be Subset-FamilySETFAM-1M1-of X : S be FilterCARD-FILM1-of X } be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of boolSETFAM-1K9 X"
        using A1 sorry
    qed
qed "sorry"

mtheorem card_fil_th_15:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be setHIDDENM2 holds S inTARSKIR2 FiltersCARD-FILK4 X iff S be FilterCARD-FILM1-of X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for S be setHIDDENM2 holds (S inTARSKIR2 FiltersCARD-FILK4 X implies S be FilterCARD-FILM1-of X) & (S be FilterCARD-FILM1-of X implies S inTARSKIR2 FiltersCARD-FILK4 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix S assume [ty]: "S be setHIDDENM2"
    show "S inTARSKIR2 FiltersCARD-FILK4 X implies S be FilterCARD-FILM1-of X"
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. Lamb1 be FilterCARD-FILM1-of X"
      assume "S inTARSKIR2 FiltersCARD-FILK4 X"
      then have A1: "S inTARSKIR2 {S1 where S1 be Subset-FamilySETFAM-1M1-of X : ?P(S1) }"
         sorry
      show "S be FilterCARD-FILM1-of X"
        using card_fil_sch_1 A1 sorry
    qed
    assume "S be FilterCARD-FILM1-of X"
    thus "S inTARSKIR2 FiltersCARD-FILK4 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve FS for " non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X"
mtheorem card_fil_th_16:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for FS be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X holds FS be c=-linearORDINAL1V6 implies unionTARSKIK3 FS be FilterCARD-FILM1-of X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for FS be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X holds FS be c=-linearORDINAL1V6 implies unionTARSKIK3 FS be FilterCARD-FILM1-of X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix FS assume [ty]: "FS be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X"
    have A1: " for S be setHIDDENM2 holds S inTARSKIR2 FS implies S c=TARSKIR1 boolSETFAM-1K9 X"
    proof(rule ballI,rule impI)
      fix S assume [ty]: "S be setHIDDENM2"
      assume "S inTARSKIR2 FS"
      then have "S be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 (boolSETFAM-1K9 X))\<^esub>-of FiltersCARD-FILK4 X"
         sorry
      thus "S c=TARSKIR1 boolSETFAM-1K9 X"
         sorry
    qed "sorry"
    obtain S where
      [ty]:"S be objectHIDDENM1" and 
      A2: "S inHIDDENR3 FS"
      using xboole_0_def_1 sorry
    assume A3: "FS be c=-linearORDINAL1V6"
    have A4: " for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 unionTARSKIK3 FS & Y2 inTARSKIR2 unionTARSKIK3 FS implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 unionTARSKIK3 FS) & (Y1 inTARSKIR2 unionTARSKIK3 FS & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 unionTARSKIK3 FS)"
    proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
      fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of X"
      fix Y2 assume [ty]: "Y2 be SubsetSUBSET-1M2-of X"
      show "Y1 inTARSKIR2 unionTARSKIK3 FS & Y2 inTARSKIR2 unionTARSKIK3 FS implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 unionTARSKIK3 FS"
      proof(rule impMI ,rule impI)
        assume A5: "Y1 inTARSKIR2 unionTARSKIK3 FS"
          and A6: "Y2 inTARSKIR2 unionTARSKIK3 FS"
        obtain S1 where
          [ty]:"S1 be setHIDDENM2" and 
          A7: "Y1 inTARSKIR2 S1"and A8: "S1 inTARSKIR2 FS"
          using A5 tarski_def_4 sorry
        have A9: "S1 be FilterCARD-FILM1-of X"
          using A8 card_fil_th_15 sorry
        obtain S2 where
          [ty]:"S2 be setHIDDENM2" and 
          A10: "Y2 inTARSKIR2 S2"and A11: "S2 inTARSKIR2 FS"
          using A6 tarski_def_4 sorry
        have A12: "(S1,S2)are-c=-comparableXBOOLE-0R3"
          using A3 A8 A11 sorry
        have A13: "S2 be FilterCARD-FILM1-of X"
          using A11 card_fil_th_15 sorry
        show "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 unionTARSKIK3 FS"
        proof-
          have cases: "S1 c=TARSKIR1 S2 or S2 c=TARSKIR1 S1"
            using A12 sorry
          have case1: "S1 c=TARSKIR1 S2 implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 unionTARSKIK3 FS"
          proof(rule impI)
            assume "S1 c=TARSKIR1 S2"
            then have "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 S2"
              using A7 A10 A13 card_fil_def_1 sorry
            thus "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 unionTARSKIK3 FS"
              using A11 tarski_def_4 sorry
          qed
          have case2: "S2 c=TARSKIR1 S1 implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 unionTARSKIK3 FS"
          proof(rule impI)
            assume "S2 c=TARSKIR1 S1"
            then have "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 S1"
              using A7 A10 A9 card_fil_def_1 sorry
            thus "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 unionTARSKIK3 FS"
              using A8 tarski_def_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      assume A14: "Y1 inTARSKIR2 unionTARSKIK3 FS"
        and A15: "Y1 c=TARSKIR1 Y2"
      obtain S1 where
        [ty]:"S1 be setHIDDENM2" and 
        A16: "Y1 inTARSKIR2 S1"and A17: "S1 inTARSKIR2 FS"
        using A14 tarski_def_4 sorry
      have "S1 be FilterCARD-FILM1-of X"
        using A17 card_fil_th_15 sorry
      then have "Y2 inTARSKIR2 S1"
        using A15 A16 card_fil_def_1 sorry
      thus "Y2 inTARSKIR2 unionTARSKIK3 FS"
        using A17 tarski_def_4 sorry
    qed "sorry"
    have A18: " not {}XBOOLE-0K1 inTARSKIR2 unionTARSKIK3 FS"
    proof-
      have "{}XBOOLE-0K1 inTARSKIR2 unionTARSKIK3 FS implies  False "
      proof(rule impI)
        assume "{}XBOOLE-0K1 inTARSKIR2 unionTARSKIK3 FS"
        then obtain S where
          [ty]:"S be setHIDDENM2" and 
          A19: "{}XBOOLE-0K1 inTARSKIR2 S"and A20: "S inTARSKIR2 FS"
          using tarski_def_4 sorry
        have "S be FilterCARD-FILM1-of X"
          using A20 card_fil_th_15 sorry
        thus " False "
          using A19 card_fil_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have 
      [ty]:"S be setHIDDENM2"
      using tarski_th_1 sorry
    have "S be FilterCARD-FILM1-of X"
      using A2 card_fil_th_15 sorry
    then have "X inTARSKIR2 S"
      using card_fil_th_5 sorry
    then have "unionTARSKIK3 FS be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X"
      using A1 A2 tarski_def_4 zfmisc_1_th_76 sorry
    thus "unionTARSKIK3 FS be FilterCARD-FILM1-of X"
      using A18 A4 card_fil_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_17:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  ex Uf be FilterCARD-FILM1-of X st F c=TARSKIR1 Uf & Uf be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds  ex tVar7 be FilterCARD-FILM1-of X st F c=TARSKIR1 tVar7 & tVar7 be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    let ?LargerF = "{S where S be Subset-FamilySETFAM-1M1-of X : F c=TARSKIR1 S & S be FilterCARD-FILM1-of X }"
    have A1: "F inTARSKIR2 ?LargerF"
       sorry
    have "{S where S be Subset-FamilySETFAM-1M1-of X : F c=TARSKIR1 S & S be FilterCARD-FILM1-of X } c=TARSKIR1 FiltersCARD-FILK4 X"
    proof-
      have "{S where S be Subset-FamilySETFAM-1M1-of X : F c=TARSKIR1 S & S be FilterCARD-FILM1-of X } c=TARSKIR1 FiltersCARD-FILK4 X"
      proof-
        let ?P = "\<lambda>Lamb1. F c=TARSKIR1 Lamb1 & Lamb1 be FilterCARD-FILM1-of X"
        have " for F2 be objectHIDDENM1 holds F2 inHIDDENR3 {S where S be Subset-FamilySETFAM-1M1-of X : F c=TARSKIR1 S & S be FilterCARD-FILM1-of X } implies F2 inHIDDENR3 FiltersCARD-FILK4 X"
        proof(rule ballI,rule impI)
          fix F2 assume [ty]: "F2 be objectHIDDENM1"
          obtain FF where 
            [ty]:"FF be setHIDDENM2" and FFDef:"FF = F2"
            using tarski_th_1 sorry
          assume "F2 inHIDDENR3 {S where S be Subset-FamilySETFAM-1M1-of X : F c=TARSKIR1 S & S be FilterCARD-FILM1-of X }"
          then have A2: "FF inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of X : ?P(S) }"
             sorry
          have "?P(FF)"
            using card_fil_sch_1 A2 sorry
          thus "F2 inHIDDENR3 FiltersCARD-FILK4 X"
             sorry
        qed "sorry"
        thus "{S where S be Subset-FamilySETFAM-1M1-of X : F c=TARSKIR1 S & S be FilterCARD-FILM1-of X } c=TARSKIR1 FiltersCARD-FILK4 X"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain LargerF where 
      [ty]:"LargerF be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X" and LargerFDef:"LargerF = ?LargerF"
      using A1 sorry
    let ?P = "\<lambda>Lamb1. F c=TARSKIR1 Lamb1 & Lamb1 be FilterCARD-FILM1-of X"
    have " for Z be setHIDDENM2 holds Z c=TARSKIR1 LargerF & Z be c=-linearORDINAL1V6 implies ( ex Y be setHIDDENM2 st Y inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 Z implies X1 c=TARSKIR1 Y))"
    proof-
      have " for X1 be setHIDDENM2 holds X1 c=TARSKIR1 LargerF & X1 be c=-linearORDINAL1V6 implies ( ex tVar5 be setHIDDENM2 st tVar5 inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 tVar5)))"
      proof(rule ballI,rule impMI ,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        assume A3: "X1 c=TARSKIR1 LargerF"
          and A4: "X1 be c=-linearORDINAL1V6"
        show " ex tVar5 be setHIDDENM2 st tVar5 inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 tVar5))"
        proof-
          have cases: "X1 =XBOOLE-0R4 {}XBOOLE-0K1 or X1 be  non emptyXBOOLE-0V1"
             sorry
          have case1: "X1 =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar5 be setHIDDENM2 st tVar5 inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 tVar5)))"
          proof(rule impI)
            assume A5: "X1 =XBOOLE-0R4 {}XBOOLE-0K1"
            show " ex tVar5 be setHIDDENM2 st tVar5 inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 tVar5))"
            proof(rule bexI[of _ "F"])
              show "F inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 F))"
                using A5 sorry
            qed "sorry"
          qed
          have case2: "X1 be  non emptyXBOOLE-0V1 implies ( ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 tVar6)))"
          proof(rule impI)
            assume "X1 be  non emptyXBOOLE-0V1"
            then obtain X2 where 
              [ty]:"X2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of FiltersCARD-FILK4 X" and X2Def:"X2 = X1"
              using A3 xboole_1_th_1 sorry
            have A6: "F c=TARSKIR1 unionTARSKIK3 X2"
            proof-
              let ?P = "\<lambda>Lamb1. F c=TARSKIR1 Lamb1 & Lamb1 be FilterCARD-FILM1-of X"
              obtain F1 where
                [ty]:"F1 be objectHIDDENM1" and 
                A7: "F1 inHIDDENR3 X2"
                using xboole_0_def_1 sorry
              have 
                [ty]:"F1 be setHIDDENM2"
                using tarski_th_1 sorry
              have A8: "F1 inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of X : ?P(S) }"
                using A3 A7 sorry
              have A9: "?P(F1)"
                using card_fil_sch_1 A8 sorry
              have "F1 c=TARSKIR1 unionTARSKIK3 X2"
                using A7 zfmisc_1_th_74 sorry
              thus "F c=TARSKIR1 unionTARSKIK3 X2"
                using A9 sorry
            qed
            have "unionTARSKIK3 X2 be FilterCARD-FILM1-of X"
              using A4 card_fil_th_16 sorry
            then have "unionTARSKIK3 X2 inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of X : F c=TARSKIR1 S & S be FilterCARD-FILM1-of X }"
              using A6 sorry
            then obtain MF where 
              [ty]:"MF be ElementSUBSET-1M3\<^bsub>(FiltersCARD-FILK4 X)\<^esub>-of LargerF" and MFDef:"MF = unionTARSKIK3 X2"
               sorry
            show " ex tVar6 be setHIDDENM2 st tVar6 inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 tVar6))"
            proof(rule bexI[of _ "MF"])
              show "MF inTARSKIR2 LargerF & ( for X1 be setHIDDENM2 holds  not (X1 inTARSKIR2 X1 &  not X1 c=TARSKIR1 MF))"
                using zfmisc_1_th_74 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then obtain Uf1 where
      [ty]:"Uf1 be setHIDDENM2" and 
      A10: "Uf1 inTARSKIR2 LargerF"and A11: " for Z be setHIDDENM2 holds Z inTARSKIR2 LargerF & Z <>HIDDENR2 Uf1 implies  not Uf1 c=TARSKIR1 Z"
      using orders_1_th_65 sorry
    have 
      [ty]:"Uf1 be ElementSUBSET-1M3\<^bsub>(FiltersCARD-FILK4 X)\<^esub>-of LargerF"
      using A10 sorry
    obtain Uf where 
      [ty]:"Uf be FilterCARD-FILM1-of X" and UfDef:"Uf = Uf1"
      using card_fil_th_15 sorry
    show " ex tVar7 be FilterCARD-FILM1-of X st F c=TARSKIR1 tVar7 & tVar7 be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
    proof(rule bexI[of _ "Uf"],rule conjMI)
      have A12: "Uf inTARSKIR2 {S where S be Subset-FamilySETFAM-1M1-of X : ?P(S) }"
         sorry
      have A13: "?P(Uf)"
        using card_fil_sch_1 A12 sorry
      thus "F c=TARSKIR1 Uf"
         sorry
      show "Uf be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
      proof-
        have " for Z be SubsetSUBSET-1M2-of X holds  not ( not Z inTARSKIR2 Uf &  not X \\SUBSET-1K6 Z inTARSKIR2 Uf)"
        proof(rule ballI)
          fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of X"
          show " not ( not Z inTARSKIR2 Uf &  not X \\SUBSET-1K6 Z inTARSKIR2 Uf)"
          proof-
            have cases: "Z inTARSKIR2 Uf or  not Z inTARSKIR2 Uf"
               sorry
            have case1: "Z inTARSKIR2 Uf implies  not ( not Z inTARSKIR2 Uf &  not X \\SUBSET-1K6 Z inTARSKIR2 Uf)"
            proof(rule impI)
              assume "Z inTARSKIR2 Uf"
              thus " not ( not Z inTARSKIR2 Uf &  not X \\SUBSET-1K6 Z inTARSKIR2 Uf)"
                 sorry
            qed
            have case2: " not Z inTARSKIR2 Uf implies  not ( not Z inTARSKIR2 Uf &  not X \\SUBSET-1K6 Z inTARSKIR2 Uf)"
            proof(rule impI)
              assume A14: " not Z inTARSKIR2 Uf"
              have "X \\SUBSET-1K6 Z inTARSKIR2 Uf"
              proof-
                have " not X \\SUBSET-1K6 Z inTARSKIR2 Uf implies  False "
                proof(rule impI)
                  assume A15: " not X \\SUBSET-1K6 Z inTARSKIR2 Uf"
                  have A16: " for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 Uf implies Y1 meetsXBOOLE-0R5 Z"
                  proof-
                    have " for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 Uf implies (Y1 missesXBOOLE-0R1 Z implies  False )"
                    proof(rule ballI,rule impI,rule impI)
                      fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of X"
                      assume A17: "Y1 inTARSKIR2 Uf"
                      assume "Y1 missesXBOOLE-0R1 Z"
                      then have "Y1 =XBOOLE-0R4 Y1 \\SUBSET-1K7\<^bsub>(X)\<^esub> Z"
                        using xboole_1_th_83 sorry
                      then have "Y1 c=TARSKIR1 X \\SUBSET-1K6 Z"
                        using xboole_1_th_33 sorry
                      thus " False "
                        using A15 A17 card_fil_def_1 sorry
                    qed "sorry"
                    thus " ?thesis "
                       sorry
                  qed
                  then have A18: "Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(Uf,Z) be FilterCARD-FILM1-of X"
                    using card_fil_th_14 sorry
                  have A19: "Z inTARSKIR2 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(Uf,Z)"
                    using A16 card_fil_th_14 sorry
                  have A20: "Uf c=TARSKIR1 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(Uf,Z)"
                    using A16 card_fil_th_14 sorry
                  then have "F c=TARSKIR1 Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(Uf,Z)"
                    using A13 sorry
                  then have "Extend-FilterCARD-FILK3\<^bsub>(X)\<^esub>(Uf,Z) inTARSKIR2 LargerF"
                    using A18 sorry
                  thus " False "
                    using A11 A14 A20 A19 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus " not ( not Z inTARSKIR2 Uf &  not X \\SUBSET-1K6 Z inTARSKIR2 Uf)"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "Uf be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
          using card_fil_def_7 sorry
      qed
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve X for "infiniteFINSET-1V2\<bar>setHIDDENM2"
reserve Y, Y1, Y2, Z for "SubsetSUBSET-1M2-of X"
reserve F, Uf for "FilterCARD-FILM1-of X"
mdef card_fil_def_10 ("Frechet-FilterCARD-FILK5  _ " [164]164 ) where
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"func Frechet-FilterCARD-FILK5 X \<rightarrow> FilterCARD-FILM1-of X equals
  {Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X }"
proof-
  (*coherence*)
    show "{Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X } be FilterCARD-FILM1-of X"
    proof-
      have "{Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X } be FilterCARD-FILM1-of X"
      proof-
        let ?P = "\<lambda>Lamb1. cardCARD-1K1 (X \\SUBSET-1K6 Lamb1) inTARSKIR2 cardCARD-1K1 X"
        let ?IT = "{Y where Y be SubsetSUBSET-1M2-of X : ?P(Y) }"
        have A1: "?IT be Subset-FamilySETFAM-1M1-of X"
          using domain_1_sch_7 sorry
        have "cardCARD-1K1 (X \\SUBSET-1K6 X) =HIDDENR1 cardCARD-1K4 ({}XBOOLE-0K1)"
          using xboole_1_th_37 sorry
        also have "... = 0ORDINAL1K5"
           sorry
        finally have "cardCARD-1K1 (X \\SUBSET-1K6 X) =HIDDENR1 0ORDINAL1K5"
           sorry
        then have A2: "cardCARD-1K1 (X \\SUBSET-1K6 X) inTARSKIR2 cardCARD-1K1 X"
          using ordinal3_th_8 sorry
        have "X c=TARSKIR1 X"
           sorry
        then have "X inTARSKIR2 ?IT"
          using A2 sorry
        then obtain IT where 
          [ty]:"IT be  non emptyXBOOLE-0V1\<bar>Subset-FamilySETFAM-1M1-of X" and ITDef:"IT = ?IT"
          using A1 sorry
        have A3: " for Y1 be SubsetSUBSET-1M2-of X holds Y1 inTARSKIR2 IT implies cardCARD-1K1 (X \\SUBSET-1K6 Y1) inTARSKIR2 cardCARD-1K1 X"
        proof(rule ballI,rule impI)
          fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of X"
          assume "Y1 inTARSKIR2 IT"
          then have A4: "Y1 inTARSKIR2 {Y where Y be SubsetSUBSET-1M2-of X : ?P(Y) }"
             sorry
          show "cardCARD-1K1 (X \\SUBSET-1K6 Y1) inTARSKIR2 cardCARD-1K1 X"
            using card_fil_sch_1 A4 sorry
        qed "sorry"
        have "IT be FilterCARD-FILM1-of X"
        proof-
          have " not {}XBOOLE-0K1 inTARSKIR2 IT & ( for Y1 be SubsetSUBSET-1M2-of X holds  for Y2 be SubsetSUBSET-1M2-of X holds (Y1 inTARSKIR2 IT & Y2 inTARSKIR2 IT implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 IT) & (Y1 inTARSKIR2 IT & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 IT))"
          proof(rule conjMI,rule ballI,rule ballI,rule conjMI)
            show " not {}XBOOLE-0K1 inTARSKIR2 IT"
            proof-
              have "{}XBOOLE-0K1 inTARSKIR2 IT implies  False "
              proof(rule impI)
                assume "{}XBOOLE-0K1 inTARSKIR2 IT"
                then have "cardCARD-1K1 (X \\SUBSET-1K6 {}XBOOLE-0K1) inTARSKIR2 cardCARD-1K1 X"
                  using A3 sorry
                thus " False "
                   sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            fix Y1 assume [ty]: "Y1 be SubsetSUBSET-1M2-of X"
            fix Y2 assume [ty]: "Y2 be SubsetSUBSET-1M2-of X"
            show "Y1 inTARSKIR2 IT & Y2 inTARSKIR2 IT implies Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 IT"
            proof(rule impI)
              assume "Y1 inTARSKIR2 IT & Y2 inTARSKIR2 IT"
              then have "cardCARD-1K1 (X \\SUBSET-1K6 Y1) inTARSKIR2 cardCARD-1K1 X & cardCARD-1K1 (X \\SUBSET-1K6 Y2) inTARSKIR2 cardCARD-1K1 X"
                using A3 sorry
              then have "cardCARD-1K1 (X \\SUBSET-1K6 Y1) +`CARD-2K1 cardCARD-1K1 (X \\SUBSET-1K6 Y2) inTARSKIR2 cardCARD-1K1 X +`CARD-2K1 cardCARD-1K1 X"
                using card_2_th_96 sorry
              then have A5: "cardCARD-1K1 (X \\SUBSET-1K6 Y1) +`CARD-2K1 cardCARD-1K1 (X \\SUBSET-1K6 Y2) inTARSKIR2 cardCARD-1K1 X"
                using card_2_th_75 sorry
              have "cardCARD-1K1 (X \\SUBSET-1K6 Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2) =XBOOLE-0R4 cardCARD-1K1 ((X \\SUBSET-1K6 Y1)\\/SUBSET-1K4\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Y2))"
                using xboole_1_th_54 sorry
              then have "cardCARD-1K1 (X \\SUBSET-1K6 Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2) inTARSKIR2 cardCARD-1K1 X"
                using A5 card_2_th_34 ordinal1_th_12 sorry
              thus "Y1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y2 inTARSKIR2 IT"
                 sorry
            qed
            show "Y1 inTARSKIR2 IT & Y1 c=TARSKIR1 Y2 implies Y2 inTARSKIR2 IT"
            proof(rule impI)
              assume "Y1 inTARSKIR2 IT & Y1 c=TARSKIR1 Y2"
              then have "cardCARD-1K1 (X \\SUBSET-1K6 Y1) inTARSKIR2 cardCARD-1K1 X & X \\SUBSET-1K6 Y2 c=TARSKIR1 X \\SUBSET-1K6 Y1"
                using A3 xboole_1_th_34 sorry
              then have "cardCARD-1K1 (X \\SUBSET-1K6 Y2) inTARSKIR2 cardCARD-1K1 X"
                using card_1_th_11 ordinal1_th_12 sorry
              thus "Y2 inTARSKIR2 IT"
                 sorry
            qed
          qed "sorry"
          thus "IT be FilterCARD-FILM1-of X"
            using card_fil_def_1 sorry
        qed
        thus "{Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X } be FilterCARD-FILM1-of X"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef card_fil_def_11 ("Frechet-IdealCARD-FILK6  _ " [164]164 ) where
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"func Frechet-IdealCARD-FILK6 X \<rightarrow> IdealCARD-FILM2-of X equals
  dualCARD-FILK2\<^bsub>(X)\<^esub> (Frechet-FilterCARD-FILK5 X)"
proof-
  (*coherence*)
    show "dualCARD-FILK2\<^bsub>(X)\<^esub> (Frechet-FilterCARD-FILK5 X) be IdealCARD-FILM2-of X"
       sorry
qed "sorry"

mtheorem card_fil_th_18:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 Frechet-FilterCARD-FILK5 X iff cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X"
proof-
  have " for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds (Y inTARSKIR2 Frechet-FilterCARD-FILK5 X implies cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X) &  not (cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X &  not Y inTARSKIR2 Frechet-FilterCARD-FILK5 X)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
    show "Y inTARSKIR2 Frechet-FilterCARD-FILK5 X implies cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X"
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. cardCARD-1K1 (X \\SUBSET-1K6 Lamb1) inTARSKIR2 cardCARD-1K1 X"
      assume "Y inTARSKIR2 Frechet-FilterCARD-FILK5 X"
      then have A1: "Y inTARSKIR2 {Y1 where Y1 be SubsetSUBSET-1M2-of X : ?P(Y1) }"
         sorry
      show "cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X"
        using card_fil_sch_1 A1 sorry
    qed
    show " not (cardCARD-1K1 (X \\SUBSET-1K6 Y) inTARSKIR2 cardCARD-1K1 X &  not Y inTARSKIR2 Frechet-FilterCARD-FILK5 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_19:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 Frechet-IdealCARD-FILK6 X iff cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X"
proof-
  have " for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of X holds  not (Y inTARSKIR2 Frechet-IdealCARD-FILK6 X &  not cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X) &  not (cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X &  not Y inTARSKIR2 Frechet-IdealCARD-FILK6 X)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
    have "Y inTARSKIR2 Frechet-IdealCARD-FILK6 X iff Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 Frechet-FilterCARD-FILK5 X"
      using setfam_1_def_7 sorry
    then have "Y inTARSKIR2 Frechet-IdealCARD-FILK6 X iff cardCARD-1K1 (Y `SUBSET-1K3\<^bsub>(X)\<^esub>)`SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 cardCARD-1K1 X"
      using card_fil_th_18 sorry
    thus " not (Y inTARSKIR2 Frechet-IdealCARD-FILK6 X &  not cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X) &  not (cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X &  not Y inTARSKIR2 Frechet-IdealCARD-FILK6 X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_20:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds Frechet-FilterCARD-FILK5 X c=TARSKIR1 F implies F be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
proof-
  have " for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds Frechet-FilterCARD-FILK5 X c=TARSKIR1 F implies F be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    assume A1: "Frechet-FilterCARD-FILK5 X c=TARSKIR1 F"
    have " for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F implies cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
    proof(rule ballI,rule impI)
      fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
      assume "Y inTARSKIR2 F"
      then have " not X \\SUBSET-1K6 Y inTARSKIR2 Frechet-FilterCARD-FILK5 X"
        using A1 card_fil_th_6 sorry
      then have A2: " not cardCARD-1K1 (X \\SUBSET-1K6 (X \\SUBSET-1K6 Y)) inTARSKIR2 cardCARD-1K1 X"
         sorry
      have A3: "cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X"
        using card_1_th_11 sorry
      have "X \\SUBSET-1K6 (X \\SUBSET-1K6 Y) =HIDDENR1 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> Y"
        using xboole_1_th_48 sorry
      also have "... = Y"
        using xboole_1_th_28 sorry
      finally have "X \\SUBSET-1K6 (X \\SUBSET-1K6 Y) =HIDDENR1 Y"
         sorry
      then have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
        using A2 card_1_th_4 sorry
      thus "cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
        using A3 sorry
    qed "sorry"
    thus "F be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
      using card_fil_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_21:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Uf be FilterCARD-FILM1-of X holds Uf be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> implies Frechet-FilterCARD-FILK5 X c=TARSKIR1 Uf"
proof-
  have " for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for Uf be FilterCARD-FILM1-of X holds Uf be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> implies Frechet-FilterCARD-FILK5 X c=TARSKIR1 Uf"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
    fix Uf assume [ty]: "Uf be FilterCARD-FILM1-of X"
    assume A1: "Uf be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
    show "Frechet-FilterCARD-FILK5 X c=TARSKIR1 Uf"
    proof-
      have " for Y be objectHIDDENM1 holds Y inHIDDENR3 Frechet-FilterCARD-FILK5 X implies Y inHIDDENR3 Uf"
      proof(rule ballI,rule impI)
        fix Y assume [ty]: "Y be objectHIDDENM1"
        obtain YY where 
          [ty]:"YY be setHIDDENM2" and YYDef:"YY = Y"
          using tarski_th_1 sorry
        assume A2: "Y inHIDDENR3 Frechet-FilterCARD-FILK5 X"
        then have "cardCARD-1K1 (X \\SUBSET-1K6 YY) inTARSKIR2 cardCARD-1K1 X"
          using card_fil_th_18 sorry
        then have "cardCARD-1K1 (X \\SUBSET-1K6 YY) <>HIDDENR2 cardCARD-1K1 X"
           sorry
        then have " not X \\SUBSET-1K6 YY inTARSKIR2 Uf"
          using A1 sorry
        thus "Y inHIDDENR3 Uf"
          using A1 A2 sorry
      qed "sorry"
      thus "Frechet-FilterCARD-FILK5 X c=TARSKIR1 Uf"
        using tarski_def_3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_cl_2:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X"
proof
(*existence*)
  show " ex it be FilterCARD-FILM1-of X st it be  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
  proof-
    have " ex tVar8 be FilterCARD-FILM1-of X st  not tVar8 be principalCARD-FILV2\<^bsub>(X)\<^esub> & tVar8 be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
    proof-
      obtain Uf where
        [ty]:"Uf be FilterCARD-FILM1-of X" and 
        A1: "Frechet-FilterCARD-FILK5 X c=TARSKIR1 Uf"and A2: "Uf be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
        using card_fil_th_17 sorry
      show " ex tVar8 be FilterCARD-FILM1-of X st  not tVar8 be principalCARD-FILV2\<^bsub>(X)\<^esub> & tVar8 be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
      proof(rule bexI[of _ "Uf"])
        have A3: "Uf be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
          using A1 card_fil_th_20 sorry
        have "Uf be  non principalCARD-FILV2\<^bsub>(X)\<^esub>"
        proof-
          have "Uf be principalCARD-FILV2\<^bsub>(X)\<^esub> implies  False "
          proof(rule impI)
            assume "Uf be principalCARD-FILV2\<^bsub>(X)\<^esub>"
            then obtain Y where
              [ty]:"Y be SubsetSUBSET-1M2-of X" and 
              A4: "Y inTARSKIR2 Uf"and A5: " for Z be SubsetSUBSET-1M2-of X holds Z inTARSKIR2 Uf implies Y c=TARSKIR1 Z"
               sorry
            have A6: " for x be ElementSUBSET-1M1-of X holds X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 Uf"
            proof-
              have " for x be ElementSUBSET-1M1-of X holds  not X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 Uf implies  False "
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
                have A7: "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K4 {TARSKIK1 x}"
                   sorry
                have "{TARSKIK1 x} be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of X"
                  using subset_1_th_33 sorry
                then have A8: "X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 Uf or {TARSKIK1 x} inTARSKIR2 Uf"
                  using A2 sorry
                assume " not X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 Uf"
                thus " False "
                  using A3 A8 A7 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have A9: " for x be ElementSUBSET-1M1-of X holds  not x inTARSKIR2 Y"
            proof-
              have " for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 Y implies  False "
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
                assume A10: "x inTARSKIR2 Y"
                have "Y c=TARSKIR1 X \\SUBSET-1K6 {TARSKIK1 x}"
                  using A5 A6 sorry
                then have " not x inTARSKIR2 {TARSKIK1 x}"
                  using A10 xboole_0_def_5 sorry
                thus " False "
                  using tarski_def_1 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have "Y =XBOOLE-0R4 {}XBOOLE-0K1"
            proof-
              have "Y <>HIDDENR2 {}XBOOLE-0K1 implies  False "
              proof(rule impI)
                assume "Y <>HIDDENR2 {}XBOOLE-0K1"
                then have " ex x be objectHIDDENM1 st x inHIDDENR3 Y"
                  using xboole_0_def_1 sorry
                thus " False "
                  using A9 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            thus " False "
              using A4 card_fil_def_1 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not Uf be principalCARD-FILV2\<^bsub>(X)\<^esub> & Uf be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
          using A2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_fil_cl_3:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> also-is  non principalCARD-FILV2\<^bsub>(X)\<^esub> for FilterCARD-FILM1-of X"
proof
(*coherence*)
  show " for it be FilterCARD-FILM1-of X holds it be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> implies it be  non principalCARD-FILV2\<^bsub>(X)\<^esub>"
  proof-
    have " for F be FilterCARD-FILM1-of X holds F be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> implies (F be principalCARD-FILV2\<^bsub>(X)\<^esub> implies  False )"
    proof(rule ballI,rule impI,rule impI)
      fix F assume [ty]: "F be FilterCARD-FILM1-of X"
      assume A1: "F be uniformCARD-FILV1\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
      assume "F be principalCARD-FILV2\<^bsub>(X)\<^esub>"
      then obtain Y where
        [ty]:"Y be SubsetSUBSET-1M2-of X" and 
        A2: "Y inTARSKIR2 F"and A3: " for Z be SubsetSUBSET-1M2-of X holds Z inTARSKIR2 F implies Y c=TARSKIR1 Z"
         sorry
      have "Y =XBOOLE-0R4 {}XBOOLE-0K1"
      proof-
        have "Y <>HIDDENR2 {}XBOOLE-0K1 implies  False "
        proof(rule impI)
          assume "Y <>HIDDENR2 {}XBOOLE-0K1"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A4: "x inHIDDENR3 Y"
            using xboole_0_def_1 sorry
          have A5: " for Z be SubsetSUBSET-1M2-of X holds Z inTARSKIR2 F implies x inHIDDENR3 Z"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of X"
            assume "Z inTARSKIR2 F"
            then have "Y c=TARSKIR1 Z"
              using A3 sorry
            thus "x inHIDDENR3 Z"
              using A4 sorry
          qed "sorry"
          have "cardCARD-1K4 {TARSKIK1 x} inTARSKIR2 cardCARD-1K1 X"
            using card_3_th_86 sorry
          then have A6: " not {TARSKIK1 x} inTARSKIR2 F"
            using A1 sorry
          have "{TARSKIK1 x} be SubsetSUBSET-1M2-of X"
            using A4 subset_1_th_33 sorry
          then have "X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 F"
            using A1 A6 sorry
          then have "x inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x}"
            using A5 sorry
          then have " not x inHIDDENR3 {TARSKIK1 x}"
            using xboole_0_def_5 sorry
          thus " False "
            using tarski_def_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " False "
        using A2 card_fil_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_fil_th_22:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>\<bar>FilterCARD-FILM1-of X holds  for Y be SubsetSUBSET-1M2-of X holds Y inTARSKIR2 F iff  not Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F"
proof-
  have " for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>\<bar>FilterCARD-FILM1-of X holds  for Y be SubsetSUBSET-1M2-of X holds (Y inTARSKIR2 F implies  not Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F) & ( not Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F implies Y inTARSKIR2 F)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
    fix F assume [ty]: "F be being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>\<bar>FilterCARD-FILM1-of X"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of X"
    show "Y inTARSKIR2 F implies  not Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F"
    proof(rule impI)
      assume "Y inTARSKIR2 F"
      then have " not Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
        using card_fil_th_6 sorry
      thus " not Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F"
        using setfam_1_def_7 sorry
    qed
    assume " not Y inTARSKIR2 dualCARD-FILK2\<^bsub>(X)\<^esub> F"
    then have " not Y `SUBSET-1K3\<^bsub>(X)\<^esub> inTARSKIR2 F"
      using setfam_1_def_7 sorry
    thus "Y inTARSKIR2 F"
      using card_fil_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve x for "ElementSUBSET-1M1-of X"
mtheorem card_fil_th_23:
" for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds F be  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> & F is-complete-withCARD-FILR3\<^bsub>(X)\<^esub> cardCARD-1K1 X implies F be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
proof-
  have " for X be infiniteFINSET-1V2\<bar>setHIDDENM2 holds  for F be FilterCARD-FILM1-of X holds F be  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub> implies (F is-complete-withCARD-FILR3\<^bsub>(X)\<^esub> cardCARD-1K1 X implies ( not F be uniformCARD-FILV1\<^bsub>(X)\<^esub> implies  False ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix X assume [ty]: "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
    fix F assume [ty]: "F be FilterCARD-FILM1-of X"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be setHIDDENM2 st (A =HIDDENR1 Lamb2 &  not Lamb1 inHIDDENR3 A) & Lamb2 inHIDDENR3 F"
    assume A1: "F be  non principalCARD-FILV2\<^bsub>(X)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(X)\<^esub>"
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex Z be objectHIDDENM1 st Z inHIDDENR3 F & ?P(x,Z))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies (( for Z be objectHIDDENM1 holds Z inHIDDENR3 F implies  not ( ex A be setHIDDENM2 st (A =HIDDENR1 Z &  not x inHIDDENR3 A) & Z inHIDDENR3 F)) implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then have A3: "{TARSKIK1 x} be SubsetSUBSET-1M2-of X"
          using subset_1_th_33 sorry
        assume A4: " for Z be objectHIDDENM1 holds Z inHIDDENR3 F implies  not ?P(x,Z)"
        have " not X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 F"
        proof-
          have "X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 F implies  False "
          proof(rule impI)
            assume "X \\SUBSET-1K6 {TARSKIK1 x} inTARSKIR2 F"
            then have "x inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x}"
              using A4 sorry
            then have " not x inHIDDENR3 {TARSKIK1 x}"
              using xboole_0_def_5 sorry
            thus " False "
              using tarski_def_1 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have A5: "{TARSKIK1 x} inTARSKIR2 F"
          using A1 A3 sorry
        have " for Z be SubsetSUBSET-1M2-of X holds Z inTARSKIR2 F implies {TARSKIK1 x} c=TARSKIR1 Z"
          using A4 zfmisc_1_th_31 sorry
        thus " False "
          using A1 A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain h where
      [ty]:"h be FunctionFUNCT-1M1" and 
      A6: "domRELAT-1K1 h =XBOOLE-0R4 X"and "rngFUNCT-1K2 h c=TARSKIR1 F"and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ?P(x,h .FUNCT-1K1 x)"
      using funct_1_sch_6 A2 sorry
    assume A8: "F is-complete-withCARD-FILR3\<^bsub>(X)\<^esub> cardCARD-1K1 X"
    assume " not F be uniformCARD-FILV1\<^bsub>(X)\<^esub>"
    then obtain Y where
      [ty]:"Y be SubsetSUBSET-1M2-of X" and 
      A9: "Y inTARSKIR2 F"and A10: " not cardCARD-1K1 Y =XBOOLE-0R4 cardCARD-1K1 X"
       sorry
    have A11: "{h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } c=TARSKIR1 F"
    proof-
      have "{h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } c=TARSKIR1 F"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } implies y inHIDDENR3 F"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }"
          then obtain x where
            [ty]:"x be ElementSUBSET-1M1-of X" and 
            A12: "y =HIDDENR1 h .FUNCT-1K1 x & x inTARSKIR2 Y"
             sorry
          have "?P(x,h .FUNCT-1K1 x)"
            using A7 sorry
          then have " ex B be setHIDDENM2 st (B =XBOOLE-0R4 h .FUNCT-1K1 x &  not x inTARSKIR2 B) & h .FUNCT-1K1 x inTARSKIR2 F"
             sorry
          thus "y inHIDDENR3 F"
            using A12 sorry
        qed "sorry"
        thus "{h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } c=TARSKIR1 F"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for y be objectHIDDENM1 holds  not y inHIDDENR3 Y /\\SUBSET-1K8\<^bsub>(X)\<^esub> meetSETFAM-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y })"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y /\\SUBSET-1K8\<^bsub>(X)\<^esub> meetSETFAM-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }) implies  False "
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A13: "y inHIDDENR3 Y /\\SUBSET-1K8\<^bsub>(X)\<^esub> meetSETFAM-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y })"
        have "y inHIDDENR3 Y"
          using A13 xboole_0_def_4 sorry
        then have A14: "h .FUNCT-1K1 y inTARSKIR2 {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }"
           sorry
        have "y inHIDDENR3 h .FUNCT-1K1 y implies  False "
        proof(rule impI)
          assume A15: "y inHIDDENR3 h .FUNCT-1K1 y"
          have "?P(y,h .FUNCT-1K1 y)"
            using A7 A13 sorry
          then obtain A where
            [ty]:"A be setHIDDENM2" and 
            A16: "(A =XBOOLE-0R4 h .FUNCT-1K1 y &  not y inHIDDENR3 A) & h .FUNCT-1K1 y inTARSKIR2 F"
             sorry
          have " not y inHIDDENR3 h .FUNCT-1K1 y & h .FUNCT-1K1 y inTARSKIR2 F"
            using A16 sorry
          thus " False "
            using A15 sorry
        qed
        then have " not y inHIDDENR3 meetSETFAM-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y })"
          using A14 setfam_1_def_1 sorry
        thus " False "
          using A13 xboole_0_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A17: "Y /\\SUBSET-1K8\<^bsub>(X)\<^esub> meetSETFAM-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }) =XBOOLE-0R4 {}XBOOLE-0K1"
      using xboole_0_def_1 sorry
    have A18: "Y be  non emptyXBOOLE-0V1"
      using A9 card_fil_def_1 sorry
    have A19: "{h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } be  non emptyXBOOLE-0V1"
    proof-
      have " not {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } be emptyXBOOLE-0V1"
      proof-
        let ?y = "the ElementSUBSET-1M1-of Y"
        have "?y inTARSKIR2 Y"
          using A18 sorry
        then have "h .FUNCT-1K1 ?y inTARSKIR2 {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }"
           sorry
        thus " not {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } be emptyXBOOLE-0V1"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "{h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } c=TARSKIR1 h .:FUNCT-1K5 Y"
    proof-
      have "{h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } c=TARSKIR1 h .:FUNCT-1K5 Y"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } implies y inHIDDENR3 h .:FUNCT-1K5 Y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 {h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }"
          then have " ex x be ElementSUBSET-1M1-of X st y =HIDDENR1 h .FUNCT-1K1 x & x inTARSKIR2 Y"
             sorry
          thus "y inHIDDENR3 h .:FUNCT-1K5 Y"
            using A6 funct_1_def_6 sorry
        qed "sorry"
        thus "{h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y } c=TARSKIR1 h .:FUNCT-1K5 Y"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have A20: "cardCARD-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }) c=ORDINAL1R1 cardCARD-1K1 Y"
      using card_1_th_66 sorry
    have "cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 X"
      using card_1_th_11 sorry
    then have "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X"
      using A10 card_1_th_3 sorry
    then have "cardCARD-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }) inTARSKIR2 cardCARD-1K1 X"
      using A20 ordinal1_th_12 sorry
    then have "meetSETFAM-1K1 ({h .FUNCT-1K1 x where x be ElementSUBSET-1M1-of X : x inTARSKIR2 Y }) inTARSKIR2 F"
      using A8 A11 A19 sorry
    then have "{}XBOOLE-0K1 inTARSKIR2 F"
      using A9 A17 card_fil_def_1 sorry
    thus " False "
      using card_fil_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem card_fil_th_24:
" for N be CardinalCARD-1M1 holds nextcardCARD-1K2 N c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,N)"
proof-
  have " for N be CardinalCARD-1M1 holds nextcardCARD-1K2 N c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,N)"
  proof(rule ballI)
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have "cardCARD-1K1 N inTARSKIR2 expCARD-2K3(\<two>\<^sub>M,N)"
      using card_5_th_14 sorry
    thus "nextcardCARD-1K2 N c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,N)"
      using card_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_fil_def_12 ("GCHCARD-FILR5" 50 ) where
"pred GCHCARD-FILR5 means
   for N be AlephCARD-5M1 holds nextcardCARD-1K2 N =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,N)"..

mdef card_fil_def_13 ("inaccessibleCARD-FILV4" 70 ) where
"attr inaccessibleCARD-FILV4 for AlephCARD-5M1 means
  (\<lambda>IT. IT be regularCARD-5V1\<bar>limit-cardinalCARD-1V2)"..

mtheorem card_fil_cl_4:
"cluster inaccessibleCARD-FILV4 also-is regularCARD-5V1\<bar>limit-cardinalCARD-1V2 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be inaccessibleCARD-FILV4 implies it be regularCARD-5V1\<bar>limit-cardinalCARD-1V2"
     sorry
qed "sorry"

mtheorem card_fil_th_25:
"omegaORDINAL1K4 be inaccessibleCARD-FILV4"
  using card_5_th_30 sorry

mdef card_fil_def_14 ("strong-limitCARD-FILV5" 70 ) where
"attr strong-limitCARD-FILV5 for AlephCARD-5M1 means
  (\<lambda>IT.  for N be CardinalCARD-1M1 holds N inTARSKIR2 IT implies expCARD-2K3(\<two>\<^sub>M,N) inTARSKIR2 IT)"..

mtheorem card_fil_th_26:
"omegaORDINAL1K4 be strong-limitCARD-FILV5"
proof-
  have " for N be CardinalCARD-1M1 holds N inTARSKIR2 omegaORDINAL1K4 implies expCARD-2K3(\<two>\<^sub>M,N) inTARSKIR2 omegaORDINAL1K4"
  proof(rule ballI,rule impI)
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume "N inTARSKIR2 omegaORDINAL1K4"
    then have "cardCARD-1K1 (boolSETFAM-1K9 N) be finiteFINSET-1V1"
       sorry
    then have "expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 N) be finiteFINSET-1V1"
      using card_2_th_31 sorry
    then have "expCARD-2K3(\<two>\<^sub>M,N) be finiteFINSET-1V1"
       sorry
    thus "expCARD-2K3(\<two>\<^sub>M,N) inTARSKIR2 omegaORDINAL1K4"
      using card_1_th_61 sorry
  qed "sorry"
  thus "omegaORDINAL1K4 be strong-limitCARD-FILV5"
    using card_fil_def_14 sorry
qed

mtheorem card_fil_th_27:
" for M be AlephCARD-5M1 holds M be strong-limitCARD-FILV5 implies M be limit-cardinalCARD-1V2"
proof-
  have " for M be AlephCARD-5M1 holds M be strong-limitCARD-FILV5 implies ( not M be limit-cardinalCARD-1V2 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix M assume [ty]: "M be AlephCARD-5M1"
    assume A1: "M be strong-limitCARD-FILV5"
    assume " not M be limit-cardinalCARD-1V2"
    then obtain N where
      [ty]:"N be CardinalCARD-1M1" and 
      A2: "M =XBOOLE-0R4 nextcardCARD-1K2 N"
       sorry
    have "M c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,N)"
      using A2 card_fil_th_24 sorry
    then have A3: " not expCARD-2K3(\<two>\<^sub>M,N) inTARSKIR2 M"
      using card_1_th_4 sorry
    have "N inTARSKIR2 M"
      using A2 card_1_th_18 sorry
    thus " False "
      using A1 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_cl_5:
"cluster strong-limitCARD-FILV5 also-is limit-cardinalCARD-1V2 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be strong-limitCARD-FILV5 implies it be limit-cardinalCARD-1V2"
    using card_fil_th_27 sorry
qed "sorry"

mtheorem card_fil_th_28:
" for M be AlephCARD-5M1 holds GCHCARD-FILR5 implies (M be limit-cardinalCARD-1V2 implies M be strong-limitCARD-FILV5)"
proof-
  have " for M be AlephCARD-5M1 holds GCHCARD-FILR5 implies (M be limit-cardinalCARD-1V2 implies ( not M be strong-limitCARD-FILV5 implies  False ))"
  proof(rule ballI,rule impI,rule impI,rule impI)
    fix M assume [ty]: "M be AlephCARD-5M1"
    assume A1: "GCHCARD-FILR5"
    assume A2: "M be limit-cardinalCARD-1V2"
    assume " not M be strong-limitCARD-FILV5"
    then obtain N where
      [ty]:"N be CardinalCARD-1M1" and 
      A3: "N inTARSKIR2 M"and A4: " not expCARD-2K3(\<two>\<^sub>M,N) inTARSKIR2 M"
       sorry
    have A5: "nextcardCARD-1K2 N c=ORDINAL1R1 M"
      using A3 card_3_th_90 sorry
    have A6: "N be infiniteFINSET-1V2"
    proof-
      have "N be finiteFINSET-1V1 implies  not  True "
      proof(rule impI)
        assume "N be finiteFINSET-1V1"
        then have "FuncsFUNCT-2K1(N,\<two>\<^sub>M) be finiteFINSET-1V1"
          using fraenkel_th_6 sorry
        then have "cardCARD-1K1 (FuncsFUNCT-2K1(N,\<two>\<^sub>M)) be finiteFINSET-1V1"
           sorry
        then have "expCARD-2K3(\<two>\<^sub>M,N) be finiteFINSET-1V1"
          using card_2_def_3 sorry
        thus " not  True "
          using A4 card_3_th_86 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "M c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,N)"
      using A4 card_1_th_4 sorry
    then have "M c=ORDINAL1R1 nextcardCARD-1K2 N"
      using A1 A6 sorry
    then have "nextcardCARD-1K2 N =XBOOLE-0R4 M"
      using A5 sorry
    thus " False "
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_fil_def_15 ("strongly-inaccessibleCARD-FILV6" 70 ) where
"attr strongly-inaccessibleCARD-FILV6 for AlephCARD-5M1 means
  (\<lambda>IT. IT be regularCARD-5V1\<bar>strong-limitCARD-FILV5)"..

mtheorem card_fil_cl_6:
"cluster strongly-inaccessibleCARD-FILV6 also-is regularCARD-5V1\<bar>strong-limitCARD-FILV5 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be strongly-inaccessibleCARD-FILV6 implies it be regularCARD-5V1\<bar>strong-limitCARD-FILV5"
     sorry
qed "sorry"

mtheorem card_fil_th_29:
"omegaORDINAL1K4 be strongly-inaccessibleCARD-FILV6"
  using card_fil_th_26 card_5_th_30 sorry

mtheorem card_fil_th_30:
" for M be AlephCARD-5M1 holds M be strongly-inaccessibleCARD-FILV6 implies M be inaccessibleCARD-FILV4"
   sorry

mtheorem card_fil_cl_7:
"cluster strongly-inaccessibleCARD-FILV6 also-is inaccessibleCARD-FILV4 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be strongly-inaccessibleCARD-FILV6 implies it be inaccessibleCARD-FILV4"
     sorry
qed "sorry"

mtheorem card_fil_th_31:
" for M be AlephCARD-5M1 holds GCHCARD-FILR5 implies (M be inaccessibleCARD-FILV4 implies M be strongly-inaccessibleCARD-FILV6)"
  using card_fil_th_28 sorry

mdef card_fil_def_16 ("measurableCARD-FILV7" 70 ) where
"attr measurableCARD-FILV7 for AlephCARD-5M1 means
  (\<lambda>M.  ex Uf be FilterCARD-FILM1-of M st Uf is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M & Uf be  non principalCARD-FILV2\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub>)"..

mtheorem card_fil_th_32:
" for A be limit-ordinalORDINAL1V4\<bar>OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies (supORDINAL2K3 X =XBOOLE-0R4 A implies unionTARSKIK3 X =XBOOLE-0R4 A)"
proof(rule ballI,rule ballI,rule impI,rule impI)
  fix A assume [ty]: "A be limit-ordinalORDINAL1V4\<bar>OrdinalORDINAL1M3"
  fix X assume [ty]: "X be setHIDDENM2"
  assume "X c=TARSKIR1 A"
  then have A1: "unionTARSKIK3 X c=TARSKIR1 unionTARSKIK3 A"
    using zfmisc_1_th_77 sorry
  assume A2: "supORDINAL2K3 X =XBOOLE-0R4 A"
  have "unionTARSKIK3 X c=TARSKIR1 A & A c=TARSKIR1 unionTARSKIK3 X"
  proof(rule conjMI)
    show "unionTARSKIK3 X c=TARSKIR1 A"
      using A1 ordinal1_def_6 sorry
    show "A c=TARSKIR1 unionTARSKIK3 X"
    proof-
      have " for X1 be objectHIDDENM1 holds X1 inHIDDENR3 A implies X1 inHIDDENR3 unionTARSKIK3 X"
      proof(rule ballI,rule impI)
        fix X1 assume [ty]: "X1 be objectHIDDENM1"
        assume A3: "X1 inHIDDENR3 A"
        obtain X2 where 
          [ty]:"X2 be OrdinalORDINAL1M3" and X2Def:"X2 = X1"
          using A3 sorry
        have "succORDINAL1K1 X2 inTARSKIR2 A"
          using A3 ordinal1_th_28 sorry
        then have A4: " ex B be OrdinalORDINAL1M3 st B inTARSKIR2 X & succORDINAL1K1 X2 c=ORDINAL1R1 B"
          using A2 ordinal2_th_21 sorry
        have "X2 inTARSKIR2 succORDINAL1K1 X2"
          using ordinal1_th_6 sorry
        thus "X1 inHIDDENR3 unionTARSKIK3 X"
          using A4 tarski_def_4 sorry
      qed "sorry"
      thus "A c=TARSKIR1 unionTARSKIK3 X"
        using tarski_def_3 sorry
    qed
  qed
  thus "unionTARSKIK3 X =XBOOLE-0R4 A"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem card_fil_th_33:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be regularCARD-5V1"
proof-
  have " for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies ( not M be regularCARD-5V1 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix M assume [ty]: "M be AlephCARD-5M1"
    have A1: "cfCARD-5K1 M c=ORDINAL1R1 M"
      using card_5_def_1 sorry
    assume "M be measurableCARD-FILV7"
    then obtain Uf where
      [ty]:"Uf be FilterCARD-FILM1-of M" and 
      A2: "Uf is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M"and A3: "Uf be  non principalCARD-FILV2\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub>"
       sorry
    assume " not M be regularCARD-5V1"
    then have "cfCARD-5K1 M <>HIDDENR2 M"
      using card_5_def_3 sorry
    then have A4: "cfCARD-5K1 M inTARSKIR2 M"
      using A1 card_1_th_3 sorry
    then obtain xi where
      [ty]:"xi be Ordinal-SequenceORDINAL2M1" and 
      A5: "domRELAT-1K1 xi =XBOOLE-0R4 cfCARD-5K1 M"and A6: "rngFUNCT-1K2 xi c=TARSKIR1 M"and "xi be increasingORDINAL2V2"and A7: "M =XBOOLE-0R4 supORDINAL2K4 xi"and "xi be Cardinal-FunctionCARD-3M1"and " not 0ORDINAL1K5 inTARSKIR2 rngFUNCT-1K2 xi"
      using card_5_th_29 sorry
    have "M =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 xi)"
      using A7 ordinal2_def_5 sorry
    then have A8: "M =XBOOLE-0R4 unionTARSKIK3 (rngFUNCT-1K2 xi)"
      using A6 card_fil_th_32 sorry
    have "Uf is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> cardCARD-1K1 M"
      using A2 sorry
    then have A9: "Uf be uniformCARD-FILV1\<^bsub>(M)\<^esub>"
      using A3 card_fil_th_23 sorry
    have A10: "rngFUNCT-1K2 xi c=TARSKIR1 dualCARD-FILK2\<^bsub>(M)\<^esub> Uf"
    proof-
      have " for X be objectHIDDENM1 holds X inHIDDENR3 rngFUNCT-1K2 xi implies X inHIDDENR3 dualCARD-FILK2\<^bsub>(M)\<^esub> Uf"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be objectHIDDENM1"
        assume A11: "X inHIDDENR3 rngFUNCT-1K2 xi"
        obtain X1 where 
          [ty]:"X1 be SubsetSUBSET-1M2-of M" and X1Def:"X1 = X"
          using A6 A11 ordinal1_def_2 sorry
        have A12: "cardCARD-1K1 X1 inTARSKIR2 M"
          using A6 A11 card_1_th_9 sorry
        have " not X1 inTARSKIR2 Uf"
        proof-
          have "X1 inTARSKIR2 Uf implies  False "
          proof(rule impI)
            assume "X1 inTARSKIR2 Uf"
            then have "cardCARD-1K1 X1 =XBOOLE-0R4 cardCARD-1K1 M"
              using A9 sorry
            then have "cardCARD-1K1 X1 =XBOOLE-0R4 M"
               sorry
            thus " False "
              using A12 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "X inHIDDENR3 dualCARD-FILK2\<^bsub>(M)\<^esub> Uf"
          using A3 card_fil_th_22 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 xi c=TARSKIR1 dualCARD-FILK2\<^bsub>(M)\<^esub> Uf"
        using tarski_def_3 sorry
    qed
    have "cardCARD-1K1 (rngFUNCT-1K2 xi) c=ORDINAL1R1 cardCARD-1K1 (domRELAT-1K1 xi)"
      using card_2_th_61 sorry
    then have "cardCARD-1K1 (rngFUNCT-1K2 xi) c=ORDINAL1R1 cfCARD-5K1 M"
      using A5 sorry
    then have A13: "cardCARD-1K1 (rngFUNCT-1K2 xi) inTARSKIR2 M"
      using A4 ordinal1_th_12 sorry
    have "dualCARD-FILK2\<^bsub>(M)\<^esub> Uf is-complete-withCARD-FILR4\<^bsub>(M)\<^esub> M"
      using A2 card_fil_th_12 sorry
    then have "unionTARSKIK3 (rngFUNCT-1K2 xi) inTARSKIR2 dualCARD-FILK2\<^bsub>(M)\<^esub> Uf"
      using A8 A13 A10 zfmisc_1_th_2 sorry
    thus " False "
      using A8 card_fil_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_cl_8:
  mlet "M be AlephCARD-5M1"
"cluster nextcardCARD-1K2 M as-term-is  non limit-cardinalCARD-1V2"
proof
(*coherence*)
  show "nextcardCARD-1K2 M be  non limit-cardinalCARD-1V2"
     sorry
qed "sorry"

mtheorem card_fil_cl_9:
"cluster  non limit-cardinalCARD-1V2\<bar>infiniteFINSET-1V2 for CardinalCARD-1M1"
proof
(*existence*)
  show " ex it be CardinalCARD-1M1 st it be  non limit-cardinalCARD-1V2\<bar>infiniteFINSET-1V2"
  proof-
    have " ex tVar9 be CardinalCARD-1M1 st  not tVar9 be limit-cardinalCARD-1V2 &  not tVar9 be infiniteFINSET-1V2"
    proof-
      show " ex tVar9 be CardinalCARD-1M1 st  not tVar9 be limit-cardinalCARD-1V2 &  not tVar9 be infiniteFINSET-1V2"
      proof(rule bexI[of _ "alephCARD-1K3 (succORDINAL1K1 (0ORDINAL1K5))"])
        have "alephCARD-1K3 (succORDINAL1K1 (0ORDINAL1K5)) =XBOOLE-0R4 nextcardCARD-1K2 (omegaORDINAL1K4)"
          using card_1_th_19 card_1_th_46 sorry
        thus " not alephCARD-1K3 (succORDINAL1K1 (0ORDINAL1K5)) be limit-cardinalCARD-1V2 &  not alephCARD-1K3 (succORDINAL1K1 (0ORDINAL1K5)) be infiniteFINSET-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_fil_cl_10:
"cluster  non limit-cardinalCARD-1V2 also-is regularCARD-5V1 for AlephCARD-5M1"
proof
(*coherence*)
  show " for it be AlephCARD-5M1 holds it be  non limit-cardinalCARD-1V2 implies it be regularCARD-5V1"
  proof-
    have " for M be AlephCARD-5M1 holds M be  non limit-cardinalCARD-1V2 implies ( not M be regularCARD-5V1 implies  False )"
    proof(rule ballI,rule impI,rule impI)
      fix M assume [ty]: "M be AlephCARD-5M1"
      assume A1: "M be  non limit-cardinalCARD-1V2"
      assume " not M be regularCARD-5V1"
      then have A2: "cfCARD-5K1 M <>HIDDENR2 M"
        using card_5_def_3 sorry
      have "cfCARD-5K1 M c=ORDINAL1R1 M"
        using card_5_def_1 sorry
      then have "cfCARD-5K1 M inTARSKIR2 M"
        using A2 card_1_th_3 sorry
      thus " False "
        using A1 card_5_th_28 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef card_fil_def_17 ("predecessorCARD-FILK7  _ " [164]164 ) where
  mlet "M be  non limit-cardinalCARD-1V2\<bar>CardinalCARD-1M1"
"func predecessorCARD-FILK7 M \<rightarrow> CardinalCARD-1M1 means
  \<lambda>it. M =XBOOLE-0R4 nextcardCARD-1K2 it"
proof-
  (*existence*)
    show " ex it be CardinalCARD-1M1 st M =XBOOLE-0R4 nextcardCARD-1K2 it"
      using card_1_def_4 sorry
  (*uniqueness*)
    show " for it1 be CardinalCARD-1M1 holds  for it2 be CardinalCARD-1M1 holds M =XBOOLE-0R4 nextcardCARD-1K2 it1 & M =XBOOLE-0R4 nextcardCARD-1K2 it2 implies it1 =HIDDENR1 it2"
      using card_3_th_89 sorry
qed "sorry"

mtheorem card_fil_cl_11:
  mlet "M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1"
"cluster predecessorCARD-FILK7 M as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "predecessorCARD-FILK7 M be infiniteFINSET-1V2"
  proof-
    have "predecessorCARD-FILK7 M be finiteFINSET-1V1 implies  False "
    proof(rule impI)
      assume A1: "predecessorCARD-FILK7 M be finiteFINSET-1V1"
      have "M =XBOOLE-0R4 nextcardCARD-1K2 (predecessorCARD-FILK7 M)"
        using card_fil_def_17 sorry
      thus " False "
        using A1 card_1_th_45 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CARD_FILM3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Ty" ("Inf-MatrixCARD-FILM3-of'( _ , _ , _ ')" [0,0,0]70)
translations "Inf-MatrixCARD-FILM3-of(N,N1,X)" \<rightharpoonup> "FunctionFUNCT-2M1-of([:ZFMISC-1K2 N,N1 :],X)"

reserve X for "setHIDDENM2"
reserve M for " non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1"
reserve F for "FilterCARD-FILM1-of M"
reserve N1, N2, N3 for "ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
reserve K1, K2 for "ElementSUBSET-1M1-of M"
reserve T for "Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)"
mdef card_fil_def_18 (" _ is-Ulam-Matrix-ofCARD-FILR6  _ " [50,50]50 ) where
  mlet "M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1", "T be Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)"
"pred T is-Ulam-Matrix-ofCARD-FILR6 M means
  ((( for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds K1 <>HIDDENR2 K2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K2) be emptyXBOOLE-0V1) & ( for K1 be ElementSUBSET-1M1-of M holds  for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds N1 <>HIDDENR2 N2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) be emptyXBOOLE-0V1)) & ( for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M)) & ( for K1 be ElementSUBSET-1M1-of M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M)"..

mtheorem card_fil_th_34:
" for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  ex T be Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M) st T is-Ulam-Matrix-ofCARD-FILR6 M"
proof-
  have " for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  ex tVar11 be Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M) st tVar11 is-Ulam-Matrix-ofCARD-FILR6 M"
  proof(rule ballI)
    fix M assume [ty]: "M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1"
    let ?N = "predecessorCARD-FILK7 M"
    let ?GT = "nextcardCARD-1K2 ?N \\SUBSET-1K6 ?N"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex f be FunctionFUNCT-1M1 st ((Lamb2 =HIDDENR1 f & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 ?N) & rngFUNCT-1K2 f =HIDDENR1 Lamb1"
    have A1: " for K1 be objectHIDDENM1 holds K1 inHIDDENR3 ?GT implies ( ex x be objectHIDDENM1 st x inHIDDENR3 FuncsFUNCT-2K9(?N,nextcardCARD-1K2 ?N) & ?P(K1,x))"
    proof-
      have " for K1 be objectHIDDENM1 holds K1 inHIDDENR3 nextcardCARD-1K2 (predecessorCARD-FILK7 M) \\SUBSET-1K6 predecessorCARD-FILK7 M implies  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 FuncsFUNCT-2K9(predecessorCARD-FILK7 M,nextcardCARD-1K2 (predecessorCARD-FILK7 M)) & ( ex f be FunctionFUNCT-1M1 st ((x =HIDDENR1 f & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 predecessorCARD-FILK7 M) & rngFUNCT-1K2 f =HIDDENR1 K1)))"
      proof(rule ballI,rule impI)
        fix K1 assume [ty]: "K1 be objectHIDDENM1"
        assume A2: "K1 inHIDDENR3 nextcardCARD-1K2 ?N \\SUBSET-1K6 ?N"
        obtain K2 where 
          [ty]:"K2 be ElementSUBSET-1M1-of nextcardCARD-1K2 ?N" and K2Def:"K2 = K1"
          using A2 sorry
        have " not K1 inHIDDENR3 ?N"
          using A2 xboole_0_def_5 sorry
        then have "cardCARD-1K1 ?N c=ORDINAL1R1 cardCARD-1K1 K2"
          using card_1_th_11 ordinal1_th_16 sorry
        then have A3: "?N c=ORDINAL1R1 cardCARD-1K1 K2"
           sorry
        have "cardCARD-1K1 K2 inTARSKIR2 nextcardCARD-1K2 ?N"
          using card_1_th_9 sorry
        then have "cardCARD-1K1 K2 c=ORDINAL1R1 ?N"
          using card_3_th_91 sorry
        then have "cardCARD-1K1 K2 =HIDDENR1 ?N"
          using A3 sorry
        also have "... = cardCARD-1K1 ?N"
           sorry
        finally have "cardCARD-1K1 K2 =HIDDENR1 cardCARD-1K1 ?N"
           sorry
        then have "(K2,?N)are-equipotentTARSKIR3"
          using card_1_th_5 sorry
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A4: "f be one-to-oneFUNCT-1V2"and A5: "domRELAT-1K1 f =XBOOLE-0R4 ?N"and A6: "rngFUNCT-1K2 f =HIDDENR1 K1"
          using wellord2_def_4 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 nextcardCARD-1K2 ?N"
          using A2 A6 ordinal1_def_2 sorry
        then have "f inTARSKIR2 FuncsFUNCT-2K9(?N,nextcardCARD-1K2 ?N)"
          using A5 funct_2_def_2 sorry
        thus " not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 FuncsFUNCT-2K9(predecessorCARD-FILK7 M,nextcardCARD-1K2 (predecessorCARD-FILK7 M)) & ( ex f be FunctionFUNCT-1M1 st ((x =HIDDENR1 f & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 predecessorCARD-FILK7 M) & rngFUNCT-1K2 f =HIDDENR1 K1)))"
          using A4 A5 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain h1 where
      [ty]:"h1 be FunctionFUNCT-1M1" and 
      A7: "domRELAT-1K1 h1 =XBOOLE-0R4 ?GT"and "rngFUNCT-1K2 h1 c=TARSKIR1 FuncsFUNCT-2K9(?N,nextcardCARD-1K2 ?N)"and A8: " for K1 be objectHIDDENM1 holds K1 inHIDDENR3 ?GT implies ?P(K1,h1 .FUNCT-1K1 K1)"
      using funct_1_sch_6 A1 sorry
    have " for K1 be objectHIDDENM1 holds K1 inHIDDENR3 domRELAT-1K1 h1 implies h1 .FUNCT-1K1 K1 be FunctionFUNCT-1M1"
    proof(rule ballI,rule impI)
      fix K1 assume [ty]: "K1 be objectHIDDENM1"
      assume "K1 inHIDDENR3 domRELAT-1K1 h1"
      then have " ex f be FunctionFUNCT-1M1 st ((h1 .FUNCT-1K1 K1 =XBOOLE-0R4 f & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 ?N) & rngFUNCT-1K2 f =HIDDENR1 K1"
        using A7 A8 sorry
      thus "h1 .FUNCT-1K1 K1 be FunctionFUNCT-1M1"
         sorry
    qed "sorry"
    then obtain h where 
      [ty]:"h be Function-yieldingFUNCOP-1V1\<bar>FunctionFUNCT-1M1" and hDef:"h = h1"
      using funcop_1_def_6 sorry
    have "?N inTARSKIR2 nextcardCARD-1K2 ?N &  not ?N inTARSKIR2 ?N"
      using card_1_th_18 sorry
    then obtain GT1 where 
      [ty]:"GT1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and GT1Def:"GT1 = nextcardCARD-1K2 ?N \\SUBSET-1K6 ?N"
      using xboole_0_def_5 sorry
    let ?g = "\<lambda>Lamb1. \<lambda>Lamb2. (h .FUNCT-1K1 Lamb2).FUNCT-1K1 Lamb1"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =XBOOLE-0R4 {K2 where K2 be ElementSUBSET-1M1-of GT1 : ?g(Lamb1,K2) =XBOOLE-0R4 Lamb2 }"
    have A9: " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  ex S1 be SubsetSUBSET-1M2-of GT1 st ?P(N1,K1,S1)"
    proof-
      have " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  ex tVar10 be SubsetSUBSET-1M2-of GT1 st tVar10 be SubsetSUBSET-1M2-of GT1 & tVar10 =XBOOLE-0R4 {K2c where K2c be ElementSUBSET-1M1-of GT1 : (h .FUNCT-1K1 K2c).FUNCT-1K1 N1 =XBOOLE-0R4 K1 }"
      proof(rule ballI,rule ballI)
        fix N1 assume [ty]: "N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
        fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
        let ?P = "\<lambda>Lamb1. ?g(N1,Lamb1) =XBOOLE-0R4 K1"
        show " ex tVar10 be SubsetSUBSET-1M2-of GT1 st tVar10 be SubsetSUBSET-1M2-of GT1 & tVar10 =XBOOLE-0R4 {K2c where K2c be ElementSUBSET-1M1-of GT1 : (h .FUNCT-1K1 K2c).FUNCT-1K1 N1 =XBOOLE-0R4 K1 }"
        proof(rule bexI[of _ "{K2 where K2 be ElementSUBSET-1M1-of GT1 : ?g(N1,K2) =XBOOLE-0R4 K1 }"])
          have "{K2 where K2 be ElementSUBSET-1M1-of GT1 : ?P(K2) } be SubsetSUBSET-1M2-of GT1"
            using domain_1_sch_7 sorry
          thus "{K2 where K2 be ElementSUBSET-1M1-of GT1 : (h .FUNCT-1K1 K2).FUNCT-1K1 N1 =XBOOLE-0R4 K1 } be SubsetSUBSET-1M2-of GT1 & {K2 where K2 be ElementSUBSET-1M1-of GT1 : (h .FUNCT-1K1 K2).FUNCT-1K1 N1 =XBOOLE-0R4 K1 } =XBOOLE-0R4 {K2c where K2c be ElementSUBSET-1M1-of GT1 : (h .FUNCT-1K1 K2c).FUNCT-1K1 N1 =XBOOLE-0R4 K1 }"
             sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain T1 where
      [ty]:"T1 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 GT1)" and 
      A10: " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds ?P(N1,K1,T1 .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 GT1)\<^esub>(N1,K1))"
      using binop_1_sch_3 A9 sorry
    have "GT1 c=TARSKIR1 nextcardCARD-1K2 ?N"
       sorry
    then have "GT1 c=TARSKIR1 M"
      using card_fil_def_17 sorry
    then have "boolSETFAM-1K9 GT1 c=TARSKIR1 boolSETFAM-1K9 M"
      using zfmisc_1_th_67 sorry
    then obtain T where 
      [ty]:"T be FunctionFUNCT-2M1-of([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 M)" and TDef:"T = T1"
      using funct_2_th_7 sorry
    show " ex tVar11 be Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M) st tVar11 is-Ulam-Matrix-ofCARD-FILR6 M"
    proof(rule bexI[of _ "T"])
      have A11: " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds  for K3 be setHIDDENM2 holds K3 inTARSKIR2 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) implies ( ex K4 be ElementSUBSET-1M1-of GT1 st (K4 =XBOOLE-0R4 K3 & ?g(N1,K4) =XBOOLE-0R4 K1) & ?g(N2,K4) =XBOOLE-0R4 K2)"
      proof-
        have " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds  for K3 be setHIDDENM2 holds K3 inTARSKIR2 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) implies ( ex tVar12 be ElementSUBSET-1M1-of GT1 st tVar12 =XBOOLE-0R4 K3 & ((h .FUNCT-1K1 tVar12).FUNCT-1K1 N1 =XBOOLE-0R4 K1 & (h .FUNCT-1K1 tVar12).FUNCT-1K1 N2 =XBOOLE-0R4 K2))"
        proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
          fix N1 assume [ty]: "N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
          fix N2 assume [ty]: "N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
          fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
          fix K2 assume [ty]: "K2 be ElementSUBSET-1M1-of M"
          fix K3 assume [ty]: "K3 be setHIDDENM2"
          let ?A = "\<lambda>Lamb1. ?g(N1,Lamb1) =XBOOLE-0R4 K1"
          let ?B = "\<lambda>Lamb1. ?g(N2,Lamb1) =XBOOLE-0R4 K2"
          assume A12: "K3 inTARSKIR2 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2)"
          then have A13: "K3 inTARSKIR2 T1 .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 GT1)\<^esub>(N1,K1)"
            using xboole_0_def_4 sorry
          then obtain K4 where 
            [ty]:"K4 be ElementSUBSET-1M1-of GT1" and K4Def:"K4 = K3"
             sorry
          show " ex tVar12 be ElementSUBSET-1M1-of GT1 st tVar12 =XBOOLE-0R4 K3 & ((h .FUNCT-1K1 tVar12).FUNCT-1K1 N1 =XBOOLE-0R4 K1 & (h .FUNCT-1K1 tVar12).FUNCT-1K1 N2 =XBOOLE-0R4 K2)"
          proof(rule bexI[of _ "K4"],rule conjMI,rule conjMI)
            show "K4 =XBOOLE-0R4 K3"
               sorry
            have A14: "K4 inTARSKIR2 {K5 where K5 be ElementSUBSET-1M1-of GT1 : ?A(K5) }"
              using A10 A13 sorry
            show "(h .FUNCT-1K1 K4).FUNCT-1K1 N1 =XBOOLE-0R4 K1"
              using card_fil_sch_1 A14 sorry
            have "K3 inTARSKIR2 T1 .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 GT1)\<^esub>(N2,K2)"
              using A12 xboole_0_def_4 sorry
            then have A15: "K4 inTARSKIR2 {K5 where K5 be ElementSUBSET-1M1-of GT1 : ?B(K5) }"
              using A10 sorry
            show "(h .FUNCT-1K1 K4).FUNCT-1K1 N2 =XBOOLE-0R4 K2"
              using card_fil_sch_1 A15 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "( for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds K1 <>HIDDENR2 K2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K2) be emptyXBOOLE-0V1) & (( for K1 be ElementSUBSET-1M1-of M holds  for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds N1 <>HIDDENR2 N2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) be emptyXBOOLE-0V1) & (( for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M) & ( for K1 be ElementSUBSET-1M1-of M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M)))"
      proof(rule conjMI,rule conjMI,rule conjMI)
        show " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds K1 <>HIDDENR2 K2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K2) be emptyXBOOLE-0V1"
        proof-
          have " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds K1 <>HIDDENR2 K2 implies ( not T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K2) be emptyXBOOLE-0V1 implies  False )"
          proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
            fix N1 assume [ty]: "N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
            fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
            fix K2 assume [ty]: "K2 be ElementSUBSET-1M1-of M"
            assume A16: "K1 <>HIDDENR2 K2"
            assume " not T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K2) be emptyXBOOLE-0V1"
            then obtain K3 where
              [ty]:"K3 be objectHIDDENM1" and 
              A17: "K3 inHIDDENR3 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K2)"
               sorry
            have " ex K4 be ElementSUBSET-1M1-of GT1 st (K4 =HIDDENR1 K3 & ?g(N1,K4) =XBOOLE-0R4 K1) & ?g(N1,K4) =XBOOLE-0R4 K2"
              using A11 A17 sorry
            thus " False "
              using A16 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for K1 be ElementSUBSET-1M1-of M holds  for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds N1 <>HIDDENR2 N2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) be emptyXBOOLE-0V1"
        proof-
          have " for K1 be ElementSUBSET-1M1-of M holds  for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds N1 <>HIDDENR2 N2 implies ( not T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) be emptyXBOOLE-0V1 implies  False )"
          proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
            fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
            fix N1 assume [ty]: "N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
            fix N2 assume [ty]: "N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
            assume A18: "N1 <>HIDDENR2 N2"
            assume " not T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) be emptyXBOOLE-0V1"
            then obtain K3 where
              [ty]:"K3 be objectHIDDENM1" and 
              A19: "K3 inHIDDENR3 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1)"
               sorry
            obtain K4 where
              [ty]:"K4 be ElementSUBSET-1M1-of GT1" and 
              "K4 =HIDDENR1 K3"and A20: "?g(N1,K4) =XBOOLE-0R4 K1 & ?g(N2,K4) =XBOOLE-0R4 K1"
              using A11 A19 sorry
            have " ex f be FunctionFUNCT-1M1 st ((h1 .FUNCT-1K1 K4 =XBOOLE-0R4 f & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 ?N) & rngFUNCT-1K2 f =XBOOLE-0R4 K4"
              using A8 sorry
            thus " False "
              using A18 A20 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A21: " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of GT1 holds domRELAT-1K1 (h .FUNCT-1K1 K1) =XBOOLE-0R4 ?N & rngFUNCT-1K2 (h .FUNCT-1K1 K1) =XBOOLE-0R4 K1"
        proof-
          have " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds  for K1 be ElementSUBSET-1M1-of GT1 holds domRELAT-1K1 (h .FUNCT-1K1 K1) =XBOOLE-0R4 predecessorCARD-FILK7 M & rngFUNCT-1K2 (h .FUNCT-1K1 K1) =XBOOLE-0R4 K1"
          proof(rule ballI,rule ballI)
            fix N1 assume [ty]: "N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
            fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of GT1"
            have " ex f be FunctionFUNCT-1M1 st ((h1 .FUNCT-1K1 K1 =XBOOLE-0R4 f & f be one-to-oneFUNCT-1V2) & domRELAT-1K1 f =XBOOLE-0R4 ?N) & rngFUNCT-1K2 f =XBOOLE-0R4 K1"
              using A8 sorry
            thus "domRELAT-1K1 (h .FUNCT-1K1 K1) =XBOOLE-0R4 predecessorCARD-FILK7 M & rngFUNCT-1K2 (h .FUNCT-1K1 K1) =XBOOLE-0R4 K1"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
        proof-
          have " for N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
          proof(rule ballI)
            fix N1 assume [ty]: "N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
            have "unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }) =XBOOLE-0R4 GT1"
            proof-
              have "unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }) =XBOOLE-0R4 GT1"
              proof-
                have Cut1411: " for S1 be setHIDDENM2 holds S1 inTARSKIR2 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M } implies S1 c=TARSKIR1 GT1"
                proof(rule ballI,rule impI)
                  fix S1 assume [ty]: "S1 be setHIDDENM2"
                  assume "S1 inTARSKIR2 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }"
                  then obtain K1 where
                    [ty]:"K1 be ElementSUBSET-1M1-of M" and 
                    A22: "S1 =XBOOLE-0R4 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1)"and "K1 inTARSKIR2 M"
                     sorry
                  have "T1 .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 GT1)\<^esub>(N1,K1) c=TARSKIR1 GT1"
                     sorry
                  thus "S1 c=TARSKIR1 GT1"
                    using A22 sorry
                qed "sorry"
                have "unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }) c=TARSKIR1 GT1 & GT1 c=TARSKIR1 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })"
                proof(rule conjMI)
                  show "unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }) c=TARSKIR1 GT1"
                    using zfmisc_1_th_76 Cut1411 sorry
                  have " for K2 be objectHIDDENM1 holds K2 inHIDDENR3 GT1 implies K2 inHIDDENR3 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })"
                  proof(rule ballI,rule impI)
                    fix K2 assume [ty]: "K2 be objectHIDDENM1"
                    assume A23: "K2 inHIDDENR3 GT1"
                    obtain K5 where 
                      [ty]:"K5 be ElementSUBSET-1M1-of GT1" and K5Def:"K5 = K2"
                      using A23 sorry
                    have "N1 inTARSKIR2 ?N"
                       sorry
                    then have "N1 inTARSKIR2 domRELAT-1K1 (h .FUNCT-1K1 K5)"
                      using A21 sorry
                    then have "(h .FUNCT-1K1 K5).FUNCT-1K1 N1 inTARSKIR2 rngFUNCT-1K2 (h .FUNCT-1K1 K5)"
                      using funct_1_def_3 sorry
                    then have A24: "?g(N1,K5) inTARSKIR2 K5"
                      using A21 sorry
                    have "K2 inHIDDENR3 nextcardCARD-1K2 ?N"
                      using A23 sorry
                    then have "K2 inHIDDENR3 M"
                      using card_fil_def_17 sorry
                    then have A25: "K5 c=TARSKIR1 M"
                      using ordinal1_def_2 sorry
                    then have A26: "T .BINOP-1K1(N1,?g(N1,K5)) inTARSKIR2 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }"
                      using A24 sorry
                    have "K5 inTARSKIR2 {K3 where K3 be ElementSUBSET-1M1-of GT1 : ?g(N1,K3) =XBOOLE-0R4 ?g(N1,K5) }"
                       sorry
                    then have "K5 inTARSKIR2 T .BINOP-1K1(N1,?g(N1,K5))"
                      using A10 A25 A24 sorry
                    thus "K2 inHIDDENR3 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })"
                      using A26 tarski_def_4 sorry
                  qed "sorry"
                  thus "GT1 c=TARSKIR1 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })"
                    using tarski_def_3 sorry
                qed
                thus "unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }) =XBOOLE-0R4 GT1"
                  using xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then have "unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }) =XBOOLE-0R4 M \\SUBSET-1K6 ?N"
              using card_fil_def_17 sorry
            then have "M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M }) =XBOOLE-0R4 M /\\XBOOLE-0K3 ?N"
              using xboole_1_th_48 sorry
            thus "cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where K1 be ElementSUBSET-1M1-of M : K1 inTARSKIR2 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
              using card_1_th_7 xboole_1_th_17 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for K1 be ElementSUBSET-1M1-of M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
        proof-
          have " for K1 be ElementSUBSET-1M1-of M holds cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
          proof(rule ballI)
            fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
            have A27: "?N c=ORDINAL1R1 K1 implies cardCARD-1K1 K1 =XBOOLE-0R4 ?N"
            proof-
              have "predecessorCARD-FILK7 M c=ORDINAL1R1 K1 implies cardCARD-1K1 K1 =XBOOLE-0R4 predecessorCARD-FILK7 M"
              proof(rule impI)
                assume "?N c=ORDINAL1R1 K1"
                then have "cardCARD-1K1 ?N c=ORDINAL1R1 cardCARD-1K1 K1"
                  using card_1_th_11 sorry
                then have A28: "?N c=ORDINAL1R1 cardCARD-1K1 K1"
                   sorry
                have "cardCARD-1K1 K1 inTARSKIR2 M"
                  using card_1_th_9 sorry
                then have "cardCARD-1K1 K1 inTARSKIR2 nextcardCARD-1K2 ?N"
                  using card_fil_def_17 sorry
                then have "cardCARD-1K1 K1 c=ORDINAL1R1 ?N"
                  using card_3_th_91 sorry
                thus "cardCARD-1K1 K1 =XBOOLE-0R4 predecessorCARD-FILK7 M"
                  using A28 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A29: "cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })) c=ORDINAL1R1 ?N"
            proof-
              have "cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
              proof-
                show "cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
                proof-
                  have cases: "?N c=ORDINAL1R1 K1 or K1 inTARSKIR2 ?N"
                    using ordinal1_th_16 sorry
                  have case1: "predecessorCARD-FILK7 M c=ORDINAL1R1 K1 implies cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
                  proof(rule impI)
                    assume A30: "?N c=ORDINAL1R1 K1"
                    have "M \\SUBSET-1K6 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1}) c=TARSKIR1 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                    proof-
                      have " for K6 be objectHIDDENM1 holds K6 inHIDDENR3 M \\SUBSET-1K6 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1}) implies K6 inHIDDENR3 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                      proof(rule ballI,rule impI)
                        fix K6 assume [ty]: "K6 be objectHIDDENM1"
                        assume A31: "K6 inHIDDENR3 M \\SUBSET-1K6 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1})"
                        obtain K7 where 
                          [ty]:"K7 be ElementSUBSET-1M1-of M" and K7Def:"K7 = K6"
                          using A31 sorry
                        have A32: " not K6 inHIDDENR3 K1 \\/XBOOLE-0K2 {TARSKIK1 K1}"
                          using A31 xboole_0_def_5 sorry
                        then have " not K6 inHIDDENR3 {TARSKIK1 K1}"
                          using xboole_0_def_3 sorry
                        then have A33: " not K6 =HIDDENR1 K1"
                          using tarski_def_1 sorry
                        have "K7 inTARSKIR2 M"
                           sorry
                        then have A34: "K7 inTARSKIR2 nextcardCARD-1K2 ?N"
                          using card_fil_def_17 sorry
                        have " not K6 inHIDDENR3 K1"
                          using A32 xboole_0_def_3 sorry
                        then have A35: "K1 inTARSKIR2 K7"
                          using A33 ordinal1_th_14 sorry
                        then have "?N inTARSKIR2 K7"
                          using A30 ordinal1_th_12 sorry
                        then obtain K8 where 
                          [ty]:"K8 be ElementSUBSET-1M1-of GT1" and K8Def:"K8 = K7"
                          using A34 xboole_0_def_5 sorry
                        have "K8 inTARSKIR2 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                          using A35 sorry
                        thus "K6 inHIDDENR3 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                           sorry
                      qed "sorry"
                      thus "M \\SUBSET-1K6 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1}) c=TARSKIR1 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                        using tarski_def_3 sorry
                    qed
                    then have "M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }) c=TARSKIR1 M \\SUBSET-1K6 (M \\SUBSET-1K6 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1}))"
                      using xboole_1_th_34 sorry
                    then have A36: "M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }) c=TARSKIR1 M /\\XBOOLE-0K3 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1})"
                      using xboole_1_th_48 sorry
                    have " not K1 be finiteFINSET-1V1"
                      using A30 sorry
                    then have A37: "cardCARD-1K1 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1}) =XBOOLE-0R4 cardCARD-1K1 K1"
                      using card_2_th_78 sorry
                    have "M /\\XBOOLE-0K3 (K1 \\/XBOOLE-0K2 {TARSKIK1 K1}) c=TARSKIR1 K1 \\/XBOOLE-0K2 {TARSKIK1 K1}"
                      using xboole_1_th_17 sorry
                    then have "M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }) c=TARSKIR1 K1 \\/XBOOLE-0K2 {TARSKIK1 K1}"
                      using A36 sorry
                    thus "cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
                      using A27 A30 A37 card_1_th_11 sorry
                  qed
                  have case2: "K1 inTARSKIR2 predecessorCARD-FILK7 M implies cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
                  proof(rule impI)
                    assume A38: "K1 inTARSKIR2 ?N"
                    have "{K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } =XBOOLE-0R4 GT1"
                    proof-
                      let ?P = "\<lambda>Lamb1. K1 inTARSKIR2 Lamb1"
                      have Cut1501: "{K5 where K5 be ElementSUBSET-1M1-of GT1 : ?P(K5) } be SubsetSUBSET-1M2-of GT1"
                        using domain_1_sch_7 sorry
                      have "{K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } c=TARSKIR1 GT1 & GT1 c=TARSKIR1 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                      proof(rule conjMI)
                        show "{K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } c=TARSKIR1 GT1"
                          using Cut1501 sorry
                        have " for K6 be objectHIDDENM1 holds K6 inHIDDENR3 GT1 implies K6 inHIDDENR3 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                        proof(rule ballI,rule impI)
                          fix K6 assume [ty]: "K6 be objectHIDDENM1"
                          assume A39: "K6 inHIDDENR3 GT1"
                          obtain K7 where 
                            [ty]:"K7 be ElementSUBSET-1M1-of nextcardCARD-1K2 ?N" and K7Def:"K7 = K6"
                            using A39 sorry
                          obtain K8 where 
                            [ty]:"K8 be ElementSUBSET-1M1-of GT1" and K8Def:"K8 = K7"
                            using A39 sorry
                          have " not K6 inHIDDENR3 ?N"
                            using A39 xboole_0_def_5 sorry
                          then have "?N c=ORDINAL1R1 K7"
                            using ordinal1_th_16 sorry
                          then have "K8 inTARSKIR2 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                            using A38 sorry
                          thus "K6 inHIDDENR3 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                             sorry
                        qed "sorry"
                        thus "GT1 c=TARSKIR1 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                          using tarski_def_3 sorry
                      qed
                      thus "{K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } =XBOOLE-0R4 GT1"
                        using xboole_0_def_10 sorry
                    qed
                    then have "M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }) =HIDDENR1 M \\SUBSET-1K6 (M \\SUBSET-1K6 ?N)"
                      using card_fil_def_17 sorry
                    also have "... = M /\\XBOOLE-0K3 ?N"
                      using xboole_1_th_48 sorry
                    finally have "M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }) =HIDDENR1 M /\\XBOOLE-0K3 ?N"
                       sorry
                    thus "cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
                      using card_1_th_7 xboole_1_th_17 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ?thesis "
                 sorry
            qed
            have "{K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } c=TARSKIR1 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N })"
            proof-
              have "{K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } c=TARSKIR1 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })"
              proof-
                have " for K4 be objectHIDDENM1 holds K4 inHIDDENR3 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } implies K4 inHIDDENR3 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })"
                proof(rule ballI,rule impI)
                  fix K4 assume [ty]: "K4 be objectHIDDENM1"
                  assume "K4 inHIDDENR3 {K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }"
                  then obtain K5 where
                    [ty]:"K5 be ElementSUBSET-1M1-of GT1" and 
                    A40: "K4 =HIDDENR1 K5"and A41: "K1 inTARSKIR2 K5"
                     sorry
                  have "rngFUNCT-1K2 (h .FUNCT-1K1 K5) =XBOOLE-0R4 K5"
                    using A21 sorry
                  then obtain N2 where
                    [ty]:"N2 be objectHIDDENM1" and 
                    A42: "N2 inHIDDENR3 domRELAT-1K1 (h .FUNCT-1K1 K5)"and A43: "(h .FUNCT-1K1 K5).FUNCT-1K1 N2 =XBOOLE-0R4 K1"
                    using A41 funct_1_def_3 sorry
                  obtain N3 where 
                    [ty]:"N3 be ElementSUBSET-1M1-of ?N" and N3Def:"N3 = N2"
                    using A21 A42 sorry
                  have "K5 inTARSKIR2 {K3 where K3 be ElementSUBSET-1M1-of GT1 : ?g(N3,K3) =XBOOLE-0R4 K1 }"
                    using A43 sorry
                  then have A44: "K5 inTARSKIR2 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N3,K1)"
                    using A10 sorry
                  have "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N3,K1) inTARSKIR2 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }"
                     sorry
                  thus "K4 inHIDDENR3 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })"
                    using A40 A44 tarski_def_4 sorry
                qed "sorry"
                thus "{K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 } c=TARSKIR1 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            then have "M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }) c=TARSKIR1 M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 })"
              using xboole_1_th_34 sorry
            then have "cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N })) c=ORDINAL1R1 cardCARD-1K1 (M \\SUBSET-1K6 ({K5 where K5 be ElementSUBSET-1M1-of GT1 : K1 inTARSKIR2 K5 }))"
              using card_1_th_11 sorry
            thus "cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M })) c=ORDINAL1R1 predecessorCARD-FILK7 M"
              using A29 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
      qed
      thus "T is-Ulam-Matrix-ofCARD-FILR6 M"
        using card_fil_def_18 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_35:
" for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  for I be IdealCARD-FILM2-of M holds I is-complete-withCARD-FILR4\<^bsub>(M)\<^esub> M & Frechet-IdealCARD-FILK6 M c=TARSKIR1 I implies ( ex S be Subset-FamilySETFAM-1M1-of M st (cardCARD-1K1 S =XBOOLE-0R4 M & ( for X1 be setHIDDENM2 holds X1 inTARSKIR2 S implies  not X1 inTARSKIR2 I)) & ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds (X1 inTARSKIR2 S & X2 inTARSKIR2 S) & X1 <>HIDDENR2 X2 implies X1 missesXBOOLE-0R1 X2))"
proof-
  have " for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  for I be IdealCARD-FILM2-of M holds I is-complete-withCARD-FILR4\<^bsub>(M)\<^esub> M & Frechet-IdealCARD-FILK6 M c=TARSKIR1 I implies ( ex tVar13 be Subset-FamilySETFAM-1M1-of M st cardCARD-1K1 tVar13 =XBOOLE-0R4 M & (( for X1 be setHIDDENM2 holds X1 inTARSKIR2 tVar13 implies  not X1 inTARSKIR2 I) & ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds (X1 inTARSKIR2 tVar13 & X2 inTARSKIR2 tVar13) & X1 <>HIDDENR2 X2 implies X1 missesXBOOLE-0R1 X2)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix M assume [ty]: "M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1"
    let ?N = "predecessorCARD-FILK7 M"
    fix I assume [ty]: "I be IdealCARD-FILM2-of M"
    assume A1: "I is-complete-withCARD-FILR4\<^bsub>(M)\<^esub> M"
      and A2: "Frechet-IdealCARD-FILK6 M c=TARSKIR1 I"
    obtain T where
      [ty]:"T be Inf-MatrixCARD-FILM3-of(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)" and 
      A3: "T is-Ulam-Matrix-ofCARD-FILR6 M"
      using card_fil_th_34 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  not T .BINOP-1K1(Lamb2,Lamb1) inTARSKIR2 I"
    have A4: "M =XBOOLE-0R4 nextcardCARD-1K2 ?N"
      using card_fil_def_17 sorry
    have A5: " for K1 be ElementSUBSET-1M1-of M holds unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }) inTARSKIR2 dualCARD-FILK1\<^bsub>(M)\<^esub> I"
    proof-
      have " for K1 be ElementSUBSET-1M1-of M holds  not unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M }) inTARSKIR2 dualCARD-FILK1\<^bsub>(M)\<^esub> I implies  False "
      proof(rule ballI,rule impI)
        let ?F = "\<lambda>Lamb1. \<lambda>Lamb2. T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(Lamb1,Lamb2)"
        let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 ?N"
        fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =XBOOLE-0R4 K1 & Lamb1 inTARSKIR2 ?N"
        have A6: "{?F(N1,K2) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M, K2 be ElementSUBSET-1M1-of M : K2 =XBOOLE-0R4 K1 & ?R(N1,K2) } =XBOOLE-0R4 {?F(N2,K1) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : ?R(N2,K1) }"
          using fraenkel_sch_20 sorry
        have "{?F(N1,K2) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M, K2 be ElementSUBSET-1M1-of M : ?P(N1,K2) } be Subset-FamilySETFAM-1M1-of M"
          using domain_1_sch_9 sorry
        then obtain C where 
          [ty]:"C be Subset-FamilySETFAM-1M1-of M" and CDef:"C = {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }"
          using A6 sorry
        assume " not unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }) inTARSKIR2 dualCARD-FILK1\<^bsub>(M)\<^esub> I"
        then have " not (unionSETFAM-1K5\<^bsub>(M)\<^esub> C)`SUBSET-1K3\<^bsub>(M)\<^esub> inTARSKIR2 Frechet-IdealCARD-FILK6 M"
          using A2 setfam_1_def_7 sorry
        then have " not cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N })) inTARSKIR2 cardCARD-1K1 M"
          using card_fil_th_19 sorry
        then have A7: " not cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N })) inTARSKIR2 nextcardCARD-1K2 ?N"
          using A4 sorry
        have "cardCARD-1K1 (M \\SUBSET-1K6 unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N })) c=ORDINAL1R1 ?N"
          using A3 sorry
        thus " False "
          using A7 card_3_th_91 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: " for K1 be ElementSUBSET-1M1-of M holds  ex N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M st ?P(K1,N2)"
    proof-
      have " for K1 be ElementSUBSET-1M1-of M holds ( for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) inTARSKIR2 I) implies  False "
      proof(rule ballI,rule impI)
        let ?F = "\<lambda>Lamb1. T .FUNCT-1K1 Lamb1"
        fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
        have A9: "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N } be  non emptyXBOOLE-0V1"
        proof-
          have " not {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } be emptyXBOOLE-0V1"
          proof-
            let ?N2 = "the ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
            have "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(?N2,K1) inTARSKIR2 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }"
               sorry
            thus " not {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } be emptyXBOOLE-0V1"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A10: "cardCARD-1K1 ({?F(X) where X be ElementSUBSET-1M1-of [:ZFMISC-1K2 ?N,M :] : X inTARSKIR2 [:ZFMISC-1K2 ?N,{TARSKIK1 K1} :] }) c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 ?N,{TARSKIK1 K1} :])"
          using trees_2_sch_2 sorry
        have "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N } c=TARSKIR1 {T .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 M)\<^esub> X where X be ElementSUBSET-1M1-of [:ZFMISC-1K2 ?N,M :] : X inTARSKIR2 [:ZFMISC-1K2 ?N,{TARSKIK1 K1} :] }"
        proof-
          have "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } c=TARSKIR1 {T .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 M)\<^esub> X where X be ElementSUBSET-1M1-of [:ZFMISC-1K2 predecessorCARD-FILK7 M,M :] : X inTARSKIR2 [:ZFMISC-1K2 predecessorCARD-FILK7 M,{TARSKIK1 K1} :] }"
          proof-
            have " for Y be objectHIDDENM1 holds Y inHIDDENR3 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } implies Y inHIDDENR3 {T .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 M)\<^esub> X where X be ElementSUBSET-1M1-of [:ZFMISC-1K2 predecessorCARD-FILK7 M,M :] : X inTARSKIR2 [:ZFMISC-1K2 predecessorCARD-FILK7 M,{TARSKIK1 K1} :] }"
            proof(rule ballI,rule impI)
              fix Y assume [ty]: "Y be objectHIDDENM1"
              assume "Y inHIDDENR3 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }"
              then obtain N1 where
                [ty]:"N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M" and 
                A11: "Y =HIDDENR1 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1)"and "N1 inTARSKIR2 ?N"
                 sorry
              have "[TARSKIK4 N1,K1 ] be ElementSUBSET-1M1-of [:ZFMISC-1K2 ?N,M :] & [TARSKIK4 N1,K1 ] inHIDDENR3 [:ZFMISC-1K2 ?N,{TARSKIK1 K1} :]"
                using zfmisc_1_th_87 zfmisc_1_th_106 sorry
              thus "Y inHIDDENR3 {T .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 M)\<^esub> X where X be ElementSUBSET-1M1-of [:ZFMISC-1K2 predecessorCARD-FILK7 M,M :] : X inTARSKIR2 [:ZFMISC-1K2 predecessorCARD-FILK7 M,{TARSKIK1 K1} :] }"
                using A11 sorry
            qed "sorry"
            thus "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } c=TARSKIR1 {T .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 M)\<^esub> X where X be ElementSUBSET-1M1-of [:ZFMISC-1K2 predecessorCARD-FILK7 M,M :] : X inTARSKIR2 [:ZFMISC-1K2 predecessorCARD-FILK7 M,{TARSKIK1 K1} :] }"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have A12: "cardCARD-1K1 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }) c=ORDINAL1R1 cardCARD-1K1 ({T .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :],boolSETFAM-1K9 M)\<^esub> X where X be ElementSUBSET-1M1-of [:ZFMISC-1K2 ?N,M :] : X inTARSKIR2 [:ZFMISC-1K2 ?N,{TARSKIK1 K1} :] })"
          using card_1_th_11 sorry
        assume A13: " for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) inTARSKIR2 I"
        have A14: "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N } c=TARSKIR1 I"
        proof-
          have "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } c=TARSKIR1 I"
          proof-
            have " for X be objectHIDDENM1 holds X inHIDDENR3 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } implies X inHIDDENR3 I"
            proof(rule ballI,rule impI)
              fix X assume [ty]: "X be objectHIDDENM1"
              assume "X inHIDDENR3 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }"
              then have " ex N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M st X =HIDDENR1 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) & N2 inTARSKIR2 ?N"
                 sorry
              thus "X inHIDDENR3 I"
                using A13 sorry
            qed "sorry"
            thus "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 predecessorCARD-FILK7 M } c=TARSKIR1 I"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "cardCARD-1K1 ([:ZFMISC-1K2 ?N,{TARSKIK1 K1} :]) =XBOOLE-0R4 cardCARD-1K1 ?N"
          using card_1_th_69 sorry
        then have A15: "cardCARD-1K1 ([:ZFMISC-1K2 ?N,{TARSKIK1 K1} :]) =XBOOLE-0R4 ?N"
           sorry
        have "?N inTARSKIR2 M"
          using A4 card_1_th_18 sorry
        then have "cardCARD-1K1 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }) inTARSKIR2 M"
          using A10 A12 A15 ordinal1_th_12 xboole_1_th_1 sorry
        then have "unionTARSKIK3 ({T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N1,K1) where N1 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N1 inTARSKIR2 ?N }) inTARSKIR2 I"
          using A1 A14 A9 sorry
        thus " False "
          using A5 card_fil_th_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain h where
      [ty]:"h be FunctionFUNCT-2M1-of(M,?N)" and 
      A16: " for K1 be ElementSUBSET-1M1-of M holds ?P(K1,h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K1)"
      using funct_2_sch_3 A8 sorry
    have " ex N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M st cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) =XBOOLE-0R4 M"
    proof-
      have "( for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) <>HIDDENR2 M) implies  False "
      proof(rule impI)
        let ?F = "\<lambda>Lamb1. supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 Lamb1})"
        assume A17: " for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) <>HIDDENR2 M"
        have A18: "{supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 ?N } c=TARSKIR1 M"
        proof-
          have "{supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 predecessorCARD-FILK7 M } c=TARSKIR1 M"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 predecessorCARD-FILK7 M } implies x inHIDDENR3 M"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 {supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 ?N }"
              then obtain N2 where
                [ty]:"N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M" and 
                A19: "x =HIDDENR1 supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2})"and "N2 inTARSKIR2 ?N"
                 sorry
              have "cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) c=ORDINAL1R1 M & cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) <>HIDDENR2 M"
                using A17 card_1_th_7 sorry
              then have "cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) inTARSKIR2 M"
                using card_1_th_3 sorry
              then have "cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) inTARSKIR2 cfCARD-5K1 M"
                using card_5_def_3 sorry
              thus "x inHIDDENR3 M"
                using A19 card_5_th_26 sorry
            qed "sorry"
            thus "{supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 predecessorCARD-FILK7 M } c=TARSKIR1 M"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "cardCARD-1K1 ({?F(N2) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 ?N }) c=ORDINAL1R1 cardCARD-1K1 ?N"
          using trees_2_sch_2 sorry
        then have "cardCARD-1K1 ({supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 ?N }) c=ORDINAL1R1 ?N"
           sorry
        then have "cardCARD-1K1 ({supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 ?N }) inTARSKIR2 M"
          using A4 card_3_th_91 sorry
        then have "cardCARD-1K1 ({supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) where N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N2 inTARSKIR2 ?N }) inTARSKIR2 cfCARD-5K1 M"
          using card_5_def_3 sorry
        then obtain K1 where 
          [ty]:"K1 be ElementSUBSET-1M1-of M" and K1Def:"K1 = supORDINAL2K3 ({supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N3}) where N3 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N3 inTARSKIR2 ?N })"
          using A18 card_5_th_26 sorry
        have " for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) inTARSKIR2 supORDINAL2K3 ({supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N3}) where N3 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N3 inTARSKIR2 ?N })"
        proof-
          have " for N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M holds supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) inTARSKIR2 supORDINAL2K3 ({supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N3}) where N3 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N3 inTARSKIR2 predecessorCARD-FILK7 M })"
          proof(rule ballI)
            fix N2 assume [ty]: "N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M"
            have "supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) inTARSKIR2 {supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N3}) where N3 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N3 inTARSKIR2 ?N }"
               sorry
            thus "supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) inTARSKIR2 supORDINAL2K3 ({supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N3}) where N3 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M : N3 inTARSKIR2 predecessorCARD-FILK7 M })"
              using ordinal2_th_19 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have "supORDINAL2K3 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K1 }) inTARSKIR2 K1"
           sorry
        thus " False "
          using ordinal2_th_19 setwiseo_th_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain N2 where
      [ty]:"N2 be ElementSUBSET-1M1-of predecessorCARD-FILK7 M" and 
      A20: "cardCARD-1K1 (h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}) =XBOOLE-0R4 M"
       sorry
    have "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) where K2 be ElementSUBSET-1M1-of M : h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2 } c=TARSKIR1 boolSETFAM-1K9 M"
    proof-
      have "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) where K2 be ElementSUBSET-1M1-of M : h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2 } c=TARSKIR1 boolSETFAM-1K9 M"
      proof-
        have " for X be objectHIDDENM1 holds X inHIDDENR3 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) where K2 be ElementSUBSET-1M1-of M : h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2 } implies X inHIDDENR3 boolSETFAM-1K9 M"
        proof(rule ballI,rule impI)
          fix X assume [ty]: "X be objectHIDDENM1"
          assume "X inHIDDENR3 {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) where K2 be ElementSUBSET-1M1-of M : h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2 }"
          then have " ex K2 be ElementSUBSET-1M1-of M st X =HIDDENR1 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) & h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2"
             sorry
          thus "X inHIDDENR3 boolSETFAM-1K9 M"
             sorry
        qed "sorry"
        thus "{T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) where K2 be ElementSUBSET-1M1-of M : h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2 } c=TARSKIR1 boolSETFAM-1K9 M"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain S where 
      [ty]:"S be Subset-FamilySETFAM-1M1-of M" and SDef:"S = {T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) where K2 be ElementSUBSET-1M1-of M : h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2 }"
       sorry
    have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 predecessorCARD-FILK7 M,M :])\<^esub> T =XBOOLE-0R4 [:ZFMISC-1K2 ?N,M :]"
      using funct_2_def_1 sorry
    then obtain G where
      [ty]:"G be FunctionFUNCT-1M1" and 
      "curryFUNCT-5K12\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub> T .FUNCT-2K3\<^bsub>(predecessorCARD-FILK7 M,FuncsFUNCT-2K9(M,boolSETFAM-1K9 M))\<^esub> N2 =FUNCT-1R1 G"and A21: "domRELAT-1K1 G =XBOOLE-0R4 M"and "rngFUNCT-1K2 G c=TARSKIR1 rngRELSET-1K2\<^bsub>(boolSETFAM-1K9 M)\<^esub> T"and A22: " for y be objectHIDDENM1 holds y inHIDDENR3 M implies G .FUNCT-1K1 y =XBOOLE-0R4 T .BINOP-1K1(N2,y)"
      using funct_5_th_29 sorry
    have "(h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2},M)are-equipotentTARSKIR3"
      using A20 card_1_def_2 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A23: "f be one-to-oneFUNCT-1V2"and A24: "domRELAT-1K1 f =XBOOLE-0R4 M"and A25: "rngFUNCT-1K2 f =XBOOLE-0R4 h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}"
      using wellord2_def_4 sorry
    have A26: "domRELAT-1K1 (G *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using A25 A21 relat_1_th_27 sorry
    have A27: "S c=TARSKIR1 rngFUNCT-1K2 (G *FUNCT-1K3 f)"
    proof-
      have " for X be objectHIDDENM1 holds X inHIDDENR3 S implies X inHIDDENR3 rngFUNCT-1K2 (G *FUNCT-1K3 f)"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be objectHIDDENM1"
        assume "X inHIDDENR3 S"
        then obtain K2 where
          [ty]:"K2 be ElementSUBSET-1M1-of M" and 
          A28: "X =HIDDENR1 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2)"and A29: "h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2"
           sorry
        have "K2 inTARSKIR2 M"
           sorry
        then have A30: "K2 inTARSKIR2 domRELSET-1K1\<^bsub>(M)\<^esub> h"
          using funct_2_def_1 sorry
        have "h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 inTARSKIR2 {TARSKIK1 N2}"
          using A29 tarski_def_1 sorry
        then have "K2 inTARSKIR2 h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}"
          using A30 funct_1_def_7 sorry
        then obtain K3 where
          [ty]:"K3 be objectHIDDENM1" and 
          A31: "K3 inHIDDENR3 domRELAT-1K1 f"and A32: "f .FUNCT-1K1 K3 =XBOOLE-0R4 K2"
          using A25 funct_1_def_3 sorry
        have "X =HIDDENR1 G .FUNCT-1K1 (f .FUNCT-1K1 K3)"
          using A22 A28 A32 sorry
        then have "X =HIDDENR1 (G *FUNCT-1K3 f).FUNCT-1K1 K3"
          using A26 A31 funct_1_th_12 sorry
        thus "X inHIDDENR3 rngFUNCT-1K2 (G *FUNCT-1K3 f)"
          using A26 A31 funct_1_def_3 sorry
      qed "sorry"
      thus "S c=TARSKIR1 rngFUNCT-1K2 (G *FUNCT-1K3 f)"
        using tarski_def_3 sorry
    qed
    have A33: " for X be setHIDDENM2 holds X inTARSKIR2 domRELAT-1K1 f implies h .FUNCT-1K1 (f .FUNCT-1K1 X) =XBOOLE-0R4 N2"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X inTARSKIR2 domRELAT-1K1 f"
      then have "f .FUNCT-1K1 X inTARSKIR2 h \<inverse>RELSET-1K8\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> {TARSKIK1 N2}"
        using A25 funct_1_def_3 sorry
      then have "h .FUNCT-1K1 (f .FUNCT-1K1 X) inTARSKIR2 {TARSKIK1 N2}"
        using funct_1_def_7 sorry
      thus "h .FUNCT-1K1 (f .FUNCT-1K1 X) =XBOOLE-0R4 N2"
        using tarski_def_1 sorry
    qed "sorry"
    have "rngFUNCT-1K2 (G *FUNCT-1K3 f) c=TARSKIR1 S"
    proof-
      have " for X be objectHIDDENM1 holds X inHIDDENR3 rngFUNCT-1K2 (G *FUNCT-1K3 f) implies X inHIDDENR3 S"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be objectHIDDENM1"
        assume "X inHIDDENR3 rngFUNCT-1K2 (G *FUNCT-1K3 f)"
        then obtain K1 where
          [ty]:"K1 be objectHIDDENM1" and 
          A34: "K1 inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 f)"and A35: "X =HIDDENR1 (G *FUNCT-1K3 f).FUNCT-1K1 K1"
          using funct_1_def_3 sorry
        have "f .FUNCT-1K1 K1 inTARSKIR2 rngFUNCT-1K2 f"
          using A26 A34 funct_1_def_3 sorry
        then obtain K3 where 
          [ty]:"K3 be ElementSUBSET-1M1-of M" and K3Def:"K3 = f .FUNCT-1K1 K1"
          using A25 sorry
        have "X =HIDDENR1 G .FUNCT-1K1 (f .FUNCT-1K1 K1)"
          using A34 A35 funct_1_th_12 sorry
        then have A36: "X =HIDDENR1 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K3)"
          using A22 sorry
        have "h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K3 =XBOOLE-0R4 N2"
          using A33 A26 A34 sorry
        thus "X inHIDDENR3 S"
          using A36 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (G *FUNCT-1K3 f) c=TARSKIR1 S"
        using tarski_def_3 sorry
    qed
    then have A37: "rngFUNCT-1K2 (G *FUNCT-1K3 f) =XBOOLE-0R4 S"
      using A27 sorry
    have A38: " for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K1 =XBOOLE-0R4 N2 & K1 <>HIDDENR2 K2 implies T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) <>HIDDENR2 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2)"
    proof-
      have " for K1 be ElementSUBSET-1M1-of M holds  for K2 be ElementSUBSET-1M1-of M holds h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K1 =XBOOLE-0R4 N2 & K1 <>HIDDENR2 K2 implies (T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) =XBOOLE-0R4 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) implies  False )"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
        fix K1 assume [ty]: "K1 be ElementSUBSET-1M1-of M"
        fix K2 assume [ty]: "K2 be ElementSUBSET-1M1-of M"
        assume A39: "h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K1 =XBOOLE-0R4 N2"
          and A40: "K1 <>HIDDENR2 K2"
        assume "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) =XBOOLE-0R4 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2)"
        then have "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) <>HIDDENR2 {}XBOOLE-0K1"
          using A16 A39 card_fil_th_11 sorry
        thus " False "
          using A3 A40 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A41: "G *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
    proof-
      have " for K1 be objectHIDDENM1 holds  for K2 be objectHIDDENM1 holds K1 inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 f) & (K2 inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 f) & (G *FUNCT-1K3 f).FUNCT-1K1 K1 =XBOOLE-0R4 (G *FUNCT-1K3 f).FUNCT-1K1 K2) implies (K1 <>HIDDENR2 K2 implies  False )"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
        fix K1 assume [ty]: "K1 be objectHIDDENM1"
        fix K2 assume [ty]: "K2 be objectHIDDENM1"
        assume A42: "K1 inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 f)"
          and A43: "K2 inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 f)"
          and A44: "(G *FUNCT-1K3 f).FUNCT-1K1 K1 =XBOOLE-0R4 (G *FUNCT-1K3 f).FUNCT-1K1 K2"
        assume "K1 <>HIDDENR2 K2"
        then have A45: "f .FUNCT-1K1 K1 <>HIDDENR2 f .FUNCT-1K1 K2"
          using A23 A26 A42 A43 sorry
        have A46: "f .FUNCT-1K1 K2 inTARSKIR2 rngFUNCT-1K2 f"
          using A26 A43 funct_1_def_3 sorry
        then obtain K4 where 
          [ty]:"K4 be ElementSUBSET-1M1-of M" and K4Def:"K4 = f .FUNCT-1K1 K2"
          using A25 sorry
        have A47: "(G *FUNCT-1K3 f).FUNCT-1K1 K2 =HIDDENR1 G .FUNCT-1K1 (f .FUNCT-1K1 K2)"
          using A43 funct_1_th_12 sorry
        also have "... = T .BINOP-1K1(N2,f .FUNCT-1K1 K2)"
          using A25 A22 A46 sorry
        finally have "(G *FUNCT-1K3 f).FUNCT-1K1 K2 =HIDDENR1 T .BINOP-1K1(N2,f .FUNCT-1K1 K2)"
           sorry
        have A48: "f .FUNCT-1K1 K1 inTARSKIR2 rngFUNCT-1K2 f"
          using A26 A42 funct_1_def_3 sorry
        then obtain K3 where 
          [ty]:"K3 be ElementSUBSET-1M1-of M" and K3Def:"K3 = f .FUNCT-1K1 K1"
          using A25 sorry
        have "h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K3 =XBOOLE-0R4 N2"
          using A33 A26 A42 sorry
        then have A49: "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K3) <>HIDDENR2 T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K4)"
          using A38 A45 sorry
        have "(G *FUNCT-1K3 f).FUNCT-1K1 K1 =HIDDENR1 G .FUNCT-1K1 (f .FUNCT-1K1 K1)"
          using A42 funct_1_th_12 sorry
        also have "... = T .BINOP-1K1(N2,f .FUNCT-1K1 K1)"
          using A25 A22 A48 sorry
        finally have "(G *FUNCT-1K3 f).FUNCT-1K1 K1 =HIDDENR1 T .BINOP-1K1(N2,f .FUNCT-1K1 K1)"
           sorry
        thus " False "
          using A44 A49 A47 sorry
      qed "sorry"
      thus "G *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    show " ex tVar13 be Subset-FamilySETFAM-1M1-of M st cardCARD-1K1 tVar13 =XBOOLE-0R4 M & (( for X1 be setHIDDENM2 holds X1 inTARSKIR2 tVar13 implies  not X1 inTARSKIR2 I) & ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds (X1 inTARSKIR2 tVar13 & X2 inTARSKIR2 tVar13) & X1 <>HIDDENR2 X2 implies X1 missesXBOOLE-0R1 X2))"
    proof(rule bexI[of _ "S"],rule conjMI,rule conjMI)
      have "domRELAT-1K1 (G *FUNCT-1K3 f) =XBOOLE-0R4 M"
        using A24 A25 A21 relat_1_th_27 sorry
      then have "(S,M)are-equipotentTARSKIR3"
        using A37 A41 wellord2_def_4 sorry
      thus "cardCARD-1K1 S =XBOOLE-0R4 M"
        using card_1_def_2 sorry
      show " for X1 be setHIDDENM2 holds X1 inTARSKIR2 S implies  not X1 inTARSKIR2 I"
      proof(rule ballI,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        assume "X1 inTARSKIR2 S"
        then have " ex K1 be ElementSUBSET-1M1-of M st T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) =XBOOLE-0R4 X1 & h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K1 =XBOOLE-0R4 N2"
           sorry
        thus " not X1 inTARSKIR2 I"
          using A16 sorry
      qed "sorry"
      show " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds (X1 inTARSKIR2 S & X2 inTARSKIR2 S) & X1 <>HIDDENR2 X2 implies X1 missesXBOOLE-0R1 X2"
      proof-
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds X1 inTARSKIR2 S & (X2 inTARSKIR2 S & X1 <>HIDDENR2 X2) implies X1 missesXBOOLE-0R1 X2"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix X1 assume [ty]: "X1 be setHIDDENM2"
          fix X2 assume [ty]: "X2 be setHIDDENM2"
          assume A50: "X1 inTARSKIR2 S"
            and A51: "X2 inTARSKIR2 S"
            and A52: "X1 <>HIDDENR2 X2"
          obtain K2 where
            [ty]:"K2 be ElementSUBSET-1M1-of M" and 
            A53: "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) =XBOOLE-0R4 X2"and "h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K2 =XBOOLE-0R4 N2"
            using A51 sorry
          obtain K1 where
            [ty]:"K1 be ElementSUBSET-1M1-of M" and 
            A54: "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) =XBOOLE-0R4 X1"and "h .FUNCT-2K3\<^bsub>(M,predecessorCARD-FILK7 M)\<^esub> K1 =XBOOLE-0R4 N2"
            using A50 sorry
          have "T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K1) /\\SUBSET-1K9\<^bsub>(M)\<^esub> T .BINOP-1K2\<^bsub>(predecessorCARD-FILK7 M,M,boolSETFAM-1K9 M)\<^esub>(N2,K2) =XBOOLE-0R4 {}XBOOLE-0K1"
            using A3 A52 A54 A53 sorry
          thus "X1 missesXBOOLE-0R1 X2"
            using A54 A53 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_36:
" for X be setHIDDENM2 holds  for N be CardinalCARD-1M1 holds N c=ORDINAL1R1 cardCARD-1K1 X implies ( ex Y be setHIDDENM2 st Y c=TARSKIR1 X & cardCARD-1K1 Y =XBOOLE-0R4 N)"
proof-
  have " for X be setHIDDENM2 holds  for N be CardinalCARD-1M1 holds N c=ORDINAL1R1 cardCARD-1K1 X implies ( ex tVar14 be setHIDDENM2 st tVar14 c=TARSKIR1 X & cardCARD-1K1 tVar14 =XBOOLE-0R4 N)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "(X,cardCARD-1K1 X)are-equipotentTARSKIR3"
      using card_1_def_2 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 cardCARD-1K1 X"and A3: "rngFUNCT-1K2 f =XBOOLE-0R4 X"
      using wellord2_def_4 sorry
    fix N assume [ty]: "N be CardinalCARD-1M1"
    assume "N c=ORDINAL1R1 cardCARD-1K1 X"
    then have A4: "domRELAT-1K1 (f  |RELAT-1K8 N) =XBOOLE-0R4 N"
      using A2 relat_1_th_62 sorry
    show " ex tVar14 be setHIDDENM2 st tVar14 c=TARSKIR1 X & cardCARD-1K1 tVar14 =XBOOLE-0R4 N"
    proof(rule bexI[of _ "f .:FUNCT-1K5 N"],rule conjMI)
      show "f .:FUNCT-1K5 N c=TARSKIR1 X"
        using A3 relat_1_th_111 sorry
      have A5: "rngFUNCT-1K2 (f  |RELAT-1K8 N) =XBOOLE-0R4 f .:FUNCT-1K5 N"
        using relat_1_th_115 sorry
      have "f  |RELAT-1K8 N be one-to-oneFUNCT-1V2"
        using A1 funct_1_th_52 sorry
      then have "(N,f .:FUNCT-1K5 N)are-equipotentTARSKIR3"
        using A4 A5 wellord2_def_4 sorry
      thus "cardCARD-1K1 (f .:FUNCT-1K5 N) =XBOOLE-0R4 N"
        using card_1_def_2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_37:
" for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds  not ( ex F be FilterCARD-FILM1-of M st F be uniformCARD-FILV1\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub> & F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M)"
proof-
  have " for M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1 holds ( ex F be FilterCARD-FILM1-of M st F be uniformCARD-FILV1\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub> & F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M) implies  False "
  proof(rule ballI,rule impI)
    fix M assume [ty]: "M be  non limit-cardinalCARD-1V2\<bar>AlephCARD-5M1"
    assume Given: " ex F be FilterCARD-FILM1-of M st F be uniformCARD-FILV1\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub> & F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M"
    then obtain F where
      [ty]:"F be FilterCARD-FILM1-of M" and 
      A1: "F be uniformCARD-FILV1\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub>"and A2: "F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M"
       sorry
    have "Frechet-IdealCARD-FILK6 M c=TARSKIR1 dualCARD-FILK2\<^bsub>(M)\<^esub> F"
    proof-
      have " for X be objectHIDDENM1 holds X inHIDDENR3 Frechet-IdealCARD-FILK6 M implies ( not X inHIDDENR3 dualCARD-FILK2\<^bsub>(M)\<^esub> F implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix X assume [ty]: "X be objectHIDDENM1"
        assume A3: "X inHIDDENR3 Frechet-IdealCARD-FILK6 M"
        obtain X1 where 
          [ty]:"X1 be SubsetSUBSET-1M2-of M" and X1Def:"X1 = X"
          using A3 sorry
        assume " not X inHIDDENR3 dualCARD-FILK2\<^bsub>(M)\<^esub> F"
        then have "X1 inTARSKIR2 F"
          using A1 card_fil_th_22 sorry
        then have A4: "cardCARD-1K1 X1 =XBOOLE-0R4 cardCARD-1K1 M"
          using A1 sorry
        have "cardCARD-1K1 X1 inTARSKIR2 cardCARD-1K1 M"
          using A3 card_fil_th_19 sorry
        thus " False "
          using A4 sorry
      qed "sorry"
      thus "Frechet-IdealCARD-FILK6 M c=TARSKIR1 dualCARD-FILK2\<^bsub>(M)\<^esub> F"
        using tarski_def_3 sorry
    qed
    then obtain S where
      [ty]:"S be Subset-FamilySETFAM-1M1-of M" and 
      A5: "cardCARD-1K1 S =XBOOLE-0R4 M"and A6: " for X1 be setHIDDENM2 holds X1 inTARSKIR2 S implies  not X1 inTARSKIR2 dualCARD-FILK2\<^bsub>(M)\<^esub> F"and A7: " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds (X1 inTARSKIR2 S & X2 inTARSKIR2 S) & X1 <>HIDDENR2 X2 implies X1 missesXBOOLE-0R1 X2"
      using A2 card_fil_th_12 card_fil_th_35 sorry
    have "S be infiniteFINSET-1V2"
      using A5 sorry
    then obtain X1 where
      [ty]:"X1 be objectHIDDENM1" and 
      A8: "X1 inHIDDENR3 S"
      using xboole_0_def_1 sorry
    have "S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 M)\<^esub> {TARSKIK1 X1} <>HIDDENR2 {}XBOOLE-0K1"
    proof-
      have "S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 M)\<^esub> {TARSKIK1 X1} =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
      proof(rule impI)
        assume "S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 M)\<^esub> {TARSKIK1 X1} =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "S c=TARSKIR1 {TARSKIK1 X1}"
          using xboole_1_th_37 sorry
        thus " False "
          using A5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain X2 where
      [ty]:"X2 be objectHIDDENM1" and 
      A9: "X2 inHIDDENR3 S \\SUBSET-1K7\<^bsub>(boolZFMISC-1K1 M)\<^esub> {TARSKIK1 X1}"
      using xboole_0_def_1 sorry
    have A10: "S \\SUBSET-1K6 {TARSKIK1 X1} be SubsetSUBSET-1M2-of S"
       sorry
    have 
      [ty]:"X1 be setHIDDENM2" and
      [ty]:"X2 be setHIDDENM2"
      using tarski_th_1 sorry
    have " not X2 inTARSKIR2 {TARSKIK1 X1}"
      using A9 xboole_0_def_5 sorry
    then have "X2 <>HIDDENR2 X1"
      using tarski_def_1 sorry
    then have "X1 missesXBOOLE-0R1 X2"
      using A7 A8 A9 A10 sorry
    then have A11: "X1 /\\XBOOLE-0K3 X2 =XBOOLE-0R4 {}XBOOLE-0K1"
       sorry
    have 
      [ty]:"X1 be SubsetSUBSET-1M2-of M" and
      [ty]:"X2 be SubsetSUBSET-1M2-of M"
      using A8 A9 sorry
    have A12: " for X1 be setHIDDENM2 holds X1 inTARSKIR2 S implies X1 inTARSKIR2 F"
      using A1 A6 card_fil_th_22 sorry
    then have A13: "X1 inTARSKIR2 F"
      using A8 sorry
    have "X2 inTARSKIR2 F"
      using A12 A9 A10 sorry
    then have "{}XBOOLE-0K1 inTARSKIR2 F"
      using A11 A13 card_fil_def_1 sorry
    thus " False "
      using card_fil_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve M for "AlephCARD-5M1"
mtheorem card_fil_th_38:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be limit-cardinalCARD-1V2"
proof-
  have " for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies ( not M be limit-cardinalCARD-1V2 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix M assume [ty]: "M be AlephCARD-5M1"
    assume "M be measurableCARD-FILV7"
    then obtain F where
      [ty]:"F be FilterCARD-FILM1-of M" and 
      A1: "F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M"and A2: "F be  non principalCARD-FILV2\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub>"
       sorry
    assume A3: " not M be limit-cardinalCARD-1V2"
    have "F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> cardCARD-1K1 M"
      using A1 sorry
    thus " False "
      using A2 A3 card_fil_th_23 card_fil_th_37 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_39:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be inaccessibleCARD-FILV4"
  using card_fil_th_33 card_fil_th_38 sorry

mtheorem card_fil_th_40:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be strong-limitCARD-FILV5"
proof-
  have " for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies ( not M be strong-limitCARD-FILV5 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix M assume [ty]: "M be AlephCARD-5M1"
    assume "M be measurableCARD-FILV7"
    then obtain F where
      [ty]:"F be FilterCARD-FILM1-of M" and 
      A1: "F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> M"and A2: "F be  non principalCARD-FILV2\<^bsub>(M)\<^esub>\<bar>being-ultrafilterCARD-FILV3\<^bsub>(M)\<^esub>"
       sorry
    assume " not M be strong-limitCARD-FILV5"
    then obtain N where
      [ty]:"N be CardinalCARD-1M1" and 
      A3: "N inTARSKIR2 M"and A4: " not expCARD-2K3(\<two>\<^sub>M,N) inTARSKIR2 M"
       sorry
    have A5: "M c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,N)"
      using A4 card_1_th_4 sorry
    then have "M c=ORDINAL1R1 cardCARD-1K1 (FuncsFUNCT-2K1(N,\<two>\<^sub>M))"
      using card_2_def_3 sorry
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A6: "Y c=TARSKIR1 FuncsFUNCT-2K1(N,\<two>\<^sub>M)"and A7: "cardCARD-1K1 Y =XBOOLE-0R4 M"
      using card_fil_th_36 sorry
    have "N be infiniteFINSET-1V2"
    proof-
      have "N be finiteFINSET-1V1 implies  False "
      proof(rule impI)
        have "M c=ORDINAL1R1 expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 N)"
          using A5 sorry
        then have A8: "M c=ORDINAL1R1 cardCARD-1K1 (boolSETFAM-1K9 N)"
          using card_2_th_31 sorry
        assume "N be finiteFINSET-1V1"
        thus " False "
          using A8 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain N1 where 
      [ty]:"N1 be AlephCARD-5M1" and N1Def:"N1 = N"
       sorry
    have "(Y,M)are-equipotentTARSKIR3"
      using A7 card_1_def_2 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A9: "f be one-to-oneFUNCT-1V2"and A10: "domRELAT-1K1 f =XBOOLE-0R4 M"and A11: "rngFUNCT-1K2 f =XBOOLE-0R4 Y"
      using wellord2_def_4 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 Lamb1 =XBOOLE-0R4 Lamb2 }) inTARSKIR2 F"
    have A12: " for A be ElementSUBSET-1M1-of N1 holds  ex i be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } st ?P(A,i)"
    proof-
      have " for A be ElementSUBSET-1M1-of N1 holds  ex tVar15 be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } st f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 tVar15 }) inTARSKIR2 F"
      proof(rule ballI)
        fix A assume [ty]: "A be ElementSUBSET-1M1-of N1"
        let ?Y1 = "{h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M }"
        obtain Inv1 where 
          [ty]:"Inv1 be SubsetSUBSET-1M2-of M" and Inv1Def:"Inv1 = f \<inverse>FUNCT-1K6 ?Y1"
          using A10 relat_1_th_132 sorry
        let ?Y0 = "{h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 }"
        obtain Inv0 where 
          [ty]:"Inv0 be SubsetSUBSET-1M2-of M" and Inv0Def:"Inv0 = f \<inverse>FUNCT-1K6 ?Y0"
          using A10 relat_1_th_132 sorry
        have A13: " for g1 be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) holds g1 inTARSKIR2 Y implies g1 inTARSKIR2 ?Y1 or g1 inTARSKIR2 ?Y0"
        proof-
          have " for g1 be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) holds g1 inTARSKIR2 Y implies  not ( not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } &  not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
          proof(rule ballI,rule impI)
            fix g1 assume [ty]: "g1 be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })"
            assume A14: "g1 inTARSKIR2 Y"
            show " not ( not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } &  not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
            proof-
              have cases: "g1 inTARSKIR2 ?Y0 or  not g1 inTARSKIR2 ?Y0"
                 sorry
              have case1: "g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 } implies  not ( not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } &  not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
              proof(rule impI)
                assume "g1 inTARSKIR2 ?Y0"
                thus " not ( not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } &  not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
                   sorry
              qed
              have case2: " not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 } implies  not ( not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } &  not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
              proof(rule impI)
                assume " not g1 inTARSKIR2 ?Y0"
                then have " not g1 .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1"
                  using A14 sorry
                then have "g1 .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M"
                  using tarski_def_2 sorry
                thus " not ( not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } &  not g1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
                  using A14 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "Y \\SUBSET-1K6 ?Y0 =XBOOLE-0R4 ?Y1"
        proof-
          have "Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 }) =XBOOLE-0R4 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M }"
          proof-
            have "Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 }) c=TARSKIR1 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } & {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } c=TARSKIR1 Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
            proof(rule conjMI)
              show "Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 }) c=TARSKIR1 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M }"
              proof-
                have " for X be objectHIDDENM1 holds X inHIDDENR3 Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 }) implies X inHIDDENR3 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M }"
                proof(rule ballI,rule impI)
                  fix X assume [ty]: "X be objectHIDDENM1"
                  assume A15: "X inHIDDENR3 Y \\SUBSET-1K6 ?Y0"
                  have "X inHIDDENR3 Y"
                    using A15 sorry
                  then obtain g1 where
                    [ty]:"g1 be FunctionFUNCT-1M1" and 
                    A16: "g1 =HIDDENR1 X"and A17: "domRELAT-1K1 g1 =XBOOLE-0R4 N1 & rngFUNCT-1K2 g1 c=TARSKIR1 {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }"
                    using A6 card_1_th_50 funct_2_def_2 sorry
                  obtain g2 where 
                    [ty]:"g2 be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })" and g2Def:"g2 = g1"
                    using A17 funct_2_def_1 relset_1_th_4 sorry
                  have " not X inHIDDENR3 ?Y0"
                    using A15 xboole_0_def_5 sorry
                  then have "g2 inTARSKIR2 ?Y1"
                    using A13 A15 A16 sorry
                  thus "X inHIDDENR3 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M }"
                    using A16 sorry
                qed "sorry"
                thus "Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 }) c=TARSKIR1 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M }"
                  using tarski_def_3 sorry
              qed
              have " for X be objectHIDDENM1 holds X inHIDDENR3 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } implies X inHIDDENR3 Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
              proof(rule ballI,rule impI)
                fix X assume [ty]: "X be objectHIDDENM1"
                assume "X inHIDDENR3 ?Y1"
                then obtain h where
                  [ty]:"h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })" and 
                  A18: "X =HIDDENR1 h & h inTARSKIR2 Y"and A19: "h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M"
                   sorry
                have " not h inTARSKIR2 ?Y0"
                proof-
                  have "h inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 } implies  False "
                  proof(rule impI)
                    assume "h inTARSKIR2 ?Y0"
                    then have " ex h1 be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) st (h1 =FUNCT-2R2\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> h & h1 inTARSKIR2 Y) & h1 .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1"
                       sorry
                    thus " False "
                      using A19 sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                thus "X inHIDDENR3 Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
                  using A18 xboole_0_def_5 sorry
              qed "sorry"
              thus "{h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M } c=TARSKIR1 Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 })"
                using tarski_def_3 sorry
            qed
            thus "Y \\SUBSET-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 }) =XBOOLE-0R4 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 \<one>\<^sub>M }"
              using xboole_0_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have A20: "Inv1 =HIDDENR1 f \<inverse>FUNCT-1K6 (rngFUNCT-1K2 f) \\SUBSET-1K6 Inv0"
          using A11 funct_1_th_69 sorry
        also have "... = M \\SUBSET-1K6 Inv0"
          using A10 relat_1_th_134 sorry
        finally have "Inv1 =HIDDENR1 M \\SUBSET-1K6 Inv0"
           sorry
        show " ex tVar15 be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } st f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 tVar15 }) inTARSKIR2 F"
        proof-
          have cases: "Inv0 inTARSKIR2 F or M \\SUBSET-1K6 Inv0 inTARSKIR2 F"
            using A2 sorry
          have case1: "Inv0 inTARSKIR2 F implies ( ex tVar15 be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } st f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 tVar15 }) inTARSKIR2 F)"
          proof(rule impI)
            assume A21: "Inv0 inTARSKIR2 F"
            obtain Z where 
              [ty]:"Z be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }" and ZDef:"Z = {}XBOOLE-0K1"
              using tarski_def_2 sorry
            show " ex tVar15 be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } st f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 tVar15 }) inTARSKIR2 F"
            proof(rule bexI[of _ "Z"])
              show "f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 Z }) inTARSKIR2 F"
                using A21 sorry
            qed "sorry"
          qed
          have case2: "M \\SUBSET-1K6 Inv0 inTARSKIR2 F implies ( ex tVar16 be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } st f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 tVar16 }) inTARSKIR2 F)"
          proof(rule impI)
            assume A22: "M \\SUBSET-1K6 Inv0 inTARSKIR2 F"
            obtain O where 
              [ty]:"O be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }" and ODef:"O = \<one>\<^sub>M"
              using tarski_def_2 sorry
            show " ex tVar16 be ElementSUBSET-1M1-of {TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M } st f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 tVar16 }) inTARSKIR2 F"
            proof(rule bexI[of _ "O"])
              show "f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-1K1 A =XBOOLE-0R4 O }) inTARSKIR2 F"
                using A20 A22 sorry
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })" and 
      A23: " for A be ElementSUBSET-1M1-of N1 holds ?P(A,g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A)"
      using funct_2_sch_3 A12 sorry
    let ?T = "\<lambda>Lamb1. f \<inverse>FUNCT-1K6 ({h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> Lamb1 =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> Lamb1 })"
    obtain f1 where 
      [ty]:"f1 be FunctionFUNCT-2M1-of(M,Y)" and f1Def:"f1 = f"
      using A10 A11 funct_2_th_1 sorry
    let ?MEET = "meetSETFAM-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 })"
    have A24: "rngFUNCT-1K2 (f  |RELAT-1K8 ?MEET) =XBOOLE-0R4 f .:FUNCT-1K5 ?MEET & f  |RELAT-1K8 ?MEET be one-to-oneFUNCT-1V2"
      using A9 funct_1_th_52 relat_1_th_115 sorry
    have "cardCARD-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) c=ORDINAL1R1 cardCARD-1K1 N1"
      using trees_2_sch_2 sorry
    then have "cardCARD-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) c=ORDINAL1R1 N1"
       sorry
    then have A25: "cardCARD-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) inTARSKIR2 M"
      using A3 ordinal1_th_12 sorry
    let ?B = "the ElementSUBSET-1M1-of N1"
    have A26: "{?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 } c=TARSKIR1 F"
    proof-
      have "{f \<inverse>FUNCT-1K6 ({hc where hc be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : hc inTARSKIR2 Y & hc .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A }) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 } c=TARSKIR1 F"
      proof-
        have " for X be objectHIDDENM1 holds X inHIDDENR3 {f \<inverse>FUNCT-1K6 ({hc where hc be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : hc inTARSKIR2 Y & hc .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A }) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 } implies X inHIDDENR3 F"
        proof(rule ballI,rule impI)
          fix X assume [ty]: "X be objectHIDDENM1"
          assume "X inHIDDENR3 {?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }"
          then have " ex A be ElementSUBSET-1M1-of N1 st X =HIDDENR1 ?T(A) & A inTARSKIR2 N1"
             sorry
          thus "X inHIDDENR3 F"
            using A23 sorry
        qed "sorry"
        thus "{?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 } c=TARSKIR1 F"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "?T(?B) inTARSKIR2 {?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }"
       sorry
    then have A27: "meetSETFAM-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) inTARSKIR2 F"
      using A1 A25 A26 sorry
    have A28: "Y be infiniteFINSET-1V2"
      using A7 sorry
    have A29: " for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) implies f .FUNCT-1K1 X =XBOOLE-0R4 g"
    proof-
      have " for X be setHIDDENM2 holds X inTARSKIR2 meetSETFAM-1K1 ({f \<inverse>FUNCT-1K6 ({hc where hc be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : hc inTARSKIR2 Y & hc .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A }) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) implies f .FUNCT-1K1 X =XBOOLE-0R4 g"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        assume A30: "X inTARSKIR2 meetSETFAM-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 })"
        then obtain X1 where 
          [ty]:"X1 be ElementSUBSET-1M1-of M" and X1Def:"X1 = X"
          using A27 sorry
        have "f1 .FUNCT-2K3\<^bsub>(M,Y)\<^esub> X1 inTARSKIR2 Y"
          using A28 funct_2_th_5 sorry
        then obtain h1 where
          [ty]:"h1 be FunctionFUNCT-1M1" and 
          A31: "f1 .FUNCT-2K3\<^bsub>(M,Y)\<^esub> X1 =XBOOLE-0R4 h1"and A32: "domRELAT-1K1 h1 =XBOOLE-0R4 N"and "rngFUNCT-1K2 h1 c=TARSKIR1 \<two>\<^sub>M"
          using A6 funct_2_def_2 sorry
        have A33: " for Z be objectHIDDENM1 holds Z inHIDDENR3 N1 implies h1 .FUNCT-1K1 Z =XBOOLE-0R4 g .FUNCT-1K1 Z"
        proof(rule ballI,rule impI)
          fix Z assume [ty]: "Z be objectHIDDENM1"
          assume "Z inHIDDENR3 N1"
          then obtain Z1 where 
            [ty]:"Z1 be ElementSUBSET-1M1-of N1" and Z1Def:"Z1 = Z"
             sorry
          have "?T(Z1) inTARSKIR2 {?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }"
             sorry
          then have "X1 inTARSKIR2 ?T(Z1)"
            using A30 setfam_1_def_1 sorry
          then have "f1 .FUNCT-2K3\<^bsub>(M,Y)\<^esub> X1 inTARSKIR2 {h where h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : h inTARSKIR2 Y & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> Z1 =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> Z1 }"
            using funct_1_def_7 sorry
          then have " ex h be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) st (f .FUNCT-1K1 X1 =XBOOLE-0R4 h & h inTARSKIR2 Y) & h .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> Z1 =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> Z1"
             sorry
          thus "h1 .FUNCT-1K1 Z =XBOOLE-0R4 g .FUNCT-1K1 Z"
            using A31 sorry
        qed "sorry"
        have "domRELSET-1K1\<^bsub>(N1)\<^esub> g =XBOOLE-0R4 N1"
          using funct_2_def_1 sorry
        thus "f .FUNCT-1K1 X =XBOOLE-0R4 g"
          using A31 A32 A33 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A34: "f .:FUNCT-1K5 ?MEET c=TARSKIR1 {TARSKIK1 g}"
    proof-
      have "f .:FUNCT-1K5 meetSETFAM-1K1 ({f \<inverse>FUNCT-1K6 ({hc where hc be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : hc inTARSKIR2 Y & hc .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A }) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) c=TARSKIR1 {TARSKIK1 g}"
      proof-
        have " for X be objectHIDDENM1 holds X inHIDDENR3 f .:FUNCT-1K5 meetSETFAM-1K1 ({f \<inverse>FUNCT-1K6 ({hc where hc be FunctionFUNCT-2M1-of(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M }) : hc inTARSKIR2 Y & hc .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(N1,{TARSKIK2 {}XBOOLE-0K1,\<one>\<^sub>M })\<^esub> A }) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) implies X inHIDDENR3 {TARSKIK1 g}"
        proof(rule ballI,rule impI)
          fix X assume [ty]: "X be objectHIDDENM1"
          assume "X inHIDDENR3 f .:FUNCT-1K5 ?MEET"
          then have " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 ?MEET) & X =HIDDENR1 f .FUNCT-1K1 x"
            using funct_1_def_6 sorry
          then have "X =HIDDENR1 g"
            using A29 sorry
          thus "X inHIDDENR3 {TARSKIK1 g}"
            using tarski_def_1 sorry
        qed "sorry"
        thus "f .:FUNCT-1K5 meetSETFAM-1K1 ({?T(A) where A be ElementSUBSET-1M1-of N1 : A inTARSKIR2 N1 }) c=TARSKIR1 {TARSKIK1 g}"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "?MEET =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 ?MEET"
      using A10 A27 xboole_1_th_28 sorry
    then have "domRELAT-1K1 (f  |RELAT-1K8 ?MEET) =XBOOLE-0R4 ?MEET"
      using relat_1_th_61 sorry
    then have A35: "cardCARD-1K1 ?MEET c=ORDINAL1R1 cardCARD-1K4 {TARSKIK1 g}"
      using A34 A24 card_1_th_10 sorry
    obtain MEET where 
      [ty]:"MEET be SubsetSUBSET-1M2-of M" and MEETDef:"MEET = ?MEET"
      using A27 sorry
    have "F is-complete-withCARD-FILR3\<^bsub>(M)\<^esub> cardCARD-1K1 M"
      using A1 sorry
    then have "F be uniformCARD-FILV1\<^bsub>(M)\<^esub>"
      using A2 card_fil_th_23 sorry
    then have "cardCARD-1K1 MEET =XBOOLE-0R4 cardCARD-1K1 M"
      using A27 sorry
    thus " False "
      using A35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_fil_th_41:
" for M be AlephCARD-5M1 holds M be measurableCARD-FILV7 implies M be strongly-inaccessibleCARD-FILV6"
  using card_fil_th_33 card_fil_th_40 sorry

end
