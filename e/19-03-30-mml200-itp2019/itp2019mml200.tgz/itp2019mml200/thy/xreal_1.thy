theory xreal_1
  imports arytm_0 xcmplx_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d for "RealXREAL-0M1"
reserve r, s for "RealXREAL-0M1"
mlemma xreal_1_lm_1:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 x9 & s =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies r <=XXREAL-0R1 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds ((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 x9 & s =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies ((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2)) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1)))) or ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies  not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1))"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume A1: "((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 x9 & s =HIDDENR1 y9) & x9 <='ARYTM-2R1 y9) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (r =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & y9 <='ARYTM-2R1 x9)) or s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
    show "((r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2)) or (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) & (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1)))) or ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) & ( not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies  not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1))"
    proof-
      have cases: "(r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2 or r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) or  not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
         sorry
      have case1: "r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2 implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2))"
      proof(rule impI)
        assume "r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2"
        thus " not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 VarFor1 & s =HIDDENR1 VarFor2) & VarFor1 <='ARYTM-2R1 VarFor2))"
          using A1 arytm_0_th_5 xboole_0_th_3 sorry
      qed
      have case2: "r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1))"
      proof(rule impI)
        assume "r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        thus " not ( for VarFor1 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  for VarFor2 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 holds  not ((r =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor1 ] & s =HIDDENR1 [TARSKIK4 0NUMBERSK6,VarFor2 ]) & VarFor2 <='ARYTM-2R1 VarFor1))"
          using A1 arytm_0_th_5 xboole_0_th_3 sorry
      qed
      have case3: " not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies  not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1)"
      proof(rule impI)
        assume " not (r inHIDDENR3 REAL+ARYTM-2K2 & s inHIDDENR3 REAL+ARYTM-2K2) &  not (r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & s inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        thus " not (( not (s inHIDDENR3 REAL+ARYTM-2K2 & r inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) &  not r =HIDDENR1 -inftyXXREAL-0K2) &  not s =HIDDENR1 +inftyXXREAL-0K1)"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_2:
" for a be RealXREAL-0M1 holds  for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds a =HIDDENR1 [*ARYTM-0K5 x1,x2 *] implies x2 =XBOOLE-0R4 0NUMBERSK6 & a =HIDDENR1 x1"
proof-
  have " for a be RealXREAL-0M1 holds  for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds a =HIDDENR1 [*ARYTM-0K5 x1,x2 *] implies (x2 <>HIDDENR2 0NUMBERSK6 implies  False ) & a =HIDDENR1 x1"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix x1 assume [ty]: "x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix x2 assume [ty]: "x2 be ElementSUBSET-1M1-of REALNUMBERSK2"
    assume A1: "a =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
    have A2: "a inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    show "x2 <>HIDDENR2 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "x2 <>HIDDENR2 0NUMBERSK6"
      then have "a =HIDDENR1 (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K6(x1,x2)"
        using A1 arytm_0_def_5 sorry
      thus " False "
        using A2 arytm_0_th_8 sorry
    qed
    thus "a =HIDDENR1 x1"
      using A1 arytm_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_3:
" for a9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a9 =HIDDENR1 a & b9 =HIDDENR1 b implies +ARYTM-0K1(a9,b9) =XBOOLE-0R4 a +XCMPLX-0K2 b"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix a9 assume [ty]: "a9 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix b9 assume [ty]: "b9 be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A1: "a9 =HIDDENR1 a"
    and A2: "b9 =HIDDENR1 b"
  obtain x1 x2 y1 y2 where
    [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
    A3: "a =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A4: "b =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A5: "a +XCMPLX-0K2 b =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
    using xcmplx_0_def_4 sorry
  have A6: "y2 =XBOOLE-0R4 0NUMBERSK6"
    using A4 xreal_1_lm_2 sorry
  have "x2 =XBOOLE-0R4 0NUMBERSK6"
    using A3 xreal_1_lm_2 sorry
  then have A7: "+ARYTM-0K1(x2,y2) =XBOOLE-0R4 0NUMBERSK6"
    using A6 arytm_0_th_11 sorry
  have A8: "b =HIDDENR1 y1"
    using A4 xreal_1_lm_2 sorry
  have "a =HIDDENR1 x1"
    using A3 xreal_1_lm_2 sorry
  thus "+ARYTM-0K1(a9,b9) =XBOOLE-0R4 a +XCMPLX-0K2 b"
    using A1 A2 A5 A8 A7 arytm_0_def_5 sorry
qed "sorry"

mlemma xreal_1_lm_4:
"{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
  using tarski_def_1 sorry

mlemma xreal_1_lm_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    obtain x1 y1 z1 where 
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and x1Def:"x1 = a" and
      [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" and y1Def:"y1 = b" and
      [ty]:"z1 be ElementSUBSET-1M1-of REALNUMBERSK2" and z1Def:"z1 = c"
      using xreal_0_def_1 sorry
    have A1: "+ARYTM-0K1(y1,z1) =XBOOLE-0R4 b +XCMPLX-0K2 c"
      using xreal_1_lm_3 sorry
    have A2: "+ARYTM-0K1(x1,z1) =XBOOLE-0R4 a +XCMPLX-0K2 c"
      using xreal_1_lm_3 sorry
    assume A3: "a <=XXREAL-0R1 b"
    show "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
    proof-
      have cases: "((((a inHIDDENR3 REAL+ARYTM-2K2 & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 REAL+ARYTM-2K2) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 REAL+ARYTM-2K2)) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2)) or a inHIDDENR3 REAL+ARYTM-2K2 & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
        using A3 xxreal_0_def_5 sorry
      have case1: "a inHIDDENR3 REAL+ARYTM-2K2 & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 REAL+ARYTM-2K2) implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A4: "a inHIDDENR3 REAL+ARYTM-2K2"
          and A5: "b inHIDDENR3 REAL+ARYTM-2K2"
          and A6: "c inHIDDENR3 REAL+ARYTM-2K2"
        obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A7: "b =HIDDENR1 b9"and A8: "c =HIDDENR1 c99"and A9: "+ARYTM-0K1(y1,z1) =XBOOLE-0R4 b9 +ARYTM-2K7 c99"
          using A5 A6 arytm_0_def_1 sorry
        obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A10: "a =HIDDENR1 a9"and A11: "c =HIDDENR1 c9"and A12: "+ARYTM-0K1(x1,z1) =XBOOLE-0R4 a9 +ARYTM-2K7 c9"
          using A4 A6 arytm_0_def_1 sorry
        have " ex a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (a =HIDDENR1 a99 & b =HIDDENR1 b99) & a99 <='ARYTM-2R1 b99"
          using A3 A4 A5 xxreal_0_def_5 sorry
        then have "a9 +ARYTM-2K7 c9 <='ARYTM-2R1 b9 +ARYTM-2K7 c99"
          using A10 A11 A7 A8 arytm_1_th_7 sorry
        thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
          using A1 A2 A12 A9 xreal_1_lm_1 sorry
      qed
      have case2: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 REAL+ARYTM-2K2) implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A13: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A14: "b inHIDDENR3 REAL+ARYTM-2K2"
          and A15: "c inHIDDENR3 REAL+ARYTM-2K2"
        obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          "b =HIDDENR1 b9"and A16: "c =HIDDENR1 c99"and A17: "+ARYTM-0K1(y1,z1) =XBOOLE-0R4 b9 +ARYTM-2K7 c99"
          using A14 A15 arytm_0_def_1 sorry
        obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ]"and A18: "c =HIDDENR1 c9"and A19: "+ARYTM-0K1(x1,z1) =XBOOLE-0R4 c9 -ARYTM-1K2 a9"
          using A13 A15 arytm_0_def_1 sorry
        have "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
        proof-
          show "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
          proof-
            have cases: "a9 <='ARYTM-2R1 c9 or  not a9 <='ARYTM-2R1 c9"
               sorry
            have case1: "a9 <='ARYTM-2R1 c9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume A20: "a9 <='ARYTM-2R1 c9"
              have A21: "c9 -'ARYTM-1K1 a9 <='ARYTM-2R1 c9"
                using arytm_1_th_11 sorry
              have "c9 <='ARYTM-2R1 b9 +ARYTM-2K7 c99"
                using A18 A16 arytm_2_th_19 sorry
              then have A22: "c9 -'ARYTM-1K1 a9 <='ARYTM-2R1 b9 +ARYTM-2K7 c99"
                using A21 arytm_1_th_3 sorry
              have "c9 -ARYTM-1K2 a9 =XBOOLE-0R4 c9 -'ARYTM-1K1 a9"
                using A20 arytm_1_def_2 sorry
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                using A1 A2 A19 A17 A22 xreal_1_lm_1 sorry
            qed
            have case2: " not a9 <='ARYTM-2R1 c9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume " not a9 <='ARYTM-2R1 c9"
              then have "c9 -ARYTM-1K2 a9 =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 -'ARYTM-1K1 c9 ]"
                using arytm_1_def_2 sorry
              then have "c9 -ARYTM-1K2 a9 inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using xreal_1_lm_4 zfmisc_1_th_87 sorry
              then have A23: " not a +XCMPLX-0K2 c inTARSKIR2 REAL+ARYTM-2K2"
                using A2 A19 arytm_0_th_5 xboole_0_th_3 sorry
              have " not b +XCMPLX-0K2 c inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using A1 A17 arytm_0_th_5 xboole_0_th_3 sorry
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                using A23 xxreal_0_def_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
           sorry
      qed
      have case3: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 REAL+ARYTM-2K2) implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A24: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A25: "b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A26: "c inHIDDENR3 REAL+ARYTM-2K2"
        obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A27: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b9 ]"and A28: "c =HIDDENR1 c99"and A29: "+ARYTM-0K1(y1,z1) =XBOOLE-0R4 c99 -ARYTM-1K2 b9"
          using A25 A26 arytm_0_def_1 sorry
        obtain a99 b99 where
          [ty]:"a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A30: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a99 ]"and A31: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b99 ]"and A32: "b99 <='ARYTM-2R1 a99"
          using A3 A24 A25 xxreal_0_def_5 sorry
        obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A33: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ]"and A34: "c =HIDDENR1 c9"and A35: "+ARYTM-0K1(x1,z1) =XBOOLE-0R4 c9 -ARYTM-1K2 a9"
          using A24 A26 arytm_0_def_1 sorry
        have A36: "a9 =XBOOLE-0R4 a99"
          using A30 A33 xtuple_0_th_1 sorry
        have A37: "b9 =XBOOLE-0R4 b99"
          using A31 A27 xtuple_0_th_1 sorry
        have "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
        proof-
          show "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
          proof-
            have cases: "a9 <='ARYTM-2R1 c9 or  not a9 <='ARYTM-2R1 c9"
               sorry
            have case1: "a9 <='ARYTM-2R1 c9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume A38: "a9 <='ARYTM-2R1 c9"
              then have "b9 <='ARYTM-2R1 c9"
                using A32 A36 A37 arytm_1_th_3 sorry
              then have A39: "c9 -ARYTM-1K2 b9 =XBOOLE-0R4 c9 -'ARYTM-1K1 b9"
                using arytm_1_def_2 sorry
              have A40: "c9 -ARYTM-1K2 a9 =XBOOLE-0R4 c9 -'ARYTM-1K1 a9"
                using A38 arytm_1_def_2 sorry
              have "c9 -'ARYTM-1K1 a9 <='ARYTM-2R1 c99 -'ARYTM-1K1 b9"
                using A32 A34 A28 A36 A37 arytm_1_th_16 sorry
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                using A1 A2 A34 A35 A28 A29 A40 A39 xreal_1_lm_1 sorry
            qed
            have case2: " not a9 <='ARYTM-2R1 c9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume " not a9 <='ARYTM-2R1 c9"
              then have A41: "+ARYTM-0K1(x1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 -'ARYTM-1K1 c9 ]"
                using A35 arytm_1_def_2 sorry
              then have A42: "+ARYTM-0K1(x1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using xreal_1_lm_4 zfmisc_1_th_87 sorry
              have "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
              proof-
                show "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                proof-
                  have cases: "b9 <='ARYTM-2R1 c9 or  not b9 <='ARYTM-2R1 c9"
                     sorry
                  have case1: "b9 <='ARYTM-2R1 c9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                  proof(rule impI)
                    assume "b9 <='ARYTM-2R1 c9"
                    then have "c9 -ARYTM-1K2 b9 =XBOOLE-0R4 c9 -'ARYTM-1K1 b9"
                      using arytm_1_def_2 sorry
                    then have A43: " not +ARYTM-0K1(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using A34 A28 A29 arytm_0_th_5 xboole_0_th_3 sorry
                    have " not +ARYTM-0K1(x1,z1) inTARSKIR2 REAL+ARYTM-2K2"
                      using A42 arytm_0_th_5 xboole_0_th_3 sorry
                    thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                      using A1 A2 A43 xxreal_0_def_5 sorry
                  qed
                  have case2: " not b9 <='ARYTM-2R1 c9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                  proof(rule impI)
                    assume A44: " not b9 <='ARYTM-2R1 c9"
                    have A45: "b9 -'ARYTM-1K1 c9 <='ARYTM-2R1 a9 -'ARYTM-1K1 c9"
                      using A32 A36 A37 arytm_1_th_17 sorry
                    have A46: "+ARYTM-0K1(y1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,b9 -'ARYTM-1K1 c9 ]"
                      using A34 A28 A29 A44 arytm_1_def_2 sorry
                    then have "+ARYTM-0K1(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using xreal_1_lm_4 zfmisc_1_th_87 sorry
                    thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                      using A1 A2 A41 A42 A46 A45 xreal_1_lm_1 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
           sorry
      qed
      have case4: "a inHIDDENR3 REAL+ARYTM-2K2 & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A47: "a inHIDDENR3 REAL+ARYTM-2K2"
          and A48: "b inHIDDENR3 REAL+ARYTM-2K2"
          and A49: "c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A50: "b =HIDDENR1 b9"and A51: "c =HIDDENR1 [TARSKIK4 0NUMBERSK6,c99 ]"and A52: "+ARYTM-0K1(y1,z1) =XBOOLE-0R4 b9 -ARYTM-1K2 c99"
          using A48 A49 arytm_0_def_1 sorry
        obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A53: "a =HIDDENR1 a9"and A54: "c =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 ]"and A55: "+ARYTM-0K1(x1,z1) =XBOOLE-0R4 a9 -ARYTM-1K2 c9"
          using A47 A49 arytm_0_def_1 sorry
        have A56: "c9 =XBOOLE-0R4 c99"
          using A54 A51 xtuple_0_th_1 sorry
        have A57: " ex a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (a =HIDDENR1 a99 & b =HIDDENR1 b99) & a99 <='ARYTM-2R1 b99"
          using A3 A47 A48 xxreal_0_def_5 sorry
        have "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
        proof-
          show "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
          proof-
            have cases: "c9 <='ARYTM-2R1 a9 or  not c9 <='ARYTM-2R1 a9"
               sorry
            have case1: "c9 <='ARYTM-2R1 a9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume A58: "c9 <='ARYTM-2R1 a9"
              then have "c9 <='ARYTM-2R1 b9"
                using A57 A53 A50 arytm_1_th_3 sorry
              then have A59: "b9 -ARYTM-1K2 c9 =XBOOLE-0R4 b9 -'ARYTM-1K1 c9"
                using arytm_1_def_2 sorry
              have A60: "a9 -ARYTM-1K2 c9 =XBOOLE-0R4 a9 -'ARYTM-1K1 c9"
                using A58 arytm_1_def_2 sorry
              have "a9 -'ARYTM-1K1 c9 <='ARYTM-2R1 b9 -'ARYTM-1K1 c99"
                using A57 A53 A50 A56 arytm_1_th_17 sorry
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                using A1 A2 A55 A52 A56 A60 A59 xreal_1_lm_1 sorry
            qed
            have case2: " not c9 <='ARYTM-2R1 a9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume " not c9 <='ARYTM-2R1 a9"
              then have A61: "+ARYTM-0K1(x1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 -'ARYTM-1K1 a9 ]"
                using A55 arytm_1_def_2 sorry
              then have A62: "+ARYTM-0K1(x1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using xreal_1_lm_4 zfmisc_1_th_87 sorry
              have "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
              proof-
                show "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                proof-
                  have cases: "c9 <='ARYTM-2R1 b9 or  not c9 <='ARYTM-2R1 b9"
                     sorry
                  have case1: "c9 <='ARYTM-2R1 b9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                  proof(rule impI)
                    assume "c9 <='ARYTM-2R1 b9"
                    then have "b9 -ARYTM-1K2 c9 =XBOOLE-0R4 b9 -'ARYTM-1K1 c9"
                      using arytm_1_def_2 sorry
                    then have A63: " not +ARYTM-0K1(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using A52 A56 arytm_0_th_5 xboole_0_th_3 sorry
                    have " not +ARYTM-0K1(x1,z1) inTARSKIR2 REAL+ARYTM-2K2"
                      using A62 arytm_0_th_5 xboole_0_th_3 sorry
                    thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                      using A1 A2 A63 xxreal_0_def_5 sorry
                  qed
                  have case2: " not c9 <='ARYTM-2R1 b9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                  proof(rule impI)
                    assume A64: " not c9 <='ARYTM-2R1 b9"
                    have A65: "c9 -'ARYTM-1K1 b9 <='ARYTM-2R1 c9 -'ARYTM-1K1 a9"
                      using A57 A53 A50 arytm_1_th_16 sorry
                    have A66: "+ARYTM-0K1(y1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 -'ARYTM-1K1 b9 ]"
                      using A52 A56 A64 arytm_1_def_2 sorry
                    then have "+ARYTM-0K1(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                      using xreal_1_lm_4 zfmisc_1_th_87 sorry
                    thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                      using A1 A2 A61 A62 A66 A65 xreal_1_lm_1 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
           sorry
      qed
      have case5: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 REAL+ARYTM-2K2 & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A67: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A68: "b inHIDDENR3 REAL+ARYTM-2K2"
          and A69: "c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        have A70: " not c inHIDDENR3 REAL+ARYTM-2K2"
          using A69 arytm_0_th_5 xboole_0_th_3 sorry
        have " not a inHIDDENR3 REAL+ARYTM-2K2"
          using A67 arytm_0_th_5 xboole_0_th_3 sorry
        then obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ]"and A71: "c =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 ]"and A72: "+ARYTM-0K1(x1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 +ARYTM-2K7 c9 ]"
          using A70 arytm_0_def_1 sorry
        have A73: "+ARYTM-0K1(x1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A72 xreal_1_lm_4 zfmisc_1_th_87 sorry
        obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          "b =HIDDENR1 b9"and A74: "c =HIDDENR1 [TARSKIK4 0NUMBERSK6,c99 ]"and A75: "+ARYTM-0K1(y1,z1) =XBOOLE-0R4 b9 -ARYTM-1K2 c99"
          using A68 A69 arytm_0_def_1 sorry
        have A76: "c9 =XBOOLE-0R4 c99"
          using A71 A74 xtuple_0_th_1 sorry
        have "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
        proof-
          show "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
          proof-
            have cases: "c9 <='ARYTM-2R1 b9 or  not c9 <='ARYTM-2R1 b9"
               sorry
            have case1: "c9 <='ARYTM-2R1 b9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume "c9 <='ARYTM-2R1 b9"
              then have "b9 -ARYTM-1K2 c99 =XBOOLE-0R4 b9 -'ARYTM-1K1 c99"
                using A76 arytm_1_def_2 sorry
              then have A77: " not +ARYTM-0K1(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using A75 arytm_0_th_5 xboole_0_th_3 sorry
              have " not +ARYTM-0K1(x1,z1) inTARSKIR2 REAL+ARYTM-2K2"
                using A73 arytm_0_th_5 xboole_0_th_3 sorry
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                using A1 A2 A77 xxreal_0_def_5 sorry
            qed
            have case2: " not c9 <='ARYTM-2R1 b9 implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
            proof(rule impI)
              assume A78: " not c9 <='ARYTM-2R1 b9"
              have A79: "c9 <='ARYTM-2R1 c9 +ARYTM-2K7 a9"
                using arytm_2_th_19 sorry
              have "c9 -'ARYTM-1K1 b9 <='ARYTM-2R1 c9"
                using arytm_1_th_11 sorry
              then have A80: "c9 -'ARYTM-1K1 b9 <='ARYTM-2R1 c9 +ARYTM-2K7 a9"
                using A79 arytm_1_th_3 sorry
              have A81: "+ARYTM-0K1(y1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 -'ARYTM-1K1 b9 ]"
                using A75 A76 A78 arytm_1_def_2 sorry
              then have "+ARYTM-0K1(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
                using xreal_1_lm_4 zfmisc_1_th_87 sorry
              thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
                using A1 A2 A72 A73 A81 A80 xreal_1_lm_1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
           sorry
      qed
      have case6: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & (b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A82: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A83: "b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A84: "c inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        have A85: " not c inHIDDENR3 REAL+ARYTM-2K2"
          using A84 arytm_0_th_5 xboole_0_th_3 sorry
        have A86: " not c inHIDDENR3 REAL+ARYTM-2K2"
          using A84 arytm_0_th_5 xboole_0_th_3 sorry
        have " not a inHIDDENR3 REAL+ARYTM-2K2"
          using A82 arytm_0_th_5 xboole_0_th_3 sorry
        then obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A87: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ]"and A88: "c =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 ]"and A89: "+ARYTM-0K1(x1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 +ARYTM-2K7 c9 ]"
          using A86 arytm_0_def_1 sorry
        have A90: "+ARYTM-0K1(x1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A89 xreal_1_lm_4 zfmisc_1_th_87 sorry
        have " not b inHIDDENR3 REAL+ARYTM-2K2"
          using A83 arytm_0_th_5 xboole_0_th_3 sorry
        then obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A91: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b9 ]"and A92: "c =HIDDENR1 [TARSKIK4 0NUMBERSK6,c99 ]"and A93: "+ARYTM-0K1(y1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,b9 +ARYTM-2K7 c99 ]"
          using A85 arytm_0_def_1 sorry
        have A94: "+ARYTM-0K1(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A93 xreal_1_lm_4 zfmisc_1_th_87 sorry
        have A95: "c9 =XBOOLE-0R4 c99"
          using A88 A92 xtuple_0_th_1 sorry
        obtain a99 b99 where
          [ty]:"a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A96: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a99 ]"and A97: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b99 ]"and A98: "b99 <='ARYTM-2R1 a99"
          using A3 A82 A83 xxreal_0_def_5 sorry
        have A99: "b9 =XBOOLE-0R4 b99"
          using A97 A91 xtuple_0_th_1 sorry
        have "a9 =XBOOLE-0R4 a99"
          using A96 A87 xtuple_0_th_1 sorry
        then have "b9 +ARYTM-2K7 c9 <='ARYTM-2R1 a9 +ARYTM-2K7 c99"
          using A98 A99 A95 arytm_1_th_7 sorry
        thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
          using A1 A2 A89 A93 A95 A90 A94 xreal_1_lm_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 case5 case6 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies (c <=XXREAL-0R1 d implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b"
    then have A1: "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
      using xreal_1_lm_5 sorry
    assume "c <=XXREAL-0R1 d"
    then have "b +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 d"
      using xreal_1_lm_5 sorry
    thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 d"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (a <=XXREAL-0R1 b &  not a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    have "a <=XXREAL-0R1 b implies a +XCMPLX-0K2 (-XCMPLX-0K4 c) <=XXREAL-0R1 b +XCMPLX-0K2 (-XCMPLX-0K4 c)"
      using xreal_1_lm_5 sorry
    thus " not (a <=XXREAL-0R1 b &  not a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <XXREAL-0R3 b & c <=XXREAL-0R1 d implies a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <XXREAL-0R3 b & c <=XXREAL-0R1 d implies  not a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
      and A2: "c <=XXREAL-0R1 d"
    have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <XXREAL-0R3 b & c <=XXREAL-0R1 d implies a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 d"
    proof-
      have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <XXREAL-0R3 b implies (c <=XXREAL-0R1 d implies  not a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 d)"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        fix c assume [ty]: "c be RealXREAL-0M1"
        fix d assume [ty]: "d be RealXREAL-0M1"
        assume A3: "a <XXREAL-0R3 b"
        assume A4: "c <=XXREAL-0R1 d"
        have A5: "a +XCMPLX-0K2 c <>HIDDENR2 b +XCMPLX-0K2 d"
        proof-
          have "a +XCMPLX-0K2 c =XBOOLE-0R4 b +XCMPLX-0K2 d implies  False "
          proof(rule impI)
            have "a +XCMPLX-0K2 c <=XXREAL-0R1 d +XCMPLX-0K2 a"
              using A4 xreal_1_lm_5 sorry
            then have A6: "(a +XCMPLX-0K2 c)-XCMPLX-0K6 d <=XXREAL-0R1 (a +XCMPLX-0K2 d)-XCMPLX-0K6 d"
              using xreal_1_lm_7 sorry
            assume "a +XCMPLX-0K2 c =XBOOLE-0R4 b +XCMPLX-0K2 d"
            thus " False "
              using A3 A6 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 d"
          using A3 A4 xreal_1_lm_6 sorry
        thus " not a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 d"
          using A5 xxreal_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " not a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 d"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies b <XXREAL-0R3 b +XCMPLX-0K2 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies  not b <XXREAL-0R3 b +XCMPLX-0K2 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 a"
    then have "b +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 b +XCMPLX-0K2 a"
      using xreal_1_lm_8 sorry
    thus " not b <XXREAL-0R3 b +XCMPLX-0K2 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_1:
" for a be RealXREAL-0M1 holds  ex b be RealXREAL-0M1 st a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  ex tVar1 be RealXREAL-0M1 st  not a <XXREAL-0R3 tVar1"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    show " ex tVar1 be RealXREAL-0M1 st  not a <XXREAL-0R3 tVar1"
    proof(rule bexI[of _ "a +XCMPLX-0K2 \<one>\<^sub>M"])
      have "a +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_lm_8 sorry
      thus " not a <XXREAL-0R3 a +XCMPLX-0K2 \<one>\<^sub>M"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_2:
" for a be RealXREAL-0M1 holds  ex b be RealXREAL-0M1 st b <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  ex tVar2 be RealXREAL-0M1 st  not tVar2 <XXREAL-0R3 a"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    show " ex tVar2 be RealXREAL-0M1 st  not tVar2 <XXREAL-0R3 a"
    proof(rule bexI[of _ "a -XCMPLX-0K6 \<one>\<^sub>M"])
      have "a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 a +XCMPLX-0K2 (-XCMPLX-0K4 0NUMBERSK6)"
        using xreal_1_lm_8 sorry
      thus " not a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 a"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  ex c be RealXREAL-0M1 st a <XXREAL-0R3 c & b <XXREAL-0R3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  ex z be setHIDDENM2 st  not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    show " ex z be setHIDDENM2 st  not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z"
    proof-
      have cases: "a <=XXREAL-0R1 b or b <=XXREAL-0R1 a"
         sorry
      have case1: "a <=XXREAL-0R1 b implies ( ex z be setHIDDENM2 st  not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z)"
      proof(rule impI)
        assume A1: "a <=XXREAL-0R1 b"
        obtain z where 
          [ty]:"z be setHIDDENM2" and zDef:"z = b +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex z be setHIDDENM2 st  not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z"
        proof(rule bexI[of _ "z"])
          have "b <XXREAL-0R3 z"
            using xreal_1_lm_9 sorry
          thus " not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z"
            using A1 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      have case2: "b <=XXREAL-0R1 a implies ( ex z be setHIDDENM2 st  not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z)"
      proof(rule impI)
        assume A2: "b <=XXREAL-0R1 a"
        obtain z where 
          [ty]:"z be setHIDDENM2" and zDef:"z = a +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex z be setHIDDENM2 st  not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z"
        proof(rule bexI[of _ "z"])
          have "a <XXREAL-0R3 z"
            using xreal_1_lm_9 sorry
          thus " not a <XXREAL-0R3 z &  not b <XXREAL-0R3 z"
            using A2 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c implies a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c implies a <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
    then have "(a +XCMPLX-0K2 c)+XCMPLX-0K2 (-XCMPLX-0K4 c) <=XXREAL-0R1 (b +XCMPLX-0K2 c)+XCMPLX-0K2 (-XCMPLX-0K4 c)"
      using xreal_1_lm_5 sorry
    thus "a <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  ex c be RealXREAL-0M1 st c <XXREAL-0R3 a & c <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  ex z be setHIDDENM2 st  not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    show " ex z be setHIDDENM2 st  not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b"
    proof-
      have cases: "a <=XXREAL-0R1 b or b <=XXREAL-0R1 a"
         sorry
      have case1: "a <=XXREAL-0R1 b implies ( ex z be setHIDDENM2 st  not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b)"
      proof(rule impI)
        assume A1: "a <=XXREAL-0R1 b"
        obtain z where 
          [ty]:"z be setHIDDENM2" and zDef:"z = a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
           sorry
        show " ex z be setHIDDENM2 st  not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b"
        proof(rule bexI[of _ "z"])
          have "z <XXREAL-0R3 a +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_lm_10 sorry
          thus " not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b"
            using A1 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      have case2: "b <=XXREAL-0R1 a implies ( ex z be setHIDDENM2 st  not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b)"
      proof(rule impI)
        assume A2: "b <=XXREAL-0R1 a"
        obtain z where 
          [ty]:"z be setHIDDENM2" and zDef:"z = b +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)"
           sorry
        show " ex z be setHIDDENM2 st  not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b"
        proof(rule bexI[of _ "z"])
          have "z <XXREAL-0R3 b +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_lm_10 sorry
          thus " not z <XXREAL-0R3 a &  not z <XXREAL-0R3 b"
            using A2 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_11:
" for a9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a9 =HIDDENR1 a & b9 =HIDDENR1 b implies  *ARYTM-0K2(a9,b9) =XBOOLE-0R4 a *XCMPLX-0K3 b"
proof-
  have " for a9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for b9 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a9 =HIDDENR1 a & b9 =HIDDENR1 b implies  *ARYTM-0K2(a9,b9) =HIDDENR1 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a9 assume [ty]: "a9 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix b9 assume [ty]: "b9 be ElementSUBSET-1M1-of REALNUMBERSK2"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a9 =HIDDENR1 a"
      and A2: "b9 =HIDDENR1 b"
    obtain x1 x2 y1 y2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A3: "a =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A4: "b =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A5: "a *XCMPLX-0K3 b =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
      using xcmplx_0_def_5 sorry
    have A6: "b =HIDDENR1 y1"
      using A4 xreal_1_lm_2 sorry
    have "x2 =XBOOLE-0R4 0NUMBERSK6"
      using A3 xreal_1_lm_2 sorry
    then have A7: " *ARYTM-0K2(x2,y1) =XBOOLE-0R4 0NUMBERSK6"
      using arytm_0_th_12 sorry
    have A8: "y2 =XBOOLE-0R4 0NUMBERSK6"
      using A4 xreal_1_lm_2 sorry
    then have " *ARYTM-0K2(x1,y2) =XBOOLE-0R4 0NUMBERSK6"
      using arytm_0_th_12 sorry
    then have A9: "+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) =XBOOLE-0R4 0NUMBERSK6"
      using A7 arytm_0_th_11 sorry
    have "a =HIDDENR1 x1"
      using A3 xreal_1_lm_2 sorry
    then have " *ARYTM-0K2(a9,b9) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2))"
      using A1 A2 A6 A8 arytm_0_th_11 arytm_0_th_12 sorry
    also have "... = +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)))"
      using arytm_0_th_15 sorry
    also have "... = a *XCMPLX-0K3 b"
      using A5 A9 arytm_0_def_5 sorry
    finally show " *ARYTM-0K2(a9,b9) =HIDDENR1 a *XCMPLX-0K3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_12:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & 0NUMBERSK6 <=XXREAL-0R1 c implies a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & 0NUMBERSK6 <=XXREAL-0R1 c implies ( not a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 c implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 c"
    have "0NUMBERSK6 be ElementSUBSET-1M1-of REAL+ARYTM-2K2"
      using arytm_2_th_20 sorry
    then have " not 0NUMBERSK6 inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      using arytm_0_th_5 xboole_0_th_3 sorry
    then have A3: "c inHIDDENR3 REAL+ARYTM-2K2"
      using A2 xxreal_0_def_5 sorry
    obtain x1 y1 z1 where 
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and x1Def:"x1 = a" and
      [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" and y1Def:"y1 = b" and
      [ty]:"z1 be ElementSUBSET-1M1-of REALNUMBERSK2" and z1Def:"z1 = c"
      using xreal_0_def_1 sorry
    have A4: " *ARYTM-0K2(y1,z1) =XBOOLE-0R4 b *XCMPLX-0K3 c"
      using xreal_1_lm_11 sorry
    have A5: " *ARYTM-0K2(x1,z1) =XBOOLE-0R4 a *XCMPLX-0K3 c"
      using xreal_1_lm_11 sorry
    assume A6: " not a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 c"
    then have A7: "c <>HIDDENR2 0NUMBERSK6"
       sorry
    show " False "
    proof-
      have cases: "(a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2 or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 REAL+ARYTM-2K2) or a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        using A1 xxreal_0_def_5 sorry
      have case1: "a inHIDDENR3 REAL+ARYTM-2K2 & b inHIDDENR3 REAL+ARYTM-2K2 implies  False "
      proof(rule impMI ,rule impI)
        assume A8: "a inHIDDENR3 REAL+ARYTM-2K2"
          and A9: "b inHIDDENR3 REAL+ARYTM-2K2"
        obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A10: "b =HIDDENR1 b9"and A11: "c =HIDDENR1 c99"and A12: " *ARYTM-0K2(y1,z1) =XBOOLE-0R4 b9 *'ARYTM-2K8 c99"
          using A3 A9 arytm_0_def_2 sorry
        obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A13: "a =HIDDENR1 a9"and A14: "c =HIDDENR1 c9"and A15: " *ARYTM-0K2(x1,z1) =XBOOLE-0R4 a9 *'ARYTM-2K8 c9"
          using A3 A8 arytm_0_def_2 sorry
        have " ex a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (a =HIDDENR1 a99 & b =HIDDENR1 b99) & a99 <='ARYTM-2R1 b99"
          using A1 A8 A9 xxreal_0_def_5 sorry
        then have "a9 *'ARYTM-2K8 c9 <='ARYTM-2R1 b9 *'ARYTM-2K8 c9"
          using A13 A10 arytm_1_th_8 sorry
        thus " False "
          using A4 A5 A6 A14 A15 A11 A12 xreal_1_lm_1 sorry
      qed
      have case2: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 REAL+ARYTM-2K2 implies  False "
      proof(rule impMI ,rule impI)
        assume A16: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A17: "b inHIDDENR3 REAL+ARYTM-2K2"
        have " ex a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ] & c =HIDDENR1 c9) &  *ARYTM-0K2(x1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 *'ARYTM-2K8 a9 ]"
          using A3 A7 A16 arytm_0_def_2 sorry
        then have " *ARYTM-0K2(x1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using xreal_1_lm_4 zfmisc_1_th_87 sorry
        then have A18: " not  *ARYTM-0K2(x1,z1) inTARSKIR2 REAL+ARYTM-2K2"
          using arytm_0_th_5 xboole_0_th_3 sorry
        have " ex b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (b =HIDDENR1 b9 & c =HIDDENR1 c99) &  *ARYTM-0K2(y1,z1) =XBOOLE-0R4 b9 *'ARYTM-2K8 c99"
          using A3 A17 arytm_0_def_2 sorry
        then have " not  *ARYTM-0K2(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using arytm_0_th_5 xboole_0_th_3 sorry
        thus " False "
          using A4 A5 A6 A18 xxreal_0_def_5 sorry
      qed
      have case3: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] implies  False "
      proof(rule impMI ,rule impI)
        assume A19: "a inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          and A20: "b inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        obtain b9 c99 where
          [ty]:"b9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A21: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b9 ]"and A22: "c =HIDDENR1 c99"and A23: " *ARYTM-0K2(y1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,c99 *'ARYTM-2K8 b9 ]"
          using A3 A7 A20 arytm_0_def_2 sorry
        have A24: " *ARYTM-0K2(y1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A23 xreal_1_lm_4 zfmisc_1_th_87 sorry
        obtain a99 b99 where
          [ty]:"a99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "b99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A25: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a99 ]"and A26: "b =HIDDENR1 [TARSKIK4 0NUMBERSK6,b99 ]"and A27: "b99 <='ARYTM-2R1 a99"
          using A1 A19 A20 xxreal_0_def_5 sorry
        have A28: "b9 =XBOOLE-0R4 b99"
          using A26 A21 xtuple_0_th_1 sorry
        obtain a9 c9 where
          [ty]:"a9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "c9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
          A29: "a =HIDDENR1 [TARSKIK4 0NUMBERSK6,a9 ]"and A30: "c =HIDDENR1 c9"and A31: " *ARYTM-0K2(x1,z1) =HIDDENR1 [TARSKIK4 0NUMBERSK6,c9 *'ARYTM-2K8 a9 ]"
          using A3 A7 A19 arytm_0_def_2 sorry
        have A32: " *ARYTM-0K2(x1,z1) inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
          using A31 xreal_1_lm_4 zfmisc_1_th_87 sorry
        have "a9 =XBOOLE-0R4 a99"
          using A25 A29 xtuple_0_th_1 sorry
        then have "b9 *'ARYTM-2K8 c9 <='ARYTM-2R1 a9 *'ARYTM-2K8 c9"
          using A27 A28 arytm_1_th_8 sorry
        thus " False "
          using A4 A5 A6 A30 A31 A22 A23 A32 A24 xreal_1_lm_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_13:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 c & a <XXREAL-0R3 b implies a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 c implies (a <XXREAL-0R3 b implies  not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 c"
    assume A2: "a <XXREAL-0R3 b"
    have A3: "a *XCMPLX-0K3 c <>HIDDENR2 b *XCMPLX-0K3 c"
    proof-
      have "a *XCMPLX-0K3 c =XBOOLE-0R4 b *XCMPLX-0K3 c implies  False "
      proof(rule impI)
        assume "a *XCMPLX-0K3 c =XBOOLE-0R4 b *XCMPLX-0K3 c"
        then have "a *XCMPLX-0K3 (c *XCMPLX-0K3 c \<inverse>XCMPLX-0K5) =XBOOLE-0R4 (b *XCMPLX-0K3 c)*XCMPLX-0K3 c \<inverse>XCMPLX-0K5"
          using xcmplx_1_th_4 sorry
        then have "a *XCMPLX-0K3 \<one>\<^sub>M =XBOOLE-0R4 b *XCMPLX-0K3 (c *XCMPLX-0K3 c \<inverse>XCMPLX-0K5)"
          using A1 xcmplx_0_def_7 sorry
        then have "a =HIDDENR1 b *XCMPLX-0K3 \<one>\<^sub>M"
          using A1 xcmplx_0_def_7 sorry
        thus " False "
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 c"
      using A1 A2 xreal_1_lm_12 sorry
    thus " not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 c"
      using A3 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies ( ex c be RealXREAL-0M1 st a <XXREAL-0R3 c & c <XXREAL-0R3 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies ( ex z be setHIDDENM2 st a <XXREAL-0R3 z &  not z <XXREAL-0R3 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
    obtain z where 
      [ty]:"z be setHIDDENM2" and zDef:"z = (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    show " ex z be setHIDDENM2 st a <XXREAL-0R3 z &  not z <XXREAL-0R3 b"
    proof(rule bexI[of _ "z"],rule conjMI)
      have "\<one>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 a <XXREAL-0R3 a +XCMPLX-0K2 b"
        using A1 xreal_1_lm_10 sorry
      then have "\<two>\<^sub>M \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
        using xreal_1_lm_13 sorry
      thus "a <XXREAL-0R3 z"
         sorry
      have "a +XCMPLX-0K2 b <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 b"
        using A1 xreal_1_lm_10 sorry
      then have "\<two>\<^sub>M \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a +XCMPLX-0K2 b) <XXREAL-0R3 \<two>\<^sub>M \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 b)"
        using xreal_1_lm_13 sorry
      thus " not z <XXREAL-0R3 b"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b iff a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 c"
  using xreal_1_lm_5 xreal_1_lm_10 sorry

mtheorem xreal_1_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies a +XCMPLX-0K2 c <=XXREAL-0R1 b +XCMPLX-0K2 d"
  using xreal_1_lm_6 sorry

mtheorem xreal_1_th_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <XXREAL-0R3 b & c <=XXREAL-0R1 d implies a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 d"
  using xreal_1_lm_8 sorry

mlemma xreal_1_lm_14:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies -XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies -XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b"
    then have "a -XCMPLX-0K6 b <=XXREAL-0R1 b -XCMPLX-0K6 b"
      using xreal_1_lm_7 sorry
    then have "(a -XCMPLX-0K6 b)-XCMPLX-0K6 a <=XXREAL-0R1 0NUMBERSK6 -XCMPLX-0K6 a"
      using xreal_1_lm_7 sorry
    thus "-XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 a implies a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 a implies a <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "-XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 a"
    then have "-XCMPLX-0K4 (-XCMPLX-0K4 a) <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 b)"
      using xreal_1_lm_14 sorry
    thus "a <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b iff a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <=XXREAL-0R1 b implies a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c) & (a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c implies a <=XXREAL-0R1 b)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    show "a <=XXREAL-0R1 b implies a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c"
      using xreal_1_lm_7 sorry
    assume "a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c"
    then have "(a +XCMPLX-0K2 (-XCMPLX-0K4 c))+XCMPLX-0K2 c <=XXREAL-0R1 (b +XCMPLX-0K2 (-XCMPLX-0K4 c))+XCMPLX-0K2 c"
      using xreal_1_lm_5 sorry
    thus "a <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b iff c -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <=XXREAL-0R1 b implies (c -XCMPLX-0K6 a <XXREAL-0R3 c -XCMPLX-0K6 b implies  False )) & (c -XCMPLX-0K6 a >=XXREAL-0R2 c -XCMPLX-0K6 b implies a <=XXREAL-0R1 b)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    show "a <=XXREAL-0R1 b implies (c -XCMPLX-0K6 a <XXREAL-0R3 c -XCMPLX-0K6 b implies  False )"
    proof(rule impI,rule impI)
      assume A1: "a <=XXREAL-0R1 b"
      assume "c -XCMPLX-0K6 a <XXREAL-0R3 c -XCMPLX-0K6 b"
      then have "-XCMPLX-0K4 (c -XCMPLX-0K6 b) <XXREAL-0R3 -XCMPLX-0K4 (c -XCMPLX-0K6 a)"
        using xreal_1_lm_15 sorry
      then have "b -XCMPLX-0K6 c <XXREAL-0R3 a -XCMPLX-0K6 c"
         sorry
      thus " False "
        using A1 xreal_1_lm_7 sorry
    qed
    assume "c -XCMPLX-0K6 a >=XXREAL-0R2 c -XCMPLX-0K6 b"
    then have "-XCMPLX-0K4 (c -XCMPLX-0K6 a) <=XXREAL-0R1 -XCMPLX-0K4 (c -XCMPLX-0K6 b)"
      using xreal_1_lm_14 sorry
    then have "a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 c"
       sorry
    thus "a <=XXREAL-0R1 b"
      using xreal_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_16:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c implies a <=XXREAL-0R1 c -XCMPLX-0K6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c implies a <=XXREAL-0R1 c -XCMPLX-0K6 b"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "a +XCMPLX-0K2 b <=XXREAL-0R1 c"
    then have "(a +XCMPLX-0K2 b)-XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 b"
      using xreal_1_lm_7 sorry
    thus "a <=XXREAL-0R1 c -XCMPLX-0K6 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_17:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b -XCMPLX-0K6 c implies a +XCMPLX-0K2 c <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b -XCMPLX-0K6 c implies a +XCMPLX-0K2 c <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b -XCMPLX-0K6 c"
    then have "a +XCMPLX-0K2 c <=XXREAL-0R1 (b -XCMPLX-0K6 c)+XCMPLX-0K2 c"
      using xreal_1_lm_5 sorry
    thus "a +XCMPLX-0K2 c <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_18:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b +XCMPLX-0K2 c implies a -XCMPLX-0K6 b <=XXREAL-0R1 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b +XCMPLX-0K2 c implies a -XCMPLX-0K6 b <=XXREAL-0R1 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b +XCMPLX-0K2 c"
    then have "a -XCMPLX-0K6 b <=XXREAL-0R1 (c +XCMPLX-0K2 b)-XCMPLX-0K6 b"
      using xreal_1_lm_7 sorry
    thus "a -XCMPLX-0K6 b <=XXREAL-0R1 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_19:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c implies a <=XXREAL-0R1 b +XCMPLX-0K2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c implies a <=XXREAL-0R1 b +XCMPLX-0K2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "a -XCMPLX-0K6 b <=XXREAL-0R1 c"
    then have "a +XCMPLX-0K2 (-XCMPLX-0K4 b) <=XXREAL-0R1 c"
       sorry
    then have "a <=XXREAL-0R1 c -XCMPLX-0K6 (-XCMPLX-0K4 b)"
      using xreal_1_lm_16 sorry
    thus "a <=XXREAL-0R1 b +XCMPLX-0K2 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b -XCMPLX-0K6 c implies c <=XXREAL-0R1 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b -XCMPLX-0K6 c implies c <=XXREAL-0R1 b -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b -XCMPLX-0K6 c"
    then have "a +XCMPLX-0K2 c <=XXREAL-0R1 b"
      using xreal_1_lm_17 sorry
    thus "c <=XXREAL-0R1 b -XCMPLX-0K6 a"
      using xreal_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_12:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c implies a -XCMPLX-0K6 c <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c >=XXREAL-0R2 a -XCMPLX-0K6 b implies a -XCMPLX-0K6 c <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume "c >=XXREAL-0R2 a -XCMPLX-0K6 b"
    then have "c +XCMPLX-0K2 b >=XXREAL-0R2 a"
      using xreal_1_lm_19 sorry
    thus "a -XCMPLX-0K6 c <=XXREAL-0R1 b"
      using xreal_1_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_13:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies a -XCMPLX-0K6 d <=XXREAL-0R1 b -XCMPLX-0K6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 d implies a -XCMPLX-0K6 d <=XXREAL-0R1 b -XCMPLX-0K6 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
      and A2: "c <=XXREAL-0R1 d"
    have "-XCMPLX-0K4 d <=XXREAL-0R1 -XCMPLX-0K4 c"
      using A2 xreal_1_lm_14 sorry
    then have "a +XCMPLX-0K2 (-XCMPLX-0K4 d) <=XXREAL-0R1 b +XCMPLX-0K2 (-XCMPLX-0K4 c)"
      using A1 xreal_1_lm_6 sorry
    thus "a -XCMPLX-0K6 d <=XXREAL-0R1 b -XCMPLX-0K6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_14:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <XXREAL-0R3 b & c <=XXREAL-0R1 d implies a -XCMPLX-0K6 d <XXREAL-0R3 b -XCMPLX-0K6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <XXREAL-0R3 b & c <=XXREAL-0R1 d implies  not a -XCMPLX-0K6 d <XXREAL-0R3 b -XCMPLX-0K6 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
      and A2: "c <=XXREAL-0R1 d"
    have "-XCMPLX-0K4 d <=XXREAL-0R1 -XCMPLX-0K4 c"
      using A2 xreal_1_lm_14 sorry
    then have "a +XCMPLX-0K2 (-XCMPLX-0K4 d) <XXREAL-0R3 b +XCMPLX-0K2 (-XCMPLX-0K4 c)"
      using A1 xreal_1_lm_8 sorry
    thus " not a -XCMPLX-0K6 d <XXREAL-0R3 b -XCMPLX-0K6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_15:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <XXREAL-0R3 d implies a -XCMPLX-0K6 d <XXREAL-0R3 b -XCMPLX-0K6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <XXREAL-0R3 d implies  not a -XCMPLX-0K6 d <XXREAL-0R3 b -XCMPLX-0K6 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
      and A2: "c <XXREAL-0R3 d"
    have "c -XCMPLX-0K6 b <XXREAL-0R3 d -XCMPLX-0K6 a"
      using A1 A2 xreal_1_th_14 sorry
    then have "-XCMPLX-0K4 (d -XCMPLX-0K6 a) <XXREAL-0R3 -XCMPLX-0K4 (c -XCMPLX-0K6 b)"
      using xreal_1_lm_15 sorry
    thus " not a -XCMPLX-0K6 d <XXREAL-0R3 b -XCMPLX-0K6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_20:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c +XCMPLX-0K2 d implies a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c +XCMPLX-0K2 d implies a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume "a +XCMPLX-0K2 b <=XXREAL-0R1 c +XCMPLX-0K2 d"
    then have "a <=XXREAL-0R1 (c +XCMPLX-0K2 d)-XCMPLX-0K6 b"
      using xreal_1_lm_16 sorry
    then have "a <=XXREAL-0R1 c +XCMPLX-0K2 (d -XCMPLX-0K6 b)"
       sorry
    thus "a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b"
      using xreal_1_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_16:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume "a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d"
    then have "(a -XCMPLX-0K6 b)+XCMPLX-0K2 d <=XXREAL-0R1 c"
      using xreal_1_lm_17 sorry
    then have "(a +XCMPLX-0K2 d)-XCMPLX-0K6 b <=XXREAL-0R1 c"
       sorry
    then have "a +XCMPLX-0K2 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
      using xreal_1_lm_19 sorry
    thus "a -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 d"
      using xreal_1_lm_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_17:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies d -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies d -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume "a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d"
    then have "(a -XCMPLX-0K6 b)+XCMPLX-0K2 d <=XXREAL-0R1 c"
      using xreal_1_lm_17 sorry
    then have "(a +XCMPLX-0K2 d)-XCMPLX-0K6 b <=XXREAL-0R1 c"
       sorry
    then have "a +XCMPLX-0K2 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
      using xreal_1_lm_19 sorry
    thus "d -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 a"
      using xreal_1_lm_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_18:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies d -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies d -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume "a -XCMPLX-0K6 b <=XXREAL-0R1 c -XCMPLX-0K6 d"
    then have "(a -XCMPLX-0K6 b)+XCMPLX-0K2 d <=XXREAL-0R1 c"
      using xreal_1_lm_17 sorry
    then have "(a +XCMPLX-0K2 d)-XCMPLX-0K6 b <=XXREAL-0R1 c"
       sorry
    then have "a +XCMPLX-0K2 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
      using xreal_1_lm_19 sorry
    thus "d -XCMPLX-0K6 c <=XXREAL-0R1 b -XCMPLX-0K6 a"
      using xreal_1_lm_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_19:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c iff a <=XXREAL-0R1 c -XCMPLX-0K6 b"
  using xreal_1_lm_16 xreal_1_lm_17 sorry

mtheorem xreal_1_th_20:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b +XCMPLX-0K2 c iff a -XCMPLX-0K6 b <=XXREAL-0R1 c"
  using xreal_1_lm_18 xreal_1_lm_19 sorry

mtheorem xreal_1_th_21:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c +XCMPLX-0K2 d iff a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (a +XCMPLX-0K2 b <=XXREAL-0R1 c +XCMPLX-0K2 d implies a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b) & (a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b implies (c +XCMPLX-0K2 d <XXREAL-0R3 a +XCMPLX-0K2 b implies  not  True ))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    show "a +XCMPLX-0K2 b <=XXREAL-0R1 c +XCMPLX-0K2 d implies a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b"
      using xreal_1_lm_20 sorry
    assume A1: "a -XCMPLX-0K6 c <=XXREAL-0R1 d -XCMPLX-0K6 b"
    assume "c +XCMPLX-0K2 d <XXREAL-0R3 a +XCMPLX-0K2 b"
    then have "d <XXREAL-0R3 (b +XCMPLX-0K2 a)-XCMPLX-0K6 c"
      using xreal_1_lm_19 sorry
    then have "d <XXREAL-0R3 b +XCMPLX-0K2 (a -XCMPLX-0K6 c)"
       sorry
    thus " not  True "
      using A1 xreal_1_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_22:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies a +XCMPLX-0K2 d <=XXREAL-0R1 c -XCMPLX-0K6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a +XCMPLX-0K2 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies a +XCMPLX-0K2 d <=XXREAL-0R1 c -XCMPLX-0K6 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "a +XCMPLX-0K2 b <=XXREAL-0R1 c -XCMPLX-0K6 d"
    show "a +XCMPLX-0K2 d <=XXREAL-0R1 c -XCMPLX-0K6 b"
    proof-
      have cases: "a +XCMPLX-0K2 b <=XXREAL-0R1 c -XCMPLX-0K6 d or b +XCMPLX-0K2 a <=XXREAL-0R1 c -XCMPLX-0K6 d"
        using A1 sorry
      have case1: "a +XCMPLX-0K2 b <=XXREAL-0R1 c -XCMPLX-0K6 d implies a +XCMPLX-0K2 d <=XXREAL-0R1 c -XCMPLX-0K6 b"
      proof(rule impI)
        assume "a +XCMPLX-0K2 b <=XXREAL-0R1 c -XCMPLX-0K6 d"
        then have "(a +XCMPLX-0K2 b)+XCMPLX-0K2 d <=XXREAL-0R1 c"
          using xreal_1_lm_17 sorry
        then have "(a +XCMPLX-0K2 d)+XCMPLX-0K2 b <=XXREAL-0R1 c"
           sorry
        thus "a +XCMPLX-0K2 d <=XXREAL-0R1 c -XCMPLX-0K6 b"
          using xreal_1_lm_16 sorry
      qed
      have case2: "b +XCMPLX-0K2 a <=XXREAL-0R1 c -XCMPLX-0K6 d implies a +XCMPLX-0K2 d <=XXREAL-0R1 c -XCMPLX-0K6 b"
      proof(rule impI)
        assume "b +XCMPLX-0K2 a <=XXREAL-0R1 c -XCMPLX-0K6 d"
        then have "(a +XCMPLX-0K2 b)+XCMPLX-0K2 d <=XXREAL-0R1 c"
          using xreal_1_lm_17 sorry
        then have "(a +XCMPLX-0K2 d)+XCMPLX-0K2 b <=XXREAL-0R1 c"
           sorry
        thus "a +XCMPLX-0K2 d <=XXREAL-0R1 c -XCMPLX-0K6 b"
          using xreal_1_lm_16 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_23:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds a -XCMPLX-0K6 b <=XXREAL-0R1 c +XCMPLX-0K2 d implies a -XCMPLX-0K6 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds c +XCMPLX-0K2 d >=XXREAL-0R2 a -XCMPLX-0K6 b implies a -XCMPLX-0K6 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "c +XCMPLX-0K2 d >=XXREAL-0R2 a -XCMPLX-0K6 b"
    show "a -XCMPLX-0K6 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
    proof-
      have cases: "c +XCMPLX-0K2 d >=XXREAL-0R2 a -XCMPLX-0K6 b or d +XCMPLX-0K2 c >=XXREAL-0R2 a -XCMPLX-0K6 b"
        using A1 sorry
      have case1: "c +XCMPLX-0K2 d >=XXREAL-0R2 a -XCMPLX-0K6 b implies a -XCMPLX-0K6 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
      proof(rule impI)
        assume "c +XCMPLX-0K2 d >=XXREAL-0R2 a -XCMPLX-0K6 b"
        then have "(c +XCMPLX-0K2 d)+XCMPLX-0K2 b >=XXREAL-0R2 a"
          using xreal_1_lm_19 sorry
        then have "(c +XCMPLX-0K2 b)+XCMPLX-0K2 d >=XXREAL-0R2 a"
           sorry
        thus "a -XCMPLX-0K6 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
          using xreal_1_lm_18 sorry
      qed
      have case2: "d +XCMPLX-0K2 c >=XXREAL-0R2 a -XCMPLX-0K6 b implies a -XCMPLX-0K6 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
      proof(rule impI)
        assume "d +XCMPLX-0K2 c >=XXREAL-0R2 a -XCMPLX-0K6 b"
        then have "(c +XCMPLX-0K2 d)+XCMPLX-0K2 b >=XXREAL-0R2 a"
          using xreal_1_lm_19 sorry
        then have "(c +XCMPLX-0K2 b)+XCMPLX-0K2 d >=XXREAL-0R2 a"
           sorry
        thus "a -XCMPLX-0K6 d <=XXREAL-0R1 c +XCMPLX-0K2 b"
          using xreal_1_lm_18 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b iff -XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 a"
  using xreal_1_lm_14 xreal_1_lm_15 sorry

mlemma xreal_1_lm_21:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies  not 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <XXREAL-0R3 b"
    then have "a +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 b"
       sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a"
      using xreal_1_lm_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 b implies b <=XXREAL-0R1 -XCMPLX-0K4 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 b implies b <=XXREAL-0R1 -XCMPLX-0K4 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 -XCMPLX-0K4 b"
    then have "a +XCMPLX-0K2 b <=XXREAL-0R1 (-XCMPLX-0K4 b)+XCMPLX-0K2 b"
      using xreal_1_lm_5 sorry
    then have "b -XCMPLX-0K6 (-XCMPLX-0K4 a) <=XXREAL-0R1 0NUMBERSK6"
       sorry
    thus "b <=XXREAL-0R1 -XCMPLX-0K4 a"
      using xreal_1_lm_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_22:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 b -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b"
    then have "a -XCMPLX-0K6 a <=XXREAL-0R1 b -XCMPLX-0K6 a"
      using xreal_1_lm_7 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 b -XCMPLX-0K6 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_26:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 b <=XXREAL-0R1 a implies -XCMPLX-0K4 a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 b <=XXREAL-0R1 a implies (b <XXREAL-0R3 -XCMPLX-0K4 a implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 b <=XXREAL-0R1 a"
    assume "b <XXREAL-0R3 -XCMPLX-0K4 a"
    then have "b +XCMPLX-0K2 a <XXREAL-0R3 (-XCMPLX-0K4 a)+XCMPLX-0K2 a"
      using xreal_1_lm_10 sorry
    then have "a -XCMPLX-0K6 (-XCMPLX-0K4 b) <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus " not  True "
      using A1 xreal_1_lm_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b) & a +XCMPLX-0K2 b =XBOOLE-0R4 0NUMBERSK6 implies a =HIDDENR1 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_28:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 0NUMBERSK6) & a +XCMPLX-0K2 b =XBOOLE-0R4 0NUMBERSK6 implies a =HIDDENR1 0NUMBERSK6"
   sorry

(*begin*)
mtheorem xreal_1_th_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies b <XXREAL-0R3 b +XCMPLX-0K2 a"
  using xreal_1_lm_9 sorry

mtheorem xreal_1_th_30:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies a +XCMPLX-0K2 b <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies  not a +XCMPLX-0K2 b <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <XXREAL-0R3 0NUMBERSK6"
    then have "b +XCMPLX-0K2 a <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 b"
      using xreal_1_lm_10 sorry
    thus " not a +XCMPLX-0K2 b <XXREAL-0R3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_23:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies (a -XCMPLX-0K6 b >=XXREAL-0R2 0NUMBERSK6 implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
    assume "a -XCMPLX-0K6 b >=XXREAL-0R2 0NUMBERSK6"
    then have "(a -XCMPLX-0K6 b)+XCMPLX-0K2 b >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 b"
      using xreal_1_lm_5 sorry
    thus " not  True "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_31:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies b <=XXREAL-0R1 a +XCMPLX-0K2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies (a +XCMPLX-0K2 b <XXREAL-0R3 b implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
    assume A2: "a +XCMPLX-0K2 b <XXREAL-0R3 b"
    show " not  True "
    proof-
      have cases: "a +XCMPLX-0K2 b <XXREAL-0R3 b or b -XCMPLX-0K6 a >XXREAL-0R4 b"
        using A2 sorry
      have case1: "a +XCMPLX-0K2 b <XXREAL-0R3 b implies  not  True "
      proof(rule impI)
        assume "a +XCMPLX-0K2 b <XXREAL-0R3 b"
        then have "(a +XCMPLX-0K2 b)-XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_lm_23 sorry
        thus " not  True "
          using A1 sorry
      qed
      have case2: "b -XCMPLX-0K6 a >XXREAL-0R4 b implies  not  True "
      proof(rule impI)
        assume "b -XCMPLX-0K6 a >XXREAL-0R4 b"
        then have "(b +XCMPLX-0K2 (-XCMPLX-0K4 a))-XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_lm_21 sorry
        thus " not  True "
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_32:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies a +XCMPLX-0K2 b <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies a +XCMPLX-0K2 b <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 0NUMBERSK6"
    then have "b +XCMPLX-0K2 a <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 b"
      using xreal_1_lm_6 sorry
    thus "a +XCMPLX-0K2 b <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_33:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 a +XCMPLX-0K2 b"
   sorry

mtheorem xreal_1_th_34:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <XXREAL-0R3 b implies 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 b"
   sorry

mtheorem xreal_1_th_35:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & c <=XXREAL-0R1 b implies c +XCMPLX-0K2 a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & c <=XXREAL-0R1 b implies c +XCMPLX-0K2 a <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "c <=XXREAL-0R1 b"
    have "a +XCMPLX-0K2 c <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 b"
      using A1 A2 xreal_1_lm_6 sorry
    thus "c +XCMPLX-0K2 a <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_36:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & c <XXREAL-0R3 b implies c +XCMPLX-0K2 a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & c <XXREAL-0R3 b implies  not c +XCMPLX-0K2 a <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "c <XXREAL-0R3 b"
    have "a +XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 b"
      using A1 A2 xreal_1_lm_8 sorry
    thus " not c +XCMPLX-0K2 a <XXREAL-0R3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_37:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & c <=XXREAL-0R1 b implies c +XCMPLX-0K2 a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & c <=XXREAL-0R1 b implies  not c +XCMPLX-0K2 a <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "c <=XXREAL-0R1 b"
    have "a +XCMPLX-0K2 c <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 b"
      using A1 A2 xreal_1_lm_8 sorry
    thus " not c +XCMPLX-0K2 a <XXREAL-0R3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_38:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 c implies b <=XXREAL-0R1 a +XCMPLX-0K2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 c implies b <=XXREAL-0R1 a +XCMPLX-0K2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "b <=XXREAL-0R1 c"
    have "b +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 a +XCMPLX-0K2 c"
      using A1 A2 xreal_1_lm_6 sorry
    thus "b <=XXREAL-0R1 a +XCMPLX-0K2 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_39:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & b <=XXREAL-0R1 c implies b <XXREAL-0R3 a +XCMPLX-0K2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & b <=XXREAL-0R1 c implies  not b <XXREAL-0R3 a +XCMPLX-0K2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "b <=XXREAL-0R1 c"
    have "b +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 c"
      using A1 A2 xreal_1_lm_8 sorry
    thus " not b <XXREAL-0R3 a +XCMPLX-0K2 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_40:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <XXREAL-0R3 c implies b <XXREAL-0R3 a +XCMPLX-0K2 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <XXREAL-0R3 c implies  not b <XXREAL-0R3 a +XCMPLX-0K2 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "b <XXREAL-0R3 c"
    have "b +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 c"
      using A1 A2 xreal_1_lm_8 sorry
    thus " not b <XXREAL-0R3 a +XCMPLX-0K2 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies b *XCMPLX-0K3 c <XXREAL-0R3 a *XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 implies (a <XXREAL-0R3 b implies  not b *XCMPLX-0K3 c <XXREAL-0R3 a *XCMPLX-0K3 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c <XXREAL-0R3 0NUMBERSK6"
    assume "a <XXREAL-0R3 b"
    then have "a *XCMPLX-0K3 (-XCMPLX-0K4 c) <XXREAL-0R3 b *XCMPLX-0K3 (-XCMPLX-0K4 c)"
      using A1 xreal_1_lm_13 sorry
    then have "-XCMPLX-0K4 a *XCMPLX-0K3 c <XXREAL-0R3 -XCMPLX-0K4 b *XCMPLX-0K3 c"
       sorry
    thus " not b *XCMPLX-0K3 c <XXREAL-0R3 a *XCMPLX-0K3 c"
      using xreal_1_lm_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 c & b <=XXREAL-0R1 a implies b /XCMPLX-0K7 c <=XXREAL-0R1 a /XCMPLX-0K7 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 c & b <=XXREAL-0R1 a implies b /XCMPLX-0K7 c <=XXREAL-0R1 a /XCMPLX-0K7 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 c"
      and A2: "b <=XXREAL-0R1 a"
    show "b /XCMPLX-0K7 c <=XXREAL-0R1 a /XCMPLX-0K7 c"
    proof-
      have cases: "c =HIDDENR1 0NUMBERSK6 or 0NUMBERSK6 <XXREAL-0R3 c"
        using A1 sorry
      have case1: "c =HIDDENR1 0NUMBERSK6 implies b /XCMPLX-0K7 c <=XXREAL-0R1 a /XCMPLX-0K7 c"
      proof(rule impI)
        assume "c =HIDDENR1 0NUMBERSK6"
        then have A3: "c \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
           sorry
        then have "b *XCMPLX-0K3 c \<inverse>XCMPLX-0K5 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        then have A4: "b /XCMPLX-0K7 c =XBOOLE-0R4 0NUMBERSK6"
          using xcmplx_0_def_9 sorry
        have "a *XCMPLX-0K3 c \<inverse>XCMPLX-0K5 =XBOOLE-0R4 0NUMBERSK6"
          using A3 sorry
        thus "b /XCMPLX-0K7 c <=XXREAL-0R1 a /XCMPLX-0K7 c"
          using A4 xcmplx_0_def_9 sorry
      qed
      have case2: "0NUMBERSK6 <XXREAL-0R3 c implies (a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c implies  False )"
      proof(rule impI,rule impI)
        assume A5: "0NUMBERSK6 <XXREAL-0R3 c"
        assume "a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c"
        then have "(a /XCMPLX-0K7 c)*XCMPLX-0K3 c <XXREAL-0R3 (b /XCMPLX-0K7 c)*XCMPLX-0K3 c"
          using A5 xreal_1_lm_13 sorry
        then have "a <XXREAL-0R3 (b /XCMPLX-0K7 c)*XCMPLX-0K3 c"
          using A5 xcmplx_1_th_87 sorry
        thus " False "
          using A2 A5 xcmplx_1_th_87 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_26:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 c & a <XXREAL-0R3 b implies a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 c implies  not ( not a <XXREAL-0R3 b & a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 c"
    have "a <XXREAL-0R3 b implies a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c"
    proof-
      have "a <XXREAL-0R3 b implies  not a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c"
      proof(rule impI)
        assume "a <XXREAL-0R3 b"
        then have "a *XCMPLX-0K3 c \<inverse>XCMPLX-0K5 <XXREAL-0R3 b *XCMPLX-0K3 c \<inverse>XCMPLX-0K5"
          using A1 xreal_1_lm_13 sorry
        then have "a /XCMPLX-0K7 c <XXREAL-0R3 b *XCMPLX-0K3 c \<inverse>XCMPLX-0K5"
          using xcmplx_0_def_9 sorry
        thus " not a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c"
          using xcmplx_0_def_9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( not a <XXREAL-0R3 b & a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_27:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies a /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies  not a /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 a"
    then have "0NUMBERSK6 +XCMPLX-0K2 a /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_lm_10 sorry
    thus " not a /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_41:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies c <=XXREAL-0R1 b +XCMPLX-0K2 a) implies c <=XXREAL-0R1 b"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies b +XCMPLX-0K2 a >=XXREAL-0R2 c) implies (b <XXREAL-0R3 c implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies b +XCMPLX-0K2 a >=XXREAL-0R2 c"
    let ?d = "c -XCMPLX-0K6 b"
    assume "b <XXREAL-0R3 c"
    then have A2: "0NUMBERSK6 <XXREAL-0R3 ?d"
      using xreal_1_lm_21 sorry
    then have "b +XCMPLX-0K2 ?d /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 b +XCMPLX-0K2 ?d"
      using xreal_1_lm_10 xreal_1_lm_27 sorry
    thus " False "
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_42:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies b +XCMPLX-0K2 a <=XXREAL-0R1 c) implies b <=XXREAL-0R1 c"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies b +XCMPLX-0K2 a <=XXREAL-0R1 c) implies (c <XXREAL-0R3 b implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies b +XCMPLX-0K2 a <=XXREAL-0R1 c"
    let ?d = "c -XCMPLX-0K6 b"
    assume "c <XXREAL-0R3 b"
    then have A2: "0NUMBERSK6 >XXREAL-0R4 c -XCMPLX-0K6 b"
      using xreal_1_lm_23 sorry
    then have "(-XCMPLX-0K4 ?d)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 -XCMPLX-0K4 ?d"
      using xreal_1_lm_27 sorry
    then have "c +XCMPLX-0K2 (-XCMPLX-0K4 ?d /XCMPLX-0K7 \<two>\<^sub>M) <XXREAL-0R3 c +XCMPLX-0K2 (-XCMPLX-0K4 ?d)"
      using xreal_1_lm_10 sorry
    then have "c -XCMPLX-0K6 ?d /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 c -XCMPLX-0K6 ?d"
       sorry
    then have "c <XXREAL-0R3 b +XCMPLX-0K2 ?d /XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_lm_16 sorry
    thus " False "
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_43:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies b -XCMPLX-0K6 a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  not (0NUMBERSK6 <=XXREAL-0R1 a &  not b -XCMPLX-0K6 a <=XXREAL-0R1 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 a implies b -XCMPLX-0K6 a <=XXREAL-0R1 b -XCMPLX-0K6 0NUMBERSK6"
      using xreal_1_th_13 sorry
    thus " not (0NUMBERSK6 <=XXREAL-0R1 a &  not b -XCMPLX-0K6 a <=XXREAL-0R1 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_44:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies b -XCMPLX-0K6 a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies  not b -XCMPLX-0K6 a <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 a"
    then have "b +XCMPLX-0K2 (-XCMPLX-0K4 a) <XXREAL-0R3 b +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_lm_10 sorry
    thus " not b -XCMPLX-0K6 a <XXREAL-0R3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_45:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies b <=XXREAL-0R1 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies b <=XXREAL-0R1 b -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 0NUMBERSK6"
    then have "b +XCMPLX-0K2 a <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 b"
      using xreal_1_lm_6 sorry
    thus "b <=XXREAL-0R1 b -XCMPLX-0K6 a"
      using xreal_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_46:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies b <XXREAL-0R3 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies  not b <XXREAL-0R3 b -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <XXREAL-0R3 0NUMBERSK6"
    then have "b +XCMPLX-0K2 a <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 b"
      using xreal_1_lm_10 sorry
    thus " not b <XXREAL-0R3 b -XCMPLX-0K6 a"
      using xreal_1_lm_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_47:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies a -XCMPLX-0K6 b <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies (a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6 implies  not  True )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
    assume "a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
    then have "(a -XCMPLX-0K6 b)+XCMPLX-0K2 b >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 b"
      using xreal_1_lm_10 sorry
    thus " not  True "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_48:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 b -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b"
    then have "a -XCMPLX-0K6 a <=XXREAL-0R1 b -XCMPLX-0K6 a"
      using xreal_1_lm_7 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 b -XCMPLX-0K6 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_49:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
  using xreal_1_lm_23 sorry

mtheorem xreal_1_th_50:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b implies 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a"
  using xreal_1_lm_21 sorry

mtheorem xreal_1_th_51:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <XXREAL-0R3 c implies b -XCMPLX-0K6 a <XXREAL-0R3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <XXREAL-0R3 c implies  not b -XCMPLX-0K6 a <XXREAL-0R3 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "b <XXREAL-0R3 c"
    have "b +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 c"
      using A1 A2 xreal_1_th_40 sorry
    thus " not b -XCMPLX-0K6 a <XXREAL-0R3 c"
      using xreal_1_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_52:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 c implies b <=XXREAL-0R1 c -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 c implies b <=XXREAL-0R1 c -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "b <=XXREAL-0R1 c"
    have "b +XCMPLX-0K2 a <=XXREAL-0R1 c"
      using A1 A2 xreal_1_th_35 sorry
    thus "b <=XXREAL-0R1 c -XCMPLX-0K6 a"
      using xreal_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <XXREAL-0R3 c implies b <XXREAL-0R3 c -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <XXREAL-0R3 c implies  not b <XXREAL-0R3 c -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 c"
    have "b +XCMPLX-0K2 a <XXREAL-0R3 c"
      using A1 A2 xreal_1_th_36 sorry
    thus " not b <XXREAL-0R3 c -XCMPLX-0K6 a"
      using xreal_1_lm_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_54:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <=XXREAL-0R1 c implies b <XXREAL-0R3 c -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <=XXREAL-0R1 c implies  not b <XXREAL-0R3 c -XCMPLX-0K6 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "b <=XXREAL-0R1 c"
    have "a +XCMPLX-0K2 b <XXREAL-0R3 c"
      using A1 A2 xreal_1_th_37 sorry
    thus " not b <XXREAL-0R3 c -XCMPLX-0K6 a"
      using xreal_1_lm_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_55:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 b implies 0NUMBERSK6 <XXREAL-0R3 a -XCMPLX-0K6 b or 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 b implies  not (0NUMBERSK6 <XXREAL-0R3 a -XCMPLX-0K6 b & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 b"
    show " not (0NUMBERSK6 <XXREAL-0R3 a -XCMPLX-0K6 b & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a)"
    proof-
      have cases: "a <XXREAL-0R3 b or b <XXREAL-0R3 a"
        using A1 xxreal_0_th_1 sorry
      have case1: "a <XXREAL-0R3 b implies  not (0NUMBERSK6 <XXREAL-0R3 a -XCMPLX-0K6 b & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a)"
      proof(rule impI)
        assume "a <XXREAL-0R3 b"
        then have "0NUMBERSK6 +XCMPLX-0K2 a <XXREAL-0R3 b"
           sorry
        thus " not (0NUMBERSK6 <XXREAL-0R3 a -XCMPLX-0K6 b & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a)"
          using xreal_1_lm_19 sorry
      qed
      have case2: "b <XXREAL-0R3 a implies  not (0NUMBERSK6 <XXREAL-0R3 a -XCMPLX-0K6 b & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a)"
      proof(rule impI)
        assume "b <XXREAL-0R3 a"
        then have "0NUMBERSK6 +XCMPLX-0K2 b <XXREAL-0R3 a"
           sorry
        thus " not (0NUMBERSK6 <XXREAL-0R3 a -XCMPLX-0K6 b & 0NUMBERSK6 <XXREAL-0R3 b -XCMPLX-0K6 a)"
          using xreal_1_lm_19 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_56:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies c <=XXREAL-0R1 b -XCMPLX-0K6 a) implies b >=XXREAL-0R2 c"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies b -XCMPLX-0K6 a >=XXREAL-0R2 c) implies (b <XXREAL-0R3 c implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies b -XCMPLX-0K6 a >=XXREAL-0R2 c"
    let ?d = "b -XCMPLX-0K6 c"
    assume "b <XXREAL-0R3 c"
    then have A2: "0NUMBERSK6 >XXREAL-0R4 b -XCMPLX-0K6 c"
      using xreal_1_lm_23 sorry
    then have "(-XCMPLX-0K4 ?d)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 -XCMPLX-0K4 ?d"
      using xreal_1_lm_27 sorry
    then have "b +XCMPLX-0K2 (-XCMPLX-0K4 ?d /XCMPLX-0K7 \<two>\<^sub>M) <XXREAL-0R3 b +XCMPLX-0K2 (-XCMPLX-0K4 ?d)"
      using xreal_1_lm_10 sorry
    then have "b -XCMPLX-0K6 ?d /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 b -XCMPLX-0K6 ?d"
       sorry
    thus " False "
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_57:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies b -XCMPLX-0K6 a <=XXREAL-0R1 c) implies b <=XXREAL-0R1 c"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies b -XCMPLX-0K6 a <=XXREAL-0R1 c) implies (b >XXREAL-0R4 c implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies b -XCMPLX-0K6 a <=XXREAL-0R1 c"
    let ?d = "b -XCMPLX-0K6 c"
    assume "b >XXREAL-0R4 c"
    then have A2: "0NUMBERSK6 <XXREAL-0R3 ?d"
      using xreal_1_lm_21 sorry
    then have "c +XCMPLX-0K2 ?d /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 c +XCMPLX-0K2 ?d"
      using xreal_1_lm_10 xreal_1_lm_27 sorry
    then have "c <XXREAL-0R3 b -XCMPLX-0K6 ?d /XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_lm_19 sorry
    thus " False "
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_58:
" for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 iff 0NUMBERSK6 <XXREAL-0R3 -XCMPLX-0K4 a"
   sorry

mtheorem xreal_1_th_59:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 b implies a +XCMPLX-0K2 b <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 b implies a +XCMPLX-0K2 b <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 -XCMPLX-0K4 b"
    then have "a +XCMPLX-0K2 b <=XXREAL-0R1 (-XCMPLX-0K4 b)+XCMPLX-0K2 b"
      using xreal_1_lm_5 sorry
    thus "a +XCMPLX-0K2 b <=XXREAL-0R1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_60:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 a <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 a +XCMPLX-0K2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >=XXREAL-0R2 -XCMPLX-0K4 a implies 0NUMBERSK6 <=XXREAL-0R1 a +XCMPLX-0K2 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "b >=XXREAL-0R2 -XCMPLX-0K4 a"
    then have "b +XCMPLX-0K2 a >=XXREAL-0R2 (-XCMPLX-0K4 a)+XCMPLX-0K2 a"
      using xreal_1_lm_5 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 a +XCMPLX-0K2 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_61:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 -XCMPLX-0K4 b implies a +XCMPLX-0K2 b <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 -XCMPLX-0K4 b implies  not a +XCMPLX-0K2 b <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <XXREAL-0R3 -XCMPLX-0K4 b"
    then have "a +XCMPLX-0K2 b <XXREAL-0R3 (-XCMPLX-0K4 b)+XCMPLX-0K2 b"
      using xreal_1_lm_10 sorry
    thus " not a +XCMPLX-0K2 b <XXREAL-0R3 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_62:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 b <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 -XCMPLX-0K4 b implies  not 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a >XXREAL-0R4 -XCMPLX-0K4 b"
    then have "a +XCMPLX-0K2 b >XXREAL-0R4 (-XCMPLX-0K4 b)+XCMPLX-0K2 b"
      using xreal_1_lm_10 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_28:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 0NUMBERSK6 implies b *XCMPLX-0K3 c <=XXREAL-0R1 a *XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies (c <=XXREAL-0R1 0NUMBERSK6 implies b *XCMPLX-0K3 c <=XXREAL-0R1 a *XCMPLX-0K3 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
    assume "c <=XXREAL-0R1 0NUMBERSK6"
    then have "a *XCMPLX-0K3 (-XCMPLX-0K4 c) <=XXREAL-0R1 b *XCMPLX-0K3 (-XCMPLX-0K4 c)"
      using A1 xreal_1_lm_12 sorry
    then have "-XCMPLX-0K4 a *XCMPLX-0K3 c <=XXREAL-0R1 -XCMPLX-0K4 b *XCMPLX-0K3 c"
       sorry
    thus "b *XCMPLX-0K3 c <=XXREAL-0R1 a *XCMPLX-0K3 c"
      using xreal_1_lm_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_63:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    show "0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-0R1 a or  not 0NUMBERSK6 <=XXREAL-0R1 a"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-0R1 a implies 0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-0R1 a"
        thus "0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
           sorry
      qed
      have case2: " not 0NUMBERSK6 <=XXREAL-0R1 a implies 0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
      proof(rule impI)
        assume " not 0NUMBERSK6 <=XXREAL-0R1 a"
        thus "0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_64:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & 0NUMBERSK6 <=XXREAL-0R1 c implies a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 c"
  using xreal_1_lm_12 sorry

mtheorem xreal_1_th_65:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <=XXREAL-0R1 0NUMBERSK6 implies b *XCMPLX-0K3 c <=XXREAL-0R1 a *XCMPLX-0K3 c"
  using xreal_1_lm_28 sorry

mtheorem xreal_1_th_66:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 a & a <=XXREAL-0R1 b) & 0NUMBERSK6 <=XXREAL-0R1 c) & c <=XXREAL-0R1 d implies a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (a <=XXREAL-0R1 b & (0NUMBERSK6 <=XXREAL-0R1 c & c <=XXREAL-0R1 d)) implies a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "a <=XXREAL-0R1 b"
      and A3: "0NUMBERSK6 <=XXREAL-0R1 c"
      and A4: "c <=XXREAL-0R1 d"
    have A5: "a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 c"
      using A2 A3 xreal_1_lm_12 sorry
    have "b *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
      using A1 A2 A4 xreal_1_lm_12 sorry
    thus "a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
      using A5 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_67:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 a) & c <=XXREAL-0R1 0NUMBERSK6) & d <=XXREAL-0R1 c implies a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 >=XXREAL-0R2 a & (a >=XXREAL-0R2 b & (0NUMBERSK6 >=XXREAL-0R2 c & c >=XXREAL-0R2 d)) implies a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 >=XXREAL-0R2 a"
      and A2: "a >=XXREAL-0R2 b"
      and A3: "0NUMBERSK6 >=XXREAL-0R2 c"
      and A4: "c >=XXREAL-0R2 d"
    have A5: "-XCMPLX-0K4 c <=XXREAL-0R1 -XCMPLX-0K4 d"
      using A4 xreal_1_lm_14 sorry
    have "-XCMPLX-0K4 a <=XXREAL-0R1 -XCMPLX-0K4 b"
      using A2 xreal_1_lm_14 sorry
    then have "(-XCMPLX-0K4 a)*XCMPLX-0K3 (-XCMPLX-0K4 c) <=XXREAL-0R1 (-XCMPLX-0K4 b)*XCMPLX-0K3 (-XCMPLX-0K4 d)"
      using A1 A3 A5 xreal_1_th_66 sorry
    thus "a *XCMPLX-0K3 c <=XXREAL-0R1 b *XCMPLX-0K3 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_68:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 c & a <XXREAL-0R3 b implies a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 c"
  using xreal_1_lm_13 sorry

mtheorem xreal_1_th_69:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies b *XCMPLX-0K3 c <XXREAL-0R3 a *XCMPLX-0K3 c"
  using xreal_1_lm_24 sorry

mtheorem xreal_1_th_70:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((a <XXREAL-0R3 0NUMBERSK6 & b <=XXREAL-0R1 a) & c <XXREAL-0R3 0NUMBERSK6) & d <XXREAL-0R3 c implies a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 >XXREAL-0R4 a & (a >=XXREAL-0R2 b & (0NUMBERSK6 >XXREAL-0R4 c & c >XXREAL-0R4 d)) implies  not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 >XXREAL-0R4 a"
      and A2: "a >=XXREAL-0R2 b"
      and A3: "0NUMBERSK6 >XXREAL-0R4 c"
      and A4: "c >XXREAL-0R4 d"
    have A5: "a *XCMPLX-0K3 c <XXREAL-0R3 a *XCMPLX-0K3 d"
      using A1 A4 xreal_1_lm_24 sorry
    have "a *XCMPLX-0K3 d <=XXREAL-0R1 b *XCMPLX-0K3 d"
      using A2 A3 A4 xreal_1_lm_28 sorry
    thus " not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
      using A5 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_71:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (((0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b) & 0NUMBERSK6 <=XXREAL-0R1 c) & 0NUMBERSK6 <=XXREAL-0R1 d) & a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d =XBOOLE-0R4 0NUMBERSK6 implies a =HIDDENR1 0NUMBERSK6 or c =HIDDENR1 0NUMBERSK6"
   sorry

mlemma xreal_1_lm_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies b /XCMPLX-0K7 c <XXREAL-0R3 a /XCMPLX-0K7 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies  not b /XCMPLX-0K7 c <XXREAL-0R3 a /XCMPLX-0K7 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c <XXREAL-0R3 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 b"
    have "a /XCMPLX-0K7 (-XCMPLX-0K4 c) <XXREAL-0R3 b /XCMPLX-0K7 (-XCMPLX-0K4 c)"
      using A1 A2 xreal_1_lm_26 sorry
    then have "-XCMPLX-0K4 a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 (-XCMPLX-0K4 c)"
      using xcmplx_1_th_188 sorry
    then have "-XCMPLX-0K4 a /XCMPLX-0K7 c <XXREAL-0R3 -XCMPLX-0K4 b /XCMPLX-0K7 c"
      using xcmplx_1_th_188 sorry
    thus " not b /XCMPLX-0K7 c <XXREAL-0R3 a /XCMPLX-0K7 c"
      using xreal_1_lm_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_30:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <=XXREAL-0R1 0NUMBERSK6 & b /XCMPLX-0K7 c <XXREAL-0R3 a /XCMPLX-0K7 c implies a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <=XXREAL-0R1 0NUMBERSK6 & b /XCMPLX-0K7 c <XXREAL-0R3 a /XCMPLX-0K7 c implies  not a <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c <=XXREAL-0R1 0NUMBERSK6"
      and A2: "b /XCMPLX-0K7 c <XXREAL-0R3 a /XCMPLX-0K7 c"
    have A3: "c =HIDDENR1 0NUMBERSK6 implies  False "
    proof(rule impI)
      assume "c =HIDDENR1 0NUMBERSK6"
      then have A4: "c \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
         sorry
      have "a /XCMPLX-0K7 c =HIDDENR1 a *XCMPLX-0K3 c \<inverse>XCMPLX-0K5"
        using xcmplx_0_def_9 sorry
      also have "... = b *XCMPLX-0K3 c \<inverse>XCMPLX-0K5"
        using A4 sorry
      also have "... = b /XCMPLX-0K7 c"
        using xcmplx_0_def_9 sorry
      finally have "a /XCMPLX-0K7 c =HIDDENR1 b /XCMPLX-0K7 c"
         sorry
      thus " False "
        using A2 sorry
    qed
    then have "(a /XCMPLX-0K7 c)*XCMPLX-0K3 c <XXREAL-0R3 (b /XCMPLX-0K7 c)*XCMPLX-0K3 c"
      using A1 A2 xreal_1_lm_24 sorry
    then have "a <XXREAL-0R3 (b /XCMPLX-0K7 c)*XCMPLX-0K3 c"
      using A3 xcmplx_1_th_87 sorry
    thus " not a <XXREAL-0R3 b"
      using A3 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_72:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 c & b <=XXREAL-0R1 a implies b /XCMPLX-0K7 c <=XXREAL-0R1 a /XCMPLX-0K7 c"
  using xreal_1_lm_25 sorry

mtheorem xreal_1_th_73:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <=XXREAL-0R1 0NUMBERSK6 & a <=XXREAL-0R1 b implies b /XCMPLX-0K7 c <=XXREAL-0R1 a /XCMPLX-0K7 c"
  using xreal_1_lm_30 sorry

mtheorem xreal_1_th_74:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 c & a <XXREAL-0R3 b implies a /XCMPLX-0K7 c <XXREAL-0R3 b /XCMPLX-0K7 c"
  using xreal_1_lm_26 sorry

mtheorem xreal_1_th_75:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies b /XCMPLX-0K7 c <XXREAL-0R3 a /XCMPLX-0K7 c"
  using xreal_1_lm_29 sorry

mtheorem xreal_1_th_76:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 c & 0NUMBERSK6 <XXREAL-0R3 a) & a <XXREAL-0R3 b implies c /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 c & (0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 b) implies  not c /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 c"
      and A2: "0NUMBERSK6 <XXREAL-0R3 a"
      and A3: "a <XXREAL-0R3 b"
    have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 b *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_13 sorry
    then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
      using A2 A3 xcmplx_0_def_7 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5) <XXREAL-0R3 a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 \<one>\<^sub>M"
      using A2 xreal_1_lm_13 sorry
    then have "(a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 a)*XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
       sorry
    then have "\<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
      using A2 xcmplx_0_def_7 sorry
    then have "c *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A1 xreal_1_lm_13 sorry
    then have "c /XCMPLX-0K7 b <XXREAL-0R3 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using xcmplx_0_def_9 sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 a"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_31:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 >XXREAL-0R4 b & a <XXREAL-0R3 b implies  not b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: "a \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a"
      using xcmplx_1_th_215 sorry
    assume A2: "0NUMBERSK6 >XXREAL-0R4 b"
      and A3: "a <XXREAL-0R3 b"
    have "b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 <XXREAL-0R3 a *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_24 sorry
    then have "b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 A3 xcmplx_1_th_87 sorry
    then have "b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5) >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A2 xreal_1_lm_24 sorry
    then have "(b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 b)*XCMPLX-0K3 a \<inverse>XCMPLX-0K5 >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
       sorry
    then have "\<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A2 xcmplx_0_def_7 sorry
    thus " not b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_77:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & a *XCMPLX-0K3 b <=XXREAL-0R1 c implies a <=XXREAL-0R1 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 b <=XXREAL-0R1 c implies a <=XXREAL-0R1 c /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b <=XXREAL-0R1 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_25 sorry
    thus "a <=XXREAL-0R1 c /XCMPLX-0K7 b"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_78:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 b <=XXREAL-0R1 c implies c /XCMPLX-0K7 b <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 b <=XXREAL-0R1 c implies c /XCMPLX-0K7 b <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b <=XXREAL-0R1 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b >=XXREAL-0R2 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_30 sorry
    thus "c /XCMPLX-0K7 b <=XXREAL-0R1 a"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_79:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & c <=XXREAL-0R1 a *XCMPLX-0K3 b implies c /XCMPLX-0K7 b <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 b >=XXREAL-0R2 c implies c /XCMPLX-0K7 b <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b >=XXREAL-0R2 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b >=XXREAL-0R2 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_25 sorry
    thus "c /XCMPLX-0K7 b <=XXREAL-0R1 a"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_80:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & c <=XXREAL-0R1 a *XCMPLX-0K3 b implies a <=XXREAL-0R1 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 b >=XXREAL-0R2 c implies a <=XXREAL-0R1 c /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b >=XXREAL-0R2 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_30 sorry
    thus "a <=XXREAL-0R1 c /XCMPLX-0K7 b"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_81:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & a *XCMPLX-0K3 b <XXREAL-0R3 c implies a <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 b <XXREAL-0R3 c implies  not a <XXREAL-0R3 c /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b <XXREAL-0R3 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_26 sorry
    thus " not a <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_82:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 b <XXREAL-0R3 c implies c /XCMPLX-0K7 b <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 b <XXREAL-0R3 c implies  not c /XCMPLX-0K7 b <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b <XXREAL-0R3 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b >XXREAL-0R4 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_29 sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 a"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_83:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & c <XXREAL-0R3 a *XCMPLX-0K3 b implies c /XCMPLX-0K7 b <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 b >XXREAL-0R4 c implies  not c /XCMPLX-0K7 b <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b >XXREAL-0R4 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b >XXREAL-0R4 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_26 sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 a"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_84:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & c <XXREAL-0R3 a *XCMPLX-0K3 b implies a <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 b >XXREAL-0R4 c implies  not a <XXREAL-0R3 c /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "a *XCMPLX-0K3 b >XXREAL-0R4 c"
    have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_29 sorry
    thus " not a <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_32:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "a <=XXREAL-0R1 b"
    have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 b *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A1 A2 xreal_1_lm_12 sorry
    then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 A2 xcmplx_0_def_7 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5) <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A1 xreal_1_lm_12 sorry
    then have "(a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 a)*XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
       sorry
    then have "\<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A1 xcmplx_0_def_7 sorry
    thus "b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_33:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a <=XXREAL-0R1 b implies b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 >XXREAL-0R4 b & a <=XXREAL-0R1 b implies b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 >XXREAL-0R4 b"
      and A2: "a <=XXREAL-0R1 b"
    have "b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A1 A2 xreal_1_lm_28 sorry
    then have "b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 A2 xcmplx_0_def_7 sorry
    then have "b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5) >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A1 xreal_1_lm_28 sorry
    then have "(b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 b)*XCMPLX-0K3 a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
       sorry
    then have "\<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A1 xcmplx_0_def_7 sorry
    thus "b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_85:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
  using xreal_1_lm_32 sorry

mtheorem xreal_1_th_86:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a <=XXREAL-0R1 b implies b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
  using xreal_1_lm_33 sorry

mtheorem xreal_1_th_87:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
  using xreal_1_lm_31 sorry

mlemma xreal_1_lm_34:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 b implies b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 b implies  not b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: "b \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 b"
      using xcmplx_1_th_215 sorry
    assume A2: "0NUMBERSK6 <XXREAL-0R3 a"
      and A3: "a <XXREAL-0R3 b"
    have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 b *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_13 sorry
    then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 A3 xcmplx_1_th_87 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5) <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A2 xreal_1_lm_13 sorry
    then have "(a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 a)*XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
       sorry
    then have "\<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A2 xcmplx_0_def_7 sorry
    thus " not b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_88:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 b implies b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
  using xreal_1_lm_34 sorry

mtheorem xreal_1_th_89:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b \<inverse>XCMPLX-0K5 & b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5 implies a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b \<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6 & a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 b \<inverse>XCMPLX-0K5 implies a <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b \<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6"
      and A2: "a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 b \<inverse>XCMPLX-0K5"
    have "(a \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (b \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
      using A1 A2 xreal_1_lm_32 sorry
    thus "a <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_90:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6 & b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5 implies a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6 & a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 b \<inverse>XCMPLX-0K5 implies a <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6"
      and A2: "a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 b \<inverse>XCMPLX-0K5"
    have "(a \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (b \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
      using A1 A2 xreal_1_lm_33 sorry
    thus "a <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_91:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b \<inverse>XCMPLX-0K5 & b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5 implies a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b \<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6 & a \<inverse>XCMPLX-0K5 >XXREAL-0R4 b \<inverse>XCMPLX-0K5 implies  not a <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b \<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6"
      and A2: "a \<inverse>XCMPLX-0K5 >XXREAL-0R4 b \<inverse>XCMPLX-0K5"
    have "(a \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <XXREAL-0R3 (b \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
      using A1 A2 xreal_1_lm_34 sorry
    thus " not a <XXREAL-0R3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_92:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6 & b \<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5 implies a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6 & a \<inverse>XCMPLX-0K5 >XXREAL-0R4 b \<inverse>XCMPLX-0K5 implies  not a <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6"
      and A2: "a \<inverse>XCMPLX-0K5 >XXREAL-0R4 b \<inverse>XCMPLX-0K5"
    have "(a \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <XXREAL-0R3 (b \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
      using A1 A2 xreal_1_lm_31 sorry
    thus " not a <XXREAL-0R3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_35:
" for b be RealXREAL-0M1 holds  for a be  non negativeXXREAL-0V3\<bar> non positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds 0NUMBERSK6 =XBOOLE-0R4 a *XCMPLX-0K3 b"
   sorry

(*begin*)
mtheorem xreal_1_th_93:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) <=XXREAL-0R1 0NUMBERSK6 implies -XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) <=XXREAL-0R1 0NUMBERSK6 implies -XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "(b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) <=XXREAL-0R1 0NUMBERSK6"
    have "b +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 b +XCMPLX-0K2 a"
      using A1 xreal_1_lm_6 sorry
    then have "b +XCMPLX-0K2 a >=XXREAL-0R2 0NUMBERSK6"
      using A1 A2 sorry
    then have A3: "b >=XXREAL-0R2 0NUMBERSK6 -XCMPLX-0K6 a"
      using xreal_1_lm_18 sorry
    have "b -XCMPLX-0K6 a >=XXREAL-0R2 0NUMBERSK6 & b +XCMPLX-0K2 a <=XXREAL-0R1 0NUMBERSK6 or b -XCMPLX-0K6 a <=XXREAL-0R1 0NUMBERSK6 & b +XCMPLX-0K2 a >=XXREAL-0R2 0NUMBERSK6"
      using A2 sorry
    then have "b <=XXREAL-0R1 a +XCMPLX-0K2 0NUMBERSK6"
      using A1 xreal_1_lm_19 sorry
    thus "-XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_94:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) <XXREAL-0R3 0NUMBERSK6 implies -XCMPLX-0K4 a <XXREAL-0R3 b & b <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) <XXREAL-0R3 0NUMBERSK6 implies  not -XCMPLX-0K4 a <XXREAL-0R3 b &  not b <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "(b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) <XXREAL-0R3 0NUMBERSK6"
    have A3: "b -XCMPLX-0K6 a >XXREAL-0R4 0NUMBERSK6 & b +XCMPLX-0K2 a <XXREAL-0R3 0NUMBERSK6 or b -XCMPLX-0K6 a <XXREAL-0R3 0NUMBERSK6 & b +XCMPLX-0K2 a >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_lm_35 sorry
    then have A4: "b <XXREAL-0R3 a +XCMPLX-0K2 0NUMBERSK6"
      using A1 xreal_1_lm_16 sorry
    have "b +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 b +XCMPLX-0K2 a"
      using A1 xreal_1_lm_6 sorry
    then have "b >XXREAL-0R4 0NUMBERSK6 -XCMPLX-0K6 a"
      using A1 A3 xreal_1_lm_17 sorry
    thus " not -XCMPLX-0K4 a <XXREAL-0R3 b &  not b <XXREAL-0R3 a"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_95:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 (b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) implies b <=XXREAL-0R1 -XCMPLX-0K4 a or a <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) >=XXREAL-0R2 0NUMBERSK6 implies  not ( not b <=XXREAL-0R1 -XCMPLX-0K4 a &  not a <=XXREAL-0R1 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "(b -XCMPLX-0K6 a)*XCMPLX-0K3 (b +XCMPLX-0K2 a) >=XXREAL-0R2 0NUMBERSK6"
    then have "b -XCMPLX-0K6 a >=XXREAL-0R2 0NUMBERSK6 & b +XCMPLX-0K2 a >=XXREAL-0R2 0NUMBERSK6 or b -XCMPLX-0K6 a <=XXREAL-0R1 0NUMBERSK6 & b +XCMPLX-0K2 a <=XXREAL-0R1 0NUMBERSK6"
       sorry
    then have "(b -XCMPLX-0K6 a)+XCMPLX-0K2 a >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 a or b +XCMPLX-0K2 a <=XXREAL-0R1 0NUMBERSK6"
      using xreal_1_lm_6 sorry
    then have "b >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 a or (b +XCMPLX-0K2 a)-XCMPLX-0K6 a <=XXREAL-0R1 0NUMBERSK6 -XCMPLX-0K6 a"
      using xreal_1_lm_7 sorry
    thus " not ( not b <=XXREAL-0R1 -XCMPLX-0K4 a &  not a <=XXREAL-0R1 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_96:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 c) & a <XXREAL-0R3 b) & c <XXREAL-0R3 d implies a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (0NUMBERSK6 <=XXREAL-0R1 c & (a <XXREAL-0R3 b & c <XXREAL-0R3 d)) implies  not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 c"
      and A3: "a <XXREAL-0R3 b"
      and A4: "c <XXREAL-0R3 d"
    have A5: "a *XCMPLX-0K3 c <=XXREAL-0R1 a *XCMPLX-0K3 d"
      using A1 A4 xreal_1_lm_12 sorry
    have "a *XCMPLX-0K3 d <XXREAL-0R3 b *XCMPLX-0K3 d"
      using A2 A3 A4 xreal_1_lm_13 sorry
    thus " not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
      using A5 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_97:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <XXREAL-0R3 c) & a <XXREAL-0R3 b) & c <=XXREAL-0R1 d implies a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (0NUMBERSK6 <XXREAL-0R3 c & (a <XXREAL-0R3 b & c <=XXREAL-0R1 d)) implies  not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <XXREAL-0R3 c"
      and A3: "a <XXREAL-0R3 b"
      and A4: "c <=XXREAL-0R1 d"
    have A5: "a *XCMPLX-0K3 c <=XXREAL-0R1 a *XCMPLX-0K3 d"
      using A1 A4 xreal_1_lm_12 sorry
    have "a *XCMPLX-0K3 d <XXREAL-0R3 b *XCMPLX-0K3 d"
      using A2 A3 A4 xreal_1_lm_13 sorry
    thus " not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
      using A5 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_98:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <XXREAL-0R3 a & 0NUMBERSK6 <XXREAL-0R3 c) & a <=XXREAL-0R1 b) & c <XXREAL-0R3 d implies a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & (0NUMBERSK6 <XXREAL-0R3 c & (a <=XXREAL-0R1 b & c <XXREAL-0R3 d)) implies  not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "0NUMBERSK6 <XXREAL-0R3 c"
      and A3: "a <=XXREAL-0R1 b"
      and A4: "c <XXREAL-0R3 d"
    have A5: "a *XCMPLX-0K3 c <XXREAL-0R3 a *XCMPLX-0K3 d"
      using A1 A4 xreal_1_lm_13 sorry
    have "a *XCMPLX-0K3 d <=XXREAL-0R1 b *XCMPLX-0K3 d"
      using A2 A3 A4 xreal_1_lm_12 sorry
    thus " not a *XCMPLX-0K3 c <XXREAL-0R3 b *XCMPLX-0K3 d"
      using A5 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_99:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 c & b <XXREAL-0R3 0NUMBERSK6) & a <XXREAL-0R3 b implies c /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c >XXREAL-0R4 0NUMBERSK6 & (b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b) implies  not c /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c >XXREAL-0R4 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 0NUMBERSK6"
      and A3: "a <XXREAL-0R3 b"
    have "a \<inverse>XCMPLX-0K5 >XXREAL-0R4 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_31 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c >XXREAL-0R4 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using A1 xreal_1_lm_13 sorry
    then have "c /XCMPLX-0K7 a >XXREAL-0R4 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using xcmplx_0_def_9 sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 a"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_100:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (c <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 a) & a <XXREAL-0R3 b implies c /XCMPLX-0K7 a <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 & (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 b) implies  not c /XCMPLX-0K7 a <XXREAL-0R3 c /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c <XXREAL-0R3 0NUMBERSK6"
      and A2: "a >XXREAL-0R4 0NUMBERSK6"
      and A3: "a <XXREAL-0R3 b"
    have "a \<inverse>XCMPLX-0K5 >XXREAL-0R4 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_34 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c <XXREAL-0R3 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using A1 xreal_1_lm_24 sorry
    then have "c /XCMPLX-0K7 a <XXREAL-0R3 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using xcmplx_0_def_9 sorry
    thus " not c /XCMPLX-0K7 a <XXREAL-0R3 c /XCMPLX-0K7 b"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_101:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (c <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) & a <XXREAL-0R3 b implies c /XCMPLX-0K7 a <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <XXREAL-0R3 0NUMBERSK6 & (b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b) implies  not c /XCMPLX-0K7 a <XXREAL-0R3 c /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c <XXREAL-0R3 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 0NUMBERSK6"
      and A3: "a <XXREAL-0R3 b"
    have "a \<inverse>XCMPLX-0K5 >XXREAL-0R4 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_31 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c <XXREAL-0R3 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using A1 xreal_1_lm_24 sorry
    then have "c /XCMPLX-0K7 a <XXREAL-0R3 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using xcmplx_0_def_9 sorry
    thus " not c /XCMPLX-0K7 a <XXREAL-0R3 c /XCMPLX-0K7 b"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_102:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & 0NUMBERSK6 <XXREAL-0R3 d) & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b implies a /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & (d >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b) implies a /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b <=XXREAL-0R1 c"
      using A1 A3 xreal_1_th_79 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d <=XXREAL-0R1 c"
      using xcmplx_1_th_74 sorry
    thus "a /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 d"
      using A2 xreal_1_th_77 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_103:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6) & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b implies a /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & (d <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b) implies a /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b >=XXREAL-0R2 c"
      using A1 A3 xreal_1_th_80 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d >=XXREAL-0R2 c"
      using xcmplx_1_th_74 sorry
    thus "a /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 d"
      using A2 xreal_1_th_80 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_104:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & d <XXREAL-0R3 0NUMBERSK6) & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b implies c /XCMPLX-0K7 d <=XXREAL-0R1 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & (d <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b) implies c /XCMPLX-0K7 d <=XXREAL-0R1 a /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b <=XXREAL-0R1 c"
      using A1 A3 xreal_1_th_79 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d <=XXREAL-0R1 c"
      using xcmplx_1_th_74 sorry
    thus "c /XCMPLX-0K7 d <=XXREAL-0R1 a /XCMPLX-0K7 b"
      using A2 xreal_1_th_78 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_105:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 d) & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b implies c /XCMPLX-0K7 d <=XXREAL-0R1 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & (d >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b) implies c /XCMPLX-0K7 d <=XXREAL-0R1 a /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <=XXREAL-0R1 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b >=XXREAL-0R2 c"
      using A1 A3 xreal_1_th_80 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d >=XXREAL-0R2 c"
      using xcmplx_1_th_74 sorry
    thus "c /XCMPLX-0K7 d <=XXREAL-0R1 a /XCMPLX-0K7 b"
      using A2 xreal_1_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_106:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & 0NUMBERSK6 <XXREAL-0R3 d) & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & (d >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b) implies  not a /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b <XXREAL-0R3 c"
      using A1 A3 xreal_1_th_83 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d <XXREAL-0R3 c"
      using xcmplx_1_th_74 sorry
    thus " not a /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 d"
      using A2 xreal_1_th_81 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_107:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6) & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & (d <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b) implies  not a /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b >XXREAL-0R4 c"
      using A1 A3 xreal_1_th_84 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d >XXREAL-0R4 c"
      using xcmplx_1_th_74 sorry
    thus " not a /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 d"
      using A2 xreal_1_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_108:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & d <XXREAL-0R3 0NUMBERSK6) & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b implies c /XCMPLX-0K7 d <XXREAL-0R3 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & (d <XXREAL-0R3 0NUMBERSK6 & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b) implies  not c /XCMPLX-0K7 d <XXREAL-0R3 a /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b <XXREAL-0R3 c"
      using A1 A3 xreal_1_th_83 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d <XXREAL-0R3 c"
      using xcmplx_1_th_74 sorry
    thus " not c /XCMPLX-0K7 d <XXREAL-0R3 a /XCMPLX-0K7 b"
      using A2 xreal_1_th_82 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_109:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 d) & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b implies c /XCMPLX-0K7 d <XXREAL-0R3 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & (d >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b) implies  not c /XCMPLX-0K7 d <XXREAL-0R3 a /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
      and A3: "a *XCMPLX-0K3 d <XXREAL-0R3 c *XCMPLX-0K3 b"
    have "(a *XCMPLX-0K3 d)/XCMPLX-0K7 b >XXREAL-0R4 c"
      using A1 A3 xreal_1_th_84 sorry
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 d >XXREAL-0R4 c"
      using xcmplx_1_th_74 sorry
    thus " not c /XCMPLX-0K7 d <XXREAL-0R3 a /XCMPLX-0K7 b"
      using A2 xreal_1_th_83 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_110:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6) & a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6 implies (a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies  not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d >XXREAL-0R4 c"
      using A2 xreal_1_th_78 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b >XXREAL-0R4 c"
       sorry
    thus " not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 xreal_1_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_111:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & 0NUMBERSK6 <XXREAL-0R3 d) & a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies  not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d <XXREAL-0R3 c"
      using A2 xreal_1_th_79 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b <XXREAL-0R3 c"
       sorry
    thus " not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 xreal_1_th_81 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_112:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6) & c /XCMPLX-0K7 d <XXREAL-0R3 a *XCMPLX-0K3 b implies c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6 implies (a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d implies  not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d <XXREAL-0R3 c"
      using A2 xreal_1_th_80 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b <XXREAL-0R3 c"
       sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
      using A1 xreal_1_th_82 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_113:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & 0NUMBERSK6 <XXREAL-0R3 d) & c /XCMPLX-0K7 d <XXREAL-0R3 a *XCMPLX-0K3 b implies c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d implies  not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d >XXREAL-0R4 c"
      using A2 xreal_1_th_77 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b >XXREAL-0R4 c"
       sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
      using A1 xreal_1_th_83 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_114:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 d) & a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies  not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d <XXREAL-0R3 c"
      using A2 xreal_1_th_79 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b <XXREAL-0R3 c"
       sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
      using A1 xreal_1_th_82 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_115:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & d <XXREAL-0R3 0NUMBERSK6) & a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6 implies (a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d implies  not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b <XXREAL-0R3 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d >XXREAL-0R4 c"
      using A2 xreal_1_th_78 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b >XXREAL-0R4 c"
       sorry
    thus " not c /XCMPLX-0K7 b <XXREAL-0R3 a *XCMPLX-0K3 d"
      using A1 xreal_1_th_83 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_116:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (b <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 d) & c /XCMPLX-0K7 d <XXREAL-0R3 a *XCMPLX-0K3 b implies a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & d >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d implies  not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
      and A2: "d >XXREAL-0R4 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d >XXREAL-0R4 c"
      using A2 xreal_1_th_77 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b >XXREAL-0R4 c"
       sorry
    thus " not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 xreal_1_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_117:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 b & d <XXREAL-0R3 0NUMBERSK6) & c /XCMPLX-0K7 d <XXREAL-0R3 a *XCMPLX-0K3 b implies a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 & d <XXREAL-0R3 0NUMBERSK6 implies (a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d implies  not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
      and A2: "d <XXREAL-0R3 0NUMBERSK6"
    assume "a *XCMPLX-0K3 b >XXREAL-0R4 c /XCMPLX-0K7 d"
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 d <XXREAL-0R3 c"
      using A2 xreal_1_th_80 sorry
    then have "(a *XCMPLX-0K3 d)*XCMPLX-0K3 b <XXREAL-0R3 c"
       sorry
    thus " not a *XCMPLX-0K3 d <XXREAL-0R3 c /XCMPLX-0K7 b"
      using A1 xreal_1_th_81 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_118:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (0NUMBERSK6 <XXREAL-0R3 a & 0NUMBERSK6 <=XXREAL-0R1 c) & a <=XXREAL-0R1 b implies c /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & (0NUMBERSK6 <=XXREAL-0R1 c & a <=XXREAL-0R1 b) implies c /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 c"
      and A3: "a <=XXREAL-0R1 b"
    have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 b *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using A1 A3 xreal_1_lm_12 sorry
    then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 A3 xcmplx_0_def_7 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5) <=XXREAL-0R1 a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 xreal_1_lm_12 sorry
    then have "(a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 a)*XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
       sorry
    then have "\<one>\<^sub>M *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
      using A1 xcmplx_0_def_7 sorry
    then have "c *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 <=XXREAL-0R1 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using A2 xreal_1_lm_12 sorry
    then have "c /XCMPLX-0K7 b <=XXREAL-0R1 c *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using xcmplx_0_def_9 sorry
    thus "c /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 a"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_119:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 c & b <XXREAL-0R3 0NUMBERSK6) & a <=XXREAL-0R1 b implies c /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c >=XXREAL-0R2 0NUMBERSK6 & (b <XXREAL-0R3 0NUMBERSK6 & a <=XXREAL-0R1 b) implies c /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 0NUMBERSK6"
      and A3: "a <=XXREAL-0R1 b"
    have "a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_33 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c >=XXREAL-0R2 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using A1 xreal_1_lm_12 sorry
    then have "c /XCMPLX-0K7 a >=XXREAL-0R2 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using xcmplx_0_def_9 sorry
    thus "c /XCMPLX-0K7 b <=XXREAL-0R1 c /XCMPLX-0K7 a"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_120:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (c <=XXREAL-0R1 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 a) & a <=XXREAL-0R1 b implies c /XCMPLX-0K7 a <=XXREAL-0R1 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <=XXREAL-0R1 0NUMBERSK6 implies (a >XXREAL-0R4 0NUMBERSK6 & a <=XXREAL-0R1 b implies c /XCMPLX-0K7 a <=XXREAL-0R1 c /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c <=XXREAL-0R1 0NUMBERSK6"
    assume A2: "a >XXREAL-0R4 0NUMBERSK6"
      and A3: "a <=XXREAL-0R1 b"
    have "a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_32 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c <=XXREAL-0R1 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using A1 xreal_1_lm_28 sorry
    then have "c /XCMPLX-0K7 a <=XXREAL-0R1 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using xcmplx_0_def_9 sorry
    thus "c /XCMPLX-0K7 a <=XXREAL-0R1 c /XCMPLX-0K7 b"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_121:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (c <=XXREAL-0R1 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6) & a <=XXREAL-0R1 b implies c /XCMPLX-0K7 a <=XXREAL-0R1 c /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c <=XXREAL-0R1 0NUMBERSK6 & (b <XXREAL-0R3 0NUMBERSK6 & a <=XXREAL-0R1 b) implies c /XCMPLX-0K7 a <=XXREAL-0R1 c /XCMPLX-0K7 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c <=XXREAL-0R1 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 0NUMBERSK6"
      and A3: "a <=XXREAL-0R1 b"
    have "a \<inverse>XCMPLX-0K5 >=XXREAL-0R2 b \<inverse>XCMPLX-0K5"
      using A2 A3 xreal_1_lm_33 sorry
    then have "a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c <=XXREAL-0R1 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using A1 xreal_1_lm_28 sorry
    then have "c /XCMPLX-0K7 a <=XXREAL-0R1 b \<inverse>XCMPLX-0K5 *XCMPLX-0K3 c"
      using xcmplx_0_def_9 sorry
    thus "c /XCMPLX-0K7 a <=XXREAL-0R1 c /XCMPLX-0K7 b"
      using xcmplx_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_122:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a iff 0NUMBERSK6 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
   sorry

mtheorem xreal_1_th_123:
" for a be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 iff a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_124:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 b implies a \<inverse>XCMPLX-0K5 <XXREAL-0R3 b \<inverse>XCMPLX-0K5"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies  not a \<inverse>XCMPLX-0K5 <XXREAL-0R3 b \<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have "a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6"
      using A1 sorry
    thus " not a \<inverse>XCMPLX-0K5 <XXREAL-0R3 b \<inverse>XCMPLX-0K5"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_125:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 b \<inverse>XCMPLX-0K5 implies a <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6 & b \<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6 implies  not a <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a \<inverse>XCMPLX-0K5 <XXREAL-0R3 0NUMBERSK6"
      and A2: "b \<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6"
    have "(a \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 <XXREAL-0R3 (b \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
      using A1 A2 xreal_1_th_124 sorry
    thus " not a <XXREAL-0R3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_126:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 a implies 0NUMBERSK6 =XBOOLE-0R4 a *XCMPLX-0K3 b"
  using xreal_1_lm_35 sorry

mtheorem xreal_1_th_127:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 b"
   sorry

mtheorem xreal_1_th_128:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 b"
   sorry

mtheorem xreal_1_th_129:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & 0NUMBERSK6 <XXREAL-0R3 b implies 0NUMBERSK6 <XXREAL-0R3 a *XCMPLX-0K3 b"
   sorry

mtheorem xreal_1_th_130:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3 a *XCMPLX-0K3 b"
   sorry

mtheorem xreal_1_th_131:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 0NUMBERSK6 implies a *XCMPLX-0K3 b <=XXREAL-0R1 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_132:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & b <XXREAL-0R3 0NUMBERSK6 implies a *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_133:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6 implies a >XXREAL-0R4 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6 implies  not ( not ( not a >XXREAL-0R4 0NUMBERSK6 &  not b <XXREAL-0R3 0NUMBERSK6) &  not ( not a <XXREAL-0R3 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a *XCMPLX-0K3 b <XXREAL-0R3 0NUMBERSK6"
    then have A2: "b <>HIDDENR2 0NUMBERSK6"
       sorry
    have "a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    thus " not ( not ( not a >XXREAL-0R4 0NUMBERSK6 &  not b <XXREAL-0R3 0NUMBERSK6) &  not ( not a <XXREAL-0R3 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6))"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_134:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a *XCMPLX-0K3 b >XXREAL-0R4 0NUMBERSK6 implies a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a *XCMPLX-0K3 b >XXREAL-0R4 0NUMBERSK6 implies  not ( not ( not a >XXREAL-0R4 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6) &  not ( not a <XXREAL-0R3 0NUMBERSK6 &  not b <XXREAL-0R3 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a *XCMPLX-0K3 b >XXREAL-0R4 0NUMBERSK6"
    then have A2: "b <>HIDDENR2 0NUMBERSK6"
       sorry
    have "a <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    thus " not ( not ( not a >XXREAL-0R4 0NUMBERSK6 &  not b >XXREAL-0R4 0NUMBERSK6) &  not ( not a <XXREAL-0R3 0NUMBERSK6 &  not b <XXREAL-0R3 0NUMBERSK6))"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_135:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 a /XCMPLX-0K7 b"
   sorry

mtheorem xreal_1_th_136:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies 0NUMBERSK6 <=XXREAL-0R1 a /XCMPLX-0K7 b"
   sorry

mtheorem xreal_1_th_137:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 0NUMBERSK6 implies a /XCMPLX-0K7 b <=XXREAL-0R1 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_138:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & 0NUMBERSK6 <=XXREAL-0R1 b implies a /XCMPLX-0K7 b <=XXREAL-0R1 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_139:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & 0NUMBERSK6 <XXREAL-0R3 b implies 0NUMBERSK6 <XXREAL-0R3 a /XCMPLX-0K7 b"
   sorry

mtheorem xreal_1_th_140:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3 a /XCMPLX-0K7 b"
   sorry

mtheorem xreal_1_th_141:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_142:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 b implies b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6"
   sorry

mtheorem xreal_1_th_143:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a /XCMPLX-0K7 b <XXREAL-0R3 0NUMBERSK6 implies b <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 or b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a /XCMPLX-0K7 b <XXREAL-0R3 0NUMBERSK6 implies  not ( not ( not b <XXREAL-0R3 0NUMBERSK6 &  not a >XXREAL-0R4 0NUMBERSK6) &  not ( not b >XXREAL-0R4 0NUMBERSK6 &  not a <XXREAL-0R3 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a /XCMPLX-0K7 b <XXREAL-0R3 0NUMBERSK6"
    then have A2: "a <>HIDDENR2 0NUMBERSK6"
       sorry
    have "a /XCMPLX-0K7 b =XBOOLE-0R4 a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using xcmplx_0_def_9 sorry
    then have "b \<inverse>XCMPLX-0K5 <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    thus " not ( not ( not b <XXREAL-0R3 0NUMBERSK6 &  not a >XXREAL-0R4 0NUMBERSK6) &  not ( not b >XXREAL-0R4 0NUMBERSK6 &  not a <XXREAL-0R3 0NUMBERSK6))"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_144:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6 implies b >XXREAL-0R4 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6 implies  not ( not ( not b >XXREAL-0R4 0NUMBERSK6 &  not a >XXREAL-0R4 0NUMBERSK6) &  not ( not b <XXREAL-0R3 0NUMBERSK6 &  not a <XXREAL-0R3 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6"
    then have A2: "a <>HIDDENR2 0NUMBERSK6"
       sorry
    have "a /XCMPLX-0K7 b =XBOOLE-0R4 a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5"
      using xcmplx_0_def_9 sorry
    then have "b \<inverse>XCMPLX-0K5 <>HIDDENR2 0NUMBERSK6"
      using A1 sorry
    thus " not ( not ( not b >XXREAL-0R4 0NUMBERSK6 &  not a >XXREAL-0R4 0NUMBERSK6) &  not ( not b <XXREAL-0R3 0NUMBERSK6 &  not a <XXREAL-0R3 0NUMBERSK6))"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_145:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies a <XXREAL-0R3 b +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies  not a <XXREAL-0R3 b +XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b"
    then have A1: "a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 b -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_lm_7 sorry
    have "b -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (b -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_lm_9 sorry
    then have "a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 b"
      using A1 xxreal_0_th_2 sorry
    then have "(a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 b +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_lm_10 sorry
    thus " not a <XXREAL-0R3 b +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_146:
" for a be RealXREAL-0M1 holds a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  not a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 a"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 a +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_lm_10 sorry
    thus " not a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_147:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies  not a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 b"
    then have A1: "a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 b -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_lm_7 sorry
    have "b -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 (b -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_lm_9 sorry
    thus " not a -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 b"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_148:
" for a be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 a"
proof-
  have " for a be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a implies  not 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a"
    then have "(-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 a +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_lm_8 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_149:
" for a be RealXREAL-0M1 holds a <XXREAL-0R3 \<one>\<^sub>M implies \<one>\<^sub>M -XCMPLX-0K6 a >XXREAL-0R4 0NUMBERSK6"
  using xreal_1_lm_21 sorry

(*begin*)
mtheorem xreal_1_th_150:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <=XXREAL-0R1 \<one>\<^sub>M & 0NUMBERSK6 <=XXREAL-0R1 b) & b <=XXREAL-0R1 \<one>\<^sub>M) & a *XCMPLX-0K3 b =XBOOLE-0R4 \<one>\<^sub>M implies a =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 \<one>\<^sub>M & (0NUMBERSK6 <=XXREAL-0R1 b & (b <=XXREAL-0R1 \<one>\<^sub>M & a *XCMPLX-0K3 b =XBOOLE-0R4 \<one>\<^sub>M)) implies a =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
      and A3: "b <=XXREAL-0R1 \<one>\<^sub>M"
      and A4: "a *XCMPLX-0K3 b =XBOOLE-0R4 \<one>\<^sub>M"
    have "b =HIDDENR1 0NUMBERSK6 &  False  or b >XXREAL-0R4 0NUMBERSK6 & (b >XXREAL-0R4 0NUMBERSK6 implies a =HIDDENR1 \<one>\<^sub>M)"
    proof-
      show "b =HIDDENR1 0NUMBERSK6 &  False  or b >XXREAL-0R4 0NUMBERSK6 & (b >XXREAL-0R4 0NUMBERSK6 implies a =HIDDENR1 \<one>\<^sub>M)"
      proof-
        have cases: "b =HIDDENR1 0NUMBERSK6 or b >XXREAL-0R4 0NUMBERSK6"
          using A2 sorry
        have case1: "b =HIDDENR1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "b =HIDDENR1 0NUMBERSK6"
          thus " False "
            using A4 sorry
        qed
        have case2: "b >XXREAL-0R4 0NUMBERSK6 implies a =HIDDENR1 \<one>\<^sub>M"
        proof(rule impI)
          assume A5: "b >XXREAL-0R4 0NUMBERSK6"
          then have "a =HIDDENR1 b \<inverse>XCMPLX-0K5"
            using A4 xcmplx_0_def_7 sorry
          then have "a >=XXREAL-0R2 \<one>\<^sub>M \<inverse>XCMPLX-0K5"
            using A3 A5 xreal_1_lm_32 sorry
          thus "a =HIDDENR1 \<one>\<^sub>M"
            using A1 xxreal_0_th_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "a =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_151:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & \<one>\<^sub>M <=XXREAL-0R1 b implies a <=XXREAL-0R1 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 \<one>\<^sub>M implies a <=XXREAL-0R1 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b >=XXREAL-0R2 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b >=XXREAL-0R2 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_12 sorry
    thus "a <=XXREAL-0R1 a *XCMPLX-0K3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_152:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 \<one>\<^sub>M implies a <=XXREAL-0R1 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 \<one>\<^sub>M implies a <=XXREAL-0R1 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b >=XXREAL-0R2 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_28 sorry
    thus "a <=XXREAL-0R1 a *XCMPLX-0K3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_153:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & b <=XXREAL-0R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b <=XXREAL-0R1 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_12 sorry
    thus "a *XCMPLX-0K3 b <=XXREAL-0R1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_154:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & \<one>\<^sub>M <=XXREAL-0R1 b implies a *XCMPLX-0K3 b <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b >=XXREAL-0R2 \<one>\<^sub>M implies a *XCMPLX-0K3 b <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "b >=XXREAL-0R2 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b <=XXREAL-0R1 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_28 sorry
    thus "a *XCMPLX-0K3 b <=XXREAL-0R1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_155:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & \<one>\<^sub>M <XXREAL-0R3 b implies a <XXREAL-0R3 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 \<one>\<^sub>M implies  not a <XXREAL-0R3 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b >XXREAL-0R4 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_13 sorry
    thus " not a <XXREAL-0R3 a *XCMPLX-0K3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_156:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 \<one>\<^sub>M implies a <XXREAL-0R3 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 \<one>\<^sub>M implies  not a <XXREAL-0R3 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b >XXREAL-0R4 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_24 sorry
    thus " not a <XXREAL-0R3 a *XCMPLX-0K3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_157:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & b <XXREAL-0R3 \<one>\<^sub>M implies a *XCMPLX-0K3 b <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b <XXREAL-0R3 \<one>\<^sub>M implies  not a *XCMPLX-0K3 b <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b <XXREAL-0R3 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_13 sorry
    thus " not a *XCMPLX-0K3 b <XXREAL-0R3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_158:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & \<one>\<^sub>M <XXREAL-0R3 b implies a *XCMPLX-0K3 b <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b >XXREAL-0R4 \<one>\<^sub>M implies  not a *XCMPLX-0K3 b <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b <XXREAL-0R3 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_24 sorry
    thus " not a *XCMPLX-0K3 b <XXREAL-0R3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_159:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 a & \<one>\<^sub>M <=XXREAL-0R1 b implies \<one>\<^sub>M <=XXREAL-0R1 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & b >=XXREAL-0R2 \<one>\<^sub>M implies \<one>\<^sub>M <=XXREAL-0R1 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "b >=XXREAL-0R2 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b >=XXREAL-0R2 b *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_12 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 a *XCMPLX-0K3 b"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_160:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M) & b <=XXREAL-0R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (a <=XXREAL-0R1 \<one>\<^sub>M & b <=XXREAL-0R1 \<one>\<^sub>M) implies a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 a"
      using A1 A3 xreal_1_lm_12 sorry
    thus "a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_161:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a & \<one>\<^sub>M <=XXREAL-0R1 b implies \<one>\<^sub>M <XXREAL-0R3 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >=XXREAL-0R2 \<one>\<^sub>M implies  not \<one>\<^sub>M <XXREAL-0R3 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "b >=XXREAL-0R2 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b >XXREAL-0R4 b *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_lm_13 sorry
    thus " not \<one>\<^sub>M <XXREAL-0R3 a *XCMPLX-0K3 b"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_162:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<one>\<^sub>M) & b <=XXREAL-0R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (a <XXREAL-0R3 \<one>\<^sub>M & b <=XXREAL-0R1 \<one>\<^sub>M) implies  not a *XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "a <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 a"
      using A1 A3 xreal_1_lm_12 sorry
    thus " not a *XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_163:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies \<one>\<^sub>M <=XXREAL-0R1 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M & b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies \<one>\<^sub>M <=XXREAL-0R1 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
      and A2: "b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "-XCMPLX-0K4 b >=XXREAL-0R2 -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A2 xreal_1_lm_14 sorry
    have "a *XCMPLX-0K3 b >=XXREAL-0R2 b *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A1 A2 xreal_1_lm_28 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 a *XCMPLX-0K3 b"
      using A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_164:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M & b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies \<one>\<^sub>M <XXREAL-0R3 a *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M & b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not \<one>\<^sub>M <XXREAL-0R3 a *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
      and A2: "b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "-XCMPLX-0K4 b >=XXREAL-0R2 -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A2 xreal_1_lm_14 sorry
    have "a *XCMPLX-0K3 b >XXREAL-0R4 b *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A1 A2 xreal_1_lm_24 sorry
    thus " not \<one>\<^sub>M <XXREAL-0R3 a *XCMPLX-0K3 b"
      using A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_165:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a <=XXREAL-0R1 0NUMBERSK6 & -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a) & -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b implies a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 >=XXREAL-0R2 a & (a >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M & b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M) implies a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 >=XXREAL-0R2 a"
      and A2: "a >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
      and A3: "b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
    have A4: "-XCMPLX-0K4 a <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A2 xreal_1_lm_14 sorry
    have "a *XCMPLX-0K3 b <=XXREAL-0R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a"
      using A1 A3 xreal_1_lm_28 sorry
    thus "a *XCMPLX-0K3 b <=XXREAL-0R1 \<one>\<^sub>M"
      using A4 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_166:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a <=XXREAL-0R1 0NUMBERSK6 & -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a) & -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b implies a *XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 >=XXREAL-0R2 a & (a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M & b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M) implies  not a *XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 >=XXREAL-0R2 a"
      and A2: "a >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
      and A3: "b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
    have A4: "-XCMPLX-0K4 a <XXREAL-0R3 -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A2 xreal_1_lm_15 sorry
    have "a *XCMPLX-0K3 b <=XXREAL-0R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a"
      using A1 A3 xreal_1_lm_28 sorry
    thus " not a *XCMPLX-0K3 b <XXREAL-0R3 \<one>\<^sub>M"
      using A4 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_167:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a implies c <=XXREAL-0R1 b *XCMPLX-0K3 a) implies c <=XXREAL-0R1 b"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M implies b *XCMPLX-0K3 a >=XXREAL-0R2 c) implies ( not c <=XXREAL-0R1 b implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M implies b *XCMPLX-0K3 a >=XXREAL-0R2 c"
    assume A2: " not c <=XXREAL-0R1 b"
    have A3: "b >=XXREAL-0R2 0NUMBERSK6"
    proof-
      have "b <XXREAL-0R3 0NUMBERSK6 implies  False "
      proof(rule impI)
        have A4: "c <=XXREAL-0R1 b *XCMPLX-0K3 \<two>\<^sub>M"
          using A1 sorry
        assume "b <XXREAL-0R3 0NUMBERSK6"
        then have A5: "b *XCMPLX-0K3 \<two>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
           sorry
        then have "c <XXREAL-0R3 0NUMBERSK6"
          using A1 sorry
        then have "b /XCMPLX-0K7 c >XXREAL-0R4 c /XCMPLX-0K7 c"
          using A2 xreal_1_lm_29 sorry
        then have "b /XCMPLX-0K7 c >XXREAL-0R4 \<one>\<^sub>M"
          using A5 A4 xcmplx_1_th_60 sorry
        then have A6: "b *XCMPLX-0K3 (b /XCMPLX-0K7 c) >=XXREAL-0R2 c"
          using A1 sorry
        have "b *XCMPLX-0K3 (b /XCMPLX-0K7 c) <XXREAL-0R3 c *XCMPLX-0K3 (b /XCMPLX-0K7 c)"
          using A2 A5 A4 xreal_1_lm_13 sorry
        then have "b *XCMPLX-0K3 (b /XCMPLX-0K7 c) <XXREAL-0R3 b"
          using A5 A4 xcmplx_1_th_87 sorry
        thus " False "
          using A2 A6 xxreal_0_th_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " False "
    proof-
      have cases: "b >XXREAL-0R4 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6"
        using A3 sorry
      have case1: "b >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A7: "b >XXREAL-0R4 0NUMBERSK6"
        then have "b /XCMPLX-0K7 b <XXREAL-0R3 c /XCMPLX-0K7 b"
          using A2 xreal_1_lm_26 sorry
        then have "\<one>\<^sub>M <XXREAL-0R3 c /XCMPLX-0K7 b"
          using A7 xcmplx_1_th_60 sorry
        then obtain d where
          [ty]:"d be RealXREAL-0M1" and 
          A8: "\<one>\<^sub>M <XXREAL-0R3 d"and A9: "d <XXREAL-0R3 c /XCMPLX-0K7 b"
          using xreal_1_th_5 sorry
        have "b *XCMPLX-0K3 d <XXREAL-0R3 b *XCMPLX-0K3 (c /XCMPLX-0K7 b)"
          using A7 A9 xreal_1_lm_13 sorry
        then have "b *XCMPLX-0K3 d <XXREAL-0R3 c"
          using A7 xcmplx_1_th_87 sorry
        thus " False "
          using A1 A8 sorry
      qed
      have case2: "b =HIDDENR1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A10: "b =HIDDENR1 0NUMBERSK6"
        have "b *XCMPLX-0K3 \<two>\<^sub>M >=XXREAL-0R2 c"
          using A1 sorry
        thus " False "
          using A2 A10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_36:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a implies a \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a implies  not a \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 a"
    then have "\<one>\<^sub>M *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 <XXREAL-0R3 a *XCMPLX-0K3 a \<inverse>XCMPLX-0K5"
      using xreal_1_lm_13 sorry
    thus " not a \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
      using A1 xcmplx_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_168:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies b *XCMPLX-0K3 a <=XXREAL-0R1 c) implies b <=XXREAL-0R1 c"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies b *XCMPLX-0K3 a <=XXREAL-0R1 c) implies b <=XXREAL-0R1 c"
  proof(rule ballI,rule ballI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies b *XCMPLX-0K3 a <=XXREAL-0R1 c"
    have " for d be RealXREAL-0M1 holds d >XXREAL-0R4 \<one>\<^sub>M implies b <=XXREAL-0R1 c *XCMPLX-0K3 d"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be RealXREAL-0M1"
      assume A2: "d >XXREAL-0R4 \<one>\<^sub>M"
      then have "b *XCMPLX-0K3 d \<inverse>XCMPLX-0K5 <=XXREAL-0R1 c"
        using A1 xreal_1_lm_36 sorry
      then have "b /XCMPLX-0K7 d <=XXREAL-0R1 c"
        using xcmplx_0_def_9 sorry
      thus "b <=XXREAL-0R1 c *XCMPLX-0K3 d"
        using A2 xreal_1_th_81 sorry
    qed "sorry"
    thus "b <=XXREAL-0R1 c"
      using xreal_1_th_167 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_37:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b & 0NUMBERSK6 <=XXREAL-0R1 a implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 b implies (0NUMBERSK6 <=XXREAL-0R1 a implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
    assume A2: "0NUMBERSK6 <=XXREAL-0R1 a"
    show "a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
    proof-
      have cases: "a =HIDDENR1 0NUMBERSK6 or a >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have case1: "a =HIDDENR1 0NUMBERSK6 implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
      proof(rule impI)
        assume "a =HIDDENR1 0NUMBERSK6"
        thus "a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
           sorry
      qed
      have case2: "a >XXREAL-0R4 0NUMBERSK6 implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
      proof(rule impI)
        assume A3: "a >XXREAL-0R4 0NUMBERSK6"
        then have "a /XCMPLX-0K7 b <=XXREAL-0R1 b /XCMPLX-0K7 b"
          using A1 xreal_1_lm_25 sorry
        thus "a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
          using A1 A3 xcmplx_1_th_60 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xreal_1_lm_38:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 a implies b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 a implies (a >=XXREAL-0R2 0NUMBERSK6 implies b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <=XXREAL-0R1 a"
    assume A2: "a >=XXREAL-0R2 0NUMBERSK6"
    show "b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M"
    proof-
      have cases: "a =HIDDENR1 0NUMBERSK6 or a >XXREAL-0R4 0NUMBERSK6"
        using A2 sorry
      have case1: "a =HIDDENR1 0NUMBERSK6 implies b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M"
      proof(rule impI)
        assume "a =HIDDENR1 0NUMBERSK6"
        then have "a \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
           sorry
        then have "b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
           sorry
        thus "b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M"
          using xcmplx_0_def_9 sorry
      qed
      have case2: "a >XXREAL-0R4 0NUMBERSK6 implies (b /XCMPLX-0K7 a >XXREAL-0R4 \<one>\<^sub>M implies  not  True )"
      proof(rule impI,rule impI)
        assume A3: "a >XXREAL-0R4 0NUMBERSK6"
        assume "b /XCMPLX-0K7 a >XXREAL-0R4 \<one>\<^sub>M"
        then have "(b /XCMPLX-0K7 a)*XCMPLX-0K3 a >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 a"
          using A3 xreal_1_lm_13 sorry
        thus " not  True "
          using A1 A3 xcmplx_1_th_87 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_169:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies b <=XXREAL-0R1 a *XCMPLX-0K3 c) implies b <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies b <=XXREAL-0R1 a *XCMPLX-0K3 c) & b >XXREAL-0R4 0NUMBERSK6 implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies b <=XXREAL-0R1 a *XCMPLX-0K3 c"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have A3: "b *XCMPLX-0K3 \<two>\<^sub>M >XXREAL-0R4 b"
      using A2 xreal_1_th_155 sorry
    then have A4: "b >XXREAL-0R4 b /XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_83 sorry
    show " False "
    proof-
      have cases: "(c <=XXREAL-0R1 0NUMBERSK6 or c <=XXREAL-0R1 b & c >XXREAL-0R4 0NUMBERSK6) or b <=XXREAL-0R1 c & c >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: "c <=XXREAL-0R1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "c <=XXREAL-0R1 0NUMBERSK6"
        then have "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 c <=XXREAL-0R1 0NUMBERSK6"
           sorry
        thus " False "
          using A1 A2 sorry
      qed
      have case2: "c <=XXREAL-0R1 b & c >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impMI ,rule impI)
        assume A5: "c <=XXREAL-0R1 b"
          and A6: "c >XXREAL-0R4 0NUMBERSK6"
        let ?a = "c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b)"
        have "(c /XCMPLX-0K7 b)*XCMPLX-0K3 \<two>\<^sub>M >XXREAL-0R4 c /XCMPLX-0K7 b"
          using A2 A6 xreal_1_th_155 sorry
        then have "c /XCMPLX-0K7 b >XXREAL-0R4 (c /XCMPLX-0K7 b)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_83 sorry
        then have A7: "c /XCMPLX-0K7 b >XXREAL-0R4 c /XCMPLX-0K7 (b *XCMPLX-0K3 \<two>\<^sub>M)"
          using xcmplx_1_th_78 sorry
        have "c /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
          using A5 A6 xreal_1_lm_37 sorry
        then have "?a <XXREAL-0R3 \<one>\<^sub>M"
          using A7 xxreal_0_th_2 sorry
        then have A8: "?a *XCMPLX-0K3 c >=XXREAL-0R2 b"
          using A1 A2 A6 sorry
        show " False "
        proof-
          have cases: "c >=XXREAL-0R2 b or c <XXREAL-0R3 b"
             sorry
          have case1: "c >=XXREAL-0R2 b implies  False "
          proof(rule impI)
            assume "c >=XXREAL-0R2 b"
            then have "b =HIDDENR1 c"
              using A5 xxreal_0_th_1 sorry
            then have "?a *XCMPLX-0K3 c =XBOOLE-0R4 b /XCMPLX-0K7 \<two>\<^sub>M"
              using A6 xcmplx_1_th_92 sorry
            thus " False "
              using A2 A8 xreal_1_th_83 xreal_1_th_155 sorry
          qed
          have case2: "c <XXREAL-0R3 b implies  False "
          proof(rule impI)
            assume A9: "c <XXREAL-0R3 b"
            then have "?a *XCMPLX-0K3 c <XXREAL-0R3 (c /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 b"
              using A6 xreal_1_th_98 sorry
            then have A10: "?a *XCMPLX-0K3 c <XXREAL-0R3 c /XCMPLX-0K7 \<two>\<^sub>M"
              using A2 xcmplx_1_th_92 sorry
            have "c /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 \<two>\<^sub>M"
              using A9 xreal_1_lm_26 sorry
            then have "?a *XCMPLX-0K3 c <XXREAL-0R3 b /XCMPLX-0K7 \<two>\<^sub>M"
              using A10 xxreal_0_th_2 sorry
            thus " False "
              using A4 A8 xxreal_0_th_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case3: "b <=XXREAL-0R1 c & c >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impMI ,rule impI)
        assume A11: "b <=XXREAL-0R1 c"
          and A12: "c >XXREAL-0R4 0NUMBERSK6"
        let ?a = "b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 c)"
        have "(b /XCMPLX-0K7 c)*XCMPLX-0K3 \<two>\<^sub>M >XXREAL-0R4 b /XCMPLX-0K7 c"
          using A2 A12 xreal_1_th_155 sorry
        then have "b /XCMPLX-0K7 c >XXREAL-0R4 (b /XCMPLX-0K7 c)/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_83 sorry
        then have A13: "b /XCMPLX-0K7 c >XXREAL-0R4 b /XCMPLX-0K7 (c *XCMPLX-0K3 \<two>\<^sub>M)"
          using xcmplx_1_th_78 sorry
        have "b /XCMPLX-0K7 c <=XXREAL-0R1 \<one>\<^sub>M"
          using A11 A12 xreal_1_lm_38 sorry
        then have "?a <XXREAL-0R3 \<one>\<^sub>M"
          using A13 xxreal_0_th_2 sorry
        then have A14: "?a *XCMPLX-0K3 c >=XXREAL-0R2 b"
          using A1 A2 A12 sorry
        have "?a *XCMPLX-0K3 c =XBOOLE-0R4 b /XCMPLX-0K7 \<two>\<^sub>M"
          using A12 xcmplx_1_th_92 sorry
        thus " False "
          using A3 A14 xreal_1_th_83 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_170:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds (((0NUMBERSK6 <=XXREAL-0R1 d & d <=XXREAL-0R1 \<one>\<^sub>M) & 0NUMBERSK6 <=XXREAL-0R1 a) & 0NUMBERSK6 <=XXREAL-0R1 b) & d *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b =XBOOLE-0R4 0NUMBERSK6 implies (d =HIDDENR1 0NUMBERSK6 & b =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M & a =HIDDENR1 0NUMBERSK6) or a =HIDDENR1 0NUMBERSK6 & b =HIDDENR1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 d & (d <=XXREAL-0R1 \<one>\<^sub>M & (a >=XXREAL-0R2 0NUMBERSK6 & (b >=XXREAL-0R2 0NUMBERSK6 & d *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b =XBOOLE-0R4 0NUMBERSK6))) implies  not (( not (d =HIDDENR1 0NUMBERSK6 & b =HIDDENR1 0NUMBERSK6) &  not (d =HIDDENR1 \<one>\<^sub>M & a =HIDDENR1 0NUMBERSK6)) &  not (a =HIDDENR1 0NUMBERSK6 & b =HIDDENR1 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 d"
      and A2: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "a >=XXREAL-0R2 0NUMBERSK6"
      and A4: "b >=XXREAL-0R2 0NUMBERSK6"
      and A5: "d *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b =XBOOLE-0R4 0NUMBERSK6"
    have "d -XCMPLX-0K6 d <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 d"
      using A2 xreal_1_lm_7 sorry
    then have "\<one>\<^sub>M -XCMPLX-0K6 d =XBOOLE-0R4 0NUMBERSK6 or b =HIDDENR1 0NUMBERSK6"
      using A1 A3 A4 A5 sorry
    thus " not (( not (d =HIDDENR1 0NUMBERSK6 & b =HIDDENR1 0NUMBERSK6) &  not (d =HIDDENR1 \<one>\<^sub>M & a =HIDDENR1 0NUMBERSK6)) &  not (a =HIDDENR1 0NUMBERSK6 & b =HIDDENR1 0NUMBERSK6))"
      using A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_171:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 d & a <=XXREAL-0R1 b implies a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 d & a <=XXREAL-0R1 b implies a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 d"
      and A2: "a <=XXREAL-0R1 b"
    have "d *XCMPLX-0K3 a <=XXREAL-0R1 d *XCMPLX-0K3 b"
      using A1 A2 xreal_1_lm_12 sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
      using xreal_1_lm_6 sorry
    thus "a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_172:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds d <=XXREAL-0R1 \<one>\<^sub>M & a <=XXREAL-0R1 b implies (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b <=XXREAL-0R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds d <=XXREAL-0R1 \<one>\<^sub>M & a <=XXREAL-0R1 b implies (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A2: "a <=XXREAL-0R1 b"
    have "\<one>\<^sub>M -XCMPLX-0K6 d >=XXREAL-0R2 0NUMBERSK6"
      using A1 xreal_1_th_48 sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b"
      using A2 xreal_1_lm_12 sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 b"
      using xreal_1_lm_6 sorry
    thus "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b <=XXREAL-0R1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_173:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 d & d <=XXREAL-0R1 \<one>\<^sub>M) & a <=XXREAL-0R1 b) & a <=XXREAL-0R1 c implies a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 d & (d <=XXREAL-0R1 \<one>\<^sub>M & (a <=XXREAL-0R1 b & a <=XXREAL-0R1 c)) implies a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 d"
      and A2: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "a <=XXREAL-0R1 b"
      and A4: "a <=XXREAL-0R1 c"
    have "\<one>\<^sub>M -XCMPLX-0K6 d >=XXREAL-0R2 0NUMBERSK6"
      using A2 xreal_1_th_48 sorry
    then have A5: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b"
      using A3 xreal_1_lm_12 sorry
    have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 a =HIDDENR1 a"
       sorry
    have "d *XCMPLX-0K3 a <=XXREAL-0R1 d *XCMPLX-0K3 c"
      using A1 A4 xreal_1_lm_12 sorry
    thus "a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
      using A5 A6 xreal_1_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_174:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 d & d <=XXREAL-0R1 \<one>\<^sub>M) & b <=XXREAL-0R1 a) & c <=XXREAL-0R1 a implies (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 d & (d <=XXREAL-0R1 \<one>\<^sub>M & (a >=XXREAL-0R2 b & a >=XXREAL-0R2 c)) implies (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 d"
      and A2: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "a >=XXREAL-0R2 b"
      and A4: "a >=XXREAL-0R2 c"
    have "\<one>\<^sub>M -XCMPLX-0K6 d >=XXREAL-0R2 0NUMBERSK6"
      using A2 xreal_1_th_48 sorry
    then have A5: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a >=XXREAL-0R2 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b"
      using A3 xreal_1_lm_12 sorry
    have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 a =HIDDENR1 a"
       sorry
    have "d *XCMPLX-0K3 a >=XXREAL-0R2 d *XCMPLX-0K3 c"
      using A1 A4 xreal_1_lm_12 sorry
    thus "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <=XXREAL-0R1 a"
      using A5 A6 xreal_1_lm_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_175:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 d & d <=XXREAL-0R1 \<one>\<^sub>M) & a <XXREAL-0R3 b) & a <XXREAL-0R3 c implies a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 d & (d <=XXREAL-0R1 \<one>\<^sub>M & (a <XXREAL-0R3 b & a <XXREAL-0R3 c)) implies  not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 d"
      and A2: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "a <XXREAL-0R3 b"
      and A4: "a <XXREAL-0R3 c"
    show " not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
    proof-
      have cases: "(d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M) or  not (d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M)"
         sorry
      have case1: "d =HIDDENR1 0NUMBERSK6 implies  not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
      proof(rule impI)
        assume "d =HIDDENR1 0NUMBERSK6"
        thus " not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
          using A3 sorry
      qed
      have case2: "d =HIDDENR1 \<one>\<^sub>M implies  not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
      proof(rule impI)
        assume "d =HIDDENR1 \<one>\<^sub>M"
        thus " not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
          using A4 sorry
      qed
      have case3: " not (d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M) implies  not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
      proof(rule impI)
        assume A5: " not (d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M)"
        then have "d <XXREAL-0R3 \<one>\<^sub>M"
          using A2 xxreal_0_th_1 sorry
        then have "\<one>\<^sub>M -XCMPLX-0K6 d >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_lm_21 sorry
        then have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b"
          using A3 xreal_1_lm_13 sorry
        have A7: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 a =HIDDENR1 a"
           sorry
        have "d *XCMPLX-0K3 a <XXREAL-0R3 d *XCMPLX-0K3 c"
          using A1 A4 A5 xreal_1_lm_13 sorry
        thus " not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
          using A6 A7 xreal_1_lm_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_176:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 d & d <=XXREAL-0R1 \<one>\<^sub>M) & b <XXREAL-0R3 a) & c <XXREAL-0R3 a implies (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 d & (d <=XXREAL-0R1 \<one>\<^sub>M & (a >XXREAL-0R4 b & a >XXREAL-0R4 c)) implies  not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 d"
      and A2: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "a >XXREAL-0R4 b"
      and A4: "a >XXREAL-0R4 c"
    show " not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
    proof-
      have cases: "(d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M) or  not (d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M)"
         sorry
      have case1: "d =HIDDENR1 0NUMBERSK6 implies  not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
      proof(rule impI)
        assume "d =HIDDENR1 0NUMBERSK6"
        thus " not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
          using A3 sorry
      qed
      have case2: "d =HIDDENR1 \<one>\<^sub>M implies  not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
      proof(rule impI)
        assume "d =HIDDENR1 \<one>\<^sub>M"
        thus " not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
          using A4 sorry
      qed
      have case3: " not (d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M) implies  not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
      proof(rule impI)
        assume A5: " not (d =HIDDENR1 0NUMBERSK6 or d =HIDDENR1 \<one>\<^sub>M)"
        then have "d <XXREAL-0R3 \<one>\<^sub>M"
          using A2 xxreal_0_th_1 sorry
        then have "\<one>\<^sub>M -XCMPLX-0K6 d >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_lm_21 sorry
        then have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a >XXREAL-0R4 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b"
          using A3 xreal_1_lm_13 sorry
        have A7: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 a =HIDDENR1 a"
           sorry
        have "d *XCMPLX-0K3 a >XXREAL-0R4 d *XCMPLX-0K3 c"
          using A1 A4 A5 xreal_1_lm_13 sorry
        thus " not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
          using A6 A7 xreal_1_lm_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_177:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <XXREAL-0R3 d & d <XXREAL-0R3 \<one>\<^sub>M) & a <=XXREAL-0R1 b) & a <XXREAL-0R3 c implies a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 d & (d <XXREAL-0R3 \<one>\<^sub>M & (a <=XXREAL-0R1 b & a <XXREAL-0R3 c)) implies  not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 d"
      and A2: "d <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "a <=XXREAL-0R1 b"
      and A4: "a <XXREAL-0R3 c"
    have "\<one>\<^sub>M -XCMPLX-0K6 d >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_lm_21 sorry
    then have A5: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b"
      using A3 xreal_1_lm_12 sorry
    have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 a =HIDDENR1 a"
       sorry
    have "d *XCMPLX-0K3 a <XXREAL-0R3 d *XCMPLX-0K3 c"
      using A1 A4 xreal_1_lm_13 sorry
    thus " not a <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c"
      using A5 A6 xreal_1_lm_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_178:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <XXREAL-0R3 d & d <XXREAL-0R3 \<one>\<^sub>M) & b <XXREAL-0R3 a) & c <=XXREAL-0R1 a implies (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 d & (d <XXREAL-0R3 \<one>\<^sub>M & (a >XXREAL-0R4 b & a >=XXREAL-0R2 c)) implies  not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 d"
      and A2: "d <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "a >XXREAL-0R4 b"
      and A4: "a >=XXREAL-0R2 c"
    have "\<one>\<^sub>M -XCMPLX-0K6 d >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_lm_21 sorry
    then have A5: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a >XXREAL-0R4 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b"
      using A3 xreal_1_lm_13 sorry
    have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 a =HIDDENR1 a"
       sorry
    have "d *XCMPLX-0K3 a >=XXREAL-0R2 d *XCMPLX-0K3 c"
      using A1 A4 xreal_1_lm_12 sorry
    thus " not (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 b +XCMPLX-0K2 d *XCMPLX-0K3 c <XXREAL-0R3 a"
      using A5 A6 xreal_1_lm_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_179:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 d & d <=XXREAL-0R1 \<one>\<^sub>M) & a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b) & b <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b implies d =HIDDENR1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds d >=XXREAL-0R2 0NUMBERSK6 & (d <=XXREAL-0R1 \<one>\<^sub>M & (a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b & b <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b)) implies (d <>HIDDENR2 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "d >=XXREAL-0R2 0NUMBERSK6"
      and A2: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
      and A4: "b <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
    let ?s = "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
    assume "d <>HIDDENR2 0NUMBERSK6"
    then have A5: "d *XCMPLX-0K3 b <XXREAL-0R3 d *XCMPLX-0K3 ?s"
      using A1 A4 xreal_1_lm_13 sorry
    have "\<one>\<^sub>M -XCMPLX-0K6 d >=XXREAL-0R2 0NUMBERSK6"
      using A2 xreal_1_th_48 sorry
    then have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 ?s"
      using A3 xreal_1_lm_12 sorry
    have "\<one>\<^sub>M *XCMPLX-0K3 ?s =XBOOLE-0R4 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 ?s +XCMPLX-0K2 d *XCMPLX-0K3 ?s"
       sorry
    thus " False "
      using A5 A6 xreal_1_lm_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_180:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds ((0NUMBERSK6 <=XXREAL-0R1 d & d <=XXREAL-0R1 \<one>\<^sub>M) & (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b <=XXREAL-0R1 a) & (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b <XXREAL-0R3 b implies d =HIDDENR1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for d be RealXREAL-0M1 holds d >=XXREAL-0R2 0NUMBERSK6 & (d <=XXREAL-0R1 \<one>\<^sub>M & (a >=XXREAL-0R2 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b & b >XXREAL-0R4 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b)) implies (d <>HIDDENR2 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix d assume [ty]: "d be RealXREAL-0M1"
    assume A1: "d >=XXREAL-0R2 0NUMBERSK6"
      and A2: "d <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "a >=XXREAL-0R2 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
      and A4: "b >XXREAL-0R4 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
    let ?s = "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a +XCMPLX-0K2 d *XCMPLX-0K3 b"
    assume "d <>HIDDENR2 0NUMBERSK6"
    then have A5: "d *XCMPLX-0K3 b >XXREAL-0R4 d *XCMPLX-0K3 ?s"
      using A1 A4 xreal_1_lm_13 sorry
    have "\<one>\<^sub>M -XCMPLX-0K6 d >=XXREAL-0R2 0NUMBERSK6"
      using A2 xreal_1_th_48 sorry
    then have A6: "(\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 a >=XXREAL-0R2 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 ?s"
      using A3 xreal_1_lm_12 sorry
    have "\<one>\<^sub>M *XCMPLX-0K3 ?s =XBOOLE-0R4 (\<one>\<^sub>M -XCMPLX-0K6 d)*XCMPLX-0K3 ?s +XCMPLX-0K2 d *XCMPLX-0K3 ?s"
       sorry
    thus " False "
      using A5 A6 xreal_1_lm_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_181:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies \<one>\<^sub>M <=XXREAL-0R1 b /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies \<one>\<^sub>M <=XXREAL-0R1 b /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "a <=XXREAL-0R1 b"
    have "b /XCMPLX-0K7 a >=XXREAL-0R2 a /XCMPLX-0K7 a"
      using A1 A2 xreal_1_lm_25 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 b /XCMPLX-0K7 a"
      using A1 xcmplx_1_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_182:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <=XXREAL-0R1 a implies \<one>\<^sub>M <=XXREAL-0R1 b /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <=XXREAL-0R1 a implies \<one>\<^sub>M <=XXREAL-0R1 b /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "b <=XXREAL-0R1 a"
    have "b /XCMPLX-0K7 a >=XXREAL-0R2 a /XCMPLX-0K7 a"
      using A1 A2 xreal_1_lm_30 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 b /XCMPLX-0K7 a"
      using A1 xcmplx_1_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_183:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & a <=XXREAL-0R1 b implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
  using xreal_1_lm_37 sorry

mtheorem xreal_1_th_184:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 a & a <=XXREAL-0R1 0NUMBERSK6 implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 a implies (a <=XXREAL-0R1 0NUMBERSK6 implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <=XXREAL-0R1 a"
    assume A2: "a <=XXREAL-0R1 0NUMBERSK6"
    show "a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
    proof-
      have cases: "a =HIDDENR1 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
        using A2 sorry
      have case1: "a =HIDDENR1 0NUMBERSK6 implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
      proof(rule impI)
        assume "a =HIDDENR1 0NUMBERSK6"
        thus "a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
           sorry
      qed
      have case2: "a <XXREAL-0R3 0NUMBERSK6 implies a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
      proof(rule impI)
        assume A3: "a <XXREAL-0R3 0NUMBERSK6"
        then have "a /XCMPLX-0K7 b <=XXREAL-0R1 b /XCMPLX-0K7 b"
          using A1 xreal_1_lm_30 sorry
        thus "a /XCMPLX-0K7 b <=XXREAL-0R1 \<one>\<^sub>M"
          using A1 A3 xcmplx_1_th_60 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_185:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 a implies b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M"
  using xreal_1_lm_38 sorry

mtheorem xreal_1_th_186:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & a <=XXREAL-0R1 b implies b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies  not (a <=XXREAL-0R1 b &  not b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
    show " not (a <=XXREAL-0R1 b &  not b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M)"
    proof-
      have cases: "a =HIDDENR1 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
        using A1 sorry
      have case1: "a =HIDDENR1 0NUMBERSK6 implies  not (a <=XXREAL-0R1 b &  not b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M)"
      proof(rule impI)
        assume "a =HIDDENR1 0NUMBERSK6"
        then have "a \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
           sorry
        then have "b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        thus " not (a <=XXREAL-0R1 b &  not b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M)"
          using xcmplx_0_def_9 sorry
      qed
      have case2: "a <XXREAL-0R3 0NUMBERSK6 implies (a <=XXREAL-0R1 b implies (b /XCMPLX-0K7 a >XXREAL-0R4 \<one>\<^sub>M implies  not  True ))"
      proof(rule impI,rule impI,rule impI)
        assume A2: "a <XXREAL-0R3 0NUMBERSK6"
        assume A3: "a <=XXREAL-0R1 b"
        assume "b /XCMPLX-0K7 a >XXREAL-0R4 \<one>\<^sub>M"
        then have "(b /XCMPLX-0K7 a)*XCMPLX-0K3 a <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 a"
          using A2 xreal_1_lm_24 sorry
        thus " not  True "
          using A2 A3 xcmplx_1_th_87 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_187:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 b implies \<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a <XXREAL-0R3 b implies (b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    assume A2: "a <XXREAL-0R3 b"
    assume "b /XCMPLX-0K7 a <=XXREAL-0R1 \<one>\<^sub>M"
    then have "(b /XCMPLX-0K7 a)*XCMPLX-0K3 a <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 a"
      using A1 xreal_1_lm_12 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_188:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 a implies \<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 a implies  not \<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 a"
    have "b /XCMPLX-0K7 a >XXREAL-0R4 a /XCMPLX-0K7 a"
      using A1 A2 xreal_1_lm_29 sorry
    thus " not \<one>\<^sub>M <XXREAL-0R3 b /XCMPLX-0K7 a"
      using A1 xcmplx_1_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_189:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 b implies  not a /XCMPLX-0K7 b <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "a <XXREAL-0R3 b"
    have "a /XCMPLX-0K7 b <XXREAL-0R3 b /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_26 sorry
    thus " not a /XCMPLX-0K7 b <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 xcmplx_1_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_190:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <XXREAL-0R3 a implies a /XCMPLX-0K7 b <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & b <XXREAL-0R3 a implies  not a /XCMPLX-0K7 b <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "b <XXREAL-0R3 a"
    have "a /XCMPLX-0K7 b <XXREAL-0R3 b /XCMPLX-0K7 b"
      using A1 A2 xreal_1_lm_29 sorry
    thus " not a /XCMPLX-0K7 b <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 xcmplx_1_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_191:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & b <XXREAL-0R3 a implies b /XCMPLX-0K7 a <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (b <XXREAL-0R3 a implies (b /XCMPLX-0K7 a >=XXREAL-0R2 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    assume A2: "b <XXREAL-0R3 a"
    assume "b /XCMPLX-0K7 a >=XXREAL-0R2 \<one>\<^sub>M"
    then have "(b /XCMPLX-0K7 a)*XCMPLX-0K3 a >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 a"
      using A1 xreal_1_lm_12 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_192:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 b implies b /XCMPLX-0K7 a <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 implies (a <XXREAL-0R3 b implies (b /XCMPLX-0K7 a >=XXREAL-0R2 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 0NUMBERSK6"
    assume A2: "a <XXREAL-0R3 b"
    assume "b /XCMPLX-0K7 a >=XXREAL-0R2 \<one>\<^sub>M"
    then have "(b /XCMPLX-0K7 a)*XCMPLX-0K3 a <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 a"
      using A1 xreal_1_lm_28 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_193:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 b & -XCMPLX-0K4 b <=XXREAL-0R1 a implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >=XXREAL-0R2 0NUMBERSK6 implies  not (-XCMPLX-0K4 b <=XXREAL-0R1 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >=XXREAL-0R2 0NUMBERSK6"
    show " not (-XCMPLX-0K4 b <=XXREAL-0R1 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
    proof-
      have cases: "b =HIDDENR1 0NUMBERSK6 or b >XXREAL-0R4 0NUMBERSK6"
        using A1 sorry
      have case1: "b =HIDDENR1 0NUMBERSK6 implies  not (-XCMPLX-0K4 b <=XXREAL-0R1 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
      proof(rule impI)
        assume "b =HIDDENR1 0NUMBERSK6"
        then have "b \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
           sorry
        then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        thus " not (-XCMPLX-0K4 b <=XXREAL-0R1 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
          using xcmplx_0_def_9 sorry
      qed
      have case2: "b >XXREAL-0R4 0NUMBERSK6 implies (-XCMPLX-0K4 b <=XXREAL-0R1 a implies (a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
      proof(rule impI,rule impI,rule impI)
        assume A2: "b >XXREAL-0R4 0NUMBERSK6"
        assume A3: "-XCMPLX-0K4 b <=XXREAL-0R1 a"
        assume "a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
        then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
          using A2 xreal_1_lm_13 sorry
        thus " not  True "
          using A2 A3 xcmplx_1_th_87 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_194:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 b & -XCMPLX-0K4 a <=XXREAL-0R1 b implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >=XXREAL-0R2 0NUMBERSK6 implies  not (-XCMPLX-0K4 a <=XXREAL-0R1 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >=XXREAL-0R2 0NUMBERSK6"
    show " not (-XCMPLX-0K4 a <=XXREAL-0R1 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
    proof-
      have cases: "b =HIDDENR1 0NUMBERSK6 or b >XXREAL-0R4 0NUMBERSK6"
        using A1 sorry
      have case1: "b =HIDDENR1 0NUMBERSK6 implies  not (-XCMPLX-0K4 a <=XXREAL-0R1 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
      proof(rule impI)
        assume "b =HIDDENR1 0NUMBERSK6"
        then have "b \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
           sorry
        then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        thus " not (-XCMPLX-0K4 a <=XXREAL-0R1 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
          using xcmplx_0_def_9 sorry
      qed
      have case2: "b >XXREAL-0R4 0NUMBERSK6 implies (-XCMPLX-0K4 a <=XXREAL-0R1 b implies (a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
      proof(rule impI,rule impI,rule impI)
        assume A2: "b >XXREAL-0R4 0NUMBERSK6"
        assume A3: "-XCMPLX-0K4 a <=XXREAL-0R1 b"
        assume "a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
        then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
          using A2 xreal_1_lm_13 sorry
        then have "a <XXREAL-0R3 -XCMPLX-0K4 b"
          using A2 xcmplx_1_th_87 sorry
        thus " not  True "
          using A3 xreal_1_th_26 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_195:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 0NUMBERSK6 & a <=XXREAL-0R1 -XCMPLX-0K4 b implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 0NUMBERSK6 implies  not (a <=XXREAL-0R1 -XCMPLX-0K4 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <=XXREAL-0R1 0NUMBERSK6"
    show " not (a <=XXREAL-0R1 -XCMPLX-0K4 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
    proof-
      have cases: "b =HIDDENR1 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
        using A1 sorry
      have case1: "b =HIDDENR1 0NUMBERSK6 implies  not (a <=XXREAL-0R1 -XCMPLX-0K4 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
      proof(rule impI)
        assume "b =HIDDENR1 0NUMBERSK6"
        then have "b \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
           sorry
        then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        thus " not (a <=XXREAL-0R1 -XCMPLX-0K4 b &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
          using xcmplx_0_def_9 sorry
      qed
      have case2: "b <XXREAL-0R3 0NUMBERSK6 implies (a <=XXREAL-0R1 -XCMPLX-0K4 b implies (a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
      proof(rule impI,rule impI,rule impI)
        assume A2: "b <XXREAL-0R3 0NUMBERSK6"
        assume A3: "a <=XXREAL-0R1 -XCMPLX-0K4 b"
        assume "a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
        then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >XXREAL-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
          using A2 xreal_1_lm_24 sorry
        thus " not  True "
          using A2 A3 xcmplx_1_th_87 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_196:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 0NUMBERSK6 & b <=XXREAL-0R1 -XCMPLX-0K4 a implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 0NUMBERSK6 implies  not (b <=XXREAL-0R1 -XCMPLX-0K4 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <=XXREAL-0R1 0NUMBERSK6"
    show " not (b <=XXREAL-0R1 -XCMPLX-0K4 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
    proof-
      have cases: "b =HIDDENR1 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
        using A1 sorry
      have case1: "b =HIDDENR1 0NUMBERSK6 implies  not (b <=XXREAL-0R1 -XCMPLX-0K4 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
      proof(rule impI)
        assume "b =HIDDENR1 0NUMBERSK6"
        then have "b \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
           sorry
        then have "a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 =XBOOLE-0R4 0NUMBERSK6"
           sorry
        thus " not (b <=XXREAL-0R1 -XCMPLX-0K4 a &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a /XCMPLX-0K7 b)"
          using xcmplx_0_def_9 sorry
      qed
      have case2: "b <XXREAL-0R3 0NUMBERSK6 implies (b <=XXREAL-0R1 -XCMPLX-0K4 a implies (a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
      proof(rule impI,rule impI,rule impI)
        assume A2: "b <XXREAL-0R3 0NUMBERSK6"
        assume A3: "b <=XXREAL-0R1 -XCMPLX-0K4 a"
        assume "a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
        then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >XXREAL-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
          using A2 xreal_1_lm_24 sorry
        then have "a >XXREAL-0R4 -XCMPLX-0K4 b"
          using A2 xcmplx_1_th_87 sorry
        thus " not  True "
          using A3 xreal_1_th_25 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_197:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & -XCMPLX-0K4 b <XXREAL-0R3 a implies -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies (-XCMPLX-0K4 b <XXREAL-0R3 a implies (a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
    assume A2: "-XCMPLX-0K4 b <XXREAL-0R3 a"
    assume "a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <=XXREAL-0R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_12 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_198:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & -XCMPLX-0K4 a <XXREAL-0R3 b implies -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies (-XCMPLX-0K4 a <XXREAL-0R3 b implies (a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
    assume A2: "-XCMPLX-0K4 a <XXREAL-0R3 b"
    assume "a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <=XXREAL-0R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_12 sorry
    then have "a <=XXREAL-0R1 -XCMPLX-0K4 b"
      using A1 xcmplx_1_th_87 sorry
    thus " not  True "
      using A2 xreal_1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_199:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 -XCMPLX-0K4 b implies -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 implies (a <XXREAL-0R3 -XCMPLX-0K4 b implies (a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
    assume A2: "a <XXREAL-0R3 -XCMPLX-0K4 b"
    assume "a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >=XXREAL-0R2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_28 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_200:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & b <XXREAL-0R3 -XCMPLX-0K4 a implies -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 implies (b <XXREAL-0R3 -XCMPLX-0K4 a implies (a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
    assume A2: "b <XXREAL-0R3 -XCMPLX-0K4 a"
    assume "a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >=XXREAL-0R2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_28 sorry
    then have "a >=XXREAL-0R2 -XCMPLX-0K4 b"
      using A1 xcmplx_1_th_87 sorry
    thus " not  True "
      using A2 xreal_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_201:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & a <=XXREAL-0R1 -XCMPLX-0K4 b implies a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies (a <=XXREAL-0R1 -XCMPLX-0K4 b implies (a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
    assume A2: "a <=XXREAL-0R1 -XCMPLX-0K4 b"
    assume "a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >XXREAL-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_13 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_202:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & b <=XXREAL-0R1 -XCMPLX-0K4 a implies a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies (b <=XXREAL-0R1 -XCMPLX-0K4 a implies (a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
    assume A2: "b <=XXREAL-0R1 -XCMPLX-0K4 a"
    assume "a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >XXREAL-0R4 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_13 sorry
    then have "a >XXREAL-0R4 -XCMPLX-0K4 b"
      using A1 xcmplx_1_th_87 sorry
    thus " not  True "
      using A2 xreal_1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_203:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & -XCMPLX-0K4 b <=XXREAL-0R1 a implies a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 implies (-XCMPLX-0K4 b <=XXREAL-0R1 a implies (a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
    assume A2: "-XCMPLX-0K4 b <=XXREAL-0R1 a"
    assume "a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_24 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_204:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & -XCMPLX-0K4 a <=XXREAL-0R1 b implies a /XCMPLX-0K7 b <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 implies (-XCMPLX-0K4 a <=XXREAL-0R1 b implies (a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
    assume A2: "-XCMPLX-0K4 a <=XXREAL-0R1 b"
    assume "a /XCMPLX-0K7 b >XXREAL-0R4 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_24 sorry
    then have "a <XXREAL-0R3 -XCMPLX-0K4 b"
      using A1 xcmplx_1_th_87 sorry
    thus " not  True "
      using A2 xreal_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_205:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & a <XXREAL-0R3 -XCMPLX-0K4 b implies a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies (a <XXREAL-0R3 -XCMPLX-0K4 b implies (a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
    assume A2: "a <XXREAL-0R3 -XCMPLX-0K4 b"
    assume "a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >=XXREAL-0R2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_12 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_206:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 b & b <XXREAL-0R3 -XCMPLX-0K4 a implies a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies (b <XXREAL-0R3 -XCMPLX-0K4 a implies (a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 0NUMBERSK6"
    assume A2: "b <XXREAL-0R3 -XCMPLX-0K4 a"
    assume "a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b >=XXREAL-0R2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_12 sorry
    then have "a >=XXREAL-0R2 -XCMPLX-0K4 b"
      using A1 xcmplx_1_th_87 sorry
    thus " not  True "
      using A2 xreal_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_207:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & -XCMPLX-0K4 b <XXREAL-0R3 a implies a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 implies (-XCMPLX-0K4 b <XXREAL-0R3 a implies (a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
    assume A2: "-XCMPLX-0K4 b <XXREAL-0R3 a"
    assume "a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <=XXREAL-0R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_28 sorry
    thus " not  True "
      using A1 A2 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_208:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 & -XCMPLX-0K4 a <XXREAL-0R3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <XXREAL-0R3 0NUMBERSK6 implies (-XCMPLX-0K4 a <XXREAL-0R3 b implies (a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M implies  not  True ))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <XXREAL-0R3 0NUMBERSK6"
    assume A2: "-XCMPLX-0K4 a <XXREAL-0R3 b"
    assume "a /XCMPLX-0K7 b >=XXREAL-0R2 -XCMPLX-0K4 \<one>\<^sub>M"
    then have "(a /XCMPLX-0K7 b)*XCMPLX-0K3 b <=XXREAL-0R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 b"
      using A1 xreal_1_lm_28 sorry
    then have "a <=XXREAL-0R1 -XCMPLX-0K4 b"
      using A1 xcmplx_1_th_87 sorry
    thus " not  True "
      using A2 xreal_1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_209:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies c <=XXREAL-0R1 b /XCMPLX-0K7 a) implies c <=XXREAL-0R1 b"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M implies b /XCMPLX-0K7 a >=XXREAL-0R2 c) implies c <=XXREAL-0R1 b"
  proof(rule ballI,rule ballI,rule impI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: " for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M implies b /XCMPLX-0K7 a >=XXREAL-0R2 c"
    have " for d be RealXREAL-0M1 holds d >XXREAL-0R4 \<one>\<^sub>M implies b *XCMPLX-0K3 d >=XXREAL-0R2 c"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be RealXREAL-0M1"
      assume "d >XXREAL-0R4 \<one>\<^sub>M"
      then have A2: "b /XCMPLX-0K7 d \<inverse>XCMPLX-0K5 >=XXREAL-0R2 c"
        using A1 xreal_1_lm_36 sorry
      have "d \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 d"
        using xcmplx_1_th_215 sorry
      then have "(b *XCMPLX-0K3 d)/XCMPLX-0K7 \<one>\<^sub>M >=XXREAL-0R2 c"
        using A2 xcmplx_1_th_77 sorry
      thus "b *XCMPLX-0K3 d >=XXREAL-0R2 c"
         sorry
    qed "sorry"
    thus "c <=XXREAL-0R1 b"
      using xreal_1_th_167 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_210:
" for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds ( for a be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a implies b /XCMPLX-0K7 a <=XXREAL-0R1 c) implies b <=XXREAL-0R1 c"
proof-
  have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  not (( for a be RealXREAL-0M1 holds  not ( not \<one>\<^sub>M <XXREAL-0R3 a &  not b /XCMPLX-0K7 a <=XXREAL-0R1 c)) &  not b <=XXREAL-0R1 c)"
  proof(rule ballI,rule ballI)
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    have "( for a be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M implies b /XCMPLX-0K7 a <=XXREAL-0R1 c) implies b <=XXREAL-0R1 c"
    proof(rule impI)
      assume A1: " for a be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M implies b /XCMPLX-0K7 a <=XXREAL-0R1 c"
      have " for d be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 d & d <XXREAL-0R3 \<one>\<^sub>M implies b <=XXREAL-0R1 c /XCMPLX-0K7 d"
      proof(rule ballI,rule impMI ,rule impI)
        fix d assume [ty]: "d be RealXREAL-0M1"
        have A2: "d \<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 d"
          using xcmplx_1_th_215 sorry
        assume A3: "0NUMBERSK6 <XXREAL-0R3 d"
          and A4: "d <XXREAL-0R3 \<one>\<^sub>M"
        have "d \<inverse>XCMPLX-0K5 >XXREAL-0R4 \<one>\<^sub>M \<inverse>XCMPLX-0K5"
          using A3 A4 xreal_1_lm_34 sorry
        then have "b /XCMPLX-0K7 d \<inverse>XCMPLX-0K5 <=XXREAL-0R1 c"
          using A1 sorry
        then have "(b *XCMPLX-0K3 d)/XCMPLX-0K7 \<one>\<^sub>M <=XXREAL-0R1 c"
          using A2 xcmplx_1_th_77 sorry
        thus "b <=XXREAL-0R1 c /XCMPLX-0K7 d"
          using A3 xreal_1_th_77 sorry
      qed "sorry"
      thus "b <=XXREAL-0R1 c"
        using xreal_1_th_209 sorry
    qed
    thus " not (( for a be RealXREAL-0M1 holds  not ( not \<one>\<^sub>M <XXREAL-0R3 a &  not b /XCMPLX-0K7 a <=XXREAL-0R1 c)) &  not b <=XXREAL-0R1 c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_211:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 a implies a \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  not (\<one>\<^sub>M <=XXREAL-0R1 a &  not a \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "\<one>\<^sub>M <=XXREAL-0R1 a implies a \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M \<inverse>XCMPLX-0K5"
      using xreal_1_lm_32 sorry
    thus " not (\<one>\<^sub>M <=XXREAL-0R1 a &  not a \<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_212:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a implies a \<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
  using xreal_1_lm_36 sorry

mtheorem xreal_1_th_213:
" for a be RealXREAL-0M1 holds a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
proof-
  have " for a be RealXREAL-0M1 holds  not (a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a \<inverse>XCMPLX-0K5)"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M implies (-XCMPLX-0K4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 a \<inverse>XCMPLX-0K5"
      using xreal_1_lm_33 sorry
    thus " not (a <=XXREAL-0R1 -XCMPLX-0K4 \<one>\<^sub>M &  not -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a \<inverse>XCMPLX-0K5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_214:
" for a be RealXREAL-0M1 holds a <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
proof-
  have " for a be RealXREAL-0M1 holds  not ( not a <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M & -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a \<inverse>XCMPLX-0K5)"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M implies (-XCMPLX-0K4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <XXREAL-0R3 a \<inverse>XCMPLX-0K5"
      using xreal_1_lm_31 sorry
    thus " not ( not a <XXREAL-0R3 -XCMPLX-0K4 \<one>\<^sub>M & -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a \<inverse>XCMPLX-0K5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_215:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 a /XCMPLX-0K7 \<two>\<^sub>M"
   sorry

mtheorem xreal_1_th_216:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies a /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 a"
  using xreal_1_lm_27 sorry

mtheorem xreal_1_th_217:
" for a be RealXREAL-0M1 holds a <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds a <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
    then have "\<two>\<^sub>M *XCMPLX-0K3 a <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using xreal_1_lm_12 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 a <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
       sorry
    thus "\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
      using xreal_1_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_218:
" for a be RealXREAL-0M1 holds a <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a"
proof-
  have " for a be RealXREAL-0M1 holds a <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
    then have "\<two>\<^sub>M *XCMPLX-0K3 a <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using xreal_1_lm_12 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M"
       sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a"
      using xreal_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_219:
" for a be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies \<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
    then have "\<two>\<^sub>M *XCMPLX-0K3 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using xreal_1_lm_12 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 a >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
       sorry
    thus "\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_lm_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_220:
" for a be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies 0NUMBERSK6 >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a"
proof-
  have " for a be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M implies 0NUMBERSK6 >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
    then have "\<two>\<^sub>M *XCMPLX-0K3 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)"
      using xreal_1_lm_12 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 0NUMBERSK6 >=XXREAL-0R2 \<one>\<^sub>M"
       sorry
    thus "0NUMBERSK6 >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a"
      using xreal_1_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_221:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies a /XCMPLX-0K7 \<three>\<^sub>M <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies  not a /XCMPLX-0K7 \<three>\<^sub>M <XXREAL-0R3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
    then have A2: "(a /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 (a /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 a /XCMPLX-0K7 \<three>\<^sub>M"
      using xreal_1_lm_10 sorry
    have "0NUMBERSK6 +XCMPLX-0K2 a /XCMPLX-0K7 \<three>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<three>\<^sub>M"
      using A1 xreal_1_lm_10 sorry
    thus " not a /XCMPLX-0K7 \<three>\<^sub>M <XXREAL-0R3 a"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_222:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 a /XCMPLX-0K7 \<three>\<^sub>M"
   sorry

(*begin*)
mtheorem xreal_1_th_223:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies a /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies  not a /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
    then have A2: "0NUMBERSK6 +XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M"
      using xreal_1_lm_10 sorry
    then have "a /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 (a /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M)+XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M"
      using A1 xreal_1_lm_10 sorry
    then have "a /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 ((a /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M)+XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M)+XCMPLX-0K2 a /XCMPLX-0K7 \<four>\<^sub>M"
      using xreal_1_lm_10 sorry
    thus " not a /XCMPLX-0K7 \<four>\<^sub>M <XXREAL-0R3 a"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_224:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 a /XCMPLX-0K7 \<four>\<^sub>M"
   sorry

mtheorem xreal_1_th_225:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <>HIDDENR2 0NUMBERSK6 implies ( ex c be RealXREAL-0M1 st a =HIDDENR1 b /XCMPLX-0K7 c)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <>HIDDENR2 0NUMBERSK6 implies  not ( for c be RealXREAL-0M1 holds  not a =HIDDENR1 b /XCMPLX-0K7 c)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <>HIDDENR2 0NUMBERSK6"
    then obtain c where
      [ty]:"c be ComplexXCMPLX-0M1" and 
      A2: "a =HIDDENR1 b /XCMPLX-0K7 c"
      using xcmplx_1_th_232 sorry
    show " not ( for c be RealXREAL-0M1 holds  not a =HIDDENR1 b /XCMPLX-0K7 c)"
    proof-
      have cases: "c =HIDDENR1 0NUMBERSK6 or c <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "c =HIDDENR1 0NUMBERSK6 implies  not ( for c be RealXREAL-0M1 holds  not a =HIDDENR1 b /XCMPLX-0K7 c)"
      proof(rule impI)
        assume "c =HIDDENR1 0NUMBERSK6"
        thus " not ( for c be RealXREAL-0M1 holds  not a =HIDDENR1 b /XCMPLX-0K7 c)"
          using A2 sorry
      qed
      have case2: "c <>HIDDENR2 0NUMBERSK6 implies ( ex tVar8 be RealXREAL-0M1 st a =HIDDENR1 b /XCMPLX-0K7 tVar8)"
      proof(rule impI)
        assume "c <>HIDDENR2 0NUMBERSK6"
        then have "c =HIDDENR1 b /XCMPLX-0K7 a"
          using A1 A2 xcmplx_1_th_54 sorry
        then have 
          [ty]:"c be RealXREAL-0M1"
           sorry
        show " ex tVar8 be RealXREAL-0M1 st a =HIDDENR1 b /XCMPLX-0K7 tVar8"
        proof(rule bexI[of _ "c"])
          show "a =HIDDENR1 b /XCMPLX-0K7 c"
            using A2 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_226:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r <XXREAL-0R3 s implies r <XXREAL-0R3 (r +XCMPLX-0K2 s)/XCMPLX-0K7 \<two>\<^sub>M & (r +XCMPLX-0K2 s)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 s"
proof-
  have " for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r <XXREAL-0R3 s implies r <XXREAL-0R3 (r +XCMPLX-0K2 s)/XCMPLX-0K7 \<two>\<^sub>M &  not (r +XCMPLX-0K2 s)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 s"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume "r <XXREAL-0R3 s"
    then have A1: "r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_lm_26 sorry
    then have "r /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 s /XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_lm_10 sorry
    thus "r <XXREAL-0R3 (r +XCMPLX-0K2 s)/XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    have "r /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 s /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 s /XCMPLX-0K7 \<two>\<^sub>M"
      using A1 xreal_1_lm_10 sorry
    thus " not (r +XCMPLX-0K2 s)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 s"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_cl_1:
"cluster note-that ext-realXXREAL-0V1 for ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds it be ext-realXXREAL-0V1"
     sorry
qed "sorry"

reserve p, q, r, s, t for "ExtRealXXREAL-0M1"
mtheorem xreal_1_th_227:
" for r be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 t implies ( ex s be ExtRealXXREAL-0M1 st r <XXREAL-0R3 s & s <XXREAL-0R3 t)"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 t implies ( ex tVar9 be ExtRealXXREAL-0M1 st  not r <XXREAL-0R3 tVar9 &  not tVar9 <XXREAL-0R3 t)"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 t"
    then have A2: "r <>HIDDENR2 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
    have A3: "t <>HIDDENR2 -inftyXXREAL-0K2"
      using A1 xxreal_0_th_5 sorry
    show " ex tVar9 be ExtRealXXREAL-0M1 st  not r <XXREAL-0R3 tVar9 &  not tVar9 <XXREAL-0R3 t"
    proof-
      have cases: "((r =HIDDENR1 -inftyXXREAL-0K2 & t =HIDDENR1 +inftyXXREAL-0K1 or r =HIDDENR1 -inftyXXREAL-0K2 & t inHIDDENR3 REALNUMBERSK2) or r inHIDDENR3 REALNUMBERSK2 & t =HIDDENR1 +inftyXXREAL-0K1) or r inHIDDENR3 REALNUMBERSK2 & t inHIDDENR3 REALNUMBERSK2"
        using A2 A3 xxreal_0_th_14 sorry
      have case1: "r =HIDDENR1 -inftyXXREAL-0K2 & t =HIDDENR1 +inftyXXREAL-0K1 implies ( ex tVar9 be ExtRealXXREAL-0M1 st  not r <XXREAL-0R3 tVar9 &  not tVar9 <XXREAL-0R3 t)"
      proof(rule impMI ,rule impI)
        assume A4: "r =HIDDENR1 -inftyXXREAL-0K2"
          and A5: "t =HIDDENR1 +inftyXXREAL-0K1"
        show " ex tVar9 be ExtRealXXREAL-0M1 st  not r <XXREAL-0R3 tVar9 &  not tVar9 <XXREAL-0R3 t"
        proof(rule bexI[of _ "0NUMBERSK6"])
          show " not r <XXREAL-0R3 0NUMBERSK6 &  not 0NUMBERSK6 <XXREAL-0R3 t"
            using A4 A5 sorry
        qed "sorry"
      qed
      have case2: "r =HIDDENR1 -inftyXXREAL-0K2 & t inHIDDENR3 REALNUMBERSK2 implies ( ex tVar10 be ExtRealXXREAL-0M1 st r <XXREAL-0R3 tVar10 &  not tVar10 <XXREAL-0R3 t)"
      proof(rule impMI ,rule impI)
        assume A6: "r =HIDDENR1 -inftyXXREAL-0K2"
          and A7: "t inHIDDENR3 REALNUMBERSK2"
        have 
          [ty]:"t be RealXREAL-0M1"
          using A7 sorry
        obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A8: "s <XXREAL-0R3 t"
          using xreal_1_th_2 sorry
        show " ex tVar10 be ExtRealXXREAL-0M1 st r <XXREAL-0R3 tVar10 &  not tVar10 <XXREAL-0R3 t"
        proof(rule bexI[of _ "s"],rule conjMI)
          have "s inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          thus "r <XXREAL-0R3 s"
            using A6 xxreal_0_th_12 sorry
          show " not s <XXREAL-0R3 t"
            using A8 sorry
        qed "sorry"
      qed
      have case3: "r inHIDDENR3 REALNUMBERSK2 & t =HIDDENR1 +inftyXXREAL-0K1 implies ( ex tVar11 be ExtRealXXREAL-0M1 st r <XXREAL-0R3 tVar11 &  not tVar11 <XXREAL-0R3 t)"
      proof(rule impMI ,rule impI)
        assume A9: "r inHIDDENR3 REALNUMBERSK2"
          and A10: "t =HIDDENR1 +inftyXXREAL-0K1"
        obtain r9 where 
          [ty]:"r9 be RealXREAL-0M1" and r9Def:"r9 = r"
          using A9 sorry
        obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A11: "r9 <XXREAL-0R3 s"
          using xreal_1_th_1 sorry
        show " ex tVar11 be ExtRealXXREAL-0M1 st r <XXREAL-0R3 tVar11 &  not tVar11 <XXREAL-0R3 t"
        proof(rule bexI[of _ "s"],rule conjMI)
          show "r <XXREAL-0R3 s"
            using A11 sorry
          have "s inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          thus " not s <XXREAL-0R3 t"
            using A10 xxreal_0_th_9 sorry
        qed "sorry"
      qed
      have case4: "r inHIDDENR3 REALNUMBERSK2 & t inHIDDENR3 REALNUMBERSK2 implies ( ex tVar12 be ExtRealXXREAL-0M1 st  not r <XXREAL-0R3 tVar12 &  not tVar12 <XXREAL-0R3 t)"
      proof(rule impMI ,rule impI)
        assume A12: "r inHIDDENR3 REALNUMBERSK2"
          and A13: "t inHIDDENR3 REALNUMBERSK2"
        have 
          [ty]:"r be RealXREAL-0M1" and
          [ty]:"t be RealXREAL-0M1"
          using A12 A13 sorry
        obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A14: "r <XXREAL-0R3 s"and A15: "s <XXREAL-0R3 t"
          using A1 xreal_1_th_5 sorry
        show " ex tVar12 be ExtRealXXREAL-0M1 st  not r <XXREAL-0R3 tVar12 &  not tVar12 <XXREAL-0R3 t"
        proof(rule bexI[of _ "s"])
          show " not r <XXREAL-0R3 s &  not s <XXREAL-0R3 t"
            using A14 A15 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_228:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ( for q be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & q <XXREAL-0R3 s implies t <=XXREAL-0R1 q) implies t <=XXREAL-0R1 r"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ( for q be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & q <XXREAL-0R3 s implies t <=XXREAL-0R1 q) implies t <=XXREAL-0R1 r"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: " for q be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & q <XXREAL-0R3 s implies t <=XXREAL-0R1 q"
    have " for q be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q implies t <=XXREAL-0R1 q"
    proof(rule ballI,rule impI)
      fix q assume [ty]: "q be ExtRealXXREAL-0M1"
      assume A3: "r <XXREAL-0R3 q"
      show "t <=XXREAL-0R1 q"
      proof-
        have cases: "q <XXREAL-0R3 s or s <=XXREAL-0R1 q"
           sorry
        have case1: "q <XXREAL-0R3 s implies t <=XXREAL-0R1 q"
        proof(rule impI)
          assume "q <XXREAL-0R3 s"
          thus "t <=XXREAL-0R1 q"
            using A2 A3 sorry
        qed
        have case2: "s <=XXREAL-0R1 q implies t <=XXREAL-0R1 q"
        proof(rule impI)
          assume A4: "s <=XXREAL-0R1 q"
          obtain p where
            [ty]:"p be ExtRealXXREAL-0M1" and 
            A5: "r <XXREAL-0R3 p"and A6: "p <XXREAL-0R3 s"
            using A1 xreal_1_th_227 sorry
          have "t <=XXREAL-0R1 p"
            using A2 A5 A6 sorry
          then have "t <=XXREAL-0R1 s"
            using A6 xxreal_0_th_2 sorry
          thus "t <=XXREAL-0R1 q"
            using A4 xxreal_0_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "t <=XXREAL-0R1 r"
      using xreal_1_th_227 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_229:
" for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ( for q be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & q <XXREAL-0R3 s implies q <=XXREAL-0R1 t) implies s <=XXREAL-0R1 t"
proof-
  have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds  for t be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 s & ( for q be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & q <XXREAL-0R3 s implies q <=XXREAL-0R1 t) implies s <=XXREAL-0R1 t"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    fix s assume [ty]: "s be ExtRealXXREAL-0M1"
    fix t assume [ty]: "t be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 s"
      and A2: " for q be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 q & q <XXREAL-0R3 s implies q <=XXREAL-0R1 t"
    have " for q be ExtRealXXREAL-0M1 holds t <XXREAL-0R3 q implies s <=XXREAL-0R1 q"
    proof-
      have " for q be ExtRealXXREAL-0M1 holds t <XXREAL-0R3 q & q <XXREAL-0R3 s implies  not  True "
      proof(rule ballI,rule impMI ,rule impI)
        fix q assume [ty]: "q be ExtRealXXREAL-0M1"
        assume A3: "t <XXREAL-0R3 q"
          and A4: "q <XXREAL-0R3 s"
        show " not  True "
        proof-
          have cases: "r <XXREAL-0R3 q or q <=XXREAL-0R1 r"
             sorry
          have case1: "r <XXREAL-0R3 q implies  not  True "
          proof(rule impI)
            assume "r <XXREAL-0R3 q"
            thus " not  True "
              using A2 A3 A4 sorry
          qed
          have case2: "q <=XXREAL-0R1 r implies  not  True "
          proof(rule impI)
            assume A5: "q <=XXREAL-0R1 r"
            obtain p where
              [ty]:"p be ExtRealXXREAL-0M1" and 
              A6: "r <XXREAL-0R3 p"and A7: "p <XXREAL-0R3 s"
              using A1 xreal_1_th_227 sorry
            have "p <=XXREAL-0R1 t"
              using A2 A6 A7 sorry
            then have "r <=XXREAL-0R1 t"
              using A6 xxreal_0_th_2 sorry
            thus " not  True "
              using A3 A5 xxreal_0_th_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "s <=XXREAL-0R1 t"
      using xreal_1_th_227 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_230:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 c implies b -XCMPLX-0K6 a <=XXREAL-0R1 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & b <=XXREAL-0R1 c implies b -XCMPLX-0K6 a <=XXREAL-0R1 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "b <=XXREAL-0R1 c"
    have "b +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 a +XCMPLX-0K2 c"
      using A1 A2 xreal_1_th_38 sorry
    thus "b -XCMPLX-0K6 a <=XXREAL-0R1 c"
      using xreal_1_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_231:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & b <=XXREAL-0R1 c implies b -XCMPLX-0K6 a <XXREAL-0R3 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & b <=XXREAL-0R1 c implies  not b -XCMPLX-0K6 a <XXREAL-0R3 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "b <=XXREAL-0R1 c"
    have "b +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 a +XCMPLX-0K2 c"
      using A1 A2 xreal_1_th_39 sorry
    thus " not b -XCMPLX-0K6 a <XXREAL-0R3 c"
      using xreal_1_lm_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem xreal_1_th_232:
" for a be RealXREAL-0M1 holds a -'XREAL-0K1 a =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds a -'XREAL-0K1 a =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a -XCMPLX-0K6 a =XBOOLE-0R4 0NUMBERSK6"
       sorry
    thus "a -'XREAL-0K1 a =XBOOLE-0R4 0NUMBERSK6"
      using xreal_0_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_233:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 a implies a -'XREAL-0K1 b =XBOOLE-0R4 a -XCMPLX-0K6 b"
  using xreal_1_th_48 xreal_0_def_2 sorry

mtheorem xreal_1_th_234:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (c <=XXREAL-0R1 a & c <=XXREAL-0R1 b) & a -'XREAL-0K1 c =XBOOLE-0R4 b -'XREAL-0K1 c implies a =HIDDENR1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >=XXREAL-0R2 c & (b >=XXREAL-0R2 c & a -'XREAL-0K1 c =XBOOLE-0R4 b -'XREAL-0K1 c) implies a =HIDDENR1 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 c"
      and A2: "b >=XXREAL-0R2 c"
      and A3: "a -'XREAL-0K1 c =XBOOLE-0R4 b -'XREAL-0K1 c"
    have "a -XCMPLX-0K6 c >=XXREAL-0R2 0NUMBERSK6"
      using A1 xreal_1_th_48 sorry
    then have A4: "a -'XREAL-0K1 c =XBOOLE-0R4 a -XCMPLX-0K6 c"
      using xreal_0_def_2 sorry
    have "b -XCMPLX-0K6 c >=XXREAL-0R2 0NUMBERSK6"
      using A2 xreal_1_th_48 sorry
    then have "a +XCMPLX-0K2 (-XCMPLX-0K4 c) =XBOOLE-0R4 b +XCMPLX-0K2 (-XCMPLX-0K4 c)"
      using A3 A4 xreal_0_def_2 sorry
    thus "a =HIDDENR1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_235:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 b implies (a -'XREAL-0K1 b)+XCMPLX-0K2 b =HIDDENR1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 b implies (a -'XREAL-0K1 b)+XCMPLX-0K2 b =HIDDENR1 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume "a >=XXREAL-0R2 b"
    then have "a -XCMPLX-0K6 b =XBOOLE-0R4 a -'XREAL-0K1 b"
      using xreal_1_th_233 sorry
    thus "(a -'XREAL-0K1 b)+XCMPLX-0K2 b =HIDDENR1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_236:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <XXREAL-0R3 a implies b -'XREAL-0K1 a <XXREAL-0R3 b -'XREAL-0K1 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a <=XXREAL-0R1 b & c <XXREAL-0R3 a implies  not b -'XREAL-0K1 a <XXREAL-0R3 b -'XREAL-0K1 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 b"
      and A2: "c <XXREAL-0R3 a"
    have A3: "b -XCMPLX-0K6 a <XXREAL-0R3 b -XCMPLX-0K6 c"
      using A2 xreal_1_th_15 sorry
    have "b -'XREAL-0K1 c =XBOOLE-0R4 b -XCMPLX-0K6 c"
      using A1 A2 xreal_1_th_233 xxreal_0_th_2 sorry
    thus " not b -'XREAL-0K1 a <XXREAL-0R3 b -'XREAL-0K1 c"
      using A1 A3 xreal_1_th_233 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xreal_1_th_237:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 a implies a -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds \<one>\<^sub>M <=XXREAL-0R1 a implies a -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "\<one>\<^sub>M <=XXREAL-0R1 a"
    then have "a -'XREAL-0K1 \<one>\<^sub>M =XBOOLE-0R4 a -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_233 sorry
    thus "a -'XREAL-0K1 \<one>\<^sub>M <XXREAL-0R3 a"
      using xreal_1_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
