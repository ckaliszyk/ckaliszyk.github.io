theory rearran1
  imports rfunct_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "NatNAT-1M1"
reserve r for "RealXREAL-0M1"
syntax REARRAN1K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')REARRAN1K1\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)REARRAN1K1\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> "r (#)VALUED-1K25 F"

mtheorem rearran1_add_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,E)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 F as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "r (#)VALUED-1K28\<^bsub>(D,E)\<^esub> F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "r (#)VALUED-1K25 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

mlemma rearran1_lm_1:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  not x inHIDDENR3 rngFUNCT-1K2 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix x assume [ty]: "x be objectHIDDENM1"
  assume A1: " not x inHIDDENR3 rngFUNCT-1K2 f"
  have "rngFUNCT-1K2 f missesXBOOLE-0R1 {TARSKIK1 x}"
  proof-
    let ?y = "the ElementSUBSET-1M1-of rngFUNCT-1K2 f /\\XBOOLE-0K3 {TARSKIK1 x}"
    have "rngFUNCT-1K2 f /\\XBOOLE-0K3 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume "rngFUNCT-1K2 f /\\XBOOLE-0K3 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
      then have "?y inTARSKIR2 rngFUNCT-1K2 f & ?y inTARSKIR2 {TARSKIK1 x}"
        using xboole_0_def_4 sorry
      thus " False "
        using A1 tarski_def_1 sorry
    qed
    thus "rngFUNCT-1K2 f missesXBOOLE-0R1 {TARSKIK1 x}"
      using xboole_0_def_7 sorry
  qed
  thus "f \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
    using relat_1_th_138 sorry
qed "sorry"

mdef rearran1_def_1 ("terms''ve-same-card-as-numberREARRAN1V1" 70 ) where
"attr terms've-same-card-as-numberREARRAN1V1 for FinSequenceFINSEQ-1M1 means
  (\<lambda>IT.  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 IT implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 IT .FUNCT-1K1 n implies cardCARD-1K4 B =XBOOLE-0R4 n))"..

mdef rearran1_def_2 ("ascendingREARRAN1V2" 70 ) where
"attr ascendingREARRAN1V2 for FinSequenceFINSEQ-1M1 means
  (\<lambda>IT.  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 IT -XCMPLX-0K6 \<one>\<^sub>M implies IT .FUNCT-1K1 n c=TARSKIR1 IT .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"..

mlemma rearran1_lm_2:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 A implies A .FUNCT-1K1 k be finiteFINSET-1V1"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
  fix A assume [ty]: "A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
  fix k assume [ty]: "k be NatNAT-1M1"
  assume "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 A"
  then have "k inTARSKIR2 domFINSEQ-1K5 A"
    using finseq_3_th_25 sorry
  then have "A .FUNCT-1K1 k inTARSKIR2 boolZFMISC-1K1 D"
    using finseq_2_th_11 sorry
  thus "A .FUNCT-1K1 k be finiteFINSET-1V1"
     sorry
qed "sorry"

mlemma rearran1_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D & A be terms've-same-card-as-numberREARRAN1V1 implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 A .FUNCT-1K1 lenFINSEQ-1K4 A implies B =XBOOLE-0R4 D)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D & A be terms've-same-card-as-numberREARRAN1V1 implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 A .FUNCT-1K1 lenFINSEQ-1K4 A implies (B <>HIDDENR2 D implies  False ))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    assume A1: "lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
      and A2: "A be terms've-same-card-as-numberREARRAN1V1"
    have A3: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A1 nat_1_th_13 sorry
    then have "lenFINSEQ-1K4 A inTARSKIR2 domFINSEQ-1K5 A"
      using finseq_3_th_25 sorry
    then have A4: "A .FUNCT-1K1 lenFINSEQ-1K4 A inTARSKIR2 boolZFMISC-1K1 D"
      using finseq_2_th_11 sorry
    fix B assume [ty]: "B be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume A5: "B =XBOOLE-0R4 A .FUNCT-1K1 lenFINSEQ-1K4 A"
    assume "B <>HIDDENR2 D"
    then have A6: "B c<XBOOLE-0R2 D"
      using A5 A4 sorry
    have "cardCARD-1K4 B =XBOOLE-0R4 cardCARD-1K4 D"
      using A1 A2 A5 A3 sorry
    thus " False "
      using A6 card_2_th_48 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rearran1_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  ex B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st (lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  not ( for B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  not ((lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1))"
  proof(rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 D =XBOOLE-0R4 Lamb1 implies ( ex B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st (lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1)"
    have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 D =XBOOLE-0R4 n implies ( ex B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st (lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1)) implies ( for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 D =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies  not ( for B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  not ((lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1)))"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: "?P(n)"
        fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
        assume A3: "cardCARD-1K4 D =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
        let ?x = "the ElementSUBSET-1M1-of D"
        let ?Y = "D \\SUBSET-1K6 {TARSKIK1 ?x}"
        have "{TARSKIK1 ?x} c=TARSKIR1 D"
          using zfmisc_1_th_31 sorry
        then have A4: "cardCARD-1K4 ?Y =HIDDENR1 cardCARD-1K4 D -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 ?x}"
          using card_2_th_44 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A3 card_1_th_30 sorry
        also have "... = n"
           sorry
        finally have "cardCARD-1K4 ?Y =HIDDENR1 n"
           sorry
        have "n =XBOOLE-0R4 0NUMBERSK6 & ( ex f be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st cardCARD-1K4 D =XBOOLE-0R4 lenFINSEQ-1K4 f & (f be ascendingREARRAN1V2 & f be terms've-same-card-as-numberREARRAN1V1)) or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies ( ex g be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st lenFINSEQ-1K4 g =XBOOLE-0R4 cardCARD-1K4 D & (g be ascendingREARRAN1V2 & g be terms've-same-card-as-numberREARRAN1V1)))"
        proof-
          show "n =XBOOLE-0R4 0NUMBERSK6 & ( ex f be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st cardCARD-1K4 D =XBOOLE-0R4 lenFINSEQ-1K4 f & (f be ascendingREARRAN1V2 & f be terms've-same-card-as-numberREARRAN1V1)) or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies ( ex g be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st lenFINSEQ-1K4 g =XBOOLE-0R4 cardCARD-1K4 D & (g be ascendingREARRAN1V2 & g be terms've-same-card-as-numberREARRAN1V1)))"
          proof-
            have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies ( ex f be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st cardCARD-1K4 D =XBOOLE-0R4 lenFINSEQ-1K4 f & (f be ascendingREARRAN1V2 & f be terms've-same-card-as-numberREARRAN1V1))"
            proof(rule impI)
              assume A5: "n =XBOOLE-0R4 0NUMBERSK6"
              let ?f = "<*FINSEQ-1K10 D*>"
              have A6: "lenFINSEQ-1K4 ?f =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_39 sorry
              have A7: "rngFUNCT-1K2 ?f =XBOOLE-0R4 {TARSKIK1 D}"
                using finseq_1_th_39 sorry
              have "rngFUNCT-1K2 ?f c=TARSKIR1 boolZFMISC-1K1 D"
              proof-
                have "rngFUNCT-1K2 (<*FINSEQ-1K10 D*>) c=TARSKIR1 boolZFMISC-1K1 D"
                proof-
                  have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K10 D*>) implies z inHIDDENR3 boolZFMISC-1K1 D"
                  proof(rule ballI,rule impI)
                    fix z assume [ty]: "z be objectHIDDENM1"
                    assume "z inHIDDENR3 rngFUNCT-1K2 ?f"
                    then have "z =HIDDENR1 D"
                      using A7 tarski_def_1 sorry
                    thus "z inHIDDENR3 boolZFMISC-1K1 D"
                      using zfmisc_1_def_1 sorry
                  qed "sorry"
                  thus "rngFUNCT-1K2 (<*FINSEQ-1K10 D*>) c=TARSKIR1 boolZFMISC-1K1 D"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then obtain f where 
                [ty]:"f be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D" and fDef:"f = ?f"
                using finseq_1_def_4 sorry
              show " ex f be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st cardCARD-1K4 D =XBOOLE-0R4 lenFINSEQ-1K4 f & (f be ascendingREARRAN1V2 & f be terms've-same-card-as-numberREARRAN1V1)"
              proof(rule bexI[of _ "f"],rule conjMI,rule conjMI)
                show "cardCARD-1K4 D =XBOOLE-0R4 lenFINSEQ-1K4 f"
                  using A3 A5 finseq_1_th_40 sorry
                show "f be ascendingREARRAN1V2"
                  using A6 xxreal_0_th_2 sorry
                show "f be terms've-same-card-as-numberREARRAN1V1"
                proof-
                  have " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 f implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 f .FUNCT-1K1 m implies cardCARD-1K4 B =XBOOLE-0R4 m)"
                  proof(rule ballI,rule impI,rule ballI,rule impI)
                    fix m assume [ty]: "m be NatNAT-1M1"
                    assume "\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 f"
                    then have A8: "m =XBOOLE-0R4 \<one>\<^sub>M"
                      using A6 xxreal_0_th_1 sorry
                    fix B assume [ty]: "B be finiteFINSET-1V1\<bar>setHIDDENM2"
                    assume "B =XBOOLE-0R4 f .FUNCT-1K1 m"
                    thus "cardCARD-1K4 B =XBOOLE-0R4 m"
                      using A3 A5 A8 finseq_1_th_40 sorry
                  qed "sorry"
                  thus "f be terms've-same-card-as-numberREARRAN1V1"
                    using rearran1_def_1 sorry
                qed
              qed "sorry"
            qed
            have case2: "n <>HIDDENR2 0NUMBERSK6 implies ( ex g be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st lenFINSEQ-1K4 g =XBOOLE-0R4 cardCARD-1K4 D & (g be ascendingREARRAN1V2 & g be terms've-same-card-as-numberREARRAN1V1))"
            proof(rule impI)
              assume "n <>HIDDENR2 0NUMBERSK6"
              then obtain Y where 
                [ty]:"Y be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2" and YDef:"Y = ?Y"
                using A4 sorry
              have "D inTARSKIR2 boolZFMISC-1K1 D"
                using zfmisc_1_def_1 sorry
              then have A9: "{TARSKIK1 D} c=TARSKIR1 boolZFMISC-1K1 D"
                using zfmisc_1_th_31 sorry
              obtain f where
                [ty]:"f be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 Y" and 
                A10: "lenFINSEQ-1K4 f =XBOOLE-0R4 cardCARD-1K4 Y"and A11: "f be ascendingREARRAN1V2"and A12: "f be terms've-same-card-as-numberREARRAN1V1"
                using A2 A4 sorry
              let ?g = "f ^FINSEQ-1K8 (<*FINSEQ-1K10 D*>)"
              have A13: "rngFUNCT-1K2 (<*FINSEQ-1K10 D*>) =XBOOLE-0R4 {TARSKIK1 D} & rngFUNCT-1K2 ?g =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(boolZFMISC-1K1 Y)\<^esub> f \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K10 D*>)"
                using finseq_1_th_31 finseq_1_th_39 sorry
              have "boolZFMISC-1K1 Y c=TARSKIR1 boolZFMISC-1K1 D"
                using zfmisc_1_th_67 sorry
              then have "rngRELSET-1K2\<^bsub>(boolZFMISC-1K1 Y)\<^esub> f c=TARSKIR1 boolZFMISC-1K1 D"
                 sorry
              then have "rngFUNCT-1K2 ?g c=TARSKIR1 boolZFMISC-1K1 D \\/XBOOLE-0K2 boolZFMISC-1K1 D"
                using A9 A13 xboole_1_th_13 sorry
              then obtain g where 
                [ty]:"g be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D" and gDef:"g = ?g"
                using finseq_1_def_4 sorry
              show " ex g be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st lenFINSEQ-1K4 g =XBOOLE-0R4 cardCARD-1K4 D & (g be ascendingREARRAN1V2 & g be terms've-same-card-as-numberREARRAN1V1)"
              proof(rule bexI[of _ "g"],rule conjMI,rule conjMI)
                have A14: "lenFINSEQ-1K4 (<*FINSEQ-1K10 D*>) =XBOOLE-0R4 \<one>\<^sub>M"
                  using finseq_1_th_39 sorry
                then have A15: "lenFINSEQ-1K4 g =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
                  using finseq_1_th_22 sorry
                show "lenFINSEQ-1K4 g =XBOOLE-0R4 cardCARD-1K4 D"
                  using A3 A4 A10 A14 finseq_1_th_22 sorry
                show "g be ascendingREARRAN1V2"
                proof-
                  have " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 g -XCMPLX-0K6 \<one>\<^sub>M implies g .FUNCT-1K1 m c=TARSKIR1 g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                  proof(rule ballI,rule impMI ,rule impI)
                    fix m assume [ty]: "m be NatNAT-1M1"
                    assume A16: "\<one>\<^sub>M <=XXREAL-0R1 m"
                      and A17: "m <=XXREAL-0R1 lenFINSEQ-1K4 g -XCMPLX-0K6 \<one>\<^sub>M"
                    have "m inTARSKIR2 domFINSEQ-1K5 f"
                      using A15 A16 A17 finseq_3_th_25 sorry
                    then have A18: "g .FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 m"
                      using finseq_1_def_7 sorry
                    show "g .FUNCT-1K1 m c=TARSKIR1 g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                    proof-
                      have cases: "m =XBOOLE-0R4 lenFINSEQ-1K4 f or m <>HIDDENR2 lenFINSEQ-1K4 f"
                         sorry
                      have case1: "m =XBOOLE-0R4 lenFINSEQ-1K4 f implies g .FUNCT-1K1 m c=TARSKIR1 g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                      proof(rule impI)
                        assume A19: "m =XBOOLE-0R4 lenFINSEQ-1K4 f"
                        then obtain gm where 
                          [ty]:"gm be finiteFINSET-1V1\<bar>setHIDDENM2" and gmDef:"gm = g .FUNCT-1K1 m"
                          using A16 A18 rearran1_lm_2 sorry
                        have "gm =XBOOLE-0R4 Y & g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 D"
                          using A10 A12 A18 A19 rearran1_lm_3 finseq_1_th_42 sorry
                        thus "g .FUNCT-1K1 m c=TARSKIR1 g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                           sorry
                      qed
                      have case2: "m <>HIDDENR2 lenFINSEQ-1K4 f implies g .FUNCT-1K1 m c=TARSKIR1 g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                      proof(rule impI)
                        assume "m <>HIDDENR2 lenFINSEQ-1K4 f"
                        then have "m <XXREAL-0R3 lenFINSEQ-1K4 f"
                          using A15 A17 xxreal_0_th_1 sorry
                        then have A20: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
                          using nat_1_th_13 sorry
                        have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                          using A16 nat_1_th_13 sorry
                        then have "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                          using A20 finseq_3_th_25 sorry
                        then have A21: "g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                          using finseq_1_def_7 sorry
                        have "m <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 \<one>\<^sub>M"
                          using A20 xreal_1_th_19 sorry
                        thus "g .FUNCT-1K1 m c=TARSKIR1 g .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                          using A11 A16 A18 A21 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                  thus "g be ascendingREARRAN1V2"
                    using rearran1_def_2 sorry
                qed
                show "g be terms've-same-card-as-numberREARRAN1V1"
                proof-
                  have " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 g implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 g .FUNCT-1K1 m implies cardCARD-1K4 B =XBOOLE-0R4 m)"
                  proof(rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
                    fix m assume [ty]: "m be NatNAT-1M1"
                    assume A22: "\<one>\<^sub>M <=XXREAL-0R1 m"
                      and A23: "m <=XXREAL-0R1 lenFINSEQ-1K4 g"
                    fix B assume [ty]: "B be finiteFINSET-1V1\<bar>setHIDDENM2"
                    assume A24: "B =XBOOLE-0R4 g .FUNCT-1K1 m"
                    show "cardCARD-1K4 B =XBOOLE-0R4 m"
                    proof-
                      have cases: "m =XBOOLE-0R4 lenFINSEQ-1K4 g or m <>HIDDENR2 lenFINSEQ-1K4 g"
                         sorry
                      have case1: "m =XBOOLE-0R4 lenFINSEQ-1K4 g implies cardCARD-1K4 B =XBOOLE-0R4 m"
                      proof(rule impI)
                        assume "m =XBOOLE-0R4 lenFINSEQ-1K4 g"
                        thus "cardCARD-1K4 B =XBOOLE-0R4 m"
                          using A3 A4 A10 A15 A24 finseq_1_th_42 sorry
                      qed
                      have case2: "m <>HIDDENR2 lenFINSEQ-1K4 g implies cardCARD-1K4 B =XBOOLE-0R4 m"
                      proof(rule impI)
                        assume "m <>HIDDENR2 lenFINSEQ-1K4 g"
                        then have "m <XXREAL-0R3 lenFINSEQ-1K4 g"
                          using A23 xxreal_0_th_1 sorry
                        then have A25: "m <=XXREAL-0R1 lenFINSEQ-1K4 f"
                          using A15 nat_1_th_13 sorry
                        then have "m inTARSKIR2 domFINSEQ-1K5 f"
                          using A22 finseq_3_th_25 sorry
                        then have "g .FUNCT-1K1 m =XBOOLE-0R4 f .FUNCT-1K1 m"
                          using finseq_1_def_7 sorry
                        thus "cardCARD-1K4 B =XBOOLE-0R4 m"
                          using A12 A22 A24 A25 sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                  thus "g be terms've-same-card-as-numberREARRAN1V1"
                    using rearran1_def_1 sorry
                qed
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " not ( for B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  not ((lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A26: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A26 A1 sorry
    thus " not ( for B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  not ((lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rearran1_def_3 ("lenght-equal-card-of-setREARRAN1V3\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr lenght-equal-card-of-setREARRAN1V3\<^bsub>(X)\<^esub> for FinSequenceFINSEQ-1M3-of X means
  (\<lambda>IT.  ex B be finiteFINSET-1V1\<bar>setHIDDENM2 st B =XBOOLE-0R4 unionTARSKIK3 X & lenFINSEQ-1K4 IT =XBOOLE-0R4 cardCARD-1K4 B)"..

mtheorem rearran1_cl_1:
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub> for FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st it be terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>"
  proof-
    have " ex tVar3 be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st (tVar3 be terms've-same-card-as-numberREARRAN1V1 & tVar3 be ascendingREARRAN1V2) & tVar3 be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>"
    proof-
      obtain B where
        [ty]:"B be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D" and 
        A1: "(lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D & B be ascendingREARRAN1V2) & B be terms've-same-card-as-numberREARRAN1V1"
        using rearran1_lm_4 sorry
      show " ex tVar3 be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D st (tVar3 be terms've-same-card-as-numberREARRAN1V1 & tVar3 be ascendingREARRAN1V2) & tVar3 be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>"
      proof(rule bexI[of _ "B"])
        have "unionTARSKIK3 (boolZFMISC-1K1 D) =XBOOLE-0R4 D"
          using zfmisc_1_th_81 sorry
        thus "(B be terms've-same-card-as-numberREARRAN1V1 & B be ascendingREARRAN1V2) & B be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax REARRAN1M1 :: " Set \<Rightarrow> Ty" ("RearrangmentGenREARRAN1M1-of  _ " [70]70)
translations "RearrangmentGenREARRAN1M1-of D" \<rightharpoonup> "terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"

reserve C, D for " non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
reserve a for "FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
mtheorem rearran1_th_1:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds a be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub> iff lenFINSEQ-1K4 a =XBOOLE-0R4 cardCARD-1K4 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds (A be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub> implies lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D) & (lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D implies A be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    show "A be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub> implies lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
      using zfmisc_1_th_81 sorry
    assume A1: "lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
    have "D =XBOOLE-0R4 unionTARSKIK3 (boolZFMISC-1K1 D) & lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
    proof-
      show "D =XBOOLE-0R4 unionTARSKIK3 (boolZFMISC-1K1 D) & lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
        using A1 zfmisc_1_th_81 sorry
    qed
    thus "A be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>"
      using bexI[of _ "D"] rearran1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_2:
" for a be FinSequenceFINSEQ-1M1 holds a be ascendingREARRAN1V2 iff ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 a) & m inTARSKIR2 domFINSEQ-1K5 a implies a .FUNCT-1K1 n c=TARSKIR1 a .FUNCT-1K1 m)"
proof-
  have " for A be FinSequenceFINSEQ-1M1 holds (A be ascendingREARRAN1V2 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 A) & m inTARSKIR2 domFINSEQ-1K5 A implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 m)) & (( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 A) & m inTARSKIR2 domFINSEQ-1K5 A implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 m) implies A be ascendingREARRAN1V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be FinSequenceFINSEQ-1M1"
    show "A be ascendingREARRAN1V2 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 A) & m inTARSKIR2 domFINSEQ-1K5 A implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 m)"
    proof(rule impI,rule ballI,rule ballI,rule impI)
      let ?P = "\<lambda>Lamb1.  for n be NatNAT-1M1 holds (n <=XXREAL-0R1 Lamb1 & n inTARSKIR2 domFINSEQ-1K5 A) & Lamb1 inTARSKIR2 domFINSEQ-1K5 A implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 Lamb1"
      assume A1: "A be ascendingREARRAN1V2"
      have A2: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for m be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds (n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 A) & m inTARSKIR2 domFINSEQ-1K5 A implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 m) implies ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M & (n inTARSKIR2 domFINSEQ-1K5 A & m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A) implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
        proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A3: "?P(m)"
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A4: "n <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
            and A5: "n inTARSKIR2 domFINSEQ-1K5 A"
            and A6: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A"
          have "n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M & A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) or n <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M & (n <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
          proof-
            show "n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M & A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) or n <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M & (n <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
            proof-
              have cases: "n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M or n <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M"
                 sorry
              have case1: "n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume "n =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
                thus "A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                   sorry
              qed
              have case2: "n <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume "n <>HIDDENR2 m +NAT-1K1 \<one>\<^sub>M"
                then have "n <XXREAL-0R3 m +NAT-1K1 \<one>\<^sub>M"
                  using A4 xxreal_0_th_1 sorry
                then have A7: "n <=XXREAL-0R1 m"
                  using nat_1_th_13 sorry
                have "\<one>\<^sub>M <=XXREAL-0R1 n"
                  using A5 finseq_3_th_25 sorry
                then have A8: "\<one>\<^sub>M <=XXREAL-0R1 m"
                  using A7 xxreal_0_th_2 sorry
                have A9: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
                  using A6 finseq_3_th_25 sorry
                have "m <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                then have "m <=XXREAL-0R1 lenFINSEQ-1K4 A"
                  using A9 xxreal_0_th_2 sorry
                then have "m inTARSKIR2 domFINSEQ-1K5 A"
                  using A8 finseq_3_th_25 sorry
                then have A10: "A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 m"
                  using A3 A5 A7 sorry
                have "m <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
                  using A9 xreal_1_th_19 sorry
                then have "A .FUNCT-1K1 m c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                  using A1 A8 sorry
                thus "A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                  using A10 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume A11: "(n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 A) & m inTARSKIR2 domFINSEQ-1K5 A"
      have A12: "?P(0NUMBERSK6)"
         sorry
      have " for m be NatNAT-1M1 holds ?P(m)"
        using nat_1_sch_2 A12 A2 sorry
      thus "A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 m"
        using A11 sorry
    qed "sorry"
    assume A13: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n <=XXREAL-0R1 m & n inTARSKIR2 domFINSEQ-1K5 A) & m inTARSKIR2 domFINSEQ-1K5 A implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 m"
    have " for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M implies A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A14: "\<one>\<^sub>M <=XXREAL-0R1 n"
        and A15: "n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
      have A16: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
        using A15 xreal_1_th_19 sorry
      have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have "n <=XXREAL-0R1 lenFINSEQ-1K4 A"
        using A16 xxreal_0_th_2 sorry
      then have A17: "n inTARSKIR2 domFINSEQ-1K5 A"
        using A14 finseq_3_th_25 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A"
        using A16 finseq_3_th_25 sorry
      thus "A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        using A13 A17 nat_1_th_11 sorry
    qed "sorry"
    thus "A be ascendingREARRAN1V2"
      using rearran1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_3:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds a .FUNCT-1K1 lenFINSEQ-1K4 a =XBOOLE-0R4 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds A .FUNCT-1K1 lenFINSEQ-1K4 A =XBOOLE-0R4 D"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    have A1: "lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
      using rearran1_th_1 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using nat_1_th_14 sorry
    then have "A .FUNCT-1K1 lenFINSEQ-1K4 A be finiteFINSET-1V1\<bar>setHIDDENM2"
      using rearran1_lm_2 sorry
    thus "A .FUNCT-1K1 lenFINSEQ-1K4 A =XBOOLE-0R4 D"
      using A1 rearran1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_4:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds lenFINSEQ-1K4 a <>HIDDENR2 0NUMBERSK6"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds lenFINSEQ-1K4 A =XBOOLE-0R4 0NUMBERSK6 implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    assume "lenFINSEQ-1K4 A =XBOOLE-0R4 0NUMBERSK6"
    then have "cardCARD-1K4 D =XBOOLE-0R4 0NUMBERSK6"
      using rearran1_th_1 sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_5:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 a & m inTARSKIR2 domFINSEQ-1K5 a) & n <>HIDDENR2 m implies a .FUNCT-1K1 n <>HIDDENR2 a .FUNCT-1K1 m"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 A & (m inTARSKIR2 domFINSEQ-1K5 A & (n <>HIDDENR2 m & A .FUNCT-1K1 n =XBOOLE-0R4 A .FUNCT-1K1 m)) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A1: "n inTARSKIR2 domFINSEQ-1K5 A"
      and A2: "m inTARSKIR2 domFINSEQ-1K5 A"
      and A3: "n <>HIDDENR2 m & A .FUNCT-1K1 n =XBOOLE-0R4 A .FUNCT-1K1 m"
    have A4: "\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A2 finseq_3_th_25 sorry
    have A5: "\<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A1 finseq_3_th_25 sorry
    obtain Am where 
      [ty]:"Am be finiteFINSET-1V1\<bar>setHIDDENM2" and AmDef:"Am = A .FUNCT-1K1 m"
      using A4 rearran1_lm_2 sorry
    have "cardCARD-1K4 Am =XBOOLE-0R4 m"
      using A4 rearran1_def_1 sorry
    thus " False "
      using A3 A5 rearran1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 a -XCMPLX-0K6 \<one>\<^sub>M implies a .FUNCT-1K1 n <>HIDDENR2 a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M implies  not A .FUNCT-1K1 n <>HIDDENR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be ascendingREARRAN1V2\<bar>terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
    have A3: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A2 xreal_1_th_19 sorry
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have "n <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A3 xxreal_0_th_2 sorry
    then have A4: "n inTARSKIR2 domFINSEQ-1K5 A"
      using A1 finseq_3_th_25 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have A5: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A"
      using A3 finseq_3_th_25 sorry
    have "n <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
       sorry
    thus " not A .FUNCT-1K1 n <>HIDDENR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A4 A5 rearran1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rearran1_lm_5:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds n inTARSKIR2 domFINSEQ-1K5 a implies a .FUNCT-1K1 n c=TARSKIR1 D"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds n inTARSKIR2 domFINSEQ-1K5 a implies a .FUNCT-1K1 n c=TARSKIR1 D"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix a assume [ty]: "a be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    assume "n inTARSKIR2 domFINSEQ-1K5 a"
    then have "a .FUNCT-1K1 n inTARSKIR2 boolZFMISC-1K1 D"
      using finseq_2_th_11 sorry
    thus "a .FUNCT-1K1 n c=TARSKIR1 D"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_7:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds n inTARSKIR2 domFINSEQ-1K5 a implies a .FUNCT-1K1 n <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds n inTARSKIR2 domFINSEQ-1K5 A implies (A .FUNCT-1K1 n =XBOOLE-0R4 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    assume "n inTARSKIR2 domFINSEQ-1K5 A"
    then have A1: "\<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using finseq_3_th_25 sorry
    assume "A .FUNCT-1K1 n =XBOOLE-0R4 {}XBOOLE-0K1"
    thus " False "
      using A1 rearran1_def_1 card_1_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_8:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 a -XCMPLX-0K6 \<one>\<^sub>M implies a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 a .FUNCT-1K1 n <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M implies (A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n =XBOOLE-0R4 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be terms've-same-card-as-numberREARRAN1V1\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
    have A3: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A2 xreal_1_th_19 sorry
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have A4: "n <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A3 xxreal_0_th_2 sorry
    then obtain An1 An where 
      [ty]:"An1 be finiteFINSET-1V1\<bar>setHIDDENM2" and An1Def:"An1 = A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)" and
      [ty]:"An be finiteFINSET-1V1\<bar>setHIDDENM2" and AnDef:"An = A .FUNCT-1K1 n"
      using A1 A3 rearran1_lm_2 nat_1_th_11 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have A5: "cardCARD-1K4 An1 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using A3 rearran1_def_1 sorry
    assume "A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A6: "A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 A .FUNCT-1K1 n"
      using xboole_1_th_37 sorry
    have "cardCARD-1K4 An =XBOOLE-0R4 n"
      using A1 A4 rearran1_def_1 sorry
    then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
      using A5 A6 nat_1_th_43 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 n -XCMPLX-0K6 n"
      using xreal_1_th_19 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
       sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  ex d be ElementSUBSET-1M1-of D st a .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 d}"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds  ex tVar5 be ElementSUBSET-1M1-of D st A .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 tVar5}"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be terms've-same-card-as-numberREARRAN1V1\<bar>lenght-equal-card-of-setREARRAN1V3\<^bsub>(boolZFMISC-1K1 D)\<^esub>\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    have "lenFINSEQ-1K4 A <>HIDDENR2 0NUMBERSK6"
      using rearran1_th_4 sorry
    then have A1: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using nat_1_th_13 sorry
    then obtain A1 where 
      [ty]:"A1 be finiteFINSET-1V1\<bar>setHIDDENM2" and A1Def:"A1 = A .FUNCT-1K1 \<one>\<^sub>M"
      using rearran1_lm_2 sorry
    have "cardCARD-1K4 A1 =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 rearran1_def_1 sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "{TARSKIK1 x} =XBOOLE-0R4 A .FUNCT-1K1 \<one>\<^sub>M"
      using card_2_th_42 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A"
      using A1 finseq_3_th_25 sorry
    then have "A .FUNCT-1K1 \<one>\<^sub>M c=TARSKIR1 D"
      using rearran1_lm_5 sorry
    then have 
      [ty]:"x be ElementSUBSET-1M1-of D"
      using A2 zfmisc_1_th_31 sorry
    show " ex tVar5 be ElementSUBSET-1M1-of D st A .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 tVar5}"
    proof(rule bexI[of _ "x"])
      show "A .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 x}"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_10:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for a be terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 a -XCMPLX-0K6 \<one>\<^sub>M implies ( ex d be ElementSUBSET-1M1-of D st (a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 a .FUNCT-1K1 n =XBOOLE-0R4 {TARSKIK1 d} & a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 a .FUNCT-1K1 n \\/XBOOLE-0K2 {TARSKIK1 d}) & a .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 d} =XBOOLE-0R4 a .FUNCT-1K1 n)"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for A be terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M implies ( ex tVar6 be ElementSUBSET-1M1-of D st {TARSKIK1 tVar6} =XBOOLE-0R4 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n & (A .FUNCT-1K1 n \\/XBOOLE-0K2 {TARSKIK1 tVar6} =HIDDENR1 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 tVar6} =HIDDENR1 A .FUNCT-1K1 n))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be terms've-same-card-as-numberREARRAN1V1\<bar>ascendingREARRAN1V2\<bar>FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
    have A3: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A2 xreal_1_th_19 sorry
    have A4: "A .FUNCT-1K1 n c=TARSKIR1 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A1 A2 rearran1_def_2 sorry
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have A5: "n <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A3 xxreal_0_th_2 sorry
    then obtain An1 An where 
      [ty]:"An1 be finiteFINSET-1V1\<bar>setHIDDENM2" and An1Def:"An1 = A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)" and
      [ty]:"An be finiteFINSET-1V1\<bar>setHIDDENM2" and AnDef:"An = A .FUNCT-1K1 n"
      using A1 A3 rearran1_lm_2 nat_1_th_11 sorry
    have A6: "cardCARD-1K4 An =XBOOLE-0R4 n"
      using A1 A5 rearran1_def_1 sorry
    have A7: "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have "cardCARD-1K4 An1 =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using A3 rearran1_def_1 sorry
    then have "cardCARD-1K4 (An1 \\SUBSET-1K6 An) =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 n"
      using A4 A6 card_2_th_44 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "cardCARD-1K4 (An1 \\SUBSET-1K6 An) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A8: "{TARSKIK1 x} =XBOOLE-0R4 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n"
      using card_2_th_42 sorry
    have "x inHIDDENR3 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n"
      using A8 zfmisc_1_th_31 sorry
    then have A9: " not x inHIDDENR3 A .FUNCT-1K1 n"
      using xboole_0_def_5 sorry
    have A10: "x inHIDDENR3 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A8 zfmisc_1_th_31 sorry
    have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A"
      using A3 A7 finseq_3_th_25 sorry
    then have "A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 D"
      using rearran1_lm_5 sorry
    then have 
      [ty]:"x be ElementSUBSET-1M1-of D"
      using A10 sorry
    show " ex tVar6 be ElementSUBSET-1M1-of D st {TARSKIK1 tVar6} =XBOOLE-0R4 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n & (A .FUNCT-1K1 n \\/XBOOLE-0K2 {TARSKIK1 tVar6} =HIDDENR1 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 tVar6} =HIDDENR1 A .FUNCT-1K1 n)"
    proof(rule bexI[of _ "x"],rule conjMI,rule conjMI)
      show "{TARSKIK1 x} =XBOOLE-0R4 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n"
        using A8 sorry
      have "A .FUNCT-1K1 n \\/XBOOLE-0K2 {TARSKIK1 x} =HIDDENR1 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\/XBOOLE-0K2 A .FUNCT-1K1 n"
        using A8 xboole_1_th_39 sorry
      also have "... = A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        using A4 xboole_1_th_12 sorry
      finally show "A .FUNCT-1K1 n \\/XBOOLE-0K2 {TARSKIK1 x} =HIDDENR1 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      then have "A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 x} =HIDDENR1 (A .FUNCT-1K1 n \\SUBSET-1K6 {TARSKIK1 x})\\/XBOOLE-0K2 ({TARSKIK1 x} \\SUBSET-1K6 {TARSKIK1 x})"
        using xboole_1_th_42 sorry
      also have "... = (A .FUNCT-1K1 n \\SUBSET-1K6 {TARSKIK1 x})\\/XBOOLE-0K2 {}XBOOLE-0K1"
        using xboole_1_th_37 sorry
      also have "... = A .FUNCT-1K1 n"
        using A9 zfmisc_1_th_57 sorry
      finally show "A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 x} =HIDDENR1 A .FUNCT-1K1 n"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rearran1_def_4 ("Co-GenREARRAN1K2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "A be RearrangmentGenREARRAN1M1-of D"
"func Co-GenREARRAN1K2\<^bsub>(D)\<^esub> A \<rightarrow> RearrangmentGenREARRAN1M1-of D means
  \<lambda>it.  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
proof-
  (*existence*)
    show " ex it be RearrangmentGenREARRAN1M1-of D st  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
    proof-
      have " ex tVar7 be RearrangmentGenREARRAN1M1-of D st  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 tVar7 -XCMPLX-0K6 \<one>\<^sub>M implies tVar7 .FUNCT-1K1 m =HIDDENR1 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
      proof-
        let ?F = "\<lambda>Lamb1. D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 Lamb1)"
        let ?c = "cardCARD-1K4 D"
        have "D c=TARSKIR1 D"
           sorry
        then obtain y where 
          [ty]:"y be SubsetSUBSET-1M2-of D" and yDef:"y = D"
           sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ?c"
          using nat_1_th_13 sorry
        then have "maxXXREAL-0K5(0NUMBERSK6,?c -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 ?c -XCMPLX-0K6 \<one>\<^sub>M"
          using finseq_2_th_4 sorry
        then obtain c1 where 
          [ty]:"c1 be ElementSUBSET-1M1-of NATNUMBERSK1" and c1Def:"c1 = ?c -XCMPLX-0K6 \<one>\<^sub>M"
          using finseq_2_th_5 sorry
        obtain f where
          [ty]:"f be FinSequenceFINSEQ-1M1" and 
          A1: "lenFINSEQ-1K4 f =XBOOLE-0R4 c1"and A2: " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 m =XBOOLE-0R4 ?F(m)"
          using finseq_1_sch_2 sorry
        have A3: "domFINSEQ-1K5 f =MEMBEREDR12 SegFINSEQ-1K2 c1"
          using A1 finseq_1_def_3 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 boolZFMISC-1K1 D"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 boolZFMISC-1K1 D"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A4: "m inTARSKIR2 domFINSEQ-1K5 f & f .FUNCT-1K1 m =HIDDENR1 x"
              using finseq_2_th_10 sorry
            have "D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m) c=TARSKIR1 D"
               sorry
            then have "x be SubsetSUBSET-1M2-of D"
              using A2 A4 sorry
            thus "x inHIDDENR3 boolZFMISC-1K1 D"
               sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 boolZFMISC-1K1 D"
            using tarski_def_3 sorry
        qed
        then have 
          [ty]:"f be FinSequenceFINSEQ-1M3-of boolZFMISC-1K1 D"
          using finseq_1_def_4 sorry
        let ?C = "f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)"
        have A5: "lenFINSEQ-1K4 ?C =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)"
          using finseq_1_th_22 sorry
        also have "... = lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
          using finseq_1_th_39 sorry
        finally have "lenFINSEQ-1K4 ?C =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
           sorry
        have A6: "cardCARD-1K4 D =XBOOLE-0R4 lenFINSEQ-1K4 A"
          using rearran1_th_1 sorry
        have A7: "?C be terms've-same-card-as-numberREARRAN1V1"
        proof-
          have "f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>) be terms've-same-card-as-numberREARRAN1V1"
          proof-
            have " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)) implies ( for B be finiteFINSET-1V1\<bar>setHIDDENM2 holds B =XBOOLE-0R4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 m implies cardCARD-1K4 B =XBOOLE-0R4 m)"
            proof(rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume A8: "\<one>\<^sub>M <=XXREAL-0R1 m"
                and A9: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?C"
              have "maxXXREAL-0K5(0NUMBERSK6,lenFINSEQ-1K4 ?C -XCMPLX-0K6 m) =HIDDENR1 lenFINSEQ-1K4 ?C -XCMPLX-0K6 m"
                using A9 finseq_2_th_4 sorry
              then obtain l where 
                [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = lenFINSEQ-1K4 ?C -XCMPLX-0K6 m"
                using finseq_2_th_5 sorry
              fix B assume [ty]: "B be finiteFINSET-1V1\<bar>setHIDDENM2"
              assume A10: "B =XBOOLE-0R4 ?C .FUNCT-1K1 m"
              have "m =XBOOLE-0R4 lenFINSEQ-1K4 ?C & cardCARD-1K4 B =XBOOLE-0R4 m or m <>HIDDENR2 lenFINSEQ-1K4 ?C & (m <>HIDDENR2 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)) implies cardCARD-1K4 B =HIDDENR1 m)"
              proof-
                show "m =XBOOLE-0R4 lenFINSEQ-1K4 ?C & cardCARD-1K4 B =XBOOLE-0R4 m or m <>HIDDENR2 lenFINSEQ-1K4 ?C & (m <>HIDDENR2 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)) implies cardCARD-1K4 B =HIDDENR1 m)"
                proof-
                  have cases: "m =XBOOLE-0R4 lenFINSEQ-1K4 ?C or m <>HIDDENR2 lenFINSEQ-1K4 ?C"
                     sorry
                  have case1: "m =XBOOLE-0R4 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)) implies cardCARD-1K4 B =XBOOLE-0R4 m"
                  proof(rule impI)
                    assume "m =XBOOLE-0R4 lenFINSEQ-1K4 ?C"
                    thus "cardCARD-1K4 B =XBOOLE-0R4 m"
                      using A1 A5 A10 finseq_1_th_42 sorry
                  qed
                  have case2: "m <>HIDDENR2 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)) implies cardCARD-1K4 B =HIDDENR1 m"
                  proof(rule impI)
                    assume "m <>HIDDENR2 lenFINSEQ-1K4 ?C"
                    then have "m <XXREAL-0R3 lenFINSEQ-1K4 ?C"
                      using A9 xxreal_0_th_1 sorry
                    then have A11: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?C"
                      using nat_1_th_13 sorry
                    then have A12: "\<one>\<^sub>M <=XXREAL-0R1 l"
                      using xreal_1_th_19 sorry
                    have A13: "l <=XXREAL-0R1 lenFINSEQ-1K4 A"
                      using A6 A1 A5 xreal_1_th_43 sorry
                    then have A14: "l inTARSKIR2 domFINSEQ-1K5 A"
                      using A12 finseq_3_th_25 sorry
                    then obtain Al where 
                      [ty]:"Al be finiteFINSET-1V1\<bar>setHIDDENM2" and AlDef:"Al = A .FUNCT-1K1 l"
                      using rearran1_lm_5 finset_1_th_1 sorry
                    have "m <=XXREAL-0R1 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M"
                      using A11 xreal_1_th_19 sorry
                    then have A15: "m inTARSKIR2 domFINSEQ-1K5 f"
                      using A5 A8 finseq_3_th_25 sorry
                    then have "?C .FUNCT-1K1 m =HIDDENR1 f .FUNCT-1K1 m"
                      using finseq_1_def_7 sorry
                    also have "... = D \\SUBSET-1K6 A .FUNCT-1K1 l"
                      using A6 A1 A2 A5 A15 sorry
                    finally have "?C .FUNCT-1K1 m =HIDDENR1 D \\SUBSET-1K6 A .FUNCT-1K1 l"
                       sorry
                    then have "cardCARD-1K4 B =HIDDENR1 cardCARD-1K4 D -XCMPLX-0K6 cardCARD-1K4 Al"
                      using A10 A14 rearran1_lm_5 card_2_th_44 sorry
                    also have "... = lenFINSEQ-1K4 A -XCMPLX-0K6 l"
                      using A6 A12 A13 rearran1_def_1 sorry
                    also have "... = m"
                      using A6 A1 A5 sorry
                    finally show "cardCARD-1K4 B =HIDDENR1 m"
                       sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "cardCARD-1K4 B =XBOOLE-0R4 m"
                 sorry
            qed "sorry"
            thus "f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>) be terms've-same-card-as-numberREARRAN1V1"
              using rearran1_def_1 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M implies ?C .FUNCT-1K1 m c=TARSKIR1 ?C .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M implies (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 m c=TARSKIR1 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule impMI ,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A16: "\<one>\<^sub>M <=XXREAL-0R1 m"
              and A17: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M"
            have A18: "m inTARSKIR2 domFINSEQ-1K5 f"
              using A5 A16 A17 finseq_3_th_25 sorry
            then have A19: "?C .FUNCT-1K1 m =HIDDENR1 f .FUNCT-1K1 m"
              using finseq_1_def_7 sorry
            also have "... = D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
              using A2 A18 sorry
            finally have "?C .FUNCT-1K1 m =HIDDENR1 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
               sorry
            show "(f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 m c=TARSKIR1 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have cases: "m =XBOOLE-0R4 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M or m <>HIDDENR2 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M"
                 sorry
              have case1: "m =XBOOLE-0R4 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)) -XCMPLX-0K6 \<one>\<^sub>M implies (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 m c=TARSKIR1 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume "m =XBOOLE-0R4 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M"
                then have "?C .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 D"
                  using A5 finseq_1_th_42 sorry
                thus "(f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 m c=TARSKIR1 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                  using A19 sorry
              qed
              have case2: "m <>HIDDENR2 lenFINSEQ-1K4 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)) -XCMPLX-0K6 \<one>\<^sub>M implies (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 m c=TARSKIR1 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume "m <>HIDDENR2 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M"
                then have A20: "m <XXREAL-0R3 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M"
                  using A17 xxreal_0_th_1 sorry
                then have A21: "m +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 A"
                  using A6 A1 A5 xreal_1_th_20 sorry
                then have "maxXXREAL-0K5(0NUMBERSK6,lenFINSEQ-1K4 A -XCMPLX-0K6 (m +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 lenFINSEQ-1K4 A -XCMPLX-0K6 (m +NAT-1K1 \<one>\<^sub>M)"
                  using finseq_2_th_4 sorry
                then obtain l where 
                  [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = lenFINSEQ-1K4 A -XCMPLX-0K6 (m +NAT-1K1 \<one>\<^sub>M)"
                  using finseq_2_th_5 sorry
                have A22: "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
                  using nat_1_th_11 sorry
                have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?C -XCMPLX-0K6 \<one>\<^sub>M"
                  using A5 A20 nat_1_th_13 sorry
                then have A23: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                  using A5 A22 finseq_3_th_25 sorry
                then have A24: "?C .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                  using finseq_1_def_7 sorry
                also have "... = D \\SUBSET-1K6 A .FUNCT-1K1 l"
                  using A2 A23 sorry
                finally have "?C .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 D \\SUBSET-1K6 A .FUNCT-1K1 l"
                   sorry
                have "(m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
                  using A21 nat_1_th_13 sorry
                then have A25: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 (m +NAT-1K1 \<one>\<^sub>M)"
                  using xreal_1_th_19 sorry
                have "l <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
                  using A22 xreal_1_th_13 sorry
                then have "A .FUNCT-1K1 l c=TARSKIR1 A .FUNCT-1K1 (l +NAT-1K1 \<one>\<^sub>M)"
                  using A25 rearran1_def_2 sorry
                thus "(f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 m c=TARSKIR1 (f ^FINSEQ-1K9\<^bsub>(boolZFMISC-1K1 D)\<^esub> (<*FINSEQ-1K13\<^bsub>(boolZFMISC-1K1 D)\<^esub> y*>)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                  using A19 A24 xboole_1_th_34 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then obtain C where 
          [ty]:"C be RearrangmentGenREARRAN1M1-of D" and CDef:"C = ?C"
          using A1 A5 A7 rearran1_def_2 rearran1_th_1 sorry
        show " ex tVar7 be RearrangmentGenREARRAN1M1-of D st  for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 tVar7 -XCMPLX-0K6 \<one>\<^sub>M implies tVar7 .FUNCT-1K1 m =HIDDENR1 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
        proof(rule bexI[of _ "C"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 C -XCMPLX-0K6 \<one>\<^sub>M"
          then have A26: "m inTARSKIR2 SegFINSEQ-1K2 c1"
            using A1 A5 finseq_1_th_1 sorry
          then have "m inTARSKIR2 domFINSEQ-1K5 f"
            using A1 finseq_1_def_3 sorry
          then have "C .FUNCT-1K1 m =HIDDENR1 f .FUNCT-1K1 m"
            using finseq_1_def_7 sorry
          also have "... = D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
            using A2 A3 A26 sorry
          finally show "C .FUNCT-1K1 m =HIDDENR1 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RearrangmentGenREARRAN1M1-of D holds  for it2 be RearrangmentGenREARRAN1M1-of D holds ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it1 -XCMPLX-0K6 \<one>\<^sub>M implies it1 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) & ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it2 -XCMPLX-0K6 \<one>\<^sub>M implies it2 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be RearrangmentGenREARRAN1M1-of D holds  for f2 be RearrangmentGenREARRAN1M1-of D holds ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 f1 -XCMPLX-0K6 \<one>\<^sub>M implies f1 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) & ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 f2 -XCMPLX-0K6 \<one>\<^sub>M implies f2 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be RearrangmentGenREARRAN1M1-of D"
        fix f2 assume [ty]: "f2 be RearrangmentGenREARRAN1M1-of D"
        assume A27: " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 f1 -XCMPLX-0K6 \<one>\<^sub>M implies f1 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
          and A28: " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 f2 -XCMPLX-0K6 \<one>\<^sub>M implies f2 .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
        have A29: "lenFINSEQ-1K4 f2 =XBOOLE-0R4 cardCARD-1K4 D"
          using rearran1_th_1 sorry
        have A30: "lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
          using rearran1_th_1 sorry
        have A31: "lenFINSEQ-1K4 f1 =XBOOLE-0R4 cardCARD-1K4 D"
          using rearran1_th_1 sorry
        then have A32: "domFINSEQ-1K5 f1 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 A)"
          using A30 finseq_1_def_3 sorry
        have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 f1 implies f1 .FUNCT-1K1 m =XBOOLE-0R4 f2 .FUNCT-1K1 m"
        proof(rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          obtain m1 where 
            [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = m"
            using ordinal1_def_12 sorry
          assume A33: "m inTARSKIR2 domFINSEQ-1K5 f1"
          then have A34: "\<one>\<^sub>M <=XXREAL-0R1 m"
            using A32 finseq_1_th_1 sorry
          have A35: "m <=XXREAL-0R1 lenFINSEQ-1K4 A"
            using A32 A33 finseq_1_th_1 sorry
          show "f1 .FUNCT-1K1 m =XBOOLE-0R4 f2 .FUNCT-1K1 m"
          proof-
            have cases: "m =XBOOLE-0R4 lenFINSEQ-1K4 A or m <>HIDDENR2 lenFINSEQ-1K4 A"
               sorry
            have case1: "m =XBOOLE-0R4 lenFINSEQ-1K4 A implies f1 .FUNCT-1K1 m =XBOOLE-0R4 f2 .FUNCT-1K1 m"
            proof(rule impI)
              assume A36: "m =XBOOLE-0R4 lenFINSEQ-1K4 A"
              then have "f1 .FUNCT-1K1 m =XBOOLE-0R4 D"
                using A31 A30 rearran1_th_3 sorry
              thus "f1 .FUNCT-1K1 m =XBOOLE-0R4 f2 .FUNCT-1K1 m"
                using A29 A30 A36 rearran1_th_3 sorry
            qed
            have case2: "m <>HIDDENR2 lenFINSEQ-1K4 A implies f1 .FUNCT-1K1 m =XBOOLE-0R4 f2 .FUNCT-1K1 m"
            proof(rule impI)
              assume "m <>HIDDENR2 lenFINSEQ-1K4 A"
              then have "m <XXREAL-0R3 lenFINSEQ-1K4 A"
                using A35 xxreal_0_th_1 sorry
              then have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
                using nat_1_th_13 sorry
              then have A37: "m <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_19 sorry
              then have "f1 .FUNCT-1K1 m1 =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m1)"
                using A27 A31 A30 A34 sorry
              thus "f1 .FUNCT-1K1 m =XBOOLE-0R4 f2 .FUNCT-1K1 m"
                using A28 A29 A30 A34 A37 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A31 A29 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem REARRAN1K2_involutiveness:
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
" for A be RearrangmentGenREARRAN1M1-of D holds Co-GenREARRAN1K2\<^bsub>(D)\<^esub> (Co-GenREARRAN1K2\<^bsub>(D)\<^esub> A) =HIDDENR1 A"
proof-
  have " for it be RearrangmentGenREARRAN1M1-of D holds  for A be RearrangmentGenREARRAN1M1-of D holds it =HIDDENR1 Co-GenREARRAN1K2\<^bsub>(D)\<^esub> A implies A =HIDDENR1 Co-GenREARRAN1K2\<^bsub>(D)\<^esub> it"
  proof-
    have " for it be RearrangmentGenREARRAN1M1-of D holds  for A be RearrangmentGenREARRAN1M1-of D holds ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 it -XCMPLX-0K6 \<one>\<^sub>M implies it .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) implies ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M implies A .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 it .FUNCT-1K1 (lenFINSEQ-1K4 it -XCMPLX-0K6 m))"
    proof-
      have " for B be RearrangmentGenREARRAN1M1-of D holds  for A be RearrangmentGenREARRAN1M1-of D holds ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 B -XCMPLX-0K6 \<one>\<^sub>M implies B .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)) implies ( for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M implies A .FUNCT-1K1 m =HIDDENR1 D \\SUBSET-1K6 B .FUNCT-1K1 (lenFINSEQ-1K4 B -XCMPLX-0K6 m))"
      proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
        fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of D"
        fix A assume [ty]: "A be RearrangmentGenREARRAN1M1-of D"
        assume A38: " for m be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 B -XCMPLX-0K6 \<one>\<^sub>M implies B .FUNCT-1K1 m =XBOOLE-0R4 D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 m)"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A39: "\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M"
        have A40: "lenFINSEQ-1K4 A =XBOOLE-0R4 cardCARD-1K4 D"
          using rearran1_th_1 sorry
        have A41: "lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 D"
          using rearran1_th_1 sorry
        have "lenFINSEQ-1K4 A -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 lenFINSEQ-1K4 A"
          using xreal_1_th_44 sorry
        then have A42: "m <XXREAL-0R3 lenFINSEQ-1K4 A"
          using A39 xxreal_0_th_2 sorry
        then have "lenFINSEQ-1K4 A -XCMPLX-0K6 m inTARSKIR2 NATNUMBERSK1"
          using int_1_th_5 sorry
        then obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = lenFINSEQ-1K4 B -XCMPLX-0K6 m"
          using A40 A41 sorry
        have A43: "lenFINSEQ-1K4 A -XCMPLX-0K6 n =XBOOLE-0R4 m"
          using A40 A41 sorry
        have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
          using A39 xreal_1_th_19 sorry
        then have A44: "\<one>\<^sub>M <=XXREAL-0R1 n"
          using A40 A41 xreal_1_th_19 sorry
        have A45: "n <=XXREAL-0R1 lenFINSEQ-1K4 B -XCMPLX-0K6 \<one>\<^sub>M"
          using A39 xreal_1_th_10 sorry
        have "lenFINSEQ-1K4 A -XCMPLX-0K6 n inTARSKIR2 domFINSEQ-1K5 A"
          using A43 A39 A42 finseq_3_th_25 sorry
        then have A46: "A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 n) c=TARSKIR1 D"
          using rearran1_lm_5 sorry
        have "A .FUNCT-1K1 m =HIDDENR1 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 n)"
          using A40 A41 sorry
        also have "... = D /\\XBOOLE-0K3 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 n)"
          using A46 xboole_1_th_28 sorry
        also have "... = D \\SUBSET-1K6 (D \\SUBSET-1K6 A .FUNCT-1K1 (lenFINSEQ-1K4 A -XCMPLX-0K6 n))"
          using xboole_1_th_48 sorry
        also have "... = D \\SUBSET-1K6 B .FUNCT-1K1 (lenFINSEQ-1K4 B -XCMPLX-0K6 m)"
          using A44 A45 A38 sorry
        finally show "A .FUNCT-1K1 m =HIDDENR1 D \\SUBSET-1K6 B .FUNCT-1K1 (lenFINSEQ-1K4 B -XCMPLX-0K6 m)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using rearran1_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem rearran1_th_12:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) =XBOOLE-0R4 lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C)) =HIDDENR1 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix A assume [ty]: "A be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    let ?a = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    obtain a9 where 
      [ty]:"a9 be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and a9Def:"a9 = ?a"
       sorry
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then obtain F9 where 
      [ty]:"F9 be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and F9Def:"F9 = F"
      using finset_1_th_10 sorry
    obtain da9 dF9 where 
      [ty]:"da9 be finiteFINSET-1V1\<bar>setHIDDENM2" and da9Def:"da9 = domRELAT-1K1 a9" and
      [ty]:"dF9 be finiteFINSET-1V1\<bar>setHIDDENM2" and dF9Def:"dF9 = domRELAT-1K1 F9"
       sorry
    have A4: "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using A3 relat_1_th_68 sorry
    have "D =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> D"
      using A3 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D)"
      using relat_1_th_61 sorry
    finally have "D =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D)"
       sorry
    then have "(F,FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A4 rfunct_3_def_13 sorry
    then have A5: "domFINSEQ-1K5 ?a =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?a) & cardCARD-1K4 da9 =XBOOLE-0R4 cardCARD-1K4 dF9"
      using classes1_th_81 finseq_1_def_3 sorry
    have "lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C)) =HIDDENR1 lenFINSEQ-1K4 A"
      using rfunct_3_def_6 sorry
    also have "... = cardCARD-1K4 C"
      using rearran1_th_1 sorry
    also have "... = lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using A2 A3 A5 finseq_1_th_57 sorry
    also have "... = lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
      using rfinseq_def_2 sorry
    finally show "lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C)) =HIDDENR1 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rearran1_def_5 ("RlandREARRAN1K3\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "A be RearrangmentGenREARRAN1M1-of C", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) \<rightarrow> PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) equals
  SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))"
proof-
  (*coherence*)
    show "SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C)) be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
       sorry
qed "sorry"

mdef rearran1_def_6 ("RlorREARRAN1K4\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2", "A be RearrangmentGenREARRAN1M1-of C", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) \<rightarrow> PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) equals
  SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A,C))"
proof-
  (*coherence*)
    show "SumRFUNCT-3K14\<^bsub>(C)\<^esub> (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A,C)) be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem rearran1_th_13:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =XBOOLE-0R4 C"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =XBOOLE-0R4 C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix A assume [ty]: "A be RearrangmentGenREARRAN1M1-of C"
    have A1: "lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C)) =XBOOLE-0R4 lenFINSEQ-1K4 A & lenFINSEQ-1K4 A <>HIDDENR2 0NUMBERSK6"
      using rearran1_th_4 rfunct_3_def_6 sorry
    assume "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A2: "lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) =XBOOLE-0R4 lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C))"
      using rearran1_th_12 sorry
    have "domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) c=TARSKIR1 C & C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A)"
    proof(rule conjMI)
      show "domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) c=TARSKIR1 C"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 C implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 C"
        then obtain c where 
          [ty]:"c be ElementSUBSET-1M1-of C" and cDef:"c = x"
           sorry
        have "lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C)) =XBOOLE-0R4 minNAT-1K4(lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)),lenFINSEQ-1K4 (CHIRFUNCT-3K15(A,C))) & c is-common-for-domRFUNCT-3R1\<^bsub>(C,REALNUMBERSK2)\<^esub> MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C)"
          using rfunct_3_th_32 rfunct_3_def_7 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A)"
          using A2 A1 rfunct_3_th_28 sorry
      qed "sorry"
      thus "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A)"
        using tarski_def_3 sorry
    qed
    thus "domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =XBOOLE-0R4 C"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_14:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 A .FUNCT-1K1 \<one>\<^sub>M implies (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) & ( for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 A) & c inTARSKIR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n implies (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 A .FUNCT-1K1 \<one>\<^sub>M implies (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & (n <XXREAL-0R3 lenFINSEQ-1K4 A & c inTARSKIR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n) implies (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix A assume [ty]: "A be RearrangmentGenREARRAN1M1-of C"
    let ?fd = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    let ?mf = "MIMRFINSEQK3 ?fd"
    let ?h = "CHIRFUNCT-3K15(A,C)"
    let ?fh = "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c"
    have A1: "domFINSEQ-1K5 A =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 A)"
      using finseq_1_def_3 sorry
    have A2: "domFINSEQ-1K5 (?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h))"
      using finseq_1_def_3 sorry
    have A3: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 A"
      using rfunct_3_def_6 sorry
    have A4: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?fd"
      using rfinseq_def_2 sorry
    have A5: "domFINSEQ-1K5 ?fh =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fh)"
      using finseq_1_def_3 sorry
    have A6: "minNAT-1K4(lenFINSEQ-1K4 ?mf,lenFINSEQ-1K4 ?h) =XBOOLE-0R4 lenFINSEQ-1K4 (?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)"
      using rfunct_3_def_7 sorry
    assume "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A7: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?h"
      using rearran1_th_12 sorry
    have A8: "lenFINSEQ-1K4 ?fh =XBOOLE-0R4 lenFINSEQ-1K4 (?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)"
      using rfunct_3_def_8 sorry
    have A9: "domFINSEQ-1K5 ?h =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?h)"
      using finseq_1_def_3 sorry
    show "c inTARSKIR2 A .FUNCT-1K1 \<one>\<^sub>M implies (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    proof(rule impI)
      assume A10: "c inTARSKIR2 A .FUNCT-1K1 \<one>\<^sub>M"
      have A11: " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 A implies c inTARSKIR2 A .FUNCT-1K1 n"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A12: "n inTARSKIR2 domFINSEQ-1K5 A"
        then have A13: "\<one>\<^sub>M <=XXREAL-0R1 n"
          using finseq_3_th_25 sorry
        have "n <=XXREAL-0R1 lenFINSEQ-1K4 A"
          using A12 finseq_3_th_25 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
          using A13 xxreal_0_th_2 sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A"
          using finseq_3_th_25 sorry
        then have "A .FUNCT-1K1 \<one>\<^sub>M c=TARSKIR1 A .FUNCT-1K1 n"
          using A12 A13 rearran1_th_2 sorry
        thus "c inTARSKIR2 A .FUNCT-1K1 n"
          using A10 sorry
      qed "sorry"
      have A14: "domFINSEQ-1K5 ((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?mf)"
        using A7 A6 A8 finseq_1_def_3 sorry
      have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        obtain m1 where 
          [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = m"
          using ordinal1_def_12 sorry
        obtain r1 where 
          [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = ?fd .FUNCT-1K1 m"
           sorry
        assume A15: "m inTARSKIR2 domFINSEQ-1K5 ((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c)"
        then have A16: "\<one>\<^sub>M <=XXREAL-0R1 m"
          using finseq_3_th_25 sorry
        have A17: "?h .FUNCT-1K1 m =FUNCT-1R1 chiRFUNCT-1K7(A .FUNCT-1K1 m,C)"
          using A9 A5 A7 A6 A8 A15 rfunct_3_def_6 sorry
        have A18: "c inTARSKIR2 A .FUNCT-1K1 m"
          using A1 A5 A7 A3 A6 A8 A11 A15 sorry
        have "m inTARSKIR2 domFINSEQ-1K5 ?mf"
          using A14 A15 finseq_1_def_3 sorry
        then have A19: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?mf"
          using finseq_3_th_25 sorry
        have "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf & ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m or m <>HIDDENR2 lenFINSEQ-1K4 ?mf & (m <>HIDDENR2 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m1)"
        proof-
          show "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf & ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m or m <>HIDDENR2 lenFINSEQ-1K4 ?mf & (m <>HIDDENR2 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m1)"
          proof-
            have cases: "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf or m <>HIDDENR2 lenFINSEQ-1K4 ?mf"
               sorry
            have case1: "m =XBOOLE-0R4 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m"
            proof(rule impI)
              assume A20: "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf"
              then have "?mf .FUNCT-1K1 m =HIDDENR1 r1"
                using A4 rfinseq_def_2 sorry
              then have "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h).FUNCT-1K1 m =FUNCT-1R1 r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)"
                using A2 A5 A8 A15 A17 rfunct_3_def_7 sorry
              then have A21: "((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 (r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)).FUNCT-1K1 c"
                using A15 rfunct_3_def_8 sorry
              have "domRELSET-1K1\<^bsub>(C)\<^esub> (r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(A .FUNCT-1K1 m,C))"
                using valued_1_def_5 sorry
              also have "... = C"
                using rfunct_1_th_61 sorry
              finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 C"
                 sorry
              then have "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 r1 *XCMPLX-0K3 chiRFUNCT-1K7(A .FUNCT-1K1 m,C) .FUNCT-1K1 c"
                using A21 valued_1_def_5 sorry
              also have "... = r1 *XCMPLX-0K3 \<one>\<^sub>M"
                using A18 rfunct_1_th_63 sorry
              also have "... = MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m"
                using A4 A20 rfinseq_def_2 sorry
              finally show "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m"
                 sorry
            qed
            have case2: "m <>HIDDENR2 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m1"
            proof(rule impI)
              assume A22: "m <>HIDDENR2 lenFINSEQ-1K4 ?mf"
              obtain r2 where 
                [ty]:"r2 be RealXREAL-0M1" and r2Def:"r2 = ?fd .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have "m <XXREAL-0R3 lenFINSEQ-1K4 ?mf"
                using A19 A22 xxreal_0_th_1 sorry
              then have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?mf"
                using nat_1_th_13 sorry
              then have A23: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?mf -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_19 sorry
              then have "?mf .FUNCT-1K1 m1 =XBOOLE-0R4 r1 -XCMPLX-0K6 r2"
                using A16 rfinseq_def_2 sorry
              then have "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h).FUNCT-1K1 m =FUNCT-1R1 (r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)"
                using A2 A5 A8 A15 A17 rfunct_3_def_7 sorry
              then have A24: "((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)).FUNCT-1K1 c"
                using A15 rfunct_3_def_8 sorry
              have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(A .FUNCT-1K1 m,C))"
                using valued_1_def_5 sorry
              also have "... = C"
                using rfunct_1_th_61 sorry
              finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 C"
                 sorry
              then have "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 (r1 -XCMPLX-0K6 r2)*XCMPLX-0K3 chiRFUNCT-1K7(A .FUNCT-1K1 m,C) .FUNCT-1K1 c"
                using A24 valued_1_def_5 sorry
              also have "... = (r1 -XCMPLX-0K6 r2)*XCMPLX-0K3 \<one>\<^sub>M"
                using A18 rfunct_1_th_63 sorry
              also have "... = MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m1"
                using A16 A23 rfinseq_def_2 sorry
              finally show "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m1"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 m"
           sorry
      qed "sorry"
      thus "(MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
        using A7 A6 A8 finseq_2_th_9 sorry
    qed
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A25: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A26: "n <XXREAL-0R3 lenFINSEQ-1K4 A"
      and A27: "c inTARSKIR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n"
    have A28: "lenFINSEQ-1K4 (?mf /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n) =XBOOLE-0R4 lenFINSEQ-1K4 ?mf -XCMPLX-0K6 n"
      using A7 A3 A26 rfinseq_def_1 sorry
    have A29: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 A & k <=XXREAL-0R1 n implies  not c inTARSKIR2 A .FUNCT-1K1 k"
    proof-
      have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 A & k <=XXREAL-0R1 n implies (c inTARSKIR2 A .FUNCT-1K1 k implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A30: "k inTARSKIR2 domFINSEQ-1K5 A & k <=XXREAL-0R1 n"
        assume A31: "c inTARSKIR2 A .FUNCT-1K1 k"
        have "n inTARSKIR2 domFINSEQ-1K5 A"
          using A25 A26 finseq_3_th_25 sorry
        then have "A .FUNCT-1K1 k c=TARSKIR1 A .FUNCT-1K1 n"
          using A30 rearran1_th_2 sorry
        thus " False "
          using A27 A31 xboole_0_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A32: "c inTARSKIR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A27 sorry
    have A33: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
      using A26 nat_1_th_13 sorry
    have A34: "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using A25 nat_1_th_13 sorry
    have A35: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 A & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k implies c inTARSKIR2 A .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A36: "k inTARSKIR2 domFINSEQ-1K5 A & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
      have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 A"
        using A33 A34 finseq_3_th_25 sorry
      then have "A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) c=TARSKIR1 A .FUNCT-1K1 k"
        using A36 rearran1_th_2 sorry
      thus "c inTARSKIR2 A .FUNCT-1K1 k"
        using A32 sorry
    qed "sorry"
    let ?fdn = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n"
    let ?mfn = "MIMRFINSEQK3 ?fdn"
    let ?n0 = "n  |->FINSEQ-2K2 (0NUMBERSK6)"
    have A37: "lenFINSEQ-1K4 ?mfn =XBOOLE-0R4 lenFINSEQ-1K4 ?fdn"
      using rfinseq_def_2 sorry
    have A38: "lenFINSEQ-1K4 ?n0 =XBOOLE-0R4 n"
      using card_1_def_7 sorry
    have "lenFINSEQ-1K4 ?fdn =XBOOLE-0R4 lenFINSEQ-1K4 ?fd -XCMPLX-0K6 n"
      using A7 A3 A4 A26 rfinseq_def_1 sorry
    then have A39: "lenFINSEQ-1K4 (?n0 ^FINSEQ-1K8 ?mfn) =HIDDENR1 n +XCMPLX-0K2 (lenFINSEQ-1K4 ?fd -XCMPLX-0K6 n)"
      using A37 A38 finseq_1_th_22 sorry
    also have "... = lenFINSEQ-1K4 ?mf"
      using rfinseq_def_2 sorry
    finally have "lenFINSEQ-1K4 (?n0 ^FINSEQ-1K8 ?mfn) =HIDDENR1 lenFINSEQ-1K4 ?mf"
       sorry
    then have A40: "domFINSEQ-1K5 (?n0 ^FINSEQ-1K8 ?mfn) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?mf)"
      using finseq_1_def_3 sorry
    have A41: "domFINSEQ-1K5 ?n0 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?n0)"
      using finseq_1_def_3 sorry
    have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      obtain m1 where 
        [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = m"
        using ordinal1_def_12 sorry
      obtain r1 where 
        [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = ?fd .FUNCT-1K1 m"
         sorry
      assume A42: "m inTARSKIR2 domFINSEQ-1K5 (?n0 ^FINSEQ-1K8 ?mfn)"
      then have A43: "\<one>\<^sub>M <=XXREAL-0R1 m"
        using finseq_3_th_25 sorry
      have "m inTARSKIR2 domFINSEQ-1K5 ?mf"
        using A40 A42 finseq_1_def_3 sorry
      then have A44: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?mf"
        using finseq_3_th_25 sorry
      have A45: "?h .FUNCT-1K1 m =FUNCT-1R1 chiRFUNCT-1K7(A .FUNCT-1K1 m,C)"
        using A9 A7 A40 A42 rfunct_3_def_6 sorry
      have "m <=XXREAL-0R1 n & ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m or n <XXREAL-0R3 m & (n <XXREAL-0R3 m implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m)"
      proof-
        show "m <=XXREAL-0R1 n & ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m or n <XXREAL-0R3 m & (n <XXREAL-0R3 m implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m)"
        proof-
          have cases: "m <=XXREAL-0R1 n or n <XXREAL-0R3 m"
             sorry
          have case1: "m <=XXREAL-0R1 n implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
          proof(rule impI)
            assume A46: "m <=XXREAL-0R1 n"
            obtain r2 where 
              [ty]:"r2 be RealXREAL-0M1" and r2Def:"r2 = ?fd .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
               sorry
            have "m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              using A46 nat_1_th_13 sorry
            then have "m <XXREAL-0R3 lenFINSEQ-1K4 A"
              using A33 xxreal_0_th_2 sorry
            then have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 A"
              using nat_1_th_13 sorry
            then have "m <=XXREAL-0R1 lenFINSEQ-1K4 ?mf -XCMPLX-0K6 \<one>\<^sub>M"
              using A7 A3 xreal_1_th_19 sorry
            then have "?mf .FUNCT-1K1 m1 =XBOOLE-0R4 r1 -XCMPLX-0K6 r2"
              using A43 rfinseq_def_2 sorry
            then have "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h).FUNCT-1K1 m =FUNCT-1R1 (r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)"
              using A2 A7 A6 A40 A42 A45 rfunct_3_def_7 sorry
            then have A47: "((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)).FUNCT-1K1 c"
              using A5 A7 A6 A8 A40 A42 rfunct_3_def_8 sorry
            have " not c inTARSKIR2 A .FUNCT-1K1 m"
              using A1 A7 A3 A29 A40 A42 A46 sorry
            then have A48: "chiRFUNCT-1K7(A .FUNCT-1K1 m,C) .FUNCT-1K1 c =XBOOLE-0R4 0NUMBERSK6"
              using rfunct_1_th_64 sorry
            have A49: "m inTARSKIR2 SegFINSEQ-1K2 n"
              using A43 A46 finseq_1_th_1 sorry
            have A50: "?n0 .FUNCT-1K1 m =XBOOLE-0R4 0NUMBERSK6"
               sorry
            have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(A .FUNCT-1K1 m,C))"
              using valued_1_def_5 sorry
            also have "... = C"
              using rfunct_1_th_61 sorry
            finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 C"
               sorry
            then have "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 (r1 -XCMPLX-0K6 r2)*XCMPLX-0K3 chiRFUNCT-1K7(A .FUNCT-1K1 m,C) .FUNCT-1K1 c"
              using A47 valued_1_def_5 sorry
            also have "... = ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
              using A38 A41 A48 A49 A50 finseq_1_def_7 sorry
            finally show "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
               sorry
          qed
          have case2: "n <XXREAL-0R3 m implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
          proof(rule impI)
            assume A51: "n <XXREAL-0R3 m"
            then have "maxXXREAL-0K5(0NUMBERSK6,m -XCMPLX-0K6 n) =HIDDENR1 m -XCMPLX-0K6 n"
              using finseq_2_th_4 sorry
            then obtain mn where 
              [ty]:"mn be ElementSUBSET-1M1-of NATNUMBERSK1" and mnDef:"mn = m -XCMPLX-0K6 n"
              using finseq_2_th_5 sorry
            have A52: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
              using A51 nat_1_th_13 sorry
            then have "c inTARSKIR2 A .FUNCT-1K1 m"
              using A1 A7 A3 A35 A40 A42 sorry
            then have A53: "chiRFUNCT-1K7(A .FUNCT-1K1 m,C) .FUNCT-1K1 c =XBOOLE-0R4 \<one>\<^sub>M"
              using rfunct_1_th_63 sorry
            have A54: "\<one>\<^sub>M <=XXREAL-0R1 mn"
              using A52 xreal_1_th_19 sorry
            have "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf & ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m or m <>HIDDENR2 lenFINSEQ-1K4 ?mf & (m <>HIDDENR2 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m)"
            proof-
              show "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf & ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m or m <>HIDDENR2 lenFINSEQ-1K4 ?mf & (m <>HIDDENR2 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m)"
              proof-
                have cases: "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf or m <>HIDDENR2 lenFINSEQ-1K4 ?mf"
                   sorry
                have case1: "m =XBOOLE-0R4 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
                proof(rule impI)
                  assume A55: "m =XBOOLE-0R4 lenFINSEQ-1K4 ?mf"
                  then have "?mf .FUNCT-1K1 m =HIDDENR1 r1"
                    using A4 rfinseq_def_2 sorry
                  then have "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h).FUNCT-1K1 m =FUNCT-1R1 r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)"
                    using A2 A7 A6 A40 A42 A45 rfunct_3_def_7 sorry
                  then have A56: "((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 (r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)).FUNCT-1K1 c"
                    using A5 A7 A6 A8 A40 A42 rfunct_3_def_8 sorry
                  have A57: "mn inTARSKIR2 domFINSEQ-1K5 (?mf /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)"
                    using A28 A54 A55 finseq_3_th_25 sorry
                  have A58: "(?n0 ^FINSEQ-1K8 ?mfn).FUNCT-1K1 m =HIDDENR1 ?mfn .FUNCT-1K1 (m -XCMPLX-0K6 n)"
                    using A38 A39 A44 A51 finseq_1_th_24 sorry
                  also have "... = (?mf /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-1K1 mn"
                    using rfinseq_th_15 sorry
                  also have "... = ?mf .FUNCT-1K1 (mn +XCMPLX-0K2 n)"
                    using A7 A3 A26 A57 rfinseq_def_1 sorry
                  also have "... = r1"
                    using A4 A55 rfinseq_def_2 sorry
                  finally have "(?n0 ^FINSEQ-1K8 ?mfn).FUNCT-1K1 m =HIDDENR1 r1"
                     sorry
                  have "domRELSET-1K1\<^bsub>(C)\<^esub> (r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(A .FUNCT-1K1 m,C))"
                    using valued_1_def_5 sorry
                  also have "... = C"
                    using rfunct_1_th_61 sorry
                  finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r1 (#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 C"
                     sorry
                  then have "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 r1 *XCMPLX-0K3 chiRFUNCT-1K7(A .FUNCT-1K1 m,C) .FUNCT-1K1 c"
                    using A56 valued_1_def_5 sorry
                  also have "... = ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
                    using A53 A58 sorry
                  finally show "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
                     sorry
                qed
                have case2: "m <>HIDDENR2 lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) implies ((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
                proof(rule impI)
                  assume A59: "m <>HIDDENR2 lenFINSEQ-1K4 ?mf"
                  obtain r2 where 
                    [ty]:"r2 be RealXREAL-0M1" and r2Def:"r2 = ?fd .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                     sorry
                  have "m <XXREAL-0R3 lenFINSEQ-1K4 ?mf"
                    using A44 A59 xxreal_0_th_1 sorry
                  then have "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?mf"
                    using nat_1_th_13 sorry
                  then have A60: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?mf -XCMPLX-0K6 \<one>\<^sub>M"
                    using xreal_1_th_19 sorry
                  then have "?mf .FUNCT-1K1 m1 =XBOOLE-0R4 r1 -XCMPLX-0K6 r2"
                    using A43 rfinseq_def_2 sorry
                  then have "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h).FUNCT-1K1 m =FUNCT-1R1 (r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)"
                    using A2 A7 A6 A40 A42 A45 rfunct_3_def_7 sorry
                  then have A61: "((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)).FUNCT-1K1 c"
                    using A5 A7 A6 A8 A40 A42 rfunct_3_def_8 sorry
                  have "mn <=XXREAL-0R1 lenFINSEQ-1K4 (?mf /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)"
                    using A28 A44 xreal_1_th_9 sorry
                  then have A62: "mn inTARSKIR2 domFINSEQ-1K5 (?mf /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)"
                    using A54 finseq_3_th_25 sorry
                  have A63: "(?n0 ^FINSEQ-1K8 ?mfn).FUNCT-1K1 m =HIDDENR1 ?mfn .FUNCT-1K1 (m -XCMPLX-0K6 n)"
                    using A38 A39 A44 A51 finseq_1_th_24 sorry
                  also have "... = (?mf /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-1K1 mn"
                    using rfinseq_th_15 sorry
                  also have "... = ?mf .FUNCT-1K1 (mn +XCMPLX-0K2 n)"
                    using A7 A3 A26 A62 rfinseq_def_1 sorry
                  also have "... = r1 -XCMPLX-0K6 r2"
                    using A43 A60 rfinseq_def_2 sorry
                  finally have "(?n0 ^FINSEQ-1K8 ?mfn).FUNCT-1K1 m =HIDDENR1 r1 -XCMPLX-0K6 r2"
                     sorry
                  have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(A .FUNCT-1K1 m,C))"
                    using valued_1_def_5 sorry
                  also have "... = C"
                    using rfunct_1_th_61 sorry
                  finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ((r1 -XCMPLX-0K6 r2)(#)REARRAN1K1\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(A .FUNCT-1K1 m,C)) =HIDDENR1 C"
                     sorry
                  then have "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 (r1 -XCMPLX-0K6 r2)*XCMPLX-0K3 chiRFUNCT-1K7(A .FUNCT-1K1 m,C) .FUNCT-1K1 c"
                    using A61 valued_1_def_5 sorry
                  also have "... = ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
                    using A53 A63 sorry
                  finally show "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =HIDDENR1 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "((MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c).FUNCT-1K1 m =XBOOLE-0R4 ((n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
         sorry
    qed "sorry"
    thus "(MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(A,C))#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using A7 A6 A8 A39 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_15:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 A .FUNCT-1K1 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 A) & c inTARSKIR2 A .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 A .FUNCT-1K1 n implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 B .FUNCT-1K1 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & (n <XXREAL-0R3 lenFINSEQ-1K4 B & c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n) implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    let ?fd = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    let ?mf = "MIMRFINSEQK3 ?fd"
    let ?h = "CHIRFUNCT-3K15(B,C)"
    have A1: "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 SumRVSUM-1K22 ((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c)"
      using rfunct_3_th_32 rfunct_3_th_33 sorry
    have A2: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 B & lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?fd"
      using rfinseq_def_2 rfunct_3_def_6 sorry
    assume A3: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A4: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?h"
      using rearran1_th_12 sorry
    show "c inTARSKIR2 B .FUNCT-1K1 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
    proof-
      have "c inTARSKIR2 B .FUNCT-1K1 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
      proof(rule impI)
        assume "c inTARSKIR2 B .FUNCT-1K1 \<one>\<^sub>M"
        then have "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 SumRVSUM-1K22 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
          using A3 A1 rearran1_th_14 sorry
        also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
          using A4 A2 rearran1_th_4 rfinseq_th_16 sorry
        finally show "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?mfn = "MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    assume A5: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A6: "n <XXREAL-0R3 lenFINSEQ-1K4 B"
      and A7: "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n"
    have "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 ?mfn"
      using A3 A5 A6 A7 rearran1_th_14 sorry
    then have "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 SumRVSUM-1K22 (n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))) +XCMPLX-0K2 SumRVSUM-1K22 (MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n))"
      using A1 rvsum_1_th_75 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 SumRVSUM-1K22 (MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n))"
      using rvsum_1_th_81 sorry
    also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A4 A2 A6 rfinseq_th_17 sorry
    finally show "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_16:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    let ?fd = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    let ?p = "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
    let ?mf = "MIMRFINSEQK3 ?fd"
    let ?h = "CHIRFUNCT-3K15(B,C)"
    have A3: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?h"
      using A1 A2 rearran1_th_12 sorry
    have A4: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then obtain fd9 F9 where 
      [ty]:"fd9 be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and fd9Def:"fd9 = ?fd" and
      [ty]:"F9 be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and F9Def:"F9 = F"
      using finset_1_th_10 sorry
    obtain dfd dF where 
      [ty]:"dfd be finiteFINSET-1V1\<bar>setHIDDENM2" and dfdDef:"dfd = domRELAT-1K1 fd9" and
      [ty]:"dF be finiteFINSET-1V1\<bar>setHIDDENM2" and dFDef:"dF = domRELAT-1K1 F9"
       sorry
    have A5: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 B & lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?fd"
      using rfinseq_def_2 rfunct_3_def_6 sorry
    have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
      using A1 A2 rearran1_th_13 sorry
    have A7: "domFINSEQ-1K5 ?fd =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fd)"
      using finseq_1_def_3 sorry
    have A8: "domFINSEQ-1K5 B =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 B)"
      using finseq_1_def_3 sorry
    have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using A4 relat_1_th_68 sorry
    then have "(?fd,F)are-fiberwise-equipotentCLASSES1R2"
      using A4 rfunct_3_def_13 sorry
    then have "cardCARD-1K4 dfd =XBOOLE-0R4 cardCARD-1K4 dF"
      using classes1_th_81 sorry
    then have "lenFINSEQ-1K4 ?fd <>HIDDENR2 0NUMBERSK6"
      using A4 A7 sorry
    then have A9: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
      using nat_1_th_13 sorry
    then have A10: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?fd"
      using finseq_3_th_25 sorry
    have "rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) c=MEMBEREDR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) & rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) c=TARSKIR1 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
    proof(rule conjMI)
      show "rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) c=MEMBEREDR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngRVSUM-1K1 ?p"
          then obtain c where
            [ty]:"c be ElementSUBSET-1M1-of C" and 
            "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ?p"and A11: "?p .FUNCT-1K1 c =HIDDENR1 x"
            using partfun1_th_3 sorry
          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 B & c inTARSKIR2 B .FUNCT-1K1 Lamb1"
          have A12: " ex n be NatNAT-1M1 st ?P(n)"
          proof-
            have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 B & c inTARSKIR2 B .FUNCT-1K1 n"
            proof-
              obtain n where 
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 B"
                 sorry
              show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 B & c inTARSKIR2 B .FUNCT-1K1 n"
              proof(rule bexI[of _ "n"])
                have "B .FUNCT-1K1 n =XBOOLE-0R4 C"
                  using rearran1_th_3 sorry
                thus "n inTARSKIR2 domFINSEQ-1K5 B & c inTARSKIR2 B .FUNCT-1K1 n"
                  using A3 A5 A9 finseq_3_th_25 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          obtain mi where
            [ty]:"mi be NatNAT-1M1" and 
            A13: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
            using nat_1_sch_5 A12 sorry
          have A14: "\<one>\<^sub>M <=XXREAL-0R1 mi"
            using A13 finseq_3_th_25 sorry
          then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
            using finseq_2_th_4 sorry
          then obtain m1 where 
            [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
            using finseq_2_th_5 sorry
          have A15: "mi <=XXREAL-0R1 lenFINSEQ-1K4 B"
            using A13 finseq_3_th_25 sorry
          have "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
          proof-
            show "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
            proof-
              have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
                 sorry
              have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
              proof(rule impI)
                assume "mi =XBOOLE-0R4 \<one>\<^sub>M"
                then have "?p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 \<one>\<^sub>M"
                  using A1 A2 A13 rearran1_th_15 sorry
                thus "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
                  using A10 A11 funct_1_def_3 sorry
              qed
              have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
              proof(rule impI)
                assume "mi <>HIDDENR2 \<one>\<^sub>M"
                then have "\<one>\<^sub>M <XXREAL-0R3 mi"
                  using A14 xxreal_0_th_1 sorry
                then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mi"
                  using nat_1_th_13 sorry
                then have A16: "\<one>\<^sub>M <=XXREAL-0R1 m1"
                  using xreal_1_th_19 sorry
                have A17: "m1 <XXREAL-0R3 mi"
                  using xreal_1_th_44 sorry
                then have "m1 <=XXREAL-0R1 lenFINSEQ-1K4 B"
                  using A15 xxreal_0_th_2 sorry
                then have "m1 inTARSKIR2 domFINSEQ-1K5 B"
                  using A16 finseq_3_th_25 sorry
                then have " not c inTARSKIR2 B .FUNCT-1K1 m1"
                  using A13 xreal_1_th_44 sorry
                then have A18: "c inTARSKIR2 B .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1"
                  using A13 xboole_0_def_5 sorry
                have "m1 <XXREAL-0R3 lenFINSEQ-1K4 B"
                  using A15 A17 xxreal_0_th_2 sorry
                then have "?p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
                  using A1 A2 A16 A18 rearran1_th_15 sorry
                thus "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
                  using A3 A5 A7 A8 A11 A13 funct_1_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
             sorry
        qed "sorry"
        thus "rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) c=MEMBEREDR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?fd & ?fd .FUNCT-1K1 Lamb1 =HIDDENR1 x"
        assume "x inHIDDENR3 rngRVSUM-1K1 ?fd"
        then have A19: " ex n be NatNAT-1M1 st ?P(n)"
          using finseq_2_th_10 sorry
        obtain mi where
          [ty]:"mi be NatNAT-1M1" and 
          A20: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
          using nat_1_sch_5 A19 sorry
        have A21: "\<one>\<^sub>M <=XXREAL-0R1 mi"
          using A20 finseq_3_th_25 sorry
        then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
          using finseq_2_th_4 sorry
        then obtain m1 where 
          [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
          using finseq_2_th_5 sorry
        have A22: "mi <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
          using A20 finseq_3_th_25 sorry
        have "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B))"
        proof-
          show "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B))"
          proof-
            have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
               sorry
            have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
            proof(rule impI)
              assume A23: "mi =XBOOLE-0R4 \<one>\<^sub>M"
              let ?y = "the ElementSUBSET-1M1-of B .FUNCT-1K1 \<one>\<^sub>M"
              have A24: "B .FUNCT-1K1 \<one>\<^sub>M <>HIDDENR2 {}XBOOLE-0K1"
                using A3 A5 A7 A8 A10 rearran1_th_7 sorry
              have "B .FUNCT-1K1 \<one>\<^sub>M c=TARSKIR1 C"
                using A3 A5 A7 A8 A10 rearran1_lm_5 sorry
              then obtain y where 
                [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = ?y"
                using A24 sorry
              have "?p .FUNCT-1K1 y =XBOOLE-0R4 ?fd .FUNCT-1K1 \<one>\<^sub>M"
                using A1 A2 A24 rearran1_th_15 sorry
              thus "x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
                using A6 A20 A23 funct_1_def_3 sorry
            qed
            have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
            proof(rule impI)
              assume A25: "mi <>HIDDENR2 \<one>\<^sub>M"
              let ?y = "the ElementSUBSET-1M1-of B .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1"
              have "\<one>\<^sub>M <XXREAL-0R3 mi"
                using A21 A25 xxreal_0_th_1 sorry
              then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mi"
                using nat_1_th_13 sorry
              then have A26: "\<one>\<^sub>M <=XXREAL-0R1 m1"
                using xreal_1_th_19 sorry
              have "m1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
                using A20 finseq_3_th_25 sorry
              then have "m1 <=XXREAL-0R1 lenFINSEQ-1K4 ?fd -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_19 sorry
              then have A27: "B .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1 <>HIDDENR2 {}XBOOLE-0K1"
                using A3 A5 A26 rearran1_th_8 sorry
              then have A28: "?y inTARSKIR2 B .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
                using xboole_0_def_5 sorry
              have "B .FUNCT-1K1 mi c=TARSKIR1 C"
                using A3 A5 A7 A8 A20 rearran1_lm_5 sorry
              then obtain y where 
                [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = ?y"
                using A28 sorry
              have "m1 <XXREAL-0R3 mi"
                using xreal_1_th_44 sorry
              then have "m1 <XXREAL-0R3 lenFINSEQ-1K4 ?fd"
                using A22 xxreal_0_th_2 sorry
              then have "?p .FUNCT-1K1 y =XBOOLE-0R4 ?fd .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
                using A1 A2 A3 A5 A26 A27 rearran1_th_15 sorry
              thus "x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
                using A6 A20 funct_1_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
           sorry
      qed "sorry"
      thus "rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) c=TARSKIR1 rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
        using tarski_def_3 sorry
    qed
    thus "rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_17:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    let ?fd = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    let ?p = "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
    let ?mf = "MIMRFINSEQK3 ?fd"
    let ?h = "CHIRFUNCT-3K15(B,C)"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ?p be finiteFINSET-1V1"
       sorry
    then obtain p where 
      [ty]:"p be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)" and pDef:"p = ?p"
      using finset_1_th_10 sorry
    have A1: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 B & lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?fd"
      using rfinseq_def_2 rfunct_3_def_6 sorry
    have A2: "domFINSEQ-1K5 ?fd =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fd) & domFINSEQ-1K5 B =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 B)"
      using finseq_1_def_3 sorry
    assume A3: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A4: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?h"
      using rearran1_th_12 sorry
    have A5: "domRELSET-1K1\<^bsub>(C)\<^esub> p =XBOOLE-0R4 C"
      using A3 rearran1_th_13 sorry
    have A6: "rngRVSUM-1K1 p =MEMBEREDR9 rngRVSUM-1K1 ?fd"
      using A3 rearran1_th_16 sorry
    have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(p,x))"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have " not x inHIDDENR3 rngRVSUM-1K1 ?fd & cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or x inHIDDENR3 rngRVSUM-1K1 ?fd & (x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
      proof-
        show " not x inHIDDENR3 rngRVSUM-1K1 ?fd & cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or x inHIDDENR3 rngRVSUM-1K1 ?fd & (x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
        proof-
          have cases: " not x inHIDDENR3 rngRVSUM-1K1 ?fd or x inHIDDENR3 rngRVSUM-1K1 ?fd"
             sorry
          have case1: " not x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
          proof(rule impI)
            assume A7: " not x inHIDDENR3 rngRVSUM-1K1 ?fd"
            then have "?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
              using rearran1_lm_1 sorry
            thus "cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
              using A6 A7 rearran1_lm_1 sorry
          qed
          have case2: "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
          proof(rule impI)
            assume A8: "x inHIDDENR3 rngRVSUM-1K1 ?fd"
            let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?fd & ?fd .FUNCT-1K1 Lamb1 =HIDDENR1 x"
            have A9: " for n be NatNAT-1M1 holds ?P(n) implies n <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using finseq_3_th_25 sorry
            have A10: " ex n be NatNAT-1M1 st ?P(n)"
              using A8 finseq_2_th_10 sorry
            obtain ma where
              [ty]:"ma be NatNAT-1M1" and 
              A11: "?P(ma) & ( for n be NatNAT-1M1 holds ?P(n) implies n <=XXREAL-0R1 ma)"
              using nat_1_sch_6 A9 A10 sorry
            have A12: " ex n be NatNAT-1M1 st ?P(n)"
              using A8 finseq_2_th_10 sorry
            obtain mi where
              [ty]:"mi be NatNAT-1M1" and 
              A13: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
              using nat_1_sch_5 A12 sorry
            obtain r where 
              [ty]:"r be RealXREAL-0M1" and rDef:"r = x"
              using A13 sorry
            have A14: "\<one>\<^sub>M <=XXREAL-0R1 mi"
              using A13 finseq_3_th_25 sorry
            then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
              using finseq_2_th_4 sorry
            then obtain m1 where 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
              using finseq_2_th_5 sorry
            have A15: "m1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi"
               sorry
            have A16: "ma <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using A11 finseq_3_th_25 sorry
            have A17: "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 =MEMBEREDR12 ?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
            proof-
              have "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 =MEMBEREDR12 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
              proof-
                have "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 c=MEMBEREDR6 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} & FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                proof(rule conjMI)
                  show "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 c=MEMBEREDR6 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  proof-
                    have " for y be objectHIDDENM1 holds y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    proof(rule ballI,rule impI)
                      fix y assume [ty]: "y be objectHIDDENM1"
                      assume A18: "y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                      then obtain l where 
                        [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = y"
                         sorry
                      obtain o where 
                        [ty]:"o be RealXREAL-0M1" and oDef:"o = ?fd .FUNCT-1K1 l"
                         sorry
                      have A19: "y inHIDDENR3 SegFINSEQ-1K2 ma"
                        using A18 xboole_0_def_5 sorry
                      then have A20: "\<one>\<^sub>M <=XXREAL-0R1 l"
                        using finseq_1_th_1 sorry
                      have A21: "l <=XXREAL-0R1 ma"
                        using A19 finseq_1_th_1 sorry
                      then have "l <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
                        using A16 xxreal_0_th_2 sorry
                      then have A22: "l inTARSKIR2 domFINSEQ-1K5 ?fd"
                        using A20 finseq_3_th_25 sorry
                      have " not y inHIDDENR3 SegFINSEQ-1K2 m1"
                        using A18 xboole_0_def_5 sorry
                      then have "l <XXREAL-0R3 \<one>\<^sub>M or m1 <XXREAL-0R3 l"
                        using finseq_1_th_1 sorry
                      then have "mi <XXREAL-0R3 l +NAT-1K1 \<one>\<^sub>M"
                        using A19 finseq_1_th_1 xreal_1_th_19 sorry
                      then have A23: "mi <=XXREAL-0R1 l"
                        using nat_1_th_13 sorry
                      have "l =XBOOLE-0R4 ma & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 ma & (l <>HIDDENR2 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                      proof-
                        show "l =XBOOLE-0R4 ma & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 ma & (l <>HIDDENR2 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                        proof-
                          have cases: "l =XBOOLE-0R4 ma or l <>HIDDENR2 ma"
                             sorry
                          have case1: "l =XBOOLE-0R4 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          proof(rule impI)
                            assume "l =XBOOLE-0R4 ma"
                            then have "o inHIDDENR3 {TARSKIK1 x}"
                              using A11 tarski_def_1 sorry
                            thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                              using A22 funct_1_def_7 sorry
                          qed
                          have case2: "l <>HIDDENR2 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          proof(rule impI)
                            assume "l <>HIDDENR2 ma"
                            then have "l <XXREAL-0R3 ma"
                              using A21 xxreal_0_th_1 sorry
                            then have A24: "o >=XXREAL-0R2 r"
                              using A11 A22 rfinseq_th_19 sorry
                            have "l =XBOOLE-0R4 mi & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 mi & (l <>HIDDENR2 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                            proof-
                              show "l =XBOOLE-0R4 mi & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 mi & (l <>HIDDENR2 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                              proof-
                                have cases: "l =XBOOLE-0R4 mi or l <>HIDDENR2 mi"
                                   sorry
                                have case1: "l =XBOOLE-0R4 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                proof(rule impI)
                                  assume "l =XBOOLE-0R4 mi"
                                  then have "o inHIDDENR3 {TARSKIK1 x}"
                                    using A13 tarski_def_1 sorry
                                  thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    using A22 funct_1_def_7 sorry
                                qed
                                have case2: "l <>HIDDENR2 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                proof(rule impI)
                                  assume "l <>HIDDENR2 mi"
                                  then have "mi <XXREAL-0R3 l"
                                    using A23 xxreal_0_th_1 sorry
                                  then have "r >=XXREAL-0R2 o"
                                    using A13 A22 rfinseq_th_19 sorry
                                  then have "r =HIDDENR1 o"
                                    using A24 xxreal_0_th_1 sorry
                                  then have "o inHIDDENR3 {TARSKIK1 x}"
                                    using tarski_def_1 sorry
                                  thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    using A22 funct_1_def_7 sorry
                                qed
                                show " ?thesis "
                                  using cases case1 case2 sorry
                              qed
                            qed
                            thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                               sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                         sorry
                    qed "sorry"
                    thus "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 c=MEMBEREDR6 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                      using tarski_def_3 sorry
                  qed
                  have " for y be objectHIDDENM1 holds y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} implies y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                  proof(rule ballI,rule impI)
                    fix y assume [ty]: "y be objectHIDDENM1"
                    assume A25: "y inHIDDENR3 ?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    then have A26: "y inHIDDENR3 domFINSEQ-1K5 ?fd"
                      using funct_1_def_7 sorry
                    obtain l where 
                      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = y"
                      using A25 sorry
                    have A27: "\<one>\<^sub>M <=XXREAL-0R1 l"
                      using A26 finseq_3_th_25 sorry
                    have "?fd .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 x}"
                      using A25 funct_1_def_7 sorry
                    then have A28: "?fd .FUNCT-1K1 l =HIDDENR1 x"
                      using tarski_def_1 sorry
                    then have "mi <=XXREAL-0R1 l"
                      using A13 A26 sorry
                    then have "mi <XXREAL-0R3 l +NAT-1K1 \<one>\<^sub>M"
                      using nat_1_th_13 sorry
                    then have "m1 <XXREAL-0R3 l or l <XXREAL-0R3 \<one>\<^sub>M"
                      using xreal_1_th_19 sorry
                    then have A29: " not l inTARSKIR2 SegFINSEQ-1K2 m1"
                      using finseq_1_th_1 sorry
                    have "l <=XXREAL-0R1 ma"
                      using A11 A26 A28 sorry
                    then have "l inTARSKIR2 SegFINSEQ-1K2 ma"
                      using A27 finseq_1_th_1 sorry
                    thus "y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                      using A29 xboole_0_def_5 sorry
                  qed "sorry"
                  thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                    using tarski_def_3 sorry
                qed
                thus "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 =MEMBEREDR12 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  using xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A30: "\<one>\<^sub>M <=XXREAL-0R1 ma"
              using A11 finseq_3_th_25 sorry
            have A31: "mi <=XXREAL-0R1 ma"
              using A13 A11 sorry
            have "m1 <=XXREAL-0R1 mi"
              using xreal_1_th_43 sorry
            then have A32: "m1 <=XXREAL-0R1 ma"
              using A31 xxreal_0_th_2 sorry
            then have "SegFINSEQ-1K2 m1 c=MEMBEREDR6 SegFINSEQ-1K2 ma"
              using finseq_1_th_5 sorry
            then have A33: "cardCARD-1K4 (?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (SegFINSEQ-1K2 ma) -XCMPLX-0K6 cardCARD-1K4 (SegFINSEQ-1K2 m1)"
              using A17 card_2_th_44 sorry
            also have "... = ma -XCMPLX-0K6 cardCARD-1K4 (SegFINSEQ-1K2 m1)"
              using finseq_1_th_57 sorry
            also have "... = ma -XCMPLX-0K6 m1"
              using finseq_1_th_57 sorry
            finally have "cardCARD-1K4 (?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 ma -XCMPLX-0K6 m1"
               sorry
            have A34: "mi <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using A13 finseq_3_th_25 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using A14 xxreal_0_th_2 sorry
            then have A35: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?fd"
              using finseq_3_th_25 sorry
            have "mi =XBOOLE-0R4 \<one>\<^sub>M & cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
            proof-
              show "mi =XBOOLE-0R4 \<one>\<^sub>M & cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
              proof-
                have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
                   sorry
                have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                proof(rule impI)
                  assume A36: "mi =XBOOLE-0R4 \<one>\<^sub>M"
                  have "B .FUNCT-1K1 ma =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  proof-
                    have "B .FUNCT-1K1 ma c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} & p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 B .FUNCT-1K1 ma"
                    proof(rule conjMI)
                      show "B .FUNCT-1K1 ma c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                      proof-
                        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 B & Lamb1 <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 B .FUNCT-1K1 Lamb1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                        have " for y be objectHIDDENM1 holds y inHIDDENR3 B .FUNCT-1K1 ma implies y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        proof(rule ballI,rule impI)
                          fix y assume [ty]: "y be objectHIDDENM1"
                          assume A37: "y inHIDDENR3 B .FUNCT-1K1 ma"
                          have "B .FUNCT-1K1 ma c=TARSKIR1 C"
                            using A4 A1 A2 A11 rearran1_lm_5 sorry
                          then obtain cy where 
                            [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                            using A37 sorry
                          have A38: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
                          proof-
                            have " for n be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 B & n <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 B .FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})) implies (n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 B & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
                            proof(rule ballI,rule impI,rule impMI ,rule impI,rule ballI,rule impI)
                              fix n assume [ty]: "n be NatNAT-1M1"
                              assume A39: "?P(n)"
                              assume A40: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 B"
                                and A41: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma"
                              have A42: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                using A40 finseq_3_th_25 sorry
                              then have A43: "n <=XXREAL-0R1 lenFINSEQ-1K4 B -XCMPLX-0K6 \<one>\<^sub>M"
                                using xreal_1_th_19 sorry
                              have A44: "n <XXREAL-0R3 lenFINSEQ-1K4 B"
                                using A42 nat_1_th_13 sorry
                              fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
                              assume A45: "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                              have A46: "n <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                using A42 nat_1_th_13 sorry
                              have "n =XBOOLE-0R4 0NUMBERSK6 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                              proof-
                                show "n =XBOOLE-0R4 0NUMBERSK6 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                proof-
                                  have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
                                     sorry
                                  have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                  proof(rule impI)
                                    assume "n =XBOOLE-0R4 0NUMBERSK6"
                                    then have "p .FUNCT-1K1 c =HIDDENR1 x"
                                      using A3 A13 A36 A45 rearran1_th_15 sorry
                                    then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                      using tarski_def_1 sorry
                                    thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                      using A5 funct_1_def_7 sorry
                                  qed
                                  have case2: "n <>HIDDENR2 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                  proof(rule impI)
                                    assume A47: "n <>HIDDENR2 0NUMBERSK6"
                                    then have A48: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                                      using xreal_1_th_6 sorry
                                    have A49: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                                      using A47 nat_1_th_13 sorry
                                    then have "B .FUNCT-1K1 n c=TARSKIR1 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                      using A43 rearran1_def_2 sorry
                                    then have A50: "B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\/XBOOLE-0K2 B .FUNCT-1K1 n"
                                      using xboole_1_th_12 sorry
                                    also have "... = (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\/XBOOLE-0K2 B .FUNCT-1K1 n"
                                      using xboole_1_th_39 sorry
                                    finally have "B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\/XBOOLE-0K2 B .FUNCT-1K1 n"
                                       sorry
                                    have "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 B .FUNCT-1K1 n & (c inTARSKIR2 B .FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                    proof-
                                      show "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 B .FUNCT-1K1 n & (c inTARSKIR2 B .FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                      proof-
                                        have cases: "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n or c inTARSKIR2 B .FUNCT-1K1 n"
                                          using A45 A50 xboole_0_def_3 sorry
                                        have case1: "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                        proof(rule impI)
                                          assume "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n"
                                          then have A51: "p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                            using A3 A44 A49 rearran1_th_15 sorry
                                          have "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                          proof-
                                            show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                            proof-
                                              have cases: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                 sorry
                                              have case1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                              proof(rule impI)
                                                assume "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma"
                                                then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                  using A11 A51 tarski_def_1 sorry
                                                thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                  using A5 funct_1_def_7 sorry
                                              qed
                                              have case2: "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                              proof(rule impI)
                                                assume "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                then have "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 ma"
                                                  using A41 xxreal_0_th_1 sorry
                                                then have A52: "p .FUNCT-1K1 c >=XXREAL-0R2 r"
                                                  using A4 A1 A2 A11 A40 A51 rfinseq_th_19 sorry
                                                have "r >=XXREAL-0R2 p .FUNCT-1K1 c"
                                                  using A4 A1 A2 A13 A36 A40 A48 A51 rfinseq_th_19 sorry
                                                then have "r =HIDDENR1 p .FUNCT-1K1 c"
                                                  using A52 xxreal_0_th_1 sorry
                                                then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                  using tarski_def_1 sorry
                                                thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                  using A5 funct_1_def_7 sorry
                                              qed
                                              show " ?thesis "
                                                using cases case1 case2 sorry
                                            qed
                                          qed
                                          thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                             sorry
                                        qed
                                        have case2: "c inTARSKIR2 B .FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                        proof(rule impI)
                                          assume "c inTARSKIR2 B .FUNCT-1K1 n"
                                          thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                            using A39 A41 A46 A49 finseq_3_th_25 nat_1_th_13 sorry
                                        qed
                                        show " ?thesis "
                                          using cases case1 case2 sorry
                                      qed
                                    qed
                                    thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                       sorry
                                  qed
                                  show " ?thesis "
                                    using cases case1 case2 sorry
                                qed
                              qed
                              thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                 sorry
                            qed "sorry"
                            thus " ?thesis "
                               sorry
                          qed
                          have A53: "?P(0NUMBERSK6)"
                            using finseq_3_th_25 sorry
                          have A54: " for n be NatNAT-1M1 holds ?P(n)"
                            using nat_1_sch_2 A53 A38 sorry
                          have "ma inTARSKIR2 domFINSEQ-1K5 B"
                            using A4 A1 A11 finseq_3_th_29 sorry
                          then have "cy inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                            using A37 A54 sorry
                          thus "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                             sorry
                        qed "sorry"
                        thus "B .FUNCT-1K1 ma c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          using tarski_def_3 sorry
                      qed
                      have " for y be objectHIDDENM1 holds y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} implies ( not y inHIDDENR3 B .FUNCT-1K1 ma implies  False )"
                      proof(rule ballI,rule impI,rule impI)
                        fix y assume [ty]: "y be objectHIDDENM1"
                        assume A55: "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        then obtain cy where 
                          [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                           sorry
                        have "p .FUNCT-1K1 cy inTARSKIR2 {TARSKIK1 x}"
                          using A55 funct_1_def_7 sorry
                        then have A56: "p .FUNCT-1K1 cy =HIDDENR1 x"
                          using tarski_def_1 sorry
                        let ?Q = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 B & ma <XXREAL-0R3 Lamb1) & cy inTARSKIR2 B .FUNCT-1K1 Lamb1"
                        assume A57: " not y inHIDDENR3 B .FUNCT-1K1 ma"
                        have A58: " ex n be NatNAT-1M1 st ?Q(n)"
                        proof-
                          have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 B & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 B .FUNCT-1K1 n)"
                          proof-
                            obtain n where 
                              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 B"
                               sorry
                            show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 B & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 B .FUNCT-1K1 n)"
                            proof(rule bexI[of _ "n"],rule conjMI)
                              have "lenFINSEQ-1K4 B <>HIDDENR2 0NUMBERSK6"
                                using rearran1_th_4 sorry
                              then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                using nat_1_th_13 sorry
                              thus "n inTARSKIR2 domFINSEQ-1K5 B"
                                using finseq_3_th_25 sorry
                              have A59: "B .FUNCT-1K1 n =XBOOLE-0R4 C"
                                using rearran1_th_3 sorry
                              have "n <=XXREAL-0R1 ma implies  False "
                              proof(rule impI)
                                assume "n <=XXREAL-0R1 ma"
                                then have "ma =XBOOLE-0R4 lenFINSEQ-1K4 B"
                                  using A4 A1 A16 xxreal_0_th_1 sorry
                                then have "cy inTARSKIR2 B .FUNCT-1K1 ma"
                                  using A59 sorry
                                thus " False "
                                  using A57 sorry
                              qed
                              thus " not ma <XXREAL-0R3 n & cy inTARSKIR2 B .FUNCT-1K1 n"
                                using A59 sorry
                            qed "sorry"
                          qed
                          thus " ?thesis "
                             sorry
                        qed
                        obtain mm where
                          [ty]:"mm be NatNAT-1M1" and 
                          A60: "?Q(mm) & ( for n be NatNAT-1M1 holds ?Q(n) implies mm <=XXREAL-0R1 n)"
                          using nat_1_sch_5 A58 sorry
                        have "\<one>\<^sub>M <=XXREAL-0R1 mm"
                          using A60 finseq_3_th_25 sorry
                        then have "maxXXREAL-0K5(0NUMBERSK6,mm -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mm -XCMPLX-0K6 \<one>\<^sub>M"
                          using finseq_2_th_4 sorry
                        then obtain Om where 
                          [ty]:"Om be ElementSUBSET-1M1-of NATNUMBERSK1" and OmDef:"Om = mm -XCMPLX-0K6 \<one>\<^sub>M"
                          using finseq_2_th_5 sorry
                        have "ma +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mm"
                          using A60 nat_1_th_13 sorry
                        then have A61: "ma <=XXREAL-0R1 Om"
                          using xreal_1_th_19 sorry
                        then have A62: "\<one>\<^sub>M <=XXREAL-0R1 Om"
                          using A30 xxreal_0_th_2 sorry
                        have A63: "mm inTARSKIR2 domFINSEQ-1K5 ?fd"
                          using A4 A1 A60 finseq_3_th_29 sorry
                        have A64: "mm <=XXREAL-0R1 lenFINSEQ-1K4 B"
                          using A60 finseq_3_th_25 sorry
                        have A65: "mm <XXREAL-0R3 mm +NAT-1K1 \<one>\<^sub>M"
                          using nat_1_th_13 sorry
                        then have "Om <XXREAL-0R3 mm"
                          using xreal_1_th_19 sorry
                        then have A66: "Om <XXREAL-0R3 lenFINSEQ-1K4 B"
                          using A64 xxreal_0_th_2 sorry
                        have "Om <=XXREAL-0R1 mm"
                          using A65 xreal_1_th_19 sorry
                        then have "Om <=XXREAL-0R1 lenFINSEQ-1K4 B"
                          using A64 xxreal_0_th_2 sorry
                        then have A67: "Om inTARSKIR2 domFINSEQ-1K5 B"
                          using A62 finseq_3_th_25 sorry
                        have "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                        proof-
                          show "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                          proof-
                            have cases: "ma =XBOOLE-0R4 Om or ma <>HIDDENR2 Om"
                               sorry
                            have case1: "ma =XBOOLE-0R4 Om implies  False "
                            proof(rule impI)
                              assume "ma =XBOOLE-0R4 Om"
                              then have "cy inTARSKIR2 B .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 Om"
                                using A57 A60 xboole_0_def_5 sorry
                              then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                using A3 A62 A66 rearran1_th_15 sorry
                              thus " False "
                                using A11 A56 A60 A63 sorry
                            qed
                            have case2: "ma <>HIDDENR2 Om implies  False "
                            proof(rule impI)
                              assume "ma <>HIDDENR2 Om"
                              then have A68: "ma <XXREAL-0R3 Om"
                                using A61 xxreal_0_th_1 sorry
                              have "cy inTARSKIR2 B .FUNCT-1K1 Om implies  False "
                              proof(rule impI)
                                assume "cy inTARSKIR2 B .FUNCT-1K1 Om"
                                then have "mm <=XXREAL-0R1 Om"
                                  using A60 A67 A68 sorry
                                then have "mm -XCMPLX-0K6 Om <=XXREAL-0R1 0NUMBERSK6"
                                  using xreal_1_th_47 sorry
                                thus " False "
                                   sorry
                              qed
                              then have "cy inTARSKIR2 B .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 Om"
                                using A60 xboole_0_def_5 sorry
                              then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                using A3 A62 A66 rearran1_th_15 sorry
                              thus " False "
                                using A11 A56 A60 A63 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                        thus " False "
                           sorry
                      qed "sorry"
                      thus "p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 B .FUNCT-1K1 ma"
                        using tarski_def_3 sorry
                    qed
                    thus "B .FUNCT-1K1 ma =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                      using xboole_0_def_10 sorry
                  qed
                  thus "cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                    using A4 A1 A30 A16 A33 A36 rearran1_def_1 sorry
                qed
                have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                proof(rule impI)
                  assume A69: "mi <>HIDDENR2 \<one>\<^sub>M"
                  then have "\<one>\<^sub>M <XXREAL-0R3 mi"
                    using A14 xxreal_0_th_1 sorry
                  then have A70: "\<one>\<^sub>M <=XXREAL-0R1 m1"
                    using A15 nat_1_th_13 sorry
                  have A71: "m1 <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
                    using A34 A15 nat_1_th_13 sorry
                  then have A72: "m1 inTARSKIR2 domFINSEQ-1K5 B"
                    using A4 A1 A70 finseq_3_th_25 sorry
                  then have A73: "B .FUNCT-1K1 m1 c=TARSKIR1 B .FUNCT-1K1 ma"
                    using A4 A1 A2 A11 A32 rearran1_th_2 sorry
                  have "B .FUNCT-1K1 ma c=TARSKIR1 C"
                    using A4 A1 A2 A11 rearran1_lm_5 sorry
                  then obtain Bma Bm1 where 
                    [ty]:"Bma be finiteFINSET-1V1\<bar>setHIDDENM2" and BmaDef:"Bma = B .FUNCT-1K1 ma" and
                    [ty]:"Bm1 be finiteFINSET-1V1\<bar>setHIDDENM2" and Bm1Def:"Bm1 = B .FUNCT-1K1 m1"
                    using A73 sorry
                  have "B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1 =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  proof-
                    have "B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1 c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} & p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1"
                    proof(rule conjMI)
                      show "B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1 c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                      proof-
                        let ?P = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 B & mi <=XXREAL-0R1 Lamb1) & Lamb1 <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 B .FUNCT-1K1 Lamb1 \\SUBSET-1K6 B .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                        have " for y be objectHIDDENM1 holds y inHIDDENR3 B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1 implies y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        proof(rule ballI,rule impI)
                          fix y assume [ty]: "y be objectHIDDENM1"
                          have A74: "B .FUNCT-1K1 ma c=TARSKIR1 C"
                            using A4 A1 A2 A11 rearran1_lm_5 sorry
                          have A75: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
                          proof-
                            have " for n be NatNAT-1M1 holds ((n inTARSKIR2 domFINSEQ-1K5 B & mi <=XXREAL-0R1 n) & n <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})) implies (n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 B & (mi <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma) implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
                            proof(rule ballI,rule impI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
                              fix n assume [ty]: "n be NatNAT-1M1"
                              assume A76: "?P(n)"
                              assume A77: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 B"
                                and A78: "mi <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                                and A79: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma"
                              fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
                              have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                using A77 finseq_3_th_25 sorry
                              then have A80: "n <XXREAL-0R3 lenFINSEQ-1K4 B"
                                using nat_1_th_13 sorry
                              assume A81: "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1"
                              have "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & (mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                              proof-
                                show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & (mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                proof-
                                  have cases: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi or mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
                                     sorry
                                  have case1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                  proof(rule impI)
                                    assume A82: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi"
                                    then have "p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                      using A3 A70 A80 A81 rearran1_th_15 sorry
                                    then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                      using A13 A82 tarski_def_1 sorry
                                    thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                      using A5 funct_1_def_7 sorry
                                  qed
                                  have case2: "mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                  proof(rule impI)
                                    assume "mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
                                    then have A83: "mi <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                                      using A78 xxreal_0_th_1 sorry
                                    then have "mi <=XXREAL-0R1 n"
                                      using nat_1_th_13 sorry
                                    then have A84: "\<one>\<^sub>M <=XXREAL-0R1 n"
                                      using A14 xxreal_0_th_2 sorry
                                    have "n <=XXREAL-0R1 ma"
                                      using A79 nat_1_th_13 sorry
                                    then have A85: "n <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                      using A4 A1 A16 xxreal_0_th_2 sorry
                                    then have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n inTARSKIR2 domFINSEQ-1K5 B"
                                      using A84 finseq_3_th_25 nat_1_th_11 sorry
                                    then have "B .FUNCT-1K1 n c=TARSKIR1 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                      using A77 rearran1_th_2 sorry
                                    then have A86: "B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1 =HIDDENR1 (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\/XBOOLE-0K2 B .FUNCT-1K1 n)\\SUBSET-1K6 B .FUNCT-1K1 m1"
                                      using xboole_1_th_12 sorry
                                    also have "... = ((B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\/XBOOLE-0K2 B .FUNCT-1K1 n)\\SUBSET-1K6 B .FUNCT-1K1 m1"
                                      using xboole_1_th_39 sorry
                                    also have "... = ((B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>(B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> B .FUNCT-1K1 m1)\\/XBOOLE-0K2 (B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1)"
                                      using xboole_1_th_42 sorry
                                    finally have "B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1 =HIDDENR1 ((B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>(B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> B .FUNCT-1K1 m1)\\/XBOOLE-0K2 (B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1)"
                                       sorry
                                    have "c inTARSKIR2 (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>(B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> B .FUNCT-1K1 m1 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1 & (c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                    proof-
                                      show "c inTARSKIR2 (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>(B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> B .FUNCT-1K1 m1 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1 & (c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                      proof-
                                        have cases: "c inTARSKIR2 (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>(B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> B .FUNCT-1K1 m1 or c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1"
                                          using A81 A86 xboole_0_def_3 sorry
                                        have case1: "c inTARSKIR2 (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>(B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> B .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                        proof(rule impI)
                                          assume "c inTARSKIR2 (B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>(B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> B .FUNCT-1K1 m1"
                                          then have "c inTARSKIR2 B .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 n"
                                            using xboole_0_def_5 sorry
                                          then have A87: "p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                            using A3 A80 A84 rearran1_th_15 sorry
                                          have "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                          proof-
                                            show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                            proof-
                                              have cases: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                 sorry
                                              have case1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                              proof(rule impI)
                                                assume "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma"
                                                then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                  using A11 A87 tarski_def_1 sorry
                                                thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                  using A5 funct_1_def_7 sorry
                                              qed
                                              have case2: "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                              proof(rule impI)
                                                assume "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                then have "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 ma"
                                                  using A79 xxreal_0_th_1 sorry
                                                then have A88: "p .FUNCT-1K1 c >=XXREAL-0R2 r"
                                                  using A4 A1 A2 A11 A77 A87 rfinseq_th_19 sorry
                                                have "r >=XXREAL-0R2 p .FUNCT-1K1 c"
                                                  using A4 A1 A2 A13 A77 A83 A87 rfinseq_th_19 sorry
                                                then have "r =HIDDENR1 p .FUNCT-1K1 c"
                                                  using A88 xxreal_0_th_1 sorry
                                                then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                  using tarski_def_1 sorry
                                                thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                  using A5 funct_1_def_7 sorry
                                              qed
                                              show " ?thesis "
                                                using cases case1 case2 sorry
                                            qed
                                          qed
                                          thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                             sorry
                                        qed
                                        have case2: "c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                        proof(rule impI)
                                          assume "c inTARSKIR2 B .FUNCT-1K1 n \\SUBSET-1K6 B .FUNCT-1K1 m1"
                                          thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                            using A76 A79 A83 A84 A85 finseq_3_th_25 nat_1_th_13 sorry
                                        qed
                                        show " ?thesis "
                                          using cases case1 case2 sorry
                                      qed
                                    qed
                                    thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                       sorry
                                  qed
                                  show " ?thesis "
                                    using cases case1 case2 sorry
                                qed
                              qed
                              thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                 sorry
                            qed "sorry"
                            thus " ?thesis "
                               sorry
                          qed
                          have A89: "?P(0NUMBERSK6)"
                             sorry
                          have A90: " for n be NatNAT-1M1 holds ?P(n)"
                            using nat_1_sch_2 A89 A75 sorry
                          assume A91: "y inHIDDENR3 B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1"
                          then have "y inHIDDENR3 B .FUNCT-1K1 ma"
                             sorry
                          then obtain cy where 
                            [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                            using A74 sorry
                          have "ma inTARSKIR2 domFINSEQ-1K5 B"
                            using A4 A1 A11 finseq_3_th_29 sorry
                          then have "cy inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                            using A31 A91 A90 sorry
                          thus "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                             sorry
                        qed "sorry"
                        thus "B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1 c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          using tarski_def_3 sorry
                      qed
                      have " for y be objectHIDDENM1 holds y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} implies ( not y inHIDDENR3 B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1 implies  False )"
                      proof(rule ballI,rule impI,rule impI)
                        fix y assume [ty]: "y be objectHIDDENM1"
                        assume A92: "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        then obtain cy where 
                          [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                           sorry
                        have "p .FUNCT-1K1 cy inTARSKIR2 {TARSKIK1 x}"
                          using A92 funct_1_def_7 sorry
                        then have A93: "p .FUNCT-1K1 cy =HIDDENR1 x"
                          using tarski_def_1 sorry
                        assume A94: " not y inHIDDENR3 B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1"
                        have " not y inHIDDENR3 B .FUNCT-1K1 ma &  False  or y inHIDDENR3 B .FUNCT-1K1 m1 & (y inHIDDENR3 B .FUNCT-1K1 m1 implies  False )"
                        proof-
                          show " not y inHIDDENR3 B .FUNCT-1K1 ma &  False  or y inHIDDENR3 B .FUNCT-1K1 m1 & (y inHIDDENR3 B .FUNCT-1K1 m1 implies  False )"
                          proof-
                            have cases: " not y inHIDDENR3 B .FUNCT-1K1 ma or y inHIDDENR3 B .FUNCT-1K1 m1"
                              using A94 xboole_0_def_5 sorry
                            have case1: " not y inHIDDENR3 B .FUNCT-1K1 ma implies  False "
                            proof(rule impI)
                              assume A95: " not y inHIDDENR3 B .FUNCT-1K1 ma"
                              let ?Q = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 B & ma <XXREAL-0R3 Lamb1) & cy inTARSKIR2 B .FUNCT-1K1 Lamb1"
                              have A96: " ex n be NatNAT-1M1 st ?Q(n)"
                              proof-
                                have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 B & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 B .FUNCT-1K1 n)"
                                proof-
                                  obtain n where 
                                    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 B"
                                     sorry
                                  show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 B & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 B .FUNCT-1K1 n)"
                                  proof(rule bexI[of _ "n"],rule conjMI)
                                    have "lenFINSEQ-1K4 B <>HIDDENR2 0NUMBERSK6"
                                      using rearran1_th_4 sorry
                                    then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                      using nat_1_th_13 sorry
                                    thus "n inTARSKIR2 domFINSEQ-1K5 B"
                                      using finseq_3_th_25 sorry
                                    have A97: "B .FUNCT-1K1 n =XBOOLE-0R4 C"
                                      using rearran1_th_3 sorry
                                    have "n <=XXREAL-0R1 ma implies  False "
                                    proof(rule impI)
                                      assume "n <=XXREAL-0R1 ma"
                                      then have "ma =XBOOLE-0R4 lenFINSEQ-1K4 B"
                                        using A4 A1 A16 xxreal_0_th_1 sorry
                                      then have "cy inTARSKIR2 B .FUNCT-1K1 ma"
                                        using A97 sorry
                                      thus " False "
                                        using A95 sorry
                                    qed
                                    thus " not ma <XXREAL-0R3 n & cy inTARSKIR2 B .FUNCT-1K1 n"
                                      using A97 sorry
                                  qed "sorry"
                                qed
                                thus " ?thesis "
                                   sorry
                              qed
                              obtain mm where
                                [ty]:"mm be NatNAT-1M1" and 
                                A98: "?Q(mm) & ( for n be NatNAT-1M1 holds ?Q(n) implies mm <=XXREAL-0R1 n)"
                                using nat_1_sch_5 A96 sorry
                              have "\<one>\<^sub>M <=XXREAL-0R1 mm"
                                using A98 finseq_3_th_25 sorry
                              then have "maxXXREAL-0K5(0NUMBERSK6,mm -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mm -XCMPLX-0K6 \<one>\<^sub>M"
                                using finseq_2_th_4 sorry
                              then obtain Om where 
                                [ty]:"Om be ElementSUBSET-1M1-of NATNUMBERSK1" and OmDef:"Om = mm -XCMPLX-0K6 \<one>\<^sub>M"
                                using finseq_2_th_5 sorry
                              have "ma +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mm"
                                using A98 nat_1_th_13 sorry
                              then have A99: "ma <=XXREAL-0R1 Om"
                                using xreal_1_th_19 sorry
                              then have A100: "\<one>\<^sub>M <=XXREAL-0R1 Om"
                                using A30 xxreal_0_th_2 sorry
                              have A101: "mm inTARSKIR2 domFINSEQ-1K5 ?fd"
                                using A4 A1 A98 finseq_3_th_29 sorry
                              have A102: "mm <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                using A98 finseq_3_th_25 sorry
                              have A103: "mm <XXREAL-0R3 mm +NAT-1K1 \<one>\<^sub>M"
                                using nat_1_th_13 sorry
                              then have "Om <XXREAL-0R3 mm"
                                using xreal_1_th_19 sorry
                              then have A104: "Om <XXREAL-0R3 lenFINSEQ-1K4 B"
                                using A102 xxreal_0_th_2 sorry
                              have "Om <=XXREAL-0R1 mm"
                                using A103 xreal_1_th_19 sorry
                              then have "Om <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                using A102 xxreal_0_th_2 sorry
                              then have A105: "Om inTARSKIR2 domFINSEQ-1K5 B"
                                using A100 finseq_3_th_25 sorry
                              have "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                              proof-
                                show "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                                proof-
                                  have cases: "ma =XBOOLE-0R4 Om or ma <>HIDDENR2 Om"
                                     sorry
                                  have case1: "ma =XBOOLE-0R4 Om implies  False "
                                  proof(rule impI)
                                    assume "ma =XBOOLE-0R4 Om"
                                    then have "cy inTARSKIR2 B .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 Om"
                                      using A95 A98 xboole_0_def_5 sorry
                                    then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                      using A3 A100 A104 rearran1_th_15 sorry
                                    thus " False "
                                      using A11 A93 A98 A101 sorry
                                  qed
                                  have case2: "ma <>HIDDENR2 Om implies  False "
                                  proof(rule impI)
                                    assume "ma <>HIDDENR2 Om"
                                    then have A106: "ma <XXREAL-0R3 Om"
                                      using A99 xxreal_0_th_1 sorry
                                    have "cy inTARSKIR2 B .FUNCT-1K1 Om implies  False "
                                    proof(rule impI)
                                      assume "cy inTARSKIR2 B .FUNCT-1K1 Om"
                                      then have "mm <=XXREAL-0R1 Om"
                                        using A98 A105 A106 sorry
                                      then have "mm -XCMPLX-0K6 Om <=XXREAL-0R1 0NUMBERSK6"
                                        using xreal_1_th_47 sorry
                                      thus " False "
                                         sorry
                                    qed
                                    then have "cy inTARSKIR2 B .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 Om"
                                      using A98 xboole_0_def_5 sorry
                                    then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                      using A3 A100 A104 rearran1_th_15 sorry
                                    thus " False "
                                      using A11 A93 A98 A101 sorry
                                  qed
                                  show " ?thesis "
                                    using cases case1 case2 sorry
                                qed
                              qed
                              thus " False "
                                 sorry
                            qed
                            have case2: "y inHIDDENR3 B .FUNCT-1K1 m1 implies  False "
                            proof(rule impI)
                              assume A107: "y inHIDDENR3 B .FUNCT-1K1 m1"
                              let ?Q = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 B & Lamb1 <=XXREAL-0R1 m1) & cy inTARSKIR2 B .FUNCT-1K1 Lamb1"
                              have A108: " ex n be NatNAT-1M1 st ?Q(n)"
                                using A72 A107 sorry
                              obtain mm where
                                [ty]:"mm be NatNAT-1M1" and 
                                A109: "?Q(mm) & ( for n be NatNAT-1M1 holds ?Q(n) implies mm <=XXREAL-0R1 n)"
                                using nat_1_sch_5 A108 sorry
                              have A110: "\<one>\<^sub>M <=XXREAL-0R1 mm"
                                using A109 finseq_3_th_25 sorry
                              then have "maxXXREAL-0K5(0NUMBERSK6,mm -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mm -XCMPLX-0K6 \<one>\<^sub>M"
                                using finseq_2_th_4 sorry
                              then obtain Om where 
                                [ty]:"Om be ElementSUBSET-1M1-of NATNUMBERSK1" and OmDef:"Om = mm -XCMPLX-0K6 \<one>\<^sub>M"
                                using finseq_2_th_5 sorry
                              have A111: "mm <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                using A109 finseq_3_th_25 sorry
                              have A112: "mm inTARSKIR2 domFINSEQ-1K5 ?fd"
                                using A4 A1 A109 finseq_3_th_29 sorry
                              have "mm =XBOOLE-0R4 \<one>\<^sub>M &  False  or mm <>HIDDENR2 \<one>\<^sub>M & (mm <>HIDDENR2 \<one>\<^sub>M implies  False )"
                              proof-
                                show "mm =XBOOLE-0R4 \<one>\<^sub>M &  False  or mm <>HIDDENR2 \<one>\<^sub>M & (mm <>HIDDENR2 \<one>\<^sub>M implies  False )"
                                proof-
                                  have cases: "mm =XBOOLE-0R4 \<one>\<^sub>M or mm <>HIDDENR2 \<one>\<^sub>M"
                                     sorry
                                  have case1: "mm =XBOOLE-0R4 \<one>\<^sub>M implies  False "
                                  proof(rule impI)
                                    assume "mm =XBOOLE-0R4 \<one>\<^sub>M"
                                    then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 \<one>\<^sub>M"
                                      using A3 A109 rearran1_th_15 sorry
                                    then have "mi <=XXREAL-0R1 \<one>\<^sub>M"
                                      using A13 A35 A93 sorry
                                    thus " False "
                                      using A14 A69 xxreal_0_th_1 sorry
                                  qed
                                  have case2: "mm <>HIDDENR2 \<one>\<^sub>M implies  False "
                                  proof(rule impI)
                                    assume "mm <>HIDDENR2 \<one>\<^sub>M"
                                    then have "\<one>\<^sub>M <XXREAL-0R3 mm"
                                      using A110 xxreal_0_th_1 sorry
                                    then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mm"
                                      using nat_1_th_13 sorry
                                    then have A113: "\<one>\<^sub>M <=XXREAL-0R1 Om"
                                      using xreal_1_th_19 sorry
                                    have A114: "mm <XXREAL-0R3 mm +NAT-1K1 \<one>\<^sub>M"
                                      using nat_1_th_13 sorry
                                    then have A115: "Om <=XXREAL-0R1 mm"
                                      using xreal_1_th_19 sorry
                                    then have "Om <=XXREAL-0R1 lenFINSEQ-1K4 B"
                                      using A111 xxreal_0_th_2 sorry
                                    then have A116: "Om inTARSKIR2 domFINSEQ-1K5 B"
                                      using A113 finseq_3_th_25 sorry
                                    have A117: "Om <XXREAL-0R3 mm"
                                      using A114 xreal_1_th_19 sorry
                                    then have A118: "Om <XXREAL-0R3 lenFINSEQ-1K4 B"
                                      using A111 xxreal_0_th_2 sorry
                                    have "Om <=XXREAL-0R1 m1"
                                      using A109 A115 xxreal_0_th_2 sorry
                                    then have " not cy inTARSKIR2 B .FUNCT-1K1 Om"
                                      using A109 A117 A116 sorry
                                    then have "cy inTARSKIR2 B .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 Om"
                                      using A109 xboole_0_def_5 sorry
                                    then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M)"
                                      using A3 A113 A118 rearran1_th_15 sorry
                                    then have "mi <=XXREAL-0R1 mm"
                                      using A13 A93 A112 sorry
                                    then have "m1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m1"
                                      using A109 xxreal_0_th_2 sorry
                                    then have "\<one>\<^sub>M <=XXREAL-0R1 m1 -XCMPLX-0K6 m1"
                                      using xreal_1_th_19 sorry
                                    then have "\<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
                                       sorry
                                    thus " False "
                                       sorry
                                  qed
                                  show " ?thesis "
                                    using cases case1 case2 sorry
                                qed
                              qed
                              thus " False "
                                 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                        thus " False "
                           sorry
                      qed "sorry"
                      thus "p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1"
                        using tarski_def_3 sorry
                    qed
                    thus "B .FUNCT-1K1 ma \\SUBSET-1K6 B .FUNCT-1K1 m1 =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                      using xboole_0_def_10 sorry
                  qed
                  then have "cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 Bma -XCMPLX-0K6 cardCARD-1K4 Bm1"
                    using A73 card_2_th_44 sorry
                  also have "... = ma -XCMPLX-0K6 cardCARD-1K4 Bm1"
                    using A4 A1 A30 A16 rearran1_def_1 sorry
                  also have "... = cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                    using A4 A1 A33 A70 A71 rearran1_def_1 sorry
                  finally show "cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(p,x))"
         sorry
    qed "sorry"
    thus "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using classes1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_18:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A2: "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using rearran1_th_17 sorry
    have A3: "domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) =XBOOLE-0R4 C"
      using A1 rearran1_th_13 sorry
    then have "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using A2 A3 rfunct_3_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_19:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using rearran1_th_18 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_20:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using relat_1_th_68 sorry
    then have A4: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),F)are-fiberwise-equipotentCLASSES1R2"
      using A3 rfunct_3_def_13 sorry
    have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_17 sorry
    then have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),F)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    then have A5: "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_51 sorry
    have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
      using valued_1_th_3 sorry
    then have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
      using relat_1_th_68 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C),RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using A6 rfunct_3_def_13 sorry
    then have A7: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C),F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_76 sorry
    have A8: "domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using valued_1_th_3 sorry
    then have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
      using A8 A7 rfunct_3_def_13 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_21:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =XBOOLE-0R4 C"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) =XBOOLE-0R4 C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    let ?b = "Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B"
    have A1: "lenFINSEQ-1K4 (CHIRFUNCT-3K15(?b,C)) =XBOOLE-0R4 lenFINSEQ-1K4 ?b & lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(?b,C)) =XBOOLE-0R4 minNAT-1K4(lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)),lenFINSEQ-1K4 (CHIRFUNCT-3K15(?b,C)))"
      using rfunct_3_def_6 rfunct_3_def_7 sorry
    assume "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A2: "lenFINSEQ-1K4 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)) =XBOOLE-0R4 lenFINSEQ-1K4 (CHIRFUNCT-3K15(?b,C)) & lenFINSEQ-1K4 ?b =XBOOLE-0R4 cardCARD-1K4 D"
      using rearran1_th_1 rearran1_th_12 sorry
    have "domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) c=TARSKIR1 C & C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
    proof(rule conjMI)
      show "domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) c=TARSKIR1 C"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 C implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 C"
        then obtain c where 
          [ty]:"c be ElementSUBSET-1M1-of C" and cDef:"c = x"
           sorry
        have "c is-common-for-domRFUNCT-3R1\<^bsub>(C,REALNUMBERSK2)\<^esub> MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) (#)RFUNCT-3K16\<^bsub>(C)\<^esub> CHIRFUNCT-3K15(?b,C)"
          using rfunct_3_th_32 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
          using A1 A2 rfunct_3_th_28 sorry
      qed "sorry"
      thus "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
        using tarski_def_3 sorry
    qed
    thus "domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) =XBOOLE-0R4 C"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_22:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 lenFINSEQ-1K4 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A)) & c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 n implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M) & ( for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & (n <XXREAL-0R3 lenFINSEQ-1K4 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n) implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    let ?fd = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    let ?mf = "MIMRFINSEQK3 ?fd"
    let ?b = "Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B"
    let ?h = "CHIRFUNCT-3K15(?b,C)"
    have A1: "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 SumRVSUM-1K22 ((?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c)"
      using rfunct_3_th_32 rfunct_3_th_33 sorry
    have A2: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 ?b & lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?fd"
      using rfinseq_def_2 rfunct_3_def_6 sorry
    assume A3: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A4: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?h"
      using rearran1_th_12 sorry
    show "c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
    proof-
      have "c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
      proof(rule impI)
        assume "c inTARSKIR2 ?b .FUNCT-1K1 \<one>\<^sub>M"
        then have "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 SumRVSUM-1K22 (MIMRFINSEQK3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
          using A3 A1 rearran1_th_14 sorry
        also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
          using A4 A2 rearran1_th_4 rfinseq_th_16 sorry
        finally show "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?mfn = "MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    assume A5: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A6: "n <XXREAL-0R3 lenFINSEQ-1K4 ?b"
      and A7: "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n"
    have "(?mf (#)RFUNCT-3K16\<^bsub>(C)\<^esub> ?h)#RFUNCT-3K17\<^bsub>(C)\<^esub> c =FINSEQ-1R1 (n  |->FINSEQ-2K2 (0NUMBERSK6))^FINSEQ-1K8 ?mfn"
      using A3 A5 A6 A7 rearran1_th_14 sorry
    then have "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 SumRVSUM-1K22 (n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> (InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))) +XCMPLX-0K2 SumRVSUM-1K22 (MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n))"
      using A1 rvsum_1_th_75 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 SumRVSUM-1K22 (MIMRFINSEQK3 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> n))"
      using rvsum_1_th_81 sorry
    also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A4 A2 A6 rfinseq_th_17 sorry
    finally show "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_23:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    let ?fd = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    let ?p = "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
    let ?mf = "MIMRFINSEQK3 ?fd"
    let ?b = "Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B"
    let ?h = "CHIRFUNCT-3K15(?b,C)"
    have A3: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?h"
      using A1 A2 rearran1_th_12 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
       sorry
    then obtain F9 where 
      [ty]:"F9 be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and F9Def:"F9 = F"
      using finset_1_th_10 sorry
    have A4: "domFINSEQ-1K5 ?fd =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fd)"
      using finseq_1_def_3 sorry
    have A5: "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
      using A1 A2 rearran1_th_21 sorry
    have A6: "domFINSEQ-1K5 ?b =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?b)"
      using finseq_1_def_3 sorry
    obtain dfd dF where 
      [ty]:"dfd be finiteFINSET-1V1\<bar>setHIDDENM2" and dfdDef:"dfd = domFINSEQ-1K5 ?fd" and
      [ty]:"dF be finiteFINSET-1V1\<bar>setHIDDENM2" and dFDef:"dF = domRELAT-1K1 F9"
       sorry
    have A7: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 ?b & lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?fd"
      using rfinseq_def_2 rfunct_3_def_6 sorry
    have A8: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using relat_1_th_68 sorry
    then have "(?fd,F)are-fiberwise-equipotentCLASSES1R2"
      using A8 rfunct_3_def_13 sorry
    then have "cardCARD-1K4 dfd =XBOOLE-0R4 cardCARD-1K4 dF"
      using classes1_th_81 sorry
    then have "lenFINSEQ-1K4 ?fd <>HIDDENR2 0NUMBERSK6"
      using A8 A4 sorry
    then have A9: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
      using nat_1_th_13 sorry
    then have A10: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?fd"
      using finseq_3_th_25 sorry
    have "rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) c=MEMBEREDR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) & rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) c=TARSKIR1 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
    proof(rule conjMI)
      show "rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) c=MEMBEREDR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngRVSUM-1K1 ?p"
          then obtain c where
            [ty]:"c be ElementSUBSET-1M1-of C" and 
            "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ?p"and A11: "?p .FUNCT-1K1 c =HIDDENR1 x"
            using partfun1_th_3 sorry
          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b & c inTARSKIR2 ?b .FUNCT-1K1 Lamb1"
          have A12: " ex n be NatNAT-1M1 st ?P(n)"
          proof-
            have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n"
            proof-
              obtain n where 
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 ?b"
                 sorry
              show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n"
              proof(rule bexI[of _ "n"])
                have "?b .FUNCT-1K1 n =XBOOLE-0R4 C"
                  using rearran1_th_3 sorry
                thus "n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n"
                  using A3 A7 A9 finseq_3_th_25 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          obtain mi where
            [ty]:"mi be NatNAT-1M1" and 
            A13: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
            using nat_1_sch_5 A12 sorry
          have A14: "\<one>\<^sub>M <=XXREAL-0R1 mi"
            using A13 finseq_3_th_25 sorry
          then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
            using finseq_2_th_4 sorry
          then obtain m1 where 
            [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
            using finseq_2_th_5 sorry
          have A15: "mi <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
            using A13 finseq_3_th_25 sorry
          have "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
          proof-
            show "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))"
            proof-
              have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
                 sorry
              have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
              proof(rule impI)
                assume "mi =XBOOLE-0R4 \<one>\<^sub>M"
                then have "?p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 \<one>\<^sub>M"
                  using A1 A2 A13 rearran1_th_22 sorry
                thus "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
                  using A10 A11 funct_1_def_3 sorry
              qed
              have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
              proof(rule impI)
                assume "mi <>HIDDENR2 \<one>\<^sub>M"
                then have "\<one>\<^sub>M <XXREAL-0R3 mi"
                  using A14 xxreal_0_th_1 sorry
                then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mi"
                  using nat_1_th_13 sorry
                then have A16: "\<one>\<^sub>M <=XXREAL-0R1 m1"
                  using xreal_1_th_19 sorry
                have A17: "m1 <XXREAL-0R3 mi"
                  using xreal_1_th_44 sorry
                then have "m1 <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                  using A15 xxreal_0_th_2 sorry
                then have "m1 inTARSKIR2 domFINSEQ-1K5 ?b"
                  using A16 finseq_3_th_25 sorry
                then have " not c inTARSKIR2 ?b .FUNCT-1K1 m1"
                  using A13 xreal_1_th_44 sorry
                then have A18: "c inTARSKIR2 ?b .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                  using A13 xboole_0_def_5 sorry
                have "m1 <XXREAL-0R3 lenFINSEQ-1K4 ?b"
                  using A15 A17 xxreal_0_th_2 sorry
                then have "?p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
                  using A1 A2 A16 A18 rearran1_th_22 sorry
                thus "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
                  using A3 A7 A4 A6 A11 A13 funct_1_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
             sorry
        qed "sorry"
        thus "rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) c=MEMBEREDR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?fd & ?fd .FUNCT-1K1 Lamb1 =HIDDENR1 x"
        assume "x inHIDDENR3 rngRVSUM-1K1 ?fd"
        then have A19: " ex n be NatNAT-1M1 st ?P(n)"
          using finseq_2_th_10 sorry
        obtain mi where
          [ty]:"mi be NatNAT-1M1" and 
          A20: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
          using nat_1_sch_5 A19 sorry
        have A21: "\<one>\<^sub>M <=XXREAL-0R1 mi"
          using A20 finseq_3_th_25 sorry
        then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
          using finseq_2_th_4 sorry
        then obtain m1 where 
          [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
          using finseq_2_th_5 sorry
        have A22: "mi <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
          using A20 finseq_3_th_25 sorry
        have "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B))"
        proof-
          show "mi =XBOOLE-0R4 \<one>\<^sub>M & x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B))"
          proof-
            have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
               sorry
            have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
            proof(rule impI)
              assume A23: "mi =XBOOLE-0R4 \<one>\<^sub>M"
              let ?y = "the ElementSUBSET-1M1-of ?b .FUNCT-1K1 \<one>\<^sub>M"
              have A24: "?b .FUNCT-1K1 \<one>\<^sub>M <>HIDDENR2 {}XBOOLE-0K1"
                using A3 A7 A4 A6 A10 rearran1_th_7 sorry
              have "?b .FUNCT-1K1 \<one>\<^sub>M c=TARSKIR1 C"
                using A3 A7 A4 A6 A10 rearran1_lm_5 sorry
              then obtain y where 
                [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = ?y"
                using A24 sorry
              have "?p .FUNCT-1K1 y =XBOOLE-0R4 ?fd .FUNCT-1K1 \<one>\<^sub>M"
                using A1 A2 A24 rearran1_th_22 sorry
              thus "x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
                using A5 A20 A23 funct_1_def_3 sorry
            qed
            have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
            proof(rule impI)
              assume A25: "mi <>HIDDENR2 \<one>\<^sub>M"
              let ?y = "the ElementSUBSET-1M1-of ?b .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
              have "\<one>\<^sub>M <XXREAL-0R3 mi"
                using A21 A25 xxreal_0_th_1 sorry
              then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mi"
                using nat_1_th_13 sorry
              then have A26: "\<one>\<^sub>M <=XXREAL-0R1 m1"
                using xreal_1_th_19 sorry
              have "m1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
                using A20 finseq_3_th_25 sorry
              then have "m1 <=XXREAL-0R1 lenFINSEQ-1K4 ?fd -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_19 sorry
              then have A27: "?b .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m1 <>HIDDENR2 {}XBOOLE-0K1"
                using A3 A7 A26 rearran1_th_8 sorry
              then have A28: "?y inTARSKIR2 ?b .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
                using xboole_0_def_5 sorry
              have "?b .FUNCT-1K1 mi c=TARSKIR1 C"
                using A3 A7 A4 A6 A20 rearran1_lm_5 sorry
              then obtain y where 
                [ty]:"y be ElementSUBSET-1M1-of C" and yDef:"y = ?y"
                using A28 sorry
              have "m1 <XXREAL-0R3 mi"
                using xreal_1_th_44 sorry
              then have "m1 <XXREAL-0R3 lenFINSEQ-1K4 ?fd"
                using A22 xxreal_0_th_2 sorry
              then have "?p .FUNCT-1K1 y =XBOOLE-0R4 ?fd .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
                using A1 A2 A3 A7 A26 A27 rearran1_th_22 sorry
              thus "x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
                using A5 A20 funct_1_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
           sorry
      qed "sorry"
      thus "rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) c=TARSKIR1 rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
        using tarski_def_3 sorry
    qed
    thus "rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) =MEMBEREDR9 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_24:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    let ?fd = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
    let ?p = "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
    let ?mf = "MIMRFINSEQK3 ?fd"
    let ?b = "Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B"
    let ?h = "CHIRFUNCT-3K15(?b,C)"
    have A1: "lenFINSEQ-1K4 ?h =XBOOLE-0R4 lenFINSEQ-1K4 ?b & lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?fd"
      using rfinseq_def_2 rfunct_3_def_6 sorry
    assume A2: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A3: "rngRVSUM-1K1 ?p =MEMBEREDR9 rngRVSUM-1K1 ?fd"
      using rearran1_th_23 sorry
    have A4: "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
      using A2 rearran1_th_21 sorry
    then obtain p where 
      [ty]:"p be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)" and pDef:"p = ?p"
      using finset_1_th_10 sorry
    have A5: "lenFINSEQ-1K4 ?mf =XBOOLE-0R4 lenFINSEQ-1K4 ?h"
      using A2 rearran1_th_12 sorry
    have A6: "domFINSEQ-1K5 ?fd =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fd) & domFINSEQ-1K5 ?b =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?b)"
      using finseq_1_def_3 sorry
    have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(p,x))"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have " not x inHIDDENR3 rngRVSUM-1K1 ?fd & cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or x inHIDDENR3 rngRVSUM-1K1 ?fd & (x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
      proof-
        show " not x inHIDDENR3 rngRVSUM-1K1 ?fd & cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or x inHIDDENR3 rngRVSUM-1K1 ?fd & (x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
        proof-
          have cases: " not x inHIDDENR3 rngRVSUM-1K1 ?fd or x inHIDDENR3 rngRVSUM-1K1 ?fd"
             sorry
          have case1: " not x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
          proof(rule impI)
            assume A7: " not x inHIDDENR3 rngRVSUM-1K1 ?fd"
            then have "?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
              using rearran1_lm_1 sorry
            thus "cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
              using A3 A7 rearran1_lm_1 sorry
          qed
          have case2: "x inHIDDENR3 rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) implies cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
          proof(rule impI)
            assume A8: "x inHIDDENR3 rngRVSUM-1K1 ?fd"
            let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?fd & ?fd .FUNCT-1K1 Lamb1 =HIDDENR1 x"
            have A9: " ex n be NatNAT-1M1 st ?P(n)"
              using A8 finseq_2_th_10 sorry
            obtain mi where
              [ty]:"mi be NatNAT-1M1" and 
              A10: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
              using nat_1_sch_5 A9 sorry
            obtain r where 
              [ty]:"r be RealXREAL-0M1" and rDef:"r = x"
              using A10 sorry
            have A11: "\<one>\<^sub>M <=XXREAL-0R1 mi"
              using A10 finseq_3_th_25 sorry
            then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
              using finseq_2_th_4 sorry
            then obtain m1 where 
              [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
              using finseq_2_th_5 sorry
            have A12: "m1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi"
               sorry
            have A13: " for n be NatNAT-1M1 holds ?P(n) implies n <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using finseq_3_th_25 sorry
            obtain ma where
              [ty]:"ma be NatNAT-1M1" and 
              A14: "?P(ma) & ( for n be NatNAT-1M1 holds ?P(n) implies n <=XXREAL-0R1 ma)"
              using nat_1_sch_6 A13 A9 sorry
            have A15: "ma <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using A14 finseq_3_th_25 sorry
            have A16: "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 =MEMBEREDR12 ?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
            proof-
              have "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 =MEMBEREDR12 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
              proof-
                have "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 c=MEMBEREDR6 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} & FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                proof(rule conjMI)
                  show "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 c=MEMBEREDR6 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  proof-
                    have " for y be objectHIDDENM1 holds y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    proof(rule ballI,rule impI)
                      fix y assume [ty]: "y be objectHIDDENM1"
                      assume A17: "y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                      then obtain l where 
                        [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = y"
                         sorry
                      obtain o where 
                        [ty]:"o be RealXREAL-0M1" and oDef:"o = ?fd .FUNCT-1K1 l"
                         sorry
                      have A18: "y inHIDDENR3 SegFINSEQ-1K2 ma"
                        using A17 xboole_0_def_5 sorry
                      then have A19: "\<one>\<^sub>M <=XXREAL-0R1 l"
                        using finseq_1_th_1 sorry
                      have A20: "l <=XXREAL-0R1 ma"
                        using A18 finseq_1_th_1 sorry
                      then have "l <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
                        using A15 xxreal_0_th_2 sorry
                      then have A21: "l inTARSKIR2 domFINSEQ-1K5 ?fd"
                        using A19 finseq_3_th_25 sorry
                      have " not y inHIDDENR3 SegFINSEQ-1K2 m1"
                        using A17 xboole_0_def_5 sorry
                      then have "l <XXREAL-0R3 \<one>\<^sub>M or m1 <XXREAL-0R3 l"
                        using finseq_1_th_1 sorry
                      then have "mi <XXREAL-0R3 l +NAT-1K1 \<one>\<^sub>M"
                        using A18 finseq_1_th_1 xreal_1_th_19 sorry
                      then have A22: "mi <=XXREAL-0R1 l"
                        using nat_1_th_13 sorry
                      have "l =XBOOLE-0R4 ma & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 ma & (l <>HIDDENR2 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                      proof-
                        show "l =XBOOLE-0R4 ma & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 ma & (l <>HIDDENR2 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                        proof-
                          have cases: "l =XBOOLE-0R4 ma or l <>HIDDENR2 ma"
                             sorry
                          have case1: "l =XBOOLE-0R4 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          proof(rule impI)
                            assume "l =XBOOLE-0R4 ma"
                            then have "o inHIDDENR3 {TARSKIK1 x}"
                              using A14 tarski_def_1 sorry
                            thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                              using A21 funct_1_def_7 sorry
                          qed
                          have case2: "l <>HIDDENR2 ma implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          proof(rule impI)
                            assume "l <>HIDDENR2 ma"
                            then have "l <XXREAL-0R3 ma"
                              using A20 xxreal_0_th_1 sorry
                            then have A23: "o >=XXREAL-0R2 r"
                              using A14 A21 rfinseq_th_19 sorry
                            have "l =XBOOLE-0R4 mi & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 mi & (l <>HIDDENR2 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                            proof-
                              show "l =XBOOLE-0R4 mi & y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or l <>HIDDENR2 mi & (l <>HIDDENR2 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                              proof-
                                have cases: "l =XBOOLE-0R4 mi or l <>HIDDENR2 mi"
                                   sorry
                                have case1: "l =XBOOLE-0R4 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                proof(rule impI)
                                  assume "l =XBOOLE-0R4 mi"
                                  then have "o inHIDDENR3 {TARSKIK1 x}"
                                    using A10 tarski_def_1 sorry
                                  thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    using A21 funct_1_def_7 sorry
                                qed
                                have case2: "l <>HIDDENR2 mi implies y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                proof(rule impI)
                                  assume "l <>HIDDENR2 mi"
                                  then have "mi <XXREAL-0R3 l"
                                    using A22 xxreal_0_th_1 sorry
                                  then have "r >=XXREAL-0R2 o"
                                    using A10 A21 rfinseq_th_19 sorry
                                  then have "r =HIDDENR1 o"
                                    using A23 xxreal_0_th_1 sorry
                                  then have "o inHIDDENR3 {TARSKIK1 x}"
                                    using tarski_def_1 sorry
                                  thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    using A21 funct_1_def_7 sorry
                                qed
                                show " ?thesis "
                                  using cases case1 case2 sorry
                              qed
                            qed
                            thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                               sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus "y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                         sorry
                    qed "sorry"
                    thus "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 c=MEMBEREDR6 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                      using tarski_def_3 sorry
                  qed
                  have " for y be objectHIDDENM1 holds y inHIDDENR3 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} implies y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                  proof(rule ballI,rule impI)
                    fix y assume [ty]: "y be objectHIDDENM1"
                    assume A24: "y inHIDDENR3 ?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    then have A25: "y inHIDDENR3 domFINSEQ-1K5 ?fd"
                      using funct_1_def_7 sorry
                    obtain l where 
                      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = y"
                      using A24 sorry
                    have A26: "\<one>\<^sub>M <=XXREAL-0R1 l"
                      using A25 finseq_3_th_25 sorry
                    have "?fd .FUNCT-1K1 y inTARSKIR2 {TARSKIK1 x}"
                      using A24 funct_1_def_7 sorry
                    then have A27: "?fd .FUNCT-1K1 l =HIDDENR1 x"
                      using tarski_def_1 sorry
                    then have "mi <=XXREAL-0R1 l"
                      using A10 A25 sorry
                    then have "mi <XXREAL-0R3 l +NAT-1K1 \<one>\<^sub>M"
                      using nat_1_th_13 sorry
                    then have "m1 <XXREAL-0R3 l or l <XXREAL-0R3 \<one>\<^sub>M"
                      using xreal_1_th_19 sorry
                    then have A28: " not l inTARSKIR2 SegFINSEQ-1K2 m1"
                      using finseq_1_th_1 sorry
                    have "l <=XXREAL-0R1 ma"
                      using A14 A25 A27 sorry
                    then have "l inTARSKIR2 SegFINSEQ-1K2 ma"
                      using A26 finseq_1_th_1 sorry
                    thus "y inHIDDENR3 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                      using A28 xboole_0_def_5 sorry
                  qed "sorry"
                  thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1"
                    using tarski_def_3 sorry
                qed
                thus "SegFINSEQ-1K2 ma \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1 =MEMBEREDR12 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  using xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A29: "\<one>\<^sub>M <=XXREAL-0R1 ma"
              using A14 finseq_3_th_25 sorry
            have A30: "mi <=XXREAL-0R1 ma"
              using A10 A14 sorry
            have "m1 <=XXREAL-0R1 mi"
              using xreal_1_th_43 sorry
            then have A31: "m1 <=XXREAL-0R1 ma"
              using A30 xxreal_0_th_2 sorry
            then have "SegFINSEQ-1K2 m1 c=MEMBEREDR6 SegFINSEQ-1K2 ma"
              using finseq_1_th_5 sorry
            then have A32: "cardCARD-1K4 (?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (SegFINSEQ-1K2 ma) -XCMPLX-0K6 cardCARD-1K4 (SegFINSEQ-1K2 m1)"
              using A16 card_2_th_44 sorry
            also have "... = ma -XCMPLX-0K6 cardCARD-1K4 (SegFINSEQ-1K2 m1)"
              using finseq_1_th_57 sorry
            also have "... = ma -XCMPLX-0K6 m1"
              using finseq_1_th_57 sorry
            finally have "cardCARD-1K4 (?fd \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 ma -XCMPLX-0K6 m1"
               sorry
            have A33: "mi <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using A10 finseq_3_th_25 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
              using A11 xxreal_0_th_2 sorry
            then have A34: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?fd"
              using finseq_3_th_25 sorry
            have "mi =XBOOLE-0R4 \<one>\<^sub>M & cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
            proof-
              show "mi =XBOOLE-0R4 \<one>\<^sub>M & cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
              proof-
                have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
                   sorry
                have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                proof(rule impI)
                  assume A35: "mi =XBOOLE-0R4 \<one>\<^sub>M"
                  have "?b .FUNCT-1K1 ma =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  proof-
                    have "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    proof-
                      have "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} & p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma"
                      proof(rule conjMI)
                        show "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        proof-
                          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b & Lamb1 <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 ?b .FUNCT-1K1 Lamb1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                          have " for y be objectHIDDENM1 holds y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma implies y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          proof(rule ballI,rule impI)
                            fix y assume [ty]: "y be objectHIDDENM1"
                            assume A36: "y inHIDDENR3 ?b .FUNCT-1K1 ma"
                            have "?b .FUNCT-1K1 ma c=TARSKIR1 C"
                              using A5 A1 A6 A14 rearran1_lm_5 sorry
                            then obtain cy where 
                              [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                              using A36 sorry
                            have A37: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
                            proof-
                              have " for n be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & n <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})) implies (n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
                              proof(rule ballI,rule impI,rule impMI ,rule impI,rule ballI,rule impI)
                                fix n assume [ty]: "n be NatNAT-1M1"
                                assume A38: "?P(n)"
                                assume A39: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?b"
                                  and A40: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma"
                                have A41: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                  using A39 finseq_3_th_25 sorry
                                then have A42: "n <=XXREAL-0R1 lenFINSEQ-1K4 ?b -XCMPLX-0K6 \<one>\<^sub>M"
                                  using xreal_1_th_19 sorry
                                have A43: "n <XXREAL-0R3 lenFINSEQ-1K4 ?b"
                                  using A41 nat_1_th_13 sorry
                                fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
                                assume A44: "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                have A45: "n <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                  using A41 nat_1_th_13 sorry
                                have "n =XBOOLE-0R4 0NUMBERSK6 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                proof-
                                  show "n =XBOOLE-0R4 0NUMBERSK6 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                  proof-
                                    have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
                                       sorry
                                    have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    proof(rule impI)
                                      assume "n =XBOOLE-0R4 0NUMBERSK6"
                                      then have "p .FUNCT-1K1 c =HIDDENR1 x"
                                        using A2 A10 A35 A44 rearran1_th_22 sorry
                                      then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                        using tarski_def_1 sorry
                                      thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                        using A4 funct_1_def_7 sorry
                                    qed
                                    have case2: "n <>HIDDENR2 0NUMBERSK6 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    proof(rule impI)
                                      assume A46: "n <>HIDDENR2 0NUMBERSK6"
                                      then have A47: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                                        using xreal_1_th_6 sorry
                                      have A48: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                                        using A46 nat_1_th_13 sorry
                                      then have "?b .FUNCT-1K1 n c=TARSKIR1 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                        using A42 rearran1_def_2 sorry
                                      then have A49: "?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\/XBOOLE-0K2 ?b .FUNCT-1K1 n"
                                        using xboole_1_th_12 sorry
                                      also have "... = (?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\/XBOOLE-0K2 ?b .FUNCT-1K1 n"
                                        using xboole_1_th_39 sorry
                                      finally have "?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\/XBOOLE-0K2 ?b .FUNCT-1K1 n"
                                         sorry
                                      have "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 ?b .FUNCT-1K1 n & (c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                      proof-
                                        show "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 ?b .FUNCT-1K1 n & (c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                        proof-
                                          have cases: "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n or c inTARSKIR2 ?b .FUNCT-1K1 n"
                                            using A44 A49 xboole_0_def_3 sorry
                                          have case1: "c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                          proof(rule impI)
                                            assume "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n"
                                            then have A50: "p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                              using A2 A43 A48 rearran1_th_22 sorry
                                            have "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                            proof-
                                              show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                              proof-
                                                have cases: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                   sorry
                                                have case1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                proof(rule impI)
                                                  assume "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma"
                                                  then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                    using A14 A50 tarski_def_1 sorry
                                                  thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                    using A4 funct_1_def_7 sorry
                                                qed
                                                have case2: "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                proof(rule impI)
                                                  assume "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                  then have "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 ma"
                                                    using A40 xxreal_0_th_1 sorry
                                                  then have A51: "p .FUNCT-1K1 c >=XXREAL-0R2 r"
                                                    using A5 A1 A6 A14 A39 A50 rfinseq_th_19 sorry
                                                  have "r >=XXREAL-0R2 p .FUNCT-1K1 c"
                                                    using A5 A1 A6 A10 A35 A39 A47 A50 rfinseq_th_19 sorry
                                                  then have "r =HIDDENR1 p .FUNCT-1K1 c"
                                                    using A51 xxreal_0_th_1 sorry
                                                  then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                    using tarski_def_1 sorry
                                                  thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                    using A4 funct_1_def_7 sorry
                                                qed
                                                show " ?thesis "
                                                  using cases case1 case2 sorry
                                              qed
                                            qed
                                            thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                               sorry
                                          qed
                                          have case2: "c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                          proof(rule impI)
                                            assume "c inTARSKIR2 ?b .FUNCT-1K1 n"
                                            thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                              using A38 A40 A45 A48 finseq_3_th_25 nat_1_th_13 sorry
                                          qed
                                          show " ?thesis "
                                            using cases case1 case2 sorry
                                        qed
                                      qed
                                      thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                         sorry
                                    qed
                                    show " ?thesis "
                                      using cases case1 case2 sorry
                                  qed
                                qed
                                thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                   sorry
                              qed "sorry"
                              thus " ?thesis "
                                 sorry
                            qed
                            have A52: "?P(0NUMBERSK6)"
                              using finseq_3_th_25 sorry
                            have A53: " for n be NatNAT-1M1 holds ?P(n)"
                              using nat_1_sch_2 A52 A37 sorry
                            have "ma inTARSKIR2 domFINSEQ-1K5 ?b"
                              using A5 A1 A14 finseq_3_th_29 sorry
                            then have "cy inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                              using A36 A53 sorry
                            thus "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                               sorry
                          qed "sorry"
                          thus "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                            using tarski_def_3 sorry
                        qed
                        have " for y be objectHIDDENM1 holds y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} implies ( not y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma implies  False )"
                        proof(rule ballI,rule impI,rule impI)
                          fix y assume [ty]: "y be objectHIDDENM1"
                          assume A54: "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          then obtain cy where 
                            [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                             sorry
                          have "p .FUNCT-1K1 cy inTARSKIR2 {TARSKIK1 x}"
                            using A54 funct_1_def_7 sorry
                          then have A55: "p .FUNCT-1K1 cy =HIDDENR1 x"
                            using tarski_def_1 sorry
                          let ?Q = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b & ma <XXREAL-0R3 Lamb1) & cy inTARSKIR2 ?b .FUNCT-1K1 Lamb1"
                          assume A56: " not y inHIDDENR3 ?b .FUNCT-1K1 ma"
                          have A57: " ex n be NatNAT-1M1 st ?Q(n)"
                          proof-
                            have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n)"
                            proof-
                              obtain n where 
                                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 ?b"
                                 sorry
                              show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n)"
                              proof(rule bexI[of _ "n"],rule conjMI)
                                have "lenFINSEQ-1K4 ?b <>HIDDENR2 0NUMBERSK6"
                                  using rearran1_th_4 sorry
                                then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                  using nat_1_th_13 sorry
                                thus "n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B)"
                                  using finseq_3_th_25 sorry
                                have A58: "?b .FUNCT-1K1 n =XBOOLE-0R4 C"
                                  using rearran1_th_3 sorry
                                have "n <=XXREAL-0R1 ma implies  False "
                                proof(rule impI)
                                  assume "n <=XXREAL-0R1 ma"
                                  then have "ma =XBOOLE-0R4 lenFINSEQ-1K4 ?b"
                                    using A5 A1 A15 xxreal_0_th_1 sorry
                                  then have "cy inTARSKIR2 ?b .FUNCT-1K1 ma"
                                    using A58 sorry
                                  thus " False "
                                    using A56 sorry
                                qed
                                thus " not ma <XXREAL-0R3 n & cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n"
                                  using A58 sorry
                              qed "sorry"
                            qed
                            thus " ?thesis "
                               sorry
                          qed
                          obtain mm where
                            [ty]:"mm be NatNAT-1M1" and 
                            A59: "?Q(mm) & ( for n be NatNAT-1M1 holds ?Q(n) implies mm <=XXREAL-0R1 n)"
                            using nat_1_sch_5 A57 sorry
                          have "\<one>\<^sub>M <=XXREAL-0R1 mm"
                            using A59 finseq_3_th_25 sorry
                          then have "maxXXREAL-0K5(0NUMBERSK6,mm -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mm -XCMPLX-0K6 \<one>\<^sub>M"
                            using finseq_2_th_4 sorry
                          then obtain Om where 
                            [ty]:"Om be ElementSUBSET-1M1-of NATNUMBERSK1" and OmDef:"Om = mm -XCMPLX-0K6 \<one>\<^sub>M"
                            using finseq_2_th_5 sorry
                          have "ma +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mm"
                            using A59 nat_1_th_13 sorry
                          then have A60: "ma <=XXREAL-0R1 Om"
                            using xreal_1_th_19 sorry
                          then have A61: "\<one>\<^sub>M <=XXREAL-0R1 Om"
                            using A29 xxreal_0_th_2 sorry
                          have A62: "mm inTARSKIR2 domFINSEQ-1K5 ?fd"
                            using A5 A1 A59 finseq_3_th_29 sorry
                          have A63: "mm <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                            using A59 finseq_3_th_25 sorry
                          have A64: "mm <XXREAL-0R3 mm +NAT-1K1 \<one>\<^sub>M"
                            using nat_1_th_13 sorry
                          then have "Om <XXREAL-0R3 mm"
                            using xreal_1_th_19 sorry
                          then have A65: "Om <XXREAL-0R3 lenFINSEQ-1K4 ?b"
                            using A63 xxreal_0_th_2 sorry
                          have "Om <=XXREAL-0R1 mm"
                            using A64 xreal_1_th_19 sorry
                          then have "Om <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                            using A63 xxreal_0_th_2 sorry
                          then have A66: "Om inTARSKIR2 domFINSEQ-1K5 ?b"
                            using A61 finseq_3_th_25 sorry
                          have "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                          proof-
                            show "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                            proof-
                              have cases: "ma =XBOOLE-0R4 Om or ma <>HIDDENR2 Om"
                                 sorry
                              have case1: "ma =XBOOLE-0R4 Om implies  False "
                              proof(rule impI)
                                assume "ma =XBOOLE-0R4 Om"
                                then have "cy inTARSKIR2 ?b .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 Om"
                                  using A56 A59 xboole_0_def_5 sorry
                                then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                  using A2 A61 A65 rearran1_th_22 sorry
                                thus " False "
                                  using A14 A55 A59 A62 sorry
                              qed
                              have case2: "ma <>HIDDENR2 Om implies  False "
                              proof(rule impI)
                                assume "ma <>HIDDENR2 Om"
                                then have A67: "ma <XXREAL-0R3 Om"
                                  using A60 xxreal_0_th_1 sorry
                                have "cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 Om implies  False "
                                proof(rule impI)
                                  assume "cy inTARSKIR2 ?b .FUNCT-1K1 Om"
                                  then have "mm <=XXREAL-0R1 Om"
                                    using A59 A66 A67 sorry
                                  then have "mm -XCMPLX-0K6 Om <=XXREAL-0R1 0NUMBERSK6"
                                    using xreal_1_th_47 sorry
                                  thus " False "
                                     sorry
                                qed
                                then have "cy inTARSKIR2 ?b .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 Om"
                                  using A59 xboole_0_def_5 sorry
                                then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                  using A2 A61 A65 rearran1_th_22 sorry
                                thus " False "
                                  using A14 A55 A59 A62 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed "sorry"
                        thus "p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma"
                          using tarski_def_3 sorry
                      qed
                      thus "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        using xboole_0_def_10 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  thus "cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                    using A5 A1 A29 A15 A32 A35 rearran1_def_1 sorry
                qed
                have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                proof(rule impI)
                  assume A68: "mi <>HIDDENR2 \<one>\<^sub>M"
                  then have "\<one>\<^sub>M <XXREAL-0R3 mi"
                    using A11 xxreal_0_th_1 sorry
                  then have A69: "\<one>\<^sub>M <=XXREAL-0R1 m1"
                    using A12 nat_1_th_13 sorry
                  have A70: "m1 <=XXREAL-0R1 lenFINSEQ-1K4 ?fd"
                    using A33 A12 nat_1_th_13 sorry
                  then have A71: "m1 inTARSKIR2 domFINSEQ-1K5 ?b"
                    using A5 A1 A69 finseq_3_th_25 sorry
                  then have A72: "?b .FUNCT-1K1 m1 c=TARSKIR1 ?b .FUNCT-1K1 ma"
                    using A5 A1 A6 A14 A31 rearran1_th_2 sorry
                  have "?b .FUNCT-1K1 ma c=TARSKIR1 C"
                    using A5 A1 A6 A14 rearran1_lm_5 sorry
                  then obtain bma bm1 where 
                    [ty]:"bma be finiteFINSET-1V1\<bar>setHIDDENM2" and bmaDef:"bma = ?b .FUNCT-1K1 ma" and
                    [ty]:"bm1 be finiteFINSET-1V1\<bar>setHIDDENM2" and bm1Def:"bm1 = ?b .FUNCT-1K1 m1"
                    using A72 sorry
                  have "?b .FUNCT-1K1 ma \\SUBSET-1K6 ?b .FUNCT-1K1 m1 =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                  proof-
                    have "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    proof-
                      have "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} & p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1"
                      proof(rule conjMI)
                        show "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        proof-
                          let ?P = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b & mi <=XXREAL-0R1 Lamb1) & Lamb1 <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 ?b .FUNCT-1K1 Lamb1 \\SUBSET-1K6 ?b .FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                          have " for y be objectHIDDENM1 holds y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          proof(rule ballI,rule impI)
                            fix y assume [ty]: "y be objectHIDDENM1"
                            have A73: "?b .FUNCT-1K1 ma c=TARSKIR1 C"
                              using A5 A1 A6 A14 rearran1_lm_5 sorry
                            have A74: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
                            proof-
                              have " for n be NatNAT-1M1 holds ((n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & mi <=XXREAL-0R1 n) & n <=XXREAL-0R1 ma implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})) implies (n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & (mi <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma) implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}))"
                              proof(rule ballI,rule impI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
                                fix n assume [ty]: "n be NatNAT-1M1"
                                assume A75: "?P(n)"
                                assume A76: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?b"
                                  and A77: "mi <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                                  and A78: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 ma"
                                fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
                                have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                  using A76 finseq_3_th_25 sorry
                                then have A79: "n <XXREAL-0R3 lenFINSEQ-1K4 ?b"
                                  using nat_1_th_13 sorry
                                assume A80: "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                                have "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & (mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                proof-
                                  show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M & (mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                  proof-
                                    have cases: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi or mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
                                       sorry
                                    have case1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    proof(rule impI)
                                      assume A81: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 mi"
                                      then have "p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                        using A2 A69 A79 A80 rearran1_th_22 sorry
                                      then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                        using A10 A81 tarski_def_1 sorry
                                      thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                        using A4 funct_1_def_7 sorry
                                    qed
                                    have case2: "mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                    proof(rule impI)
                                      assume "mi <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
                                      then have A82: "mi <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                                        using A77 xxreal_0_th_1 sorry
                                      then have "mi <=XXREAL-0R1 n"
                                        using nat_1_th_13 sorry
                                      then have A83: "\<one>\<^sub>M <=XXREAL-0R1 n"
                                        using A11 xxreal_0_th_2 sorry
                                      have "n <=XXREAL-0R1 ma"
                                        using A78 nat_1_th_13 sorry
                                      then have A84: "n <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                        using A5 A1 A15 xxreal_0_th_2 sorry
                                      then have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n inTARSKIR2 domFINSEQ-1K5 ?b"
                                        using A83 finseq_3_th_25 nat_1_th_11 sorry
                                      then have "?b .FUNCT-1K1 n c=TARSKIR1 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                        using A76 rearran1_th_2 sorry
                                      then have A85: "?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m1 =HIDDENR1 (?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\/XBOOLE-0K2 ?b .FUNCT-1K1 n)\\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                                        using xboole_1_th_12 sorry
                                      also have "... = ((?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\/XBOOLE-0K2 ?b .FUNCT-1K1 n)\\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                                        using xboole_1_th_39 sorry
                                      also have "... = ((?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> ?b .FUNCT-1K1 m1)\\/XBOOLE-0K2 (?b .FUNCT-1K1 n \\SUBSET-1K6 ?b .FUNCT-1K1 m1)"
                                        using xboole_1_th_42 sorry
                                      finally have "?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m1 =HIDDENR1 ((?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> ?b .FUNCT-1K1 m1)\\/XBOOLE-0K2 (?b .FUNCT-1K1 n \\SUBSET-1K6 ?b .FUNCT-1K1 m1)"
                                         sorry
                                      have "c inTARSKIR2 (?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> ?b .FUNCT-1K1 m1 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 ?b .FUNCT-1K1 n \\SUBSET-1K6 ?b .FUNCT-1K1 m1 & (c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                      proof-
                                        show "c inTARSKIR2 (?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> ?b .FUNCT-1K1 m1 & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or c inTARSKIR2 ?b .FUNCT-1K1 n \\SUBSET-1K6 ?b .FUNCT-1K1 m1 & (c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                        proof-
                                          have cases: "c inTARSKIR2 (?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> ?b .FUNCT-1K1 m1 or c inTARSKIR2 ?b .FUNCT-1K1 n \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                                            using A80 A85 xboole_0_def_3 sorry
                                          have case1: "c inTARSKIR2 ((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                          proof(rule impI)
                                            assume "c inTARSKIR2 (?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n)\\SUBSET-1K7\<^bsub>((Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))\<^esub> ?b .FUNCT-1K1 m1"
                                            then have "c inTARSKIR2 ?b .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 n"
                                              using xboole_0_def_5 sorry
                                            then have A86: "p .FUNCT-1K1 c =XBOOLE-0R4 ?fd .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                                              using A2 A79 A83 rearran1_th_22 sorry
                                            have "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                            proof-
                                              show "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma & c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma & (n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                                              proof-
                                                have cases: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma or n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                   sorry
                                                have case1: "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                proof(rule impI)
                                                  assume "n +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 ma"
                                                  then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                    using A14 A86 tarski_def_1 sorry
                                                  thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                    using A4 funct_1_def_7 sorry
                                                qed
                                                have case2: "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                proof(rule impI)
                                                  assume "n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 ma"
                                                  then have "n +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 ma"
                                                    using A78 xxreal_0_th_1 sorry
                                                  then have A87: "p .FUNCT-1K1 c >=XXREAL-0R2 r"
                                                    using A5 A1 A6 A14 A76 A86 rfinseq_th_19 sorry
                                                  have "r >=XXREAL-0R2 p .FUNCT-1K1 c"
                                                    using A5 A1 A6 A10 A76 A82 A86 rfinseq_th_19 sorry
                                                  then have "r =HIDDENR1 p .FUNCT-1K1 c"
                                                    using A87 xxreal_0_th_1 sorry
                                                  then have "p .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 x}"
                                                    using tarski_def_1 sorry
                                                  thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                                    using A4 funct_1_def_7 sorry
                                                qed
                                                show " ?thesis "
                                                  using cases case1 case2 sorry
                                              qed
                                            qed
                                            thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                               sorry
                                          qed
                                          have case2: "c inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                          proof(rule impI)
                                            assume "c inTARSKIR2 ?b .FUNCT-1K1 n \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                                            thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                              using A75 A78 A82 A83 A84 finseq_3_th_25 nat_1_th_13 sorry
                                          qed
                                          show " ?thesis "
                                            using cases case1 case2 sorry
                                        qed
                                      qed
                                      thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                         sorry
                                    qed
                                    show " ?thesis "
                                      using cases case1 case2 sorry
                                  qed
                                qed
                                thus "c inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                                   sorry
                              qed "sorry"
                              thus " ?thesis "
                                 sorry
                            qed
                            have A88: "?P(0NUMBERSK6)"
                               sorry
                            have A89: " for n be NatNAT-1M1 holds ?P(n)"
                              using nat_1_sch_2 A88 A74 sorry
                            assume A90: "y inHIDDENR3 ?b .FUNCT-1K1 ma \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                            then have "y inHIDDENR3 ?b .FUNCT-1K1 ma"
                               sorry
                            then obtain cy where 
                              [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                              using A73 sorry
                            have "ma inTARSKIR2 domFINSEQ-1K5 ?b"
                              using A5 A1 A14 finseq_3_th_29 sorry
                            then have "cy inTARSKIR2 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                              using A30 A90 A89 sorry
                            thus "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                               sorry
                          qed "sorry"
                          thus "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 c=TARSKIR1 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                            using tarski_def_3 sorry
                        qed
                        have " for y be objectHIDDENM1 holds y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} implies ( not y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies  False )"
                        proof(rule ballI,rule impI,rule impI)
                          fix y assume [ty]: "y be objectHIDDENM1"
                          assume A91: "y inHIDDENR3 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                          then obtain cy where 
                            [ty]:"cy be ElementSUBSET-1M1-of C" and cyDef:"cy = y"
                             sorry
                          have "p .FUNCT-1K1 cy inTARSKIR2 {TARSKIK1 x}"
                            using A91 funct_1_def_7 sorry
                          then have A92: "p .FUNCT-1K1 cy =HIDDENR1 x"
                            using tarski_def_1 sorry
                          assume A93: " not y inHIDDENR3 ?b .FUNCT-1K1 ma \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
                          have " not y inHIDDENR3 ?b .FUNCT-1K1 ma &  False  or y inHIDDENR3 ?b .FUNCT-1K1 m1 & (y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies  False )"
                          proof-
                            show " not y inHIDDENR3 ?b .FUNCT-1K1 ma &  False  or y inHIDDENR3 ?b .FUNCT-1K1 m1 & (y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies  False )"
                            proof-
                              have cases: " not y inHIDDENR3 ?b .FUNCT-1K1 ma or y inHIDDENR3 ?b .FUNCT-1K1 m1"
                                using A93 xboole_0_def_5 sorry
                              have case1: " not y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma implies  False "
                              proof(rule impI)
                                assume A94: " not y inHIDDENR3 ?b .FUNCT-1K1 ma"
                                let ?Q = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b & ma <XXREAL-0R3 Lamb1) & cy inTARSKIR2 ?b .FUNCT-1K1 Lamb1"
                                have A95: " ex n be NatNAT-1M1 st ?Q(n)"
                                proof-
                                  have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n)"
                                  proof-
                                    obtain n where 
                                      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 ?b"
                                       sorry
                                    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) & ( not ma <XXREAL-0R3 n & cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n)"
                                    proof(rule bexI[of _ "n"],rule conjMI)
                                      have "lenFINSEQ-1K4 ?b <>HIDDENR2 0NUMBERSK6"
                                        using rearran1_th_4 sorry
                                      then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                        using nat_1_th_13 sorry
                                      thus "n inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B)"
                                        using finseq_3_th_25 sorry
                                      have A96: "?b .FUNCT-1K1 n =XBOOLE-0R4 C"
                                        using rearran1_th_3 sorry
                                      have "n <=XXREAL-0R1 ma implies  False "
                                      proof(rule impI)
                                        assume "n <=XXREAL-0R1 ma"
                                        then have "ma =XBOOLE-0R4 lenFINSEQ-1K4 ?b"
                                          using A5 A1 A15 xxreal_0_th_1 sorry
                                        then have "cy inTARSKIR2 ?b .FUNCT-1K1 ma"
                                          using A96 sorry
                                        thus " False "
                                          using A94 sorry
                                      qed
                                      thus " not ma <XXREAL-0R3 n & cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n"
                                        using A96 sorry
                                    qed "sorry"
                                  qed
                                  thus " ?thesis "
                                     sorry
                                qed
                                obtain mm where
                                  [ty]:"mm be NatNAT-1M1" and 
                                  A97: "?Q(mm) & ( for n be NatNAT-1M1 holds ?Q(n) implies mm <=XXREAL-0R1 n)"
                                  using nat_1_sch_5 A95 sorry
                                have "\<one>\<^sub>M <=XXREAL-0R1 mm"
                                  using A97 finseq_3_th_25 sorry
                                then have "maxXXREAL-0K5(0NUMBERSK6,mm -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mm -XCMPLX-0K6 \<one>\<^sub>M"
                                  using finseq_2_th_4 sorry
                                then obtain Om where 
                                  [ty]:"Om be ElementSUBSET-1M1-of NATNUMBERSK1" and OmDef:"Om = mm -XCMPLX-0K6 \<one>\<^sub>M"
                                  using finseq_2_th_5 sorry
                                have "ma +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mm"
                                  using A97 nat_1_th_13 sorry
                                then have A98: "ma <=XXREAL-0R1 Om"
                                  using xreal_1_th_19 sorry
                                then have A99: "\<one>\<^sub>M <=XXREAL-0R1 Om"
                                  using A29 xxreal_0_th_2 sorry
                                have A100: "mm inTARSKIR2 domFINSEQ-1K5 ?fd"
                                  using A5 A1 A97 finseq_3_th_29 sorry
                                have A101: "mm <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                  using A97 finseq_3_th_25 sorry
                                have A102: "mm <XXREAL-0R3 mm +NAT-1K1 \<one>\<^sub>M"
                                  using nat_1_th_13 sorry
                                then have "Om <XXREAL-0R3 mm"
                                  using xreal_1_th_19 sorry
                                then have A103: "Om <XXREAL-0R3 lenFINSEQ-1K4 ?b"
                                  using A101 xxreal_0_th_2 sorry
                                have "Om <=XXREAL-0R1 mm"
                                  using A102 xreal_1_th_19 sorry
                                then have "Om <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                  using A101 xxreal_0_th_2 sorry
                                then have A104: "Om inTARSKIR2 domFINSEQ-1K5 ?b"
                                  using A99 finseq_3_th_25 sorry
                                have "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                                proof-
                                  show "ma =XBOOLE-0R4 Om &  False  or ma <>HIDDENR2 Om & (ma <>HIDDENR2 Om implies  False )"
                                  proof-
                                    have cases: "ma =XBOOLE-0R4 Om or ma <>HIDDENR2 Om"
                                       sorry
                                    have case1: "ma =XBOOLE-0R4 Om implies  False "
                                    proof(rule impI)
                                      assume "ma =XBOOLE-0R4 Om"
                                      then have "cy inTARSKIR2 ?b .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 Om"
                                        using A94 A97 xboole_0_def_5 sorry
                                      then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                        using A2 A99 A103 rearran1_th_22 sorry
                                      thus " False "
                                        using A14 A92 A97 A100 sorry
                                    qed
                                    have case2: "ma <>HIDDENR2 Om implies  False "
                                    proof(rule impI)
                                      assume "ma <>HIDDENR2 Om"
                                      then have A105: "ma <XXREAL-0R3 Om"
                                        using A98 xxreal_0_th_1 sorry
                                      have "cy inTARSKIR2 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 Om implies  False "
                                      proof(rule impI)
                                        assume "cy inTARSKIR2 ?b .FUNCT-1K1 Om"
                                        then have "mm <=XXREAL-0R1 Om"
                                          using A97 A104 A105 sorry
                                        then have "mm -XCMPLX-0K6 Om <=XXREAL-0R1 0NUMBERSK6"
                                          using xreal_1_th_47 sorry
                                        thus " False "
                                           sorry
                                      qed
                                      then have "cy inTARSKIR2 ?b .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 Om"
                                        using A97 xboole_0_def_5 sorry
                                      then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 mm"
                                        using A2 A99 A103 rearran1_th_22 sorry
                                      thus " False "
                                        using A14 A92 A97 A100 sorry
                                    qed
                                    show " ?thesis "
                                      using cases case1 case2 sorry
                                  qed
                                qed
                                thus " False "
                                   sorry
                              qed
                              have case2: "y inHIDDENR3 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 implies  False "
                              proof(rule impI)
                                assume A106: "y inHIDDENR3 ?b .FUNCT-1K1 m1"
                                let ?Q = "\<lambda>Lamb1. (Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b & Lamb1 <=XXREAL-0R1 m1) & cy inTARSKIR2 ?b .FUNCT-1K1 Lamb1"
                                have A107: " ex n be NatNAT-1M1 st ?Q(n)"
                                  using A71 A106 sorry
                                obtain mm where
                                  [ty]:"mm be NatNAT-1M1" and 
                                  A108: "?Q(mm) & ( for n be NatNAT-1M1 holds ?Q(n) implies mm <=XXREAL-0R1 n)"
                                  using nat_1_sch_5 A107 sorry
                                have A109: "\<one>\<^sub>M <=XXREAL-0R1 mm"
                                  using A108 finseq_3_th_25 sorry
                                then have "maxXXREAL-0K5(0NUMBERSK6,mm -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mm -XCMPLX-0K6 \<one>\<^sub>M"
                                  using finseq_2_th_4 sorry
                                then obtain Om where 
                                  [ty]:"Om be ElementSUBSET-1M1-of NATNUMBERSK1" and OmDef:"Om = mm -XCMPLX-0K6 \<one>\<^sub>M"
                                  using finseq_2_th_5 sorry
                                have A110: "mm <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                  using A108 finseq_3_th_25 sorry
                                have A111: "mm inTARSKIR2 domFINSEQ-1K5 ?fd"
                                  using A5 A1 A108 finseq_3_th_29 sorry
                                have "mm =XBOOLE-0R4 \<one>\<^sub>M &  False  or mm <>HIDDENR2 \<one>\<^sub>M & (mm <>HIDDENR2 \<one>\<^sub>M implies  False )"
                                proof-
                                  show "mm =XBOOLE-0R4 \<one>\<^sub>M &  False  or mm <>HIDDENR2 \<one>\<^sub>M & (mm <>HIDDENR2 \<one>\<^sub>M implies  False )"
                                  proof-
                                    have cases: "mm =XBOOLE-0R4 \<one>\<^sub>M or mm <>HIDDENR2 \<one>\<^sub>M"
                                       sorry
                                    have case1: "mm =XBOOLE-0R4 \<one>\<^sub>M implies  False "
                                    proof(rule impI)
                                      assume "mm =XBOOLE-0R4 \<one>\<^sub>M"
                                      then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 \<one>\<^sub>M"
                                        using A2 A108 rearran1_th_22 sorry
                                      then have "mi <=XXREAL-0R1 \<one>\<^sub>M"
                                        using A10 A34 A92 sorry
                                      thus " False "
                                        using A11 A68 xxreal_0_th_1 sorry
                                    qed
                                    have case2: "mm <>HIDDENR2 \<one>\<^sub>M implies  False "
                                    proof(rule impI)
                                      assume "mm <>HIDDENR2 \<one>\<^sub>M"
                                      then have "\<one>\<^sub>M <XXREAL-0R3 mm"
                                        using A109 xxreal_0_th_1 sorry
                                      then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mm"
                                        using nat_1_th_13 sorry
                                      then have A112: "\<one>\<^sub>M <=XXREAL-0R1 Om"
                                        using xreal_1_th_19 sorry
                                      have A113: "mm <XXREAL-0R3 mm +NAT-1K1 \<one>\<^sub>M"
                                        using nat_1_th_13 sorry
                                      then have A114: "Om <=XXREAL-0R1 mm"
                                        using xreal_1_th_19 sorry
                                      then have "Om <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
                                        using A110 xxreal_0_th_2 sorry
                                      then have A115: "Om inTARSKIR2 domFINSEQ-1K5 ?b"
                                        using A112 finseq_3_th_25 sorry
                                      have A116: "Om <XXREAL-0R3 mm"
                                        using A113 xreal_1_th_19 sorry
                                      then have A117: "Om <XXREAL-0R3 lenFINSEQ-1K4 ?b"
                                        using A110 xxreal_0_th_2 sorry
                                      have "Om <=XXREAL-0R1 m1"
                                        using A108 A114 xxreal_0_th_2 sorry
                                      then have " not cy inTARSKIR2 ?b .FUNCT-1K1 Om"
                                        using A108 A116 A115 sorry
                                      then have "cy inTARSKIR2 ?b .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 Om"
                                        using A108 xboole_0_def_5 sorry
                                      then have "p .FUNCT-1K1 cy =XBOOLE-0R4 ?fd .FUNCT-1K1 (Om +NAT-1K1 \<one>\<^sub>M)"
                                        using A2 A112 A117 rearran1_th_22 sorry
                                      then have "mi <=XXREAL-0R1 mm"
                                        using A10 A92 A111 sorry
                                      then have "m1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m1"
                                        using A108 xxreal_0_th_2 sorry
                                      then have "\<one>\<^sub>M <=XXREAL-0R1 m1 -XCMPLX-0K6 m1"
                                        using xreal_1_th_19 sorry
                                      then have "\<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
                                         sorry
                                      thus " False "
                                         sorry
                                    qed
                                    show " ?thesis "
                                      using cases case1 case2 sorry
                                  qed
                                qed
                                thus " False "
                                   sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed "sorry"
                        thus "p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x} c=TARSKIR1 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1"
                          using tarski_def_3 sorry
                      qed
                      thus "(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 ma \\SUBSET-1K6 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m1 =XBOOLE-0R4 p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                        using xboole_0_def_10 sorry
                    qed
                    thus " ?thesis "
                       sorry
                  qed
                  then have "cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 bma -XCMPLX-0K6 cardCARD-1K4 bm1"
                    using A72 card_2_th_44 sorry
                  also have "... = ma -XCMPLX-0K6 cardCARD-1K4 bm1"
                    using A5 A1 A29 A15 rearran1_def_1 sorry
                  also have "... = cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                    using A5 A1 A32 A69 A70 rearran1_def_1 sorry
                  finally show "cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "cardCARD-1K4 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 cardCARD-1K4 (p \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 x})"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(p,x))"
         sorry
    qed "sorry"
    thus "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using classes1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_25:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A2: "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using rearran1_th_24 sorry
    have A3: "domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) =XBOOLE-0R4 C"
      using A1 rearran1_th_21 sorry
    then have "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using A2 A3 rfunct_3_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_26:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using rearran1_th_25 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_27:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using relat_1_th_68 sorry
    then have A4: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),F)are-fiberwise-equipotentCLASSES1R2"
      using A3 rfunct_3_def_13 sorry
    have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_24 sorry
    then have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),F)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    then have A5: "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_51 sorry
    have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
      using valued_1_th_3 sorry
    then have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
      using relat_1_th_68 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C),RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using A6 rfunct_3_def_13 sorry
    then have A7: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C),F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_76 sorry
    have A8: "domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using valued_1_th_3 sorry
    then have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
      using A8 A7 rfunct_3_def_13 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_28:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    then have A2: "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,D) & (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using rearran1_th_19 rearran1_th_24 sorry
    have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D)"
      using A1 rearran1_th_17 rearran1_th_18 sorry
    thus "((RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)"
      using A1 A2 rearran1_th_25 rearran1_th_26 classes1_th_76 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_29:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    let ?mp = "max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
    let ?mf = "max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using relat_1_th_68 sorry
    then have A4: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),F)are-fiberwise-equipotentCLASSES1R2"
      using A3 rfunct_3_def_13 sorry
    have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_17 sorry
    then have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),F)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    then have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_51 sorry
    thus A5: "(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_41 sorry
    have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> ?mp =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_10 sorry
    then have "?mp  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ?mp"
      using relat_1_th_68 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mp)are-fiberwise-equipotentCLASSES1R2"
      using A6 rfunct_3_def_13 sorry
    then have A7: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mf)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_76 sorry
    have A8: "domRELSET-1K1\<^bsub>(D)\<^esub> ?mf =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_10 sorry
    then have "?mf  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?mf"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using A8 A7 rfunct_3_def_13 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_30:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    let ?mp = "max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
    let ?mf = "max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using relat_1_th_68 sorry
    then have A4: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),F)are-fiberwise-equipotentCLASSES1R2"
      using A3 rfunct_3_def_13 sorry
    have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_17 sorry
    then have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),F)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    then have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_51 sorry
    thus A5: "(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_42 sorry
    have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> ?mp =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_11 sorry
    then have "?mp  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ?mp"
      using relat_1_th_68 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mp)are-fiberwise-equipotentCLASSES1R2"
      using A6 rfunct_3_def_13 sorry
    then have A7: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mf)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_76 sorry
    have A8: "domRELSET-1K1\<^bsub>(D)\<^esub> ?mf =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_11 sorry
    then have "?mf  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?mf"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using A8 A7 rfunct_3_def_13 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_31:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C) =XBOOLE-0R4 cardCARD-1K4 C & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =XBOOLE-0R4 cardCARD-1K4 C & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    let ?p = "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
    assume "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C"
    then have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
      using rearran1_th_13 sorry
    then have A2: "?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ?p"
      using relat_1_th_68 sorry
    thus "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C) =XBOOLE-0R4 cardCARD-1K4 C"
      using A1 rfunct_3_th_67 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 cardCARD-1K4 C"
      using nat_1_th_13 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)"
      using A1 A2 rfunct_3_th_67 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_32:
" for n be NatNAT-1M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds (F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C) & n inTARSKIR2 domFINSEQ-1K5 A implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),A .FUNCT-1K1 n)"
proof-
  have " for n be NatNAT-1M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds (F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C) & n inTARSKIR2 domFINSEQ-1K5 B implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 n)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C"
      and A2: "n inTARSKIR2 domFINSEQ-1K5 B"
    let ?p = "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B)"
    have A3: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) =XBOOLE-0R4 cardCARD-1K4 C"
      using A1 rearran1_th_31 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 B implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 Lamb1)"
    have A4: "lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 C"
      using rearran1_th_1 sorry
    have A5: "domFINSEQ-1K5 B =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 B) & domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C))"
      using finseq_1_def_3 sorry
    have A6: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds (m inTARSKIR2 domFINSEQ-1K5 B implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 m)) implies (m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 B implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
      proof(rule ballI,rule impI,rule impI)
        let ?f = "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A7: "?P(m)"
        have A8: "m <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        assume A9: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 B"
        then have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using finseq_3_th_25 sorry
        then have A10: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_1 sorry
        have A11: "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
          using A1 rearran1_th_13 sorry
        have A12: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 B"
          using A9 finseq_3_th_25 sorry
        then have A13: "m <=XXREAL-0R1 lenFINSEQ-1K4 B"
          using nat_1_th_13 sorry
        have A14: "m <XXREAL-0R3 lenFINSEQ-1K4 B"
          using A12 nat_1_th_13 sorry
        have A15: "m <=XXREAL-0R1 lenFINSEQ-1K4 B -XCMPLX-0K6 \<one>\<^sub>M"
          using A12 xreal_1_th_19 sorry
        have A16: "lenFINSEQ-1K4 (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
          using A4 A3 A12 finseq_1_th_59 sorry
        have "m =XBOOLE-0R4 0NUMBERSK6 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)) or m <>HIDDENR2 0NUMBERSK6 & (m <>HIDDENR2 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
        proof-
          show "m =XBOOLE-0R4 0NUMBERSK6 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)) or m <>HIDDENR2 0NUMBERSK6 & (m <>HIDDENR2 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
          proof-
            have cases: "m =XBOOLE-0R4 0NUMBERSK6 or m <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "m =XBOOLE-0R4 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
            proof(rule impI)
              assume A17: "m =XBOOLE-0R4 0NUMBERSK6"
              obtain d where
                [ty]:"d be ElementSUBSET-1M1-of C" and 
                A18: "B .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 d}"
                using rearran1_th_9 sorry
              have A19: "d inTARSKIR2 B .FUNCT-1K1 \<one>\<^sub>M"
                using A18 tarski_def_1 sorry
              have A20: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)"
                using A1 rearran1_th_31 sorry
              then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M & \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)"
                using finseq_1_th_1 finseq_3_th_25 sorry
              then have A21: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) .FUNCT-1K1 \<one>\<^sub>M"
                using A17 rfinseq_th_6 sorry
              also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
                using A1 rearran1_th_18 sorry
              also have "... = ?p .FUNCT-1K1 d"
                using A1 A19 rearran1_th_15 sorry
              finally have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ?p .FUNCT-1K1 d"
                 sorry
              have "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
                using A1 rearran1_th_13 sorry
              then have A22: "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)) =FINSEQ-1R1 <*FINSEQ-1K10 ?p .FUNCT-1K1 d*>"
                using A17 A18 rfunct_3_th_69 sorry
              have "lenFINSEQ-1K4 (FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 \<one>\<^sub>M"
                using A17 A20 finseq_1_th_59 sorry
              thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
                using A22 A21 finseq_1_th_40 sorry
            qed
            have case2: "m <>HIDDENR2 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
            proof(rule impI)
              assume A23: "m <>HIDDENR2 0NUMBERSK6"
              have A24: "SegFINSEQ-1K2 m c=MEMBEREDR6 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
                using A8 finseq_1_th_5 sorry
              have A25: "(?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 m"
                using finseq_1_def_15 sorry
              also have "... = (?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 m"
                using finseq_1_def_15 sorry
              also have "... = ?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m)"
                using relat_1_th_71 sorry
              also have "... = ?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 m"
                using A24 xboole_1_th_28 sorry
              also have "... = ?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m"
                using finseq_1_def_15 sorry
              finally have "(?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 ?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m"
                 sorry
              have A26: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
                using A23 nat_1_th_13 sorry
              then obtain d where
                [ty]:"d be ElementSUBSET-1M1-of C" and 
                A27: "B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m =XBOOLE-0R4 {TARSKIK1 d}"and "B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 B .FUNCT-1K1 m \\/XBOOLE-0K2 {TARSKIK1 d}"and A28: "B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 d} =XBOOLE-0R4 B .FUNCT-1K1 m"
                using A15 rearran1_th_10 sorry
              have A29: "d inTARSKIR2 {TARSKIK1 d}"
                using tarski_def_1 sorry
              then have "?p .FUNCT-1K1 d =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A1 A14 A26 A27 rearran1_th_15 sorry
              also have "... = FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A1 rearran1_th_18 sorry
              also have "... = (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A5 A4 A3 A9 A10 rfinseq_th_6 sorry
              finally have "?p .FUNCT-1K1 d =HIDDENR1 (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              then have A30: "?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 ?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m ^FINSEQ-1K8 (<*FINSEQ-1K10 ?p .FUNCT-1K1 d*>)"
                using A16 A25 rfinseq_th_7 sorry
              have "d inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ?p /\\SUBSET-1K8\<^bsub>(C)\<^esub> B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A11 A27 A29 xboole_0_def_4 sorry
              then have A31: "d inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
                using relat_1_th_61 sorry
              have A32: "?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) be non-increasingRFINSEQV1"
                using rfinseq_th_20 sorry
              have A33: "domRELSET-1K1\<^bsub>(C)\<^esub> (?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ?p /\\SUBSET-1K8\<^bsub>(C)\<^esub> B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using relat_1_th_61 sorry
              also have "... = B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A9 A11 rearran1_lm_5 xboole_1_th_28 sorry
              finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))) =HIDDENR1 B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have "B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) be finiteFINSET-1V1"
                using A9 rearran1_lm_5 finset_1_th_1 sorry
              then have "(?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M),?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))are-fiberwise-equipotentCLASSES1R2"
                using A7 A13 A26 A28 A30 A31 finseq_3_th_25 rfunct_3_th_65 sorry
              thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
                using A33 A32 rfunct_3_def_13 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A34: "?P(0NUMBERSK6)"
      using finseq_3_th_25 sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A34 A6 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B),B .FUNCT-1K1 n)"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_33:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,A) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C"
    have A3: "domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) =XBOOLE-0R4 C"
      using A1 A2 rearran1_th_13 sorry
    have A4: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have A5: "domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 D"
      using valued_1_th_3 sorry
    then have A6: "F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      using partfun1_def_2 sorry
    have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r"
      using A5 relat_1_th_68 sorry
    then have A7: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) =XBOOLE-0R4 cardCARD-1K4 D"
      using A5 rfunct_3_th_67 sorry
    have A8: "lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 C"
      using rearran1_th_1 sorry
    obtain rr where 
      [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r"
      using xreal_0_def_1 sorry
    have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using A4 relat_1_th_68 sorry
    then have A9: "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) -RVSUM-1K9 cardCARD-1K4 D  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr"
      using A4 rfunct_3_th_73 sorry
    have A10: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B)"
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 B & c inTARSKIR2 B .FUNCT-1K1 Lamb1"
      have A11: "C =XBOOLE-0R4 B .FUNCT-1K1 lenFINSEQ-1K4 B"
        using rearran1_th_3 sorry
      have "lenFINSEQ-1K4 B <>HIDDENR2 0NUMBERSK6"
        using rearran1_th_4 sorry
      then have A12: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 B"
        using nat_1_th_13 sorry
      then have A13: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 B"
        using finseq_3_th_25 sorry
      have "lenFINSEQ-1K4 B inTARSKIR2 domFINSEQ-1K5 B"
        using A12 finseq_3_th_25 sorry
      then have A14: " ex n be NatNAT-1M1 st ?P(n)"
        using A11 sorry
      obtain mi where
        [ty]:"mi be NatNAT-1M1" and 
        A15: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
        using nat_1_sch_5 A14 sorry
      have A16: "\<one>\<^sub>M <=XXREAL-0R1 mi"
        using A15 finseq_3_th_25 sorry
      then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_4 sorry
      then obtain m1 where 
        [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_5 sorry
      have A17: "mi <=XXREAL-0R1 lenFINSEQ-1K4 B"
        using A15 finseq_3_th_25 sorry
      have A18: "mi <XXREAL-0R3 mi +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      then have "m1 <XXREAL-0R3 mi"
        using xreal_1_th_19 sorry
      then have A19: "m1 <XXREAL-0R3 lenFINSEQ-1K4 B"
        using A17 xxreal_0_th_2 sorry
      have "m1 <=XXREAL-0R1 mi"
        using A18 xreal_1_th_19 sorry
      then have A20: "m1 <=XXREAL-0R1 lenFINSEQ-1K4 B"
        using A17 xxreal_0_th_2 sorry
      have "mi =XBOOLE-0R4 \<one>\<^sub>M & RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c)"
      proof-
        show "mi =XBOOLE-0R4 \<one>\<^sub>M & RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c)"
        proof-
          have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
             sorry
          have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
          proof(rule impI)
            assume A21: "mi =XBOOLE-0R4 \<one>\<^sub>M"
            have A22: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
              using A2 A7 A8 A12 finseq_3_th_25 sorry
            have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (cardCARD-1K4 D)"
              using A2 A8 A13 finseq_1_def_3 sorry
            then have A23: "(cardCARD-1K4 D  |->FINSEQ-2K2 r).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 r"
              using funcop_1_th_7 sorry
            have "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) .FUNCT-1K1 \<one>\<^sub>M & RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
              using A1 A2 A6 A15 A21 rearran1_th_15 sorry
            then have "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c -XCMPLX-0K6 r"
              using A9 A22 A23 valued_1_th_13 sorry
            also have "... = (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
              using A3 valued_1_th_3 sorry
            finally show "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
               sorry
          qed
          have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
          proof(rule impI)
            assume "mi <>HIDDENR2 \<one>\<^sub>M"
            then have "\<one>\<^sub>M <XXREAL-0R3 mi"
              using A16 xxreal_0_th_1 sorry
            then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mi"
              using nat_1_th_13 sorry
            then have A24: "\<one>\<^sub>M <=XXREAL-0R1 m1"
              using xreal_1_th_19 sorry
            then have "m1 inTARSKIR2 domFINSEQ-1K5 B"
              using A20 finseq_3_th_25 sorry
            then have " not c inTARSKIR2 B .FUNCT-1K1 m1"
              using A15 xreal_1_th_44 sorry
            then have "c inTARSKIR2 B .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 B .FUNCT-1K1 m1"
              using A15 xboole_0_def_5 sorry
            then have A25: "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) & RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
              using A1 A2 A6 A19 A24 rearran1_th_15 sorry
            have "m1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (cardCARD-1K4 D)"
              using A2 A8 A15 finseq_1_def_3 sorry
            then have A26: "(cardCARD-1K4 D  |->FINSEQ-2K2 r).FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 r"
              using funcop_1_th_7 sorry
            have "m1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
              using A2 A7 A8 A15 finseq_3_th_29 sorry
            then have "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c -XCMPLX-0K6 r"
              using A9 A25 A26 valued_1_th_13 sorry
            also have "... = (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
              using A3 valued_1_th_3 sorry
            finally show "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 C"
      using A3 valued_1_th_3 sorry
    thus "RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
      using A2 A6 A10 rearran1_th_13 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_34:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    let ?mp = "max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
    let ?mf = "max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using relat_1_th_68 sorry
    then have A4: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),F)are-fiberwise-equipotentCLASSES1R2"
      using A3 rfunct_3_def_13 sorry
    have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_24 sorry
    then have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),F)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    then have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_51 sorry
    thus A5: "(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_41 sorry
    have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> ?mp =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_10 sorry
    then have "?mp  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ?mp"
      using relat_1_th_68 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mp)are-fiberwise-equipotentCLASSES1R2"
      using A6 rfunct_3_def_13 sorry
    then have A7: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mf)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_76 sorry
    have A8: "domRELSET-1K1\<^bsub>(D)\<^esub> ?mf =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_10 sorry
    then have "?mf  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?mf"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using A8 A7 rfunct_3_def_13 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max+RFUNCT-3K18\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_35:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies ((max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D implies (max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D) & SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 C =XBOOLE-0R4 cardCARD-1K4 D"
    let ?mp = "max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
    let ?mf = "max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using relat_1_th_68 sorry
    then have A4: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),F)are-fiberwise-equipotentCLASSES1R2"
      using A3 rfunct_3_def_13 sorry
    have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_24 sorry
    then have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),F)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    then have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_51 sorry
    thus A5: "(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r))are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_th_42 sorry
    have A6: "domRELSET-1K1\<^bsub>(C)\<^esub> ?mp =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_11 sorry
    then have "?mp  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ?mp"
      using relat_1_th_68 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mp)are-fiberwise-equipotentCLASSES1R2"
      using A6 rfunct_3_def_13 sorry
    then have A7: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?mp,C),?mf)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_76 sorry
    have A8: "domRELSET-1K1\<^bsub>(D)\<^esub> ?mf =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
      using rfunct_3_def_11 sorry
    then have "?mf  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?mf"
      using relat_1_th_68 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using A8 A7 rfunct_3_def_13 sorry
    then have "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
      using rfunct_3_def_14 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(C)\<^esub>(max-RFUNCT-3K19\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r),C) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r),D)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_36:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C) =XBOOLE-0R4 cardCARD-1K4 C & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =XBOOLE-0R4 cardCARD-1K4 C & \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    let ?p = "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
    assume "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C"
    then have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
      using rearran1_th_21 sorry
    then have A2: "?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> C =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> ?p"
      using relat_1_th_68 sorry
    thus "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C) =XBOOLE-0R4 cardCARD-1K4 C"
      using A1 rfunct_3_th_67 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 cardCARD-1K4 C"
      using nat_1_th_13 sorry
    thus "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)"
      using A1 A2 rfunct_3_th_67 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_37:
" for n be NatNAT-1M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds (F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C) & n inTARSKIR2 domFINSEQ-1K5 A implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> A).FUNCT-1K1 n)"
proof-
  have " for n be NatNAT-1M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds (F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C) & n inTARSKIR2 domFINSEQ-1K5 B implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C"
      and A2: "n inTARSKIR2 domFINSEQ-1K5 B"
    let ?p = "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B)"
    let ?b = "Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B"
    have A3: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) =XBOOLE-0R4 cardCARD-1K4 C"
      using A1 rearran1_th_36 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),?b .FUNCT-1K1 Lamb1)"
    have A4: "domFINSEQ-1K5 ?b =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?b)"
      using finseq_1_def_3 sorry
    have A5: "lenFINSEQ-1K4 ?b =XBOOLE-0R4 cardCARD-1K4 C"
      using rearran1_th_1 sorry
    have A6: "domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C))"
      using finseq_1_def_3 sorry
    have A7: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds (m inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 m)) implies (m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B) implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
      proof(rule ballI,rule impI,rule impI)
        let ?f = "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A8: "?P(m)"
        have A9: "m <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        assume A10: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?b"
        then have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using finseq_3_th_25 sorry
        then have A11: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_th_1 sorry
        have A12: "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
          using A1 rearran1_th_21 sorry
        have A13: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
          using A10 finseq_3_th_25 sorry
        then have A14: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
          using nat_1_th_13 sorry
        have A15: "m <XXREAL-0R3 lenFINSEQ-1K4 ?b"
          using A13 nat_1_th_13 sorry
        have A16: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?b -XCMPLX-0K6 \<one>\<^sub>M"
          using A13 xreal_1_th_19 sorry
        have A17: "lenFINSEQ-1K4 (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 m +NAT-1K1 \<one>\<^sub>M"
          using A5 A3 A13 finseq_1_th_59 sorry
        have "m =XBOOLE-0R4 0NUMBERSK6 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)) or m <>HIDDENR2 0NUMBERSK6 & (m <>HIDDENR2 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
        proof-
          show "m =XBOOLE-0R4 0NUMBERSK6 & FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)) or m <>HIDDENR2 0NUMBERSK6 & (m <>HIDDENR2 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
          proof-
            have cases: "m =XBOOLE-0R4 0NUMBERSK6 or m <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "m =XBOOLE-0R4 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
            proof(rule impI)
              assume A18: "m =XBOOLE-0R4 0NUMBERSK6"
              obtain d where
                [ty]:"d be ElementSUBSET-1M1-of C" and 
                A19: "?b .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 d}"
                using rearran1_th_9 sorry
              have A20: "d inTARSKIR2 ?b .FUNCT-1K1 \<one>\<^sub>M"
                using A19 tarski_def_1 sorry
              have A21: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)"
                using A1 rearran1_th_36 sorry
              then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M & \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)"
                using finseq_1_th_1 finseq_3_th_25 sorry
              then have A22: "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) .FUNCT-1K1 \<one>\<^sub>M"
                using A18 rfinseq_th_6 sorry
              also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
                using A1 rearran1_th_25 sorry
              also have "... = ?p .FUNCT-1K1 d"
                using A1 A20 rearran1_th_22 sorry
              finally have "(FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ?p .FUNCT-1K1 d"
                 sorry
              have "domRELSET-1K1\<^bsub>(C)\<^esub> ?p =XBOOLE-0R4 C"
                using A1 rearran1_th_21 sorry
              then have A23: "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)) =FINSEQ-1R1 <*FINSEQ-1K10 ?p .FUNCT-1K1 d*>"
                using A18 A19 rfunct_3_th_69 sorry
              have "lenFINSEQ-1K4 (FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 \<one>\<^sub>M"
                using A18 A21 finseq_1_th_59 sorry
              thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
                using A23 A22 finseq_1_th_40 sorry
            qed
            have case2: "m <>HIDDENR2 0NUMBERSK6 implies FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
            proof(rule impI)
              assume A24: "m <>HIDDENR2 0NUMBERSK6"
              have A25: "SegFINSEQ-1K2 m c=MEMBEREDR6 SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)"
                using A9 finseq_1_th_5 sorry
              have A26: "(?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 m"
                using finseq_1_def_15 sorry
              also have "... = (?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 m"
                using finseq_1_def_15 sorry
              also have "... = ?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (SegFINSEQ-1K2 (m +NAT-1K1 \<one>\<^sub>M) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m)"
                using relat_1_th_71 sorry
              also have "... = ?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 m"
                using A25 xboole_1_th_28 sorry
              also have "... = ?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m"
                using finseq_1_def_15 sorry
              finally have "(?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 ?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m"
                 sorry
              have A27: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
                using A24 nat_1_th_13 sorry
              then obtain d where
                [ty]:"d be ElementSUBSET-1M1-of C" and 
                A28: "?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m =XBOOLE-0R4 {TARSKIK1 d}"and "?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?b .FUNCT-1K1 m \\/XBOOLE-0K2 {TARSKIK1 d}"and A29: "?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 {TARSKIK1 d} =XBOOLE-0R4 ?b .FUNCT-1K1 m"
                using A16 rearran1_th_10 sorry
              have A30: "d inTARSKIR2 {TARSKIK1 d}"
                using tarski_def_1 sorry
              then have "?p .FUNCT-1K1 d =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A1 A15 A27 A28 rearran1_th_22 sorry
              also have "... = FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(?p,C) .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A1 rearran1_th_25 sorry
              also have "... = (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A4 A6 A5 A3 A10 A11 rfinseq_th_6 sorry
              finally have "?p .FUNCT-1K1 d =HIDDENR1 (?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              then have A31: "?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 ?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> m ^FINSEQ-1K8 (<*FINSEQ-1K10 ?p .FUNCT-1K1 d*>)"
                using A17 A26 rfinseq_th_7 sorry
              have "d inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> ?p /\\SUBSET-1K8\<^bsub>(C)\<^esub> ?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A12 A28 A30 xboole_0_def_4 sorry
              then have A32: "d inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
                using relat_1_th_61 sorry
              have A33: "?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) be non-increasingRFINSEQV1"
                using rfinseq_th_20 sorry
              have A34: "domRELSET-1K1\<^bsub>(C)\<^esub> (?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> ?p /\\SUBSET-1K8\<^bsub>(C)\<^esub> ?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using relat_1_th_61 sorry
              also have "... = ?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                using A10 A12 rearran1_lm_5 xboole_1_th_28 sorry
              finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))) =HIDDENR1 ?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have "?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) be finiteFINSET-1V1"
                using A10 rearran1_lm_5 finset_1_th_1 sorry
              then have "(?f  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M),?p  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (?b .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)))are-fiberwise-equipotentCLASSES1R2"
                using A8 A14 A27 A29 A31 A32 finseq_3_th_25 rfunct_3_th_65 sorry
              thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
                using A34 A33 rfunct_3_def_13 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> (m +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A35: "domFINSEQ-1K5 B =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 B) & lenFINSEQ-1K4 B =XBOOLE-0R4 cardCARD-1K4 C"
      using rearran1_th_1 finseq_1_def_3 sorry
    have A36: "?P(0NUMBERSK6)"
      using finseq_3_th_25 sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A36 A7 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),C)  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(C)\<^esub>(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B),(Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B).FUNCT-1K1 n)"
      using A2 A4 A35 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_38:
" for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,A) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
proof-
  have " for r be RealXREAL-0M1 holds  for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for B be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix B assume [ty]: "B be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C"
    have A3: "domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) =XBOOLE-0R4 C"
      using A1 A2 rearran1_th_21 sorry
    let ?b = "Co-GenREARRAN1K2\<^bsub>(C)\<^esub> B"
    have A4: "lenFINSEQ-1K4 ?b =XBOOLE-0R4 cardCARD-1K4 C"
      using rearran1_th_1 sorry
    have A5: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    then have A6: "domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 D"
      using valued_1_th_3 sorry
    then have A7: "F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      using partfun1_def_2 sorry
    have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r"
      using A6 relat_1_th_68 sorry
    then have A8: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) =XBOOLE-0R4 cardCARD-1K4 D"
      using A6 rfunct_3_th_67 sorry
    obtain rr where 
      [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r"
      using xreal_0_def_1 sorry
    have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using A5 relat_1_th_68 sorry
    then have A9: "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) -RVSUM-1K9 cardCARD-1K4 D  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr"
      using A5 rfunct_3_th_73 sorry
    have A10: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B)"
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domFINSEQ-1K5 ?b & c inTARSKIR2 ?b .FUNCT-1K1 Lamb1"
      have A11: "C =XBOOLE-0R4 ?b .FUNCT-1K1 lenFINSEQ-1K4 ?b"
        using rearran1_th_3 sorry
      have "lenFINSEQ-1K4 ?b <>HIDDENR2 0NUMBERSK6"
        using rearran1_th_4 sorry
      then have A12: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
        using nat_1_th_13 sorry
      then have A13: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?b"
        using finseq_3_th_25 sorry
      have "lenFINSEQ-1K4 ?b inTARSKIR2 domFINSEQ-1K5 ?b"
        using A12 finseq_3_th_25 sorry
      then have A14: " ex n be NatNAT-1M1 st ?P(n)"
        using A11 sorry
      obtain mi where
        [ty]:"mi be NatNAT-1M1" and 
        A15: "?P(mi) & ( for n be NatNAT-1M1 holds ?P(n) implies mi <=XXREAL-0R1 n)"
        using nat_1_sch_5 A14 sorry
      have A16: "\<one>\<^sub>M <=XXREAL-0R1 mi"
        using A15 finseq_3_th_25 sorry
      then have "maxXXREAL-0K5(0NUMBERSK6,mi -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 mi -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_4 sorry
      then obtain m1 where 
        [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = mi -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_5 sorry
      have A17: "mi <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
        using A15 finseq_3_th_25 sorry
      have A18: "mi <XXREAL-0R3 mi +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      then have "m1 <XXREAL-0R3 mi"
        using xreal_1_th_19 sorry
      then have A19: "m1 <XXREAL-0R3 lenFINSEQ-1K4 ?b"
        using A17 xxreal_0_th_2 sorry
      have "m1 <=XXREAL-0R1 mi"
        using A18 xreal_1_th_19 sorry
      then have A20: "m1 <=XXREAL-0R1 lenFINSEQ-1K4 ?b"
        using A17 xxreal_0_th_2 sorry
      have "mi =XBOOLE-0R4 \<one>\<^sub>M & RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c)"
      proof-
        show "mi =XBOOLE-0R4 \<one>\<^sub>M & RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c or mi <>HIDDENR2 \<one>\<^sub>M & (mi <>HIDDENR2 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c)"
        proof-
          have cases: "mi =XBOOLE-0R4 \<one>\<^sub>M or mi <>HIDDENR2 \<one>\<^sub>M"
             sorry
          have case1: "mi =XBOOLE-0R4 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
          proof(rule impI)
            assume A21: "mi =XBOOLE-0R4 \<one>\<^sub>M"
            have A22: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
              using A2 A8 A4 A12 finseq_3_th_25 sorry
            have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (cardCARD-1K4 D)"
              using A2 A4 A13 finseq_1_def_3 sorry
            then have A23: "(cardCARD-1K4 D  |->FINSEQ-2K2 r).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 r"
              using funcop_1_th_7 sorry
            have "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) .FUNCT-1K1 \<one>\<^sub>M & RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 \<one>\<^sub>M"
              using A1 A2 A7 A15 A21 rearran1_th_22 sorry
            then have "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c -XCMPLX-0K6 r"
              using A9 A22 A23 valued_1_th_13 sorry
            also have "... = (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
              using A3 valued_1_th_3 sorry
            finally show "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
               sorry
          qed
          have case2: "mi <>HIDDENR2 \<one>\<^sub>M implies RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
          proof(rule impI)
            assume "mi <>HIDDENR2 \<one>\<^sub>M"
            then have "\<one>\<^sub>M <XXREAL-0R3 mi"
              using A16 xxreal_0_th_1 sorry
            then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 mi"
              using nat_1_th_13 sorry
            then have A24: "\<one>\<^sub>M <=XXREAL-0R1 m1"
              using xreal_1_th_19 sorry
            then have "m1 inTARSKIR2 domFINSEQ-1K5 ?b"
              using A20 finseq_3_th_25 sorry
            then have " not c inTARSKIR2 ?b .FUNCT-1K1 m1"
              using A15 xreal_1_th_44 sorry
            then have "c inTARSKIR2 ?b .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) \\SUBSET-1K6 ?b .FUNCT-1K1 m1"
              using A15 xboole_0_def_5 sorry
            then have A25: "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D) .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) & RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c =XBOOLE-0R4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D) .FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)"
              using A1 A2 A7 A19 A24 rearran1_th_22 sorry
            have "m1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (cardCARD-1K4 D)"
              using A2 A4 A15 finseq_1_def_3 sorry
            then have A26: "(cardCARD-1K4 D  |->FINSEQ-2K2 r).FUNCT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 r"
              using funcop_1_th_7 sorry
            have "m1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,D)"
              using A2 A8 A4 A15 finseq_3_th_29 sorry
            then have "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) .FUNCT-1K1 c -XCMPLX-0K6 r"
              using A9 A25 A26 valued_1_th_13 sorry
            also have "... = (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
              using A3 valued_1_th_3 sorry
            finally show "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =HIDDENR1 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) .FUNCT-1K1 c =XBOOLE-0R4 (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 C"
      using A3 valued_1_th_3 sorry
    thus "RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,B) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,B) -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r"
      using A2 A7 A10 rearran1_th_21 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rearran1_th_39:
" for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies (((RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2 & (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2) & rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F) & rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for A be RearrangmentGenREARRAN1M1-of C holds F be totalPARTFUN1V1\<^bsub>(D)\<^esub> & cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C implies ((RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2 & (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2) & (rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F & rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix A assume [ty]: "A be RearrangmentGenREARRAN1M1-of C"
    assume A1: "F be totalPARTFUN1V1\<^bsub>(D)\<^esub>"
      and A2: "cardCARD-1K4 D =XBOOLE-0R4 cardCARD-1K4 C"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 D"
      using A1 partfun1_def_2 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> D"
      using relat_1_th_61 sorry
    also have "... = D"
      using A3 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D) =HIDDENR1 D"
       sorry
    then have A4: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_def_13 sorry
    have "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_24 sorry
    then have A5: "(RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,D))are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rearran1_th_17 sorry
    then have "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> D)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    thus "(RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2 & (RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A),F)are-fiberwise-equipotentCLASSES1R2"
      using A3 A5 relat_1_th_68 sorry
    thus "rngRVSUM-1K1 RlandREARRAN1K3\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F & rngRVSUM-1K1 RlorREARRAN1K4\<^bsub>(D,C)\<^esub>(F,A) =MEMBEREDR9 rngRVSUM-1K1 F"
      using classes1_th_75 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
