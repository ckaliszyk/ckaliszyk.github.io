theory trees_3
  imports trees_2 finseq_3 square_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z for "objectHIDDENM1"
reserve X, Y for "setHIDDENM2"
reserve i, k, n for "NatNAT-1M1"
reserve p, q, r, s for "FinSequenceFINSEQ-1M1"
reserve w for "FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
reserve f for "FunctionFUNCT-1M1"
mlemma trees_3_lm_1:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^FINSEQ-1K8 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies (p ^FINSEQ-1K8 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
    have "n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
      using A1 A2 finseq_3_th_25 sorry
    thus "(p ^FINSEQ-1K8 q).FUNCT-1K1 n =XBOOLE-0R4 p .FUNCT-1K1 n"
      using finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef trees_3_def_1 ("TreesTREES-3K1" 164 ) where
"func TreesTREES-3K1 \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be TreeTREES-1M1"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be TreeTREES-1M1"
    proof-
      have " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar1 implies x be TreeTREES-1M1) & (x be TreeTREES-1M1 implies x inHIDDENR3 tVar1)"
      proof-
        let ?X = "{T where T be SubsetSUBSET-1M2-of NATNUMBERSK1 * FINSEQ-2K3 : T be TreeTREES-1M1 }"
        show " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar1 implies x be TreeTREES-1M1) & (x be TreeTREES-1M1 implies x inHIDDENR3 tVar1)"
        proof(rule bexI[of _ "?X"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 {T where T be SubsetSUBSET-1M2-of NATNUMBERSK1 * FINSEQ-2K3 : T be TreeTREES-1M1 } implies x be TreeTREES-1M1"
          proof(rule impI)
            assume "x inHIDDENR3 ?X"
            then have " ex T be SubsetSUBSET-1M2-of NATNUMBERSK1 * FINSEQ-2K3 st x =HIDDENR1 T & T be TreeTREES-1M1"
               sorry
            thus "x be TreeTREES-1M1"
               sorry
          qed
          assume "x be TreeTREES-1M1"
          then obtain T where 
            [ty]:"T be TreeTREES-1M1" and TDef:"T = x"
             sorry
          have "T be SubsetSUBSET-1M2-of NATNUMBERSK1 * FINSEQ-2K3"
            using trees_1_def_3 sorry
          thus "x inHIDDENR3 {T where T be SubsetSUBSET-1M2-of NATNUMBERSK1 * FINSEQ-2K3 : T be TreeTREES-1M1 }"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x be TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x be TreeTREES-1M1) implies it1 =HIDDENR1 it2"
    proof-
      have " for T1 be setHIDDENM2 holds  for T2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 T1 iff x be TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 T2 iff x be TreeTREES-1M1) implies T1 =HIDDENR1 T2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?X = "\<lambda>Lamb1. Lamb1 be TreeTREES-1M1"
        fix T1 assume [ty]: "T1 be setHIDDENM2"
        fix T2 assume [ty]: "T2 be setHIDDENM2"
        assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 T1 iff ?X(x)"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 T2 iff ?X(x)"
        show "T1 =HIDDENR1 T2"
          using xboole_0_sch_2 A1 A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_3_cl_1:
"cluster TreesTREES-3K1 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "TreesTREES-3K1 be  non emptyXBOOLE-0V1"
  proof-
    have " not TreesTREES-3K1 be emptyXBOOLE-0V1"
    proof-
      let ?T = "the TreeTREES-1M1"
      have "?T inTARSKIR2 TreesTREES-3K1"
        using trees_3_def_1 sorry
      thus " not TreesTREES-3K1 be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef trees_3_def_2 ("FinTreesTREES-3K2" 164 ) where
"func FinTreesTREES-3K2 \<rightarrow> SubsetSUBSET-1M2-of TreesTREES-3K1 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of TreesTREES-3K1 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    proof-
      have " ex tVar2 be SubsetSUBSET-1M2-of TreesTREES-3K1 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar2 implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 implies x inHIDDENR3 tVar2)"
      proof-
        let ?X = "{T where T be ElementSUBSET-1M1-of TreesTREES-3K1 : T be finiteFINSET-1V1\<bar>TreeTREES-1M1 }"
        have "?X c=TARSKIR1 TreesTREES-3K1"
        proof-
          have "{T where T be ElementSUBSET-1M1-of TreesTREES-3K1 : T be finiteFINSET-1V1\<bar>TreeTREES-1M1 } c=TARSKIR1 TreesTREES-3K1"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {T where T be ElementSUBSET-1M1-of TreesTREES-3K1 : T be finiteFINSET-1V1\<bar>TreeTREES-1M1 } implies x inHIDDENR3 TreesTREES-3K1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ?X"
              then have " ex T be ElementSUBSET-1M1-of TreesTREES-3K1 st x =HIDDENR1 T & T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
                 sorry
              thus "x inHIDDENR3 TreesTREES-3K1"
                 sorry
            qed "sorry"
            thus "{T where T be ElementSUBSET-1M1-of TreesTREES-3K1 : T be finiteFINSET-1V1\<bar>TreeTREES-1M1 } c=TARSKIR1 TreesTREES-3K1"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain X where 
          [ty]:"X be SubsetSUBSET-1M2-of TreesTREES-3K1" and XDef:"X = ?X"
           sorry
        show " ex tVar2 be SubsetSUBSET-1M2-of TreesTREES-3K1 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar2 implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 implies x inHIDDENR3 tVar2)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          proof(rule impI)
            assume "x inHIDDENR3 X"
            then have " ex T be ElementSUBSET-1M1-of TreesTREES-3K1 st x =HIDDENR1 T & T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
               sorry
            thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
               sorry
          qed
          assume "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          then obtain T where 
            [ty]:"T be finiteFINSET-1V1\<bar>TreeTREES-1M1" and TDef:"T = x"
             sorry
          have "T inTARSKIR2 TreesTREES-3K1"
            using trees_3_def_1 sorry
          thus "x inHIDDENR3 X"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be SubsetSUBSET-1M2-of TreesTREES-3K1 holds  for it2 be SubsetSUBSET-1M2-of TreesTREES-3K1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies it1 =HIDDENR1 it2"
    proof-
      have " for T1 be SubsetSUBSET-1M2-of TreesTREES-3K1 holds  for T2 be SubsetSUBSET-1M2-of TreesTREES-3K1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 T1 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 T2 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies T1 =HIDDENR1 T2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?X = "\<lambda>Lamb1. Lamb1 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        fix T1 assume [ty]: "T1 be SubsetSUBSET-1M2-of TreesTREES-3K1"
        fix T2 assume [ty]: "T2 be SubsetSUBSET-1M2-of TreesTREES-3K1"
        assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 T1 iff ?X(x)"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 T2 iff ?X(x)"
        show "T1 =HIDDENR1 T2"
          using xboole_0_sch_2 A1 A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_3_cl_2:
"cluster FinTreesTREES-3K2 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "FinTreesTREES-3K2 be  non emptyXBOOLE-0V1"
  proof-
    have " not FinTreesTREES-3K2 be emptyXBOOLE-0V1"
    proof-
      let ?T = "the finiteFINSET-1V1\<bar>TreeTREES-1M1"
      have "?T inTARSKIR2 FinTreesTREES-3K2"
        using trees_3_def_2 sorry
      thus " not FinTreesTREES-3K2 be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef trees_3_def_3 ("constituted-TreesTREES-3V1" 70 ) where
"attr constituted-TreesTREES-3V1 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies x be TreeTREES-1M1)"..

mdef trees_3_def_4 ("constituted-FinTreesTREES-3V2" 70 ) where
"attr constituted-FinTreesTREES-3V2 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"..

mdef trees_3_def_5 ("constituted-DTreesTREES-3V3" 70 ) where
"attr constituted-DTreesTREES-3V3 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies x be DecoratedTreeTREES-2M4)"..

mtheorem trees_3_th_1:
" for X be setHIDDENM2 holds X be constituted-TreesTREES-3V1 iff X c=TARSKIR1 TreesTREES-3K1"
proof-
  have " for X be setHIDDENM2 holds (X be constituted-TreesTREES-3V1 implies X c=TARSKIR1 TreesTREES-3K1) & (X c=TARSKIR1 TreesTREES-3K1 implies X be constituted-TreesTREES-3V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    show "X be constituted-TreesTREES-3V1 implies X c=TARSKIR1 TreesTREES-3K1"
    proof-
      have " not (X be constituted-TreesTREES-3V1 &  not X c=TARSKIR1 TreesTREES-3K1)"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1) implies X c=TARSKIR1 TreesTREES-3K1"
        proof(rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 TreesTREES-3K1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            then have "x be TreeTREES-1M1"
              using A1 sorry
            thus "x inHIDDENR3 TreesTREES-3K1"
              using trees_3_def_1 sorry
          qed "sorry"
          thus "X c=TARSKIR1 TreesTREES-3K1"
            using tarski_def_3 sorry
        qed
        thus " not (X be constituted-TreesTREES-3V1 &  not X c=TARSKIR1 TreesTREES-3K1)"
          using trees_3_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "X c=TARSKIR1 TreesTREES-3K1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      thus "x be TreeTREES-1M1"
        using A2 trees_3_def_1 sorry
    qed "sorry"
    thus "X be constituted-TreesTREES-3V1"
      using trees_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_2:
" for X be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 iff X c=TARSKIR1 FinTreesTREES-3K2"
proof-
  have " for X be setHIDDENM2 holds (X be constituted-FinTreesTREES-3V2 implies X c=TARSKIR1 FinTreesTREES-3K2) & (X c=TARSKIR1 FinTreesTREES-3K2 implies X be constituted-FinTreesTREES-3V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    show "X be constituted-FinTreesTREES-3V2 implies X c=TARSKIR1 FinTreesTREES-3K2"
    proof-
      have " not (X be constituted-FinTreesTREES-3V2 &  not X c=TARSKIR1 FinTreesTREES-3K2)"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies X c=TARSKIR1 FinTreesTREES-3K2"
        proof(rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 FinTreesTREES-3K2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X"
            then have "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
              using A1 sorry
            thus "x inHIDDENR3 FinTreesTREES-3K2"
              using trees_3_def_2 sorry
          qed "sorry"
          thus "X c=TARSKIR1 FinTreesTREES-3K2"
            using tarski_def_3 sorry
        qed
        thus " not (X be constituted-FinTreesTREES-3V2 &  not X c=TARSKIR1 FinTreesTREES-3K2)"
          using trees_3_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "X c=TARSKIR1 FinTreesTREES-3K2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        using A2 trees_3_def_2 sorry
    qed "sorry"
    thus "X be constituted-FinTreesTREES-3V2"
      using trees_3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1 iff X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1 implies X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1) &  not (X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1 &  not (X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1 implies X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1"
    proof-
      have " not ((X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1) &  not X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1)"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be TreeTREES-1M1) implies X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1"
        proof(rule impMI ,rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1"
            and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be TreeTREES-1M1"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be TreeTREES-1M1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            then have "x inHIDDENR3 X or x inHIDDENR3 Y"
              using xboole_0_def_3 sorry
            thus "x be TreeTREES-1M1"
              using A1 A2 sorry
          qed "sorry"
          thus "X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1"
            using trees_3_def_3 sorry
        qed
        thus " not ((X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1) &  not X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1)"
          using trees_3_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be TreeTREES-1M1) implies X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1"
    proof(rule impI,rule conjMI)
      assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be TreeTREES-1M1"
      show "X be constituted-TreesTREES-3V1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
          thus "x be TreeTREES-1M1"
            using A3 sorry
        qed "sorry"
        thus "X be constituted-TreesTREES-3V1"
          using trees_3_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be TreeTREES-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 Y"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 sorry
        thus "x be TreeTREES-1M1"
          using A3 sorry
      qed "sorry"
      thus "Y be constituted-TreesTREES-3V1"
        using trees_3_def_3 sorry
    qed
    thus " not (X \\/XBOOLE-0K2 Y be constituted-TreesTREES-3V1 &  not (X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1))"
      using trees_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1 implies X \\+\\XBOOLE-0K5 Y be constituted-TreesTREES-3V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1) &  not X \\+\\XBOOLE-0K5 Y be constituted-TreesTREES-3V1)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be TreeTREES-1M1) implies X \\+\\XBOOLE-0K5 Y be constituted-TreesTREES-3V1"
    proof(rule impMI ,rule impI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1"
        and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be TreeTREES-1M1"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\+\\XBOOLE-0K5 Y implies x be TreeTREES-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\+\\XBOOLE-0K5 Y"
        then have " not x inHIDDENR3 X iff x inHIDDENR3 Y"
          using xboole_0_th_1 sorry
        thus "x be TreeTREES-1M1"
          using A1 A2 sorry
      qed "sorry"
      thus "X \\+\\XBOOLE-0K5 Y be constituted-TreesTREES-3V1"
        using trees_3_def_3 sorry
    qed
    thus " not ((X be constituted-TreesTREES-3V1 & Y be constituted-TreesTREES-3V1) &  not X \\+\\XBOOLE-0K5 Y be constituted-TreesTREES-3V1)"
      using trees_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 implies (X /\\XBOOLE-0K3 Y be constituted-TreesTREES-3V1 & Y /\\XBOOLE-0K3 X be constituted-TreesTREES-3V1) & X \\SUBSET-1K6 Y be constituted-TreesTREES-3V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (X be constituted-TreesTREES-3V1 &  not ((X /\\XBOOLE-0K3 Y be constituted-TreesTREES-3V1 & Y /\\XBOOLE-0K3 X be constituted-TreesTREES-3V1) & X \\SUBSET-1K6 Y be constituted-TreesTREES-3V1))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1) implies X /\\XBOOLE-0K3 Y be constituted-TreesTREES-3V1 & (Y /\\XBOOLE-0K3 X be constituted-TreesTREES-3V1 & X \\SUBSET-1K6 Y be constituted-TreesTREES-3V1)"
    proof(rule impI,rule conjMI,rule conjMI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be TreeTREES-1M1"
      show "X /\\XBOOLE-0K3 Y be constituted-TreesTREES-3V1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y implies x be TreeTREES-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          then have "x inHIDDENR3 X"
            using xboole_0_def_4 sorry
          thus "x be TreeTREES-1M1"
            using A1 sorry
        qed "sorry"
        thus "X /\\XBOOLE-0K3 Y be constituted-TreesTREES-3V1"
          using trees_3_def_3 sorry
      qed
      thus "Y /\\XBOOLE-0K3 X be constituted-TreesTREES-3V1"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\SUBSET-1K6 Y implies x be TreeTREES-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\SUBSET-1K6 Y"
        thus "x be TreeTREES-1M1"
          using A1 sorry
      qed "sorry"
      thus "X \\SUBSET-1K6 Y be constituted-TreesTREES-3V1"
        using trees_3_def_3 sorry
    qed
    thus " not (X be constituted-TreesTREES-3V1 &  not ((X /\\XBOOLE-0K3 Y be constituted-TreesTREES-3V1 & Y /\\XBOOLE-0K3 X be constituted-TreesTREES-3V1) & X \\SUBSET-1K6 Y be constituted-TreesTREES-3V1))"
      using trees_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2 iff X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2 implies X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2) &  not (X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2 &  not (X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2 implies X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2"
    proof-
      have " not ((X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2) &  not X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2)"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2"
        proof(rule impMI ,rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
            and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            then have "x inHIDDENR3 X or x inHIDDENR3 Y"
              using xboole_0_def_3 sorry
            thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
              using A1 A2 sorry
          qed "sorry"
          thus "X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2"
            using trees_3_def_4 sorry
        qed
        thus " not ((X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2) &  not X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2)"
          using trees_3_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2"
    proof(rule impI,rule conjMI)
      assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      show "X be constituted-FinTreesTREES-3V2"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
          thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
            using A3 sorry
        qed "sorry"
        thus "X be constituted-FinTreesTREES-3V2"
          using trees_3_def_4 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 Y"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 sorry
        thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          using A3 sorry
      qed "sorry"
      thus "Y be constituted-FinTreesTREES-3V2"
        using trees_3_def_4 sorry
    qed
    thus " not (X \\/XBOOLE-0K2 Y be constituted-FinTreesTREES-3V2 &  not (X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2))"
      using trees_3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_7:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2 implies X \\+\\XBOOLE-0K5 Y be constituted-FinTreesTREES-3V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2) &  not X \\+\\XBOOLE-0K5 Y be constituted-FinTreesTREES-3V2)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies X \\+\\XBOOLE-0K5 Y be constituted-FinTreesTREES-3V2"
    proof(rule impMI ,rule impI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\+\\XBOOLE-0K5 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\+\\XBOOLE-0K5 Y"
        then have " not x inHIDDENR3 X iff x inHIDDENR3 Y"
          using xboole_0_th_1 sorry
        thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          using A1 A2 sorry
      qed "sorry"
      thus "X \\+\\XBOOLE-0K5 Y be constituted-FinTreesTREES-3V2"
        using trees_3_def_4 sorry
    qed
    thus " not ((X be constituted-FinTreesTREES-3V2 & Y be constituted-FinTreesTREES-3V2) &  not X \\+\\XBOOLE-0K5 Y be constituted-FinTreesTREES-3V2)"
      using trees_3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 implies (X /\\XBOOLE-0K3 Y be constituted-FinTreesTREES-3V2 & Y /\\XBOOLE-0K3 X be constituted-FinTreesTREES-3V2) & X \\SUBSET-1K6 Y be constituted-FinTreesTREES-3V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (X be constituted-FinTreesTREES-3V2 &  not ((X /\\XBOOLE-0K3 Y be constituted-FinTreesTREES-3V2 & Y /\\XBOOLE-0K3 X be constituted-FinTreesTREES-3V2) & X \\SUBSET-1K6 Y be constituted-FinTreesTREES-3V2))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies X /\\XBOOLE-0K3 Y be constituted-FinTreesTREES-3V2 & (Y /\\XBOOLE-0K3 X be constituted-FinTreesTREES-3V2 & X \\SUBSET-1K6 Y be constituted-FinTreesTREES-3V2)"
    proof(rule impI,rule conjMI,rule conjMI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      show "X /\\XBOOLE-0K3 Y be constituted-FinTreesTREES-3V2"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          then have "x inHIDDENR3 X"
            using xboole_0_def_4 sorry
          thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
            using A1 sorry
        qed "sorry"
        thus "X /\\XBOOLE-0K3 Y be constituted-FinTreesTREES-3V2"
          using trees_3_def_4 sorry
      qed
      thus "Y /\\XBOOLE-0K3 X be constituted-FinTreesTREES-3V2"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\SUBSET-1K6 Y implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\SUBSET-1K6 Y"
        thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          using A1 sorry
      qed "sorry"
      thus "X \\SUBSET-1K6 Y be constituted-FinTreesTREES-3V2"
        using trees_3_def_4 sorry
    qed
    thus " not (X be constituted-FinTreesTREES-3V2 &  not ((X /\\XBOOLE-0K3 Y be constituted-FinTreesTREES-3V2 & Y /\\XBOOLE-0K3 X be constituted-FinTreesTREES-3V2) & X \\SUBSET-1K6 Y be constituted-FinTreesTREES-3V2))"
      using trees_3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3 iff X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3 implies X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3) &  not (X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3 &  not (X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3 implies X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3"
    proof-
      have " not ((X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3) &  not X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3)"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M4) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be DecoratedTreeTREES-2M4) implies X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3"
        proof(rule impMI ,rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M4"
            and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be DecoratedTreeTREES-2M4"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be DecoratedTreeTREES-2M4"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            then have "x inHIDDENR3 X or x inHIDDENR3 Y"
              using xboole_0_def_3 sorry
            thus "x be DecoratedTreeTREES-2M4"
              using A1 A2 sorry
          qed "sorry"
          thus "X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3"
            using trees_3_def_5 sorry
        qed
        thus " not ((X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3) &  not X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3)"
          using trees_3_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be DecoratedTreeTREES-2M4) implies X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3"
    proof(rule impI,rule conjMI)
      assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 Y implies x be DecoratedTreeTREES-2M4"
      show "X be constituted-DTreesTREES-3V3"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M4"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
            using xboole_0_def_3 sorry
          thus "x be DecoratedTreeTREES-2M4"
            using A3 sorry
        qed "sorry"
        thus "X be constituted-DTreesTREES-3V3"
          using trees_3_def_5 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be DecoratedTreeTREES-2M4"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 Y"
        then have "x inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using xboole_0_def_3 sorry
        thus "x be DecoratedTreeTREES-2M4"
          using A3 sorry
      qed "sorry"
      thus "Y be constituted-DTreesTREES-3V3"
        using trees_3_def_5 sorry
    qed
    thus " not (X \\/XBOOLE-0K2 Y be constituted-DTreesTREES-3V3 &  not (X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3))"
      using trees_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3 implies X \\+\\XBOOLE-0K5 Y be constituted-DTreesTREES-3V3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3) &  not X \\+\\XBOOLE-0K5 Y be constituted-DTreesTREES-3V3)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M4) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be DecoratedTreeTREES-2M4) implies X \\+\\XBOOLE-0K5 Y be constituted-DTreesTREES-3V3"
    proof(rule impMI ,rule impI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M4"
        and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x be DecoratedTreeTREES-2M4"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\+\\XBOOLE-0K5 Y implies x be DecoratedTreeTREES-2M4"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\+\\XBOOLE-0K5 Y"
        then have " not x inHIDDENR3 X iff x inHIDDENR3 Y"
          using xboole_0_th_1 sorry
        thus "x be DecoratedTreeTREES-2M4"
          using A1 A2 sorry
      qed "sorry"
      thus "X \\+\\XBOOLE-0K5 Y be constituted-DTreesTREES-3V3"
        using trees_3_def_5 sorry
    qed
    thus " not ((X be constituted-DTreesTREES-3V3 & Y be constituted-DTreesTREES-3V3) &  not X \\+\\XBOOLE-0K5 Y be constituted-DTreesTREES-3V3)"
      using trees_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 implies (X /\\XBOOLE-0K3 Y be constituted-DTreesTREES-3V3 & Y /\\XBOOLE-0K3 X be constituted-DTreesTREES-3V3) & X \\SUBSET-1K6 Y be constituted-DTreesTREES-3V3"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not (X be constituted-DTreesTREES-3V3 &  not ((X /\\XBOOLE-0K3 Y be constituted-DTreesTREES-3V3 & Y /\\XBOOLE-0K3 X be constituted-DTreesTREES-3V3) & X \\SUBSET-1K6 Y be constituted-DTreesTREES-3V3))"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M4) implies X /\\XBOOLE-0K3 Y be constituted-DTreesTREES-3V3 & (Y /\\XBOOLE-0K3 X be constituted-DTreesTREES-3V3 & X \\SUBSET-1K6 Y be constituted-DTreesTREES-3V3)"
    proof(rule impI,rule conjMI,rule conjMI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M4"
      show "X /\\XBOOLE-0K3 Y be constituted-DTreesTREES-3V3"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 Y implies x be DecoratedTreeTREES-2M4"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X /\\XBOOLE-0K3 Y"
          then have "x inHIDDENR3 X"
            using xboole_0_def_4 sorry
          thus "x be DecoratedTreeTREES-2M4"
            using A1 sorry
        qed "sorry"
        thus "X /\\XBOOLE-0K3 Y be constituted-DTreesTREES-3V3"
          using trees_3_def_5 sorry
      qed
      thus "Y /\\XBOOLE-0K3 X be constituted-DTreesTREES-3V3"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\SUBSET-1K6 Y implies x be DecoratedTreeTREES-2M4"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\SUBSET-1K6 Y"
        thus "x be DecoratedTreeTREES-2M4"
          using A1 sorry
      qed "sorry"
      thus "X \\SUBSET-1K6 Y be constituted-DTreesTREES-3V3"
        using trees_3_def_5 sorry
    qed
    thus " not (X be constituted-DTreesTREES-3V3 &  not ((X /\\XBOOLE-0K3 Y be constituted-DTreesTREES-3V3 & Y /\\XBOOLE-0K3 X be constituted-DTreesTREES-3V3) & X \\SUBSET-1K6 Y be constituted-DTreesTREES-3V3))"
      using trees_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_cl_3:
"cluster emptyXBOOLE-0V1 also-is constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar>constituted-DTreesTREES-3V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar>constituted-DTreesTREES-3V3"
     sorry
qed "sorry"

mtheorem trees_3_th_12:
" for x be objectHIDDENM1 holds {TARSKIK1 x} be constituted-TreesTREES-3V1 iff x be TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds ({TARSKIK1 x} be constituted-TreesTREES-3V1 implies x be TreeTREES-1M1) & (x be TreeTREES-1M1 implies {TARSKIK1 x} be constituted-TreesTREES-3V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "{TARSKIK1 x} be constituted-TreesTREES-3V1 implies x be TreeTREES-1M1"
    proof-
      have " not ({TARSKIK1 x} be constituted-TreesTREES-3V1 &  not x be TreeTREES-1M1)"
      proof-
        have "( for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies y be TreeTREES-1M1) implies x be TreeTREES-1M1"
        proof(rule impI)
          assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies y be TreeTREES-1M1"
          have "x inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
          thus "x be TreeTREES-1M1"
            using A1 sorry
        qed
        thus " not ({TARSKIK1 x} be constituted-TreesTREES-3V1 &  not x be TreeTREES-1M1)"
          using trees_3_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "x be TreeTREES-1M1"
    have " for y be objectHIDDENM1 holds  not (y inHIDDENR3 {TARSKIK1 x} &  not y be TreeTREES-1M1)"
    proof(rule ballI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show " not (y inHIDDENR3 {TARSKIK1 x} &  not y be TreeTREES-1M1)"
        using A2 tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK1 x} be constituted-TreesTREES-3V1"
      using trees_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_13:
" for x be objectHIDDENM1 holds {TARSKIK1 x} be constituted-FinTreesTREES-3V2 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds ({TARSKIK1 x} be constituted-FinTreesTREES-3V2 implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) & (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 implies {TARSKIK1 x} be constituted-FinTreesTREES-3V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "{TARSKIK1 x} be constituted-FinTreesTREES-3V2 implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    proof-
      have " not ({TARSKIK1 x} be constituted-FinTreesTREES-3V2 &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
      proof-
        have "( for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies y be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        proof(rule impI)
          assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          have "x inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
          thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
            using A1 sorry
        qed
        thus " not ({TARSKIK1 x} be constituted-FinTreesTREES-3V2 &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
          using trees_3_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    have " for y be objectHIDDENM1 holds  not (y inHIDDENR3 {TARSKIK1 x} &  not y be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
    proof(rule ballI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show " not (y inHIDDENR3 {TARSKIK1 x} &  not y be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
        using A2 tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK1 x} be constituted-FinTreesTREES-3V2"
      using trees_3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_14:
" for x be objectHIDDENM1 holds {TARSKIK1 x} be constituted-DTreesTREES-3V3 iff x be DecoratedTreeTREES-2M4"
proof-
  have " for x be objectHIDDENM1 holds ({TARSKIK1 x} be constituted-DTreesTREES-3V3 implies x be DecoratedTreeTREES-2M4) & (x be DecoratedTreeTREES-2M4 implies {TARSKIK1 x} be constituted-DTreesTREES-3V3)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "{TARSKIK1 x} be constituted-DTreesTREES-3V3 implies x be DecoratedTreeTREES-2M4"
    proof-
      have " not ({TARSKIK1 x} be constituted-DTreesTREES-3V3 &  not x be DecoratedTreeTREES-2M4)"
      proof-
        have "( for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies y be DecoratedTreeTREES-2M4) implies x be DecoratedTreeTREES-2M4"
        proof(rule impI)
          assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 x} implies y be DecoratedTreeTREES-2M4"
          have "x inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
          thus "x be DecoratedTreeTREES-2M4"
            using A1 sorry
        qed
        thus " not ({TARSKIK1 x} be constituted-DTreesTREES-3V3 &  not x be DecoratedTreeTREES-2M4)"
          using trees_3_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: "x be DecoratedTreeTREES-2M4"
    have " for y be objectHIDDENM1 holds  not (y inHIDDENR3 {TARSKIK1 x} &  not y be DecoratedTreeTREES-2M4)"
    proof(rule ballI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show " not (y inHIDDENR3 {TARSKIK1 x} &  not y be DecoratedTreeTREES-2M4)"
        using A2 tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK1 x} be constituted-DTreesTREES-3V3"
      using trees_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_15:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK2 x,y } be constituted-TreesTREES-3V1 iff x be TreeTREES-1M1 & y be TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ({TARSKIK2 x,y } be constituted-TreesTREES-3V1 implies x be TreeTREES-1M1 & y be TreeTREES-1M1) & (x be TreeTREES-1M1 & y be TreeTREES-1M1 implies {TARSKIK2 x,y } be constituted-TreesTREES-3V1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "{TARSKIK2 x,y } be constituted-TreesTREES-3V1 implies x be TreeTREES-1M1 & y be TreeTREES-1M1"
    proof-
      have " not ({TARSKIK2 x,y } be constituted-TreesTREES-3V1 &  not (x be TreeTREES-1M1 & y be TreeTREES-1M1))"
      proof-
        have "( for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z be TreeTREES-1M1) implies x be TreeTREES-1M1 & y be TreeTREES-1M1"
        proof(rule impI)
          assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z be TreeTREES-1M1"
          have A2: "x inHIDDENR3 {TARSKIK2 x,y }"
            using tarski_def_2 sorry
          have "y inHIDDENR3 {TARSKIK2 x,y }"
            using tarski_def_2 sorry
          thus "x be TreeTREES-1M1 & y be TreeTREES-1M1"
            using A1 A2 sorry
        qed
        thus " not ({TARSKIK2 x,y } be constituted-TreesTREES-3V1 &  not (x be TreeTREES-1M1 & y be TreeTREES-1M1))"
          using trees_3_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: "x be TreeTREES-1M1"
      and A4: "y be TreeTREES-1M1"
    have " for z be objectHIDDENM1 holds  not (z inHIDDENR3 {TARSKIK2 x,y } &  not z be TreeTREES-1M1)"
    proof(rule ballI)
      fix z assume [ty]: "z be objectHIDDENM1"
      show " not (z inHIDDENR3 {TARSKIK2 x,y } &  not z be TreeTREES-1M1)"
        using A3 A4 tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK2 x,y } be constituted-TreesTREES-3V1"
      using trees_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_16:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK2 x,y } be constituted-FinTreesTREES-3V2 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ({TARSKIK2 x,y } be constituted-FinTreesTREES-3V2 implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1) & (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1 implies {TARSKIK2 x,y } be constituted-FinTreesTREES-3V2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "{TARSKIK2 x,y } be constituted-FinTreesTREES-3V2 implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    proof-
      have " not ({TARSKIK2 x,y } be constituted-FinTreesTREES-3V2 &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1))"
      proof-
        have "( for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        proof(rule impI)
          assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          have A2: "x inHIDDENR3 {TARSKIK2 x,y }"
            using tarski_def_2 sorry
          have "y inHIDDENR3 {TARSKIK2 x,y }"
            using tarski_def_2 sorry
          thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
            using A1 A2 sorry
        qed
        thus " not ({TARSKIK2 x,y } be constituted-FinTreesTREES-3V2 &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1))"
          using trees_3_def_4 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      and A4: "y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    have " for z be objectHIDDENM1 holds  not (z inHIDDENR3 {TARSKIK2 x,y } &  not z be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
    proof(rule ballI)
      fix z assume [ty]: "z be objectHIDDENM1"
      show " not (z inHIDDENR3 {TARSKIK2 x,y } &  not z be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
        using A3 A4 tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK2 x,y } be constituted-FinTreesTREES-3V2"
      using trees_3_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_17:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds {TARSKIK2 x,y } be constituted-DTreesTREES-3V3 iff x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ({TARSKIK2 x,y } be constituted-DTreesTREES-3V3 implies x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4) & (x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4 implies {TARSKIK2 x,y } be constituted-DTreesTREES-3V3)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "{TARSKIK2 x,y } be constituted-DTreesTREES-3V3 implies x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4"
    proof-
      have " not ({TARSKIK2 x,y } be constituted-DTreesTREES-3V3 &  not (x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4))"
      proof-
        have "( for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z be DecoratedTreeTREES-2M4) implies x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4"
        proof(rule impI)
          assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z be DecoratedTreeTREES-2M4"
          have A2: "x inHIDDENR3 {TARSKIK2 x,y }"
            using tarski_def_2 sorry
          have "y inHIDDENR3 {TARSKIK2 x,y }"
            using tarski_def_2 sorry
          thus "x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4"
            using A1 A2 sorry
        qed
        thus " not ({TARSKIK2 x,y } be constituted-DTreesTREES-3V3 &  not (x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4))"
          using trees_3_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: "x be DecoratedTreeTREES-2M4"
      and A4: "y be DecoratedTreeTREES-2M4"
    have " for z be objectHIDDENM1 holds  not (z inHIDDENR3 {TARSKIK2 x,y } &  not z be DecoratedTreeTREES-2M4)"
    proof(rule ballI)
      fix z assume [ty]: "z be objectHIDDENM1"
      show " not (z inHIDDENR3 {TARSKIK2 x,y } &  not z be DecoratedTreeTREES-2M4)"
        using A3 A4 tarski_def_2 sorry
    qed "sorry"
    thus "{TARSKIK2 x,y } be constituted-DTreesTREES-3V3"
      using trees_3_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_18:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-TreesTREES-3V1 & Y c=TARSKIR1 X implies Y be constituted-TreesTREES-3V1"
   sorry

mtheorem trees_3_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-FinTreesTREES-3V2 & Y c=TARSKIR1 X implies Y be constituted-FinTreesTREES-3V2"
   sorry

mtheorem trees_3_th_20:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be constituted-DTreesTREES-3V3 & Y c=TARSKIR1 X implies Y be constituted-DTreesTREES-3V3"
   sorry

mtheorem trees_3_cl_4:
"cluster finiteFINSET-1V1\<bar>constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be finiteFINSET-1V1\<bar>constituted-TreesTREES-3V1\<bar>constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar3 be setHIDDENM2 st ((tVar3 be finiteFINSET-1V1 & tVar3 be constituted-TreesTREES-3V1) & tVar3 be constituted-FinTreesTREES-3V2) &  not tVar3 be emptyXBOOLE-0V1"
    proof-
      let ?T = "the finiteFINSET-1V1\<bar>TreeTREES-1M1"
      show " ex tVar3 be setHIDDENM2 st ((tVar3 be finiteFINSET-1V1 & tVar3 be constituted-TreesTREES-3V1) & tVar3 be constituted-FinTreesTREES-3V2) &  not tVar3 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "{TARSKIK1 ?T}"])
        show "(({TARSKIK1 the finiteFINSET-1V1\<bar>TreeTREES-1M1 } be finiteFINSET-1V1 & {TARSKIK1 the finiteFINSET-1V1\<bar>TreeTREES-1M1 } be constituted-TreesTREES-3V1) & {TARSKIK1 the finiteFINSET-1V1\<bar>TreeTREES-1M1 } be constituted-FinTreesTREES-3V2) &  not {TARSKIK1 the finiteFINSET-1V1\<bar>TreeTREES-1M1 } be emptyXBOOLE-0V1"
          using trees_3_th_12 trees_3_th_13 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_5:
"cluster finiteFINSET-1V1\<bar>constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be finiteFINSET-1V1\<bar>constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar4 be setHIDDENM2 st (tVar4 be finiteFINSET-1V1 & tVar4 be constituted-DTreesTREES-3V3) &  not tVar4 be emptyXBOOLE-0V1"
    proof-
      let ?T = "the DecoratedTreeTREES-2M4"
      show " ex tVar4 be setHIDDENM2 st (tVar4 be finiteFINSET-1V1 & tVar4 be constituted-DTreesTREES-3V3) &  not tVar4 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "{TARSKIK1 ?T}"])
        show "({TARSKIK1 the DecoratedTreeTREES-2M4 } be finiteFINSET-1V1 & {TARSKIK1 the DecoratedTreeTREES-2M4 } be constituted-DTreesTREES-3V3) &  not {TARSKIK1 the DecoratedTreeTREES-2M4 } be emptyXBOOLE-0V1"
          using trees_3_th_14 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_6:
"cluster constituted-FinTreesTREES-3V2 also-is constituted-TreesTREES-3V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be constituted-FinTreesTREES-3V2 implies it be constituted-TreesTREES-3V1"
     sorry
qed "sorry"

mtheorem trees_3_cl_7:
  mlet "X be constituted-TreesTREES-3V1\<bar>setHIDDENM2"
"cluster note-that constituted-TreesTREES-3V1 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be constituted-TreesTREES-3V1"
    using trees_3_def_3 sorry
qed "sorry"

mtheorem trees_3_cl_8:
  mlet "X be constituted-FinTreesTREES-3V2\<bar>setHIDDENM2"
"cluster note-that constituted-FinTreesTREES-3V2 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be constituted-FinTreesTREES-3V2"
    using trees_3_def_4 sorry
qed "sorry"

mtheorem trees_3_cl_9:
  mlet "X be constituted-DTreesTREES-3V3\<bar>setHIDDENM2"
"cluster note-that constituted-DTreesTREES-3V3 for SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of X holds it be constituted-DTreesTREES-3V3"
    using trees_3_def_5 sorry
qed "sorry"

mtheorem trees_3_cl_10:
  mlet "D be constituted-TreesTREES-3V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1 for ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D holds it be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
    using trees_3_def_3 sorry
qed "sorry"

mtheorem trees_3_cl_11:
  mlet "D be constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that finiteFINSET-1V1 for ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D holds it be finiteFINSET-1V1"
    using trees_3_def_4 sorry
qed "sorry"

mtheorem trees_3_cl_12:
"cluster constituted-DTreesTREES-3V3 also-is functionalFUNCT-1V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be constituted-DTreesTREES-3V3 implies it be functionalFUNCT-1V6"
     sorry
qed "sorry"

mtheorem trees_3_cl_13:
  mlet "D be constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that DecoratedTree-likeTREES-2V3 for ElementSUBSET-1M1-of D"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of D holds it be DecoratedTree-likeTREES-2V3"
    using trees_3_def_5 sorry
qed "sorry"

mtheorem trees_3_cl_14:
"cluster TreesTREES-3K1 as-term-is constituted-TreesTREES-3V1"
proof
(*coherence*)
  show "TreesTREES-3K1 be constituted-TreesTREES-3V1"
    using trees_3_def_1 sorry
qed "sorry"

mtheorem trees_3_cl_15:
"cluster FinTreesTREES-3K2 as-term-is constituted-FinTreesTREES-3V2"
proof
(*coherence*)
  show "FinTreesTREES-3K2 be constituted-FinTreesTREES-3V2"
    using trees_3_def_2 sorry
qed "sorry"

mtheorem trees_3_cl_16:
"cluster constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1 for SubsetSUBSET-1M2-of TreesTREES-3K1"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of TreesTREES-3K1 st it be constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar5 be SubsetSUBSET-1M2-of TreesTREES-3K1 st tVar5 be constituted-FinTreesTREES-3V2 &  not tVar5 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar5 be SubsetSUBSET-1M2-of TreesTREES-3K1 st tVar5 be constituted-FinTreesTREES-3V2 &  not tVar5 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "FinTreesTREES-3K2"])
        show "FinTreesTREES-3K2 be constituted-FinTreesTREES-3V2 &  not FinTreesTREES-3K2 be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef trees_3_def_6 ("DTree-setTREES-3M1-of  _ " [70]70 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"mode DTree-setTREES-3M1-of D \<rightarrow>  non emptyXBOOLE-0V1\<bar>setHIDDENM2 means
  (\<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it implies x be DecoratedTreeTREES-2M5-of D)"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it implies x be DecoratedTreeTREES-2M5-of D"
    proof-
      have " ex tVar6 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar6 &  not x be DecoratedTreeTREES-2M5-of D)"
      proof-
        show " ex tVar6 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar6 &  not x be DecoratedTreeTREES-2M5-of D)"
        proof(rule bexI[of _ "{DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 elementary-treeTREES-1K2 (0NUMBERSK6),D :]))\<^esub> elementary-treeTREES-1K2 (0NUMBERSK6) -->FUNCOP-1K8\<^bsub>(D)\<^esub> (the ElementSUBSET-1M1-of D) }"])
          show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 {DOMAIN-1K6\<^bsub>(boolZFMISC-1K1 ([:ZFMISC-1K2 elementary-treeTREES-1K2 (0NUMBERSK6),D :]))\<^esub> elementary-treeTREES-1K2 (0NUMBERSK6) -->FUNCOP-1K8\<^bsub>(D)\<^esub> (the ElementSUBSET-1M1-of D) } &  not x be DecoratedTreeTREES-2M5-of D)"
            using tarski_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_3_cl_17:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that constituted-DTreesTREES-3V3 for DTree-setTREES-3M1-of D"
proof
(*coherence*)
  show " for it be DTree-setTREES-3M1-of D holds it be constituted-DTreesTREES-3V3"
    using trees_3_def_6 sorry
qed "sorry"

mtheorem trees_3_cl_18:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1 for DTree-setTREES-3M1-of D"
proof
(*existence*)
  show " ex it be DTree-setTREES-3M1-of D st it be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar7 be DTree-setTREES-3M1-of D st tVar7 be finiteFINSET-1V1 &  not tVar7 be emptyXBOOLE-0V1"
    proof-
      let ?X = "{TARSKIK1 the DecoratedTreeTREES-2M5-of D }"
      have "?X be constituted-DTreesTREES-3V3"
        using tarski_def_1 sorry
      then obtain X where 
        [ty]:"X be  non emptyXBOOLE-0V1\<bar>constituted-DTreesTREES-3V3\<bar>setHIDDENM2" and XDef:"X = ?X"
         sorry
      have "X be DTree-setTREES-3M1-of D"
      proof-
        have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x be DecoratedTreeTREES-2M5-of D)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " not (x inHIDDENR3 X &  not x be DecoratedTreeTREES-2M5-of D)"
            using tarski_def_1 sorry
        qed "sorry"
        thus "X be DTree-setTREES-3M1-of D"
          using trees_3_def_6 sorry
      qed
      then have 
        [ty]:"X be DTree-setTREES-3M1-of D"
         sorry
      show " ex tVar7 be DTree-setTREES-3M1-of D st tVar7 be finiteFINSET-1V1 &  not tVar7 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "X"])
        show "X be finiteFINSET-1V1 &  not X be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_19:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D"
"cluster note-that D -valuedRELAT-1V5 for ElementSUBSET-1M1-of E"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of E holds it be D -valuedRELAT-1V5"
    using trees_3_def_6 sorry
qed "sorry"

abbreviation(input) TREES_3K3("FuncsTREES-3K3'( _ , _ ')" [0,0]228) where
  "FuncsTREES-3K3(T,D) \<equiv> FuncsFUNCT-2K1(T,D)"

mtheorem trees_3_add_1:
  mlet "T be TreeTREES-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(T,D) as-term-is  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(T,D) be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D"
  proof-
    let ?F = "FuncsFUNCT-2K9(T,D)"
    have "?F be constituted-DTreesTREES-3V3"
    proof-
      have "FuncsFUNCT-2K9(T,D) be constituted-DTreesTREES-3V3"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K9(T,D) implies x be DecoratedTreeTREES-2M4"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?F"
          then have " ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 T) & rngFUNCT-1K2 f c=TARSKIR1 D"
            using funct_2_def_2 sorry
          thus "x be DecoratedTreeTREES-2M4"
            using trees_2_def_8 sorry
        qed "sorry"
        thus "FuncsFUNCT-2K9(T,D) be constituted-DTreesTREES-3V3"
          using trees_3_def_5 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain F where 
      [ty]:"F be  non emptyXBOOLE-0V1\<bar>constituted-DTreesTREES-3V3\<bar>setHIDDENM2" and FDef:"F = ?F"
       sorry
    have "F be DTree-setTREES-3M1-of D"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F implies x be DecoratedTreeTREES-2M5-of D"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 F"
        then have " ex f be FunctionFUNCT-1M1 st (x =HIDDENR1 f & domRELAT-1K1 f =XBOOLE-0R4 T) & rngFUNCT-1K2 f c=TARSKIR1 D"
          using funct_2_def_2 sorry
        thus "x be DecoratedTreeTREES-2M5-of D"
          using relat_1_def_19 trees_2_def_8 sorry
      qed "sorry"
      thus "F be DTree-setTREES-3M1-of D"
        using trees_3_def_6 sorry
    qed
    then have 
      [ty]:"F be DTree-setTREES-3M1-of D"
       sorry
    let ?d = "the FunctionFUNCT-2M1-of(T,D)"
    have A1: "domRELSET-1K1\<^bsub>(T)\<^esub> ?d =XBOOLE-0R4 T"
      using funct_2_def_1 sorry
    have "rngRELSET-1K2\<^bsub>(D)\<^esub> ?d c=TARSKIR1 D"
       sorry
    then have "?d inTARSKIR2 F"
      using A1 funct_2_def_2 sorry
    thus "FuncsFUNCT-2K1(T,D) be  non emptyXBOOLE-0V1\<bar>DTree-setTREES-3M1-of D"
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_20:
  mlet "T be TreeTREES-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that DecoratedTree-likeTREES-2V3 for FunctionFUNCT-2M1-of(T,D)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(T,D) holds it be DecoratedTree-likeTREES-2V3"
    using funct_2_def_1 sorry
qed "sorry"

mdef trees_3_def_7 ("TreesTREES-3K4  _ " [164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func TreesTREES-3K4 D \<rightarrow> DTree-setTREES-3M1-of D means
  \<lambda>it.  for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it"
proof-
  (*existence*)
    show " ex it be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it"
    proof-
      have " ex tVar8 be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 tVar8"
      proof-
        let ?A = "{FuncsTREES-3K3(T,D) where T be ElementSUBSET-1M1-of TreesTREES-3K1 :  True  }"
        let ?TT = "unionTARSKIK3 ?A"
        let ?f = "(the ElementSUBSET-1M1-of TreesTREES-3K1)-->FUNCOP-1K8\<^bsub>(D)\<^esub> (the ElementSUBSET-1M1-of D)"
        have A1: "?f inTARSKIR2 FuncsTREES-3K3(the ElementSUBSET-1M1-of TreesTREES-3K1,D)"
          using funct_2_th_8 sorry
        have A2: "FuncsTREES-3K3(the ElementSUBSET-1M1-of TreesTREES-3K1,D) inTARSKIR2 ?A"
           sorry
        have "?TT be constituted-DTreesTREES-3V3"
        proof-
          have "unionTARSKIK3 ({FuncsTREES-3K3(T,D) where T be ElementSUBSET-1M1-of TreesTREES-3K1 :  True  }) be constituted-DTreesTREES-3V3"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 ({FuncsTREES-3K3(T,D) where T be ElementSUBSET-1M1-of TreesTREES-3K1 :  True  }) implies x be DecoratedTreeTREES-2M4"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ?TT"
              then obtain X where
                [ty]:"X be setHIDDENM2" and 
                A3: "x inHIDDENR3 X"and A4: "X inTARSKIR2 {FuncsTREES-3K3(T,D) where T be ElementSUBSET-1M1-of TreesTREES-3K1 :  True  }"
                using tarski_def_4 sorry
              have " ex T be ElementSUBSET-1M1-of TreesTREES-3K1 st X =XBOOLE-0R4 FuncsTREES-3K3(T,D)"
                using A4 sorry
              thus "x be DecoratedTreeTREES-2M4"
                using A3 sorry
            qed "sorry"
            thus "unionTARSKIK3 ({FuncsTREES-3K3(T,D) where T be ElementSUBSET-1M1-of TreesTREES-3K1 :  True  }) be constituted-DTreesTREES-3V3"
              using trees_3_def_5 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain TT where 
          [ty]:"TT be  non emptyXBOOLE-0V1\<bar>constituted-DTreesTREES-3V3\<bar>setHIDDENM2" and TTDef:"TT = ?TT"
          using A2 A1 tarski_def_4 sorry
        have "TT be DTree-setTREES-3M1-of D"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 TT implies x be DecoratedTreeTREES-2M5-of D"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 TT"
            then obtain X where
              [ty]:"X be setHIDDENM2" and 
              A5: "x inHIDDENR3 X"and A6: "X inTARSKIR2 {FuncsTREES-3K3(T,D) where T be ElementSUBSET-1M1-of TreesTREES-3K1 :  True  }"
              using tarski_def_4 sorry
            have " ex T be ElementSUBSET-1M1-of TreesTREES-3K1 st X =XBOOLE-0R4 FuncsTREES-3K3(T,D)"
              using A6 sorry
            thus "x be DecoratedTreeTREES-2M5-of D"
              using A5 sorry
          qed "sorry"
          thus "TT be DTree-setTREES-3M1-of D"
            using trees_3_def_6 sorry
        qed
        then have 
          [ty]:"TT be DTree-setTREES-3M1-of D"
           sorry
        show " ex tVar8 be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 tVar8"
        proof(rule bexI[of _ "TT"],rule ballI)
          fix T assume [ty]: "T be DecoratedTreeTREES-2M5-of D"
          obtain t where 
            [ty]:"t be ElementSUBSET-1M1-of TreesTREES-3K1" and tDef:"t = domRELAT-1K1 T"
            using trees_3_def_1 sorry
          have "rngRELSET-1K2\<^bsub>(D)\<^esub> T c=TARSKIR1 D"
             sorry
          then have A7: "T inTARSKIR2 FuncsTREES-3K3(t,D)"
            using funct_2_def_2 sorry
          have "FuncsTREES-3K3(t,D) inTARSKIR2 {FuncsTREES-3K3(W,D) where W be ElementSUBSET-1M1-of TreesTREES-3K1 :  True  }"
             sorry
          thus "T inTARSKIR2 TT"
            using A7 tarski_def_4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be DTree-setTREES-3M1-of D holds  for it2 be DTree-setTREES-3M1-of D holds ( for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it1) & ( for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 it2) implies it1 =HIDDENR1 it2"
    proof-
      have " for T1 be DTree-setTREES-3M1-of D holds  for T2 be DTree-setTREES-3M1-of D holds ( for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 T1) & ( for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 T2) implies T1 =HIDDENR1 T2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix T1 assume [ty]: "T1 be DTree-setTREES-3M1-of D"
        fix T2 assume [ty]: "T2 be DTree-setTREES-3M1-of D"
        assume A8: " for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 T1"
          and A9: " for T be DecoratedTreeTREES-2M5-of D holds T inTARSKIR2 T2"
        have "T1 c=TARSKIR1 T2 & T2 c=TARSKIR1 T1"
        proof(rule conjMI)
          show "T1 c=TARSKIR1 T2"
            using A9 sorry
          have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 T2 &  not x inHIDDENR3 T1)"
          proof(rule ballI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show " not (x inHIDDENR3 T2 &  not x inHIDDENR3 T1)"
              using A8 sorry
          qed "sorry"
          thus "T2 c=TARSKIR1 T1"
            using tarski_def_3 sorry
        qed
        thus "T1 =HIDDENR1 T2"
          using xboole_0_def_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_3_cl_21:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster TreesTREES-3K4 D as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "TreesTREES-3K4 D be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mdef trees_3_def_8 ("FinTreesTREES-3K5  _ " [164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func FinTreesTREES-3K5 D \<rightarrow> DTree-setTREES-3M1-of D means
  \<lambda>it.  for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it"
proof-
  (*existence*)
    show " ex it be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it"
    proof-
      have " ex tVar9 be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds (domRELAT-1K1 T be finiteFINSET-1V1 implies T inTARSKIR2 tVar9) & (T inTARSKIR2 tVar9 implies domRELAT-1K1 T be finiteFINSET-1V1)"
      proof-
        let ?X = "\<lambda>Lamb1.  ex T be DecoratedTreeTREES-2M5-of D st Lamb1 =HIDDENR1 T & domRELAT-1K1 T be finiteFINSET-1V1"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 TreesTREES-3K4 D & ?X(x)"
          using xboole_0_sch_1 sorry
        let ?T = "the finiteFINSET-1V1\<bar>DecoratedTreeTREES-2M5-of D"
        have A2: "domRELAT-1K1 ?T be finiteFINSET-1V1"
           sorry
        have "?T inTARSKIR2 TreesTREES-3K4 D"
          using trees_3_def_7 sorry
        then have A3: "X be  non emptyXBOOLE-0V1"
          using A1 A2 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be DecoratedTreeTREES-2M5-of D"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have "x inHIDDENR3 TreesTREES-3K4 D"
            using A1 sorry
          thus "x be DecoratedTreeTREES-2M5-of D"
             sorry
        qed "sorry"
        then have 
          [ty]:"X be DTree-setTREES-3M1-of D"
          using A3 trees_3_def_6 sorry
        show " ex tVar9 be DTree-setTREES-3M1-of D st  for T be DecoratedTreeTREES-2M5-of D holds (domRELAT-1K1 T be finiteFINSET-1V1 implies T inTARSKIR2 tVar9) & (T inTARSKIR2 tVar9 implies domRELAT-1K1 T be finiteFINSET-1V1)"
        proof(rule bexI[of _ "X"],rule ballI,rule conjMI,rule impI)
          fix T assume [ty]: "T be DecoratedTreeTREES-2M5-of D"
          have "T inTARSKIR2 TreesTREES-3K4 D"
            using trees_3_def_7 sorry
          thus "domRELAT-1K1 T be finiteFINSET-1V1 implies T inTARSKIR2 X"
            using A1 sorry
          assume "T inTARSKIR2 X"
          then have " ex t be DecoratedTreeTREES-2M5-of D st T =FUNCT-1R1 t & domRELAT-1K1 t be finiteFINSET-1V1"
            using A1 sorry
          thus "domRELAT-1K1 T be finiteFINSET-1V1"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be DTree-setTREES-3M1-of D holds  for it2 be DTree-setTREES-3M1-of D holds ( for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it1) & ( for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 it2) implies it1 =HIDDENR1 it2"
    proof-
      have " for T1 be DTree-setTREES-3M1-of D holds  for T2 be DTree-setTREES-3M1-of D holds ( for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 T1) & ( for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 T2) implies T1 =HIDDENR1 T2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix T1 assume [ty]: "T1 be DTree-setTREES-3M1-of D"
        fix T2 assume [ty]: "T2 be DTree-setTREES-3M1-of D"
        assume A4: " for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 T1"
          and A5: " for T be DecoratedTreeTREES-2M5-of D holds domRELAT-1K1 T be finiteFINSET-1V1 iff T inTARSKIR2 T2"
        have "T1 c=TARSKIR1 T2 & T2 c=TARSKIR1 T1"
        proof(rule conjMI)
          show "T1 c=TARSKIR1 T2"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies x inHIDDENR3 T2"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A6: "x inHIDDENR3 T1"
              then obtain T where 
                [ty]:"T be DecoratedTreeTREES-2M5-of D" and TDef:"T = x"
                 sorry
              have "domRELAT-1K1 T be finiteFINSET-1V1"
                using A4 A6 sorry
              thus "x inHIDDENR3 T2"
                using A5 sorry
            qed "sorry"
            thus "T1 c=TARSKIR1 T2"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 T2 implies x inHIDDENR3 T1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A7: "x inHIDDENR3 T2"
            then obtain T where 
              [ty]:"T be DecoratedTreeTREES-2M5-of D" and TDef:"T = x"
               sorry
            have "domRELAT-1K1 T be finiteFINSET-1V1"
              using A5 A7 sorry
            thus "x inHIDDENR3 T1"
              using A4 sorry
          qed "sorry"
          thus "T2 c=TARSKIR1 T1"
            using tarski_def_3 sorry
        qed
        thus "T1 =HIDDENR1 T2"
          using xboole_0_def_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem trees_3_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds FinTreesTREES-3K5 D c=TARSKIR1 TreesTREES-3K4 D"
  using trees_3_def_7 sorry

(*begin*)
mdef trees_3_def_9 ("Tree-yieldingTREES-3V4" 70 ) where
"attr Tree-yieldingTREES-3V4 for FunctionFUNCT-1M1 means
  (\<lambda>IT. rngFUNCT-1K2 IT be constituted-TreesTREES-3V1)"..

mdef trees_3_def_10 ("FinTree-yieldingTREES-3V5" 70 ) where
"attr FinTree-yieldingTREES-3V5 for FunctionFUNCT-1M1 means
  (\<lambda>IT. rngFUNCT-1K2 IT be constituted-FinTreesTREES-3V2)"..

mdef trees_3_def_11 ("DTree-yieldingTREES-3V6" 70 ) where
"attr DTree-yieldingTREES-3V6 for FunctionFUNCT-1M1 means
  (\<lambda>IT. rngFUNCT-1K2 IT be constituted-DTreesTREES-3V3)"..

mtheorem trees_3_cl_22:
"cluster emptyXBOOLE-0V1 also-is Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>DTree-yieldingTREES-3V6 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>DTree-yieldingTREES-3V6"
     sorry
qed "sorry"

mtheorem trees_3_th_22:
" for f be FunctionFUNCT-1M1 holds f be Tree-yieldingTREES-3V4 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be TreeTREES-1M1)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be Tree-yieldingTREES-3V4 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be TreeTREES-1M1)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be TreeTREES-1M1) implies f be Tree-yieldingTREES-3V4)"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be Tree-yieldingTREES-3V4 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be TreeTREES-1M1)"
    proof-
      have " not (f be Tree-yieldingTREES-3V4 &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x be TreeTREES-1M1)))"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be TreeTREES-1M1) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be TreeTREES-1M1)"
        proof(rule impI,rule ballI,rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be TreeTREES-1M1"
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
          thus "f .FUNCT-1K1 x be TreeTREES-1M1"
            using A1 sorry
        qed "sorry"
        thus " not (f be Tree-yieldingTREES-3V4 &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x be TreeTREES-1M1)))"
          using trees_3_def_3 trees_3_def_9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be TreeTREES-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be TreeTREES-1M1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 f"
      then have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      thus "x be TreeTREES-1M1"
        using A2 sorry
    qed "sorry"
    thus "f be Tree-yieldingTREES-3V4"
      using trees_3_def_3 trees_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_23:
" for f be FunctionFUNCT-1M1 holds f be FinTree-yieldingTREES-3V5 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be FinTree-yieldingTREES-3V5 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies f be FinTree-yieldingTREES-3V5)"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be FinTree-yieldingTREES-3V5 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
    proof-
      have " not (f be FinTree-yieldingTREES-3V5 &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1)))"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
        proof(rule impI,rule ballI,rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
          thus "f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
            using A1 sorry
        qed "sorry"
        thus " not (f be FinTree-yieldingTREES-3V5 &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1)))"
          using trees_3_def_4 trees_3_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 f"
      then have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      thus "x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        using A2 sorry
    qed "sorry"
    thus "f be FinTree-yieldingTREES-3V5"
      using trees_3_def_4 trees_3_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_24:
" for f be FunctionFUNCT-1M1 holds f be DTree-yieldingTREES-3V6 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be DecoratedTreeTREES-2M4)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be DTree-yieldingTREES-3V6 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be DecoratedTreeTREES-2M4)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be DecoratedTreeTREES-2M4) implies f be DTree-yieldingTREES-3V6)"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be DTree-yieldingTREES-3V6 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be DecoratedTreeTREES-2M4)"
    proof-
      have " not (f be DTree-yieldingTREES-3V6 &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x be DecoratedTreeTREES-2M4)))"
      proof-
        have "( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be DecoratedTreeTREES-2M4) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be DecoratedTreeTREES-2M4)"
        proof(rule impI,rule ballI,rule impI)
          assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be DecoratedTreeTREES-2M4"
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
          thus "f .FUNCT-1K1 x be DecoratedTreeTREES-2M4"
            using A1 sorry
        qed "sorry"
        thus " not (f be DTree-yieldingTREES-3V6 &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not f .FUNCT-1K1 x be DecoratedTreeTREES-2M4)))"
          using trees_3_def_5 trees_3_def_11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be DecoratedTreeTREES-2M4"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x be DecoratedTreeTREES-2M4"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 f"
      then have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 y"
        using funct_1_def_3 sorry
      thus "x be DecoratedTreeTREES-2M4"
        using A2 sorry
    qed "sorry"
    thus "f be DTree-yieldingTREES-3V6"
      using trees_3_def_5 trees_3_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_25:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4 iff p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4 implies p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4) &  not (p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4 &  not (p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have A1: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using finseq_1_th_31 sorry
    show "p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4 implies p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4"
      using A1 trees_3_th_3 sorry
    have "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) be constituted-TreesTREES-3V1 implies p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4"
    proof(rule impI)
      assume A2: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) be constituted-TreesTREES-3V1"
      have "rngFUNCT-1K2 p be constituted-TreesTREES-3V1 & q be Tree-yieldingTREES-3V4"
      proof(rule conjMI)
        show "rngFUNCT-1K2 p be constituted-TreesTREES-3V1"
          using A1 trees_3_th_3 A2 sorry
        have "rngFUNCT-1K2 q be constituted-TreesTREES-3V1"
        proof-
          show "rngFUNCT-1K2 q be constituted-TreesTREES-3V1"
            using A1 A2 trees_3_th_3 sorry
        qed
        thus "q be Tree-yieldingTREES-3V4"
          using trees_3_def_9 sorry
      qed
      thus "p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4"
        using trees_3_def_9 sorry
    qed
    thus " not (p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4 &  not (p be Tree-yieldingTREES-3V4 & q be Tree-yieldingTREES-3V4))"
      using trees_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_26:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5 iff p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5 implies p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5) &  not (p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5 &  not (p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have A1: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using finseq_1_th_31 sorry
    show "p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5 implies p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5"
      using A1 trees_3_th_6 sorry
    have "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) be constituted-FinTreesTREES-3V2 implies p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5"
    proof(rule impI)
      assume A2: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) be constituted-FinTreesTREES-3V2"
      have "rngFUNCT-1K2 p be constituted-FinTreesTREES-3V2 & q be FinTree-yieldingTREES-3V5"
      proof(rule conjMI)
        show "rngFUNCT-1K2 p be constituted-FinTreesTREES-3V2"
          using A1 trees_3_th_6 A2 sorry
        have "rngFUNCT-1K2 q be constituted-FinTreesTREES-3V2"
        proof-
          show "rngFUNCT-1K2 q be constituted-FinTreesTREES-3V2"
            using A1 A2 trees_3_th_6 sorry
        qed
        thus "q be FinTree-yieldingTREES-3V5"
          using trees_3_def_10 sorry
      qed
      thus "p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5"
        using trees_3_def_10 sorry
    qed
    thus " not (p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5 &  not (p be FinTree-yieldingTREES-3V5 & q be FinTree-yieldingTREES-3V5))"
      using trees_3_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_27:
" for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6 iff p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds (p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6 implies p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6) &  not (p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6 &  not (p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    have A1: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 rngFUNCT-1K2 q"
      using finseq_1_th_31 sorry
    show "p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6 implies p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6"
      using A1 trees_3_th_9 sorry
    have "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) be constituted-DTreesTREES-3V3 implies p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6"
    proof(rule impI)
      assume A2: "rngFUNCT-1K2 (p ^FINSEQ-1K8 q) be constituted-DTreesTREES-3V3"
      have "rngFUNCT-1K2 p be constituted-DTreesTREES-3V3 & q be DTree-yieldingTREES-3V6"
      proof(rule conjMI)
        show "rngFUNCT-1K2 p be constituted-DTreesTREES-3V3"
          using A1 trees_3_th_9 A2 sorry
        have "rngFUNCT-1K2 q be constituted-DTreesTREES-3V3"
        proof-
          show "rngFUNCT-1K2 q be constituted-DTreesTREES-3V3"
            using A1 A2 trees_3_th_9 sorry
        qed
        thus "q be DTree-yieldingTREES-3V6"
          using trees_3_def_11 sorry
      qed
      thus "p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6"
        using trees_3_def_11 sorry
    qed
    thus " not (p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6 &  not (p be DTree-yieldingTREES-3V6 & q be DTree-yieldingTREES-3V6))"
      using trees_3_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_28:
" for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> be Tree-yieldingTREES-3V4 iff x be TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds  not (<*FINSEQ-1K10 x*> be Tree-yieldingTREES-3V4 &  not x be TreeTREES-1M1) &  not (x be TreeTREES-1M1 &  not <*FINSEQ-1K10 x*> be Tree-yieldingTREES-3V4)"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "x be TreeTREES-1M1 iff {TARSKIK1 x} be constituted-TreesTREES-3V1"
      using trees_3_th_12 sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 x}"
      using finseq_1_th_39 sorry
    thus " not (<*FINSEQ-1K10 x*> be Tree-yieldingTREES-3V4 &  not x be TreeTREES-1M1) &  not (x be TreeTREES-1M1 &  not <*FINSEQ-1K10 x*> be Tree-yieldingTREES-3V4)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_29:
" for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> be FinTree-yieldingTREES-3V5 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds  not (<*FINSEQ-1K10 x*> be FinTree-yieldingTREES-3V5 &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1) &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 &  not <*FINSEQ-1K10 x*> be FinTree-yieldingTREES-3V5)"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "x be finiteFINSET-1V1\<bar>TreeTREES-1M1 iff {TARSKIK1 x} be constituted-FinTreesTREES-3V2"
      using trees_3_th_13 sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 x}"
      using finseq_1_th_39 sorry
    thus " not (<*FINSEQ-1K10 x*> be FinTree-yieldingTREES-3V5 &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1) &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 &  not <*FINSEQ-1K10 x*> be FinTree-yieldingTREES-3V5)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_30:
" for x be objectHIDDENM1 holds <*FINSEQ-1K10 x*> be DTree-yieldingTREES-3V6 iff x be DecoratedTreeTREES-2M4"
proof-
  have " for x be objectHIDDENM1 holds  not (<*FINSEQ-1K10 x*> be DTree-yieldingTREES-3V6 &  not x be DecoratedTreeTREES-2M4) &  not (x be DecoratedTreeTREES-2M4 &  not <*FINSEQ-1K10 x*> be DTree-yieldingTREES-3V6)"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have A1: "x be DecoratedTreeTREES-2M4 iff {TARSKIK1 x} be constituted-DTreesTREES-3V3"
      using trees_3_th_14 sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 {TARSKIK1 x}"
      using finseq_1_th_39 sorry
    thus " not (<*FINSEQ-1K10 x*> be DTree-yieldingTREES-3V6 &  not x be DecoratedTreeTREES-2M4) &  not (x be DecoratedTreeTREES-2M4 &  not <*FINSEQ-1K10 x*> be DTree-yieldingTREES-3V6)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_31:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <*FINSEQ-1K11 x,y *> be Tree-yieldingTREES-3V4 iff x be TreeTREES-1M1 & y be TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (<*FINSEQ-1K11 x,y *> be Tree-yieldingTREES-3V4 &  not (x be TreeTREES-1M1 & y be TreeTREES-1M1)) &  not ((x be TreeTREES-1M1 & y be TreeTREES-1M1) &  not <*FINSEQ-1K11 x,y *> be Tree-yieldingTREES-3V4)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have A1: "x be TreeTREES-1M1 & y be TreeTREES-1M1 iff {TARSKIK2 x,y } be constituted-TreesTREES-3V1"
      using trees_3_th_15 sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 {TARSKIK2 x,y }"
      using finseq_2_th_127 sorry
    thus " not (<*FINSEQ-1K11 x,y *> be Tree-yieldingTREES-3V4 &  not (x be TreeTREES-1M1 & y be TreeTREES-1M1)) &  not ((x be TreeTREES-1M1 & y be TreeTREES-1M1) &  not <*FINSEQ-1K11 x,y *> be Tree-yieldingTREES-3V4)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_32:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <*FINSEQ-1K11 x,y *> be FinTree-yieldingTREES-3V5 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (<*FINSEQ-1K11 x,y *> be FinTree-yieldingTREES-3V5 &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1)) &  not ((x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1) &  not <*FINSEQ-1K11 x,y *> be FinTree-yieldingTREES-3V5)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have A1: "x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1 iff {TARSKIK2 x,y } be constituted-FinTreesTREES-3V2"
      using trees_3_th_16 sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 {TARSKIK2 x,y }"
      using finseq_2_th_127 sorry
    thus " not (<*FINSEQ-1K11 x,y *> be FinTree-yieldingTREES-3V5 &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1)) &  not ((x be finiteFINSET-1V1\<bar>TreeTREES-1M1 & y be finiteFINSET-1V1\<bar>TreeTREES-1M1) &  not <*FINSEQ-1K11 x,y *> be FinTree-yieldingTREES-3V5)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_33:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds <*FINSEQ-1K11 x,y *> be DTree-yieldingTREES-3V6 iff x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not (<*FINSEQ-1K11 x,y *> be DTree-yieldingTREES-3V6 &  not (x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4)) &  not ((x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4) &  not <*FINSEQ-1K11 x,y *> be DTree-yieldingTREES-3V6)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have A1: "x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4 iff {TARSKIK2 x,y } be constituted-DTreesTREES-3V3"
      using trees_3_th_17 sorry
    have "rngFUNCT-1K2 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 {TARSKIK2 x,y }"
      using finseq_2_th_127 sorry
    thus " not (<*FINSEQ-1K11 x,y *> be DTree-yieldingTREES-3V6 &  not (x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4)) &  not ((x be DecoratedTreeTREES-2M4 & y be DecoratedTreeTREES-2M4) &  not <*FINSEQ-1K11 x,y *> be DTree-yieldingTREES-3V6)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_34:
" for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i  |->FINSEQ-2K2 x be Tree-yieldingTREES-3V4 iff x be TreeTREES-1M1)"
proof-
  have " for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies  not (i  |->FINSEQ-2K2 x be Tree-yieldingTREES-3V4 &  not x be TreeTREES-1M1) &  not (x be TreeTREES-1M1 &  not i  |->FINSEQ-2K2 x be Tree-yieldingTREES-3V4)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i <>HIDDENR2 0NUMBERSK6"
    have "i  |->FINSEQ-2K2 x =FINSEQ-1R1 SegFINSEQ-1K2 i -->FUNCOP-1K7 x"
      using finseq_2_def_2 sorry
    then have "rngFUNCT-1K2 (i  |->FINSEQ-2K2 x) =XBOOLE-0R4 {TARSKIK1 x}"
      using A1 funcop_1_th_8 sorry
    then have "x be TreeTREES-1M1 iff rngFUNCT-1K2 (i  |->FINSEQ-2K2 x) be constituted-TreesTREES-3V1"
      using trees_3_th_12 sorry
    thus " not (i  |->FINSEQ-2K2 x be Tree-yieldingTREES-3V4 &  not x be TreeTREES-1M1) &  not (x be TreeTREES-1M1 &  not i  |->FINSEQ-2K2 x be Tree-yieldingTREES-3V4)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_35:
" for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i  |->FINSEQ-2K2 x be FinTree-yieldingTREES-3V5 iff x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
proof-
  have " for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies  not (i  |->FINSEQ-2K2 x be FinTree-yieldingTREES-3V5 &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1) &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 &  not i  |->FINSEQ-2K2 x be FinTree-yieldingTREES-3V5)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i <>HIDDENR2 0NUMBERSK6"
    have "i  |->FINSEQ-2K2 x =FINSEQ-1R1 SegFINSEQ-1K2 i -->FUNCOP-1K7 x"
      using finseq_2_def_2 sorry
    then have "rngFUNCT-1K2 (i  |->FINSEQ-2K2 x) =XBOOLE-0R4 {TARSKIK1 x}"
      using A1 funcop_1_th_8 sorry
    then have "x be finiteFINSET-1V1\<bar>TreeTREES-1M1 iff rngFUNCT-1K2 (i  |->FINSEQ-2K2 x) be constituted-FinTreesTREES-3V2"
      using trees_3_th_13 sorry
    thus " not (i  |->FINSEQ-2K2 x be FinTree-yieldingTREES-3V5 &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1) &  not (x be finiteFINSET-1V1\<bar>TreeTREES-1M1 &  not i  |->FINSEQ-2K2 x be FinTree-yieldingTREES-3V5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_36:
" for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i  |->FINSEQ-2K2 x be DTree-yieldingTREES-3V6 iff x be DecoratedTreeTREES-2M4)"
proof-
  have " for x be objectHIDDENM1 holds  for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies  not (i  |->FINSEQ-2K2 x be DTree-yieldingTREES-3V6 &  not x be DecoratedTreeTREES-2M4) &  not (x be DecoratedTreeTREES-2M4 &  not i  |->FINSEQ-2K2 x be DTree-yieldingTREES-3V6)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i <>HIDDENR2 0NUMBERSK6"
    have "i  |->FINSEQ-2K2 x =FINSEQ-1R1 SegFINSEQ-1K2 i -->FUNCOP-1K7 x"
      using finseq_2_def_2 sorry
    then have "rngFUNCT-1K2 (i  |->FINSEQ-2K2 x) =XBOOLE-0R4 {TARSKIK1 x}"
      using A1 funcop_1_th_8 sorry
    then have "x be DecoratedTreeTREES-2M4 iff rngFUNCT-1K2 (i  |->FINSEQ-2K2 x) be constituted-DTreesTREES-3V3"
      using trees_3_th_14 sorry
    thus " not (i  |->FINSEQ-2K2 x be DTree-yieldingTREES-3V6 &  not x be DecoratedTreeTREES-2M4) &  not (x be DecoratedTreeTREES-2M4 &  not i  |->FINSEQ-2K2 x be DTree-yieldingTREES-3V6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_cl_23:
"cluster Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar10 be FinSequenceFINSEQ-1M1 st (tVar10 be Tree-yieldingTREES-3V4 & tVar10 be FinTree-yieldingTREES-3V5) &  not tVar10 be emptyXBOOLE-0V1"
    proof-
      let ?T = "the finiteFINSET-1V1\<bar>TreeTREES-1M1"
      show " ex tVar10 be FinSequenceFINSEQ-1M1 st (tVar10 be Tree-yieldingTREES-3V4 & tVar10 be FinTree-yieldingTREES-3V5) &  not tVar10 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "<*FINSEQ-1K10 ?T*>"])
        show "(<*FINSEQ-1K10 the finiteFINSET-1V1\<bar>TreeTREES-1M1 *> be Tree-yieldingTREES-3V4 & <*FINSEQ-1K10 the finiteFINSET-1V1\<bar>TreeTREES-1M1 *> be FinTree-yieldingTREES-3V5) &  not <*FINSEQ-1K10 the finiteFINSET-1V1\<bar>TreeTREES-1M1 *> be emptyXBOOLE-0V1"
          using trees_3_th_28 trees_3_th_29 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_24:
"cluster DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar11 be FinSequenceFINSEQ-1M1 st tVar11 be DTree-yieldingTREES-3V6 &  not tVar11 be emptyXBOOLE-0V1"
    proof-
      let ?T = "the DecoratedTreeTREES-2M4"
      show " ex tVar11 be FinSequenceFINSEQ-1M1 st tVar11 be DTree-yieldingTREES-3V6 &  not tVar11 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "<*FINSEQ-1K10 ?T*>"])
        show "<*FINSEQ-1K10 the DecoratedTreeTREES-2M4 *> be DTree-yieldingTREES-3V6 &  not <*FINSEQ-1K10 the DecoratedTreeTREES-2M4 *> be emptyXBOOLE-0V1"
          using trees_3_th_30 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_25:
"cluster Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar12 be FunctionFUNCT-1M1 st (the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be Tree-yieldingTREES-3V4 & the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be FinTree-yieldingTREES-3V5) &  not the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be emptyXBOOLE-0V1"
    proof-
      let ?p = "the Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
      show " ex tVar12 be FunctionFUNCT-1M1 st (the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be Tree-yieldingTREES-3V4 & the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be FinTree-yieldingTREES-3V5) &  not the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "?p"])
        show "(the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be Tree-yieldingTREES-3V4 & the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be FinTree-yieldingTREES-3V5) &  not the  non emptyXBOOLE-0V1\<bar>Tree-yieldingTREES-3V4\<bar>FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_26:
"cluster DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar13 be FunctionFUNCT-1M1 st the  non emptyXBOOLE-0V1\<bar>DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 be DTree-yieldingTREES-3V6 &  not the  non emptyXBOOLE-0V1\<bar>DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 be emptyXBOOLE-0V1"
    proof-
      let ?p = "the DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
      show " ex tVar13 be FunctionFUNCT-1M1 st the  non emptyXBOOLE-0V1\<bar>DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 be DTree-yieldingTREES-3V6 &  not the  non emptyXBOOLE-0V1\<bar>DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "?p"])
        show "the  non emptyXBOOLE-0V1\<bar>DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 be DTree-yieldingTREES-3V6 &  not the  non emptyXBOOLE-0V1\<bar>DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_27:
"cluster FinTree-yieldingTREES-3V5 also-is Tree-yieldingTREES-3V4 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be FinTree-yieldingTREES-3V5 implies it be Tree-yieldingTREES-3V4"
     sorry
qed "sorry"

mtheorem trees_3_cl_28:
  mlet "D be constituted-TreesTREES-3V1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that Tree-yieldingTREES-3V4 for FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of D holds it be Tree-yieldingTREES-3V4"
  proof-
    have " for p be FinSequenceFINSEQ-1M3-of D holds p be Tree-yieldingTREES-3V4"
    proof(rule ballI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 rngFUNCT-1K2 p &  not x be TreeTREES-1M1)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "rngRELSET-1K2\<^bsub>(D)\<^esub> p c=TARSKIR1 D"
           sorry
        thus " not (x inHIDDENR3 rngFUNCT-1K2 p &  not x be TreeTREES-1M1)"
           sorry
      qed "sorry"
      thus "p be Tree-yieldingTREES-3V4"
        using trees_3_def_3 trees_3_def_9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_29:
  mlet "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1", "q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
"cluster p ^FINSEQ-1K8 q as-term-is Tree-yieldingTREES-3V4"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be Tree-yieldingTREES-3V4"
    using trees_3_th_25 sorry
qed "sorry"

mtheorem trees_3_cl_30:
  mlet "D be constituted-FinTreesTREES-3V2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that FinTree-yieldingTREES-3V5 for FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of D holds it be FinTree-yieldingTREES-3V5"
  proof-
    have " for p be FinSequenceFINSEQ-1M3-of D holds p be FinTree-yieldingTREES-3V5"
    proof(rule ballI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 rngFUNCT-1K2 p &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "rngRELSET-1K2\<^bsub>(D)\<^esub> p c=TARSKIR1 D"
           sorry
        thus " not (x inHIDDENR3 rngFUNCT-1K2 p &  not x be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
           sorry
      qed "sorry"
      thus "p be FinTree-yieldingTREES-3V5"
        using trees_3_def_4 trees_3_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_31:
  mlet "p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1", "q be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
"cluster p ^FINSEQ-1K8 q as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be FinTree-yieldingTREES-3V5"
    using trees_3_th_26 sorry
qed "sorry"

mtheorem trees_3_cl_32:
  mlet "D be constituted-DTreesTREES-3V3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that DTree-yieldingTREES-3V6 for FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show " for it be FinSequenceFINSEQ-1M3-of D holds it be DTree-yieldingTREES-3V6"
  proof-
    have " for p be FinSequenceFINSEQ-1M3-of D holds p be DTree-yieldingTREES-3V6"
    proof(rule ballI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 rngFUNCT-1K2 p &  not x be DecoratedTreeTREES-2M4)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "rngRELSET-1K2\<^bsub>(D)\<^esub> p c=TARSKIR1 D"
           sorry
        thus " not (x inHIDDENR3 rngFUNCT-1K2 p &  not x be DecoratedTreeTREES-2M4)"
           sorry
      qed "sorry"
      thus "p be DTree-yieldingTREES-3V6"
        using trees_3_def_5 trees_3_def_11 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_33:
  mlet "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1", "q be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
"cluster p ^FINSEQ-1K8 q as-term-is DTree-yieldingTREES-3V6"
proof
(*coherence*)
  show "p ^FINSEQ-1K8 q be DTree-yieldingTREES-3V6"
    using trees_3_th_27 sorry
qed "sorry"

mtheorem trees_3_cl_34:
  mlet "T be TreeTREES-1M1"
"cluster <*FINSEQ-1K10 T*> as-term-is Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 T*> be Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_28 sorry
qed "sorry"

mtheorem trees_3_cl_35:
  mlet "T be TreeTREES-1M1", "S be TreeTREES-1M1"
"cluster <*FINSEQ-1K11 T,S *> as-term-is Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 T,S *> be Tree-yieldingTREES-3V4\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_31 sorry
qed "sorry"

mtheorem trees_3_cl_36:
  mlet "n be NatNAT-1M1", "T be TreeTREES-1M1"
"cluster n  |->FINSEQ-2K2 T as-term-is Tree-yieldingTREES-3V4"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 T be Tree-yieldingTREES-3V4"
  proof-
    have "(0NUMBERSK6) |->FINSEQ-2K2 T =FINSEQ-1R1 {}XBOOLE-0K1"
       sorry
    thus "n  |->FINSEQ-2K2 T be Tree-yieldingTREES-3V4"
      using trees_3_th_34 sorry
  qed
qed "sorry"

mtheorem trees_3_cl_37:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster <*FINSEQ-1K10 T*> as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "<*FINSEQ-1K10 T*> be FinTree-yieldingTREES-3V5"
    using trees_3_th_29 sorry
qed "sorry"

mtheorem trees_3_cl_38:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1", "S be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster <*FINSEQ-1K11 T,S *> as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "<*FINSEQ-1K11 T,S *> be FinTree-yieldingTREES-3V5"
    using trees_3_th_32 sorry
qed "sorry"

mtheorem trees_3_cl_39:
  mlet "n be NatNAT-1M1", "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster n  |->FINSEQ-2K2 T as-term-is FinTree-yieldingTREES-3V5"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 T be FinTree-yieldingTREES-3V5"
  proof-
    have "(0NUMBERSK6) |->FINSEQ-2K2 T =FINSEQ-1R1 {}XBOOLE-0K1"
       sorry
    thus "n  |->FINSEQ-2K2 T be FinTree-yieldingTREES-3V5"
      using trees_3_th_35 sorry
  qed
qed "sorry"

mtheorem trees_3_cl_40:
  mlet "T be DecoratedTreeTREES-2M4"
"cluster <*FINSEQ-1K10 T*> as-term-is DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 T*> be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_30 sorry
qed "sorry"

mtheorem trees_3_cl_41:
  mlet "T be DecoratedTreeTREES-2M4", "S be DecoratedTreeTREES-2M4"
"cluster <*FINSEQ-1K11 T,S *> as-term-is DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 T,S *> be DTree-yieldingTREES-3V6\<bar> non emptyXBOOLE-0V1"
    using trees_3_th_33 sorry
qed "sorry"

mtheorem trees_3_cl_42:
  mlet "n be NatNAT-1M1", "T be DecoratedTreeTREES-2M4"
"cluster n  |->FINSEQ-2K2 T as-term-is DTree-yieldingTREES-3V6"
proof
(*coherence*)
  show "n  |->FINSEQ-2K2 T be DTree-yieldingTREES-3V6"
  proof-
    have "(0NUMBERSK6) |->FINSEQ-2K2 T =FINSEQ-1R1 {}XBOOLE-0K1"
       sorry
    thus "n  |->FINSEQ-2K2 T be DTree-yieldingTREES-3V6"
      using trees_3_th_36 sorry
  qed
qed "sorry"

mtheorem trees_3_cl_43:
"cluster DTree-yieldingTREES-3V6 also-is Function-yieldingFUNCOP-1V1 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be DTree-yieldingTREES-3V6 implies it be Function-yieldingFUNCOP-1V1"
  proof-
    have " for f be FunctionFUNCT-1M1 holds  not (f be DTree-yieldingTREES-3V6 &  not f be Function-yieldingFUNCOP-1V1)"
    proof(rule ballI)
      fix f assume [ty]: "f be FunctionFUNCT-1M1"
      have "rngFUNCT-1K2 f be constituted-DTreesTREES-3V3 implies f be Function-yieldingFUNCOP-1V1"
      proof(rule impI)
        assume A1: "rngFUNCT-1K2 f be constituted-DTreesTREES-3V3"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be FunctionFUNCT-1M1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_th_3 sorry
          then have "f .FUNCT-1K1 x be DecoratedTreeTREES-2M4"
            using A1 sorry
          thus "f .FUNCT-1K1 x be FunctionFUNCT-1M1"
             sorry
        qed "sorry"
        thus "f be Function-yieldingFUNCOP-1V1"
          using funcop_1_def_6 sorry
      qed
      thus " not (f be DTree-yieldingTREES-3V6 &  not f be Function-yieldingFUNCOP-1V1)"
        using trees_3_def_11 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_th_37:
" for f be DTree-yieldingTREES-3V6\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f & domsFUNCT-6K1 f be Tree-yieldingTREES-3V4"
proof(rule ballI)
  fix f assume [ty]: "f be DTree-yieldingTREES-3V6\<bar>FunctionFUNCT-1M1"
  have A1: "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f"
    using funct_6_def_2 sorry
  have "domRELAT-1K1 (domsFUNCT-6K1 f) c=TARSKIR1 domRELAT-1K1 f & (domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 (domsFUNCT-6K1 f) & domsFUNCT-6K1 f be Tree-yieldingTREES-3V4)"
  proof(rule conjMI,rule conjMI)
    show "domRELAT-1K1 (domsFUNCT-6K1 f) c=TARSKIR1 domRELAT-1K1 f"
      using A1 sorry
    show "domRELAT-1K1 f c=TARSKIR1 domRELAT-1K1 (domsFUNCT-6K1 f)"
      using A1 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f) implies domsFUNCT-6K1 f .FUNCT-1K1 x be TreeTREES-1M1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 (domsFUNCT-6K1 f)"
      then have A2: "x inHIDDENR3 domRELAT-1K1 f"
        using A1 sorry
      then obtain g where 
        [ty]:"g be DecoratedTreeTREES-2M4" and gDef:"g = f .FUNCT-1K1 x"
        using trees_3_th_24 sorry
      have "domsFUNCT-6K1 f .FUNCT-1K1 x =XBOOLE-0R4 domRELAT-1K1 g"
        using A2 funct_6_th_22 sorry
      thus "domsFUNCT-6K1 f .FUNCT-1K1 x be TreeTREES-1M1"
         sorry
    qed "sorry"
    thus "domsFUNCT-6K1 f be Tree-yieldingTREES-3V4"
      using trees_3_th_22 sorry
  qed
  thus "domRELAT-1K1 (domsFUNCT-6K1 f) =XBOOLE-0R4 domRELAT-1K1 f & domsFUNCT-6K1 f be Tree-yieldingTREES-3V4"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem trees_3_cl_44:
  mlet "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
"cluster domsFUNCT-6K1 p as-term-is Tree-yieldingTREES-3V4\<bar>FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "domsFUNCT-6K1 p be Tree-yieldingTREES-3V4\<bar>FinSequence-likeFINSEQ-1V1"
  proof-
    have "domsFUNCT-6K1 p be Tree-yieldingTREES-3V4 & domsFUNCT-6K1 p be FinSequence-likeFINSEQ-1V1"
    proof-
      have A1: "domRELAT-1K1 (domsFUNCT-6K1 p) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
        using trees_3_th_37 sorry
      have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
        using finseq_1_def_3 sorry
      thus "domsFUNCT-6K1 p be Tree-yieldingTREES-3V4 & domsFUNCT-6K1 p be FinSequence-likeFINSEQ-1V1"
        using A1 trees_3_th_37 finseq_1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem trees_3_th_38:
" for p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
proof(rule ballI)
  fix p assume [ty]: "p be DTree-yieldingTREES-3V6\<bar>FinSequenceFINSEQ-1M1"
  have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (domsFUNCT-6K1 p)"
    using trees_3_th_37 sorry
  have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
    using finseq_1_def_3 sorry
  thus "lenFINSEQ-1K4 (domsFUNCT-6K1 p) =XBOOLE-0R4 lenFINSEQ-1K4 p"
    using A1 finseq_1_def_3 sorry
qed "sorry"

mlemma trees_3_lm_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-2M5-of D holds T be FunctionFUNCT-2M1-of(domRELAT-1K1 T,D)"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix T assume [ty]: "T be DecoratedTreeTREES-2M5-of D"
  have "rngRELSET-1K2\<^bsub>(D)\<^esub> T c=TARSKIR1 D"
     sorry
  thus "T be FunctionFUNCT-2M1-of(domRELAT-1K1 T,D)"
    using funct_2_def_1 relset_1_th_4 sorry
qed "sorry"

(*begin*)
syntax TREES_3M2 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("DecoratedTreeTREES-3M2-of'( _ , _ ')" [0,0]70)
translations "DecoratedTreeTREES-3M2-of(D,E)" \<rightharpoonup> "DecoratedTreeTREES-2M5-of [:ZFMISC-1K2 D,E :]"

syntax TREES_3M3 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("DTree-setTREES-3M3-of'( _ , _ ')" [0,0]70)
translations "DTree-setTREES-3M3-of(D,E)" \<rightharpoonup> "DTree-setTREES-3M1-of [:ZFMISC-1K2 D,E :]"

mtheorem trees_3_cl_45:
  mlet "T1 be DecoratedTreeTREES-2M4", "T2 be DecoratedTreeTREES-2M4"
"cluster <:FUNCT-3K14 T1,T2 :> as-term-is DecoratedTree-likeTREES-2V3"
proof
(*coherence*)
  show "<:FUNCT-3K14 T1,T2 :> be DecoratedTree-likeTREES-2V3"
  proof-
    have "domRELAT-1K1 (<:FUNCT-3K14 T1,T2 :>) =XBOOLE-0R4 domRELAT-1K1 T1 /\\XBOOLE-0K3 domRELAT-1K1 T2"
      using funct_3_def_7 sorry
    thus "<:FUNCT-3K14 T1,T2 :> be DecoratedTree-likeTREES-2V3"
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_46:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T1 be DecoratedTreeTREES-2M5-of D1", "T2 be DecoratedTreeTREES-2M5-of D2"
"cluster <:FUNCT-3K14 T1,T2 :> as-term-is [:ZFMISC-1K2 D1,D2 :] -valuedRELAT-1V5"
proof
(*coherence*)
  show "<:FUNCT-3K14 T1,T2 :> be [:ZFMISC-1K2 D1,D2 :] -valuedRELAT-1V5"
  proof-
    have A1: "rngFUNCT-1K2 (<:FUNCT-3K14 T1,T2 :>) c=TARSKIR1 [:ZFMISC-1K2 rngRELSET-1K2\<^bsub>(D1)\<^esub> T1,rngRELSET-1K2\<^bsub>(D2)\<^esub> T2 :]"
      using funct_3_th_51 sorry
    have "[:ZFMISC-1K2 rngRELSET-1K2\<^bsub>(D1)\<^esub> T1,rngRELSET-1K2\<^bsub>(D2)\<^esub> T2 :] c=RELAT-1R2 [:ZFMISC-1K2 D1,D2 :]"
      using zfmisc_1_th_96 sorry
    then have "rngFUNCT-1K2 (<:FUNCT-3K14 T1,T2 :>) c=TARSKIR1 [:ZFMISC-1K2 D1,D2 :]"
      using A1 sorry
    thus "<:FUNCT-3K14 T1,T2 :> be [:ZFMISC-1K2 D1,D2 :] -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem trees_3_cl_47:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-2M5-of D", "f be FunctionFUNCT-2M1-of(D,E)"
"cluster f *FUNCT-1K3 T as-term-is DecoratedTree-likeTREES-2V3"
proof
(*coherence*)
  show "f *FUNCT-1K3 T be DecoratedTree-likeTREES-2V3"
  proof-
    obtain g where 
      [ty]:"g be FunctionFUNCT-2M1-of(domRELAT-1K1 T,D)" and gDef:"g = T"
      using trees_3_lm_2 sorry
    obtain fg where 
      [ty]:"fg be FunctionFUNCT-2M1-of(domRELAT-1K1 T,E)" and fgDef:"fg = f *PARTFUN1K1\<^bsub>(domRELAT-1K1 T,D,D,E)\<^esub> g"
       sorry
    have "rngRELSET-1K2\<^bsub>(E)\<^esub> fg c=TARSKIR1 E"
       sorry
    thus "f *FUNCT-1K3 T be DecoratedTree-likeTREES-2V3"
       sorry
  qed
qed "sorry"

abbreviation(input) TREES_3K6("pr1TREES-3K6'( _ , _ ')" [0,0]228) where
  "pr1TREES-3K6(D1,D2) \<equiv> pr1FUNCT-3K8(D1,D2)"

mtheorem trees_3_add_2:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster pr1FUNCT-3K8(D1,D2) as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D1)"
proof
(*coherence*)
  show "pr1FUNCT-3K8(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D1)"
  proof-
    have "pr1FUNCT-3K10(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D1)"
    proof-
      show "pr1FUNCT-3K10(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) TREES_3K7("pr2TREES-3K7'( _ , _ ')" [0,0]228) where
  "pr2TREES-3K7(D1,D2) \<equiv> pr2FUNCT-3K9(D1,D2)"

mtheorem trees_3_add_3:
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster pr2FUNCT-3K9(D1,D2) as-term-is FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D2)"
proof
(*coherence*)
  show "pr2FUNCT-3K9(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D2)"
  proof-
    have "pr2FUNCT-3K11(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D2)"
    proof-
      show "pr2FUNCT-3K11(D1,D2) be FunctionFUNCT-2M1-of([:ZFMISC-1K2 D1,D2 :],D2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef trees_3_def_12 (" _ `1TREES-3K8\<^bsub>'( _ , _ ')\<^esub>" [355,0,0]355 ) where
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-3M2-of(D1,D2)"
"func T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> \<rightarrow> DecoratedTreeTREES-2M5-of D1 equals
  pr1TREES-3K6(D1,D2) *FUNCT-1K3 T"
proof-
  (*coherence*)
    show "pr1TREES-3K6(D1,D2) *FUNCT-1K3 T be DecoratedTreeTREES-2M5-of D1"
       sorry
qed "sorry"

mdef trees_3_def_13 (" _ `2TREES-3K9\<^bsub>'( _ , _ ')\<^esub>" [355,0,0]355 ) where
  mlet "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "T be DecoratedTreeTREES-3M2-of(D1,D2)"
"func T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> \<rightarrow> DecoratedTreeTREES-2M5-of D2 equals
  pr2TREES-3K7(D1,D2) *FUNCT-1K3 T"
proof-
  (*coherence*)
    show "pr2TREES-3K7(D1,D2) *FUNCT-1K3 T be DecoratedTreeTREES-2M5-of D2"
       sorry
qed "sorry"

mtheorem trees_3_th_39:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-3M2-of(D1,D2) holds  for t be ElementTREES-1M2-of domRELAT-1K1 T holds (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub> =XBOOLE-0R4 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t & T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t =XBOOLE-0R4 (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub>"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix T assume [ty]: "T be DecoratedTreeTREES-3M2-of(D1,D2)"
  fix t assume [ty]: "t be ElementTREES-1M2-of domRELAT-1K1 T"
  have A1: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> (pr1TREES-3K6(D1,D2)) =RELAT-1R1 [:ZFMISC-1K2 D1,D2 :]"
    using funct_2_def_1 sorry
  have A2: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> (pr2TREES-3K7(D1,D2)) =RELAT-1R1 [:ZFMISC-1K2 D1,D2 :]"
    using funct_2_def_1 sorry
  have A3: "rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> T c=RELSET-1R1\<^bsub>(D1,D2)\<^esub> [:ZFMISC-1K2 D1,D2 :]"
     sorry
  then have A4: "domRELAT-1K1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
    using A1 relat_1_th_27 sorry
  have A5: "domRELAT-1K1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
    using A2 A3 relat_1_th_27 sorry
  have A6: "T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub>,(T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub> ]"
    using mcart_1_th_21 sorry
  then have A7: "T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t =XBOOLE-0R4 pr1TREES-3K6(D1,D2) .BINOP-1K2\<^bsub>(D1,D2,D1)\<^esub>((T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub>,(T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub>)"
    using A4 funct_1_th_12 sorry
  have "T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t =XBOOLE-0R4 pr2TREES-3K7(D1,D2) .BINOP-1K2\<^bsub>(D1,D2,D2)\<^esub>((T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub>,(T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub>)"
    using A5 A6 funct_1_th_12 sorry
  thus "(T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub> =XBOOLE-0R4 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t & T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t =XBOOLE-0R4 (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub>"
    using A7 funct_3_def_4 funct_3_def_5 sorry
qed "sorry"

mtheorem trees_3_th_40:
" for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for T be DecoratedTreeTREES-3M2-of(D1,D2) holds <:FUNCT-3K14 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> :> =FUNCT-1R1 T"
proof(rule ballI,rule ballI,rule ballI)
  fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix T assume [ty]: "T be DecoratedTreeTREES-3M2-of(D1,D2)"
  have A1: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> (pr1TREES-3K6(D1,D2)) =RELAT-1R1 [:ZFMISC-1K2 D1,D2 :]"
    using funct_2_def_1 sorry
  have A2: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> (pr2TREES-3K7(D1,D2)) =RELAT-1R1 [:ZFMISC-1K2 D1,D2 :]"
    using funct_2_def_1 sorry
  have A3: "rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> T c=RELSET-1R1\<^bsub>(D1,D2)\<^esub> [:ZFMISC-1K2 D1,D2 :]"
     sorry
  then have A4: "domRELAT-1K1 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
    using A1 relat_1_th_27 sorry
  have A5: "domRELAT-1K1 T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> =TREES-2R1 domRELAT-1K1 T"
    using A2 A3 relat_1_th_27 sorry
  then have A6: "domRELAT-1K1 (<:FUNCT-3K14 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> :>) =TREES-2R1 domRELAT-1K1 T"
    using A4 funct_3_th_50 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 T implies (<:FUNCT-3K14 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> :>).FUNCT-1K1 x =HIDDENR1 T .FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 domRELAT-1K1 T"
    then obtain t where 
      [ty]:"t be ElementTREES-1M2-of domRELAT-1K1 T" and tDef:"t = x"
       sorry
    have "(<:FUNCT-3K14 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> :>).FUNCT-1K1 x =HIDDENR1 [TARSKIK4 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t ]"
      using A4 A5 funct_3_th_49 sorry
    also have "... = [TARSKIK4 (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> .FUNCT-1K1 t ]"
      using trees_3_th_39 sorry
    also have "... = [DOMAIN-1K1\<^bsub>(D1,D2)\<^esub> (T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`1DOMAIN-1K2\<^bsub>(D1,D2)\<^esub>,(T .TREES-2K3\<^bsub>([:ZFMISC-1K2 D1,D2 :])\<^esub> t)`2DOMAIN-1K3\<^bsub>(D1,D2)\<^esub> ]"
      using trees_3_th_39 sorry
    also have "... = T .FUNCT-1K1 x"
      using mcart_1_th_21 sorry
    finally show "(<:FUNCT-3K14 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> :>).FUNCT-1K1 x =HIDDENR1 T .FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus "<:FUNCT-3K14 T `1TREES-3K8\<^bsub>(D1,D2)\<^esub>,T `2TREES-3K9\<^bsub>(D1,D2)\<^esub> :> =FUNCT-1R1 T"
    using A6 sorry
qed "sorry"

mtheorem trees_3_cl_48:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster LeavesTREES-1K3 T as-term-is finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "LeavesTREES-1K3 T be finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have "LeavesTREES-1K3 T be finiteFINSET-1V1 &  not LeavesTREES-1K3 T be emptyXBOOLE-0V1"
    proof-
      have A1: "T <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  ex t1 be ElementTREES-1M2-of T st  ex t2 be ElementTREES-1M2-of T st (Lamb1 =HIDDENR1 t1 & Lamb2 =HIDDENR1 t2) & t2 is-a-prefix-ofTREES-1R2 t1"
      have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?X(x,y) & ?X(y,x) implies x =HIDDENR1 y"
        using xboole_0_def_10 sorry
      have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ?X(x,y) & ?X(y,z) implies ?X(x,z)"
        using xboole_1_th_1 sorry
      obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A4: "x inHIDDENR3 T & ( for y be objectHIDDENM1 holds y inHIDDENR3 T & y <>HIDDENR2 x implies  not ?X(y,x))"
        using card_2_sch_1 A1 A2 A3 sorry
      have 
        [ty]:"x be ElementTREES-1M2-of T"
        using A4 sorry
      have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T implies  not x is-a-proper-prefix-ofTREES-1R3 p"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        assume "p inTARSKIR2 T"
        then obtain t1 where 
          [ty]:"t1 be ElementTREES-1M2-of T" and t1Def:"t1 = p"
           sorry
        show " not x is-a-proper-prefix-ofTREES-1R3 p"
        proof-
          have "x is-a-prefix-ofTREES-1R2 p implies x =HIDDENR1 p"
          proof(rule impI)
            assume "x is-a-prefix-ofTREES-1R2 p"
            then have "x =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> t1"
              using A4 sorry
            thus "x =HIDDENR1 p"
               sorry
          qed
          thus " not x is-a-proper-prefix-ofTREES-1R3 p"
            using xboole_0_def_8 sorry
        qed
      qed "sorry"
      thus "LeavesTREES-1K3 T be finiteFINSET-1V1 &  not LeavesTREES-1K3 T be emptyXBOOLE-0V1"
        using trees_1_def_5 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax TREES_3M4 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("ElementTREES-3M4\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "ElementTREES-3M4\<^bsub>(T)\<^esub>-of S" \<rightharpoonup> "ElementSUBSET-1M1-of S"

mtheorem trees_3_add_4:
  mlet "T be TreeTREES-1M1", "S be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of T"
"cluster note-that ElementTREES-1M2-of T for ElementSUBSET-1M1-of S"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of S holds it be ElementTREES-1M2-of T"
  proof-
    have " for t be ElementSUBSET-1M3\<^bsub>(T)\<^esub>-of S holds t be ElementTREES-1M2-of T"
    proof(rule ballI)
      fix t assume [ty]: "t be ElementSUBSET-1M3\<^bsub>(T)\<^esub>-of S"
      show "t be ElementTREES-1M2-of T"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) TREES_3M5("LeafTREES-3M5-of  _ " [70]70) where
  "LeafTREES-3M5-of T \<equiv> LeafTREES-1M3-of T"

mtheorem trees_3_add_5:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster note-that ElementTREES-3M4\<^bsub>(T)\<^esub>-of LeavesTREES-1K3 T for LeafTREES-1M3-of T"
proof
(*coherence*)
  show " for it be LeafTREES-1M3-of T holds it be ElementTREES-3M4\<^bsub>(T)\<^esub>-of LeavesTREES-1K3 T"
    using trees_1_def_7 sorry
qed "sorry"

mdef trees_3_def_14 ("T-SubstitutionTREES-3M6-of  _ " [70]70 ) where
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"mode T-SubstitutionTREES-3M6-of T \<rightarrow> TreeTREES-1M1 means
  (\<lambda>it.  for t be ElementTREES-1M2-of it holds t inTARSKIR2 T or ( ex l be LeafTREES-3M5-of T st l is-a-proper-prefix-ofTREES-1R3 t))"
proof-
  (*existence*)
    show " ex it be TreeTREES-1M1 st  for t be ElementTREES-1M2-of it holds t inTARSKIR2 T or ( ex l be LeafTREES-3M5-of T st l is-a-proper-prefix-ofTREES-1R3 t)"
    proof-
      have " ex tVar14 be TreeTREES-1M1 st  for t be ElementTREES-1M2-of tVar14 holds  not ( not t inTARSKIR2 tVar14 & ( for l be LeafTREES-3M5-of tVar14 holds  not l is-a-proper-prefix-ofTREES-1R3 t))"
      proof-
        show " ex tVar14 be TreeTREES-1M1 st  for t be ElementTREES-1M2-of tVar14 holds  not ( not t inTARSKIR2 tVar14 & ( for l be LeafTREES-3M5-of tVar14 holds  not l is-a-proper-prefix-ofTREES-1R3 t))"
        proof(rule bexI[of _ "T"])
          show " for t be ElementTREES-1M2-of T holds  not ( not t inTARSKIR2 T & ( for l be LeafTREES-3M5-of T holds  not l is-a-proper-prefix-ofTREES-1R3 t))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

abbreviation(input) TREES_3K10(" _ with-replacementTREES-3K10'( _ , _ ')" [164,0,0]164) where
  "T with-replacementTREES-3K10(t,S) \<equiv> T with-replacementTREES-1K5(t,S)"

mtheorem trees_3_add_6:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1", "t be LeafTREES-3M5-of T", "S be TreeTREES-1M1"
"cluster T with-replacementTREES-1K5(t,S) as-term-is T-SubstitutionTREES-3M6-of T"
proof
(*coherence*)
  show "T with-replacementTREES-1K5(t,S) be T-SubstitutionTREES-3M6-of T"
  proof-
    have " for s be ElementTREES-1M2-of T with-replacementTREES-1K5(t,S) holds  not s inTARSKIR2 T implies ( ex tVar15 be LeafTREES-3M5-of T st tVar15 is-a-proper-prefix-ofTREES-1R3 s)"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be ElementTREES-1M2-of T with-replacementTREES-1K5(t,S)"
      assume A1: " not s inTARSKIR2 T"
      then obtain t1 where
        [ty]:"t1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
        "t1 inTARSKIR2 S"and A2: "s =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> t ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> t1"
        using trees_1_def_9 sorry
      show " ex tVar15 be LeafTREES-3M5-of T st tVar15 is-a-proper-prefix-ofTREES-1R3 s"
      proof(rule bexI[of _ "t"])
        have "t ^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 t"
          using finseq_1_th_34 sorry
        then have "t1 <>HIDDENR2 {}XBOOLE-0K1"
          using A1 A2 sorry
        thus "t is-a-proper-prefix-ofTREES-1R3 s"
          using A2 trees_1_th_10 sorry
      qed "sorry"
    qed "sorry"
    thus "T with-replacementTREES-1K5(t,S) be T-SubstitutionTREES-3M6-of T"
      using trees_3_def_14 sorry
  qed
qed "sorry"

mtheorem trees_3_cl_49:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster finiteFINSET-1V1 for T-SubstitutionTREES-3M6-of T"
proof
(*existence*)
  show " ex it be T-SubstitutionTREES-3M6-of T st it be finiteFINSET-1V1"
  proof-
    have " not ( for VarFor1 be T-SubstitutionTREES-3M6-of T holds  not VarFor1 be finiteFINSET-1V1)"
    proof-
      have " for t be ElementTREES-1M2-of T holds t inTARSKIR2 T or ( ex l be LeafTREES-3M5-of T st l is-a-proper-prefix-ofTREES-1R3 t)"
         sorry
      then have "T be T-SubstitutionTREES-3M6-of T"
        using trees_3_def_14 sorry
      thus " not ( for VarFor1 be T-SubstitutionTREES-3M6-of T holds  not VarFor1 be finiteFINSET-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) TREES_3M7("T-SubstitutionTREES-3M7-of  _ " [70]70) where
  "T-SubstitutionTREES-3M7-of n \<equiv> T-SubstitutionTREES-3M6-of elementary-treeTREES-1K2 n"

mtheorem trees_3_th_41:
" for T be TreeTREES-1M1 holds T be T-SubstitutionTREES-3M7-of 0NUMBERSK6"
proof(rule ballI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  have " for t be ElementTREES-1M2-of T holds  not t inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) implies ( ex tVar16 be LeafTREES-3M5-of elementary-treeTREES-1K2 (0NUMBERSK6) st tVar16 is-a-proper-prefix-ofTREES-1R3 t)"
  proof(rule ballI,rule impI)
    fix t assume [ty]: "t be ElementTREES-1M2-of T"
    assume A1: " not t inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6)"
    let ?l = "the LeafTREES-3M5-of elementary-treeTREES-1K2 (0NUMBERSK6)"
    show " ex tVar16 be LeafTREES-3M5-of elementary-treeTREES-1K2 (0NUMBERSK6) st tVar16 is-a-proper-prefix-ofTREES-1R3 t"
    proof(rule bexI[of _ "?l"])
      have A2: "?l =FINSEQ-1R1 {}XBOOLE-0K1"
        using tarski_def_1 trees_1_th_29 sorry
      have A3: "t <>HIDDENR2 {}XBOOLE-0K1"
        using A1 tarski_def_1 trees_1_th_29 sorry
      have "{}XBOOLE-0K1 is-a-prefix-ofTREES-1R2 t"
         sorry
      thus "the LeafTREES-3M5-of elementary-treeTREES-1K2 (0NUMBERSK6) is-a-proper-prefix-ofTREES-1R3 t"
        using A2 A3 sorry
    qed "sorry"
  qed "sorry"
  thus "T be T-SubstitutionTREES-3M7-of 0NUMBERSK6"
    using trees_3_def_14 sorry
qed "sorry"

mtheorem trees_3_th_42:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds T1 -levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 T2 -levelTREES-2K2 \<one>\<^sub>M & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> inTARSKIR2 T1 implies T1  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =TREES-2R1 T2  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)) implies T1 c=TARSKIR1 T2"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  assume A1: "T1 -levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 T2 -levelTREES-2K2 \<one>\<^sub>M"
    and A2: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> inTARSKIR2 T1 implies T1  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =TREES-2R1 T2  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 T1 implies x inHIDDENR3 T2"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 T1"
    then obtain t where 
      [ty]:"t be ElementTREES-1M2-of T1" and tDef:"t = x"
       sorry
    have "t <>HIDDENR2 {}XBOOLE-0K1 implies t inTARSKIR2 T2"
    proof(rule impI)
      assume "t <>HIDDENR2 {}XBOOLE-0K1"
      then obtain p n where
        [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A3: "t =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p"
        using finseq_2_th_130 sorry
      have A4: "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =XBOOLE-0R4 \<one>\<^sub>M"
        using finseq_1_th_39 sorry
      have 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      obtain q where 
        [ty]:"q be ElementTREES-1M2-of T1" and qDef:"q = <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>"
        using A3 trees_1_th_21 sorry
      have A5: "q inTARSKIR2 T1 -levelTREES-2K2 \<one>\<^sub>M"
        using A4 sorry
      then have A6: "q inTARSKIR2 T2 -levelTREES-2K2 \<one>\<^sub>M"
        using A1 sorry
      have A7: "p inTARSKIR2 T1  |TREES-1K4 q"
        using A3 trees_1_def_6 sorry
      have "T1  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =TREES-2R1 T2  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
        using A2 A5 sorry
      thus "t inTARSKIR2 T2"
        using A3 A6 A7 trees_1_def_6 sorry
    qed
    thus "x inHIDDENR3 T2"
      using trees_1_th_22 sorry
  qed "sorry"
  thus "T1 c=TARSKIR1 T2"
    using tarski_def_3 sorry
qed "sorry"

mlemma trees_3_lm_3:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
    have A2: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
      using A1 nat_1_th_13 sorry
    then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
      using A2 finseq_3_th_25 sorry
    thus "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
      using funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem trees_3_th_43:
" for T be TreeTREES-1M1 holds  for T9 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 LeavesTREES-1K3 T implies T c=TARSKIR1 T with-replacementTREES-1K5(p,T9)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  fix T9 assume [ty]: "T9 be TreeTREES-1M1"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
  assume A1: "p inTARSKIR2 LeavesTREES-1K3 T"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 T implies x inHIDDENR3 T with-replacementTREES-1K5(p,T9)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 T"
    then obtain t where 
      [ty]:"t be ElementTREES-1M2-of T" and tDef:"t = x"
       sorry
    have " not p is-a-proper-prefix-ofTREES-1R3 t"
      using A1 trees_1_def_5 sorry
    thus "x inHIDDENR3 T with-replacementTREES-1K5(p,T9)"
      using A1 trees_1_def_9 sorry
  qed "sorry"
  thus "T c=TARSKIR1 T with-replacementTREES-1K5(p,T9)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem trees_3_th_44:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 p =XBOOLE-0R4 T9 .FUNCT-1K1 {}XBOOLE-0K1"
proof(rule ballI,rule ballI,rule ballI)
  fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
  fix T9 assume [ty]: "T9 be DecoratedTreeTREES-2M4"
  fix p assume [ty]: "p be ElementTREES-1M2-of domRELAT-1K1 T"
  have "p inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T9)"
    using trees_1_def_9 sorry
  then have A1: " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T9 & p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 p =XBOOLE-0R4 T9 .FUNCT-1K1 r"
    using trees_2_def_11 sorry
  have "p =FINSEQ-1R1 p ^FINSEQ-1K8 {}XBOOLE-0K1"
    using finseq_1_th_34 sorry
  thus "(T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 p =XBOOLE-0R4 T9 .FUNCT-1K1 {}XBOOLE-0K1"
    using A1 finseq_1_th_33 sorry
qed "sorry"

mtheorem trees_3_th_45:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds  for q be ElementTREES-1M2-of domRELAT-1K1 T holds  not p is-a-prefix-ofTREES-1R2 q implies (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
  fix T9 assume [ty]: "T9 be DecoratedTreeTREES-2M4"
  fix p assume [ty]: "p be ElementTREES-1M2-of domRELAT-1K1 T"
  fix q assume [ty]: "q be ElementTREES-1M2-of domRELAT-1K1 T"
  assume A1: " not p is-a-prefix-ofTREES-1R2 q"
  then have A2: "q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T9)"
    using trees_2_th_7 sorry
  have " not ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T9 & q =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 q =XBOOLE-0R4 T9 .FUNCT-1K1 r)"
    using A1 trees_1_th_1 sorry
  thus "(T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 q =XBOOLE-0R4 T .FUNCT-1K1 q"
    using A2 trees_2_def_11 sorry
qed "sorry"

mtheorem trees_3_th_46:
" for T be DecoratedTreeTREES-2M4 holds  for T9 be DecoratedTreeTREES-2M4 holds  for p be ElementTREES-1M2-of domRELAT-1K1 T holds  for q be ElementTREES-1M2-of domRELAT-1K1 T9 holds (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix T assume [ty]: "T be DecoratedTreeTREES-2M4"
  fix T9 assume [ty]: "T9 be DecoratedTreeTREES-2M4"
  fix p assume [ty]: "p be ElementTREES-1M2-of domRELAT-1K1 T"
  fix q assume [ty]: "q be ElementTREES-1M2-of domRELAT-1K1 T9"
  have A1: "p is-a-prefix-ofTREES-1R2 p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
    using trees_1_th_1 sorry
  have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 domRELAT-1K1 T with-replacementTREES-1K5(p,domRELAT-1K1 T9)"
    using trees_1_def_9 sorry
  then have " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st (r inTARSKIR2 domRELAT-1K1 T9 & p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) & (T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 r"
    using A1 trees_2_def_11 sorry
  thus "(T with-replacementTREES-2K7(p,T9)).FUNCT-1K1 (p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q) =XBOOLE-0R4 T9 .FUNCT-1K1 q"
    using finseq_1_th_33 sorry
qed "sorry"

mtheorem trees_3_cl_50:
  mlet "T1 be TreeTREES-1M1", "T2 be TreeTREES-1M1"
"cluster T1 \\/XBOOLE-0K2 T2 as-term-is  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
proof
(*coherence*)
  show "T1 \\/XBOOLE-0K2 T2 be  non emptyXBOOLE-0V1\<bar>Tree-likeTREES-1V1"
     sorry
qed "sorry"

mtheorem trees_3_th_47:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T1 \\/XBOOLE-0K2 T2 holds ((p inTARSKIR2 T1 & p inTARSKIR2 T2 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p) & ( not p inTARSKIR2 T1 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T2  |TREES-1K4 p)) & ( not p inTARSKIR2 T2 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p)"
proof-
  have " for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T1 \\/XBOOLE-0K2 T2 holds (p inTARSKIR2 T1 & p inTARSKIR2 T2 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p) & ( not ( not p inTARSKIR2 T1 &  not (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T2  |TREES-1K4 p) &  not ( not p inTARSKIR2 T2 &  not (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix T2 assume [ty]: "T2 be TreeTREES-1M1"
    fix p assume [ty]: "p be ElementTREES-1M2-of T1 \\/XBOOLE-0K2 T2"
    show "p inTARSKIR2 T1 & p inTARSKIR2 T2 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p"
    proof(rule impMI ,rule impI)
      assume A1: "p inTARSKIR2 T1"
        and A2: "p inTARSKIR2 T2"
      have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p implies q inTARSKIR2 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p) & (q inTARSKIR2 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p implies q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p)"
      proof(rule ballI,rule conjMI,rule impI)
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        show "q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p implies q inTARSKIR2 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p"
        proof(rule impI)
          assume "q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p"
          then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T1 \\/XBOOLE-0K2 T2"
            using trees_1_def_6 sorry
          then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T1 or p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T2"
            using xboole_0_def_3 sorry
          then have "q inTARSKIR2 T1  |TREES-1K4 p or q inTARSKIR2 T2  |TREES-1K4 p"
            using A1 A2 trees_1_def_6 sorry
          thus "q inTARSKIR2 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p"
            using xboole_0_def_3 sorry
        qed
        assume "q inTARSKIR2 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p"
        then have "q inTARSKIR2 T1  |TREES-1K4 p or q inTARSKIR2 T2  |TREES-1K4 p"
          using xboole_0_def_3 sorry
        then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T1 or p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T2"
          using A1 A2 trees_1_def_6 sorry
        then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T1 \\/XBOOLE-0K2 T2"
          using xboole_0_def_3 sorry
        thus "q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p"
          using trees_1_def_6 sorry
      qed "sorry"
      thus "(T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p \\/XBOOLE-0K2 T2  |TREES-1K4 p"
        using trees_2_def_1 sorry
    qed
    have " for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be ElementTREES-1M2-of T1 \\/XBOOLE-0K2 T2 holds  not p inTARSKIR2 T1 implies (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T2  |TREES-1K4 p"
    proof(rule ballI,rule ballI,rule ballI,rule impI)
      fix T1 assume [ty]: "T1 be TreeTREES-1M1"
      fix T2 assume [ty]: "T2 be TreeTREES-1M1"
      fix p assume [ty]: "p be ElementTREES-1M2-of T1 \\/XBOOLE-0K2 T2"
      assume A3: " not p inTARSKIR2 T1"
      then have A4: "p inTARSKIR2 T2"
        using xboole_0_def_3 sorry
      have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p implies q inTARSKIR2 T2  |TREES-1K4 p) & (q inTARSKIR2 T2  |TREES-1K4 p implies q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p)"
      proof(rule ballI,rule conjMI,rule impI)
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        show "q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p implies q inTARSKIR2 T2  |TREES-1K4 p"
        proof(rule impI)
          assume "q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p"
          then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T1 \\/XBOOLE-0K2 T2"
            using trees_1_def_6 sorry
          then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T1 or p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T2"
            using xboole_0_def_3 sorry
          thus "q inTARSKIR2 T2  |TREES-1K4 p"
            using A3 A4 trees_1_th_21 trees_1_def_6 sorry
        qed
        assume "q inTARSKIR2 T2  |TREES-1K4 p"
        then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T2"
          using A4 trees_1_def_6 sorry
        then have "p ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 T1 \\/XBOOLE-0K2 T2"
          using xboole_0_def_3 sorry
        thus "q inTARSKIR2 (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p"
          using trees_1_def_6 sorry
      qed "sorry"
      thus "(T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T2  |TREES-1K4 p"
        using trees_2_def_1 sorry
    qed "sorry"
    thus " not ( not p inTARSKIR2 T1 &  not (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T2  |TREES-1K4 p) &  not ( not p inTARSKIR2 T2 &  not (T1 \\/XBOOLE-0K2 T2) |TREES-1K4 p =TREES-2R1 T1  |TREES-1K4 p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef trees_3_def_15 ("treeTREES-3K11  _ " [164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1"
"assume p be Tree-yieldingTREES-3V4 func treeTREES-3K11 p \<rightarrow> TreeTREES-1M1 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
proof-
  (*existence*)
    show "p be Tree-yieldingTREES-3V4 implies ( ex it be TreeTREES-1M1 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q))"
    proof(rule impI)
      assume Assume: "p be Tree-yieldingTREES-3V4"
      have A1: "p be Tree-yieldingTREES-3V4"
        using Assume sorry
      show " ex it be TreeTREES-1M1 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
      proof-
        have " ex tVar17 be TreeTREES-1M1 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar17 implies x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) & (x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q) implies x inHIDDENR3 tVar17)"
        proof-
          let ?X = "\<lambda>Lamb1. Lamb1 =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & Lamb1 =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
          obtain T where
            [ty]:"T be setHIDDENM2" and 
            A2: " for y be objectHIDDENM1 holds y inHIDDENR3 T iff y inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3 & ?X(y)"
            using xboole_0_sch_1 sorry
          have "<*>FINSEQ-1K7 NATNUMBERSK1 inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
            using finseq_1_def_11 sorry
          then have 
            [ty]:"T be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
            using A2 sorry
          have A3: "rngFUNCT-1K2 p be constituted-TreesTREES-3V1"
            using A1 sorry
          then have A4: " for n be NatNAT-1M1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) be TreeTREES-1M1"
            using trees_3_lm_3 sorry
          have "T be Tree-likeTREES-1V1"
          proof-
            have "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3 & (( for w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds w inTARSKIR2 T implies ProperPrefixesTREES-1K1 w c=TARSKIR1 T) & ( for w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T & n <=XXREAL-0R1 k implies w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T))"
            proof(rule conjMI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
              show "T c=TARSKIR1 NATNUMBERSK1 * FINSEQ-2K3"
                using A2 sorry
              show " for w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds w inTARSKIR2 T implies ProperPrefixesTREES-1K1 w c=TARSKIR1 T"
              proof-
                have " for w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds w inTARSKIR2 T implies ProperPrefixesTREES-1K1 w c=TARSKIR1 T"
                proof(rule ballI,rule impI)
                  fix w assume [ty]: "w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                  assume A5: "w inTARSKIR2 T"
                  have "w <>HIDDENR2 {}XBOOLE-0K1 implies ProperPrefixesTREES-1K1 w c=TARSKIR1 T"
                  proof(rule impI)
                    assume "w <>HIDDENR2 {}XBOOLE-0K1"
                    then obtain n q where
                      [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
                      A6: "n <XXREAL-0R3 lenFINSEQ-1K4 p"and A7: "q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A8: "w =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q"
                      using A2 A5 sorry
                    have 
                      [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                      using A8 finseq_1_th_36 sorry
                    show "ProperPrefixesTREES-1K1 w c=TARSKIR1 T"
                    proof-
                      have " for x be objectHIDDENM1 holds x inHIDDENR3 ProperPrefixesTREES-1K1 w implies x inHIDDENR3 T"
                      proof(rule ballI,rule impI)
                        fix x assume [ty]: "x be objectHIDDENM1"
                        assume "x inHIDDENR3 ProperPrefixesTREES-1K1 w"
                        then obtain r where
                          [ty]:"r be FinSequenceFINSEQ-1M1" and 
                          A9: "x =HIDDENR1 r"and A10: "r is-a-proper-prefix-ofTREES-1R3 w"
                          using trees_1_def_2 sorry
                        have "r is-a-prefix-ofTREES-1R2 w"
                          using A10 sorry
                        then obtain k where
                          [ty]:"k be NatNAT-1M1" and 
                          A11: "r =FUNCT-1R1 w  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 k"
                           sorry
                        have "rngFUNCT-1K2 r =XBOOLE-0R4 w .:RELSET-1K7\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 k"
                          using A11 relat_1_th_115 sorry
                        then have 
                          [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
                          using finseq_1_def_4 sorry
                        have A12: "r inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
                          using finseq_1_def_11 sorry
                        have "r <>HIDDENR2 {}XBOOLE-0K1 implies x inHIDDENR3 T"
                        proof(rule impI)
                          assume "r <>HIDDENR2 {}XBOOLE-0K1"
                          then obtain r1 i where
                            [ty]:"r1 be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                            A13: "r =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r1"
                            using finseq_2_th_130 sorry
                          have A14: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> i*>) =XBOOLE-0R4 SegFINSEQ-1K2 \<one>\<^sub>M"
                            using finseq_1_th_38 sorry
                          have A15: "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
                            using finseq_1_th_2 tarski_def_1 sorry
                          have A16: "SegFINSEQ-1K2 \<one>\<^sub>M c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> r"
                            using A13 A14 finseq_1_th_26 sorry
                          have A17: "r .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i"
                            using A13 finseq_1_th_41 sorry
                          have A18: "w .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n"
                            using A8 finseq_1_th_41 sorry
                          have A19: "r .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 w .FUNCT-1K1 \<one>\<^sub>M"
                            using A11 A15 A16 funct_1_th_47 sorry
                          then have A20: "r1 is-a-proper-prefix-ofTREES-1R3 q"
                            using A8 A10 A13 A17 A18 trees_1_th_49 sorry
                          have A21: "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) be TreeTREES-1M1"
                            using A4 A6 sorry
                          have "r1 is-a-prefix-ofTREES-1R2 q"
                            using A20 sorry
                          then have "r1 inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                            using A7 A21 trees_1_th_20 sorry
                          thus "x inHIDDENR3 T"
                            using A2 A6 A9 A12 A13 A17 A18 A19 sorry
                        qed
                        thus "x inHIDDENR3 T"
                          using A2 A9 A12 sorry
                      qed "sorry"
                      thus "ProperPrefixesTREES-1K1 w c=TARSKIR1 T"
                        using tarski_def_3 sorry
                    qed
                  qed
                  thus "ProperPrefixesTREES-1K1 w c=TARSKIR1 T"
                    using trees_1_th_15 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              fix w assume [ty]: "w be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
              fix k assume [ty]: "k be NatNAT-1M1"
              fix n assume [ty]: "n be NatNAT-1M1"
              assume A22: "w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) inTARSKIR2 T"
                and A23: "n <=XXREAL-0R1 k"
              have A24: "w =FINSEQ-1R1 {}XBOOLE-0K1 implies w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
              proof(rule impI)
                assume A25: "w =FINSEQ-1R1 {}XBOOLE-0K1"
                then have "<*FINSEQ-1K10 k*> inTARSKIR2 T"
                  using A22 finseq_1_th_34 sorry
                then obtain m q where
                  [ty]:"m be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
                  A26: "m <XXREAL-0R3 lenFINSEQ-1K4 p"and "q inTARSKIR2 p .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"and A27: "<*FINSEQ-1K10 k*> =FINSEQ-1R1 (<*FINSEQ-1K10 m*>)^FINSEQ-1K8 q"
                  using A2 sorry
                have A28: "(<*FINSEQ-1K10 k*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k"
                  using finseq_1_def_8 sorry
                have "((<*FINSEQ-1K10 m*>)^FINSEQ-1K8 q).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m"
                  using finseq_1_th_41 sorry
                then have A29: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
                  using A23 A26 A27 A28 xxreal_0_th_2 sorry
                then have "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
                  using trees_3_lm_3 sorry
                then have A30: "{}XBOOLE-0K1 inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A3 trees_1_th_22 sorry
                have A31: "(<*FINSEQ-1K10 n*>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*FINSEQ-1K10 n*>"
                  using finseq_1_th_34 sorry
                have A32: "{}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) =FINSEQ-1R1 <*FINSEQ-1K10 n*>"
                  using finseq_1_th_34 sorry
                have 
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
                  using finseq_1_def_11 sorry
                thus "w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
                  using A2 A25 A29 A30 A31 A32 sorry
              qed
              have "w <>HIDDENR2 {}XBOOLE-0K1 implies w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
              proof(rule impI)
                assume "w <>HIDDENR2 {}XBOOLE-0K1"
                then obtain q m where
                  [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" "m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A33: "w =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> m*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
                  using finseq_2_th_130 sorry
                obtain m9 r where
                  [ty]:"m9 be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
                  A34: "m9 <XXREAL-0R3 lenFINSEQ-1K4 p"and A35: "r inTARSKIR2 p .FUNCT-1K1 (m9 +NAT-1K1 \<one>\<^sub>M)"and A36: "w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 (<*FINSEQ-1K10 m9*>)^FINSEQ-1K8 r"
                  using A2 A22 sorry
                have 
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have A37: "w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>) =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> m*>)^FINSEQ-1K8 (q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>))"
                  using A33 finseq_1_th_32 sorry
                have A38: "w ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> m*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>))"
                  using A33 finseq_1_th_32 sorry
                have A39: "(w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m"
                  using A37 finseq_1_th_41 sorry
                have A40: "(w ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m9"
                  using A36 finseq_1_th_41 sorry
                have A41: "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> m*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)) inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
                  using finseq_1_def_11 sorry
                have A42: "r =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 k*>)"
                  using A36 A37 A39 A40 finseq_1_th_33 sorry
                have "p .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
                  using A34 A39 A40 trees_3_lm_3 sorry
                then have "q ^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) inTARSKIR2 p .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
                  using A3 A23 A35 A39 A40 A42 trees_1_def_3 sorry
                thus "w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
                  using A2 A34 A38 A39 A40 A41 sorry
              qed
              thus "w ^FINSEQ-1K8 (<*FINSEQ-1K10 n*>) inTARSKIR2 T"
                using A24 sorry
            qed "sorry"
            thus "T be Tree-likeTREES-1V1"
              using trees_1_def_3 sorry
          qed
          then have 
            [ty]:"T be TreeTREES-1M1"
             sorry
          show " ex tVar17 be TreeTREES-1M1 st  for x be objectHIDDENM1 holds (x inHIDDENR3 tVar17 implies x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) & (x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q) implies x inHIDDENR3 tVar17)"
          proof(rule bexI[of _ "T"],rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 T implies x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
              using A2 sorry
            assume A43: "x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
            have A44: "( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q) implies x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
            proof(rule impI)
              assume Given: " ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q"
              then obtain n q where
                [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
                A45: "n <XXREAL-0R3 lenFINSEQ-1K4 p"and A46: "q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A47: "x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q"
                 sorry
              obtain T1 where 
                [ty]:"T1 be TreeTREES-1M1" and T1Def:"T1 = p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                using A4 A45 sorry
              have 
                [ty]:"q be ElementTREES-1M2-of T1"
                using A46 sorry
              have 
                [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
                using finseq_1_def_11 sorry
              thus "x inHIDDENR3 NATNUMBERSK1 * FINSEQ-2K3"
                using A47 sorry
            qed
            have "{}XBOOLE-0K1 inTARSKIR2 NATNUMBERSK1 * FINSEQ-2K3"
              using finseq_1_th_49 sorry
            thus "x inHIDDENR3 T"
              using A2 A43 A44 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p be Tree-yieldingTREES-3V4 implies ( for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p be Tree-yieldingTREES-3V4"
      have A1: "p be Tree-yieldingTREES-3V4"
        using Assume sorry
      show " for it1 be TreeTREES-1M1 holds  for it2 be TreeTREES-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) implies it1 =HIDDENR1 it2"
      proof-
        have " for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 T1 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 T2 iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & x =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)) implies T1 =HIDDENR1 T2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          let ?X = "\<lambda>Lamb1. Lamb1 =HIDDENR1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & Lamb1 =HIDDENR1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
          fix T1 assume [ty]: "T1 be TreeTREES-1M1"
          fix T2 assume [ty]: "T2 be TreeTREES-1M1"
          assume A48: " for x be objectHIDDENM1 holds x inHIDDENR3 T1 iff ?X(x)"
            and A49: " for x be objectHIDDENM1 holds x inHIDDENR3 T2 iff ?X(x)"
          show "T1 =HIDDENR1 T2"
            using xboole_0_sch_2 A48 A49 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef trees_3_def_16 ("^TREES-3K12  _ " [164]164 ) where
  mlet "T be TreeTREES-1M1"
"func ^TREES-3K12 T \<rightarrow> TreeTREES-1M1 equals
  treeTREES-3K11 (<*FINSEQ-1K10 T*>)"
proof-
  (*coherence*)
    show "treeTREES-3K11 (<*FINSEQ-1K10 T*>) be TreeTREES-1M1"
       sorry
qed "sorry"

mdef trees_3_def_17 ("treeTREES-3K13'( _ , _ ')" [0,0]164 ) where
  mlet "T1 be TreeTREES-1M1", "T2 be TreeTREES-1M1"
"func treeTREES-3K13(T1,T2) \<rightarrow> TreeTREES-1M1 equals
  treeTREES-3K11 (<*FINSEQ-1K11 T1,T2 *>)"
proof-
  (*coherence*)
    show "treeTREES-3K11 (<*FINSEQ-1K11 T1,T2 *>) be TreeTREES-1M1"
       sorry
qed "sorry"

mtheorem trees_3_th_48:
" for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies ((<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p iff n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  for q be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies ((<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p implies n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) &  not (( not n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) &  not (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M1"
    assume A1: "p be Tree-yieldingTREES-3V4"
    show "(<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p implies n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have "(<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p implies  not n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI)
        assume "(<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p"
        then obtain k r where
          [ty]:"k be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
          A2: "k <XXREAL-0R3 lenFINSEQ-1K4 p"and A3: "r inTARSKIR2 p .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"and A4: "(<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q =FINSEQ-1R1 (<*FINSEQ-1K10 k*>)^FINSEQ-1K8 r"
          using A1 trees_3_def_15 sorry
        have A5: "((<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n"
          using finseq_1_th_41 sorry
        have "((<*FINSEQ-1K10 k*>)^FINSEQ-1K8 r).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k"
          using finseq_1_th_41 sorry
        thus " not n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 A3 A4 A5 finseq_1_th_33 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " not (( not n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) &  not (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q inTARSKIR2 treeTREES-3K11 p)"
      using A1 trees_3_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_49:
" for p be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p } & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p } & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 lenFINSEQ-1K4 p implies (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule impI,rule conjMI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    let ?T = "treeTREES-3K11 p"
    assume A1: "p be Tree-yieldingTREES-3V4"
    then have A2: "rngFUNCT-1K2 p be constituted-TreesTREES-3V1"
       sorry
    show "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p }"
    proof-
      have "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p }"
      proof-
        have "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p } & {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p } c=TARSKIR1 (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M"
        proof(rule conjMI)
          show "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p }"
          proof-
            have "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M implies x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 ?T -levelTREES-2K2 \<one>\<^sub>M"
                then obtain t where
                  [ty]:"t be ElementTREES-1M2-of ?T" and 
                  A3: "x =HIDDENR1 t"and A4: "lenFINSEQ-1K4 t =XBOOLE-0R4 \<one>\<^sub>M"
                   sorry
                have A5: "t =FINSEQ-1R1 <*FINSEQ-1K10 t .FUNCT-1K1 \<one>\<^sub>M*>"
                  using A4 finseq_1_th_40 sorry
                then obtain n q where
                  [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
                  A6: "n <XXREAL-0R3 lenFINSEQ-1K4 p"and "q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A7: "t =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q"
                  using A1 trees_3_def_15 sorry
                have "t =FINSEQ-1R1 <*FINSEQ-1K10 n*>"
                  using A5 A7 finseq_1_th_88 sorry
                thus "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p }"
                  using A3 A6 sorry
              qed "sorry"
              thus "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M c=TARSKIR1 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p }"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p } implies x inHIDDENR3 (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p }"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A8: "x =HIDDENR1 <*FINSEQ-1K10 n*>"and A9: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
               sorry
            have "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
              using A9 trees_3_lm_3 sorry
            then have A10: "{}XBOOLE-0K1 inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              using A2 trees_1_th_22 sorry
            have "(<*FINSEQ-1K10 n*>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*FINSEQ-1K10 n*>"
              using finseq_1_th_34 sorry
            then obtain t where 
              [ty]:"t be ElementTREES-1M2-of ?T" and tDef:"t = <*FINSEQ-1K10 n*>"
              using A1 A9 A10 trees_3_def_15 sorry
            have "lenFINSEQ-1K4 t =XBOOLE-0R4 \<one>\<^sub>M"
              using finseq_1_th_39 sorry
            thus "x inHIDDENR3 (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M"
              using A8 sorry
          qed "sorry"
          thus "{<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p } c=TARSKIR1 (treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M"
            using tarski_def_3 sorry
        qed
        thus "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 :  not n <XXREAL-0R3 lenFINSEQ-1K4 p }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A11: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
    then have "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
      using trees_3_lm_3 sorry
    then obtain S where 
      [ty]:"S be TreeTREES-1M1" and SDef:"S = p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    have A12: "{}XBOOLE-0K1 inTARSKIR2 S"
      using trees_1_th_22 sorry
    have "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>"
      using finseq_1_th_34 sorry
    then have A13: "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> inTARSKIR2 ?T"
      using A1 A11 A12 trees_3_def_15 sorry
    have "?T  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =TREES-2R1 S"
    proof-
      have "(treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =TREES-2R1 S"
      proof-
        have " for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (r inTARSKIR2 (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) implies r inTARSKIR2 S) & (r inTARSKIR2 S implies r inTARSKIR2 (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>))"
        proof(rule ballI,rule conjMI,rule impI)
          fix r assume [ty]: "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          show "r inTARSKIR2 (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) implies r inTARSKIR2 S"
          proof(rule impI)
            assume "r inTARSKIR2 ?T  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
            then have "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r inTARSKIR2 ?T"
              using A13 trees_1_def_6 sorry
            then obtain m q where
              [ty]:"m be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
              "m <XXREAL-0R3 lenFINSEQ-1K4 p"and A14: "q inTARSKIR2 p .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"and A15: "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r =FINSEQ-1R1 (<*FINSEQ-1K10 m*>)^FINSEQ-1K8 q"
              using A1 trees_3_def_15 sorry
            have A16: "((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n"
              using finseq_1_th_41 sorry
            have "((<*FINSEQ-1K10 m*>)^FINSEQ-1K8 q).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 m"
              using finseq_1_th_41 sorry
            thus "r inTARSKIR2 S"
              using A14 A15 A16 finseq_1_th_33 sorry
          qed
          assume "r inTARSKIR2 S"
          then have A17: "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r inTARSKIR2 ?T"
            using A1 A11 trees_3_def_15 sorry
          then have "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> inTARSKIR2 ?T"
            using trees_1_th_21 sorry
          thus "r inTARSKIR2 (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>)"
            using A17 trees_1_def_6 sorry
        qed "sorry"
        thus "(treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =TREES-2R1 S"
          using trees_2_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "(treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*>) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_50:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds treeTREES-3K11 p =TREES-2R1 treeTREES-3K11 q implies p =FINSEQ-1R1 q"
proof(rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
  assume A1: "treeTREES-3K11 p =TREES-2R1 treeTREES-3K11 q"
  have A2: "(treeTREES-3K11 p)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p }"
    using trees_3_th_49 sorry
  have A3: "(treeTREES-3K11 q)-levelTREES-2K2 \<one>\<^sub>M =XBOOLE-0R4 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 lenFINSEQ-1K4 q }"
    using trees_3_th_49 sorry
  have A4: " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds {<*FINSEQ-1K10 i*> where i be NatNAT-1M1 : i <XXREAL-0R3 n1 } =XBOOLE-0R4 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n2 } & n1 <XXREAL-0R3 n2 implies  False "
  proof(rule ballI,rule ballI,rule impI)
    fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume "{<*FINSEQ-1K10 i*> where i be NatNAT-1M1 : i <XXREAL-0R3 n1 } =XBOOLE-0R4 {<*FINSEQ-1K10 k*> where k be NatNAT-1M1 : k <XXREAL-0R3 n2 } & n1 <XXREAL-0R3 n2"
    then have "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n1*> inTARSKIR2 {<*FINSEQ-1K10 i*> where i be NatNAT-1M1 : i <XXREAL-0R3 n1 }"
       sorry
    then have A5: " ex i be NatNAT-1M1 st <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n1*> =FINSEQ-1R1 <*FINSEQ-1K10 i*> & i <XXREAL-0R3 n1"
       sorry
    have "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n1*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n1"
      using finseq_1_th_40 sorry
    thus " False "
      using A5 finseq_1_th_40 sorry
  qed "sorry"
  then have A6: " not lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 q"
    using A1 A2 A3 sorry
  have A7: " not lenFINSEQ-1K4 p >XXREAL-0R4 lenFINSEQ-1K4 q"
    using A1 A2 A3 A4 sorry
  then have A8: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
    using A6 xxreal_0_th_1 sorry
  have " for i be NatNAT-1M1 holds i >=XXREAL-0R2 \<one>\<^sub>M & i <=XXREAL-0R1 lenFINSEQ-1K4 p implies p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
  proof(rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A9: "i >=XXREAL-0R2 \<one>\<^sub>M"
      and A10: "i <=XXREAL-0R1 lenFINSEQ-1K4 p"
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A11: "i =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 k"
      using A9 nat_1_th_10 sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A12: "k <XXREAL-0R3 lenFINSEQ-1K4 p"
      using A10 A11 nat_1_th_13 sorry
    then have "p .FUNCT-1K1 i =XBOOLE-0R4 (treeTREES-3K11 p) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> k*>)"
      using A11 trees_3_th_49 sorry
    thus "p .FUNCT-1K1 i =XBOOLE-0R4 q .FUNCT-1K1 i"
      using A1 A8 A11 A12 trees_3_th_49 sorry
  qed "sorry"
  thus "p =FINSEQ-1R1 q"
    using A6 A7 finseq_1_th_14 xxreal_0_th_1 sorry
qed "sorry"

mtheorem trees_3_th_51:
" for p be FinSequenceFINSEQ-1M1 holds  for p1 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for p2 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for T be TreeTREES-1M1 holds p inTARSKIR2 T iff (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K11 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2)"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for p1 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for p2 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for T be TreeTREES-1M1 holds (p inTARSKIR2 T implies (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K11 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2)) & ((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K11 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2) implies p inTARSKIR2 T)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix p1 assume [ty]: "p1 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
    fix T assume [ty]: "T be TreeTREES-1M1"
    have A1: "lenFINSEQ-1K4 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2) =XBOOLE-0R4 lenFINSEQ-1K4 (p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) +NAT-1K1 lenFINSEQ-1K4 p2"
      using finseq_1_th_22 sorry
    have A2: "lenFINSEQ-1K4 (p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 T*>)"
      using finseq_1_th_22 sorry
    have A3: "lenFINSEQ-1K4 (<*FINSEQ-1K10 T*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    have A4: "(lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 p2 =XBOOLE-0R4 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)+NAT-1K1 \<one>\<^sub>M"
       sorry
    have "lenFINSEQ-1K4 p1 <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2"
      using nat_1_th_11 sorry
    then have A5: "lenFINSEQ-1K4 p1 <XXREAL-0R3 lenFINSEQ-1K4 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2)"
      using A1 A2 A3 A4 nat_1_th_13 sorry
    have "lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have "lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))"
      using A2 A3 finseq_3_th_25 sorry
    then have A6: "((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2).FUNCT-1K1 (lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_def_7 sorry
    also have "... = T"
      using finseq_1_th_42 sorry
    finally have "((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2).FUNCT-1K1 (lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 T"
       sorry
    thus "p inTARSKIR2 T implies (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K11 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2)"
      using A5 trees_3_def_15 sorry
    assume "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K11 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2)"
    then obtain n q where
      [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
      "n <XXREAL-0R3 lenFINSEQ-1K4 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2)"and A7: "q inTARSKIR2 ((p1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))^FINSEQ-1K8 p2).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A8: "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q"
      using trees_3_def_15 sorry
    have A9: "((<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p1*>)^FINSEQ-1K8 p).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 p1"
      using finseq_1_th_41 sorry
    have "((<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n"
      using finseq_1_th_41 sorry
    thus "p inTARSKIR2 T"
      using A6 A7 A8 A9 finseq_1_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_52:
"treeTREES-3K11 {}XBOOLE-0K1 =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
proof-
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 treeTREES-3K11 {}XBOOLE-0K1 implies p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6)) & (p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) implies p inTARSKIR2 treeTREES-3K11 {}XBOOLE-0K1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    show "p inTARSKIR2 treeTREES-3K11 {}XBOOLE-0K1 implies p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6)"
    proof-
      have "p inTARSKIR2 treeTREES-3K11 {}XBOOLE-0K1 implies ( not p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6) implies  False )"
      proof(rule impI,rule impI)
        assume "p inTARSKIR2 treeTREES-3K11 {}XBOOLE-0K1"
        then have A1: "p =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 ({}XBOOLE-0K1) & q inTARSKIR2 {}XBOOLE-0K1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & p =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
          using trees_3_def_15 sorry
        assume " not p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6)"
        thus " False "
          using A1 tarski_def_1 trees_1_th_29 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "p inTARSKIR2 elementary-treeTREES-1K2 (0NUMBERSK6)"
    then have "p =FINSEQ-1R1 {}XBOOLE-0K1"
      using tarski_def_1 trees_1_th_29 sorry
    thus "p inTARSKIR2 treeTREES-3K11 {}XBOOLE-0K1"
      using trees_3_def_15 sorry
  qed "sorry"
  thus "treeTREES-3K11 {}XBOOLE-0K1 =TREES-2R1 elementary-treeTREES-1K2 (0NUMBERSK6)"
    using trees_2_def_1 sorry
qed

mtheorem trees_3_th_53:
" for p be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 treeTREES-3K11 p"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds p be Tree-yieldingTREES-3V4 implies elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 treeTREES-3K11 p"
  proof(rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "p be Tree-yieldingTREES-3V4"
    then have A2: "rngFUNCT-1K2 p be constituted-TreesTREES-3V1"
       sorry
    have " for q be objectHIDDENM1 holds q inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) implies ( not q inHIDDENR3 treeTREES-3K11 p implies  not  True )"
    proof(rule ballI,rule impI,rule impI)
      fix q assume [ty]: "q be objectHIDDENM1"
      assume "q inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p)"
      then have "q inHIDDENR3 {<*FINSEQ-1K10 n*> where n be NatNAT-1M1 : n <XXREAL-0R3 lenFINSEQ-1K4 p } or q inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        using xboole_0_def_3 sorry
      then have A3: "( ex n be NatNAT-1M1 st q =HIDDENR1 <*FINSEQ-1K10 n*> & n <XXREAL-0R3 lenFINSEQ-1K4 p) or q =HIDDENR1 {}XBOOLE-0K1"
        using tarski_def_1 sorry
      assume A4: " not q inHIDDENR3 treeTREES-3K11 p"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A5: "q =HIDDENR1 <*FINSEQ-1K10 n*>"and A6: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
        using A3 trees_1_th_22 sorry
      have "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
        using A6 trees_3_lm_3 sorry
      then obtain t where 
        [ty]:"t be TreeTREES-1M1" and tDef:"t = p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        using A2 sorry
      have A7: "{}XBOOLE-0K1 inTARSKIR2 t"
        using trees_1_th_22 sorry
      have "(<*FINSEQ-1K10 n*>)^FINSEQ-1K8 {}XBOOLE-0K1 =HIDDENR1 q"
        using A5 finseq_1_th_34 sorry
      thus " not  True "
        using A1 A4 A6 A7 trees_3_def_15 sorry
    qed "sorry"
    thus "elementary-treeTREES-1K2 (lenFINSEQ-1K4 p) c=TARSKIR1 treeTREES-3K11 p"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_54:
" for i be NatNAT-1M1 holds elementary-treeTREES-1K2 i =TREES-2R1 treeTREES-3K11 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))"
proof-
  have " for i be NatNAT-1M1 holds elementary-treeTREES-1K2 i =TREES-2R1 treeTREES-3K11 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))"
  proof(rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    let ?p = "i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6)"
    have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 elementary-treeTREES-1K2 i implies q inTARSKIR2 treeTREES-3K11 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))) & (q inTARSKIR2 treeTREES-3K11 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6)) implies q inTARSKIR2 elementary-treeTREES-1K2 i)"
    proof(rule ballI,rule conjMI,rule impI)
      fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      have A1: "lenFINSEQ-1K4 ?p =XBOOLE-0R4 i"
        using card_1_def_7 sorry
      then have "elementary-treeTREES-1K2 i c=TARSKIR1 treeTREES-3K11 ?p"
        using trees_3_th_53 sorry
      thus "q inTARSKIR2 elementary-treeTREES-1K2 i implies q inTARSKIR2 treeTREES-3K11 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))"
         sorry
      assume "q inTARSKIR2 treeTREES-3K11 ?p"
      then have A2: "q =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 ?p & r inTARSKIR2 ?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r)"
        using trees_3_def_15 sorry
      have "( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6)) & r inTARSKIR2 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r) implies q inTARSKIR2 elementary-treeTREES-1K2 i"
      proof(rule impI)
        assume Given: " ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 ?p & r inTARSKIR2 ?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
        then obtain n r where
          [ty]:"n be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
          A3: "n <XXREAL-0R3 lenFINSEQ-1K4 ?p"and A4: "r inTARSKIR2 ?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A5: "q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
           sorry
        have "?p =FINSEQ-1R1 SegFINSEQ-1K2 i -->FUNCOP-1K7 elementary-treeTREES-1K2 (0NUMBERSK6)"
          using finseq_2_def_2 sorry
        then have A6: "rngFUNCT-1K2 ?p c=TARSKIR1 {TARSKIK1 elementary-treeTREES-1K2 (0NUMBERSK6) }"
          using funcop_1_th_13 sorry
        have "?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 ?p"
          using A3 trees_3_lm_3 sorry
        then have "?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 elementary-treeTREES-1K2 (0NUMBERSK6)"
          using A6 tarski_def_1 sorry
        then have "r =FINSEQ-1R1 {}XBOOLE-0K1"
          using A4 tarski_def_1 trees_1_th_29 sorry
        then have "q =FINSEQ-1R1 <*FINSEQ-1K10 n*>"
          using A5 finseq_1_th_34 sorry
        thus "q inTARSKIR2 elementary-treeTREES-1K2 i"
          using A1 A3 trees_1_th_28 sorry
      qed
      thus "q inTARSKIR2 elementary-treeTREES-1K2 i"
        using A2 trees_1_th_22 sorry
    qed "sorry"
    thus "elementary-treeTREES-1K2 i =TREES-2R1 treeTREES-3K11 (i  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))"
      using trees_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_55:
" for T be TreeTREES-1M1 holds  for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) =TREES-2R1 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
proof(rule ballI,rule ballI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  fix p assume [ty]: "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
  let ?W1 = "elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
  let ?W2 = "treeTREES-3K11 p \\/XBOOLE-0K2 ?W1"
  let ?W = "?W2 with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
  have "lenFINSEQ-1K4 (<*FINSEQ-1K10 T*>) =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_40 sorry
  then have A1: "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
    using finseq_1_th_22 sorry
  have "lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
    using nat_1_th_13 sorry
  then have "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> inTARSKIR2 ?W1"
    using trees_1_th_28 sorry
  then have A2: "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> inTARSKIR2 ?W2"
    using xboole_0_def_3 sorry
  have " for q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (q inTARSKIR2 treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) implies q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)) & (q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T) implies ( not q inTARSKIR2 treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) implies  not  True ))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    show "q inTARSKIR2 treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) implies q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
    proof(rule impI)
      assume "q inTARSKIR2 treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))"
      then have A3: "q =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) & r inTARSKIR2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r)"
        using trees_3_def_15 sorry
      have "( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) & r inTARSKIR2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r) implies q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
      proof(rule impI)
        assume Given: " ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) & r inTARSKIR2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
        then obtain n r where
          [ty]:"n be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
          A4: "n <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))"and A5: "r inTARSKIR2 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A6: "q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
           sorry
        have 
          [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          using A6 finseq_1_th_36 sorry
        have A7: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A1 A4 nat_1_th_13 sorry
        have A8: "n <XXREAL-0R3 lenFINSEQ-1K4 p implies q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
        proof(rule impI)
          assume A9: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
          then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
            using trees_3_lm_3 sorry
          then have "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using finseq_1_def_7 sorry
          then have "q inTARSKIR2 treeTREES-3K11 p"
            using A5 A6 A9 trees_3_def_15 sorry
          then have A10: "q inTARSKIR2 ?W2"
            using xboole_0_def_3 sorry
          have " not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> is-a-prefix-ofTREES-1R2 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
            using A9 trees_1_th_50 sorry
          then have " not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> is-a-proper-prefix-ofTREES-1R3 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
             sorry
          thus "q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
            using A2 A6 A10 trees_1_def_9 sorry
        qed
        have "n =XBOOLE-0R4 lenFINSEQ-1K4 p implies q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
        proof(rule impI)
          assume A11: "n =XBOOLE-0R4 lenFINSEQ-1K4 p"
          then have A12: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T"
            using finseq_1_th_42 sorry
          have "r =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> r"
             sorry
          thus "q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
            using A2 A5 A6 A11 A12 trees_1_def_9 sorry
        qed
        thus "q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
          using A7 A8 xxreal_0_th_1 sorry
      qed
      thus "q inTARSKIR2 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
        using A3 trees_1_th_22 sorry
    qed
    assume A13: "q inTARSKIR2 ?W"
    assume A14: " not q inTARSKIR2 treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))"
    have A15: "( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T & q =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r) implies  not  True "
    proof(rule impI)
      assume Given: " ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T & q =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
      then obtain r where
        [ty]:"r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
        A16: "r inTARSKIR2 T"and A17: "q =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r"
         sorry
      have A18: "lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      have "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T"
        using finseq_1_th_42 sorry
      thus " not  True "
        using A1 A14 A16 A17 A18 trees_3_def_15 sorry
    qed
    have "q inTARSKIR2 treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) implies  not  True "
    proof(rule impI)
      assume "q inTARSKIR2 ?W2"
      then have A19: "q inTARSKIR2 treeTREES-3K11 p or q inTARSKIR2 ?W1"
        using xboole_0_def_3 sorry
      have A20: "q inTARSKIR2 treeTREES-3K11 p implies  not  True "
      proof(rule impI)
        assume "q inTARSKIR2 treeTREES-3K11 p"
        then have "q =FINSEQ-1R1 {}XBOOLE-0K1 & {}XBOOLE-0K1 inTARSKIR2 treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) or ( ex n be NatNAT-1M1 st  ex r be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & r inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r)"
          using trees_3_def_15 sorry
        then obtain n r where
          [ty]:"n be NatNAT-1M1" "r be FinSequenceFINSEQ-1M1" and 
          A21: "n <XXREAL-0R3 lenFINSEQ-1K4 p"and A22: "r inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A23: "q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
          using A14 sorry
        have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
          using A21 trees_3_lm_3 sorry
        then have A24: "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_def_7 sorry
        have "n <XXREAL-0R3 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>))"
          using A1 A21 nat_1_th_13 sorry
        thus " not  True "
          using A14 A22 A23 A24 trees_3_def_15 sorry
      qed
      have " not q inTARSKIR2 treeTREES-3K11 p implies  not  True "
      proof(rule impI)
        assume A25: " not q inTARSKIR2 treeTREES-3K11 p"
        then have "q =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M & q =FINSEQ-1R1 <*FINSEQ-1K10 n*>)"
          using A19 trees_1_th_30 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A26: "n <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"and A27: "q =FINSEQ-1R1 <*FINSEQ-1K10 n*>"
          using A14 trees_1_th_22 sorry
        have A28: "n <XXREAL-0R3 lenFINSEQ-1K4 p implies {}XBOOLE-0K1 inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        proof(rule impI)
          assume "n <XXREAL-0R3 lenFINSEQ-1K4 p"
          then have A29: "p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 p"
            using trees_3_lm_3 sorry
          have "rngFUNCT-1K2 p be constituted-TreesTREES-3V1"
            using trees_3_def_9 sorry
          thus "{}XBOOLE-0K1 inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A29 trees_1_th_22 sorry
        qed
        have A30: "q =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 {}XBOOLE-0K1"
          using A27 finseq_1_th_34 sorry
        then have A31: "n >=XXREAL-0R2 lenFINSEQ-1K4 p"
          using A25 A28 trees_3_def_15 sorry
        have "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A26 nat_1_th_13 sorry
        then have A32: "lenFINSEQ-1K4 p =XBOOLE-0R4 n"
          using A31 xxreal_0_th_1 sorry
        have A33: "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        have A34: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T"
          using finseq_1_th_42 sorry
        have "{}XBOOLE-0K1 inTARSKIR2 T"
          using trees_1_th_22 sorry
        thus " not  True "
          using A1 A14 A30 A32 A33 A34 trees_3_def_15 sorry
      qed
      thus " not  True "
        using A20 sorry
    qed
    thus " not  True "
      using A2 A13 A15 trees_1_def_9 sorry
  qed "sorry"
  thus "treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)) =TREES-2R1 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T)"
    using trees_2_def_1 sorry
qed "sorry"

mtheorem trees_3_th_56:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 elementary-treeTREES-1K2 (0NUMBERSK6)*>)) =TREES-2R1 treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 elementary-treeTREES-1K2 (0NUMBERSK6)*>)) =HIDDENR1 treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix p assume [ty]: "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
    have "lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    then have A1: "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> inTARSKIR2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
      using trees_1_th_28 sorry
    then have A2: "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> inTARSKIR2 treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
      using xboole_0_def_3 sorry
    have "{}XBOOLE-0K1 inTARSKIR2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)"
      using trees_1_th_22 sorry
    then have A3: "elementary-treeTREES-1K2 (0NUMBERSK6) c=TARSKIR1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)"
      using trees_1_th_29 zfmisc_1_th_31 sorry
    have A4: "elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>) c=TARSKIR1 elementary-treeTREES-1K2 (0NUMBERSK6)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>) implies x inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)"
        then obtain q where 
          [ty]:"q be ElementTREES-1M2-of elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)" and qDef:"q = x"
           sorry
        have "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
          using A1 trees_1_def_6 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          "n <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"and A5: "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q =FINSEQ-1R1 <*FINSEQ-1K10 n*>"
          using trees_1_th_30 sorry
        have A6: "lenFINSEQ-1K4 (<*FINSEQ-1K10 n*>) =XBOOLE-0R4 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        have "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>) =XBOOLE-0R4 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        then have "\<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
          using A5 A6 finseq_1_th_22 sorry
        then have "x =HIDDENR1 {}XBOOLE-0K1"
           sorry
        thus "x inHIDDENR3 elementary-treeTREES-1K2 (0NUMBERSK6)"
          using trees_1_th_22 sorry
      qed "sorry"
      thus "elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>) c=TARSKIR1 elementary-treeTREES-1K2 (0NUMBERSK6)"
        using tarski_def_3 sorry
    qed
    have " for n be NatNAT-1M1 holds  for r be FinSequenceFINSEQ-1M1 holds <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r implies  not n <XXREAL-0R3 lenFINSEQ-1K4 p"
    proof(rule ballI,rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix r assume [ty]: "r be FinSequenceFINSEQ-1M1"
      assume "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 r"
      then have "n =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>).FUNCT-1K1 \<one>\<^sub>M"
        using finseq_1_th_41 sorry
      also have "... = lenFINSEQ-1K4 p"
        using finseq_1_th_40 sorry
      finally have "n =HIDDENR1 lenFINSEQ-1K4 p"
         sorry
      thus " not n <XXREAL-0R3 lenFINSEQ-1K4 p"
         sorry
    qed "sorry"
    then have " not ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 p & q inTARSKIR2 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 q)"
       sorry
    then have " not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> inTARSKIR2 treeTREES-3K11 p"
      using trees_3_def_15 sorry
    then have A7: "(treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>) =HIDDENR1 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)  |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)"
      using A2 trees_3_th_47 sorry
    also have "... = elementary-treeTREES-1K2 (0NUMBERSK6)"
      using A3 A4 sorry
    finally have "(treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)) |TREES-1K4 (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>) =HIDDENR1 elementary-treeTREES-1K2 (0NUMBERSK6)"
       sorry
    have "treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 elementary-treeTREES-1K2 (0NUMBERSK6)*>)) =HIDDENR1 (treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,elementary-treeTREES-1K2 (0NUMBERSK6))"
      using trees_3_th_55 sorry
    also have "... = treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
      using A2 A7 trees_2_th_6 sorry
    finally show "treeTREES-3K11 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 elementary-treeTREES-1K2 (0NUMBERSK6)*>)) =HIDDENR1 treeTREES-3K11 p \\/XBOOLE-0K2 elementary-treeTREES-1K2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_57:
" for p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1 holds  for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q) =TREES-2R1 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix p assume [ty]: "p be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
  fix q assume [ty]: "q be Tree-yieldingTREES-3V4\<bar>FinSequenceFINSEQ-1M1"
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  let ?w1 = "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q"
  let ?W1 = "treeTREES-3K11 ?w1"
  let ?w2 = "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q"
  let ?W2 = "treeTREES-3K11 ?w2"
  let ?W = "?W2 with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
  have A1: "lenFINSEQ-1K4 (<*FINSEQ-1K10 T1*>) =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_40 sorry
  have A2: "lenFINSEQ-1K4 (<*FINSEQ-1K10 T2*>) =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_40 sorry
  have A3: "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
    using A1 finseq_1_th_22 sorry
  have A4: "lenFINSEQ-1K4 ?w1 =XBOOLE-0R4 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)) +NAT-1K1 lenFINSEQ-1K4 q"
    using finseq_1_th_22 sorry
  have A5: "lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)) =XBOOLE-0R4 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
    using A2 finseq_1_th_22 sorry
  have A6: "lenFINSEQ-1K4 ?w2 =XBOOLE-0R4 lenFINSEQ-1K4 (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)) +NAT-1K1 lenFINSEQ-1K4 q"
    using finseq_1_th_22 sorry
  have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 q"
    using nat_1_th_11 sorry
  then have A7: "lenFINSEQ-1K4 p <XXREAL-0R3 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 q"
    using nat_1_th_13 sorry
  then have A8: "?w2 .FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 ?w2"
    using A5 A6 trees_3_lm_3 sorry
  have "rngFUNCT-1K2 ?w2 be constituted-TreesTREES-3V1"
    using trees_3_def_9 sorry
  then have A9: "{}XBOOLE-0K1 inTARSKIR2 ?w2 .FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
    using A8 trees_1_th_22 sorry
  have "(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>"
    using finseq_1_th_34 sorry
  then have A10: "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> inTARSKIR2 ?W2"
    using A5 A6 A7 A9 trees_3_def_15 sorry
  have " for r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (r inTARSKIR2 treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q) implies r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)) & (r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1) implies ( not r inTARSKIR2 treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q) implies  False ))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix r assume [ty]: "r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    show "r inTARSKIR2 treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q) implies r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
    proof(rule impI)
      assume "r inTARSKIR2 ?W1"
      then have A11: "r =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex n be NatNAT-1M1 st  ex s be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 ?w1 & s inTARSKIR2 ?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & r =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s)"
        using trees_3_def_15 sorry
      have "( ex n be NatNAT-1M1 st  ex s be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q) & s inTARSKIR2 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & r =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s) implies r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
      proof(rule impI)
        assume Given: " ex n be NatNAT-1M1 st  ex s be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 ?w1 & s inTARSKIR2 ?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & r =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s"
        then obtain n s where
          [ty]:"n be NatNAT-1M1" "s be FinSequenceFINSEQ-1M1" and 
          A12: "n <XXREAL-0R3 lenFINSEQ-1K4 ?w1"and A13: "s inTARSKIR2 ?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A14: "r =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s"
           sorry
        have 
          [ty]:"s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          using A14 finseq_1_th_36 sorry
        have A15: "n <=XXREAL-0R1 lenFINSEQ-1K4 p or n >=XXREAL-0R2 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        have A16: "n <XXREAL-0R3 lenFINSEQ-1K4 p implies r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
        proof(rule impI)
          assume A17: "n <XXREAL-0R3 lenFINSEQ-1K4 p"
          then have A18: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
            using trees_3_lm_3 sorry
          have A19: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))"
            using finseq_1_th_26 sorry
          have A20: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))"
            using finseq_1_th_26 sorry
          have A21: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A18 finseq_1_def_7 sorry
          have A22: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A18 finseq_1_def_7 sorry
          have A23: "?w2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A18 A19 A21 finseq_1_def_7 sorry
          have "?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A18 A20 A22 finseq_1_def_7 sorry
          then have A24: "r inTARSKIR2 ?W2"
            using A3 A4 A5 A6 A12 A13 A14 A23 trees_3_def_15 sorry
          have " not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> is-a-prefix-ofTREES-1R2 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s"
            using A17 trees_1_th_50 sorry
          then have " not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> is-a-proper-prefix-ofTREES-1R3 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s"
             sorry
          thus "r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
            using A10 A14 A24 trees_1_def_9 sorry
        qed
        have A25: "n =XBOOLE-0R4 lenFINSEQ-1K4 p implies r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
        proof(rule impI)
          assume A26: "n =XBOOLE-0R4 lenFINSEQ-1K4 p"
          then have A27: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T1"
            using finseq_1_th_42 sorry
          have "n <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
            using A26 nat_1_th_13 sorry
          then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))"
            using A3 trees_3_lm_3 sorry
          then have A28: "?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T1"
            using A27 finseq_1_def_7 sorry
          have "s =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> s"
             sorry
          thus "r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
            using A10 A13 A14 A26 A28 trees_1_def_9 sorry
        qed
        have "n >=XXREAL-0R2 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M & n <XXREAL-0R3 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 q implies r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
        proof(rule impMI ,rule impI)
          assume A29: "n >=XXREAL-0R2 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
            and A30: "n <XXREAL-0R3 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 q"
          have A31: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
            using A29 xreal_1_th_7 sorry
          have A32: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 q"
            using A30 nat_1_th_13 sorry
          then have A33: "?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))"
            using A3 A31 finseq_1_th_23 sorry
          have "?w2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))"
            using A5 A31 A32 finseq_1_th_23 sorry
          then have A34: "r inTARSKIR2 ?W2"
            using A3 A4 A5 A6 A12 A13 A14 A33 trees_3_def_15 sorry
          have "lenFINSEQ-1K4 p <>HIDDENR2 n"
            using A29 nat_1_th_13 sorry
          then have " not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> is-a-prefix-ofTREES-1R2 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s"
            using trees_1_th_50 sorry
          then have " not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> is-a-proper-prefix-ofTREES-1R3 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s"
             sorry
          thus "r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
            using A10 A14 A34 trees_1_def_9 sorry
        qed
        thus "r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
          using A3 A12 A15 A16 A25 finseq_1_th_22 xxreal_0_th_1 sorry
      qed
      thus "r inTARSKIR2 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
        using A11 trees_1_th_22 sorry
    qed
    assume "r inTARSKIR2 ?W"
    then have A35: "r inTARSKIR2 ?W2 &  not <*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*> is-a-proper-prefix-ofTREES-1R3 r or ( ex s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st s inTARSKIR2 T1 & r =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> s)"
      using A10 trees_1_def_9 sorry
    assume A36: " not r inTARSKIR2 ?W1"
    then have A37: "r <>HIDDENR2 {}XBOOLE-0K1"
      using trees_3_def_15 sorry
    have A38: "(p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)).FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T1"
      using finseq_1_th_42 sorry
    have A39: "lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 lenFINSEQ-1K4 q"
      using nat_1_th_11 sorry
    then have A40: "lenFINSEQ-1K4 p <XXREAL-0R3 lenFINSEQ-1K4 ?w2"
      using A5 A6 nat_1_th_13 sorry
    have "lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))"
      using A3 A39 trees_3_lm_3 sorry
    then have A41: "?w1 .FUNCT-1K1 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 T1"
      using A38 finseq_1_def_7 sorry
    then obtain n s where
      [ty]:"n be NatNAT-1M1" "s be FinSequenceFINSEQ-1M1" and 
      A42: "n <XXREAL-0R3 lenFINSEQ-1K4 ?w2"and A43: "s inTARSKIR2 ?w2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A44: "r =FINSEQ-1R1 (<*FINSEQ-1K10 n*>)^FINSEQ-1K8 s"
      using A3 A4 A5 A6 A35 A36 A37 A40 trees_3_def_15 sorry
    have 
      [ty]:"s be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      using A44 finseq_1_th_36 sorry
    have A45: "n =XBOOLE-0R4 lenFINSEQ-1K4 p implies s =FINSEQ-1R1 {}XBOOLE-0K1"
      using A3 A4 A5 A6 A35 A36 A41 A42 A44 trees_3_def_15 trees_1_th_10 sorry
    have "{}XBOOLE-0K1 inTARSKIR2 T1"
      using trees_1_th_22 sorry
    then have "n <>HIDDENR2 lenFINSEQ-1K4 p"
      using A3 A4 A5 A6 A36 A41 A42 A44 A45 trees_3_def_15 sorry
    then have "n <XXREAL-0R3 lenFINSEQ-1K4 p or n >XXREAL-0R4 lenFINSEQ-1K4 p & \<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M"
      using xxreal_0_th_1 sorry
    then have "(((\<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 n & \<one>\<^sub>M +XCMPLX-0K2 n =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M) & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p) & ?w1 =FINSEQ-1R1 p ^FINSEQ-1K8 ((<*FINSEQ-1K10 T1*>)^FINSEQ-1K8 q)) & ?w2 =FINSEQ-1R1 p ^FINSEQ-1K8 ((<*FINSEQ-1K10 T2*>)^FINSEQ-1K8 q) or lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?w1"
      using A3 A4 A5 A6 A42 finseq_1_th_32 nat_1_th_11 nat_1_th_13 xreal_1_th_6 sorry
    then have "?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & ?w2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) or ?w1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)) & ?w2 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 q .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M))"
      using A3 A4 A5 A6 trees_3_lm_1 finseq_1_th_24 sorry
    thus " False "
      using A3 A4 A5 A6 A36 A42 A43 A44 trees_3_def_15 sorry
  qed "sorry"
  thus "treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>))^FINSEQ-1K8 q) =TREES-2R1 (treeTREES-3K11 ((p ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>))^FINSEQ-1K8 q))with-replacementTREES-1K5(<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> lenFINSEQ-1K4 p*>,T1)"
    using trees_2_def_1 sorry
qed "sorry"

abbreviation(input) TREES_3K14("<*TREES-3K14  _ *>" [0]164) where
  "<*TREES-3K14 n*> \<equiv> <*FINSEQ-1K6 n*>"

mtheorem trees_3_add_7:
  mlet "n be NatNAT-1M1"
"cluster <*FINSEQ-1K6 n*> as-term-is FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
proof
(*coherence*)
  show "<*FINSEQ-1K6 n*> be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
  proof-
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "<*FINSEQ-1K13\<^bsub>(NATNUMBERSK1)\<^esub> n*> be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
       sorry
    thus "<*FINSEQ-1K6 n*> be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
       sorry
  qed
qed "sorry"

mtheorem trees_3_th_58:
" for T be TreeTREES-1M1 holds ^TREES-3K12 T =TREES-2R1 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
proof(rule ballI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 ^TREES-3K12 T implies p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)) & (p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T) implies p inTARSKIR2 ^TREES-3K12 T)"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have A1: "(<*FINSEQ-1K10 T*>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 T"
      using finseq_1_th_40 sorry
    have A2: "lenFINSEQ-1K4 (<*FINSEQ-1K10 T*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    have A3: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    have A4: "{}XBOOLE-0K1 inTARSKIR2 T"
      using trees_1_th_22 sorry
    have A5: "<*TREES-3K14 0NUMBERSK6 *> inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M"
      using tarski_def_2 trees_1_th_51 sorry
    show "p inTARSKIR2 ^TREES-3K12 T implies p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
    proof(rule impI)
      assume A6: "p inTARSKIR2 ^TREES-3K12 T"
      have "p <>HIDDENR2 {}XBOOLE-0K1 implies p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
      proof(rule impI)
        assume "p <>HIDDENR2 {}XBOOLE-0K1"
        then obtain n q where
          [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
          A7: "n <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K10 T*>)"and A8: "q inTARSKIR2 (<*FINSEQ-1K10 T*>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A9: "p =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q"
          using A6 trees_3_def_15 sorry
        have 
          [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          using A9 finseq_1_th_36 sorry
        have A10: "n =XBOOLE-0R4 0NUMBERSK6"
          using A2 A3 A7 nat_1_th_13 sorry
        have "p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
          using A9 sorry
        thus "p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
          using A1 A5 A8 A10 trees_1_def_9 sorry
      qed
      thus "p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
        using trees_1_th_22 sorry
    qed
    assume "p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
    then have A11: "p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M &  not <*TREES-3K14 0NUMBERSK6 *> is-a-proper-prefix-ofTREES-1R3 p or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T & p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      using A5 trees_1_def_9 sorry
    have "p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M implies p inTARSKIR2 ^TREES-3K12 T"
    proof(rule impI)
      assume "p inTARSKIR2 elementary-treeTREES-1K2 \<one>\<^sub>M"
      then have "p =FINSEQ-1R1 {}XBOOLE-0K1 or p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> <*TREES-3K14 0NUMBERSK6 *> & p ^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 p"
        using finseq_1_th_34 tarski_def_2 trees_1_th_51 sorry
      thus "p inTARSKIR2 ^TREES-3K12 T"
        using A1 A2 A3 A4 trees_3_def_15 sorry
    qed
    thus "p inTARSKIR2 ^TREES-3K12 T"
      using A1 A2 A3 A11 trees_3_def_15 sorry
  qed "sorry"
  thus "^TREES-3K12 T =TREES-2R1 elementary-treeTREES-1K2 \<one>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T)"
    using trees_2_def_1 sorry
qed "sorry"

mtheorem trees_3_th_59:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds treeTREES-3K13(T1,T2) =TREES-2R1 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
proof(rule ballI,rule ballI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds (p inTARSKIR2 treeTREES-3K13(T1,T2) implies p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)) & (p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2) implies p inTARSKIR2 treeTREES-3K13(T1,T2))"
  proof(rule ballI,rule conjMI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have A1: "(<*FINSEQ-1K11 T1,T2 *>).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 T1"
      using finseq_1_th_44 sorry
    have A2: "(<*FINSEQ-1K11 T1,T2 *>).FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 T2"
      using finseq_1_th_44 sorry
    have A3: "lenFINSEQ-1K4 (<*FINSEQ-1K11 T1,T2 *>) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_1_th_44 sorry
    have A4: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
       sorry
    have A5: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    have A6: "{}XBOOLE-0K1 inTARSKIR2 T1"
      using trees_1_th_22 sorry
    have A7: "{}XBOOLE-0K1 inTARSKIR2 T2"
      using trees_1_th_22 sorry
    have A8: "<*TREES-3K14 0NUMBERSK6 *> inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M"
      using enumset1_def_1 trees_1_th_53 sorry
    have A9: "<*TREES-3K14 \<one>\<^sub>M*> inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M"
      using enumset1_def_1 trees_1_th_53 sorry
    have " not <*TREES-3K14 0NUMBERSK6 *> is-a-proper-prefix-ofTREES-1R3 <*TREES-3K14 \<one>\<^sub>M*>"
      using trees_1_th_52 sorry
    then have A10: "<*TREES-3K14 \<one>\<^sub>M*> inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1)"
      using A8 A9 trees_1_def_9 sorry
    show "p inTARSKIR2 treeTREES-3K13(T1,T2) implies p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
    proof(rule impI)
      assume A11: "p inTARSKIR2 treeTREES-3K13(T1,T2)"
      have "p <>HIDDENR2 {}XBOOLE-0K1 implies p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
      proof(rule impI)
        assume "p <>HIDDENR2 {}XBOOLE-0K1"
        then obtain n q where
          [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
          A12: "n <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K11 T1,T2 *>)"and A13: "q inTARSKIR2 (<*FINSEQ-1K11 T1,T2 *>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A14: "p =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q"
          using A11 trees_3_def_15 sorry
        have 
          [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
          using A14 finseq_1_th_36 sorry
        have A15: " not <*TREES-3K14 \<one>\<^sub>M*> is-a-prefix-ofTREES-1R2 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
          using trees_1_th_50 sorry
        have 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A16: "n =XBOOLE-0R4 0NUMBERSK6 implies p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
        proof(rule impI)
          assume A17: "n =XBOOLE-0R4 0NUMBERSK6"
          then have A18: " not <*TREES-3K14 \<one>\<^sub>M*> is-a-proper-prefix-ofTREES-1R3 (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q"
            using A15 sorry
          have "(<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1)"
            using A1 A8 A13 A17 trees_1_def_9 sorry
          thus "p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
            using A10 A14 A18 trees_1_def_9 sorry
        qed
        have "n <=XXREAL-0R1 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using A3 A4 A12 nat_1_th_13 sorry
        then have "n =XBOOLE-0R4 \<one>\<^sub>M & (n =XBOOLE-0R4 \<one>\<^sub>M implies (<*TREES-3K14 n*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> q inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)) or n >=XXREAL-0R2 0NUMBERSK6 & n <=XXREAL-0R1 0NUMBERSK6"
          using A2 A10 A13 nat_1_th_8 trees_1_def_9 sorry
        thus "p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
          using A14 A16 sorry
      qed
      thus "p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
        using trees_1_th_22 sorry
    qed
    assume "p inTARSKIR2 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
    then have A19: "p inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1) &  not <*TREES-3K14 \<one>\<^sub>M*> is-a-proper-prefix-ofTREES-1R3 p or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T2 & p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
      using A10 trees_1_def_9 sorry
    have "p inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1) implies p inTARSKIR2 treeTREES-3K13(T1,T2)"
    proof(rule impI)
      assume "p inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1)"
      then have A20: "p inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M &  not <*TREES-3K14 0NUMBERSK6 *> is-a-proper-prefix-ofTREES-1R3 p or ( ex r be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 st r inTARSKIR2 T1 & p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> r)"
        using A8 trees_1_def_9 sorry
      have "p inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M implies p inTARSKIR2 treeTREES-3K13(T1,T2)"
      proof(rule impI)
        assume "p inTARSKIR2 elementary-treeTREES-1K2 \<two>\<^sub>M"
        then have A21: "(p =FINSEQ-1R1 {}XBOOLE-0K1 or p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> <*TREES-3K14 0NUMBERSK6 *>) or p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> <*TREES-3K14 \<one>\<^sub>M*>"
          using enumset1_def_1 trees_1_th_53 sorry
        have "p ^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 p"
          using finseq_1_th_34 sorry
        thus "p inTARSKIR2 treeTREES-3K13(T1,T2)"
          using A1 A2 A3 A4 A5 A6 A7 A21 trees_3_def_15 sorry
      qed
      thus "p inTARSKIR2 treeTREES-3K13(T1,T2)"
        using A1 A3 A5 A20 trees_3_def_15 sorry
    qed
    thus "p inTARSKIR2 treeTREES-3K13(T1,T2)"
      using A2 A3 A4 A19 trees_3_def_15 sorry
  qed "sorry"
  thus "treeTREES-3K13(T1,T2) =TREES-2R1 (elementary-treeTREES-1K2 \<two>\<^sub>M with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T1))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T2)"
    using trees_2_def_1 sorry
qed "sorry"

mtheorem trees_3_cl_51:
  mlet "p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
"cluster treeTREES-3K11 p as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "treeTREES-3K11 p be finiteFINSET-1V1"
  proof-
    let ?X = "\<lambda>Lamb1.  for p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 Lamb1 implies treeTREES-3K11 p be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    have A1: "?X(0NUMBERSK6)"
    proof-
      have " for p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6 implies treeTREES-3K11 p be finiteFINSET-1V1\<bar>TreeTREES-1M1"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
        assume "lenFINSEQ-1K4 p =XBOOLE-0R4 0NUMBERSK6"
        then have "p =FINSEQ-1R1 {}XBOOLE-0K1"
           sorry
        thus "treeTREES-3K11 p be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          using trees_3_th_52 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 n implies treeTREES-3K11 p be finiteFINSET-1V1\<bar>TreeTREES-1M1) implies ( for p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies treeTREES-3K11 p be finiteFINSET-1V1\<bar>TreeTREES-1M1)"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: " for p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 p =XBOOLE-0R4 n implies treeTREES-3K11 p be finiteFINSET-1V1\<bar>TreeTREES-1M1"
        fix p assume [ty]: "p be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
        assume A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
        have "p <>HIDDENR2 {}XBOOLE-0K1"
          using A4 sorry
        then obtain q x where
          [ty]:"q be FinSequenceFINSEQ-1M1" "x be objectHIDDENM1" and 
          A5: "p =FINSEQ-1R1 q ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)"
          using finseq_1_th_46 sorry
        have 
          [ty]:"q be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
          using A5 trees_3_th_26 sorry
        have "lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) =XBOOLE-0R4 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        then have A6: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q +NAT-1K1 \<one>\<^sub>M"
          using A5 finseq_1_th_22 sorry
        then have "treeTREES-3K11 q be finiteFINSET-1V1"
          using A3 A4 sorry
        then obtain W where 
          [ty]:"W be finiteFINSET-1V1\<bar>TreeTREES-1M1" and WDef:"W = treeTREES-3K11 q \\/XBOOLE-0K2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        have "<*FINSEQ-1K10 x*> be FinTree-yieldingTREES-3V5"
          using A5 trees_3_th_26 sorry
        then have 
          [ty]:"x be finiteFINSET-1V1\<bar>TreeTREES-1M1"
          using trees_3_th_29 sorry
        have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "<*TREES-3K14 n*> inTARSKIR2 elementary-treeTREES-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          using trees_1_th_28 sorry
        then obtain r where 
          [ty]:"r be ElementTREES-1M2-of W" and rDef:"r = <*TREES-3K14 n*>"
          using xboole_0_def_3 sorry
        have "treeTREES-3K11 p =TREES-2R1 W with-replacementTREES-1K5(r,x)"
          using A4 A5 A6 trees_3_th_55 sorry
        thus "treeTREES-3K11 p be finiteFINSET-1V1\<bar>TreeTREES-1M1"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A1 A2 sorry
    then have "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 p implies treeTREES-3K11 p be finiteFINSET-1V1"
       sorry
    thus "treeTREES-3K11 p be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem trees_3_cl_52:
  mlet "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster ^TREES-3K12 T as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "^TREES-3K12 T be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem trees_3_cl_53:
  mlet "T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1", "T2 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
"cluster treeTREES-3K13(T1,T2) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "treeTREES-3K13(T1,T2) be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem trees_3_th_60:
" for T be TreeTREES-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 ^TREES-3K12 T iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p)"
proof-
  have " for T be TreeTREES-1M1 holds  for x be objectHIDDENM1 holds (x inHIDDENR3 ^TREES-3K12 T & x <>HIDDENR2 {}XBOOLE-0K1 implies ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p)) &  not ( not ( not x =HIDDENR1 {}XBOOLE-0K1 & ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p))) &  not x inHIDDENR3 ^TREES-3K12 T)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?p = "<*FINSEQ-1K10 T*>"
    have A1: "lenFINSEQ-1K4 ?p =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    have A2: "?p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 T"
      using finseq_1_th_40 sorry
    show "x inHIDDENR3 ^TREES-3K12 T & x <>HIDDENR2 {}XBOOLE-0K1 implies ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p)"
    proof-
      have "x inHIDDENR3 ^TREES-3K12 T & x <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p))"
      proof(rule impMI ,rule impI)
        assume A3: "x inHIDDENR3 ^TREES-3K12 T"
          and A4: "x <>HIDDENR2 {}XBOOLE-0K1"
        obtain n q where
          [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
          A5: "n <XXREAL-0R3 lenFINSEQ-1K4 ?p"and A6: "q inTARSKIR2 ?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A7: "x =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q"
          using A3 A4 trees_3_def_15 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
        then have "n =XBOOLE-0R4 0NUMBERSK6"
          using A1 A5 nat_1_th_13 sorry
        thus " not ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p))"
          using A2 A6 A7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "0NUMBERSK6 <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
       sorry
    thus " not ( not ( not x =HIDDENR1 {}XBOOLE-0K1 & ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p))) &  not x inHIDDENR3 ^TREES-3K12 T)"
      using A1 A2 trees_3_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_61:
" for T be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T iff (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 ^TREES-3K12 T"
proof-
  have " for T be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds (p inTARSKIR2 T implies (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 ^TREES-3K12 T) & ((<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 ^TREES-3K12 T implies p inTARSKIR2 T)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix T assume [ty]: "T be TreeTREES-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    show "p inTARSKIR2 T implies (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 ^TREES-3K12 T"
      using trees_3_th_60 sorry
    assume "(<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 ^TREES-3K12 T"
    then obtain n q where
      [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
      "n <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K10 T*>)"and A1: "q inTARSKIR2 (<*FINSEQ-1K10 T*>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A2: "(<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q"
      using trees_3_def_15 sorry
    have A3: "((<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
      using finseq_1_th_41 sorry
    have A4: "((<*TREES-3K14 n*>)^FINSEQ-1K8 q).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 n"
      using finseq_1_th_41 sorry
    then have "p =FINSEQ-1R1 q"
      using A2 A3 finseq_1_th_33 sorry
    thus "p inTARSKIR2 T"
      using A1 A2 A3 A4 finseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_62:
" for T be TreeTREES-1M1 holds elementary-treeTREES-1K2 \<one>\<^sub>M c=TARSKIR1 ^TREES-3K12 T"
proof(rule ballI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 elementary-treeTREES-1K2 \<one>\<^sub>M implies x inHIDDENR3 ^TREES-3K12 T"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 elementary-treeTREES-1K2 \<one>\<^sub>M"
    then obtain p where 
      [ty]:"p be ElementTREES-1M2-of elementary-treeTREES-1K2 \<one>\<^sub>M" and pDef:"p = x"
       sorry
    have "p =FINSEQ-1R1 {}XBOOLE-0K1 or (p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> <*TREES-3K14 0NUMBERSK6 *> & {}XBOOLE-0K1 inTARSKIR2 T) & (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*TREES-3K14 0NUMBERSK6 *>"
      using finseq_1_th_34 tarski_def_2 trees_1_th_22 trees_1_th_51 sorry
    thus "x inHIDDENR3 ^TREES-3K12 T"
      using trees_3_th_60 sorry
  qed "sorry"
  thus "elementary-treeTREES-1K2 \<one>\<^sub>M c=TARSKIR1 ^TREES-3K12 T"
    using tarski_def_3 sorry
qed "sorry"

mtheorem trees_3_th_63:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds T1 c=TARSKIR1 T2 implies ^TREES-3K12 T1 c=TARSKIR1 ^TREES-3K12 T2"
proof(rule ballI,rule ballI,rule impI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  assume A1: "T1 c=TARSKIR1 T2"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 ^TREES-3K12 T1 implies x inHIDDENR3 ^TREES-3K12 T2"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 ^TREES-3K12 T1"
    then obtain p where 
      [ty]:"p be ElementTREES-1M2-of ^TREES-3K12 T1" and pDef:"p = x"
       sorry
    have "p =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex q be FinSequenceFINSEQ-1M1 st q inTARSKIR2 T1 & p =FINSEQ-1R1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q)"
      using trees_3_th_60 sorry
    thus "x inHIDDENR3 ^TREES-3K12 T2"
      using A1 trees_3_th_60 sorry
  qed "sorry"
  thus "^TREES-3K12 T1 c=TARSKIR1 ^TREES-3K12 T2"
    using tarski_def_3 sorry
qed "sorry"

mtheorem trees_3_th_64:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds ^TREES-3K12 T1 =TREES-2R1 ^TREES-3K12 T2 implies T1 =TREES-2R1 T2"
proof(rule ballI,rule ballI,rule impI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  assume A1: "^TREES-3K12 T1 =TREES-2R1 ^TREES-3K12 T2"
  have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 T1 &  not p inTARSKIR2 T2) &  not (p inTARSKIR2 T2 &  not p inTARSKIR2 T1)"
  proof(rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
    have "p inTARSKIR2 T1 iff (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p inTARSKIR2 ^TREES-3K12 T1"
      using trees_3_th_61 sorry
    thus " not (p inTARSKIR2 T1 &  not p inTARSKIR2 T2) &  not (p inTARSKIR2 T2 &  not p inTARSKIR2 T1)"
      using A1 trees_3_th_61 sorry
  qed "sorry"
  thus "T1 =TREES-2R1 T2"
    using trees_2_def_1 sorry
qed "sorry"

mtheorem trees_3_th_65:
" for T be TreeTREES-1M1 holds (^TREES-3K12 T) |TREES-1K4 (<*TREES-3K14 0NUMBERSK6 *>) =TREES-2R1 T"
proof(rule ballI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  let ?p = "<*FINSEQ-1K10 T*>"
  have A1: "lenFINSEQ-1K4 ?p =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_40 sorry
  have A2: "?p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 T"
    using finseq_1_th_40 sorry
  have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
     sorry
  thus "(^TREES-3K12 T) |TREES-1K4 (<*TREES-3K14 0NUMBERSK6 *>) =TREES-2R1 T"
    using A1 A2 trees_3_th_49 sorry
qed "sorry"

mtheorem trees_3_th_66:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds (^TREES-3K12 T1)with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T2) =TREES-2R1 ^TREES-3K12 T2"
proof(rule ballI,rule ballI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  have A1: "lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6"
     sorry
  have A2: "<*FINSEQ-1K10 T1*> =FINSEQ-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)"
    using finseq_1_th_34 sorry
  have A3: "<*FINSEQ-1K10 T2*> =FINSEQ-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)"
    using finseq_1_th_34 sorry
  have A4: "<*FINSEQ-1K10 T1*> =FINSEQ-1R1 (<*FINSEQ-1K10 T1*>)^FINSEQ-1K8 {}XBOOLE-0K1"
    using finseq_1_th_34 sorry
  have "<*FINSEQ-1K10 T2*> =FINSEQ-1R1 (<*FINSEQ-1K10 T2*>)^FINSEQ-1K8 {}XBOOLE-0K1"
    using finseq_1_th_34 sorry
  thus "(^TREES-3K12 T1)with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T2) =TREES-2R1 ^TREES-3K12 T2"
    using A1 A2 A3 A4 trees_3_th_57 sorry
qed "sorry"

mtheorem trees_3_th_67:
"^TREES-3K12 elementary-treeTREES-1K2 (0NUMBERSK6) =TREES-2R1 elementary-treeTREES-1K2 \<one>\<^sub>M"
proof-
  have "^TREES-3K12 elementary-treeTREES-1K2 (0NUMBERSK6) =HIDDENR1 elementary-treeTREES-1K2 \<one>\<^sub>M"
  proof-
    let ?T = "elementary-treeTREES-1K2 (0NUMBERSK6)"
    have "^TREES-3K12 elementary-treeTREES-1K2 (0NUMBERSK6) =HIDDENR1 treeTREES-3K11 (\<one>\<^sub>M  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))"
      using finseq_2_th_59 sorry
    also have "... = elementary-treeTREES-1K2 \<one>\<^sub>M"
      using trees_3_th_54 sorry
    finally show "^TREES-3K12 elementary-treeTREES-1K2 (0NUMBERSK6) =HIDDENR1 elementary-treeTREES-1K2 \<one>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_68:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 treeTREES-3K13(T1,T2) iff x =HIDDENR1 {}XBOOLE-0K1 or ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p or p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p)"
proof-
  have " for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for x be objectHIDDENM1 holds (x inHIDDENR3 treeTREES-3K13(T1,T2) & x <>HIDDENR2 {}XBOOLE-0K1 implies ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p or p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p)) &  not ( not ( not x =HIDDENR1 {}XBOOLE-0K1 & ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p) &  not (p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p))) &  not x inHIDDENR3 treeTREES-3K13(T1,T2))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix T2 assume [ty]: "T2 be TreeTREES-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?p = "<*FINSEQ-1K11 T1,T2 *>"
    have A1: "lenFINSEQ-1K4 ?p =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_1_th_44 sorry
    have A2: "?p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 T1"
      using finseq_1_th_44 sorry
    have A3: "?p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 T2"
      using finseq_1_th_44 sorry
    show "x inHIDDENR3 treeTREES-3K13(T1,T2) & x <>HIDDENR2 {}XBOOLE-0K1 implies ( ex p be FinSequenceFINSEQ-1M1 st p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p or p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p)"
    proof-
      have "x inHIDDENR3 treeTREES-3K13(T1,T2) & x <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p) &  not (p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p))"
      proof(rule impMI ,rule impI)
        assume A4: "x inHIDDENR3 treeTREES-3K13(T1,T2)"
          and A5: "x <>HIDDENR2 {}XBOOLE-0K1"
        obtain n q where
          [ty]:"n be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
          A6: "n <XXREAL-0R3 lenFINSEQ-1K4 ?p"and A7: "q inTARSKIR2 ?p .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"and A8: "x =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q"
          using A4 A5 trees_3_def_15 sorry
        have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
           sorry
        then have "n <=XXREAL-0R1 \<one>\<^sub>M"
          using A1 A6 nat_1_th_13 sorry
        then have "n =XBOOLE-0R4 \<one>\<^sub>M or n <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using xxreal_0_th_1 sorry
        then have "n =XBOOLE-0R4 \<one>\<^sub>M or n =XBOOLE-0R4 0NUMBERSK6"
          using nat_1_th_13 sorry
        thus " not ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p) &  not (p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p))"
          using A2 A3 A7 A8 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "( ex q be FinSequenceFINSEQ-1M1 st q inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q or q inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 q) implies ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K11 T1,T2 *>) & (q inTARSKIR2 (<*FINSEQ-1K11 T1,T2 *>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & x =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q))"
    proof(rule impI)
      assume Given: " ex q be FinSequenceFINSEQ-1M1 st q inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q or q inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 q"
      then obtain q where
        [ty]:"q be FinSequenceFINSEQ-1M1" and 
        A9: "q inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q or q inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 q"
         sorry
      have "x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q or x <>HIDDENR2 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q"
         sorry
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A10: "n =XBOOLE-0R4 0NUMBERSK6 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q or n =XBOOLE-0R4 \<one>\<^sub>M & x <>HIDDENR2 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q"
         sorry
      show " ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K11 T1,T2 *>) & (q inTARSKIR2 (<*FINSEQ-1K11 T1,T2 *>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & x =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q)"
      proof(rule bexI[of _ "n"])
        show " ex q be FinSequenceFINSEQ-1M1 st n <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K11 T1,T2 *>) & (q inTARSKIR2 (<*FINSEQ-1K11 T1,T2 *>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & x =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q)"
        proof(rule bexI[of _ "q"],rule conjMI)
          show "n <XXREAL-0R3 lenFINSEQ-1K4 (<*FINSEQ-1K11 T1,T2 *>)"
            using A1 A10 sorry
          have "((<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
            using finseq_1_th_41 sorry
          thus "q inTARSKIR2 (<*FINSEQ-1K11 T1,T2 *>).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & x =HIDDENR1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q"
            using A9 A10 finseq_1_th_41 finseq_1_th_44 sorry
        qed "sorry"
      qed "sorry"
    qed
    thus " not ( not ( not x =HIDDENR1 {}XBOOLE-0K1 & ( for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T1 & x =HIDDENR1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p) &  not (p inTARSKIR2 T2 & x =HIDDENR1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p))) &  not x inHIDDENR3 treeTREES-3K13(T1,T2))"
      using trees_3_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_69:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T1 iff (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)"
proof-
  have " for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T1 &  not (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)) &  not ((<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2) &  not p inTARSKIR2 T1)"
  proof(rule ballI,rule ballI)
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix T2 assume [ty]: "T2 be TreeTREES-1M1"
    have A1: "<*FINSEQ-1K11 T1,T2 *> =FINSEQ-1R1 (<*FINSEQ-1K10 T1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)"
      using finseq_1_def_9 sorry
    have A2: "<*FINSEQ-1K10 T1*> =FINSEQ-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)"
      using finseq_1_th_34 sorry
    have "lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    thus " for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T1 &  not (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)) &  not ((<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2) &  not p inTARSKIR2 T1)"
      using A1 A2 trees_3_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_70:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T2 iff (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)"
proof-
  have " for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T2 &  not (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)) &  not ((<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2) &  not p inTARSKIR2 T2)"
  proof(rule ballI,rule ballI)
    fix T1 assume [ty]: "T1 be TreeTREES-1M1"
    fix T2 assume [ty]: "T2 be TreeTREES-1M1"
    have A1: "<*FINSEQ-1K11 T1,T2 *> =FINSEQ-1R1 (<*FINSEQ-1K10 T1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)"
      using finseq_1_def_9 sorry
    have A2: "lenFINSEQ-1K4 (<*FINSEQ-1K10 T1*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    have "<*FINSEQ-1K11 T1,T2 *> =FINSEQ-1R1 (<*FINSEQ-1K11 T1,T2 *>)^FINSEQ-1K8 {}XBOOLE-0K1"
      using finseq_1_th_34 sorry
    thus " for p be FinSequenceFINSEQ-1M1 holds  not (p inTARSKIR2 T2 &  not (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)) &  not ((<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2) &  not p inTARSKIR2 T2)"
      using A1 A2 trees_3_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_71:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds elementary-treeTREES-1K2 \<two>\<^sub>M c=TARSKIR1 treeTREES-3K13(T1,T2)"
proof(rule ballI,rule ballI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 elementary-treeTREES-1K2 \<two>\<^sub>M implies x inHIDDENR3 treeTREES-3K13(T1,T2)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 elementary-treeTREES-1K2 \<two>\<^sub>M"
    then obtain p where 
      [ty]:"p be ElementTREES-1M2-of elementary-treeTREES-1K2 \<two>\<^sub>M" and pDef:"p = x"
       sorry
    have "(p =FINSEQ-1R1 {}XBOOLE-0K1 or (p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> <*TREES-3K14 0NUMBERSK6 *> & {}XBOOLE-0K1 inTARSKIR2 T1) & (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*TREES-3K14 0NUMBERSK6 *>) or (p =RELSET-1R2\<^bsub>(NATNUMBERSK1,NATNUMBERSK1)\<^esub> <*TREES-3K14 \<one>\<^sub>M*> & {}XBOOLE-0K1 inTARSKIR2 T2) & (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*TREES-3K14 \<one>\<^sub>M*>"
      using enumset1_def_1 finseq_1_th_34 trees_1_th_22 trees_1_th_53 sorry
    thus "x inHIDDENR3 treeTREES-3K13(T1,T2)"
      using trees_3_th_68 sorry
  qed "sorry"
  thus "elementary-treeTREES-1K2 \<two>\<^sub>M c=TARSKIR1 treeTREES-3K13(T1,T2)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem trees_3_th_72:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds T1 c=TARSKIR1 W1 & T2 c=TARSKIR1 W2 implies treeTREES-3K13(T1,T2) c=TARSKIR1 treeTREES-3K13(W1,W2)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  fix W1 assume [ty]: "W1 be TreeTREES-1M1"
  fix W2 assume [ty]: "W2 be TreeTREES-1M1"
  assume A1: "T1 c=TARSKIR1 W1"
    and A2: "T2 c=TARSKIR1 W2"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 treeTREES-3K13(T1,T2) implies x inHIDDENR3 treeTREES-3K13(W1,W2)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 treeTREES-3K13(T1,T2)"
    then obtain p where 
      [ty]:"p be ElementTREES-1M2-of treeTREES-3K13(T1,T2)" and pDef:"p = x"
       sorry
    have "p =FINSEQ-1R1 {}XBOOLE-0K1 or ( ex q be FinSequenceFINSEQ-1M1 st q inTARSKIR2 T1 & p =FINSEQ-1R1 (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 q or q inTARSKIR2 T2 & p =FINSEQ-1R1 (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K8 q)"
      using trees_3_th_68 sorry
    thus "x inHIDDENR3 treeTREES-3K13(W1,W2)"
      using A1 A2 trees_3_th_68 sorry
  qed "sorry"
  thus "treeTREES-3K13(T1,T2) c=TARSKIR1 treeTREES-3K13(W1,W2)"
    using tarski_def_3 sorry
qed "sorry"

mtheorem trees_3_th_73:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds  for W1 be TreeTREES-1M1 holds  for W2 be TreeTREES-1M1 holds treeTREES-3K13(T1,T2) =TREES-2R1 treeTREES-3K13(W1,W2) implies T1 =TREES-2R1 W1 & T2 =TREES-2R1 W2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  fix W1 assume [ty]: "W1 be TreeTREES-1M1"
  fix W2 assume [ty]: "W2 be TreeTREES-1M1"
  assume A1: "treeTREES-3K13(T1,T2) =TREES-2R1 treeTREES-3K13(W1,W2)"
  have Cut2630: " for p be FinSequenceFINSEQ-1M1 holds p inTARSKIR2 T1 iff p inTARSKIR2 W1"
  proof(rule ballI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    have "p inTARSKIR2 T1 iff (<*TREES-3K14 0NUMBERSK6 *>)^FINSEQ-1K8 p inTARSKIR2 treeTREES-3K13(T1,T2)"
      using trees_3_th_69 sorry
    thus "p inTARSKIR2 T1 iff p inTARSKIR2 W1"
      using A1 trees_3_th_69 sorry
  qed "sorry"
  have "( for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T1 iff p inTARSKIR2 W1) & T2 =TREES-2R1 W2"
  proof(rule conjMI)
    show " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds p inTARSKIR2 T1 iff p inTARSKIR2 W1"
      using Cut2630 sorry
    have " for p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1 holds  not (p inTARSKIR2 T2 &  not p inTARSKIR2 W2) &  not (p inTARSKIR2 W2 &  not p inTARSKIR2 T2)"
    proof(rule ballI)
      fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      have "p inTARSKIR2 T2 iff (<*TREES-3K14 \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(NATNUMBERSK1)\<^esub> p inTARSKIR2 treeTREES-3K13(T1,T2)"
        using trees_3_th_70 sorry
      thus " not (p inTARSKIR2 T2 &  not p inTARSKIR2 W2) &  not (p inTARSKIR2 W2 &  not p inTARSKIR2 T2)"
        using A1 trees_3_th_70 sorry
    qed "sorry"
    thus "T2 =TREES-2R1 W2"
      using trees_2_def_1 sorry
  qed
  thus "T1 =TREES-2R1 W1 & T2 =TREES-2R1 W2"
    using trees_2_def_1 sorry
qed "sorry"

mtheorem trees_3_th_74:
" for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds (treeTREES-3K13(T1,T2)) |TREES-1K4 (<*TREES-3K14 0NUMBERSK6 *>) =TREES-2R1 T1 & (treeTREES-3K13(T1,T2)) |TREES-1K4 (<*TREES-3K14 \<one>\<^sub>M*>) =TREES-2R1 T2"
proof(rule ballI,rule ballI)
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  let ?p = "<*FINSEQ-1K11 T1,T2 *>"
  have A1: "lenFINSEQ-1K4 ?p =XBOOLE-0R4 \<two>\<^sub>M"
    using finseq_1_th_44 sorry
  have A2: "?p .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 T1"
    using finseq_1_th_44 sorry
  have A3: "?p .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 T2"
    using finseq_1_th_44 sorry
  have A4: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
     sorry
  have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
     sorry
  thus "(treeTREES-3K13(T1,T2)) |TREES-1K4 (<*TREES-3K14 0NUMBERSK6 *>) =TREES-2R1 T1 & (treeTREES-3K13(T1,T2)) |TREES-1K4 (<*TREES-3K14 \<one>\<^sub>M*>) =TREES-2R1 T2"
    using A1 A2 A3 A4 trees_3_th_49 sorry
qed "sorry"

mtheorem trees_3_th_75:
" for T be TreeTREES-1M1 holds  for T1 be TreeTREES-1M1 holds  for T2 be TreeTREES-1M1 holds (treeTREES-3K13(T1,T2))with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T) =TREES-2R1 treeTREES-3K13(T,T2) & (treeTREES-3K13(T1,T2))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T) =TREES-2R1 treeTREES-3K13(T1,T)"
proof(rule ballI,rule ballI,rule ballI)
  fix T assume [ty]: "T be TreeTREES-1M1"
  fix T1 assume [ty]: "T1 be TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be TreeTREES-1M1"
  have A1: "lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6"
     sorry
  have A2: "<*FINSEQ-1K10 T1*> =FINSEQ-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T1*>)"
    using finseq_1_th_34 sorry
  have A3: "<*FINSEQ-1K10 T*> =FINSEQ-1R1 {}XBOOLE-0K1 ^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)"
    using finseq_1_th_34 sorry
  have A4: "(<*FINSEQ-1K11 T1,T2 *>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*FINSEQ-1K11 T1,T2 *>"
    using finseq_1_th_34 sorry
  have A5: "(<*FINSEQ-1K11 T1,T *>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*FINSEQ-1K11 T1,T *>"
    using finseq_1_th_34 sorry
  have A6: "lenFINSEQ-1K4 (<*FINSEQ-1K10 T1*>) =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_40 sorry
  have A7: "<*FINSEQ-1K11 T1,T2 *> =FINSEQ-1R1 (<*FINSEQ-1K10 T1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)"
    using finseq_1_def_9 sorry
  have A8: "<*FINSEQ-1K11 T1,T *> =FINSEQ-1R1 (<*FINSEQ-1K10 T1*>)^FINSEQ-1K8 (<*FINSEQ-1K10 T*>)"
    using finseq_1_def_9 sorry
  have "<*FINSEQ-1K11 T,T2 *> =FINSEQ-1R1 (<*FINSEQ-1K10 T*>)^FINSEQ-1K8 (<*FINSEQ-1K10 T2*>)"
    using finseq_1_def_9 sorry
  thus "(treeTREES-3K13(T1,T2))with-replacementTREES-1K5(<*TREES-3K14 0NUMBERSK6 *>,T) =TREES-2R1 treeTREES-3K13(T,T2) & (treeTREES-3K13(T1,T2))with-replacementTREES-1K5(<*TREES-3K14 \<one>\<^sub>M*>,T) =TREES-2R1 treeTREES-3K13(T1,T)"
    using A1 A2 A3 A4 A5 A6 A7 A8 trees_3_th_57 sorry
qed "sorry"

mtheorem trees_3_th_76:
"treeTREES-3K13(elementary-treeTREES-1K2 (0NUMBERSK6),elementary-treeTREES-1K2 (0NUMBERSK6)) =TREES-2R1 elementary-treeTREES-1K2 \<two>\<^sub>M"
proof-
  have "treeTREES-3K13(elementary-treeTREES-1K2 (0NUMBERSK6),elementary-treeTREES-1K2 (0NUMBERSK6)) =HIDDENR1 elementary-treeTREES-1K2 \<two>\<^sub>M"
  proof-
    let ?T = "elementary-treeTREES-1K2 (0NUMBERSK6)"
    have "treeTREES-3K13(elementary-treeTREES-1K2 (0NUMBERSK6),elementary-treeTREES-1K2 (0NUMBERSK6)) =HIDDENR1 treeTREES-3K11 (\<two>\<^sub>M  |->FINSEQ-2K2 elementary-treeTREES-1K2 (0NUMBERSK6))"
      using finseq_2_th_61 sorry
    also have "... = elementary-treeTREES-1K2 \<two>\<^sub>M"
      using trees_3_th_54 sorry
    finally show "treeTREES-3K13(elementary-treeTREES-1K2 (0NUMBERSK6),elementary-treeTREES-1K2 (0NUMBERSK6)) =HIDDENR1 elementary-treeTREES-1K2 \<two>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

reserve w for "FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
mtheorem trees_3_th_77:
" for n be NatNAT-1M1 holds  for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds ( for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t <=XXREAL-0R1 n) implies heightTREES-1K6 (treeTREES-3K11 w) <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds ( for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t <=XXREAL-0R1 n) implies heightTREES-1K6 (treeTREES-3K11 w) <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix w assume [ty]: "w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
    assume A1: " for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t <=XXREAL-0R1 n"
    obtain p where
      [ty]:"p be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
      A2: "p inTARSKIR2 treeTREES-3K11 w"and A3: "lenFINSEQ-1K4 p =XBOOLE-0R4 heightTREES-1K6 (treeTREES-3K11 w)"
      using trees_1_def_12 sorry
    have A4: "p =FINSEQ-1R1 {}XBOOLE-0K1 & lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6 or ( ex n be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (n <XXREAL-0R3 lenFINSEQ-1K4 w & q inTARSKIR2 w .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)) & p =FINSEQ-1R1 (<*TREES-3K14 n*>)^FINSEQ-1K8 q)"
      using A2 trees_3_def_15 sorry
    have "( ex k be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (k <XXREAL-0R3 lenFINSEQ-1K4 w & q inTARSKIR2 w .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & p =FINSEQ-1R1 (<*TREES-3K14 k*>)^FINSEQ-1K8 q) implies heightTREES-1K6 (treeTREES-3K11 w) <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
    proof(rule impI)
      assume Given: " ex k be NatNAT-1M1 st  ex q be FinSequenceFINSEQ-1M1 st (k <XXREAL-0R3 lenFINSEQ-1K4 w & q inTARSKIR2 w .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & p =FINSEQ-1R1 (<*TREES-3K14 k*>)^FINSEQ-1K8 q"
      then obtain k q where
        [ty]:"k be NatNAT-1M1" "q be FinSequenceFINSEQ-1M1" and 
        A5: "k <XXREAL-0R3 lenFINSEQ-1K4 w"and A6: "q inTARSKIR2 w .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"and A7: "p =FINSEQ-1R1 (<*TREES-3K14 k*>)^FINSEQ-1K8 q"
         sorry
      have A8: "w .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngFUNCT-1K2 w"
        using A5 trees_3_lm_3 sorry
      have "rngFUNCT-1K2 w be constituted-FinTreesTREES-3V2"
        using trees_3_def_10 sorry
      then obtain t where 
        [ty]:"t be finiteFINSET-1V1\<bar>TreeTREES-1M1" and tDef:"t = w .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        using A8 sorry
      have 
        [ty]:"q be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
        using A7 finseq_1_th_36 sorry
      have A9: "lenFINSEQ-1K4 q <=XXREAL-0R1 heightTREES-1K6 t"
        using A6 trees_1_def_12 sorry
      have A10: "heightTREES-1K6 t <=XXREAL-0R1 n"
        using A1 A5 trees_3_lm_3 sorry
      have A11: "lenFINSEQ-1K4 (<*TREES-3K14 k*>) =XBOOLE-0R4 \<one>\<^sub>M"
        using finseq_1_th_40 sorry
      have A12: "lenFINSEQ-1K4 q <=XXREAL-0R1 n"
        using A9 A10 xxreal_0_th_2 sorry
      have "lenFINSEQ-1K4 p =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 q"
        using A7 A11 finseq_1_th_22 sorry
      thus "heightTREES-1K6 (treeTREES-3K11 w) <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using A3 A12 xreal_1_th_7 sorry
    qed
    thus "heightTREES-1K6 (treeTREES-3K11 w) <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_78:
" for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds  for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 (treeTREES-3K11 w) >XXREAL-0R4 heightTREES-1K6 t"
proof-
  have " for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds  for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w implies  not heightTREES-1K6 (treeTREES-3K11 w) >XXREAL-0R4 heightTREES-1K6 t"
  proof(rule ballI,rule ballI,rule impI)
    fix w assume [ty]: "w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
    fix t assume [ty]: "t be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    assume "t inTARSKIR2 rngFUNCT-1K2 w"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> w"and A2: "t =XBOOLE-0R4 w .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    have 
      [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A1 sorry
    have A3: "\<one>\<^sub>M <=XXREAL-0R1 x"
      using A1 finseq_3_th_25 sorry
    have A4: "lenFINSEQ-1K4 w >=XXREAL-0R2 x"
      using A1 finseq_3_th_25 sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A5: "x =XBOOLE-0R4 \<one>\<^sub>M +XCMPLX-0K2 n"
      using A3 nat_1_th_10 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A6: "n <XXREAL-0R3 lenFINSEQ-1K4 w"
      using A4 A5 nat_1_th_13 sorry
    have A7: "{}XBOOLE-0K1 inTARSKIR2 t"
      using trees_1_th_22 sorry
    have A8: "(<*TREES-3K14 n*>)^FINSEQ-1K8 {}XBOOLE-0K1 =FINSEQ-1R1 <*TREES-3K14 n*>"
      using finseq_1_th_34 sorry
    have A9: "t =TREES-2R1 (treeTREES-3K11 w) |TREES-1K4 (<*TREES-3K14 n*>)"
      using A2 A5 A6 trees_3_th_49 sorry
    have "<*TREES-3K14 n*> inTARSKIR2 treeTREES-3K11 w"
      using A2 A5 A6 A7 A8 trees_3_def_15 sorry
    thus " not heightTREES-1K6 (treeTREES-3K11 w) >XXREAL-0R4 heightTREES-1K6 t"
      using A9 trees_1_th_48 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_79:
" for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds  for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w & ( for t9 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t9 inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t9 <=XXREAL-0R1 heightTREES-1K6 t) implies heightTREES-1K6 (treeTREES-3K11 w) =XBOOLE-0R4 heightTREES-1K6 t +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1 holds  for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 w & ( for t9 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t9 inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t9 <=XXREAL-0R1 heightTREES-1K6 t) implies heightTREES-1K6 (treeTREES-3K11 w) =XBOOLE-0R4 heightTREES-1K6 t +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix w assume [ty]: "w be FinTree-yieldingTREES-3V5\<bar>FinSequenceFINSEQ-1M1"
    fix t assume [ty]: "t be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    assume A1: "t inTARSKIR2 rngFUNCT-1K2 w"
      and A2: " for t9 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t9 inTARSKIR2 rngFUNCT-1K2 w implies heightTREES-1K6 t9 <=XXREAL-0R1 heightTREES-1K6 t"
    have A3: "heightTREES-1K6 (treeTREES-3K11 w) >XXREAL-0R4 heightTREES-1K6 t"
      using A1 trees_3_th_78 sorry
    have A4: "heightTREES-1K6 (treeTREES-3K11 w) <=XXREAL-0R1 heightTREES-1K6 t +NAT-1K1 \<one>\<^sub>M"
      using A2 trees_3_th_77 sorry
    have "heightTREES-1K6 (treeTREES-3K11 w) >=XXREAL-0R2 heightTREES-1K6 t +NAT-1K1 \<one>\<^sub>M"
      using A3 nat_1_th_13 sorry
    thus "heightTREES-1K6 (treeTREES-3K11 w) =XBOOLE-0R4 heightTREES-1K6 t +NAT-1K1 \<one>\<^sub>M"
      using A4 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem trees_3_th_80:
" for T be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 (^TREES-3K12 T) =XBOOLE-0R4 heightTREES-1K6 T +NAT-1K1 \<one>\<^sub>M"
proof(rule ballI)
  fix T assume [ty]: "T be finiteFINSET-1V1\<bar>TreeTREES-1M1"
  let ?m = "heightTREES-1K6 T"
  have A1: "rngFUNCT-1K2 (<*FINSEQ-1K10 T*>) =XBOOLE-0R4 {TARSKIK1 T}"
    using finseq_1_th_38 sorry
  have A2: "T inTARSKIR2 {TARSKIK1 T}"
    using tarski_def_1 sorry
  have " for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K10 T*>) implies heightTREES-1K6 t <=XXREAL-0R1 ?m"
    using A1 tarski_def_1 sorry
  thus "heightTREES-1K6 (^TREES-3K12 T) =XBOOLE-0R4 heightTREES-1K6 T +NAT-1K1 \<one>\<^sub>M"
    using A1 A2 trees_3_th_79 sorry
qed "sorry"

mtheorem trees_3_th_81:
" for T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds  for T2 be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds heightTREES-1K6 (treeTREES-3K13(T1,T2)) =XBOOLE-0R4 maxXXREAL-0K5(heightTREES-1K6 T1,heightTREES-1K6 T2) +NAT-1K1 \<one>\<^sub>M"
proof(rule ballI,rule ballI)
  fix T1 assume [ty]: "T1 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
  fix T2 assume [ty]: "T2 be finiteFINSET-1V1\<bar>TreeTREES-1M1"
  let ?m = "maxXXREAL-0K5(heightTREES-1K6 T1,heightTREES-1K6 T2)"
  have A1: "rngFUNCT-1K2 (<*FINSEQ-1K11 T1,T2 *>) =XBOOLE-0R4 {TARSKIK2 T1,T2 }"
    using finseq_2_th_127 sorry
  have A2: "T1 inTARSKIR2 {TARSKIK2 T1,T2 }"
    using tarski_def_2 sorry
  have A3: "T2 inTARSKIR2 {TARSKIK2 T1,T2 }"
    using tarski_def_2 sorry
  have A4: "?m =HIDDENR1 heightTREES-1K6 T1 or ?m =HIDDENR1 heightTREES-1K6 T2"
    using xxreal_0_def_10 sorry
  have " for t be finiteFINSET-1V1\<bar>TreeTREES-1M1 holds t inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K11 T1,T2 *>) implies heightTREES-1K6 t <=XXREAL-0R1 maxXXREAL-0K5(heightTREES-1K6 T1,heightTREES-1K6 T2)"
  proof(rule ballI,rule impI)
    fix t assume [ty]: "t be finiteFINSET-1V1\<bar>TreeTREES-1M1"
    assume "t inTARSKIR2 rngFUNCT-1K2 (<*FINSEQ-1K11 T1,T2 *>)"
    then have "t =TREES-2R1 T1 or t =TREES-2R1 T2"
      using A1 tarski_def_2 sorry
    thus "heightTREES-1K6 t <=XXREAL-0R1 maxXXREAL-0K5(heightTREES-1K6 T1,heightTREES-1K6 T2)"
      using xxreal_0_th_25 sorry
  qed "sorry"
  thus "heightTREES-1K6 (treeTREES-3K13(T1,T2)) =XBOOLE-0R4 maxXXREAL-0K5(heightTREES-1K6 T1,heightTREES-1K6 T2) +NAT-1K1 \<one>\<^sub>M"
    using A1 A2 A3 A4 trees_3_th_79 sorry
qed "sorry"

(*begin*)
mtheorem trees_3_cl_54:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "t be ElementSUBSET-1M1-of FinTreesTREES-3K5 D"
"cluster domRELAT-1K1 t as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "domRELAT-1K1 t be finiteFINSET-1V1"
    using trees_3_def_8 sorry
qed "sorry"

mdef trees_3_def_18 ("rootsTREES-3K15  _ " [164]164 ) where
  mlet "p be FinSequenceFINSEQ-1M1"
"assume p be DTree-yieldingTREES-3V6 func rootsTREES-3K15 p \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))"
proof-
  (*existence*)
    show "p be DTree-yieldingTREES-3V6 implies ( ex it be FinSequenceFINSEQ-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1)))"
    proof(rule impI)
      assume Assume: "p be DTree-yieldingTREES-3V6"
      have A1: "p be DTree-yieldingTREES-3V6"
        using Assume sorry
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 Lamb1 & Lamb2 =HIDDENR1 T .FUNCT-1K1 {}XBOOLE-0K1"
      show " ex it be FinSequenceFINSEQ-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))"
      proof-
        have " ex tVar22 be FinSequenceFINSEQ-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> tVar22 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for T be DecoratedTreeTREES-2M4 holds  not (T =XBOOLE-0R4 p .FUNCT-1K1 i & tVar22 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))))"
        proof-
          have A2: "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
            using finseq_1_def_3 sorry
          have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ( ex x be objectHIDDENM1 st ?P(k,x))"
          proof-
            have " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ( ex tVar20 be objectHIDDENM1 st  ex tVar21 be DecoratedTreeTREES-2M4 st tVar21 =XBOOLE-0R4 p .FUNCT-1K1 k & tVar21 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 tVar21 .FUNCT-1K1 {}XBOOLE-0K1)"
            proof(rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume "k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              then have A4: "p .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 p"
                using A2 funct_1_def_3 sorry
              have "rngFUNCT-1K2 p be constituted-DTreesTREES-3V3"
                using A1 sorry
              then obtain T where 
                [ty]:"T be DecoratedTreeTREES-2M4" and TDef:"T = p .FUNCT-1K1 k"
                using A4 sorry
              show " ex tVar20 be objectHIDDENM1 st  ex tVar21 be DecoratedTreeTREES-2M4 st tVar21 =XBOOLE-0R4 p .FUNCT-1K1 k & tVar21 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 tVar21 .FUNCT-1K1 {}XBOOLE-0K1"
              proof(rule bexI[of _ "T .FUNCT-1K1 {}XBOOLE-0K1"])
                show " ex tVar21 be DecoratedTreeTREES-2M4 st tVar21 =XBOOLE-0R4 p .FUNCT-1K1 k & tVar21 .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 tVar21 .FUNCT-1K1 {}XBOOLE-0K1"
                proof(rule bexI[of _ "T"])
                  show "T =XBOOLE-0R4 p .FUNCT-1K1 k & T .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 T .FUNCT-1K1 {}XBOOLE-0K1"
                     sorry
                qed "sorry"
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain q where
            [ty]:"q be FinSequenceFINSEQ-1M1" and 
            A5: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) & ( for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ?P(k,q .FUNCT-1K1 k))"
            using finseq_1_sch_1 A3 sorry
          show " ex tVar22 be FinSequenceFINSEQ-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> tVar22 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for T be DecoratedTreeTREES-2M4 holds  not (T =XBOOLE-0R4 p .FUNCT-1K1 i & tVar22 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))))"
          proof(rule bexI[of _ "q"],rule conjMI)
            show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> q =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
              using A5 finseq_1_def_3 sorry
            show " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for T be DecoratedTreeTREES-2M4 holds  not (T =XBOOLE-0R4 p .FUNCT-1K1 i & q .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1)))"
              using A2 A5 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p be DTree-yieldingTREES-3V6 implies ( for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it1 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))) & (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it2 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p be DTree-yieldingTREES-3V6"
      have A1: "p be DTree-yieldingTREES-3V6"
        using Assume sorry
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 Lamb1 & Lamb2 =HIDDENR1 T .FUNCT-1K1 {}XBOOLE-0K1"
      show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it1 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))) & (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & it2 .FUNCT-1K1 i =XBOOLE-0R4 T .FUNCT-1K1 {}XBOOLE-0K1))) implies it1 =HIDDENR1 it2"
      proof-
        have " for x1 be FinSequenceFINSEQ-1M1 holds  for x2 be FinSequenceFINSEQ-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> x1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & (( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & x1 .FUNCT-1K1 i =HIDDENR1 T .FUNCT-1K1 {}XBOOLE-0K1)) & (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> x2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p & ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ( ex T be DecoratedTreeTREES-2M4 st T =XBOOLE-0R4 p .FUNCT-1K1 i & x2 .FUNCT-1K1 i =HIDDENR1 T .FUNCT-1K1 {}XBOOLE-0K1)))) implies x1 =HIDDENR1 x2"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix x1 assume [ty]: "x1 be FinSequenceFINSEQ-1M1"
          fix x2 assume [ty]: "x2 be FinSequenceFINSEQ-1M1"
          assume A6: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> x1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
            and A7: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ?P(i,x1 .FUNCT-1K1 i)"
            and A8: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> x2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
            and A9: " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies ?P(i,x2 .FUNCT-1K1 i)"
          have " for k be NatNAT-1M1 holds k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies x1 .FUNCT-1K1 k =XBOOLE-0R4 x2 .FUNCT-1K1 k"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A10: "k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
            then have A11: "?P(k,x1 .FUNCT-1K1 k)"
              using A7 sorry
            have "?P(k,x2 .FUNCT-1K1 k)"
              using A9 A10 sorry
            thus "x1 .FUNCT-1K1 k =XBOOLE-0R4 x2 .FUNCT-1K1 k"
              using A11 sorry
          qed "sorry"
          thus "x1 =HIDDENR1 x2"
            using A6 A8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

end
