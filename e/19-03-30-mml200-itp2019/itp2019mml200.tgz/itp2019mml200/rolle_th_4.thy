theory rolle_th_4
  imports "mml/rolle" "mml/arithm"
begin

ML {* derive_types := true *}

mtheorem rolle_th_4:
  " for x be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 t implies 
( for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) 
holds ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & 
f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & 
f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .[ implies 
( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t)))))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix t assume [ty]: "t be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 t"
    hence B1: "t <>HIDDENR2 0NUMBERSK6" using XXREAL_0R1_connectedness[of "0NUMBERSK6" t] by mty auto 
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have [ty]:"f be FunctionFUNCT-1M1"  using relset_1_cl_1[of "REALNUMBERSK2" "REALNUMBERSK2"] by mty auto  
    assume "([.RCOMP-1K1 x,x +XCMPLX-0K2 t .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x +XCMPLX-0K2 t .]) be continuousFCONT-1V1) & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["
    then obtain x0 where [ty]:"x0 be RealXREAL-0M1" and 
      A2: "x0 inHIDDENR3 ].RCOMP-1K2 x,x +XCMPLX-0K2 t .["and 
      A3: "diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 ((x +XCMPLX-0K2 t)-XCMPLX-0K6 x)"
      using A1 rolle_th_3[of x "x +XCMPLX-0K2 t" f,simplified] xreal_1_th_29[of t x] by mauto
    have "diffFDIFF-1K1(f,x0) =HIDDENR1 (f .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 t"
      using XCMPLX_0K2_commutativity[of t x]  xcmplx_1_th_26[of t x] using A3 by mty auto  
    obtain s where [ty]:"s be set" and 
      sDef:"s = (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t" using tarski_th_1 by auto
    have [ty]: "s is RealXREAL-0M1" using sDef by mty auto
    show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t)))"
    proof(rule bexI[of _ "s"],rule conjMI,rule conjMI)
      have "x0 inHIDDENR3 {r where r be RealXREAL-0M1 : x <XXREAL-0R3 r & r <XXREAL-0R3 x +XCMPLX-0K2 t }"
        using A2 rcomp_1_def_2[of x "x +XCMPLX-0K2  t" ] by mauto
      then have A4: " ex g be RealXREAL-0M1 st (g =HIDDENR1 x0 & x <XXREAL-0R3 g) & g <XXREAL-0R3 x +XCMPLX-0K2 t"
         using Fraenkel_A1_ex[of "RealXREAL-0M1" x0 "\<lambda> r. r" "\<lambda>r.\<not> r <=XXREAL-0R1  x  \<and> \<not>   x +XCMPLX-0K2  t  <=XXREAL-0R1  r"] xreal_0_sethood_1 by mauto
      then have "0NUMBERSK6 <XXREAL-0R3 x0 -XCMPLX-0K6 x"
        using xreal_1_th_50 XCMPLX_0K2_commutativity[of x t] by mauto 
      then have "(0NUMBERSK6)/XCMPLX-0K7 t <XXREAL-0R3 (x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t"
        using A1 xreal_1_th_74 by mauto
      thus "0NUMBERSK6 <XXREAL-0R3 s"  using sDef arithm_th_5[of t] by mty auto
      have "x0 -XCMPLX-0K6 x <XXREAL-0R3 t"
        using xreal_1_th_19[of t x x0,simplified] A4 XCMPLX_0K2_commutativity[of x t]  by mauto
      then have "(x0 -XCMPLX-0K6 x)/XCMPLX-0K7 t <XXREAL-0R3 t /XCMPLX-0K7 t"
        using A1 xreal_1_th_74[of "x0 -XCMPLX-0K6 x" t  t]  by mauto
      thus "s <XXREAL-0R3 \<one>\<^sub>M"
        using A1 xcmplx_1_th_60[of t,OF _ B1] sDef by mty auto
      have A5: "s *XCMPLX-0K3 t +XCMPLX-0K2 x =XBOOLE-0R4 (x0 -XCMPLX-0K6 x)+XCMPLX-0K2 x"
        using A1 xcmplx_1_th_87[of "x0 -XCMPLX-0K6 x" t] sDef B1 by mty auto
      have "f .FUNCT-1K1 x +XCMPLX-0K2  t *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))
            =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 (f .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f .FUNCT-1K1 x)"
        using B1 A3 xcmplx_1_th_87[of " f .FUNCT-1K1  ( x +XCMPLX-0K2  t )  -XCMPLX-0K6   f .FUNCT-1K1  x" t]
                    XCMPLX_0K3_commutativity[of t "diffFDIFF-1K1(f,x0)"] 
                    xcmplx_1_th_26[of t x] 
                    XCMPLX_0K2_commutativity[of t x] by mty auto
      thus "f .FUNCT-1K1 (x +XCMPLX-0K2 t) =XBOOLE-0R4 f .FUNCT-1K1 x +XCMPLX-0K2 
         t *XCMPLX-0K3 (diffFDIFF-1K1(f,x +XCMPLX-0K2 s *XCMPLX-0K3 t))"
        using A5 XCMPLX_0K2_commutativity[of "f .FUNCT-1K1 (x +XCMPLX-0K2 t) -XCMPLX-0K6 f .FUNCT-1K1 x"  "f .FUNCT-1K1 x"]
                 xcmplx_1_th_27[of "f .FUNCT-1K1 (x +XCMPLX-0K2 t)" "f .FUNCT-1K1 x"]
                 xcmplx_1_th_27[of x0 x] XCMPLX_0K2_commutativity[of "s *XCMPLX-0K3 t" x] by mty auto
    qed auto
  qed auto



abbreviation(input) HIDDENR3_s ("_ \<in> _"[50,50]50) where
  "x \<in> X \<equiv> x inHIDDENR3 X "    


abbreviation(input) PARTFUN1M1_s ("PartFunc of _ , _"[0,0]70) where
  "PartFunc of X , Y \<equiv> PartFuncPARTFUN1M1-of(X,Y) "    

abbreviation(input) RELAT_1M1_s ("Relation" 70) where
  "Relation \<equiv> RelationRELAT-1M1"    

abbreviation(input) XREAL_0M1_s ("Real" 70) where
  "Real \<equiv>RealXREAL-0M1"    

abbreviation(input) FCONT_1V1_s ("continuous" 70) where
  "continuous \<equiv> continuousFCONT-1V1"    

abbreviation(input) NUMBERSK2_s ("\<real>") where
  "\<real> \<equiv>REALNUMBERSK2"    

abbreviation(input) PARTFUN1K2_s (" _ |\<^bsub> _ \<^esub>" [200,0]200) where
  "f |\<^bsub> Z \<^esub> \<equiv> f |RELAT-1K8 Z"


abbreviation(input) RELAT_1K1_s ("dom _" [228]228) where
  "dom f \<equiv> domRELAT-1K1 f"

abbreviation(input) XCMPLX_0K2_s ("_ + _" [132,133]132) where
  "a + b \<equiv> a +XCMPLX-0K2 b"    

abbreviation(input) XCMPLX_0K6_s ("_ - _" [132,133]132) where
  "a - b \<equiv> a -XCMPLX-0K6 b"    

abbreviation(input) XCMPLX_0K3_s ("_ * _" [164,164]164) where
  "a * b \<equiv> a *XCMPLX-0K3 b"    

abbreviation(input) XCMPLX_0K7_s ("_ '/ _" [164,164]164) where
  "a / b \<equiv> a /XCMPLX-0K7 b"    


abbreviation(input) XXREAL_0R3_s ("_ < _" [50,50]50) where
  "a < b \<equiv> a <XXREAL-0R3 b"    

abbreviation(input) FUNCT_1K1_s ("_ . _" [200,200]200) where
  "a . b \<equiv> a .FUNCT-1K1 b"    

abbreviation(input) RCOMP_1K1_s("\<lbrakk> _ , _ \<rbrakk>" [0,0]164) where
  "\<lbrakk> g,s \<rbrakk> \<equiv> [.RCOMP-1K1 g,s .]"

abbreviation(input) RCOMP_1K2_s("\<lparr> _ , _ \<rparr>" [0,0]164) where
  "\<lparr> g,s \<rparr> \<equiv> ].RCOMP-1K2 g,s .["

abbreviation(input) FDIFF_1K1_s("diff'( _ , _ ')" [0,0]164) where
  "diff(f,X) \<equiv> diffFDIFF-1K1(f,X)"

abbreviation(input) FDIFF_1R2_s("_ is differentiable on _" [50,50]50) where
"f is differentiable on X ==  f is-differentiable-onFDIFF-1R2 X"

text_raw {*\DefineSnippet{rollelagrange}{*}
mtheorem Lagrange:
  "for x,t be Real st \<zero>\<^sub>M < t holds
    for f be PartFunc of \<real>,\<real>  st (\<lbrakk> x,x + t \<rbrakk> \<subseteq> dom f & f |\<^bsub> \<lbrakk> x,x + t \<rbrakk> \<^esub> be continuous) &
       f is differentiable on \<lparr>x,x+t \<rparr> holds
   ex s be Real st \<zero>\<^sub>M < s & (s < \<one>\<^sub>M & f.(x+t) = f .x + t * diff(f,x+s*t))"
proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
  fix x assume [ty]: "x be Real" fix t assume [ty]: "t be Real"
  assume A1: "\<zero>\<^sub>M < t"
  hence B1: "t <> \<zero>\<^sub>M" using XXREAL_0R1_connectedness[of "\<zero>\<^sub>M" t] by mty auto
  fix f assume [ty]: "f be PartFunc of \<real>,\<real>"
  have [ty]:"f be Relation" using relset_1_cl_1[of "\<real>" "\<real>"] by mty auto
  assume "(\<lbrakk> x,x+t \<rbrakk> \<subseteq> dom f & f|\<^bsub> \<lbrakk>x,x+t\<rbrakk>\<^esub> be continuous) & f is differentiable on \<lparr> x,x+t \<rparr>"
  then obtain x0 where [ty]:"x0 be Real" and
    A2: "x0 \<in> \<lparr>x,x+t\<rparr>" and A3: "diff(f,x0) = (f.(x+t) - f .x)/(x+t-x)" using A1 rolle_th_3[of x "x+t" f,simplified] xreal_1_th_29[of t x] by mauto
  obtain s where [ty]:"s be set" and sDef:"s = (x0-x)/ t" using tarski_th_1 by auto
  have [ty]:"s is Real" using sDef by mty auto
  show "ex s be Real st \<zero>\<^sub>M < s & (s < \<one>\<^sub>M & f.(x+t) = f .x + t * diff(f,x+s*t))"
  proof(rule bexI[of _ "s"],rule conjMI,rule conjMI)
    have "x0 \<in> {r where r be Real : x < r & r < x + t }" using A2 rcomp_1_def_2[of x "x+t" ] by mauto
    hence A4: "ex g be Real st (g = x0 & x < g) & g < x + t" using Fraenkel_A1_ex[of "Real" x0 "\<lambda>r .r" "\<lambda>r. x<r & r<x+t"] xreal_0_sethood_1 by mauto
    hence "\<zero>\<^sub>M < x0 - x" using xreal_1_th_50 XCMPLX_0K2_commutativity[of x t] by mauto
    hence "\<zero>\<^sub>M / t < (x0 - x)/t" using A1 xreal_1_th_74 by mauto
    thus "\<zero>\<^sub>M < s" using sDef arithm_th_5[of t] by mty auto
    have "x0 - x < t" using xreal_1_th_19[of t x x0,simplified] A4 XCMPLX_0K2_commutativity[of x t]  by mauto
    hence "(x0 - x)/ t < t / t" using A1 xreal_1_th_74[of "x0 - x" t  t]  by mauto
    thus "s < \<one>\<^sub>M" using A1 xcmplx_1_th_60[of t,OF _ B1] sDef by mty auto
    have A5: "s * t + x = x0 - x + x" using A1 xcmplx_1_th_87[of "x0 - x" t] sDef B1 by mty auto
    have "f .x + t * diff(f,x0) = f .x + (f.(x+t) - f .x)" using B1 A3 xcmplx_1_th_87[of " f.(x+t)-f .x" t] XCMPLX_0K3_commutativity[of t "diff(f,x0)"] xcmplx_1_th_26[of t x] XCMPLX_0K2_commutativity[of t x] by mty auto
    thus "f.(x + t) = f .x + t * diff(f,x+s*t)" using A5 XCMPLX_0K2_commutativity[of "f.(x+t) - f .x"  "f . x"] xcmplx_1_th_27[of "f . (x + t)" "f . x"] xcmplx_1_th_27[of x0 x] XCMPLX_0K2_commutativity[of "s * t" x] by mty auto
  qed auto
qed auto
text_raw {*}%EndSnippet*}

end
