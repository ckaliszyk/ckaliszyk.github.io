theory E_number
imports "../mml/ordinal1"
begin

(*ML {* derive_types := true *}*)
theorem nextNat: "n is NatORDINAL1M6 \<Longrightarrow> succORDINAL1K1(n) is NatORDINAL1M6"
proof-
  assume "n is NatORDINAL1M6"
  thus "succORDINAL1K1(n) is NatORDINAL1M6" using  ordinal1_cl_19[of n]
    ordinal1_cl_23[of n] tarski_th_1[of "succORDINAL1K1(n)"] by auto
qed


abbreviation Zero:: "Set" ("\<zero>\<^sub>M" 500)
  where "\<zero>\<^sub>M \<equiv> 0ORDINAL1K5"

definition One:: "Set" ("\<one>\<^sub>M" 500)
  where "\<one>\<^sub>M \<equiv> succORDINAL1K1 \<zero>\<^sub>M"

definition Two:: "Set" ("\<two>\<^sub>M" 500)
  where "\<two>\<^sub>M \<equiv> succORDINAL1K1 \<one>\<^sub>M"

definition Three:: "Set" ("\<three>\<^sub>M" 500)
  where "\<three>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<^sub>M"

definition Four:: "Set" ("\<four>\<^sub>M" 500)
  where "\<four>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<^sub>M"

definition Five:: "Set" ("\<five>\<^sub>M" 500)
  where "\<five>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<^sub>M"

definition Six:: "Set" ("\<six>\<^sub>M" 500)
  where "\<six>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<^sub>M"

definition Seven:: "Set" ("\<seven>\<^sub>M" 500)
  where "\<seven>\<^sub>M \<equiv> succORDINAL1K1 \<six>\<^sub>M"

definition Eight:: "Set" ("\<eight>\<^sub>M" 500)
  where "\<eight>\<^sub>M \<equiv> succORDINAL1K1 \<seven>\<^sub>M"

definition Nine:: "Set" ("\<nine>\<^sub>M" 500)
  where "\<nine>\<^sub>M \<equiv> succORDINAL1K1 \<eight>\<^sub>M"

definition OneZero:: "Set" ("\<one>\<zero>\<^sub>M" 500)
  where "\<one>\<zero>\<^sub>M \<equiv> succORDINAL1K1 \<nine>\<^sub>M"

definition OneOne:: "Set" ("\<one>\<one>\<^sub>M" 500)
  where "\<one>\<one>\<^sub>M \<equiv> succORDINAL1K1 \<one>\<zero>\<^sub>M"

definition OneTwo:: "Set" ("\<one>\<two>\<^sub>M" 500)
  where "\<one>\<two>\<^sub>M \<equiv> succORDINAL1K1 \<one>\<one>\<^sub>M"

definition OneThree:: "Set" ("\<one>\<three>\<^sub>M" 500)
  where "\<one>\<three>\<^sub>M \<equiv> succORDINAL1K1 \<one>\<two>\<^sub>M"

definition OneFour:: "Set" ("\<one>\<four>\<^sub>M" 500)
  where "\<one>\<four>\<^sub>M \<equiv> succORDINAL1K1 \<one>\<three>\<^sub>M"

definition OneFive:: "Set" ("\<one>\<five>\<^sub>M" 500)
  where "\<one>\<five>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<^sub>M"

definition OneSix:: "Set" ("\<one>\<six>\<^sub>M" 500)
  where "\<one>\<six>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<^sub>M"

definition OneSeven:: "Set" ("\<one>\<seven>\<^sub>M" 500)
  where "\<one>\<seven>\<^sub>M \<equiv> succORDINAL1K1 \<six>\<^sub>M"

definition OneEight:: "Set" ("\<one>\<eight>\<^sub>M" 500)
  where "\<one>\<eight>\<^sub>M \<equiv> succORDINAL1K1 \<seven>\<^sub>M"

definition OneNine:: "Set" ("\<one>\<nine>\<^sub>M" 500)
  where "\<one>\<nine>\<^sub>M \<equiv> succORDINAL1K1 \<eight>\<^sub>M"

definition TwoZero:: "Set" ("\<two>\<zero>\<^sub>M" 500)
  where "\<two>\<zero>\<^sub>M \<equiv> succORDINAL1K1 \<one>\<nine>\<^sub>M"

definition TwoOne:: "Set" ("\<two>\<one>\<^sub>M" 500)
  where "\<two>\<one>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<zero>\<^sub>M"

definition TwoTwo:: "Set" ("\<two>\<two>\<^sub>M" 500)
  where "\<two>\<two>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<one>\<^sub>M"

definition TwoThree:: "Set" ("\<two>\<three>\<^sub>M" 500)
  where "\<two>\<three>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<two>\<^sub>M"

definition TwoFour:: "Set" ("\<two>\<four>\<^sub>M" 500)
  where "\<two>\<four>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<three>\<^sub>M"

definition TwoFive:: "Set" ("\<two>\<five>\<^sub>M" 500)
  where "\<two>\<five>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<four>\<^sub>M"

definition TwoSix:: "Set" ("\<two>\<six>\<^sub>M" 500)
  where "\<two>\<six>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<five>\<^sub>M"

definition TwoSeven:: "Set" ("\<two>\<seven>\<^sub>M" 500)
  where "\<two>\<seven>\<^sub>M \<equiv> succORDINAL1K1 \<six>\<^sub>M"

definition TwoEight:: "Set" ("\<two>\<eight>\<^sub>M" 500)
  where "\<two>\<eight>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<seven>\<^sub>M"

definition TwoNine:: "Set" ("\<two>\<nine>\<^sub>M" 500)
  where "\<two>\<nine>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<eight>\<^sub>M"

definition ThreeZero:: "Set" ("\<three>\<zero>\<^sub>M" 500)
  where "\<three>\<zero>\<^sub>M \<equiv> succORDINAL1K1 \<two>\<nine>\<^sub>M"

definition ThreeOne:: "Set" ("\<three>\<one>\<^sub>M" 500)
  where "\<three>\<one>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<zero>\<^sub>M"

definition ThreeTwo:: "Set" ("\<three>\<two>\<^sub>M" 500)
  where "\<three>\<two>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<one>\<^sub>M"

definition ThreeThree:: "Set" ("\<three>\<three>\<^sub>M" 500)
  where "\<three>\<three>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<two>\<^sub>M"

definition ThreeFour:: "Set" ("\<three>\<four>\<^sub>M" 500)
  where "\<three>\<four>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<three>\<^sub>M"

definition ThreeFive:: "Set" ("\<three>\<five>\<^sub>M" 500)
  where "\<three>\<five>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<four>\<^sub>M"

definition ThreeSix:: "Set" ("\<three>\<six>\<^sub>M" 500)
  where "\<three>\<six>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<five>\<^sub>M"

definition ThreeSeven:: "Set" ("\<three>\<seven>\<^sub>M" 500)
  where "\<three>\<seven>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<six>\<^sub>M"

definition ThreeEight:: "Set" ("\<three>\<eight>\<^sub>M" 500)
  where "\<three>\<eight>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<seven>\<^sub>M"

definition ThreeNine:: "Set" ("\<three>\<nine>\<^sub>M" 500)
  where "\<three>\<nine>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<eight>\<^sub>M"

definition FourZero:: "Set" ("\<four>\<zero>\<^sub>M" 500)
  where "\<four>\<zero>\<^sub>M \<equiv> succORDINAL1K1 \<three>\<nine>\<^sub>M"

definition FourOne:: "Set" ("\<four>\<one>\<^sub>M" 500)
  where "\<four>\<one>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<zero>\<^sub>M"

definition FourTwo:: "Set" ("\<four>\<two>\<^sub>M" 500)
  where "\<four>\<two>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<one>\<^sub>M"

definition FourThree:: "Set" ("\<four>\<three>\<^sub>M" 500)
  where "\<four>\<three>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<two>\<^sub>M"

definition FourFour:: "Set" ("\<four>\<four>\<^sub>M" 500)
  where "\<four>\<four>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<three>\<^sub>M"

definition FourFive:: "Set" ("\<four>\<five>\<^sub>M" 500)
  where "\<four>\<five>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<four>\<^sub>M"

definition FourSix:: "Set" ("\<four>\<six>\<^sub>M" 500)
  where "\<four>\<six>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<five>\<^sub>M"

definition FourSeven:: "Set" ("\<four>\<seven>\<^sub>M" 500)
  where "\<four>\<seven>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<six>\<^sub>M"

definition FourEight:: "Set" ("\<four>\<eight>\<^sub>M" 500)
  where "\<four>\<eight>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<seven>\<^sub>M"

definition FourNine:: "Set" ("\<four>\<nine>\<^sub>M" 500)
  where "\<four>\<nine>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<eight>\<^sub>M"

definition FiveZero:: "Set" ("\<five>\<zero>\<^sub>M" 500)
  where "\<five>\<zero>\<^sub>M \<equiv> succORDINAL1K1 \<four>\<nine>\<^sub>M"

definition FiveOne:: "Set" ("\<five>\<one>\<^sub>M" 500)
  where "\<five>\<one>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<zero>\<^sub>M"

definition FiveTwo:: "Set" ("\<five>\<two>\<^sub>M" 500)
  where "\<five>\<two>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<one>\<^sub>M"

definition FiveThree:: "Set" ("\<five>\<three>\<^sub>M" 500)
  where "\<five>\<three>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<two>\<^sub>M"

definition FiveFour:: "Set" ("\<five>\<four>\<^sub>M" 500)
  where "\<five>\<four>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<three>\<^sub>M"

definition FiveFive:: "Set" ("\<five>\<five>\<^sub>M" 500)
  where "\<five>\<five>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<four>\<^sub>M"

definition FiveSix:: "Set" ("\<five>\<six>\<^sub>M" 500)
  where "\<five>\<six>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<five>\<^sub>M"

definition FiveSeven:: "Set" ("\<five>\<seven>\<^sub>M" 500)
  where "\<five>\<seven>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<six>\<^sub>M"

definition FiveEight:: "Set" ("\<five>\<eight>\<^sub>M" 500)
  where "\<five>\<eight>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<seven>\<^sub>M"

definition FiveNine:: "Set" ("\<five>\<nine>\<^sub>M" 500)
  where "\<five>\<nine>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<eight>\<^sub>M"

definition SixZero:: "Set" ("\<six>\<zero>\<^sub>M" 500)
  where "\<six>\<zero>\<^sub>M \<equiv> succORDINAL1K1 \<five>\<nine>\<^sub>M"

definition SixOne:: "Set" ("\<six>\<one>\<^sub>M" 500)
  where "\<six>\<one>\<^sub>M \<equiv> succORDINAL1K1 \<six>\<zero>\<^sub>M"

definition SixTwo:: "Set" ("\<six>\<two>\<^sub>M" 500)
  where "\<six>\<two>\<^sub>M \<equiv> succORDINAL1K1 \<six>\<one>\<^sub>M"

definition SixThree:: "Set" ("\<six>\<three>\<^sub>M" 500)
  where "\<six>\<three>\<^sub>M \<equiv> succORDINAL1K1 \<six>\<two>\<^sub>M"

definition SixFour:: "Set" ("\<six>\<four>\<^sub>M" 500)
  where "\<six>\<four>\<^sub>M \<equiv> succORDINAL1K1 \<six>\<three>\<^sub>M"












consts
N71::"Set" ("\<seven>\<one>\<^sub>M" 500)
N81 ::"Set" ("\<eight>\<one>\<^sub>M" 500)
N83::"Set" ("\<eight>\<three>\<^sub>M" 500)
N84::"Set" ("\<eight>\<four>\<^sub>M" 500)
N96::"Set" ("\<nine>\<six>\<^sub>M" 500)
N97::"Set" ("\<nine>\<seven>\<^sub>M" 500)
N100::"Set" ("\<one>\<zero>\<zero>\<^sub>M" 500)
N111::"Set" ("\<one>\<one>\<one>\<^sub>M" 500)
N112::"Set" ("\<one>\<one>\<two>\<^sub>M" 500)
N120::"Set" ("\<one>\<two>\<zero>\<^sub>M" 500)
N123::"Set" ("\<one>\<two>\<three>\<^sub>M" 500)
N128:: "Set"  ("\<one>\<two>\<eight>\<^sub>M" 500)
N136:: "Set" ("\<one>\<three>\<six>\<^sub>M" 500)
N159::"Set" ("\<one>\<five>\<nine>\<^sub>M" 500)
N164::"Set" ("\<one>\<six>\<four>\<^sub>M" 500)
N172:: "Set" ("\<one>\<seven>\<two>\<^sub>M" 500)
N192::"Set" ("\<one>\<nine>\<two>\<^sub>M" 500)
N197::"Set" ("\<one>\<nine>\<seven>\<^sub>M" 500)
N225::"Set" ("\<two>\<two>\<five>\<^sub>M" 500)
N241::"Set" ("\<two>\<four>\<one>\<^sub>M" 500)
N249::"Set" ("\<two>\<four>\<nine>\<^sub>M" 500)
N255::"Set" ("\<two>\<five>\<five>\<^sub>M" 500)
N256::"Set" ("\<two>\<five>\<six>\<^sub>M" 500)
N257::"Set" ("\<two>\<five>\<seven>\<^sub>M" 500)
N263::"Set" ("\<two>\<six>\<three>\<^sub>M" 500)
N282::"Set" ("\<two>\<eight>\<two>\<^sub>M" 500)
N289::"Set" ("\<two>\<eight>\<nine>\<^sub>M" 500)
M315::"Set" ("\<three>\<one>\<five>\<^sub>M" 500)
N325::"Set" ("\<three>\<two>\<five>\<^sub>M" 500)
N332::"Set" ("\<three>\<three>\<two>\<^sub>M" 500)
N386:: "Set" ("\<three>\<eight>\<six>\<^sub>M" 500)
N400::"Set" ("\<four>\<zero>\<zero>\<^sub>M" 500)

N503::"Set" ("\<five>\<zero>\<three>\<^sub>M" 500)
N512::"Set" ("\<five>\<one>\<two>\<^sub>M" 500)
N656::"Set" ("\<six>\<five>\<six>\<^sub>M" 500)
N673::"Set" ("\<six>\<seven>\<three>\<^sub>M" 500)
N809::"Set" ("\<eight>\<zero>\<nine>\<^sub>M" 500)
N1000::"Set" ("\<one>\<zero>\<zero>\<zero>\<^sub>M" 500)
N1024::"Set" ("\<one>\<zero>\<two>\<four>\<^sub>M" 500)
N1031::"Set"("\<one>\<zero>\<three>\<one>\<^sub>M" 500)
N1367::"Set" ("\<one>\<three>\<six>\<seven>\<^sub>M" 500)
N1536::"Set" ("\<one>\<five>\<three>\<six>\<^sub>M" 500)
N2048::"Set"("\<two>\<zero>\<four>\<eight>\<^sub>M" 500)
N2985::"Set"("\<two>\<nine>\<eight>\<five>\<^sub>M" 500)
M3125::"Set" ("\<three>\<one>\<two>\<five>\<^sub>M" 500)
N3446::"Set" ("\<three>\<four>\<four>\<six>\<^sub>M" 500)
N4096::"Set" ("\<four>\<zero>\<nine>\<six>\<^sub>M" 500)
N5589::"Set" ("\<five>\<five>\<eight>\<nine>\<^sub>M" 500)
N6560::"Set" ("\<six>\<five>\<six>\<zero>\<^sub>M" 500)
N6561::"Set" ("\<six>\<five>\<six>\<one>\<^sub>M" 500)
N6562::"Set" ("\<six>\<five>\<six>\<two>\<^sub>M" 500)
N7200::"Set" ("\<seven>\<two>\<zero>\<zero>\<^sub>M" 500)
N8192::"Set" ("\<eight>\<one>\<nine>\<two>\<^sub>M" 500)
N13122::"Set" ("\<one>\<three>\<one>\<two>\<two>\<^sub>M" 500)
N14175::"Set" ("\<one>\<four>\<one>\<seven>\<five>\<^sub>M" 500)
N18496::"Set" ("\<one>\<eight>\<four>\<nine>\<six>\<^sub>M" 500)








theorem ZeroM[simp]:"\<zero>\<^sub>M is NatORDINAL1M6"  using ordinal1_def_13_ty ordinal1_cl_26 by auto
theorem OneM[simp]  :"\<one>\<^sub>M is NatORDINAL1M6" unfolding One_def using nextNat[of "\<zero>\<^sub>M"] ZeroM by auto
theorem TwoM[simp]  :"\<two>\<^sub>M is NatORDINAL1M6" unfolding Two_def using nextNat[of "\<one>\<^sub>M"] OneM by auto
theorem ThreeM[simp]:"\<three>\<^sub>M is NatORDINAL1M6" unfolding Three_def using nextNat[of "\<two>\<^sub>M"] TwoM by auto
theorem FourM[simp] :"\<four>\<^sub>M is NatORDINAL1M6" unfolding Four_def using nextNat[of "\<three>\<^sub>M"] ThreeM by auto
theorem FiveM[simp] :"\<five>\<^sub>M is NatORDINAL1M6" unfolding Five_def using nextNat[of "\<four>\<^sub>M"] FourM by auto
theorem SixM[simp]  :"\<six>\<^sub>M is NatORDINAL1M6" unfolding Six_def using nextNat[of "\<five>\<^sub>M"] FiveM by auto
theorem SevenM[simp]:"\<seven>\<^sub>M is NatORDINAL1M6" unfolding Seven_def using nextNat[of "\<six>\<^sub>M"] SixM by auto
theorem EightM[simp]:"\<eight>\<^sub>M is NatORDINAL1M6" unfolding Eight_def using nextNat[of "\<seven>\<^sub>M"] SevenM by auto
theorem NineM[simp] :"\<nine>\<^sub>M is NatORDINAL1M6" unfolding Nine_def using nextNat[of "\<eight>\<^sub>M"] EightM by auto
theorem TenM[simp]  :"\<one>\<zero>\<^sub>M is NatORDINAL1M6" unfolding OneZero_def using nextNat[of "\<nine>\<^sub>M"] NineM by auto

(*ML {* derive_types := false *}*)

end