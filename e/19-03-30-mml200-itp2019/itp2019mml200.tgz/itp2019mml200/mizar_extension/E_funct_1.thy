
theory E_funct_1
imports E_relat_1
begin

text_raw {*\DefineSnippet{funct_1def1}{*}
mdef E_funct_1_def_1 ("Function'_like") where
  "attr Function_like for set means
     (\<lambda>IT. for x,y1,y2 being object st
          [x,y1] in IT \<and> [x,y2] in IT holds y1 = y2)"..
text_raw {*}%EndSnippet*} 
  
  
(*mtheorem funct_1_cl_1:
  "cluster empty \<rightarrow> Function_like for set" 
using xboole_0_def_1 funct_1_def_1 by mauto
*)
  
  
  
mtheorem E_funct_1_cl_3:
  mlet "a be object","b be object"
  "cluster {[a,b]} as-term-is Function_like"
proof
  let ?F = "{[a,b]}"
  have "for x,y1,y2 being object st [x,y1] in ?F \<and> [x,y2] in ?F holds y1 = y2"
     proof(intro ballI impI)
       fix x y1 y2
       assume "[x , y1] in ?F \<and> [x , y2] in ?F"
       hence "[x,y1] = [a,b]" "[x,y2] =[a,b]" using tarski_def_1 by auto
       thus "y1=y2" using E_xtuple_0_th_1[of x y1]  E_xtuple_0_th_1[of x y2] by auto
     qed simp_all
  thus "?F is Function_like" using E_funct_1_def_1I by mauto
qed


  
abbreviation funct_1_M_1("Function") where
  "Function \<equiv> Function_like \<bar>Relation"

(* ! ! *)     

mtheorem E_funct_1_cl:
  mlet "X be set"," F be Function"
  "cluster F | X as-term-is Function_like"
proof
  have "for x,y1,y2 being object st [x,y1] in F|X \<and> [x,y2] in F|X holds y1 = y2"
  proof(intro ballI impI)
       fix x y1 y2
       assume T0: "x be object" "y1 be object " "y2 be object"
       assume "[x,y1] in F|X \<and> [x,y2] in F|X"
       hence A2: "[x,y1] in F \<and> [x,y2] in F" using E_relat_1_def_11[of F X] by simp
       have A4: "for x,y1,y2 be object holds ([x,y1] in F \<and> [x,y2] in F \<longrightarrow> y1=y2)" using E_funct_1_def_1[of F] by auto
       thus "y1=y2" using A2 by auto
  qed mauto
  thus "F | X is Function_like" using E_funct_1_def_1 by mauto
qed
  
mdef  E_funct_1_def_2 (infix "." 110) where
  mlet "f be Function", "x be object"
  "func f . x \<rightarrow> object means
     \<lambda>it. [x,it] in f if x in dom f otherwise \<lambda>it. it = {}"
proof
  show "(x in proj1 f \<longrightarrow> (\<exists>xa : object. [x , xa] in f)) \<and> (\<not> x in proj1 f \<longrightarrow> (\<exists>x : object. x = {}))"
  proof(intro conjI impI)
    assume "x in dom(f)"
      then obtain y where
A1:       "y be object \<and> [x,y] in f" using E_xtuple_0_def_12 by auto
      thus "ex y being object st [x,y] in f" using A1 E_all_set by auto
    next 
      show "(\<not> x in proj1 f \<Longrightarrow> (\<exists>x : object. x = {}))" by auto
    qed 
   show "for xa,y be object holds
            (x in dom f \<longrightarrow>( [x , xa] in f \<and> [x , y] in f \<longrightarrow> xa = y)) \<and> (\<not> x in dom f \<longrightarrow>( xa = {} \<and> y = {} \<longrightarrow> xa = y))"
     using E_funct_1_def_1E[of f] by auto  
 qed auto

reserve f for Function
    
mtheorem E_funct_1_th_1: "[x,y] in f \<longleftrightarrow> x in dom f \<and> y = f . x"
proof(intro conjI iffI)
  assume A1: "[x,y] in f"
  thus A2: "x in dom f" using E_xtuple_0_def_12 by auto
  hence "[x , f . x] in f" using A2 E_funct_1_def_2 by auto
  thus "y = f . x" using A1 E_funct_1_def_1E by mby auto
 next
  assume "x in dom f \<and> y = f . x"
  then show "[x , y] in f" using E_funct_1_def_2 by auto
qed

end

