theory E_relat_1
imports E_zfmisc_1
begin

reserve x for object

mdef E_relat_1_def_1 ("Relation'_like")where
  "attr Relation_like for set means (\<lambda>IT. \<forall>x.  x in IT \<longrightarrow> (ex y, z st x = [y, z]))"..

mtheorem E_relat_1_cl_1:
  "cluster empty also-is Relation_like for set" 
  using E_relat_1_def_1 E_xboole_0_def_1 by auto
    
mtheorem E_relat_1_cl_0:
  "cluster Relation_like for set"
proof
  show "ex X be set st X is Relation_like" using bexI[of _"{}"] by mty auto
qed mauto

abbreviation relat_1_M_1 ("Relation") where  "Relation \<equiv> Relation_like\<bar> set"

reserve R,P for Relation

mtheorem E_relat_1_cl_5:
   mlet "P be Relation", "R be Relation"
  "cluster P \<union> R as-term-is Relation_like"
proof
  have A0: "\<forall>x.  x in P \<longrightarrow> (ex y, z st x = [y, z])" using E_relat_1_def_1 by mauto
  have "\<forall>x.  x in R \<longrightarrow> (ex y, z st x = [y, z])" using E_relat_1_def_1 by mauto
  hence "\<forall>x.  x in P\<union>R \<longrightarrow> (ex y, z st x = [y, z])" using A0 E_xboole_0_def_3 by auto
  thus "(P \<union> R) is Relation_like" using E_relat_1_def_1 by mauto
qed
  

mtheorem E_relat_1_cl_7:
   mlet "a be object", "b be object"
   "cluster {[a,b]} as-term-is Relation_like"
proof
   show "{[a,b]} is Relation_like" using E_relat_1_def_1 tarski_def_1 by auto
qed

abbreviation(input) relat_1_syn_1("dom _" [105] 105) where
  "dom R \<equiv> proj1 R"

abbreviation(input) relat_1_syn_2("rng _" [105] 105) where
  "rng R \<equiv> proj2 R"

mtheorem E_relat_1_th_3:
  "R = {[x,y]} \<longrightarrow> dom R = {x} \<and> rng R = {y}"
proof(intro impI, rule conjI)
  assume A1: "R = {[x,y]}"
  have "for z being object holds z in dom R \<longleftrightarrow> z in {x}"
  proof (rule ballI,rule iffI3)
     fix z
     assume "z be object"
     show "z in dom R \<longrightarrow> z in {x}"
       proof
         assume "z in dom R"
         then obtain b where
            [ty]: "b be object" and A2: "[z,b] in R" using E_xtuple_0_def_12 by auto
          have "[z,b] = [x,y]" using A1 A2 tarski_def_1 by simp
          hence "z=x" using E_xtuple_0_th_1[of z b] by simp
          thus "z in {x}" using tarski_def_1 by simp
       qed
     assume "z in {x}"
     hence "z=x" using tarski_def_1 by simp
     hence "[z,y] in R" using A1 tarski_def_1 by simp
     thus "z in dom R" using E_xtuple_0_def_12 by auto
  qed simp_all
  thus "dom R = {x}" by (intro tarski_th_2) auto
  have "for z being object holds z in rng R \<longleftrightarrow> z in {y}"
  proof (rule ballI,rule iffI3)
     fix z
     assume [ty]: "z be object"
     show "z in rng R \<longrightarrow> z in {y}"
       proof
         assume "z in rng R"
         then obtain b where
            T1: "b be object" and A2: "[b,z] in R" using E_xtuple_0_def_13 by auto
          have "[b,z] = [x,y]" using A1 A2 tarski_def_1 by simp
          hence "z=y" using E_xtuple_0_th_1[of b z] by simp
          thus "z in {y}" using tarski_def_1 by simp
       qed
     assume "z in {y}"
     hence "z=y" using tarski_def_1 by simp
     hence "[x,z] in R" using A1 tarski_def_1 by simp
     thus "z in rng R" using E_xtuple_0_def_13 by auto
  qed simp_all
  thus "rng R = {y}" by (intro tarski_th_2) auto
 qed

theorem E_relat_1_sch_1:
   "A be set \<Longrightarrow> B be set
       \<Longrightarrow> ex R being Relation st (for x,y holds
  [x,y] in R \<longleftrightarrow> (x in A \<and> y in B \<and> P (x,y) ))"
proof-
   assume [ty]:"A be set" "B be set"
   let ?Q = "\<lambda> it.  ex x,y st it=[x,y] \<and> P (x,y)"
   have T2: "[:A,B:] be set" by mauto
   obtain X where
     T1:"X be set" and
A1: "for p being object holds p in X \<longleftrightarrow> p in [:A , B:] \<and> ?Q(p)"
   using E_xboole_0_sch_1[OF T2, of ?Q] by auto
   show "ex R being Relation st (for x,y holds
           [x,y] in R \<longleftrightarrow> (x in A \<and> y in B \<and> P (x,y) ))"
   proof (intro bexI[of _ X] ballI)
       have "for p being object st p in X ex x,y st p=[x,y]"
      proof(intro ballI impI)
         fix p assume "p be object"
         assume "p in X"
        hence "ex x,y st p=[x,y] \<and> P (x,y)" using A1 by simp
        thus "ex x,y st p=[x,y]" by auto
      qed simp
      thus A2: "X be Relation" using T1 E_relat_1_def_1 by auto
      fix x y
      assume "x be object" "y be object"
      show "[x,y] in X \<longleftrightarrow> (x in A \<and> y in B \<and> P (x,y))"
          proof (intro iffI2)
             show "[x,y] in X \<longrightarrow> x in A \<and> y in B \<and> P (x, y)"
                proof
                   assume A3: "[x,y] in X"
                    then obtain xx yy where
                     "xx be object" "yy be object"
                   and A4: "[x,y]=[xx,yy]" and
                       A5: "P (xx,yy)" using A1 by auto
                   have A6: "[x,y] in [:A,B:]" using A1 A3 by auto
                   have "x=xx \<and> y=yy" using A4 E_xtuple_0_th_1a by auto
                   thus "x in A \<and> y in B \<and> P (x,y)"
                      using A5 A6 zfmisc_1_th_87 by auto
                qed
             show "x in A \<and> y in B \<and> P (x,y)  \<longrightarrow> [x,y] in X"
               proof (intro impI, elim conjE)
                 assume
                   A7: "x in A" "y in B" and A8: "P(x,y)"
                 have "[x,y] in [:A,B:]" using A7 zfmisc_1_th_87 by auto
                 thus "[x,y] in X" using A1 A8 by auto
               qed
   qed
   qed simp_all
qed

mtheorem E_relat_1_def_2:
  mlet "P be Relation", "R be Relation"
   "redefine pred P = R means for a,b being object holds [a,b] in P \<longleftrightarrow> [a,b] in R"
proof
  show "P = R \<longleftrightarrow> (for a,b being object holds ([a,b] in P \<longleftrightarrow> [a,b] in R))"
     proof (intro iffI2)
        show "P = R \<longrightarrow> (for a,b being object holds ([a,b] in P \<longleftrightarrow> [a,b] in R))" by auto
        show "(for a,b being object holds ([a,b] in P \<longleftrightarrow> [a,b] in R)) \<longrightarrow> P=R"
             proof
                assume A1: "for a,b being object holds ([a,b] in P \<longleftrightarrow> [a,b] in R)"
                have T2: "P be set" "R be set" by simp_all
                show "P = R"
                  proof (unfold E_xboole_0_def_10[OF T2], intro conjI)
                      show "P c= R"
                      proof (standard,auto)
                            fix x
                            assume A2: "x in P"
                            hence "ex y,z being object st x = [y,z]" using E_relat_1_def_1 by mby simp
                            thus "x in R" using A1 A2 by auto
                        qed
                       show "R c= P"
                        proof (standard,auto)
                            fix x
                            assume A2: "x in R"
                            hence "ex y,z being object st x = [y,z]" using E_relat_1_def_1 by mby simp
                            thus "x in P" using A1 A2 by auto
                        qed
                qed
            qed
     qed
qed  
  
mdef E_relat_1_def_11:: "Set \<Rightarrow> Set \<Rightarrow> Set" (infix "|" 190) where
mlet "R be Relation", "X be set"
     "func (R | X) \<rightarrow> Relation means \<lambda>it.(for x being object,y being object holds ([x,y] in it \<longleftrightarrow> (x in X \<and> [x,y] in R)))"
proof-
      let ?Z = "\<lambda> x y.(x in X \<and> [x,y] in R)"
      obtain S where
        [ty]: "S be Relation" and
        A2: "for x,y holds [x,y] in S \<longleftrightarrow> x in dom R \<and> y in rng R \<and> ?Z (x,y)"
         using E_relat_1_sch_1[of "dom R" "rng R" "?Z"] by mauto
       show "ex S being Relation st
            for x,y holds ([x,y] in S \<longleftrightarrow> (x in X \<and> [x,y] in R))"
       proof (intro bexI[of _ "S"])
         show "for x,y holds ([x,y] in S \<longleftrightarrow> (x in X \<and> [x,y] in R))"
           proof(intro ballI)
              fix x y
              have "[x , y] in R \<Longrightarrow> x in dom R" "[x,y] in R \<Longrightarrow> y in rng R" using E_xtuple_0_def_12 E_xtuple_0_def_13 by mauto
              hence "[x,y] in R \<and> x in X \<Longrightarrow> [x,y] in S" using A2 by auto
              thus "[x , y] in S \<longleftrightarrow> x in X \<and> [x , y] in R" using A2 by auto
           qed simp_all
       qed simp_all
     next
              show "for P1,P2 be Relation st 
          (for x,y holds [x,y] in P1 \<longleftrightarrow> x in X \<and> [x,y] in R)&(for x,y holds [x,y] in P2 \<longleftrightarrow> x in X \<and> [x,y] in R)
             holds P1=P2"
         proof(rule ballI,rule ballI,rule impMI,rule impI)
      fix P1 P2
      assume [ty]:"P1 be Relation " " P2 be Relation" and
             A2: "for x,y holds [x,y] in P1 \<longleftrightarrow> x in X \<and> [x,y] in R" and
             A3: "for x,y holds [x,y] in P2 \<longleftrightarrow> x in X \<and> [x,y] in R"
      show "P1=P2"
          proof (intro E_relat_1_def_2I ballI)
            fix x y
            assume "x be object" "y be object"
            have "[x,y] in P1 \<longleftrightarrow> x in X \<and> [x,y] in R" using A2 by auto
            thus "[x,y] in P1 \<longleftrightarrow> [x,y] in P2" using A3 by auto
          qed simp_all
qed mauto
qed mauto

abbreviation(input) relat_1_def_11_notation ("_ \<restriction> \<^bsub>_\<^esub>" [190,0] 190) where
  "R\<restriction>\<^bsub>X\<^esub> \<equiv> R|X"  
  
mtheorem E_relat_1_th_51:
  "x in dom(R|X) \<longleftrightarrow> x in X \<and> x in dom R"
proof(rule iffI3)
  show "x in dom(R|X) \<longrightarrow> x in X \<and> x in dom R"
  proof
    assume "x in dom(R|X)"
    then obtain y where "y be object" and
    A1: "[x,y] in R|X" using E_xtuple_0_def_12[of "(R|X)"] by auto
    have "x in X" "[x,y] in R" using E_relat_1_def_11[of R X] A1 by auto
    thus "x in X \<and> x in dom R" using E_xtuple_0_def_12 by auto
  qed
  assume
A2: "x in X \<and> x in dom R"
  then obtain y where "y be object" and
A3: "[x,y] in R" using E_xtuple_0_def_12 by auto
  hence "[x,y] in R|X" using A2 E_relat_1_def_11 by auto
  thus "x in dom (R|X)" using E_xtuple_0_def_12 by auto
qed

  (* ! ! *)

mtheorem E_relat_1_th_55:
  "dom(R|X) = dom R \<inter> X"
proof-
  have "for x being object holds x in dom(R|X) \<longleftrightarrow> x in dom R \<inter> X"
  proof(rule ballI)
    fix x
    have "x in dom(R|X) \<longleftrightarrow> x in dom R \<and> x in X" using E_relat_1_th_51 by auto
    thus "x in dom(R|X) \<longleftrightarrow> x in dom R \<inter> X" using E_xboole_0_def_4 by auto
  qed simp_all
  thus ?thesis using tarski_th_2 E_all_set by auto
qed

mtheorem E_relat_1_th_56:
  "X \<subseteq> dom R \<longrightarrow> dom (R|X) = X"
proof
   assume A1: "X \<subseteq> dom R"
   hence A2: "dom R \<inter> X \<subseteq> X" using E_xboole_0_def_4 tarski_def_3 by mauto
   have "X \<subseteq> dom R \<inter> X" using E_xboole_0_def_4[of "proj1 R" X] A1 tarski_def_3[of X "proj1 R"]
     by (intro tarski_def_3I) mauto
   hence "dom R \<inter> X = X" using E_xboole_0_def_10 A2 by mauto
   thus "dom (R|X) = X" using E_relat_1_th_55 by simp
qed


mtheorem E_relat_1_th75:
 "X \<subseteq> Y \<longrightarrow> R|X \<subseteq> R|Y"
proof
  assume A0:"X \<subseteq> Y"
  show "R|X \<subseteq> R|Y"
  proof(standard,auto)
      fix x
    assume A2: "x in R|X"
    then obtain a b where
       A3:"a be object" "b be object" "x=[a,b]" using E_relat_1_def_1[of "R|X"] by auto
    have "a in X \<and> [a,b] in R" using E_relat_1_def_11 A2 A3 by auto
    hence "a in Y \<and> [a,b] in R" using A0 tarski_def_3E[of X Y] by auto
    thus "x in R|Y" using E_relat_1_def_11 A2 A3 by auto
  qed
qed


end
