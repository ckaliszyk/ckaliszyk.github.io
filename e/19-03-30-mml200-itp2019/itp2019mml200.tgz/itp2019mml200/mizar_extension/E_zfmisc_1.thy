theory E_zfmisc_1
imports E_xboole_0 E_xtuple_0
begin

reserve x,y,z,x1,x2,y1,y2 for object

section "ZFMISC1"
reserve X,Y,Z,N,M for set

text_raw {*\DefineSnippet{zfmisc_1_def_1}{*}

mdef E_zfmisc_1_def_1   ("bool _" [110] 110) where
   mlet "X be set"
   "func (bool X) \<rightarrow> set means
     \<lambda>it. (\<forall>Y. Y in it \<longleftrightarrow> Y \<subseteq> X)"
text_raw {*}%EndSnippet*}
proof-
       let ?IT="\<lambda>x. x c= X"
       obtain M where
          [ty]: "M be set" and A1: "X in M" "(for X,Y holds X in M \<and> Y c= X \<longrightarrow> Y in M) \<and>
            (for X st X in M ex Z st Z in M \<and> (for Y st Y c= X holds Y in Z)) \<and>
            (\<forall>X.  X c= M \<longrightarrow> (X, M areequipotent \<or> X in M))"
         using tarski_a_th_1[THEN bspec, of X] by auto
     obtain IT where
          [ty]:"IT be set" and A2: "for Y being object holds (Y in IT \<longleftrightarrow> Y in M \<and> Y c= X)"
          using E_xboole_0_sch_1[of M ?IT] by auto
       show "ex IT being set st (for Y being set holds (Y in IT \<longleftrightarrow> Y c= X))"
          proof (rule bexI[of _ IT])
            show "IT be set" using A2 by auto
            show "for Y being set holds (Y in IT \<longleftrightarrow> Y c= X)"
            proof(rule ballI,rule iffI2)
              fix Y assume [ty]:"Y be set"
              show "Y in IT \<longrightarrow> Y c= X" using A1 A2 by auto
              show "Y c= X \<longrightarrow> Y in IT"
              proof
                assume A: "Y c= X"
                hence "Y in M" using A1(2)[THEN conjunct1,THEN bspec,of X] A1(1) by auto
                thus "Y in IT" using A2 A by auto
              qed
            qed simp_all
          qed simp_all
        next
    show "for x,y be set st (for Z being set holds (Z in x \<longleftrightarrow> Z c= X)) &  
      (for Z being set holds (Z in y \<longleftrightarrow> Z c= X)) holds x=y" 
    proof(rule ballI,rule ballI,rule impMI,rule impI)
      fix x y
       assume [ty]: "x be set" and [ty]: "y be set" and A3: "(for Z being set holds (Z in x \<longleftrightarrow> Z c= X))"
         "(for Z being set holds (Z in y \<longleftrightarrow> Z c= X))"
       show "x = y" using E_xfamily_sch_3[OF _ _ A3(1) A3(2) ] by mty auto
    qed simp_all
qed mauto

mdef E_zfmisc_1_def_2 ("[:_ ,_:]") where
  mlet "X1 be set", "X2 be set"
  "func [: X1, X2 :] \<rightarrow> set means \<lambda>it. (\<forall>z.  z in it \<longleftrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y]))"
proof-
      let ?X1="\<lambda>it1. ex x,y st x in X1 \<and> y in X2 \<and> it1 = [x,y]"
     have AA: "(bool(bool(X1 \<union> X2))) be set" using E_zfmisc_1_def_1 by mauto
    obtain X where
    [ty]: "X be set " and A2: "for z being object holds z in X \<longleftrightarrow> (z in (bool(bool(X1 \<union> X2))) \<and> ?X1(z))" using
                     E_xboole_0_sch_1[OF AA, of ?X1] by auto
       show "ex X being set st (\<forall>z.  z in X \<longleftrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y]))"
          proof (rule bexI[of _  X])
             show "\<forall>z.  z in X \<longleftrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y])"
                proof (intro ballI, rule iffI2)
                  fix z
                  assume [ty]: "z be object"
                  show "z in X \<longrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y])" using A2 by simp
                  show "(ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y]) \<longrightarrow> z in X"
                     proof
                       assume "ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y]"
                       then obtain x y where
                          "x be object \<and> y be object" and A3: "x in X1" and A4:"y in X2" and A5:  "z = [x, y]" by auto
                       have A5': "z = {{x,y},{x}}" using A5 tarski_def_5 by simp
                       have "{x,y} c= X1 \<union> X2"
                         proof(standard,auto)
                           fix z
                           assume "z in {x,y}"
                           thus "z in X1 \<union> X2" using A3 A4 E_xboole_0_def_3 tarski_def_2 by auto
                         qed mauto
                       hence A6: "{x,y} in bool(X1 \<union> X2)" using E_zfmisc_1_def_1 by mauto
                       have "{x} c= X1 \<union> X2"
                         proof(standard,auto)
                           fix z
                           assume "z in {x}"
                           thus "z in X1 \<union> X2" using A3 A4 E_xboole_0_def_3 tarski_def_1 by auto
                         qed mauto
                       hence A7: "{x} in bool(X1 \<union> X2)" using E_zfmisc_1_def_1 by mauto
                       hence "{{x,y},{x}} c= bool(X1 \<union> X2)" using A6 tarski_def_2 tarski_def_3 by mty auto
                       hence "{{x,y},{x}} in bool(bool(X1 \<union> X2))" using E_zfmisc_1_def_1[of "bool (X1 \<union> X2)"] by mauto
                       thus "z in X" using A2 A3 A4 A5 A5' by auto
                     qed
                qed simp_all
              qed simp_all
            next
     show "for IT1,IT2 be set st (\<forall>z.  z in IT1 \<longleftrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y]))&
           (\<forall>z.  z in IT2 \<longleftrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y])) holds IT1=IT2"
     proof(rule ballI,rule ballI,rule impMI,rule impI)
       fix IT1 IT2 assume [ty]: "IT1 be set" "IT2 be set" and
       A1:"\<forall>z.  z in IT1 \<longleftrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y])"
       and A2:"\<forall>z.  z in IT2 \<longleftrightarrow> (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y])"
       show "IT1 = IT2" using E_xboole_0_sch_3[of IT1 IT2 "\<lambda>z . (ex x, y st x in X1 \<and> y in X2 \<and> z = [x, y])"] A1 A2 by auto
    qed simp_all
qed mauto
  
mtheorem zfmisc_1_th_87:
  "for x,y holds [x,y] in [:X,Y:] \<longleftrightarrow> x in X \<and> y in Y"
proof (intro ballI)
  fix x y
  assume T0: "x be object" "y be object"
  show "[x,y] in [:X,Y:] \<longleftrightarrow> x in X \<and> y in Y"
     proof(rule iffI2)
        show "[x,y] in [:X,Y:] \<longrightarrow> x in X \<and> y in Y"
           proof
               assume "[x,y] in [:X,Y:]"
               hence "ex x1,y1 st x1 in X \<and> y1 in Y \<and> [x,y]=[x1,y1]" using E_zfmisc_1_def_2 ty by auto
               then obtain x1 y1 where
                  "x1 be object "  "y1 be object " and A1: "x1 in X \<and> y1 in Y \<and> [x,y]=[x1,y1]" by auto
               have "x=x1 \<and> y=y1" using A1 E_xtuple_0_th_1a by auto
               thus "x in X \<and> y in Y" using A1 by simp
           qed
       show "x in X \<and> y in Y \<longrightarrow> [x,y] in [:X,Y:]" using E_zfmisc_1_def_2 by auto
    qed
  qed simp_all


end
