theory hidden imports "../mizar/mizar_reserve" 

begin

abbreviation "objectHIDDENM1 \<equiv> object" 
notation SET ("setHIDDENM2")
notation mizeq (infixl "=HIDDENR1" 50)
notation not_eq (infixl "<>HIDDENR2" 50)
notation prefix_in (infixl "inHIDDENR3" 50)

end

