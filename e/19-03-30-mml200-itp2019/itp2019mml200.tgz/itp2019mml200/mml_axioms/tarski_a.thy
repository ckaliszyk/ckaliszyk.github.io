theory tarski_a
  imports tarski
begin
(*begin*)
reserve N, M, X, Y, Z for "setHIDDENM2"
axiomatization where tarski_a_th_1:
" for N be setHIDDENM2 holds  
  ex M be setHIDDENM2 st 
    ((N inTARSKIR2 M & 
     ( for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X inTARSKIR2 M & Y c=TARSKIR1 X implies Y inTARSKIR2 M)) & 
     ( for X be setHIDDENM2 holds X inTARSKIR2 M implies 
          ( ex Z be setHIDDENM2 st Z inTARSKIR2 M & ( for Y be setHIDDENM2 holds Y c=TARSKIR1 X implies Y inTARSKIR2 Z)))) &
    ( for X be setHIDDENM2 holds X c=TARSKIR1 M implies (X,M)are-equipotentTARSKIR3 or X inTARSKIR2 M)"

end
