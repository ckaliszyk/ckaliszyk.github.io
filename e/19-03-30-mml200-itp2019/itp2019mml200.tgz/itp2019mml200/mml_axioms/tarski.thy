    theory tarski
      imports "tarski_0"
begin
ML {* derive_types := true *}

(*begin*)
reserve x, y, z, u for "objectHIDDENM1"
reserve N, M, X, Y, Z for "setHIDDENM2"
mtheorem tarski_th_1:
" for x be objectHIDDENM1 holds x be setHIDDENM2"
  using tarski_0_th_1 by auto

mtheorem tarski_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Y) implies X =HIDDENR1 Y"
  using tarski_0_th_2 by auto



mdef tarski_def_1 ("{TARSKIK1 _ }" [0]356 ) where
  mlet "y be objectHIDDENM1"
"func {TARSKIK1 y} \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 y"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 y"
    proof-
      have " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar1 &  not x =HIDDENR1 y) 
               &  not (x =HIDDENR1 y &  not x inHIDDENR3 tVar1)"
      proof-
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x =HIDDENR1 y or x =HIDDENR1 y"
          using tarski_0_th_3[THEN bspec,THEN bspec, of y y] by mty auto
        show " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar1 &  not x =HIDDENR1 y) &  not (x =HIDDENR1 y &  not x inHIDDENR3 tVar1)"
        proof(rule bexI[of _ X])
          show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x =HIDDENR1 y) &  not (x =HIDDENR1 y &  not x inHIDDENR3 X)"
            using A1 by auto
        qed mauto
      qed
      thus " ?thesis "
         by auto
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x =HIDDENR1 y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x =HIDDENR1 y) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 X1 iff z =HIDDENR1 y) & ( for z be objectHIDDENM1 holds z inHIDDENR3 X2 iff z =HIDDENR1 y) implies X1 =HIDDENR1 X2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        fix X2 assume [ty]: "X2 be setHIDDENM2"
        assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 X1 iff z =HIDDENR1 y"
          and A2: " for z be objectHIDDENM1 holds z inHIDDENR3 X2 iff z =HIDDENR1 y"
        have " for z be objectHIDDENM1 holds z inHIDDENR3 X1 iff z inHIDDENR3 X2"
        proof(rule ballI)
          fix z assume [ty]: "z be objectHIDDENM1"
          have "z inHIDDENR3 X1 iff z =HIDDENR1 y"
            using A1 by auto
          thus "z inHIDDENR3 X1 iff z inHIDDENR3 X2"
            using A2 by auto
        qed mauto
        thus "X1 =HIDDENR1 X2"
          using tarski_0_th_2[THEN bspec,THEN bspec] by mauto
      qed mauto
      thus " ?thesis "
         by auto
    qed
qed mauto

mdef tarski_def_2 ("{TARSKIK2 _ , _ }" [0,0]356 ) where
  mlet "y be objectHIDDENM1", "z be objectHIDDENM1"
"func {TARSKIK2 y,z } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 y or x =HIDDENR1 z"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x =HIDDENR1 y or x =HIDDENR1 z"
    proof-
      have " ex tVar2 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar2 &  not x =HIDDENR1 y &  not x =HIDDENR1 z) &  not ( not ( not x =HIDDENR1 y &  not x =HIDDENR1 z) &  not x inHIDDENR3 tVar2)"
      proof-
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x =HIDDENR1 y or x =HIDDENR1 z"
          using tarski_0_th_3[THEN bspec,THEN bspec, of y z] by auto
        show " ex tVar2 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar2 &  not x =HIDDENR1 y &  not x =HIDDENR1 z) &  not ( not ( not x =HIDDENR1 y &  not x =HIDDENR1 z) &  not x inHIDDENR3 tVar2)"
        proof(rule bexI[of _ X])
          show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 X &  not x =HIDDENR1 y &  not x =HIDDENR1 z) &  not ( not ( not x =HIDDENR1 y &  not x =HIDDENR1 z) &  not x inHIDDENR3 X)"
            using A1 by auto
        qed mauto
      qed
      thus " ?thesis "
         by auto
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff x =HIDDENR1 y or x =HIDDENR1 z) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff x =HIDDENR1 y or x =HIDDENR1 z) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x =HIDDENR1 y or x =HIDDENR1 z) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff x =HIDDENR1 y or x =HIDDENR1 z) implies X1 =HIDDENR1 X2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        fix X2 assume [ty]: "X2 be setHIDDENM2"
        assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x =HIDDENR1 y or x =HIDDENR1 z"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff x =HIDDENR1 y or x =HIDDENR1 z"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x inHIDDENR3 X2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 X1 iff x =HIDDENR1 y or x =HIDDENR1 z"
            using A1 by auto
          thus "x inHIDDENR3 X1 iff x inHIDDENR3 X2"
            using A2 by auto
        qed mauto
        thus "X1 =HIDDENR1 X2"
          using tarski_0_th_2[THEN bspec,THEN bspec] by mauto
      qed mauto
      thus " ?thesis "
         by auto
    qed
qed mauto

lemma commutativity_prop:
  assumes 
     "for it be parentty holds 
         for x,y be ty holds it =HIDDENR1 F(x,y) implies it =HIDDENR1 F(y,x)"
     "for x,y be ty holds F(x,y) is parentty" and
     [ex]:"inhabited (ty)" "inhabited (parentty)"
   shows "for x,y be ty holds F(x,y) =F(y,x)"
proof(auto)
  fix x y assume [ty]: "x be ty" "y be ty"
  show "F(x,y) =F(y,x)"  using assms(1)[THEN bspec,THEN bspec,THEN bspec, of "F(x,y)" x y] 
     assms(2)[THEN bspec,THEN bspec, of x y] by mty auto
qed
thm tarski_def_2

lemma commutativity_unfold:
  assumes 
     "for it be parrentty holds 
         for x,y be ty holds D(it,x,y) implies D(it,y,x)"
     "\<And> x y it. x be ty \<Longrightarrow> y be ty \<Longrightarrow> D(it,x,y) \<Longrightarrow> it = F(x,y)"
     "\<And> x y . x be ty \<Longrightarrow>y be ty \<Longrightarrow> D(F(x,y),x,y)"
     "\<And> x y . x be ty \<Longrightarrow>y be ty \<Longrightarrow> F(x,y) is parrentty" and
     [ex]:"inhabited (ty)" "inhabited (parrentty)"
   shows "for it be parrentty holds 
         for x,y be ty holds it =HIDDENR1 F(x,y) implies it =HIDDENR1 F(y,x)"
proof(intro ballI impI)
  fix it x y assume [ty]: "it be parrentty" "x be ty" "y be ty" 
  assume "it =HIDDENR1 F(x, y)"
  hence "D(it,x,y)" using assms(3) by auto
  hence "D(it,y,x)" using assms(1) by auto
  thus "it = F(y,x)" using assms(2) by auto
qed mauto



mtheorem TARSKIK2_commutativity:
" for y be objectHIDDENM1 holds for z be objectHIDDENM1 holds {TARSKIK2 y,z } =HIDDENR1 {TARSKIK2 z,y }"
proof(rule ballI,rule ballI)
  fix y z
  show "{TARSKIK2 y , z } =HIDDENR1 {TARSKIK2 z , y }"
  proof(rule tarski_def_2_uniq[of  z y "{TARSKIK2 y , z }"]) 
    fix x 
    show "x inHIDDENR3 {TARSKIK2 y , z } \<longleftrightarrow> x =HIDDENR1 z \<or> x =HIDDENR1 y" 
          using tarski_def_2 by auto
   qed mauto
qed mauto

mdef tarski_def_3 (" _ c=TARSKIR1 _ " [100,100]50 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"pred X c=TARSKIR1 Y means
   for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Y"..

mtheorem TARSKIR1_reflexivity:
" for Y be setHIDDENM2 holds Y c=TARSKIR1 Y"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 Y implies x inHIDDENR3 Y"
     by auto
  thus " ?thesis "
    using tarski_def_3 by auto
qed

mdef tarski_def_4 ("unionTARSKIK3 _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func unionTARSKIK3 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)"
    proof-
      have " ex tVar3 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar3 & ( for Y be setHIDDENM2 holds  not (x inHIDDENR3 Y & Y inHIDDENR3 X))) &  not ( not ( for Y be setHIDDENM2 holds  not (x inHIDDENR3 Y & Y inHIDDENR3 X)) &  not x inHIDDENR3 tVar3)"
      proof-
        obtain Z where
          [ty]:"Z be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Z iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)"
          using tarski_0_th_4[THEN bspec,of X] by auto
        show " ex tVar3 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (x inHIDDENR3 tVar3 & ( for Y be setHIDDENM2 holds  not (x inHIDDENR3 Y & Y inHIDDENR3 X))) &  not ( not ( for Y be setHIDDENM2 holds  not (x inHIDDENR3 Y & Y inHIDDENR3 X)) &  not x inHIDDENR3 tVar3)"
        proof(rule bexI[of _ Z])
          show " for x be objectHIDDENM1 holds  not (x inHIDDENR3 Z & ( for Y be setHIDDENM2 holds  not (x inHIDDENR3 Y & Y inHIDDENR3 X))) &  not ( not ( for Y be setHIDDENM2 holds  not (x inHIDDENR3 Y & Y inHIDDENR3 X)) &  not x inHIDDENR3 Z)"
            using A1 by auto
        qed mauto
      qed
      thus " ?thesis "
         by auto
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)) implies it1 =HIDDENR1 it2"
    proof-
      have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)) implies X1 =HIDDENR1 X2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix X1 assume [ty]: "X1 be setHIDDENM2"
        fix X2 assume [ty]: "X2 be setHIDDENM2"
        assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff x inHIDDENR3 X2"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 X1 iff ( ex Y be setHIDDENM2 st x inHIDDENR3 Y & Y inHIDDENR3 X)"
            using A1 by auto
          thus "x inHIDDENR3 X1 iff x inHIDDENR3 X2"
            using A2 by auto
        qed mauto
        thus "X1 =HIDDENR1 X2"
          using tarski_0_th_2[THEN bspec,THEN bspec] by mauto
      qed mauto
      thus " ?thesis "
         by auto
    qed
qed mauto

mtheorem tarski_th_3:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 X implies ( ex Y be setHIDDENM2 st Y inHIDDENR3 X &  not ( ex x be objectHIDDENM1 st x inHIDDENR3 X & x inHIDDENR3 Y))"
  using tarski_0_th_5 by auto

syntax TARSKIR2 :: " Set \<Rightarrow>  Set \<Rightarrow> o" (" _ inTARSKIR2 _ " [100,100]50)
translations "x inTARSKIR2 X" \<rightharpoonup> "x inHIDDENR3 X"

mtheorem TARSKIR2_asymmetry:
" for x be setHIDDENM2 holds  for X be setHIDDENM2 holds x inTARSKIR2 X implies  not X inTARSKIR2 x"
proof-
  have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds a inHIDDENR3 b & b inHIDDENR3 a implies  not  True "
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix b assume [ty]: "b be setHIDDENM2"
    assume A1: "a inHIDDENR3 b & b inHIDDENR3 a"
    let ?X = "{TARSKIK2 a,b }"
    have A3: "a inHIDDENR3 ?X & b inHIDDENR3 ?X"
      using tarski_def_2 by auto
    obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A4: "Y inHIDDENR3 ?X &  not ( ex x be objectHIDDENM1 st x inHIDDENR3 ?X & x inHIDDENR3 Y)"
      using A3 tarski_0_th_5[THEN bspec,THEN bspec,of a ?X] by mty auto
    have "Y =HIDDENR1 a or Y =HIDDENR1 b"
      using A4 tarski_def_2 by auto
    thus " not  True "
      using A1 A3 A4 by auto
  qed mauto
  thus " ?thesis "
     by auto
qed

theorem tarski_sch_1:
  fixes Af0 Pp2 
  assumes [ty]: "Af0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds Pp2(x,y) & Pp2(x,z) implies y =HIDDENR1 z"
  shows " ex X be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 X iff ( ex y be objectHIDDENM1 st y inHIDDENR3 Af0 & Pp2(y,x))"
  proof-
    have " not ( for X be setHIDDENM2 holds  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Af0 & Pp2(y,x)))) &  not ( not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Af0 & Pp2(y,x))) &  not x inHIDDENR3 X)))"
    proof-
      show " not ( for X be setHIDDENM2 holds  
            not ( for x be objectHIDDENM1 holds  
           not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Af0 & Pp2(y,x)))) &  
           not ( not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Af0 & Pp2(y,x))) &  not x inHIDDENR3 X)))"
        using tarski_0_sch_1[OF assms(1) A1] using ex by blast
    qed
    thus " ?thesis "
       by auto
  qed

mdef tarski_def_5 ("[TARSKIK4 _ , _ ]" [0,0]356 ) where
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"func [TARSKIK4 x,y ] \<rightarrow> objectHIDDENM1 equals
  {TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} }"
proof-
  (*coherence*)
    show "{TARSKIK2 {TARSKIK2 x,y },{TARSKIK1 x} } be objectHIDDENM1"
       by auto
qed mauto

mdef tarski_def_6 ("'( _ , _ ')are-equipotentTARSKIR3" [0,0]50 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"pred (X,Y)are-equipotentTARSKIR3 means
   ex Z be setHIDDENM2 st ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 Z)) & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 Z)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for u be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Z & [TARSKIK4 z,u ] inHIDDENR3 Z implies x =HIDDENR1 z iff y =HIDDENR1 u)"..

end