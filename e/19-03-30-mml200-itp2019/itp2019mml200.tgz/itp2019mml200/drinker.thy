theory drinker
  imports "../mml_axioms/tarski"
begin
(*begin*)
ML {* derive_types := true *}
reserve x, y, t for "set"

text_raw {*\DefineSnippet{cc1drink}{*}
theorem cc1_sch_1: "\<exists>x. P(x) \<longrightarrow> (\<forall>y. P(y))"
proof-
  have cases: "(\<exists>x.\<not>P(x)) \<or> (\<forall>x. P(x))" by auto
  have case1: "(\<exists>x.\<not>P(x)) \<longrightarrow> (\<exists>t. P(t) \<longrightarrow> (\<forall>y. P(y)))"
  proof(rule impI)
    assume "\<exists>x. \<not>P(x)"
    then obtain x where
      [ty]:"x be set" and A1: "\<not>P(x)" by auto
    show "ex t st P(t) \<longrightarrow> (\<forall>y. P(y))"
    proof(rule bexI[of _ "x"],rule impI)
      assume "P(x)"
      thus "\<forall>y. P(y)" using A1 by simp
    qed auto
  qed
  have case2: "(\<forall>x. P(x)) \<longrightarrow> (\<exists>x. P(x) \<longrightarrow> (\<forall>y. P(y)))"
  proof(rule impI)
    assume A2: "\<forall>x:set. P(x)"
    obtain x where
      [ty]:"x be set" and xDef: "x = the set" by auto
    show "\<exists>x. P(x) \<longrightarrow> (\<forall>y. P(y))"
    proof(rule bexI[of _ "x"],rule impI)
      assume "P(x)"
      show "\<forall>y. P(y)" using A2 by simp
    qed auto
  qed
  show "?thesis" using cases case1 case2 by auto
qed
text_raw {*}%EndSnippet*}

end

