theory relset_2
  imports eqrel_1 mssubfam sysrel classes1
begin
(*begin*)
reserve x, y for "objectHIDDENM1"
reserve X, Y, A, B, C, M for "setHIDDENM2"
reserve P, Q, R, R1, R2 for "RelationRELAT-1M1"
abbreviation(input) RELSET_2K1("{-{RELSET-2K1  _ }-}" [0]164) where
  "{-{RELSET-2K1 X}-} \<equiv> SmallestPartitionEQREL-1K12 X"

mtheorem relset_2_th_1:
" for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds y inHIDDENR3 {-{RELSET-2K1 X}-} iff ( ex x be objectHIDDENM1 st y =HIDDENR1 {TARSKIK1 x} & x inHIDDENR3 X)"
sorry

mtheorem relset_2_th_2:
" for X be setHIDDENM2 holds X =XBOOLE-0R4 {}XBOOLE-0K1 iff {-{RELSET-2K1 X}-} =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem relset_2_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {-{RELSET-2K1 X \\/XBOOLE-0K2 Y }-} =XBOOLE-0R4 {-{RELSET-2K1 X}-} \\/XBOOLE-0K2 {-{RELSET-2K1 Y}-}"
sorry

mtheorem relset_2_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {-{RELSET-2K1 X /\\XBOOLE-0K3 Y }-} =XBOOLE-0R4 ({-{RELSET-2K1 X}-})/\\XBOOLE-0K3 ({-{RELSET-2K1 Y}-})"
sorry

mtheorem relset_2_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {-{RELSET-2K1 X \\SUBSET-1K6 Y }-} =XBOOLE-0R4 {-{RELSET-2K1 X}-} \\SUBSET-1K6 {-{RELSET-2K1 Y}-}"
sorry

mtheorem relset_2_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y iff {-{RELSET-2K1 X}-} c=TARSKIR1 {-{RELSET-2K1 Y}-}"
sorry

mtheorem relset_2_th_7:
" for M be setHIDDENM2 holds  for B1 be Subset-FamilySETFAM-1M1-of M holds  for B2 be Subset-FamilySETFAM-1M1-of M holds (IntersectSETFAM-1K8\<^bsub>(M)\<^esub> B1)/\\SUBSET-1K9\<^bsub>(M)\<^esub> (IntersectSETFAM-1K8\<^bsub>(M)\<^esub> B2) c=TARSKIR1 IntersectSETFAM-1K8\<^bsub>(M)\<^esub> (B1 /\\SUBSET-1K9\<^bsub>(boolZFMISC-1K1 M)\<^esub> B2)"
sorry

mtheorem relset_2_th_8:
" for P be RelationRELAT-1M1 holds  for Q be RelationRELAT-1M1 holds  for R be RelationRELAT-1M1 holds (P /\\XBOOLE-0K3 Q)*RELAT-1K6 R c=RELAT-1R2 (P *RELAT-1K6 R)/\\XBOOLE-0K3 (Q *RELAT-1K6 R)"
sorry

(*begin*)
mtheorem relset_2_th_9:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds y inHIDDENR3 ImRELAT-1K12(R,x) iff [TARSKIK4 x,y ] inHIDDENR3 R"
sorry

mtheorem relset_2_th_10:
" for x be objectHIDDENM1 holds  for R1 be RelationRELAT-1M1 holds  for R2 be RelationRELAT-1M1 holds ImRELAT-1K12(R1 \\/XBOOLE-0K2 R2,x) =XBOOLE-0R4 ImRELAT-1K12(R1,x) \\/XBOOLE-0K2 ImRELAT-1K12(R2,x)"
sorry

mtheorem relset_2_th_11:
" for x be objectHIDDENM1 holds  for R1 be RelationRELAT-1M1 holds  for R2 be RelationRELAT-1M1 holds ImRELAT-1K12(R1 /\\XBOOLE-0K3 R2,x) =XBOOLE-0R4 ImRELAT-1K12(R1,x) /\\XBOOLE-0K3 ImRELAT-1K12(R2,x)"
sorry

mtheorem relset_2_th_12:
" for x be objectHIDDENM1 holds  for R1 be RelationRELAT-1M1 holds  for R2 be RelationRELAT-1M1 holds ImRELAT-1K12(R1 \\SUBSET-1K6 R2,x) =XBOOLE-0R4 ImRELAT-1K12(R1,x) \\SUBSET-1K6 ImRELAT-1K12(R2,x)"
sorry

mtheorem relset_2_th_13:
" for X be setHIDDENM2 holds  for R1 be RelationRELAT-1M1 holds  for R2 be RelationRELAT-1M1 holds (R1 /\\XBOOLE-0K3 R2).:RELAT-1K10 ({-{RELSET-2K1 X}-}) c=TARSKIR1 R1 .:RELAT-1K10 ({-{RELSET-2K1 X}-}) /\\XBOOLE-0K3 R2 .:RELAT-1K10 ({-{RELSET-2K1 X}-})"
sorry

syntax RELSET_2K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("ImRELSET-2K2\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]228)
translations "ImRELSET-2K2\<^bsub>(X,Y)\<^esub>(R,x)" \<rightharpoonup> "ImRELAT-1K12(R,x)"

mtheorem relset_2_add_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)", "x be objectHIDDENM1"
"cluster ImRELAT-1K12(R,x) as-term-is SubsetSUBSET-1M2-of Y"
proof
(*coherence*)
  show "ImRELAT-1K12(R,x) be SubsetSUBSET-1M2-of Y"
sorry
qed "sorry"

syntax RELSET_2K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("CoimRELSET-2K3\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]164)
translations "CoimRELSET-2K3\<^bsub>(X,Y)\<^esub>(R,x)" \<rightharpoonup> "CoimRELAT-1K13(R,x)"

mtheorem relset_2_add_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)", "x be objectHIDDENM1"
"cluster CoimRELAT-1K13(R,x) as-term-is SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show "CoimRELAT-1K13(R,x) be SubsetSUBSET-1M2-of X"
sorry
qed "sorry"

mtheorem relset_2_th_14:
" for A be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of A holds  for R be RelationRELAT-1M1 holds R .:RELAT-1K10 unionSETFAM-1K5\<^bsub>(A)\<^esub> F =XBOOLE-0R4 unionTARSKIK3 ({R .:RELAT-1K10 X where X be SubsetSUBSET-1M2-of A : X inTARSKIR2 F })"
sorry

mtheorem relset_2_th_15:
" for A be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds X =XBOOLE-0R4 unionTARSKIK3 ({{TARSKIK1 x} where x be ElementSUBSET-1M1-of A : x inTARSKIR2 X })"
sorry

mtheorem relset_2_th_16:
" for A be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds {{TARSKIK1 x} where x be ElementSUBSET-1M1-of A : x inTARSKIR2 X } be Subset-FamilySETFAM-1M1-of A"
sorry

mtheorem relset_2_th_17:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be RelationRELSET-1M1-of(A,B) holds R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 unionTARSKIK3 ({ClassEQREL-1K7\<^bsub>(A,B)\<^esub>(R,x) where x be ElementSUBSET-1M1-of A : x inTARSKIR2 X })"
sorry

mtheorem relset_2_th_18:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be RelationRELSET-1M1-of(A,B) holds {R .:RELSET-1K7\<^bsub>(A,B)\<^esub> x where x be ElementSUBSET-1M1-of A : x inTARSKIR2 X } be Subset-FamilySETFAM-1M1-of B"
sorry

mdef relset_2_def_1 (".:RELSET-2K4'( _ , _ ')" [0,0]200 ) where
  mlet "A be setHIDDENM2", "R be RelationRELAT-1M1"
"func .:RELSET-2K4(R,A) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 boolSETFAM-1K9 A & ( for X be setHIDDENM2 holds X c=TARSKIR1 A implies it .FUNCT-1K1 X =XBOOLE-0R4 R .:RELAT-1K10 X)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 boolSETFAM-1K9 A & ( for X be setHIDDENM2 holds X c=TARSKIR1 A implies it .FUNCT-1K1 X =XBOOLE-0R4 R .:RELAT-1K10 X)"
sorry
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 boolSETFAM-1K9 A & ( for X be setHIDDENM2 holds X c=TARSKIR1 A implies it1 .FUNCT-1K1 X =XBOOLE-0R4 R .:RELAT-1K10 X)) & (domRELAT-1K1 it2 =XBOOLE-0R4 boolSETFAM-1K9 A & ( for X be setHIDDENM2 holds X c=TARSKIR1 A implies it2 .FUNCT-1K1 X =XBOOLE-0R4 R .:RELAT-1K10 X)) implies it1 =HIDDENR1 it2"
sorry
qed "sorry"

syntax RELSET_2K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (".:RELSET-2K5\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,200]200)
translations ".:RELSET-2K5\<^bsub>(B,A)\<^esub> R" \<rightharpoonup> ".:RELSET-2K4(R,A)"

mtheorem relset_2_th_19:
" for X be setHIDDENM2 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds X inTARSKIR2 domRELAT-1K1 (.:RELSET-2K4(R,A)) implies (.:RELSET-2K4(R,A)).FUNCT-1K1 X =XBOOLE-0R4 R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_20:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds rngFUNCT-1K2 (.:RELSET-2K4(R,A)) c=TARSKIR1 boolSETFAM-1K9 (rngRELSET-1K2\<^bsub>(B)\<^esub> R)"
sorry

mtheorem relset_2_th_21:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds .:RELSET-2K4(R,A) be FunctionFUNCT-2M1-of(boolSETFAM-1K9 A,boolSETFAM-1K9 (rngRELSET-1K2\<^bsub>(B)\<^esub> R))"
sorry

syntax RELSET_2K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (".:RELSET-2K6\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,200]200)
translations ".:RELSET-2K6\<^bsub>(B,A)\<^esub> R" \<rightharpoonup> ".:RELSET-2K4(R,A)"

mtheorem relset_2_add_3:
  mlet "B be setHIDDENM2", "A be setHIDDENM2", "R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :]"
"cluster .:RELSET-2K4(R,A) as-term-is FunctionFUNCT-2M1-of(boolSETFAM-1K9 A,boolSETFAM-1K9 B)"
proof
(*coherence*)
  show ".:RELSET-2K4(R,A) be FunctionFUNCT-2M1-of(boolSETFAM-1K9 A,boolSETFAM-1K9 B)"
sorry
qed "sorry"

mtheorem relset_2_th_22:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds unionSETFAM-1K5\<^bsub>(B)\<^esub> ((.:RELSET-2K6\<^bsub>(B,A)\<^esub> R).:RELSET-1K7\<^bsub>(boolSETFAM-1K9 A,boolSETFAM-1K9 B)\<^esub> A) c=TARSKIR1 R .:RELSET-1K7\<^bsub>(A,B)\<^esub> unionTARSKIK3 A"
sorry

(*begin*)
reserve X, X1, X2 for "SubsetSUBSET-1M2-of A"
reserve Y for "SubsetSUBSET-1M2-of B"
reserve R, R1, R2 for "SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :]"
reserve FR for "Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 A,B :]"
mdef relset_2_def_2 (" _ .:^RELSET-2K7\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164 ) where
  mlet "A be setHIDDENM2", "B be setHIDDENM2", "X be SubsetSUBSET-1M2-of A", "R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :]"
"func R .:^RELSET-2K7\<^bsub>(A,B)\<^esub> X \<rightarrow> setHIDDENM2 equals
  IntersectSETFAM-1K8\<^bsub>(B)\<^esub> (.:RELSET-2K6\<^bsub>(B,A)\<^esub> R).:RELSET-1K7\<^bsub>(boolSETFAM-1K9 A,boolSETFAM-1K9 B)\<^esub> ({-{RELSET-2K1 X}-})"
proof-
  (*coherence*)
    show "IntersectSETFAM-1K8\<^bsub>(B)\<^esub> (.:RELSET-2K6\<^bsub>(B,A)\<^esub> R).:RELSET-1K7\<^bsub>(boolSETFAM-1K9 A,boolSETFAM-1K9 B)\<^esub> ({-{RELSET-2K1 X}-}) be setHIDDENM2"
       sorry
qed "sorry"

abbreviation(input) RELSET_2K8(" _ .:^RELSET-2K8\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164) where
  "R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X \<equiv> R .:^RELSET-2K7\<^bsub>(A,B)\<^esub> X"

mtheorem relset_2_add_4:
  mlet "A be setHIDDENM2", "B be setHIDDENM2", "X be SubsetSUBSET-1M2-of A", "R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :]"
"cluster R .:^RELSET-2K7\<^bsub>(A,B)\<^esub> X as-term-is SubsetSUBSET-1M2-of B"
proof
(*coherence*)
  show "R .:^RELSET-2K7\<^bsub>(A,B)\<^esub> X be SubsetSUBSET-1M2-of B"
     sorry
qed "sorry"

mtheorem relset_2_th_23:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds (.:RELSET-2K6\<^bsub>(B,A)\<^esub> R).:RELSET-1K7\<^bsub>(boolSETFAM-1K9 A,boolSETFAM-1K9 B)\<^esub> ({-{RELSET-2K1 X}-}) =XBOOLE-0R4 {}XBOOLE-0K1 iff X =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem relset_2_th_24:
" for y be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds y inHIDDENR3 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X implies ( for x be setHIDDENM2 holds x inTARSKIR2 X implies y inHIDDENR3 ImRELSET-2K2\<^bsub>(A,B)\<^esub>(R,x))"
sorry

mtheorem relset_2_th_25:
" for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for y be ElementSUBSET-1M1-of B holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds y inTARSKIR2 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X iff ( for x be setHIDDENM2 holds x inTARSKIR2 X implies y inTARSKIR2 ImRELSET-2K2\<^bsub>(A,B)\<^esub>(R,x))"
sorry

mtheorem relset_2_th_26:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of A holds  for X2 be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds (.:RELSET-2K6\<^bsub>(B,A)\<^esub> R).:RELSET-1K7\<^bsub>(boolSETFAM-1K9 A,boolSETFAM-1K9 B)\<^esub> ({-{RELSET-2K1 X1}-}) =XBOOLE-0R4 {}XBOOLE-0K1 implies R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> (X1 \\/SUBSET-1K4\<^bsub>(A)\<^esub> X2) =XBOOLE-0R4 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X2"
sorry

mtheorem relset_2_th_27:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of A holds  for X2 be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> (X1 \\/SUBSET-1K4\<^bsub>(A)\<^esub> X2) =XBOOLE-0R4 (R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X1)/\\SUBSET-1K9\<^bsub>(B)\<^esub> (R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X2)"
sorry

mtheorem relset_2_th_28:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be setHIDDENM2 holds  for F be Subset-FamilySETFAM-1M1-of A holds  for R be RelationRELSET-1M1-of(A,B) holds {R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X where X be SubsetSUBSET-1M2-of A : X inTARSKIR2 F } be Subset-FamilySETFAM-1M1-of B"
sorry

mtheorem relset_2_th_29:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds X =XBOOLE-0R4 {}XBOOLE-0K1 implies R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 B"
  using relset_2_th_23 setfam_1_def_9 sorry

mtheorem relset_2_th_30:
" for A be setHIDDENM2 holds  for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds  for F be Subset-FamilySETFAM-1M1-of A holds  for G be Subset-FamilySETFAM-1M1-of B holds G =XBOOLE-0R4 {R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> Y where Y be SubsetSUBSET-1M2-of A : Y inTARSKIR2 F } implies R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> unionSETFAM-1K5\<^bsub>(A)\<^esub> F =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(B)\<^esub> G"
sorry

mtheorem relset_2_th_31:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of A holds  for X2 be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds X1 c=TARSKIR1 X2 implies R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X2 c=TARSKIR1 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X1"
sorry

mtheorem relset_2_th_32:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X1 be SubsetSUBSET-1M2-of A holds  for X2 be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X1 \\/SUBSET-1K4\<^bsub>(B)\<^esub> R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X2 c=TARSKIR1 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> (X1 /\\SUBSET-1K9\<^bsub>(A)\<^esub> X2)"
sorry

mtheorem relset_2_th_33:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R1 be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds  for R2 be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds (R1 /\\SUBSET-1K9\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> R2).:^RELSET-2K8\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 (R1 .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X)/\\SUBSET-1K9\<^bsub>(B)\<^esub> (R2 .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X)"
sorry

mtheorem relset_2_th_34:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for FR be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 A,B :] holds unionSETFAM-1K5\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> FR .:RELSET-1K7\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 unionTARSKIK3 ({R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X where R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] : R inTARSKIR2 FR })"
sorry

mtheorem relset_2_th_35:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for FR be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 A,B :] holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds {R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X where R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] : R inTARSKIR2 FR } be Subset-FamilySETFAM-1M1-of B"
sorry

mtheorem relset_2_th_36:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds R =RELAT-1R1 {}XBOOLE-0K1 & X <>HIDDENR2 {}XBOOLE-0K1 implies R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 {}XBOOLE-0K1"
sorry

mtheorem relset_2_th_37:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds R =RELAT-1R1 [:ZFMISC-1K2 A,B :] implies R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 B"
sorry

mtheorem relset_2_th_38:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for FR be Subset-FamilySETFAM-1M1-of [:ZFMISC-1K2 A,B :] holds  for G be Subset-FamilySETFAM-1M1-of B holds G =XBOOLE-0R4 {R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X where R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] : R inTARSKIR2 FR } implies (IntersectSETFAM-1K8\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> FR).:^RELSET-2K8\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 IntersectSETFAM-1K8\<^bsub>(B)\<^esub> G"
sorry

mtheorem relset_2_th_39:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R1 be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds  for R2 be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds R1 c=RELSET-1R1\<^bsub>(A,B)\<^esub> R2 implies R1 .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X c=TARSKIR1 R2 .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_40:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R1 be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds  for R2 be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds R1 .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X \\/SUBSET-1K4\<^bsub>(B)\<^esub> R2 .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X c=TARSKIR1 (R1 \\/SUBSET-1K4\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> R2).:^RELSET-2K8\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_41:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds y inHIDDENR3 ImRELSET-2K2\<^bsub>(A,B)\<^esub>(R `SUBSET-1K3\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub>,x) iff ( not [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 A) & y inHIDDENR3 B"
sorry

mtheorem relset_2_th_42:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds X <>HIDDENR2 {}XBOOLE-0K1 implies R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X c=TARSKIR1 R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_43:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X meetsXBOOLE-0R5 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> Y iff ( ex x be setHIDDENM2 st  ex y be setHIDDENM2 st (x inTARSKIR2 X & y inTARSKIR2 Y) & x inTARSKIR2 ImRELSET-2K2\<^bsub>(B,A)\<^esub>(R ~RELSET-1K3\<^bsub>(A,B)\<^esub>,y))"
sorry

mtheorem relset_2_th_44:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( ex x be setHIDDENM2 st  ex y be setHIDDENM2 st (x inTARSKIR2 X & y inTARSKIR2 Y) & x inTARSKIR2 ImRELSET-2K2\<^bsub>(B,A)\<^esub>(R ~RELSET-1K3\<^bsub>(A,B)\<^esub>,y)) iff Y meetsXBOOLE-0R5 R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_45:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for Y be SubsetSUBSET-1M2-of B holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds X missesXBOOLE-0R1 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> Y iff Y missesXBOOLE-0R1 R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_46:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds  for X be setHIDDENM2 holds R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 R .:RELSET-1K7\<^bsub>(A,B)\<^esub> (X /\\XBOOLE-0K3 proj1XTUPLE-0K12 R)"
sorry

mtheorem relset_2_th_47:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds  for Y be setHIDDENM2 holds R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> Y =XBOOLE-0R4 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> (Y /\\XBOOLE-0K3 proj2XTUPLE-0K13 R)"
sorry

mtheorem relset_2_th_48:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :] holds (R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X)`SUBSET-1K3\<^bsub>(B)\<^esub> =XBOOLE-0R4 R `SUBSET-1K3\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> .:RELSET-1K7\<^bsub>(A,B)\<^esub> X"
sorry

reserve R for "RelationRELSET-1M1-of(A,B)"
reserve S for "RelationRELSET-1M1-of(B,C)"
syntax RELSET_2K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *RELSET-2K9\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "R *RELSET-2K9\<^bsub>(A,B,C)\<^esub> S" \<rightharpoonup> "R *RELAT-1K6 S"

mtheorem relset_2_add_5:
  mlet "A be setHIDDENM2", "B be setHIDDENM2", "C be setHIDDENM2", "R be SubsetSUBSET-1M2-of [:ZFMISC-1K2 A,B :]", "S be SubsetSUBSET-1M2-of [:ZFMISC-1K2 B,C :]"
"cluster R *RELAT-1K6 S as-term-is RelationRELSET-1M1-of(A,C)"
proof
(*coherence*)
  show "R *RELAT-1K6 S be RelationRELSET-1M1-of(A,C)"
sorry
qed "sorry"

mtheorem relset_2_th_49:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be RelationRELSET-1M1-of(A,B) holds (R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X)`SUBSET-1K3\<^bsub>(B)\<^esub> =XBOOLE-0R4 R `SUBSET-1K3\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_50:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds proj1XTUPLE-0K12 R =XBOOLE-0R4 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> B & proj2XTUPLE-0K13 R =XBOOLE-0R4 R .:RELSET-1K7\<^bsub>(A,B)\<^esub> A"
sorry

mtheorem relset_2_th_51:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds  for S be RelationRELSET-1M1-of(B,C) holds proj1XTUPLE-0K12 (R *RELSET-2K9\<^bsub>(A,B,C)\<^esub> S) =XBOOLE-0R4 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> proj1XTUPLE-0K12 S & proj1XTUPLE-0K12 (R *RELSET-2K9\<^bsub>(A,B,C)\<^esub> S) c=TARSKIR1 proj1XTUPLE-0K12 R"
sorry

mtheorem relset_2_th_52:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds  for S be RelationRELSET-1M1-of(B,C) holds proj2XTUPLE-0K13 (R *RELSET-2K9\<^bsub>(A,B,C)\<^esub> S) =XBOOLE-0R4 S .:RELSET-1K7\<^bsub>(B,C)\<^esub> proj2XTUPLE-0K13 R & proj2XTUPLE-0K13 (R *RELSET-2K9\<^bsub>(A,B,C)\<^esub> S) c=TARSKIR1 proj2XTUPLE-0K13 S"
sorry

mtheorem relset_2_th_53:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be RelationRELSET-1M1-of(A,B) holds X c=TARSKIR1 proj1XTUPLE-0K12 R iff X c=TARSKIR1 (R *RELSET-2K9\<^bsub>(A,B,A)\<^esub> R ~RELSET-1K3\<^bsub>(A,B)\<^esub>).:RELSET-1K7\<^bsub>(A,A)\<^esub> X"
sorry

mtheorem relset_2_th_54:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for Y be SubsetSUBSET-1M2-of B holds  for R be RelationRELSET-1M1-of(A,B) holds Y c=TARSKIR1 proj2XTUPLE-0K13 R iff Y c=TARSKIR1 (R ~RELSET-1K3\<^bsub>(A,B)\<^esub> *RELSET-2K9\<^bsub>(B,A,B)\<^esub> R).:RELSET-1K7\<^bsub>(B,B)\<^esub> Y"
sorry

mtheorem relset_2_th_55:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds proj1XTUPLE-0K12 R =XBOOLE-0R4 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> B & R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> (R .:RELSET-1K7\<^bsub>(A,B)\<^esub> A) =XBOOLE-0R4 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> proj2XTUPLE-0K13 R"
  using relset_2_th_50 sorry

mtheorem relset_2_th_56:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> B =XBOOLE-0R4 (R *RELSET-2K9\<^bsub>(A,B,A)\<^esub> R ~RELSET-1K3\<^bsub>(A,B)\<^esub>).:RELSET-1K7\<^bsub>(A,A)\<^esub> A"
sorry

mtheorem relset_2_th_57:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds R .:RELSET-1K7\<^bsub>(A,B)\<^esub> A =XBOOLE-0R4 (R ~RELSET-1K3\<^bsub>(A,B)\<^esub> *RELSET-2K9\<^bsub>(B,A,B)\<^esub> R).:RELSET-1K7\<^bsub>(B,B)\<^esub> B"
sorry

mtheorem relset_2_th_58:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for R be RelationRELSET-1M1-of(A,B) holds  for S be RelationRELSET-1M1-of(B,C) holds S .:^RELSET-2K8\<^bsub>(B,C)\<^esub> R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 (R *RELSET-2K9\<^bsub>(A,B,C)\<^esub> S `SUBSET-1K3\<^bsub>([:ZFMISC-1K2 B,C :])\<^esub>)`SUBSET-1K3\<^bsub>([:ZFMISC-1K2 A,C :])\<^esub> .:^RELSET-2K8\<^bsub>(A,C)\<^esub> X"
sorry

mtheorem relset_2_th_59:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds R `SUBSET-1K3\<^bsub>([:ZFMISC-1K2 A,B :])\<^esub> ~RELSET-1K3\<^bsub>(A,B)\<^esub> =RELSET-1R2\<^bsub>(B,A)\<^esub> (R ~RELSET-1K3\<^bsub>(A,B)\<^esub>)`SUBSET-1K3\<^bsub>([:ZFMISC-1K2 B,A :])\<^esub>"
sorry

mtheorem relset_2_th_60:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for Y be SubsetSUBSET-1M2-of B holds  for R be RelationRELSET-1M1-of(A,B) holds X c=TARSKIR1 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:^RELSET-2K8\<^bsub>(B,A)\<^esub> Y iff Y c=TARSKIR1 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X"
sorry

mtheorem relset_2_th_61:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for Y be SubsetSUBSET-1M2-of B holds  for R be RelationRELSET-1M1-of(A,B) holds R .:RELSET-1K7\<^bsub>(A,B)\<^esub> X `SUBSET-1K3\<^bsub>(A)\<^esub> c=TARSKIR1 Y `SUBSET-1K3\<^bsub>(B)\<^esub> iff R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:RELSET-1K7\<^bsub>(B,A)\<^esub> Y c=TARSKIR1 X"
sorry

mtheorem relset_2_th_62:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for Y be SubsetSUBSET-1M2-of B holds  for R be RelationRELSET-1M1-of(A,B) holds X c=TARSKIR1 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:^RELSET-2K8\<^bsub>(B,A)\<^esub> (R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X) & Y c=TARSKIR1 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> (R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:^RELSET-2K8\<^bsub>(B,A)\<^esub> Y)"
  using relset_2_th_60 sorry

mtheorem relset_2_th_63:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for X be SubsetSUBSET-1M2-of A holds  for Y be SubsetSUBSET-1M2-of B holds  for R be RelationRELSET-1M1-of(A,B) holds R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> (R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:^RELSET-2K8\<^bsub>(B,A)\<^esub> (R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> X)) & R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:^RELSET-2K8\<^bsub>(B,A)\<^esub> Y =XBOOLE-0R4 R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:^RELSET-2K8\<^bsub>(B,A)\<^esub> (R .:^RELSET-2K8\<^bsub>(A,B)\<^esub> (R ~RELSET-1K3\<^bsub>(A,B)\<^esub> .:^RELSET-2K8\<^bsub>(B,A)\<^esub> Y))"
sorry

mtheorem relset_2_th_64:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(A,B) holds idRELAT-1K7 A *RELAT-1K6 R =RELAT-1R1 R *RELAT-1K6 idRELAT-1K7 B"
sorry

end
